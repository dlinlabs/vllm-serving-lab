"""Unit and regression tests for native_campaign_protocol.

Validates ground-truth accounting, R3 rejection guards, observable state,
and >=10h campaign protocol generation.
"""

import json
import math
import os
from pathlib import Path
import sys
import time
import unittest

# Ensure module can be imported whether tests are run from native-v3 dir or repo root
sys.path.insert(0, str(Path(__file__).parent.resolve()))

from native_campaign_protocol import (
    WORKLOAD_FAMILIES,
    ActionableAcceptanceCriteria,
    ActuationComplianceAnalyzer,
    BenchmarkEpisodeResult,
    CausalActionPathwayValidator,
    CausalGatedPlanResponseModel,
    ClosedLoopBenchmarkHarness,
    ControllerDecision,
    DecodeRequestState,
    DeliveredTokensAuditResult,
    ExperimentDurationAccounting,
    FINAL_WORKLOAD_CLASSES,
    Fixed16Controller,
    GatewayEpoch,
    HeuristicBacklogController,
    HeuristicThresholdController,
    IndependentSeedBlockOutcome,
    MarkedReservationRecord,
    MeasuredIntervalReceipt,
    MultiHorizonPlan,
    ObservableBatchState,
    OnlineCutObservationAdapter,
    PolicyBestTrainSelectedFixed,
    PolicyFixed16,
    PolicyOneMove,
    PolicyReactive,
    PolicyRecedingHorizonMPC,
    PrefillRequestState,
    PreregisteredFinalProtocol,
    PublishedHistoryView,
    RecedingHorizonMPCController,
    RequestOutcome,
    StreamedRequest,
    StrongOneMoveController,
    StructuralBatchProgressHybridModel,
    StructuralBatchProgressState,
    SuperiorityEvaluator,
    UnconstrainedDirectPlanModel,
    WorkAccounting,
    audit_native_qualification_tail_distribution,
    audit_train_block_diagnostics,
    build_native_campaign_protocol,
    build_preregistered_final_protocol,
    calculate_benchmark_outcomes,
    canonical_digest,
    canonical_join_observations,
    compute_normalized_absolute_error,
    compute_work_accounting,
    demonstrate_astra_selection_defect,
    demonstrate_sol_block_ceiling_and_float_defect,
    ensure_integration_paths,
    generate_workload_tape,
    holm_bonferroni_step_down,
    is_finite_real,
    plan_gateway_epochs,
    robust_paired_permutation_test,
    run_direct_plan_vs_causal_hybrid_discriminator,
    run_legacy_delivered_tokens_audit,
    run_real_pipeline_episode,
    run_simulate_plan_causal_interference_witness,
    run_structural_progress_vs_scalar_diagnostic,
    RealPipelineControlHarness,
    RealPipelineServingTransport,
    is_foreign_abi_site_packages,
    validate_request_outcome,
    verify_gpu_elapsed_clock_semantics,
)


class TestGroundTruthAccounting(unittest.TestCase):
    """Test verification of the ground-truth baseline fact and work accounting."""

    def test_legacy_strict_audit_remains_false(self):
        """The strict v2 audit must evaluate to FALSE and not be silently relaxed."""
        audit = run_legacy_delivered_tokens_audit(
            prompt_tokens=4096,
            delivered_tokens=32,
            worker_forward_end_position=4128,
            total_forward_steps=34,
            prefill_steps=2,
            decode_steps=32,
        )
        self.assertIsInstance(audit, DeliveredTokensAuditResult)
        self.assertFalse(audit.strict_v2_match, "Strict audit must be False per ground truth")
        self.assertEqual(audit.delivered_token_minimum_position, 4127)
        self.assertEqual(audit.worker_forward_end_position, 4128)
        self.assertIn("Strict audit FALSE", audit.reason)

    def test_explicit_work_accounting(self):
        """Useful, physical, and tail work must be explicitly decomposed without masking."""
        acct = compute_work_accounting(
            prompt_tokens=4096,
            delivered_tokens=32,
            worker_forward_end_position=4128,
            total_forward_steps=34,
            prefill_steps=2,
            decode_steps=32,
        )
        self.assertIsInstance(acct, WorkAccounting)
        self.assertEqual(acct.useful_prompt_tokens, 4096)
        self.assertEqual(acct.useful_output_tokens, 32)
        self.assertEqual(acct.useful_prompt_tokens + acct.useful_output_tokens, 4128)
        self.assertEqual(acct.useful_token_minimum_position, 4127)
        self.assertEqual(acct.physical_executed_positions, 4128)
        self.assertEqual(acct.tail_work_tokens, 1)
        self.assertEqual(acct.missing_work_tokens, 0)
        self.assertEqual(acct.tail_work_steps, 1)
        self.assertTrue(acct.accounted)
        self.assertIn("pre-finish scheduler placeholder 1", acct.tail_work_cause)
        self.assertAlmostEqual(acct.tail_work_tokens / acct.useful_output_tokens, 1.0 / 32.0)

        # Missing work case (physical < useful minimum)
        acct_miss = compute_work_accounting(
            prompt_tokens=4096,
            delivered_tokens=32,
            worker_forward_end_position=4100,
            total_forward_steps=30,
            prefill_steps=2,
            decode_steps=28,
        )
        self.assertEqual(acct_miss.missing_work_tokens, 27)
        self.assertEqual(acct_miss.tail_work_tokens, -27)
        self.assertFalse(acct_miss.accounted)

        # Unexplained tail case (tail > 1)
        acct_excess = compute_work_accounting(
            prompt_tokens=4096,
            delivered_tokens=32,
            worker_forward_end_position=4200,
            total_forward_steps=40,
            prefill_steps=2,
            decode_steps=38,
        )
        self.assertEqual(acct_excess.tail_work_tokens, 73)
        self.assertFalse(acct_excess.accounted)

    def test_gpu_elapsed_and_serial_falsification(self):
        """GPU elapsed is not an exclusive single-tenant service duration."""
        res = verify_gpu_elapsed_clock_semantics(
            http_residence_s=1.2,
            gpu_kernel_forward_elapsed_s=0.4,
            active_concurrent_requests=8,
            measured_throughput_completions=2449,
            measurement_window_s=90.0,
            serial_max_theoretical_completions=2004,
        )
        self.assertFalse(res["kernel_exceeds_residence"])
        self.assertFalse(res["concurrency_alone_falsifies_serial"])
        self.assertTrue(res["serial_service_model_falsified_by_throughput"])


class TestOutcomeValidationAndR3Rejection(unittest.TestCase):
    """Test outcome validation rejecting R3 flaws (zero tokens, NaN origin, pseudoreplication)."""

    def test_zero_completion_tokens_rejected(self):
        """0 output tokens must be rejected as invalid and not scored as good."""
        outcome = RequestOutcome(
            request_id="req-zero",
            prompt_tokens=128,
            output_tokens=0,  # Flaw in R3
            scheduled_at=10.0,
            client_post_at=10.05,
            first_content_at=10.2,
            terminal_at=10.25,
            origin_s=10.0,
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertFalse(val["valid"])
        self.assertFalse(val["is_good"])
        self.assertIn("invalid_output_token_count_must_be_positive_integer_not_bool", val["rejection_reasons"])

    def test_boolean_tokens_rejected(self):
        """Boolean tokens (bool is subclass of int in Python) must be explicitly rejected."""
        outcome = RequestOutcome(
            request_id="req-bool",
            prompt_tokens=True,  # Flaw: boolean prompt
            output_tokens=True,  # Flaw: boolean output
            scheduled_at=10.0,
            client_post_at=10.05,
            first_content_at=10.2,
            terminal_at=10.25,
            origin_s=10.0,
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertFalse(val["valid"])
        self.assertIn("invalid_prompt_token_count_must_be_positive_integer_not_bool", val["rejection_reasons"])
        self.assertIn("invalid_output_token_count_must_be_positive_integer_not_bool", val["rejection_reasons"])

    def test_chronology_inversion_rejected(self):
        """Client POST timestamp occurring after first token or terminal must be rejected."""
        outcome = RequestOutcome(
            request_id="req-chrono",
            prompt_tokens=128,
            output_tokens=32,
            scheduled_at=10.0,
            client_post_at=100.0,  # Flaw: client POST at 100 after first at 10.1
            first_content_at=10.1,
            terminal_at=10.2,
            origin_s=10.0,
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertFalse(val["valid"])
        self.assertIn("chronology_inversion_post_after_first", val["rejection_reasons"])

    def test_nan_origin_rejected(self):
        """NaN origin timestamp must be rejected as invalid."""
        outcome = RequestOutcome(
            request_id="req-nan",
            prompt_tokens=128,
            output_tokens=16,
            scheduled_at=10.0,
            client_post_at=10.05,
            first_content_at=10.2,
            terminal_at=10.5,
            origin_s=float("nan"),  # Flaw in R3
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertFalse(val["valid"])
        self.assertFalse(val["is_good"])
        self.assertIn("nonfinite_origin_timestamp", val["rejection_reasons"])

    def test_valid_good_outcome(self):
        """A properly formatted request meeting SLOs must be scored good."""
        outcome = RequestOutcome(
            request_id="req-valid",
            prompt_tokens=128,
            output_tokens=32,
            scheduled_at=10.0,
            client_post_at=10.01,
            first_content_at=10.15,  # TTFT = 0.15s <= 0.5s
            terminal_at=10.77,       # TPOT = (10.77 - 10.15) / 31 = 0.02s <= 0.05s
            origin_s=10.0,
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertTrue(val["valid"])
        self.assertTrue(val["is_good"])
        self.assertAlmostEqual(val["ttft_s"], 0.15)
        self.assertAlmostEqual(val["tpot_s"], 0.02)

    def test_evaluator_rejects_pseudoreplication(self):
        """Duplicating the identical block (R3 flaw) must trigger pseudoreplication rejection."""
        evaluator = SuperiorityEvaluator(min_blocks=6)
        single_block = IndependentSeedBlockOutcome(
            block_id="block-dup",
            seed=170001,
            workload_family="short_homogeneous",
            split="development",
            duration_s=10.0,
            control_decisions=10,
            offered_requests=100,
            policy_a_good_completions=10,
            policy_a_rejections=5,
            policy_a_solver_overruns=0,
            policy_b_good_completions=20,
            policy_b_rejections=5,
            policy_b_solver_overruns=0,
        )
        # Duplicate identical block 6 times
        replicated_blocks = [single_block] * 6
        res = evaluator.evaluate(replicated_blocks)
        self.assertEqual(res["verdict"], "REJECTED_PSEUDOREPLICATION")
        self.assertFalse(res["statistically_significant"])

    def test_impossible_aggregates_rejected(self):
        """Aggregates with more good completions than offered requests must raise ValueError."""
        with self.assertRaises(ValueError):
            IndependentSeedBlockOutcome(
                block_id="block-impossible",
                seed=170001,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=10,
                offered_requests=5,
                policy_a_good_completions=10,  # 10 > 5 is physically impossible
                policy_a_rejections=0,
                policy_a_solver_overruns=0,
                policy_b_good_completions=2,
                policy_b_rejections=0,
                policy_b_solver_overruns=0,
            )

    def test_evaluator_exact_permutation_and_zero_variance_handling(self):
        """Equal independent differences are evaluated by exact sign-flip without artificial crash."""
        evaluator = SuperiorityEvaluator(min_blocks=6, pre_registered_margin_req_s=0.5)
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"block-{i}",
                seed=170000 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=10,
                offered_requests=100,
                policy_a_good_completions=10,
                policy_a_rejections=5,
                policy_a_solver_overruns=0,
                policy_b_good_completions=20,  # Exactly +1.0 req/s difference across all
                policy_b_rejections=5,
                policy_b_solver_overruns=0,
            )
            for i in range(6)
        ]
        res = evaluator.evaluate(blocks)
        # For N=6 identical signs, two-sided exact sign-flip p-value is 2 / (2^6) = 2/64 = 0.03125
        self.assertEqual(res["verdict"], "DISTINGUISHABLE_FROM_NULL")
        self.assertAlmostEqual(res["two_sided_permutation_p_value"], 0.03125)
        self.assertGreaterEqual(res["two_sided_permutation_p_value"], 1.0 / (2 ** (6 - 1)))
        self.assertAlmostEqual(res["bootstrap_ci95"][0], 1.0)
        self.assertAlmostEqual(res["bootstrap_ci95"][1], 1.0)

    def test_evaluator_confirms_valid_superiority(self):
        """Independent blocks with natural variance and genuine margin can achieve confirmation."""
        evaluator = SuperiorityEvaluator(
            min_blocks=6,
            pre_registered_margin_req_s=0.5,
        )
        # 8 independent blocks with positive mean improvement and natural variance
        good_b = [22, 24, 21, 25, 23, 26, 22, 24]
        good_a = [12, 11, 13, 10, 12, 11, 13, 12]
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"valid-block-{i}",
                seed=170010 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=10,
                offered_requests=100,
                policy_a_good_completions=good_a[i],
                policy_a_rejections=5,
                policy_a_solver_overruns=0,
                policy_b_good_completions=good_b[i],
                policy_b_rejections=5,
                policy_b_solver_overruns=0,
            )
            for i in range(8)
        ]
        res = evaluator.evaluate(blocks)
        self.assertEqual(res["verdict"], "DISTINGUISHABLE_FROM_NULL")
        self.assertTrue(res["statistically_significant"])
        self.assertTrue(res["margin_satisfied"])
        self.assertGreater(res["std_goodput_difference"], 0.0)
        self.assertGreaterEqual(res["two_sided_permutation_p_value"], 1.0 / (2 ** (8 - 1)))

    def test_holm_bonferroni_correction(self):
        """Holm-Bonferroni step-down must correctly control FWER."""
        raw_p = [0.005, 0.02, 0.03, 0.10]
        adj = holm_bonferroni_step_down(raw_p, familywise_alpha=0.05)
        # Sorted: 0.005 (x4=0.02 <= 0.05 -> True), 0.02 (x3=0.06 > 0.05 -> False), ...
        self.assertTrue(adj[0]["significant_after_correction"])
        self.assertFalse(adj[1]["significant_after_correction"])
        self.assertFalse(adj[2]["significant_after_correction"])
        self.assertFalse(adj[3]["significant_after_correction"])


class TestObservableBatchState(unittest.TestCase):
    """Test observable Gateway state, soft-cap behavior, and conservation."""

    def test_soft_cap_reduction_does_not_evict(self):
        """Lowering applied cap from 32 to 16 must NOT evict existing reservations."""
        state = ObservableBatchState(initial_cap=32.0)
        
        # Admit 3 requests with cost 8.0 each -> total 24.0
        for i in range(3):
            admitted = state.admit(MarkedReservationRecord(
                request_id=f"r-{i}",
                original_cost=8.0,
                admitted_at=10.0 + i,
                prompt_tokens=256,
                max_tokens=128,
            ))
            self.assertTrue(admitted)
            
        self.assertEqual(state.reserved_cost, 24.0)
        
        # Lower cap to 16.0
        state.update_cap(16.0)
        self.assertEqual(state.applied_cap, 16.0)
        # Invariant: existing reservations survive
        self.assertEqual(state.reserved_cost, 24.0)
        self.assertEqual(len(state.active_reservations), 3)
        
        # New admission is throttled because 24.0 + 4.0 > 16.0
        new_admitted = state.admit(MarkedReservationRecord(
            request_id="r-new",
            original_cost=4.0,
            admitted_at=15.0,
            prompt_tokens=128,
            max_tokens=128,
        ))
        self.assertFalse(new_admitted)

    def test_release_and_conservation(self):
        """Releasing terminal reservations strictly decreases reserved cost without duplicate reuse."""
        state = ObservableBatchState(initial_cap=32.0)
        rec = MarkedReservationRecord(
            request_id="r-term",
            original_cost=6.5,
            admitted_at=10.0,
            prompt_tokens=512,
            max_tokens=128,
        )
        state.admit(rec)
        self.assertEqual(state.reserved_cost, 6.5)

        # Duplicate admission of the active request must raise ValueError
        with self.assertRaises(ValueError):
            state.admit(rec)

        released = state.release("r-term", timestamp_s=12.5)
        self.assertIsNotNone(released)
        self.assertEqual(state.reserved_cost, 0.0)
        self.assertEqual(len(state.history_released), 1)

        # Re-releasing non-active request returns None
        self.assertIsNone(state.release("r-term", timestamp_s=13.0))
        self.assertEqual(state.reserved_cost, 0.0)

    def test_normalized_absolute_error_computation(self):
        """NAE across multi-step horizons must be correctly normalized."""
        pred = {1: 4.0, 3: 8.0, 5: 12.0}
        actual = {1: 5.0, 3: 8.0, 5: 10.0}
        origin_r = 16.0
        
        res = compute_normalized_absolute_error(pred, actual, origin_r)
        self.assertFalse(res["empty_origin"])
        # |4-5|/16 = 1/16, |8-8|/16 = 0, |12-10|/16 = 2/16 -> mean = (3/16)/3 = 1/16 = 0.0625
        self.assertAlmostEqual(res["mean_normalized_absolute_error"], 0.0625)


class TestCampaignProtocolBuilder(unittest.TestCase):
    """Test campaign protocol builder properties (duration, workloads, splits, immutability)."""

    def test_protocol_builder_duration_exceeds_10_hours(self):
        """The protocol must schedule >= 10.0 hours of active execution."""
        protocol = build_native_campaign_protocol()
        hours = protocol["duration_summary"]["total_active_hours"]
        self.assertGreaterEqual(hours, 10.0, f"Scheduled hours {hours:.2f}h must be >= 10.0h")
        self.assertTrue(protocol["duration_summary"]["hours_requirement_satisfied"])
        self.assertEqual(protocol["duration_summary"]["total_episodes"], 320)

    def test_eight_workload_families_present(self):
        """All 8 workload families must be declared and populated in the protocol."""
        protocol = build_native_campaign_protocol()
        self.assertEqual(len(protocol["workload_families"]), 8)
        for fam in WORKLOAD_FAMILIES:
            self.assertIn(fam, protocol["workload_families"])

    def test_splits_and_seed_isolation(self):
        """Train, calibration, development, and final splits must be populated with fresh seeds."""
        protocol = build_native_campaign_protocol(base_seed=180001)
        groups = protocol["groups"]
        all_seeds = [g["seed"] for g in groups.values()]
        
        # Verify no duplicate seeds
        self.assertEqual(len(all_seeds), len(set(all_seeds)))
        
        # Verify historical held-out seeds 160021-160024 are NOT used
        for seed in all_seeds:
            self.assertFalse(
                160021 <= seed <= 160024,
                f"Seed {seed} must not overlap with historical final held-out seeds 160021-160024!",
            )

    def test_matched_arms_share_tape(self):
        """Matched arms (0 and 1) must share identical arrival and prompt tape keys."""
        protocol = build_native_campaign_protocol()
        episodes = protocol["episodes"]
        
        # Group episodes by block_id
        by_block = {}
        for ep in episodes:
            by_block.setdefault(ep["block_id"], []).append(ep)
            
        for block_id, eps in by_block.items():
            self.assertEqual(len(eps), 2, f"Block {block_id} must have exactly 2 matched arms")
            arm0, arm1 = sorted(eps, key=lambda x: x["arm"])
            self.assertEqual(arm0["arm"], 0)
            self.assertEqual(arm1["arm"], 1)
            self.assertEqual(arm0["arrival_tape_key"], arm1["arrival_tape_key"])
            self.assertEqual(arm0["prompt_tape_key"], arm1["prompt_tape_key"])

    def test_canonical_digest_immutability(self):
        """Protocol hash must be a deterministic 64-character SHA-256 hex string."""
        p1 = build_native_campaign_protocol()
        p2 = build_native_campaign_protocol()
        self.assertEqual(p1["protocol_hash"], p2["protocol_hash"])
        self.assertEqual(len(p1["protocol_hash"]), 64)

    def test_protocol_json_serialization_roundtrip(self):
        """Protocol must serialize to valid JSON without NaN or Inf and roundtrip exactly."""
        protocol = build_native_campaign_protocol()
        json_str = json.dumps(protocol, allow_nan=False)
        roundtrip = json.loads(json_str)
        self.assertEqual(protocol["protocol_hash"], roundtrip["protocol_hash"])
        self.assertEqual(len(roundtrip["episodes"]), 320)

    def test_overrun_guard_rejection(self):
        """Excessive decision overruns must trigger REJECTED_OVERRUN_GUARD."""
        evaluator = SuperiorityEvaluator(min_blocks=6, max_decision_overrun_rate=0.01)
        good_b = [22, 24, 21, 25, 23, 26]
        good_a = [12, 11, 13, 10, 12, 11]
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"overrun-block-{i}",
                seed=170050 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=100,
                offered_requests=100,
                policy_a_good_completions=good_a[i],
                policy_a_rejections=5,
                policy_a_solver_overruns=0,
                policy_b_good_completions=good_b[i],
                policy_b_rejections=5,
                policy_b_solver_overruns=5,  # 5% overrun rate > 1% threshold
            )
            for i in range(6)
        ]
        res = evaluator.evaluate(blocks)
        self.assertEqual(res["verdict"], "REJECTED_OVERRUN_GUARD")
        self.assertFalse(res["overrun_guard_passed"])

    def test_rejection_guard_rejection(self):
        """Excessive relative rejection increase must trigger REJECTED_REJECTION_GUARD."""
        evaluator = SuperiorityEvaluator(min_blocks=6, max_relative_rejection_increase=0.05)
        good_b = [22, 24, 21, 25, 23, 26]
        good_a = [12, 11, 13, 10, 12, 11]
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"rej-block-{i}",
                seed=170060 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=100,
                offered_requests=100,
                policy_a_good_completions=good_a[i],
                policy_a_rejections=10,
                policy_a_solver_overruns=0,
                policy_b_good_completions=good_b[i],
                policy_b_rejections=15,  # 50% relative increase > 5% threshold
                policy_b_solver_overruns=0,
            )
            for i in range(6)
        ]
        res = evaluator.evaluate(blocks)
        self.assertEqual(res["verdict"], "REJECTED_REJECTION_GUARD")
        self.assertFalse(res["rejection_guard_passed"])

    def test_controllers_produce_valid_budgets(self):
        """All supported valid baseline controllers must produce allowed budgets in {16.0, 32.0}."""
        state = ObservableBatchState(initial_cap=16.0)
        controllers = [
            Fixed16Controller(),
            HeuristicBacklogController(),
            HeuristicThresholdController(),
        ]
        for ctrl in controllers:
            decision = ctrl.decide(state, queue_length=5)
            self.assertIn(decision, (16.0, 32.0))

    def test_misleading_mpc_aliases_rejected(self):
        """Calling StrongOneMoveController or RecedingHorizonMPCController must raise RuntimeError."""
        with self.assertRaises(RuntimeError):
            StrongOneMoveController()
        with self.assertRaises(RuntimeError):
            RecedingHorizonMPCController()


class TestRound2PeerCounterexamplesAndSurgicalFixes(unittest.TestCase):
    """Round 2 tests: reproducible counterexamples, peer bug demonstrations, and surgical fixes."""

    def test_astra_selection_defect_reproduced_and_fixed(self):
        """Astra's decision tree drops resolved Two-Move actions when One-Move is unresolved."""
        res = demonstrate_astra_selection_defect()
        # Verify Astra unfixed status falls back to uncertainty despite Two-Move being resolved
        self.assertFalse(res["one_resolved"], "One-move should be unresolved")
        self.assertTrue(res["two_resolved"], "Two-move should be resolved")
        self.assertGreater(res["gain_lower"], 0.0, "Two-move has strictly positive lower gain")
        self.assertEqual(res["astra_unfixed_status"], "fallback")
        self.assertEqual(res["astra_unfixed_reason"], "first-action uncertainty")
        self.assertIsNone(res["astra_unfixed_cap"], "Astra sends no command despite resolved action")
        
        # Verify surgical fix resolves to shadow action with cap 16
        self.assertEqual(res["surgical_fixed_status"], "shadow")
        self.assertEqual(res["surgical_fixed_chosen"], "two")
        self.assertEqual(res["surgical_fixed_cap"], 16)

    def test_sol_block_ceiling_and_float_defect_reproduced_and_fixed(self):
        """Sol's paired_effect crashes on N > 16 blocks, and its scheduled float check is brittle."""
        res = demonstrate_sol_block_ceiling_and_float_defect()
        self.assertTrue(res["sol_crashes_on_dev_split_32_blocks"])
        self.assertTrue(res["exact_float_inequality_triggered"])
        self.assertGreater(res["float_difference"], 0.0)

        # Test robust permutation test on small N (exact rational enumeration)
        effects_small = [0.1, 0.2, 0.15, 0.3, -0.05, 0.25]
        res_exact = robust_paired_permutation_test(effects_small, max_exact_n=16)
        self.assertEqual(res_exact["n_blocks"], 6)
        self.assertTrue(res_exact["method"].startswith("exact_sign_flip_rational"))
        self.assertLess(res_exact["p_value"], 0.1)

        # Test robust permutation test on large N=32 (development split scale) via Monte Carlo
        effects_dev = [0.15 + (0.02 * (i % 5) - 0.04) for i in range(32)]
        res_mc = robust_paired_permutation_test(effects_dev, max_exact_n=16, mc_samples=1000)
        self.assertEqual(res_mc["n_blocks"], 32)
        self.assertTrue(res_mc["method"].startswith("conservative_monte_carlo_permutation"))
        self.assertTrue(res_mc["statistically_significant"])

    def test_robust_permutation_exact_rational_regression_491c42b7(self):
        """Regression test for 491c42b7: exact rational sign arithmetic must not collapse at 1e-15."""
        # On 491c42b7 with 1e-12 tolerance, [1e-15]*4 returned p=1.0 instead of exact 0.125
        res_tiny = robust_paired_permutation_test([1e-15, 1e-15, 1e-15, 1e-15])
        self.assertEqual(res_tiny["n_blocks"], 4)
        self.assertAlmostEqual(res_tiny["p_value"], 0.125)
        self.assertTrue(res_tiny["exact_rational_arithmetic"])

        # Identical result for [1.0, 1.0, 1.0, 1.0]
        res_unit = robust_paired_permutation_test([1.0, 1.0, 1.0, 1.0])
        self.assertAlmostEqual(res_unit["p_value"], 0.125)

        # Reject non-finite inputs
        with self.assertRaises(ValueError):
            robust_paired_permutation_test([1.0, float("nan"), 1.0])

    def test_actual_duration_accounting_falsifies_planned_time(self):
        """Planned time, setup, idle, and drain cannot be counted as completed >=10h science."""
        # Case A: 48,000s planned, but only 18,000s realized active measurement
        acct_partial = ExperimentDurationAccounting(
            planned_windows_count=400,
            window_duration_seconds=120.0,
            planned_active_measurement_seconds=48000.0,
            realized_active_measurement_seconds=18000.0,  # 5 hours
            drain_duration_seconds=6000.0,
            epoch_rollover_duration_seconds=1200.0,
            setup_and_idle_seconds=14400.0,
            verified_interval_durations_s=(120.0,) * 150,
        )
        passed, reason = acct_partial.validate_actual_10h_milestone()
        self.assertFalse(passed, "Planned 48ks and idle time cannot pass 10h threshold")
        self.assertIn("Falsified", reason)

        # Case B: 36,050s realized active measurement WITH verified interval evidence (meets requirement)
        intervals_300 = (120.16666666666667,) * 300
        acct_complete = ExperimentDurationAccounting(
            planned_windows_count=320,
            window_duration_seconds=120.0,
            planned_active_measurement_seconds=38400.0,
            realized_active_measurement_seconds=36050.0,  # > 10.0h
            drain_duration_seconds=2400.0,
            epoch_rollover_duration_seconds=600.0,
            setup_and_idle_seconds=1800.0,
            verified_interval_durations_s=intervals_300,
        )
        passed_comp, reason_comp = acct_complete.validate_actual_10h_milestone()
        self.assertTrue(passed_comp)
        self.assertIn("Qualified", reason_comp)

    def test_actual_duration_accounting_regression_nan_inf_and_naked_scalar(self):
        """Regression test for 491c42b7: reject NaN, Inf, and naked unverified caller scalars."""
        # 1. Reject NaN in constructor
        with self.assertRaises(ValueError):
            ExperimentDurationAccounting(
                planned_windows_count=400,
                window_duration_seconds=120.0,
                planned_active_measurement_seconds=48000.0,
                realized_active_measurement_seconds=float("nan"),
                drain_duration_seconds=100.0,
                epoch_rollover_duration_seconds=100.0,
                setup_and_idle_seconds=100.0,
            )

        # 2. Reject Inf in constructor
        with self.assertRaises(ValueError):
            ExperimentDurationAccounting(
                planned_windows_count=400,
                window_duration_seconds=120.0,
                planned_active_measurement_seconds=48000.0,
                realized_active_measurement_seconds=float("inf"),
                drain_duration_seconds=100.0,
                epoch_rollover_duration_seconds=100.0,
                setup_and_idle_seconds=100.0,
            )

        # 3. Reject naked caller scalar 36050.0 lacking verified interval evidence
        acct_naked = ExperimentDurationAccounting(
            planned_windows_count=400,
            window_duration_seconds=120.0,
            planned_active_measurement_seconds=48000.0,
            realized_active_measurement_seconds=36050.0,
            drain_duration_seconds=100.0,
            epoch_rollover_duration_seconds=100.0,
            setup_and_idle_seconds=100.0,
            verified_interval_durations_s=None,  # Naked scalar without interval receipts
        )
        passed_naked, reason_naked = acct_naked.validate_actual_10h_milestone()
        self.assertFalse(passed_naked)
        self.assertIn("lacks verified interval evidence", reason_naked)

    def test_gateway_epoch_rollovers_respect_1024_op_ceiling(self):
        """Gateway epochs must bound operations below 1024 without restarting native engine."""
        protocol = build_native_campaign_protocol()
        episodes = protocol["episodes"]
        epochs = plan_gateway_epochs(episodes, episodes_per_epoch=2, max_ops_per_epoch=1024)
        
        # 320 episodes / 2 episodes per epoch = 160 epochs
        self.assertEqual(len(epochs), 160)
        for ep in epochs:
            self.assertEqual(len(ep.episode_ids), 2)
            self.assertLess(ep.estimated_operations, 1024)
            self.assertTrue(ep.requires_strict_drain_before_rollover)
            self.assertFalse(ep.requires_native_restart)
            self.assertFalse(ep.evict_idempotency_tables)
            self.assertTrue(ep.clock_domain.startswith("linux-monotonic:"))
            self.assertEqual(ep.clock_domain, epochs[0].clock_domain)
            self.assertEqual(ep.cache_type, "in_memory")

    def test_qualification_tail_distribution_audit(self):
        """Authoritative qualification receipt 2587d2b proves 100% tail incidence on LIGHT requests."""
        audit = audit_native_qualification_tail_distribution()
        self.assertEqual(audit["qualification_commit"], "2587d2b")
        self.assertEqual(audit["total_requests"], 40)
        self.assertEqual(audit["natural_eos_count"], 40)
        self.assertEqual(audit["v3_audits_valid"], 16)
        self.assertEqual(audit["legacy_v2_audits_retained_false"], 8)
        self.assertEqual(audit["light_requests_measured"], 20)
        self.assertEqual(audit["light_requests_with_tail"], 20)
        self.assertAlmostEqual(audit["measured_tail_incidence_rate"], 1.0)
        self.assertEqual(audit["off_requests_unmeasured"], 20)
        self.assertFalse(audit["tail_is_stochastic_0_1"])

    def test_canonical_join_observations(self):
        """Canonical observation joiner must resolve chatcmpl-<32hex>-<8hex> to <32hex>."""
        gw_marks = [
            {"request_id": "a" * 32, "client_post_at": 10.0, "status": "accepted"},
            {"request_id": "b" * 32, "client_post_at": 10.1, "status": "accepted"},
            {"request_id": "c" * 32, "client_post_at": 10.2, "status": "accepted"},
        ]
        native_frame = {
            "requests": [
                {
                    "request_id": f"chatcmpl-{'a' * 32}-12345678",
                    "computed_tokens": 128,
                    "output_tokens": 16,
                }
            ]
        }
        res = canonical_join_observations(gw_marks, native_frame)
        self.assertEqual(res["total_gateway_marks"], 3)
        self.assertEqual(res["joined_native_running"], 1)
        # 2 marks were accepted by Gateway but not visible in native running
        self.assertEqual(res["accepted_not_native_visible_count"], 2)
        self.assertAlmostEqual(res["accepted_not_native_visible_ratio"], 2.0 / 3.0)
        self.assertTrue(res["canonical_normalization_verified"])


class TestTrainDiagnosticsAndCausalOnlineCut(unittest.TestCase):
    """Test online cut causal conditioning and Train seedblock 181001 diagnostics."""

    def test_online_cut_filters_strictly_before_cut(self):
        """Observations after cut timestamp must be excluded to prevent future leakage."""
        adapter = OnlineCutObservationAdapter(
            cut_time_s=100.0,
            applied_action_sequence=(16.0, 32.0),
            cas_delay_s=0.05,
        )
        observations = [
            {"request_id": "r1", "receipt_at": 99.5, "status": "accepted"},
            {"request_id": "r2", "receipt_at": 100.0, "status": "accepted"},
            {"request_id": "r3", "receipt_at": 100.05, "status": "accepted"},  # Future
            {"request_id": "r4", "status": "accepted"},  # Missing receipt
        ]
        filtered = adapter.filter_observations(observations)
        self.assertEqual(len(filtered), 2)
        self.assertEqual([o["request_id"] for o in filtered], ["r1", "r2"])
        self.assertTrue(adapter.verify_no_post_action_leakage(filtered, action_application_time_s=100.05))

    def test_online_cut_rejects_post_action_causal_inversion(self):
        """Action applied before cut timestamp must raise a causal violation ValueError."""
        adapter = OnlineCutObservationAdapter(
            cut_time_s=100.0,
            applied_action_sequence=(16.0, 32.0),
        )
        filtered = [{"request_id": "r1", "receipt_at": 99.0}]
        with self.assertRaises(ValueError):
            adapter.verify_no_post_action_leakage(filtered, action_application_time_s=98.0)

    def test_sequence_order_preserved_no_average_aliasing(self):
        """Sequence [16, 32] is not aliased to scalar average 24.0 or reversed order [32, 16]."""
        adapter1 = OnlineCutObservationAdapter(cut_time_s=10.0, applied_action_sequence=(16.0, 32.0))
        adapter2 = OnlineCutObservationAdapter(cut_time_s=10.0, applied_action_sequence=(32.0, 16.0))
        self.assertNotEqual(adapter1.applied_action_sequence, adapter2.applied_action_sequence)
        with self.assertRaises(ValueError):
            OnlineCutObservationAdapter(cut_time_s=10.0, applied_action_sequence=(24.0,))  # Average cap invalid

    def test_train_block_diagnostics_audit(self):
        """Train seedblock 181001 diagnostics demonstrate transient memory and KV usage."""
        diag_path = "/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-long01-replica/first-train-block-descriptive-diagnostics.json"
        if os.path.exists(diag_path):
            with open(diag_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            audit = audit_train_block_diagnostics(data)
            self.assertEqual(audit["seedblock"], 181001)
            self.assertEqual(audit["cells_audited"], 5)
            self.assertAlmostEqual(audit["max_overall_kv_usage"], 0.37247, places=3)
            # Short p128-m128 transient ratio ~14% (112 / 795)
            self.assertAlmostEqual(audit["short_p128_m128_transient_ratio"], 112 / 795, places=3)
            # Prefill-heavy p4096-m128 transient ratio ~40% (363 / 909)
            self.assertAlmostEqual(audit["prefill_p4096_m128_transient_ratio"], 363 / 909, places=3)
            self.assertIn("1.25s to 3.24s", audit["control_timescale_justification"])


class TestRound4IndependentCritiqueAndReceiptHardening(unittest.TestCase):
    """Round 4 tests validating interval non-overlap, clock domain homogeneity, and finite-B conservatism."""

    def test_duration_accounting_rejects_overlapping_intervals_double_count(self):
        """Overlapping execution intervals on the same Pod cannot be counted twice toward 10h."""
        # Two arms running concurrently during [0, 20000s].
        # Naive sum is 40,000s (> 10h), but disjoint union duration is only 20,000s (< 10h).
        receipts = (
            MeasuredIntervalReceipt(
                start_s=0.0,
                end_s=20000.0,
                epoch_id="epoch-001",
                clock_domain="linux-monotonic:pod1",
                arm=0,
            ),
            MeasuredIntervalReceipt(
                start_s=0.0,
                end_s=20000.0,
                epoch_id="epoch-001",
                clock_domain="linux-monotonic:pod1",
                arm=1,
            ),
        )
        # Caller claims naive sum 40000.0 as realized measurement time
        acct = ExperimentDurationAccounting(
            planned_windows_count=400,
            window_duration_seconds=120.0,
            planned_active_measurement_seconds=48000.0,
            realized_active_measurement_seconds=40000.0,
            drain_duration_seconds=100.0,
            epoch_rollover_duration_seconds=100.0,
            setup_and_idle_seconds=100.0,
            verified_interval_receipts=receipts,
        )
        passed, reason = acct.validate_actual_10h_milestone()
        self.assertFalse(passed)
        self.assertIn("double-counts overlapping intervals", reason)

    def test_duration_accounting_rejects_mismatched_clock_domain_or_unrelated_epoch(self):
        """Interval receipts from unrelated source epochs or mismatched clock domains must be rejected."""
        receipts = (
            MeasuredIntervalReceipt(
                start_s=0.0,
                end_s=18000.0,
                epoch_id="epoch-001",
                clock_domain="linux-monotonic:pod1-valid",
                arm=0,
            ),
            MeasuredIntervalReceipt(
                start_s=18000.0,
                end_s=36500.0,
                epoch_id="epoch-unrelated",
                clock_domain="linux-monotonic:pod2-alien-reboot",
                arm=0,
            ),
        )
        acct = ExperimentDurationAccounting(
            planned_windows_count=400,
            window_duration_seconds=120.0,
            planned_active_measurement_seconds=48000.0,
            realized_active_measurement_seconds=36500.0,
            drain_duration_seconds=100.0,
            epoch_rollover_duration_seconds=100.0,
            setup_and_idle_seconds=100.0,
            verified_interval_receipts=receipts,
        )
        passed, reason = acct.validate_actual_10h_milestone(expected_clock_domain="linux-monotonic:pod1-valid")
        self.assertFalse(passed)
        self.assertIn("unrelated clock domain", reason)

    def test_duration_accounting_qualifies_disjoint_intervals_exceeding_10h(self):
        """Disjoint interval receipts exceeding 36,000s under constant clock domain must qualify."""
        receipts = (
            MeasuredIntervalReceipt(
                start_s=0.0,
                end_s=18000.0,
                epoch_id="epoch-001",
                clock_domain="linux-monotonic:pod1-valid",
                arm=0,
            ),
            # Gap of 100s between epochs
            MeasuredIntervalReceipt(
                start_s=18100.0,
                end_s=36200.0,
                epoch_id="epoch-002",
                clock_domain="linux-monotonic:pod1-valid",
                arm=0,
            ),
        )
        # Disjoint union: 18000 + 18100 = 36100s (> 10h)
        acct = ExperimentDurationAccounting(
            planned_windows_count=400,
            window_duration_seconds=120.0,
            planned_active_measurement_seconds=48000.0,
            realized_active_measurement_seconds=36100.0,
            drain_duration_seconds=100.0,
            epoch_rollover_duration_seconds=100.0,
            setup_and_idle_seconds=100.0,
            verified_interval_receipts=receipts,
        )
        passed, reason = acct.validate_actual_10h_milestone()
        self.assertTrue(passed)
        self.assertIn("Qualified", reason)
        self.assertIn("10.03h", reason)

    def test_monte_carlo_permutation_finite_b_is_conservative_not_unbiased(self):
        """Finite-B Monte Carlo permutation inference is explicitly conservative, bounding FWER."""
        # N = 17 blocks (> max_exact_n=16) with all equal positive effects
        diffs = [1.0] * 17
        res = robust_paired_permutation_test(diffs, max_exact_n=16, mc_samples=1000, random_seed=42)
        self.assertFalse(res["exact_rational_arithmetic"])
        self.assertIn("conservative_monte_carlo", res["method"])
        # Even if 0 sampled permutations exceed observed sum, p-value cannot be 0
        # Formula: (1 + extreme) / (1 + B) >= 1 / 1001 ≈ 0.000999
        self.assertGreater(res["p_value"], 0.0)
        self.assertAlmostEqual(res["p_value"], (1.0 + 0.0) / (1.0 + 1000.0), places=5)


class TestRound6StructuralBatchProgressArchitecture(unittest.TestCase):
    """Round 6 tests: Structural batch progress, causal action pathway, and progress vs scalar diagnostic."""

    def test_structural_batch_progress_state_invariants(self):
        """Minimal observable state validates physical bounds and cohort structures."""
        state = StructuralBatchProgressState(
            timestamp_s=10.0,
            applied_cap=16.0,
            active_reserved_cost=12.0,
            prefill_cohort=(
                PrefillRequestState(
                    request_id="pref-1",
                    prompt_tokens=512,
                    computed_tokens=256,
                    original_cost=6.0,
                    admitted_at=9.5,
                    scheduled_at=9.4,
                ),
            ),
            decode_cohort=(
                DecodeRequestState(
                    request_id="dec-1",
                    prompt_tokens=128,
                    output_tokens=15,
                    maximum_output_tokens=32,
                    original_cost=6.0,
                    admitted_at=9.0,
                    scheduled_at=8.9,
                    first_token_at=9.2,
                ),
            ),
            kv_cache_usage=0.25,
        )
        self.assertEqual(state.timestamp_s, 10.0)
        self.assertEqual(state.applied_cap, 16.0)
        self.assertEqual(state.active_reserved_cost, 12.0)
        self.assertEqual(state.prefill_cohort[0].remaining_prompt_tokens, 256)
        self.assertEqual(state.decode_cohort[0].remaining_output_tokens, 17)
        self.assertEqual(state.kv_cache_usage, 0.25)

        # Invariant: Invalid cap raises ValueError
        with self.assertRaises(ValueError):
            StructuralBatchProgressState(
                timestamp_s=10.0,
                applied_cap=24.0,  # Invalid cap
                active_reserved_cost=12.0,
                prefill_cohort=(),
                decode_cohort=(),
            )

    def test_causal_action_pathway_zero_direct_gpu_edge(self):
        """Gateway cap u_t enters ONLY at admission; GPU hardware service rate has ZERO direct cap edge."""
        model = StructuralBatchProgressHybridModel()
        mock_state = StructuralBatchProgressState(
            timestamp_s=10.0,
            applied_cap=16.0,
            active_reserved_cost=16.0,
            prefill_cohort=(
                PrefillRequestState("p1", 512, 0, 8.0, 10.0, 10.0),
            ),
            decode_cohort=(
                DecodeRequestState("d1", 128, 10, 32, 8.0, 9.0, 9.0, 9.2),
            ),
        )
        # Verify across candidate caps {16.0, 32.0}
        invariant_holds = CausalActionPathwayValidator.validate_causal_graph(
            candidate_caps=[16.0, 32.0],
            service_rate_fn=model.compute_gpu_service_rate,
            mock_state=mock_state,
        )
        self.assertTrue(invariant_holds)

    def test_structural_progress_vs_scalar_counterexample(self):
        """State A (decode near EOS) vs State B (prefill 4096) with identical R=16 diverge in goodput."""
        diag = run_structural_progress_vs_scalar_diagnostic()
        self.assertTrue(diag["birth_dominance_confirmed"])
        self.assertGreater(diag["birth_share_5s"], 0.80)
        self.assertTrue(diag["oracle_offers_still_loses_to_history"])

        # Counterexample checks
        cx = diag["counterexample"]
        self.assertTrue(cx["identical_scalar_cost"])
        self.assertEqual(cx["scalar_cost_state_a"], 16.0)
        self.assertEqual(cx["scalar_cost_state_b"], 16.0)
        # State A finishes decode and admits arrivals; State B stays saturated and rejects arrivals
        self.assertGreater(cx["state_a_good_completed"], 0)
        self.assertEqual(cx["state_b_good_completed"], 0)
        self.assertGreater(cx["state_b_rejected"], 0)
        self.assertTrue(cx["goodput_divergence"])

    def test_train1_2_fit_train3_descriptive_diagnostic_receipt(self):
        """Descriptive audit of Train 1/2 vs Train 3 confirms ~81% G5 birth share and R5 performance."""
        json_path = "/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-round5-frozen/mayor-r5-dev-181003.json"
        diag = run_structural_progress_vs_scalar_diagnostic(json_path)
        self.assertAlmostEqual(diag["birth_share_5s"], 0.8109, places=3)
        self.assertTrue(diag["birth_dominance_confirmed"])


class TestRound7AdversarialArchitectureExchange(unittest.TestCase):
    """Round 7 tests: Multi-horizon full-plan response vs causal hybrid kernel discriminator."""

    def test_multi_horizon_plan_invariants(self):
        """MultiHorizonPlan validates exactly 5 binary steps in {16.0, 32.0}."""
        valid_plan = MultiHorizonPlan(budgets=(16.0, 32.0, 16.0, 32.0, 16.0))
        self.assertEqual(len(valid_plan.budgets), 5)
        self.assertEqual(valid_plan.step_duration_s, 1.0)

        # Invalid length
        with self.assertRaises(ValueError):
            MultiHorizonPlan(budgets=(16.0, 32.0, 16.0))

        # Invalid budget value
        with self.assertRaises(ValueError):
            MultiHorizonPlan(budgets=(16.0, 32.0, 24.0, 16.0, 32.0))

        # Non-positive step duration
        with self.assertRaises(ValueError):
            MultiHorizonPlan(budgets=(16.0, 16.0, 16.0, 16.0, 16.0), step_duration_s=-1.0)

    def test_unconstrained_direct_plan_spurious_cap_effect(self):
        """Unconstrained direct IO model predicts a spurious positive treatment effect in uncongested regime."""
        model = UnconstrainedDirectPlanModel(beta_per_step=0.05)
        plan_16 = MultiHorizonPlan((16.0, 16.0, 16.0, 16.0, 16.0))
        plan_32 = MultiHorizonPlan((32.0, 32.0, 32.0, 32.0, 32.0))

        # In uncongested regime, increasing cap from 16 to 32 should have ZERO physical effect
        pred_16 = model.predict_5s_goodput(r_initial=4.0, arrival_rate=2.0, plan=plan_16)
        pred_32 = model.predict_5s_goodput(r_initial=4.0, arrival_rate=2.0, plan=plan_32)
        spurious_tau = pred_32 - pred_16

        # Direct model incorrectly predicts positive effect (5 * 0.05 * 16 = 4.0)
        self.assertGreater(spurious_tau, 0.0)
        self.assertAlmostEqual(spurious_tau, 4.0)

    def test_causal_gated_plan_model_zero_uncongested_treatment_effect(self):
        """Causal admission-gated model maintains strictly ZERO treatment effect when gate is non-binding."""
        model = CausalGatedPlanResponseModel(request_cost=2.0, slo_pass_prob=0.95)
        plan_16 = MultiHorizonPlan((16.0, 16.0, 16.0, 16.0, 16.0))
        plan_32 = MultiHorizonPlan((32.0, 32.0, 32.0, 32.0, 32.0))

        # Uncongested: 2 arrivals per step (cost 4.0), R_init = 4.0 -> easily fits under 16
        uncongested_arrivals = (2.0, 2.0, 2.0, 2.0, 2.0)
        res_16 = model.evaluate_plan_response(4.0, uncongested_arrivals, plan_16)
        res_32 = model.evaluate_plan_response(4.0, uncongested_arrivals, plan_32)

        # Both admit all 10 arrivals; zero rejections; treatment effect tau == 0.0
        self.assertEqual(res_16["total_rejected"], 0.0)
        self.assertEqual(res_32["total_rejected"], 0.0)
        self.assertEqual(res_16["predicted_good"], res_32["predicted_good"])
        tau_uncongested = res_32["predicted_good"] - res_16["predicted_good"]
        self.assertEqual(tau_uncongested, 0.0)

        # Congested: 8 arrivals per step (cost 16.0), R_init = 14.0 -> severely bound under 16
        congested_arrivals = (8.0, 8.0, 8.0, 8.0, 8.0)
        c_res_16 = model.evaluate_plan_response(14.0, congested_arrivals, plan_16)
        c_res_32 = model.evaluate_plan_response(14.0, congested_arrivals, plan_32)
        self.assertGreater(c_res_16["total_rejected"], 0.0)
        self.assertGreater(c_res_32["predicted_good"], c_res_16["predicted_good"])

    def test_itt_vs_ack_compliance_dilution(self):
        """Actuation compliance analyzer computes exact dilution between scheduled plan and actual ACK."""
        comp = ActuationComplianceAnalyzer.compute_itt_compliance_dilution(
            scheduled_step_duration_s=1.0,
            actual_cas_lag_s=0.15,
            true_step_effect=2.0,
        )
        self.assertEqual(comp["compliance_ratio"], 0.85)
        self.assertAlmostEqual(comp["itt_observed_effect"], 1.70)
        self.assertAlmostEqual(comp["dilution_percentage"], 15.0)

    def test_actionable_acceptance_criteria_validation(self):
        """Actionable acceptance criteria correctly enforces all 5 mandatory preregistered checks."""
        # Case 1: All criteria met
        valid = ActionableAcceptanceCriteria.validate_acceptance_criteria(
            uncongested_treatment_effect=0.0,
            future_arrival_law_is_exogenous=True,
            compliance_corrected=True,
            positivity_verified_32_paths=True,
            dev_5s_good_mae=8.20,
            history_mean_5s_mae=8.757,
        )
        self.assertTrue(valid["all_criteria_met"])

        # Case 2: Fails uncongested check (spurious cap effect)
        invalid_c1 = ActionableAcceptanceCriteria.validate_acceptance_criteria(
            uncongested_treatment_effect=2.5,
            future_arrival_law_is_exogenous=True,
            compliance_corrected=True,
            positivity_verified_32_paths=True,
            dev_5s_good_mae=8.20,
        )
        self.assertFalse(invalid_c1["all_criteria_met"])
        self.assertFalse(invalid_c1["criterion_1_zero_uncongested_effect"]["passed"])

        # Case 3: Fails 5s Goodput MAE check (worse than history mean)
        invalid_c5 = ActionableAcceptanceCriteria.validate_acceptance_criteria(
            uncongested_treatment_effect=0.0,
            future_arrival_law_is_exogenous=True,
            compliance_corrected=True,
            positivity_verified_32_paths=True,
            dev_5s_good_mae=9.40,
        )
        self.assertFalse(invalid_c5["all_criteria_met"])
        self.assertFalse(invalid_c5["criterion_5_beats_history_mean_5s"]["passed"])

    def test_direct_plan_vs_causal_hybrid_discriminator_run(self):
        """Full discriminating diagnostic executes and validates physical divergence and compliance dilution."""
        diag = run_direct_plan_vs_causal_hybrid_discriminator()
        self.assertTrue(diag["uncongested_regime"]["causal_zero_effect_verified"])
        self.assertTrue(diag["uncongested_regime"]["direct_model_falsified"])
        self.assertTrue(diag["congested_regime"]["positive_treatment_effect_verified"])
        self.assertGreater(diag["actuation_compliance"]["dilution_percentage"], 0.0)


class TestRound8FairClosedLoopBenchmarkAndPreregisteredProtocol(unittest.TestCase):
    """Round 8 tests: Fair CPU-executable closed-loop benchmark harness & preregistered protocol."""

    def test_future_hidden_controller(self):
        """Controller callback receives strictly pre-cut published history; future tape is invisible."""
        tape = generate_workload_tape("stationary", seed=101, duration_s=10.0)
        harness = ClosedLoopBenchmarkHarness(control_slot_s=1.0, max_drain_duration_s=2.0)

        inspected_cuts = []

        def inspecting_controller(view: PublishedHistoryView) -> ControllerDecision:
            # 1. Assert internal consistency and future-hidden invariant
            view.assert_no_future_leakage()
            inspected_cuts.append(view.cut_time_s)

            # 2. Verify all visible offers have scheduled_at <= view.cut_time_s
            for offer in view.published_offers_history:
                self.assertLessEqual(offer["scheduled_at"], view.cut_time_s + 1e-9)

            # 3. Verify future offers from tape are NOT in the view
            future_tape_ids = {
                req.request_id for req in tape
                if req.scheduled_at > view.cut_time_s
            }
            visible_ids = {
                offer["request_id"] for offer in view.published_offers_history
            }
            self.assertTrue(future_tape_ids.isdisjoint(visible_ids))

            return ControllerDecision(
                decision_time_s=view.cut_time_s,
                requested_budget=16.0,
                candidate_plan=(16.0,) * 5,
                first_action=16.0,
                status="active",
                active_mpc=False,
            )

        result = harness.run_episode(tape, inspecting_controller, episode_duration_s=10.0)
        self.assertGreater(len(inspected_cuts), 5)

        # 4. Injected future leakage triggers immediate failure
        leaked_view = PublishedHistoryView(
            cut_time_s=5.0,
            applied_cap=16.0,
            active_reserved_cost=0.0,
            admitted_active_requests=(),
            completed_requests_history=(),
            rejected_requests_history=(),
            published_offers_history=({"request_id": "future-leak", "scheduled_at": 5.5, "original_cost": 2.0},),
        )
        with self.assertRaises(ValueError):
            leaked_view.assert_no_future_leakage()

    def test_same_tape_across_competing_policies(self):
        """All 5 candidate policies receive the exact same offered tape and initial drain state."""
        tape = generate_workload_tape("mixed", seed=202, duration_s=12.0)
        harness = ClosedLoopBenchmarkHarness(control_slot_s=1.0, max_drain_duration_s=3.0)

        policies = {
            "fixed16": PolicyFixed16(),
            "best_train_fixed32": PolicyBestTrainSelectedFixed(selected_budget=32.0),
            "reactive": PolicyReactive(high_cost_threshold=10.0),
            "one_move": PolicyOneMove(cost_headroom_target=6.0),
            "mpc": PolicyRecedingHorizonMPC(),
        }

        results = {}
        for name, pol in policies.items():
            results[name] = harness.run_episode(tape, pol, episode_duration_s=12.0)

        # Invariant 1: Total offered and request sequence are identical across all runs
        base_records = sorted(results["fixed16"].records, key=lambda x: x["scheduled_at"])
        base_rids = [r["request_id"] for r in base_records]
        base_sched = [r["scheduled_at"] for r in base_records]

        for name, res in results.items():
            self.assertEqual(res.summary["secondary_panels"]["total_offered"], len(base_records))
            res_sorted = sorted(res.records, key=lambda x: x["scheduled_at"])
            res_rids = [r["request_id"] for r in res_sorted]
            res_sched = [r["scheduled_at"] for r in res_sorted]
            self.assertEqual(res_rids, base_rids)
            self.assertEqual(res_sched, base_sched)

        # Invariant 2: Candidate policies produce different budget actions under the same tape
        fixed16_budgets = [d.requested_budget for d in results["fixed16"].controller_logs]
        fixed32_budgets = [d.requested_budget for d in results["best_train_fixed32"].controller_logs]
        self.assertTrue(all(b == 16.0 for b in fixed16_budgets))
        self.assertTrue(all(b == 32.0 for b in fixed32_budgets))

    def test_incomplete_late_and_rejection_accounting(self):
        """Preserves and distinguishes in-window good, late good, pending, rejections, and length caps."""
        # Custom tape with known outcome dynamics
        tape = [
            # 1. In-window good completion (scheduled at 1.0, completes at ~1.2)
            StreamedRequest(
                request_id="req-in-window-good",
                workload_class="stationary",
                scheduled_at=1.0,
                prompt_tokens=128,
                max_tokens=128,
                original_cost=2.0,
                ground_truth_output_tokens=32,
                ground_truth_finish_reason="stop",
                base_service_s=0.1,
            ),
            # 2. Length-capped completion (scheduled at 2.0, finish="length")
            StreamedRequest(
                request_id="req-length-capped",
                workload_class="stationary",
                scheduled_at=2.0,
                prompt_tokens=128,
                max_tokens=128,
                original_cost=2.0,
                ground_truth_output_tokens=32,
                ground_truth_finish_reason="length",
                base_service_s=0.1,
            ),
            # 3. Late good completion (scheduled at 9.8 in a 10s window, completes at ~10.4 during drain)
            StreamedRequest(
                request_id="req-late-good",
                workload_class="stationary",
                scheduled_at=9.8,
                prompt_tokens=128,
                max_tokens=128,
                original_cost=2.0,
                ground_truth_output_tokens=32,
                ground_truth_finish_reason="stop",
                base_service_s=0.1,
            ),
            # 4. Massive cost request to fill reservation ledger to 16.0; output=1 fails output>=2 SLO rule
            StreamedRequest(
                request_id="req-fill-ledger",
                workload_class="stationary",
                scheduled_at=3.0,
                prompt_tokens=128,
                max_tokens=128,
                original_cost=14.0,
                ground_truth_output_tokens=1,  # Fails minimum output tokens >= 2
                ground_truth_finish_reason="stop",
                base_service_s=4.0,  # runs from 3.0 to ~5.0
            ),
            # 5. Overflow request while ledger is 16.0 -> rejected at admission gate
            StreamedRequest(
                request_id="req-rejected-overflow",
                workload_class="stationary",
                scheduled_at=3.2,
                prompt_tokens=128,
                max_tokens=128,
                original_cost=2.0,
                ground_truth_output_tokens=32,
                ground_truth_finish_reason="stop",
                base_service_s=0.1,
            ),
        ]

        harness = ClosedLoopBenchmarkHarness(control_slot_s=1.0, max_drain_duration_s=2.0)
        res = harness.run_episode(tape, PolicyFixed16(), episode_duration_s=10.0)
        summary = res.summary

        # Check primary metric: only req-in-window-good should qualify
        primary = summary["primary_metric"]
        self.assertEqual(primary["in_window_natural_good_count"], 1)
        self.assertEqual(primary["endpoint_classification"], "natural_api_stop")
        self.assertFalse(primary["physical_eos_verified"])

        # Check secondary panels
        secondary = summary["secondary_panels"]
        self.assertEqual(secondary["endpoint_classification"], "natural_api_stop")
        self.assertFalse(secondary["physical_eos_verified"])
        self.assertEqual(secondary["late_good_count"], 1)  # req-late-good
        self.assertEqual(secondary["cohort_good_count"], 2)  # req-in-window-good + req-late-good
        self.assertEqual(secondary["length_capped_count"], 1)  # req-length-capped
        self.assertEqual(secondary["rejected_count"], 1)  # req-rejected-overflow
        self.assertGreater(secondary["rejection_rate"], 0.0)

        # Check controller overhead and offline CPU boundary
        overhead = summary["controller_overhead"]
        self.assertFalse(overhead["active_native_permit"])
        self.assertTrue(res.is_cpu_simulation)
        self.assertFalse(res.active_native_permit)
        self.assertFalse(res.physical_eos_verified)
        self.assertEqual(res.harness_scope, "offline_deterministic_cpu_simulation_not_live_http_gpu")

    def test_genuine_fallback_and_inactive_separation(self):
        """Simulated solver timeout/failure triggers genuine fallback; never disguised as active MPC."""
        tape = generate_workload_tape("stationary", seed=303, duration_s=6.0)
        harness = ClosedLoopBenchmarkHarness(control_slot_s=1.0, max_drain_duration_s=1.0)

        failing_mpc = PolicyRecedingHorizonMPC(simulate_failure=True)
        res = harness.run_episode(tape, failing_mpc, episode_duration_s=6.0)

        logs = res.controller_logs
        self.assertGreater(len(logs), 0)

        # All decisions must be explicitly marked as fallback, active_mpc=False
        for dec in logs:
            self.assertEqual(dec.status, "fallback")
            self.assertEqual(dec.fallback_reason, "simulated_solver_timeout_or_error")
            self.assertFalse(dec.active_mpc)
            self.assertEqual(dec.requested_budget, 16.0)

        overhead = res.summary["controller_overhead"]
        self.assertEqual(overhead["fallback_count"], len(logs))
        self.assertEqual(overhead["active_mpc_decisions"], 0)
        self.assertFalse(overhead["silent_substitution_detected"])

        # Invariant: Attempting to disguise fallback as active_mpc must raise ValueError
        with self.assertRaises(ValueError):
            ControllerDecision(
                decision_time_s=1.0,
                requested_budget=16.0,
                status="fallback",
                active_mpc=True,  # Misleading disguise forbidden
            )

    def test_eight_workload_classes_tape_generation(self):
        """Verify deterministic generation and distinct profiles for all 8 workload classes."""
        for w_class in FINAL_WORKLOAD_CLASSES:
            tape = generate_workload_tape(w_class, seed=404, duration_s=25.0)
            self.assertGreater(len(tape), 0)
            # Determinism check
            tape_repeat = generate_workload_tape(w_class, seed=404, duration_s=25.0)
            self.assertEqual([r.request_id for r in tape], [r.request_id for r in tape_repeat])
            self.assertEqual([r.scheduled_at for r in tape], [r.scheduled_at for r in tape_repeat])

            # Class-specific invariants
            if w_class == "prefill":
                self.assertTrue(all(r.prompt_tokens == 4096 for r in tape))
            elif w_class == "decode":
                self.assertTrue(all(r.ground_truth_output_tokens == 256 for r in tape))
            elif w_class == "unseen":
                self.assertTrue(all(r.prompt_tokens == 2048 for r in tape))
                self.assertTrue(any(r.ground_truth_finish_reason == "length" for r in tape))

        # Check alias resolution
        tape_alias = generate_workload_tape("short_homogeneous", seed=505, duration_s=10.0)
        self.assertEqual(tape_alias[0].workload_class, "stationary")

    def test_preregistered_final_protocol_invariants(self):
        """Verify preregistered Final protocol specification rules, metrics, and lift thresholds."""
        protocol = build_preregistered_final_protocol()

        self.assertIn("protocol_digest", protocol)
        self.assertEqual(len(protocol["protocol_digest"]), 64)
        self.assertEqual(len(protocol["workload_classes"]), 8)
        self.assertEqual(set(protocol["workload_classes"]), set(FINAL_WORKLOAD_CLASSES))

        # Draft status and Mayor sealing invariant
        self.assertEqual(protocol["status"], "draft_unsealed_proposal")
        self.assertFalse(protocol["mayor_sealed_before_final"])

        # Primary metric invariants
        prim = protocol["primary_metric"]
        self.assertEqual(prim["name"], "api_stop_natural_in_window_goodput_per_second")
        self.assertEqual(prim["endpoint_classification"], "natural_api_stop")
        self.assertFalse(prim["physical_eos_verified"])
        self.assertEqual(prim["ttft_threshold_s"], 0.5)
        self.assertEqual(prim["mean_tpot_threshold_s"], 0.05)
        self.assertEqual(prim["minimum_output_tokens"], 2)
        self.assertTrue(prim["natural_eos_only"])
        self.assertTrue(prim["in_window_only"])
        self.assertEqual(prim["per_token_tpot_note"], "per-token TPOT is unavailable on native vLLM; per-request mean TPOT is used")

        # Proposed minimum lift invariant
        rules = protocol["decision_rules"]
        self.assertEqual(rules["proposed_minimum_meaningful_lift_pct"], 5.0)
        self.assertEqual(rules["multiplicity_correction"], "holm_bonferroni_step_down")
        self.assertEqual(rules["block_unit"], "independent arrival/action seedblock")

        # Zero Final leakage invariant
        boundaries = protocol["preregistration_boundaries"]
        self.assertFalse(boundaries["final_data_accessed"])
        self.assertFalse(boundaries["proved_risk_guarantees_asserted"])
        self.assertTrue(boundaries["protocol_frozen_before_final"])
        self.assertEqual(boundaries["protocol_status"], "draft_unsealed_proposal")
        self.assertFalse(boundaries["mayor_sealed_before_final"])


class TestRound9RealPipelineQualification(unittest.TestCase):
    """Round 9 test suite verifying genuine CPU end-to-end control and capture pipeline qualification."""

    @classmethod
    def setUpClass(cls):
        ensure_integration_paths()

    def test_source_or_clock_changed_before_time_comparisons(self):
        """Native state adapter rejects clock domain and run ID changes before evaluating timestamps."""
        from mpc_lab.native_state import estimate_native_state, NativeBinding
        import httpx

        transport = RealPipelineServingTransport()
        client = httpx.Client(transport=httpx.MockTransport(transport), base_url="http://test")
        binding = NativeBinding(
            clock_domain=transport.clock_domain,
            gateway_run_id=transport.gateway_run_id,
            native_run_id=transport.native_run_id,
            observer_sha256=transport.observer_sha256,
            identity=transport.parameters.identity,
        )

        # 1. Normal state passes estimation
        resp = client.get("/native/state").json()
        est_normal = estimate_native_state(resp, binding, now=transport.clock())
        self.assertIsNotNone(est_normal.state)
        self.assertIsNone(est_normal.reason)

        # 2. Clock domain changed before time comparisons
        transport.simulate_clock_mismatch = True
        resp_clock = client.get("/native/state").json()
        est_clock = estimate_native_state(resp_clock, binding, now=transport.clock())
        self.assertIsNone(est_clock.state)
        self.assertEqual(est_clock.reason, "clock_domain_mismatch")

        # 3. Native run ID changed before time comparisons
        transport.simulate_clock_mismatch = False
        transport.simulate_source_mismatch = True
        resp_source = client.get("/native/state").json()
        est_source = estimate_native_state(resp_source, binding, now=transport.clock())
        self.assertIsNone(est_source.state)
        self.assertEqual(est_source.reason, "native_source_mismatch")

        # 4. Harness execution under clock/source mismatch triggers clean fallback without disguising as MPC
        res_mismatch = run_real_pipeline_episode("mpc", transport_override=transport, episode_duration_s=2.0)
        self.assertGreater(len(res_mismatch.controller_logs), 0)
        for dec in res_mismatch.controller_logs:
            self.assertEqual(dec.status, "fallback")
            self.assertFalse(dec.active_mpc)
            self.assertIn("native_source_mismatch", dec.fallback_reason)

    def test_one_pending_operation_blocks_next(self):
        """GuardedActuator pending file fence strictly blocks subsequent commands from overlapping."""
        import tempfile
        from mpc_lab.contracts import SCHEMA, asdict

        with tempfile.TemporaryDirectory() as td:
            pending_dir = Path(td)
            pending_file = pending_dir / "pending.json"
            transport = RealPipelineServingTransport()

            # Pre-populate pending.json with an uncompleted operation
            pending_cmd = {
                "schema": SCHEMA,
                "run_id": transport.gateway_run_id,
                "clock_domain": transport.clock_domain,
                "identity": asdict(transport.parameters.identity),
                "expected_version": 0,
                "operation_id": "op-pending-blocker-1234",
                "budget": 16.0,
                "not_after": transport.clock() + 100.0,
            }
            pending_file.write_text(json.dumps(pending_cmd))

            # Run episode through harness with the pending blocker
            res = run_real_pipeline_episode(
                "mpc",
                transport_override=transport,
                pending_dir=pending_dir,
                episode_duration_s=2.0,
            )
            self.assertGreater(len(res.controller_logs), 0)
            for dec in res.controller_logs:
                self.assertEqual(dec.status, "fallback")
                self.assertFalse(dec.active_mpc)
                self.assertIn("actuator_pending", dec.fallback_reason)

    def test_ttl_expired_recorded_fallback(self):
        """Actuator command TTL expiry returns 409 / stale snapshot and records fallback without silent disguise."""
        transport = RealPipelineServingTransport()
        transport.simulate_ttl_expired = True

        res = run_real_pipeline_episode("mpc", transport_override=transport, episode_duration_s=2.0)
        logs = res.controller_logs
        self.assertGreater(len(logs), 0)
        for dec in logs:
            self.assertEqual(dec.status, "fallback")
            self.assertFalse(dec.active_mpc)
            self.assertIn("actuator_pending", dec.fallback_reason)

        overhead = res.summary["controller_overhead"]
        self.assertEqual(overhead["fallback_count"], len(logs))
        self.assertEqual(overhead["active_mpc_decisions"], 0)
        self.assertFalse(overhead["silent_substitution_detected"])

    def test_partial_sse_rejected_unsent_cancel_and_late_kept(self):
        """Whole offered fate accounting retains fragmented SSE, admission rejections, errors, and late arrivals."""
        import hashlib
        import asyncio

        def mkhex(name: str) -> str:
            return hashlib.sha256(name.encode()).hexdigest()[:32]

        r_normal = mkhex("req-normal")
        r_length = mkhex("req-length")
        r_partial = mkhex("req-partial")
        r_reject = mkhex("req-reject")
        r_error = mkhex("req-error")
        r_late = mkhex("req-late")

        tape = [
            StreamedRequest(r_normal, "stationary", 0.5, 128, 128, 2.0, 32, "stop", 0.1),
            StreamedRequest(r_length, "stationary", 0.6, 128, 128, 2.0, 32, "length", 0.1),
            StreamedRequest(r_partial, "stationary", 0.7, 128, 128, 2.0, 32, "stop", 0.1),
            StreamedRequest(r_reject, "stationary", 0.8, 128, 128, 2.0, 32, "stop", 0.1),
            StreamedRequest(r_error, "stationary", 0.9, 128, 128, 2.0, 32, "stop", 0.1),
            StreamedRequest(r_late, "stationary", 1.9, 128, 128, 2.0, 32, "stop", 0.1),
        ]

        transport = RealPipelineServingTransport()
        transport.mode_overrides[r_partial] = "partial"
        transport.mode_overrides[r_reject] = "reject"
        transport.mode_overrides[r_error] = "error"

        harness = RealPipelineControlHarness()
        res_custom = asyncio.run(
            harness.run_episode(
                PolicyFixed16(),
                tape,
                episode_duration_s=2.0,
                transport_override=transport,
            )
        )
        fates = res_custom.whole_offered_fates
        self.assertEqual(fates["total_offered"], 6)
        self.assertEqual(fates["completed_natural_api_stop"], 2)  # r_normal + r_late
        self.assertEqual(fates["completed_length"], 1)  # r_length
        self.assertEqual(fates["rejected_admission"], 1)  # r_reject
        self.assertEqual(fates["failed_partial_or_error"], 2)  # r_partial + r_error
        self.assertGreaterEqual(fates["late_good"], 1)

    def test_all_five_policies_share_real_pipeline_transport(self):
        """All five matched policies execute over the genuine mock transport and produce sound accounting."""
        policies = ["fixed_16", "best_train_fixed_16_or_32", "reactive", "strong_one_move", "mpc"]
        for p in policies:
            res = run_real_pipeline_episode(p, episode_duration_s=2.0)
            self.assertEqual(res.policy_name, p)
            self.assertEqual(res.harness_scope, "offline_deterministic_cpu_simulation_not_live_http_gpu")
            self.assertFalse(res.active_native_permit)
            self.assertFalse(res.physical_eos_verified)
            self.assertGreater(len(res.records), 0)
            self.assertGreater(len(res.controller_logs), 0)
            self.assertIn("api_stop_natural_in_window_goodput_per_second", res.summary["primary_metric"]["name"])


class TestRound10PortabilityAndSolR9Qualification(unittest.TestCase):
    """Round 10 tests: ABI portability, Sol R9 metadata/cut adapter, missing-lineage refusal, and simulate_plan witness."""

    def test_abi_portability_sanitizes_foreign_site_packages(self):
        """Sanitizer rejects foreign ABI site-packages and preserves current ABI."""
        curr_ver = f"{sys.version_info.major}.{sys.version_info.minor}"
        foreign_ver = "3.12" if curr_ver != "3.12" else "3.14"

        foreign_path = f"/custom/venv/lib/python{foreign_ver}/site-packages"
        native_path = f"/custom/venv/lib/python{curr_ver}/site-packages"

        self.assertTrue(is_foreign_abi_site_packages(foreign_path))
        self.assertFalse(is_foreign_abi_site_packages(native_path))

        # Test that ensure_integration_paths purges foreign path if injected into sys.path
        sys.path.append(foreign_path)
        self.assertIn(foreign_path, sys.path)
        ensure_integration_paths()
        self.assertNotIn(foreign_path, sys.path)

    def test_sol_r9_metadata_and_registration_v2(self):
        """Sol R9 prospective registration accepts valid public_metadata and rejects mismatches."""
        from native_experiment_audit import CaptureReceiptBridge

        clock = time.monotonic
        bridge = CaptureReceiptBridge(
            publisher_run_id="a" * 32,
            observer_run_id="b" * 32,
            clock_domain="test-domain",
            publisher_clock=clock,
            observer_clock=clock,
        )

        valid_meta = {
            "schema": "native-v3-public-payload-v1",
            "requested_max_tokens": 64,
            "prompt_class": "short",
            "prompt_token_estimate": 128,
            "source_sha256": "c" * 64,
            "prompt_estimator_sha256": "d" * 64,
        }
        rid = "0" * 31 + "1"
        bridge.register(
            rid,
            0.0,
            original_offered_estimate=1.0,
            estimate_provenance={"source_sha256": "e" * 64},
            public_metadata=valid_meta,
        )

        # Confirm published with REGISTRATION_V2
        cut = bridge.cut(clock())
        req = next(r for r in cut["requests"] if r["request_id"] == rid)
        self.assertEqual(req["registration_schema"], "native-v3-offered-registration-v2")
        self.assertEqual(req["public_metadata"]["requested_max_tokens"], 64)

        # Invalid metadata (missing field or wrong schema) must raise ValueError
        invalid_meta = dict(valid_meta, schema="invalid-schema")
        with self.assertRaises(ValueError):
            bridge.register(
                "0" * 31 + "2",
                0.1,
                original_offered_estimate=1.0,
                estimate_provenance={"source_sha256": "e" * 64},
                public_metadata=invalid_meta,
            )

    def test_sol_r9_cut_adapter_refuses_v5_input_missing_lineage(self):
        """OnlineModelInputAdapter seals cut with v5_input=None, all 5 refusal reasons, and active_mpc_permit=False."""
        from mpc_lab.native_state import NativeBinding
        from mpc_lab.contracts import ModelParameters
        from native_experiment_audit import CaptureReceiptBridge, OnlineModelInputAdapter

        clock = time.monotonic
        bridge = CaptureReceiptBridge(
            publisher_run_id="a" * 32,
            observer_run_id="b" * 32,
            clock_domain="test-domain",
            publisher_clock=clock,
            observer_clock=clock,
        )
        binding = NativeBinding(
            clock_domain="test-domain",
            gateway_run_id="g" * 32,
            native_run_id="n" * 32,
            observer_sha256="c" * 64,
            identity=ModelParameters().identity,
        )
        adapter = OnlineModelInputAdapter(bridge, binding, clock=clock)
        cut = adapter.cut(clock())

        self.assertEqual(cut["schema"], "native-v3-online-model-input-v1")
        self.assertIsNone(cut["v5_input"])
        self.assertFalse(cut["active_mpc_permit"])
        self.assertEqual(cut["request_lineage"], "unverified_no_namespace_joins")

        expected_refusals = [
            "verified_engine_gateway_client_lineage_missing",
            "pending_original_gateway_charge_unknown",
            "all_offered_completeness_and_v5_arrival_law_unqualified",
            "cell_payload_cost_table_and_prompt_estimator_transfer_unqualified",
            "planned_assignment_ACK_compliance_and_plan_support_unqualified",
        ]
        self.assertEqual(cut["v5_refusals"], expected_refusals)

    def test_mpc_policy_explicitly_falls_back_when_v5_input_refused(self):
        """When v5_input is refused, MPC policy records fallback without masquerading as active MPC."""
        res = run_real_pipeline_episode("mpc", episode_duration_s=2.0)
        self.assertEqual(res.policy_name, "mpc")
        self.assertFalse(res.active_native_permit)
        self.assertIsNone(res.v5_input)
        self.assertIn("verified_engine_gateway_client_lineage_missing", res.v5_refusals)

        # Every MPC decision must be recorded as fallback with explicit refusal reason
        for decision in res.controller_logs:
            self.assertEqual(decision.status, "fallback")
            self.assertFalse(decision.active_mpc)
            self.assertTrue(decision.fallback_reason.startswith("v5_input_refused:"))

    def test_simulate_plan_fixed_crn_causal_non_interference_witness(self):
        """Executable witness proves cohort and earlier-birth service non-interference in frozen simulate_plan."""
        witness = run_simulate_plan_causal_interference_witness()
        self.assertEqual(witness.schema, "native-v3-simulate-plan-witness-v1")
        self.assertTrue(witness.cohort_invariance)
        self.assertTrue(witness.earlier_birth_invariance)
        self.assertEqual(witness.live_cohort_delay_s, 0.0)
        self.assertEqual(witness.earlier_birth_delay_s, 0.0)
        self.assertIn("marked renewal", witness.interpretation)
        self.assertIn("Minimal observable batch-aware", witness.gap_specification)


if __name__ == "__main__":
    unittest.main()


