"""Independent report-only audit of the sealed baseline04 matrix."""
import ast
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import subprocess
import tarfile

BASE = Path("/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-baseline-four-seed04-replica")
PARENT = Path("/home/daniel_lin/gt/pr32/mayor/mpc-native-integration")
EVIDENCE = PARENT / "results/mpc-native-v3/review-evidence"
OUTPUT = Path(__file__).with_name("sol-r19-baseline04-canonical.json")
failures, checks = [], Counter()


def check(kind, condition, context=None):
    checks[kind] += 1
    if not condition:
        failures.append(dict(kind=kind, context=context))


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def quantiles(values):
    values = sorted(values)
    if not values:
        return None
    return dict(n=len(values), minimum=values[0], median=statistics.median(values),
                p95=values[min(len(values)-1, math.ceil(.95*len(values))-1)],
                maximum=values[-1])


def main():
    receipt_raw = (EVIDENCE / "nv3-026-complete-native-baseline04-receipt.json").read_bytes()
    check("receipt_sha", digest(receipt_raw) == "00fb93ff8e5d8afd3eb06e23b2e4e1b77ffb7917e31a52e11072ca9159155694")
    receipt = json.loads(receipt_raw)
    index_raw = (BASE / "latest-index.json").read_bytes()
    index = json.loads(index_raw)
    check("index_sha", digest(index_raw) == receipt["index_sha256"])
    with tarfile.open(EVIDENCE / "nv3-024-qualified-baseline04-before-full-exposure-source-evidence.tar.gz") as archive:
        protocol_raw = archive.extractfile("pr33-native-v3-four-seed-baseline04-protocol.json").read()
        factory = archive.extractfile("collector-c4ace2e/count_baseline.py").read()
        classifier = archive.extractfile("collector-c4ace2e/baseline_http_capture.py").read()
    protocol = json.loads(protocol_raw)
    for key, raw in (("protocol_sha256", protocol_raw), ("collector_sha256", factory),
                     ("classifier_sha256", classifier)):
        check("source_sha", digest(raw) == receipt[key], key)
    legacy_raw = (PARENT / "experiments/mpc-research/native-v3/collect_identification.py").read_bytes()
    check("legacy_sha", digest(legacy_raw) == protocol["legacy_collector_sha256"])
    for path, key in (("gateway.py", "serving_gateway_sha256"),
                      ("mpc_lab/http_capture.py", "http_capture_sha256"),
                      ("mpc_lab/runtime.py", "runtime_sha256"),
                      ("experiments/mpc-research/native_observer/pr33_native_observer.py", "observer_sha256")):
        check("serving_source_sha", digest((PARENT / path).read_bytes()) == protocol[key], path)
    cells = {"p128-m128": (128, 128, 43.), "p128-m256": (128, 256, 14.),
             "p4096-m128": (4096, 128, 10.), "p4096-m256": (4096, 256, 3.75),
             "mixed": (None, None, 6.)}
    policies = {"fixed-count16": ("protected", 16, 32), "fixed-count32": ("protected", 32, 32),
                "fixed-cost16": ("cost_aware", 32, 16), "fixed-cost32": ("cost_aware", 32, 32)}
    expected = []
    for block, seed in enumerate(range(181045, 181049)):
        for cell in cells:
            order = list(policies)
            random.Random(f"baseline-order:181045:{cell}").shuffle(order)
            if block % 2:
                order.reverse()
            expected.extend(f"nv3-baseline-{seed}-{cell}-{p}" for p in order)
    check("factory_order", [e["episode_id"] for e in protocol["episodes"]] == expected)
    check("index_order", [e["episode_id"] for e in index["episodes"]] == expected)
    check("complete_matrix", len(set(expected)) == 80 and index["completed"] is True
          and index["actual_offered_window_s"] == 9600 and len(index["gateway_epochs"]) == 80)
    manifest = {r["artifact"]: r["sha256"] for r in receipt["artifact_manifest"]}
    check("manifest_unique", len(manifest) == len(receipt["artifact_manifest"]) == 400)
    actual_manifest = []
    for name, sha in manifest.items():
        raw = (BASE / name).read_bytes()
        actual = digest(raw)
        check("artifact_sha", sha == actual, name)
        actual_manifest.append(dict(artifact=name, sha256=actual, bytes=len(raw)))
    rehash_rows = [json.loads(l) for l in (BASE / "verified-artifact-sha256.jsonl").read_text().splitlines()]
    check("rehash_manifest", {r["artifact"]: r["sha256"] for r in rehash_rows} == manifest
          and len(rehash_rows) == 400)
    archived = set()
    archive_receipts = []
    completion_manifest = {
        "completion/latest-index.json": digest(index_raw),
        "completion/distinct-acquisition-ledger.json": digest((BASE / "distinct-acquisition-ledger.json").read_bytes()),
        "completion/owned-service-shutdown.json": digest((BASE / "owned-service-shutdown.json").read_bytes()),
        "completion/verified-artifact-sha256.jsonl": digest((BASE / "verified-artifact-sha256.jsonl").read_bytes()),
        "completion/pr33-native-v3-four-seed-baseline04-protocol.json": digest(protocol_raw),
    }
    for item in receipt["archives"]:
        path = EVIDENCE / item["archive"]
        check("archive_sha", digest(path.read_bytes()) == item["sha256"], path.name)
        check("archive_bytes", path.stat().st_size == item["bytes"], path.name)
        members, completion_members = [], []
        with tarfile.open(path) as archive:
            for member in archive.getmembers():
                if not member.isfile():
                    continue
                raw = archive.extractfile(member).read()
                if member.name in completion_manifest:
                    check("archive_completion_sha", digest(raw) == completion_manifest[member.name], member.name)
                    completion_members.append(member.name)
                    continue
                check("archive_member_sha", member.name in manifest
                      and digest(raw) == manifest.get(member.name), member.name)
                check("archive_member_unique", member.name not in archived, member.name)
                archived.add(member.name)
                members.append(member.name)
        check("archive_member_count", len(members) == item["artifact_count"] == 100, path.name)
        check("archive_completion_inventory", set(completion_members) == set(completion_manifest)
              and len(completion_members) == 5, path.name)
        archive_receipts.append(dict(archive=path.name, sha256=item["sha256"], episode_artifacts=len(members),
                                     completion_metadata=len(completion_members)))
    check("archive_inventory", archived == set(manifest))
    ns = {"math": math, "random": random, "CELLS": cells}
    tape_node = next(n for n in ast.parse(legacy_raw).body
                     if isinstance(n, ast.FunctionDef) and n.name == "tape_for")
    exec(compile(ast.Module(body=[tape_node], type_ignores=[]), "sealed-legacy:tape_for", "exec"), ns)
    episode_results, seen_ids, observed_runs, engine_runs, windows = [], set(), set(), set(), []
    tape_groups, max_groups = {}, {}
    for number, (spec, epoch) in enumerate(zip(protocol["episodes"], index["gateway_epochs"]), 1):
        eid = spec["episode_id"]
        episode = json.loads((BASE / (eid + ".json")).read_bytes())
        check("episode_spec", all(episode[k] == v for k, v in spec.items()), eid)
        check("train_only", episode["split"] == "train", eid)
        check("epoch_policy", epoch["policy"] == spec["policy"], eid)
        mode, count, budget = policies[spec["policy"]]
        rows = episode["rows"]
        row_map = {r["request_id"]: r for r in rows}
        ids = episode["expected_ids"]
        check("assigned_inventory", len(ids) == len(set(ids)) == len(rows) == len(row_map)
              and set(ids) == set(row_map), eid)
        check("global_uuid_uniqueness", not seen_ids.intersection(ids)
              and all(len(rid) == 32 and all(c in "0123456789abcdef" for c in rid) for rid in ids), eid)
        seen_ids.update(ids)
        observed_runs.add(episode["gateway_run_id"])
        tape = ns["tape_for"](spec["seed_block"], spec["cell"], 120)
        check("factory_tape", tape == episode["offered_tape"] and len(tape) == len(ids), eid)
        group = spec["seed_block"], spec["cell"]
        maxima = [row_map[rid]["requested_max_tokens"] for rid in ids]
        if group in tape_groups:
            check("paired_offers", tape_groups[group] == tape and max_groups[group] == maxima, eid)
        tape_groups[group], max_groups[group] = tape, maxima
        rng = random.Random(f"payloads:{spec['seed_block']}:{spec['cell']}")
        offered_prompts = {}
        for rid, offset in zip(ids, tape):
            selected = rng.choice(("p128-m256", "p4096-m128")) if spec["cell"] == "mixed" else spec["cell"]
            prompt, maximum, _ = cells[selected]
            rng.choice((28, 32, 36) if maximum == 128 else (65, 80, 95))
            rng.choice(("the solar system", "ocean currents", "photosynthesis", "volcanoes"))
            offered_prompts[rid] = prompt
            r = row_map[rid]
            check("scheduled_payload", r["requested_max_tokens"] == maximum
                  and r["requested_ignore_eos"] is False
                  and r["request_model"] == "Qwen/Qwen3-4B-Instruct-2507"
                  and r["scheduled_at"] == episode["start"] + offset, dict(episode=eid, rid=rid))
        start, end = episode["start"], episode["start"] + 120
        windows.append([start, end])
        states = episode["samples"]
        publication = Counter()
        event_rows, event_states, event_drains = [], [], []
        for line in (BASE / (eid + ".events.jsonl")).read_text().splitlines():
            ev = json.loads(line)
            publication[ev["kind"]] += 1
            if ev["kind"] == "http_outcome":
                event_rows.append(ev["value"])
            elif ev["kind"] == "state":
                event_states.append(ev["value"])
            elif ev["kind"] == "final_drain_probe":
                event_drains.append(ev["value"])
        check("event_publication", event_rows == rows and event_states == states
              and event_drains == episode["final_drain_probes"], eid)
        samples_in_window = [s for s in states if start <= s["native"]["sampled_at"] <= end]
        native_visible, window_visible = set(), set()
        foreign_native, invalid_native = [], []
        ages, sample_gaps = [], []
        complete_count = pending_count = 0
        for s in states + episode["initial_drain_probes"] + episode["final_drain_probes"]:
            n, m, receive = s["native"], s["metrics"], s["received_at"]
            check("native_source_clock", n["clock_domain"] == index["clock_domain"]
                  and n["observer_sha256"] == protocol["observer_sha256"]
                  and 0 <= receive - n["sampled_at"] <= .5
                  and 0 <= n["frontend_sampled_at"] - n["sampled_at"] <= .05, eid)
            check("metrics_policy", m["admission_mode"] == mode and m["max_in_flight"] == count
                  and m["max_waiting_capacity"] == 2 and m["admission_budget"] == budget
                  and m["initial_admission_budget"] == budget and m["budget_version"] == 0
                  and m["telemetry_run_id"] == episode["gateway_run_id"]
                  and m["tokenizer_available"] is True and m["telemetry_dropped_records"] == 0
                  and m["telemetry_write_errors"] == 0, eid)
            for key, field in (("cost_intercept", "intercept"), ("input_token_cost", "input_per_token"),
                               ("output_token_cost", "output_per_token")):
                check("metrics_cost_spec", m[key] == protocol["cost_spec"][field], eid)
        for s in states:
            n = s["native"]
            engine_runs.add(n["run_id"])
            m = s["metrics"]
            check("protected_outstanding_capacity", mode != "protected"
                  or m["current_in_flight"] + m["current_waiting"] <= count + 2, eid)
            check("offered_observer_symmetry", s["cost_snapshot"] is None and s["cost_drain"] is None, eid)
            ages.append(s["received_at"] - n["sampled_at"])
            complete_count += n["complete"] is True
            pending_count += n.get("pending_batches", 0) != 0
            mark_ids = [mark["request_id"] for mark in n["requests"]]
            check("native_snapshot_unique", len(mark_ids) == len(set(mark_ids)), eid)
            for mark in n["requests"]:
                rid = mark.get("gateway_request_id")
                check("native_reported_counter_validity",
                      all(type(mark.get(k)) is int and mark[k] >= 0
                          for k in ("prompt_tokens", "computed_tokens", "output_tokens", "maximum_output_tokens"))
                      and mark["output_tokens"] <= mark["maximum_output_tokens"], eid)
                native_visible.add(rid)
                if start <= n["sampled_at"] <= end:
                    window_visible.add(rid)
                if rid not in row_map or row_map[rid]["status"] != "complete":
                    foreign_native.append(rid)
                elif (mark["prompt_tokens"] != offered_prompts[rid]
                      or mark["maximum_output_tokens"] != row_map[rid]["requested_max_tokens"]
                      or mark["ignore_eos"] is not False):
                    invalid_native.append(rid)
        check("native_tag_join", not foreign_native and not invalid_native, eid)
        for before, after in zip(states, states[1:]):
            gap = after["native"]["sampled_at"] - before["native"]["sampled_at"]
            sample_gaps.append(gap)
            check("sample_order", gap >= 0, eid)
        drain_facts = {}
        for which in ("initial", "final"):
            probes, selected = episode[which + "_drain_probes"], episode[which + "_drain"]
            check("drain_probe_retention", len(selected) == 2 and probes[-2:] == selected, dict(episode=eid, which=which))
            for s in selected:
                n, m = s["native"], s["metrics"]
                check("empty_drain", n["complete"] is True and not n["requests"]
                      and all(n.get(k, 0) == 0 for k in ("running", "waiting", "pending_batches", "orphaned", "frontend_unfinished"))
                      and m["current_in_flight"] == m["current_waiting"] == 0
                      and (mode == "cost_aware" or m["current_admitted_cost"] == 0),
                      dict(episode=eid, which=which))
                check("drain_clock", s["received_at"] < start if which == "initial"
                      else s["received_at"] >= max(r["terminal_at"] for r in rows), dict(episode=eid, which=which))
                if mode == "cost_aware":
                    snap = s["cost_snapshot"]
                    check("cost_drain_proof", s["cost_drain"] == dict(drained=True, reason="clear")
                          and snap["complete"] is True and snap["requests"] == []
                          and snap["run_id"] == episode["gateway_run_id"]
                          and snap["clock_domain"] == index["clock_domain"]
                          and snap["identity"]["implementation_hash"] == receipt["implementation_hash"]
                          and snap["identity"]["cost_hash"] == "cf8162ea687a697d698f26d0bd663fdb9a2f172dce71add05d267ac3dfb43833"
                          and snap["identity"]["support_hash"] == "7e6d49ca4a15ab8630fed9a7fa150eb3ab8f2e1a7b0d9585cc8a6c48f666498d"
                          and snap["identity"]["model_version"] == "native-id-unfitted-v1"
                          and snap["identity"]["calibration_version"] == "unfitted-not-validated"
                          and snap["budget"] == budget and snap["budget_version"] == 0
                          and 0 <= s["received_at"] - snap["sampled_at"] <= .5, eid)
            drain_facts[which] = dict(probes=len(probes), failed_probes=len(probes)-2,
                raw_scalar_reserved_costs=[s["metrics"]["current_admitted_cost"] for s in selected],
                cost_snapshot_request_counts=[len(s["cost_snapshot"]["requests"])
                                              for s in selected if s["cost_snapshot"] is not None])
        telemetry = BASE / epoch["evidence"] / "gateway-telemetry.jsonl"
        status = json.loads((telemetry.parent / "gateway-telemetry-status.json").read_bytes())
        check("epoch_closed_lossfree", status["status"] == "closed" and status["dropped"] == status["write_errors"] == 0
              and status["run_id"] == episode["gateway_run_id"]
              and status == episode["gateway_telemetry_receipt"]["closed_status"], eid)
        events_by_id, accepted = defaultdict(Counter), {}
        ledger_seq, ledger_final, ledger_incomplete = [], None, 0
        last_snapshot = None
        with telemetry.open() as stream:
            for line in stream:
                event = json.loads(line)
                check("telemetry_run", event["run_id"] == episode["gateway_run_id"], eid)
                rid = event.get("request_id")
                if rid is not None:
                    events_by_id[rid][event["event"]] += 1
                if event["event"] == "accepted":
                    accepted[rid] = event
                elif event["event"] == "mpc_ledger":
                    ledger_seq.append(event["sequence"])
                    ledger_final = event
                    ledger_incomplete += event["complete"] is not True
                elif event["event"] == "snapshot":
                    last_snapshot = event
        check("gateway_assigned_set", set(events_by_id) == set(ids), eid)
        counts = Counter(r["status"] for r in rows)
        for rid in ids:
            c, row = events_by_id[rid], row_map[rid]
            complete = row["status"] == "complete"
            check("gateway_fate_parity", c["received"] == 1 and c["accepted"] == int(complete)
                  and c["completed"] == int(complete) and c["rejected"] == int(not complete)
                  and not c["failed"] and not c["cancelled"], dict(episode=eid, rid=rid))
            if complete and mode == "cost_aware":
                a = accepted[rid]
                cost = max(.1, .259 + .000758*offered_prompts[rid] + .0052083333*row["requested_max_tokens"])
                check("actual_original_charge", math.isclose(a["request_cost"], cost, abs_tol=1e-9)
                      and a["estimated_input_tokens"] == offered_prompts[rid]
                      and a["max_output_tokens"] == row["requested_max_tokens"]
                      and a["budget"] == budget and a["budget_version"] == 0, dict(episode=eid, rid=rid))
        check("scalar_ledger_sequence", ledger_seq == list(range(1, len(ledger_seq)+1)), eid)
        if ledger_final:
            check("scalar_final_stock", ledger_final["reserved_cost"] == 0 and ledger_final["running"] == 0, eid)
        check("telemetry_bytes", digest(telemetry.read_bytes()) == episode["gateway_telemetry_receipt"]["sha256"]
              and telemetry.stat().st_size == episode["gateway_telemetry_receipt"]["bytes"], eid)
        totals = Counter()
        send_lags, ttfts, tpots, latencies = [], [], [], []
        for r in rows:
            ctx = dict(episode=eid, rid=r["request_id"])
            check("row_source", r["clock_domain"] == index["clock_domain"]
                  and r["source_capture_sha256"] == protocol["http_capture_sha256"]
                  and r["baseline_classifier_sha256"] == protocol["classifier_sha256"]
                  and r["admission_policy_mode"] == mode
                  and r["response_request_id"] == r["request_id"], ctx)
            check("row_chronology", start <= r["scheduled_at"] < end
                  and r["scheduled_at"] <= r["sent_at"] <= r["terminal_at"], ctx)
            send_lags.append(r["sent_at"] - r["scheduled_at"])
            latency = r["terminal_at"] - r["sent_at"]
            latencies.append(latency)
            check("request_deadline", latency <= 30, ctx)
            totals["offered"] += 1
            if r["status"] == "rejected":
                totals["rejected"] += 1
                body = r["source_503_body_utf8"].encode()
                check("rejection_body_sha", digest(body) == r["source_503_body_sha256"]
                      and r["http_status"] == 503 and r["admission_rejection"] is True, ctx)
                continue
            if r["status"] != "complete":
                totals["other"] += 1
                continue
            tokens = r["usage"]["completion_tokens"]
            check("complete_label", r["http_status"] == 200 and r["stream_done"] is True
                  and r["stream_error"] is False and type(tokens) is int and tokens > 0
                  and r["sent_at"] <= r["first_content_at"] <= r["last_content_at"] <= r["terminal_at"], ctx)
            totals["complete"] += 1
            totals["natural_eos"] += r["finish_reason"] == "stop"
            totals["capped"] += r["finish_reason"] == "length"
            ttft = r["first_content_at"] - r["scheduled_at"]
            tpot = (r["terminal_at"] - r["first_content_at"])/(tokens-1) if tokens > 1 else None
            ttfts.append(ttft)
            if tpot is not None:
                tpots.append(tpot)
            good = r["finish_reason"] == "stop" and tokens > 1 and 0 <= ttft <= .5 and 0 <= tpot <= .05 and latency <= 30
            totals["cohort_good"] += good
            totals["window_good"] += good and r["terminal_at"] <= end
            totals["cohort_good_tokens"] += tokens if good else 0
            totals["window_good_tokens"] += tokens if good and r["terminal_at"] <= end else 0
        for key, ours in (("offered", "offered"), ("complete", "complete"), ("natural_eos", "natural_eos"),
                          ("capped", "capped"), ("rejected", "rejected"), ("other", "other"),
                          ("natural_cohort_good", "cohort_good"), ("natural_in_window_good", "window_good")):
            check("independent_headline", episode["summary"][key] == totals[ours], dict(episode=eid, metric=key))
        admitted = {r["request_id"] for r in rows if r["status"] == "complete"}
        episode_results.append(dict(episode_id=eid, seed=spec["seed_block"], cell=spec["cell"], policy=spec["policy"],
            acquisition_position=number, window=[start, end], totals=dict(totals),
            cohort_goodput_rps=totals["cohort_good"]/120, window_goodput_rps=totals["window_good"]/120,
            window_good_tokens_per_s=totals["window_good_tokens"]/120,
            all_assigned_good_fraction=totals["cohort_good"]/len(rows),
            native_visibility=dict(admitted=len(admitted), observed_all_samples=len(native_visible),
                observed_in_window=len(window_visible), never_observed=len(admitted-native_visible),
                never_observed_in_window=len(admitted-window_visible), foreign_ids=foreign_native,
                metadata_mismatch_ids=invalid_native),
            observation=dict(samples=len(states), in_window=len(samples_in_window), complete=complete_count,
                pending_frames=pending_count, age=quantiles(ages), gap=quantiles(sample_gaps),
                gaps_above_500ms=sum(g > .5 for g in sample_gaps)),
            send_lag=quantiles(send_lags), ttft=quantiles(ttfts), terminal_tpot_proxy=quantiles(tpots),
            attempt_latency=quantiles(latencies), drains=drain_facts,
            sampled_peaks=dict(in_flight=max(s["metrics"]["current_in_flight"] for s in states),
                waiting=max(s["metrics"]["current_waiting"] for s in states),
                outstanding=max(s["metrics"]["current_in_flight"] + s["metrics"]["current_waiting"]
                                for s in states),
                reserved_cost=max(s["metrics"]["current_admitted_cost"] for s in states)),
            scalar_ledger=dict(rows=len(ledger_seq), incomplete=ledger_incomplete,
                final_zero=ledger_final is None or ledger_final["reserved_cost"] == 0,
                owner_replay_qualified=False, suffix_authenticated=False),
            last_snapshot_counts=last_snapshot["counts"] if last_snapshot else None))
    check("epoch_run_unique", len(observed_runs) == 80)
    check("engine_run_constant", len(engine_runs) == 1)
    for a, b in zip(windows, windows[1:]):
        check("window_nonoverlap", a[1] <= b[0], [a,b])
    ledger = json.loads((BASE / "distinct-acquisition-ledger.json").read_bytes())
    check("acquisition_ledger_windows", ledger["windows"] == windows and ledger["verified_episode_ids"] == expected
          and ledger["new_distinct_seconds"] == 9600 and ledger["smoke_seconds_included"] == 0)
    aggregates = []
    lookup = {(e["seed"], e["cell"], e["policy"]): e for e in episode_results}
    for cell in cells:
        for policy in policies:
            group = [e for e in episode_results if e["cell"] == cell and e["policy"] == policy]
            totals = Counter()
            for e in group:
                totals.update(e["totals"])
            aggregates.append(dict(cell=cell, policy=policy, seed_blocks=4, duration_s=480,
                totals=dict(totals), cohort_goodput_rps=totals["cohort_good"]/480,
                window_goodput_rps=totals["window_good"]/480,
                window_good_tokens_per_s=totals["window_good_tokens"]/480,
                all_assigned_good_fraction=totals["cohort_good"]/totals["offered"]))
    contrasts = []
    policy_names = list(policies)
    for cell in cells:
        for i, a in enumerate(policy_names):
            for b in policy_names[i+1:]:
                deltas = [lookup[(seed,cell,b)]["window_goodput_rps"]-lookup[(seed,cell,a)]["window_goodput_rps"]
                          for seed in range(181045,181049)]
                contrasts.append(dict(cell=cell, comparison=b+" minus "+a, seed_deltas_rps=deltas,
                    mean_delta_rps=statistics.fmean(deltas), range=[min(deltas),max(deltas)],
                    independent_seed_units=4, confidence_interval=None))
    result = dict(schema="sol-r19-baseline04-independent-audit-v1", receipt_sha256=digest(receipt_raw),
        index_sha256=digest(index_raw), protocol_sha256=digest(protocol_raw),
        audit_script_sha256=digest(Path(__file__).read_bytes()), checks=dict(checks), failures=failures,
        artifact_manifest=actual_manifest, archives=archive_receipts, episodes=episode_results,
        aggregates=aggregates, contrasts=contrasts, new_verified_window_seconds=9600,
        prior_distinct_seconds_reported_not_reaudited=ledger["prior_distinct_seconds"],
        cumulative_distinct_seconds_reported=ledger["cumulative_distinct_seconds"],
        completion_metadata_manifest=completion_manifest,
        retained_initial_audit=dict(file="sol-r19-baseline04-initial-canonical.json",
            sha256=digest(OUTPUT.with_name("sol-r19-baseline04-initial-canonical.json").read_bytes()),
            failed_checks=64, packaging_assumption_failures=40, literal_scalar_zero_failures=24),
        source_lookup_limitations=["Published fee9f28 commit is absent from worker Git objects; exact sealed factory/classifier/protocol read from supplied nv3-024 source archive."],
        forbidden_data_read=False, peer_analyses_read=False, source_hash_authenticates_execution=False,
        native_physical_clock_qualified=False, calibrated_mpc_permit=False, active_mpc_permit=False,
        classwide_policy_conclusion=False, confidence_guarantee=False)
    raw = canonical(result)
    OUTPUT.write_bytes(raw + b"\n")
    print(json.dumps(dict(episodes=len(episode_results), assigned_ids=len(seen_ids), artifacts=len(manifest),
        failed_checks=len(failures), canonical_sha256=digest(raw), file_sha256=digest(raw+b"\n"),
        aggregates=aggregates), sort_keys=True))


if __name__ == "__main__":
    main()
