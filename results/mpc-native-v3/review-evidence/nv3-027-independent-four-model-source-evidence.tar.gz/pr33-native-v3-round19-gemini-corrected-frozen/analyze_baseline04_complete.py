#!/usr/bin/env python3
"""
Complete, standalone CPU analysis script for Baseline04 80-episode replica dataset.
Audits all 80 episodes, verifies UUID bijections, classifies 503 response bodies,
decomposes HTTP timings, and produces canonical fate & SLO tables across policies, cells, and seeds.
"""

import json
import hashlib
from pathlib import Path
from collections import defaultdict

REPLICA_DIR = Path('/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-baseline-four-seed04-replica')
RECEIPT_FILE = Path('/home/daniel_lin/gt/pr32/mayor/mpc-native-integration/results/mpc-native-v3/review-evidence/nv3-026-complete-native-baseline04-receipt.json')
OUTPUT_FILE = Path('/home/daniel_lin/.copilot/session-state/2a180def-21ed-4865-8c0e-162fc464823b/files/pr33-native-v3-baseline04-gemini-analysis.json')


def percentile(sorted_list, pct):
    if not sorted_list:
        return 0.0
    idx = min(int(pct * len(sorted_list)), len(sorted_list) - 1)
    return sorted_list[idx]


def main():
    with open(RECEIPT_FILE, 'rb') as f:
        receipt_sha = hashlib.sha256(f.read()).hexdigest()

    json_files = sorted(list(REPLICA_DIR.glob('nv3-baseline-*.json')))
    assert len(json_files) == 80, f"Expected 80 JSON files, got {len(json_files)}"

    total_offered = 0
    total_complete = 0
    total_natural_eos = 0
    total_capped = 0
    total_rejected = 0
    total_other = 0
    total_uuid_mismatches = 0
    total_stream_errors = 0

    body_shas = defaultdict(int)
    body_sha_examples = {}

    ttft_all = []
    tpot_all = []
    cleanup_all = []

    pol_stats = defaultdict(lambda: {
        'offered': 0, 'complete': 0, 'natural_eos': 0, 'rejected': 0,
        'cohort_good': 0, 'window_good': 0,
        'ttft': [], 'tpot': [], 'cleanup': []
    })

    cell_stats = defaultdict(lambda: {
        'offered': 0, 'complete': 0, 'natural_eos': 0, 'rejected': 0,
        'cohort_good': 0, 'window_good': 0,
        'ttft': [], 'tpot': [], 'cleanup': []
    })

    pol_cell_stats = defaultdict(lambda: {
        'offered': 0, 'complete': 0, 'natural_eos': 0, 'rejected': 0,
        'cohort_good': 0, 'window_good': 0,
        'ttft': [], 'tpot': [], 'cleanup': []
    })

    seed_stats = defaultdict(lambda: {
        'offered': 0, 'complete': 0, 'natural_eos': 0, 'rejected': 0,
        'cohort_good': 0, 'window_good': 0
    })

    window_stats = defaultdict(lambda: {
        'offered_30': 0, 'compl_30': 0, 'good_30': 0,
        'offered_120': 0, 'compl_120': 0, 'good_120': 0
    })

    for jf in json_files:
        with open(jf) as f:
            d = json.load(f)

        pol = d['policy']
        cell = d['cell']
        seed = int(d['seed_block'])
        start_t = d['start']
        s = d['summary']

        total_offered += s['offered']
        total_complete += s['complete']
        total_natural_eos += s['natural_eos']
        total_capped += s['capped']
        total_rejected += s['rejected']
        total_other += s['other']

        for target in (pol_stats[pol], cell_stats[cell], pol_cell_stats[(pol, cell)]):
            target['offered'] += s['offered']
            target['complete'] += s['complete']
            target['natural_eos'] += s['natural_eos']
            target['rejected'] += s['rejected']
            target['cohort_good'] += s['natural_cohort_good']
            target['window_good'] += s['natural_in_window_good']

        seed_stats[(seed, pol)]['offered'] += s['offered']
        seed_stats[(seed, pol)]['complete'] += s['complete']
        seed_stats[(seed, pol)]['rejected'] += s['rejected']
        seed_stats[(seed, pol)]['cohort_good'] += s['natural_cohort_good']
        seed_stats[(seed, pol)]['window_good'] += s['natural_in_window_good']

        window_stats[pol]['offered_120'] += s['offered']
        window_stats[pol]['compl_120'] += s['complete']
        window_stats[pol]['good_120'] += s['natural_in_window_good']

        for r in d['rows']:
            req_id = r.get('request_id')
            resp_id = r.get('response_request_id')
            if req_id != resp_id:
                total_uuid_mismatches += 1

            status = r.get('status')
            if status == 'complete':
                fc = r.get('first_content_at')
                lc = r.get('last_content_at')
                term = r.get('terminal_at')
                sched = r.get('scheduled_at')
                out = r.get('usage', {}).get('completion_tokens', 0)

                if fc is not None and sched is not None:
                    ttft = fc - sched
                    ttft_all.append(ttft)
                    pol_stats[pol]['ttft'].append(ttft)
                    cell_stats[cell]['ttft'].append(ttft)
                    pol_cell_stats[(pol, cell)]['ttft'].append(ttft)

                if fc is not None and term is not None and out > 1:
                    tpot = (term - fc) / (out - 1)
                    tpot_all.append(tpot)
                    pol_stats[pol]['tpot'].append(tpot)
                    cell_stats[cell]['tpot'].append(tpot)
                    pol_cell_stats[(pol, cell)]['tpot'].append(tpot)

                if term is not None and lc is not None:
                    lag = term - lc
                    cleanup_all.append(lag)
                    pol_stats[pol]['cleanup'].append(lag)
                    cell_stats[cell]['cleanup'].append(lag)
                    pol_cell_stats[(pol, cell)]['cleanup'].append(lag)

            elif status == 'rejected':
                b_sha = r.get('source_503_body_sha256')
                b_utf8 = r.get('source_503_body_utf8')
                body_shas[b_sha] += 1
                if b_sha not in body_sha_examples:
                    body_sha_examples[b_sha] = b_utf8

            # 30s window evaluation
            sched = r.get('scheduled_at')
            if sched is not None and sched <= start_t + 30.0:
                window_stats[pol]['offered_30'] += 1
                if status == 'complete':
                    window_stats[pol]['compl_30'] += 1
                    fc = r.get('first_content_at')
                    term = r.get('terminal_at')
                    out = r.get('usage', {}).get('completion_tokens', 0)
                    ttft = (fc - sched) if fc is not None else 999.0
                    tpot = (term - fc) / (out - 1) if (fc is not None and term is not None and out > 1) else 0.0
                    if ttft <= 0.5 and tpot <= 0.05 and term <= start_t + 30.0:
                        window_stats[pol]['good_30'] += 1

    # Sorting
    ttft_all.sort()
    tpot_all.sort()
    cleanup_all.sort()

    output_data = {
        'receipt_file': str(RECEIPT_FILE),
        'receipt_sha256': receipt_sha,
        'dataset': {
            'episodes': len(json_files),
            'total_offered': total_offered,
            'total_complete': total_complete,
            'total_natural_eos': total_natural_eos,
            'total_capped': total_capped,
            'total_rejected': total_rejected,
            'total_other': total_other,
            'total_uuid_mismatches': total_uuid_mismatches,
            'total_stream_errors': total_stream_errors,
        },
        'timing_percentiles': {
            'ttft': {
                'p50': percentile(ttft_all, 0.50),
                'p90': percentile(ttft_all, 0.90),
                'p95': percentile(ttft_all, 0.95),
                'p99': percentile(ttft_all, 0.99),
                'max': ttft_all[-1] if ttft_all else 0.0,
            },
            'tpot': {
                'p50': percentile(tpot_all, 0.50),
                'p90': percentile(tpot_all, 0.90),
                'p95': percentile(tpot_all, 0.95),
                'p99': percentile(tpot_all, 0.99),
                'max': tpot_all[-1] if tpot_all else 0.0,
            },
            'cleanup_lag': {
                'p50': percentile(cleanup_all, 0.50),
                'p90': percentile(cleanup_all, 0.90),
                'p95': percentile(cleanup_all, 0.95),
                'p99': percentile(cleanup_all, 0.99),
                'max': cleanup_all[-1] if cleanup_all else 0.0,
            }
        },
        'body_shas_503': {k: {'count': v, 'example': body_sha_examples[k]} for k, v in body_shas.items()},
        'policy_summary': {},
        'cell_summary': {},
        'policy_cell_summary': {},
        'seed_summary': {},
        'window_comparison': {}
    }

    for pol in ['fixed-cost16', 'fixed-cost32', 'fixed-count16', 'fixed-count32']:
        st = pol_stats[pol]
        st['ttft'].sort()
        st['tpot'].sort()
        output_data['policy_summary'][pol] = {
            'offered': st['offered'],
            'complete': st['complete'],
            'rejected': st['rejected'],
            'rejection_pct': round(st['rejected'] / st['offered'] * 100, 2),
            'cohort_good': st['cohort_good'],
            'window_good': st['window_good'],
            'goodput_s': round(st['window_good'] / (20 * 120.0), 3),
            'p50_ttft': round(percentile(st['ttft'], 0.50), 4),
            'p95_ttft': round(percentile(st['ttft'], 0.95), 4),
            'p50_tpot': round(percentile(st['tpot'], 0.50), 4),
            'p95_tpot': round(percentile(st['tpot'], 0.95), 4),
        }

    for cell in ['p128-m128', 'p128-m256', 'p4096-m128', 'p4096-m256', 'mixed']:
        st = cell_stats[cell]
        output_data['cell_summary'][cell] = {
            'offered': st['offered'],
            'complete': st['complete'],
            'rejected': st['rejected'],
            'rejection_pct': round(st['rejected'] / st['offered'] * 100, 2),
            'cohort_good': st['cohort_good'],
            'window_good': st['window_good'],
            'slo_attainment_pct': round(st['window_good'] / st['complete'] * 100, 2) if st['complete'] else 0.0
        }

    for cell in ['p128-m128', 'p128-m256', 'p4096-m128', 'p4096-m256', 'mixed']:
        for pol in ['fixed-cost16', 'fixed-cost32', 'fixed-count16', 'fixed-count32']:
            st = pol_cell_stats[(pol, cell)]
            st['ttft'].sort()
            st['tpot'].sort()
            output_data['policy_cell_summary'][f"{cell}__{pol}"] = {
                'cell': cell,
                'policy': pol,
                'offered': st['offered'],
                'complete': st['complete'],
                'rejected': st['rejected'],
                'rejection_pct': round(st['rejected'] / st['offered'] * 100, 2),
                'window_good': st['window_good'],
                'slo_attainment_pct': round(st['window_good'] / st['complete'] * 100, 2) if st['complete'] else 0.0,
                'p50_ttft': round(percentile(st['ttft'], 0.50), 4),
                'p95_ttft': round(percentile(st['ttft'], 0.95), 4),
                'p50_tpot': round(percentile(st['tpot'], 0.50), 4),
                'p95_tpot': round(percentile(st['tpot'], 0.95), 4),
            }

    for seed in [181045, 181046, 181047, 181048]:
        for pol in ['fixed-cost16', 'fixed-cost32', 'fixed-count16', 'fixed-count32']:
            st = seed_stats[(seed, pol)]
            output_data['seed_summary'][f"seed_{seed}__{pol}"] = {
                'seed': seed,
                'policy': pol,
                'offered': st['offered'],
                'complete': st['complete'],
                'rejected': st['rejected'],
                'window_good': st['window_good']
            }

    for pol in ['fixed-cost16', 'fixed-cost32', 'fixed-count16', 'fixed-count32']:
        ws = window_stats[pol]
        output_data['window_comparison'][pol] = {
            'offered_30s': ws['offered_30'],
            'complete_30s': ws['compl_30'],
            'good_30s': ws['good_30'],
            'goodput_s_30s': round(ws['good_30'] / (20 * 30.0), 3),
            'goodput_s_120s': round(ws['good_120'] / (20 * 120.0), 3),
        }

    with open(OUTPUT_FILE, 'w') as f:
        json.dump(output_data, f, indent=2)

    print(f"Audit complete. Canonical analysis written to {OUTPUT_FILE}")


if __name__ == '__main__':
    main()
