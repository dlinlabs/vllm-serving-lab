import ast
from collections import Counter, defaultdict
import hashlib
import itertools
import json
import math
from pathlib import Path
import random
import statistics

B = Path("/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files")
ROOT = B / "pr33-native-v3-baseline-four-seed04-replica"
SOURCE = Path("/home/daniel_lin/gt/pr32/mayor/mpc-native-count-baseline/experiments/mpc-research/native-v3")
RECEIPT = Path("/home/daniel_lin/gt/pr32/mayor/mpc-native-integration/results/mpc-native-v3/review-evidence/nv3-026-complete-native-baseline04-receipt.json")
OUT = Path("/home/daniel_lin/gt/pr32/polecats/jade/pr32/.runtime/astra-r19-baseline04-analysis.json")
SEEDS = (181045, 181046, 181047, 181048)
CELLS = ("p128-m128", "p128-m256", "p4096-m128", "p4096-m256", "mixed")
POLICIES = ("fixed-cost16", "fixed-cost32", "fixed-count16", "fixed-count32")

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def checked(path, expected):
    raw = path.read_bytes()
    assert sha(raw) == expected, str(path)
    return raw

receipt_raw = checked(RECEIPT, "00fb93ff8e5d8afd3eb06e23b2e4e1b77ffb7917e31a52e11072ca9159155694")
receipt = json.loads(receipt_raw)
protocol_raw = checked(B / "pr33-native-v3-four-seed-baseline04-protocol.json", receipt["protocol_sha256"])
protocol = json.loads(protocol_raw)
index_raw = checked(ROOT / "latest-index.json", receipt["index_sha256"])
index = json.loads(index_raw)
assert index["completed"] is True and index["mpc_active"] is False
assert index["actual_offered_window_s"] == protocol["planned_offered_window_s"] == 9600
assert len(index["episodes"]) == len(protocol["episodes"]) == len(index["gateway_epochs"]) == 80
assert [(e["episode_id"], e["artifact"], e["split"]) for e in index["episodes"]] == [
    (e["episode_id"], e["episode_id"] + ".json", "train") for e in protocol["episodes"]]
assert {(s["seed_block"], s["cell"], s["policy"]) for s in protocol["episodes"]} == set(
    itertools.product(SEEDS, CELLS, POLICIES))
assert all(s["split"] == "train" and s["duration_s"] == 120 for s in protocol["episodes"])
for key in ("collector_sha256", "classifier_sha256", "implementation_hash", "serving_source_commit"):
    assert index[key] == receipt[key] == protocol[key]

manifest_raw = (ROOT / "verified-artifact-sha256.jsonl").read_bytes()
manifest = [json.loads(line) for line in manifest_raw.splitlines() if line.strip()]
hashes = {r["artifact"]: r["sha256"] for r in receipt["artifact_manifest"]}
assert len(hashes) == len(manifest) == 400
assert hashes == {r["artifact"]: r["sha256"] for r in manifest}
expected_names = {s["episode_id"] + ext for s in protocol["episodes"] for ext in (".json", ".events.jsonl")}
expected_names |= {f"gateway-epoch-{i:04d}/{name}" for i in range(1, 81)
                   for name in ("gateway-telemetry.jsonl", "gateway-telemetry-status.json", "process.log")}
assert set(hashes) == expected_names
verified_bytes = 0
for name, expected in hashes.items():
    path = ROOT / name
    assert not path.is_symlink() and ".." not in Path(name).parts
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
            verified_bytes += len(chunk)
    assert digest.hexdigest() == expected, name

collector = checked(SOURCE / "count_baseline.py", protocol["collector_sha256"])
classifier = checked(SOURCE / "baseline_http_capture.py", protocol["classifier_sha256"])
legacy = checked(SOURCE / "collect_identification.py", protocol["legacy_collector_sha256"])
env = dict(math=math, random=random)
nodes = [n for n in ast.parse(legacy).body
         if isinstance(n, ast.FunctionDef) and n.name == "tape_for"
         or isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "CELLS" for t in n.targets)]
exec(compile(ast.Module(body=nodes, type_ignores=[]), "pinned-tape-only", "exec"), env)
env["messages"] = lambda tokenizer, target, words, topic: dict(target=target, words=words, topic=topic)
node = next(n for n in ast.parse(collector).body if isinstance(n, ast.FunctionDef) and n.name == "payloads_for")
exec(compile(ast.Module(body=[node], type_ignores=[]), "pinned-payload-recipe-only", "exec"), env)

def stats(values):
    assert len(values) == 4
    return dict(by_seed=dict(zip(map(str, SEEDS), values)), mean=statistics.mean(values),
                sample_sd=statistics.stdev(values), seed_range=[min(values), max(values)],
                leave_one_seed_out_mean_range=[
                    min(statistics.mean(values[:i] + values[i+1:]) for i in range(4)),
                    max(statistics.mean(values[:i] + values[i+1:]) for i in range(4))],
                independent_seed_n=4, confidence_interval=False)

episodes, pairs, order = {}, defaultdict(dict), defaultdict(list)
all_ids, native_runs = set(), set()
prior_completed = None
for position, spec in enumerate(protocol["episodes"], 1):
    name = spec["episode_id"]
    doc = json.loads(checked(ROOT / (name + ".json"), hashes[name + ".json"]))
    assert all(doc[k] == v for k, v in spec.items())
    seed, cell, policy = spec["seed_block"], spec["cell"], spec["policy"]
    epoch = f"gateway-epoch-{position:04d}"
    assert index["gateway_epochs"][position - 1]["evidence"] == epoch
    assert index["gateway_epochs"][position - 1]["policy"] == policy
    assert prior_completed is None or prior_completed <= doc["start"]
    prior_completed = doc["completed_at"]
    assert doc["completed_at"] >= doc["start"] + 120
    order[(seed, cell)].append(policy)
    tape = env["tape_for"](seed, cell, 120)
    assert doc["offered_tape"] == tape
    recipe = env["payloads_for"](None, seed, cell, tape)
    ids = doc["expected_ids"]
    assert len(ids) == len(set(ids)) == len(tape) == len(doc["rows"])
    assert not all_ids.intersection(ids)
    all_ids.update(ids)
    rows = {r["request_id"]: r for r in doc["rows"]}
    assert set(rows) == set(ids)
    ordered = [rows[rid] for rid in ids]
    counts = Counter(offered=len(ids))
    fates, finishes, source_fates = Counter(), Counter(), Counter()
    observations = []
    for rid, at, payload, row in zip(ids, tape, recipe, ordered):
        assert row["clock_domain"] == index["clock_domain"]
        assert row["response_request_id"] == rid
        assert row["baseline_classifier_sha256"] == protocol["classifier_sha256"]
        assert row["source_capture_sha256"] == protocol["http_capture_sha256"]
        assert row["request_model"] == payload["model"] and row["requested_ignore_eos"] is False
        assert row["requested_max_tokens"] == payload["max_tokens"]
        assert row["scheduled_at"] == doc["start"] + at
        assert row["scheduled_at"] <= row["sent_at"] <= row["terminal_at"] <= doc["completed_at"]
        expected_mode = "cost_aware" if "cost" in policy else "protected"
        assert row["admission_policy_mode"] == expected_mode
        fates[row["status"]] += 1
        source_fates[row["source_capture_status"]] += 1
        output = None
        if row["status"] == "complete":
            counts["complete"] += 1
            assert row["http_status"] == 200 and row["stream_done"] and not row["stream_error"]
            assert row["source_capture_status"] == "complete"
            output = row["usage"]["completion_tokens"]
            finishes[row["finish_reason"]] += 1
            natural = row["finish_reason"] == "stop"
            counts["natural_eos"] += natural
            counts["capped"] += row["finish_reason"] == "length"
            ttft = row["first_content_at"] - row["scheduled_at"]
            tpot = (row["terminal_at"] - row["first_content_at"]) / (output - 1) if output > 1 else None
            good = natural and output > 1 and 0 <= ttft <= protocol["ttft_slo_s"] and 0 <= tpot <= protocol["tpot_slo_s"]
            counts["natural_cohort_good"] += good
            counts["natural_in_window_good"] += good and row["terminal_at"] <= doc["start"] + 120
            counts["good_after_window"] += good and row["terminal_at"] > doc["start"] + 120
            counts["natural_ttft_failed"] += natural and not 0 <= ttft <= protocol["ttft_slo_s"]
            counts["natural_tpot_failed_or_undefined"] += natural and (tpot is None or not 0 <= tpot <= protocol["tpot_slo_s"])
        elif row["status"] == "rejected":
            counts["rejected"] += 1
            assert row["http_status"] == 503 and row["admission_rejection"] is True
            body = row["source_503_body_utf8"].encode()
            assert sha(body) == row["source_503_body_sha256"]
            parsed = json.loads(body)
            assert parsed["detail"] == "request rejected: admission capacity exceeded"
            if expected_mode == "protected":
                assert row["source_capture_status"] == "failed"
                assert set(parsed) == {"detail", "estimated_request_cost", "estimated_input_tokens",
                                       "estimated_output_tokens", "max_admitted_cost", "budget_version"}
                assert parsed["estimated_request_cost"] == parsed["estimated_input_tokens"] == parsed["estimated_output_tokens"] == 0
                assert parsed["max_admitted_cost"] is None and parsed["budget_version"] is None
            else:
                assert row["source_capture_status"] == "rejected"
        else:
            counts["other"] += 1
        counts["terminal_after_window"] += row["terminal_at"] > doc["start"] + 120
        observations.append(dict(status=row["status"], maximum=row["requested_max_tokens"],
                                 actual_prompt=row["usage"]["prompt_tokens"] if row["status"] == "complete" else None))
    for key in ("offered", "complete", "natural_eos", "capped", "rejected", "other",
                "natural_cohort_good", "natural_in_window_good"):
        assert counts[key] == doc["summary"][key], (name, key)
    assert sum(fates.values()) == counts["offered"]
    events = defaultdict(list)
    event_raw = checked(ROOT / (name + ".events.jsonl"), hashes[name + ".events.jsonl"])
    for line in event_raw.splitlines():
        event = json.loads(line)
        events[event["kind"]].append(event["value"])
    assert set(events) <= {"state", "http_outcome", "final_drain_probe"}
    assert events["http_outcome"] == doc["rows"] and events["state"] == doc["samples"]
    assert events["final_drain_probe"] == doc["final_drain_probes"]
    status = json.loads(checked(ROOT / epoch / "gateway-telemetry-status.json", hashes[epoch + "/gateway-telemetry-status.json"]))
    assert status["status"] == "closed" and status["dropped"] == status["write_errors"] == 0
    assert status["run_id"] == doc["gateway_run_id"]
    assert doc["gateway_telemetry_receipt"]["sha256"] == hashes[epoch + "/gateway-telemetry.jsonl"]
    request_events, geometry = defaultdict(Counter), {}
    with (ROOT / epoch / "gateway-telemetry.jsonl").open() as stream:
        for line in stream:
            event = json.loads(line)
            assert event["run_id"] == doc["gateway_run_id"]
            rid = event.get("request_id")
            if rid is not None:
                assert rid in rows
                request_events[rid][event["event"]] += 1
                if event["event"] in ("accepted", "rejected") and "cost" in policy:
                    value = [event["estimated_input_tokens"], event["max_output_tokens"]]
                    assert rid not in geometry
                    geometry[rid] = value
    assert set(request_events) == set(ids)
    for rid in ids:
        ev = request_events[rid]
        assert ev["received"] == 1
        if rows[rid]["status"] == "complete":
            assert ev["accepted"] == ev["completed"] == 1 and ev["rejected"] == ev["failed"] == 0
        elif rows[rid]["status"] == "rejected":
            assert ev["rejected"] == 1 and ev["accepted"] == ev["completed"] == ev["failed"] == 0
    for sample in doc["samples"] + doc["initial_drain"] + doc["final_drain"]:
        m, n = sample["metrics"], sample["native"]
        assert m["telemetry_run_id"] == doc["gateway_run_id"]
        assert m["admission_mode"] == ("cost_aware" if "cost" in policy else "protected")
        assert m["max_in_flight"] == (16 if policy == "fixed-count16" else 32)
        assert m["admission_budget"] == (16 if policy == "fixed-cost16" else 32)
        assert m["max_waiting_capacity"] == 2 and m["budget_version"] == 0
        assert n["clock_domain"] == index["clock_domain"] and n["observer_sha256"] == protocol["observer_sha256"]
        native_runs.add(n["run_id"])
    episodes[name] = dict(seed=seed, cell=cell, policy=policy, protocol_position=position,
                          start=doc["start"], completed_at=doc["completed_at"],
                          offered_seconds=120, counts=dict(counts), fates=dict(fates),
                          source_capture_fates=dict(source_fates), finish_reasons=dict(finishes),
                          natural_goodput_per_s=counts["natural_cohort_good"] / 120,
                          all_assigned_good_fraction=counts["natural_cohort_good"] / counts["offered"],
                          in_window_goodput_per_s=counts["natural_in_window_good"] / 120,
                          terminal_lag_after_window_s=max(0., max(r["terminal_at"] for r in ordered) - doc["start"] - 120))
    pairs[(seed, cell)][policy] = dict(tape_sha256=sha(canonical(tape)),
                                      intended_recipe_sha256=sha(canonical(recipe)),
                                      observed=observations,
                                      cost_geometry=[geometry[rid] for rid in ids] if "cost" in policy else None)

pair_audits = {}
for (seed, cell), arms in pairs.items():
    assert set(arms) == set(POLICIES)
    assert len({v["tape_sha256"] for v in arms.values()}) == 1
    assert len({v["intended_recipe_sha256"] for v in arms.values()}) == 1
    assert arms["fixed-cost16"]["cost_geometry"] == arms["fixed-cost32"]["cost_geometry"]
    comparable, disagreements = 0, []
    count_usage_checked = 0
    for i, values in enumerate(zip(*(arms[p]["observed"] for p in POLICIES))):
        assert len({v["maximum"] for v in values}) == 1
        observed = [v["actual_prompt"] for v in values if v["actual_prompt"] is not None]
        comparable += len(observed) >= 2
        if len(set(observed)) > 1:
            disagreements.append(i)
        for value in values:
            if value["actual_prompt"] is not None:
                count_usage_checked += 1
                assert value["actual_prompt"] == arms["fixed-cost16"]["cost_geometry"][i][0]
                assert value["maximum"] == arms["fixed-cost16"]["cost_geometry"][i][1]
    assert not disagreements
    expected_order = ["fixed-count16", "fixed-count32", "fixed-cost16", "fixed-cost32"]
    random.Random(f"baseline-order:181045:{cell}").shuffle(expected_order)
    if SEEDS.index(seed) % 2:
        expected_order.reverse()
    assert order[(seed, cell)] == expected_order
    pair_audits[f"{seed}|{cell}"] = dict(
        offered=len(arms[POLICIES[0]]["observed"]), tape_sha256=arms[POLICIES[0]]["tape_sha256"],
        intended_recipe_sha256=arms[POLICIES[0]]["intended_recipe_sha256"], policy_order=expected_order,
        all_requested_caps_match=True, cost_policy_geometry_all_offers_equal=True,
        completion_usage_geometry_matches_cost_policy=True, completion_usage_rows_checked=count_usage_checked,
        positions_with_two_or_more_completed_prompt_observations=comparable,
        completed_prompt_disagreements=disagreements, exact_outgoing_payload_bytes_verified=False)

by_key = {(e["seed"], e["cell"], e["policy"]): e for e in episodes.values()}
policy_results = {}
contrasts = {}
for cell in (*CELLS, "equal_exposure_five_cell_mixture"):
    selected_cells = CELLS if cell == "equal_exposure_five_cell_mixture" else (cell,)
    seconds = 120 * len(selected_cells)
    for policy in POLICIES:
        policy_results[f"{cell}|{policy}"] = stats([
            sum(by_key[(s, c, policy)]["counts"].get("natural_cohort_good", 0) for c in selected_cells) / seconds
            for s in SEEDS])
    for left, right in itertools.combinations(POLICIES, 2):
        differences = [
            sum(by_key[(s, c, right)]["counts"].get("natural_cohort_good", 0)
                - by_key[(s, c, left)]["counts"].get("natural_cohort_good", 0)
                for c in selected_cells) for s in SEEDS]
        contrasts[f"{cell}|{right}-minus-{left}"] = dict(
            right=right, left=left, good_count_difference_by_seed=dict(zip(map(str, SEEDS), differences)),
            offered_seconds_per_policy_seed=seconds, **stats([d / seconds for d in differences]))
totals = {}
for policy in POLICIES:
    selected = [e for e in episodes.values() if e["policy"] == policy]
    counts = Counter()
    fates = Counter()
    for episode in selected:
        counts.update(episode["counts"])
        fates.update(episode["fates"])
    totals[policy] = dict(counts=dict(counts), fates=dict(fates), offered_seconds=2400,
                         goodput_per_s=counts["natural_cohort_good"] / 2400,
                         all_assigned_good_fraction=counts["natural_cohort_good"] / counts["offered"])
result = dict(
    schema="astra-r19-independent-baseline04-paired-analysis-v1",
    receipt_sha256=sha(receipt_raw), protocol_sha256=sha(protocol_raw), index_sha256=sha(index_raw),
    manifest_sha256=sha(manifest_raw), verified_artifacts=400, verified_bytes=verified_bytes,
    artifact_sha256=hashes, source_hashes=dict(collector=sha(collector), classifier=sha(classifier), legacy=sha(legacy)),
    analysis_source_sha256=sha(ANALYSIS_SOURCE.encode()), all_assigned_uuid_count=len(all_ids),
    native_runs=sorted(native_runs), independent_seeds=list(SEEDS),
    primary_metric="natural_EOS_SLO_good_all_assigned_cohort_per_offered_second",
    uncertainty="four seed contrasts, sample SD, observed range, leave-one-seed-out mean range; no CI or p-values",
    episodes=episodes, pairing_audits=pair_audits, policy_goodput=policy_results,
    paired_goodput_contrasts=contrasts, policy_totals=totals,
    exact_outgoing_payload_bytes_verified=False, fitted_state_recovered=False,
    h16_runtime_qualified=False, active_mpc_permit=False, closed_loop_mpc_conclusion=False,
    prior_discovery_failures=[
        "Expected protocol.json/index.json at replica root; protocol.json absent. Actual inputs are latest-index.json plus separately sealed baseline04 protocol.",
        "Published integration-tree baseline source search returned no matches; exact producer sources were located and hash-verified in the separate count-baseline worktree."],
)
raw = canonical(result)
OUT.write_bytes(raw)
print(json.dumps(dict(raw_path=str(OUT), raw_bytes=len(raw), raw_sha256=sha(raw),
                      verified_bytes=verified_bytes, policy_totals=totals), sort_keys=True))