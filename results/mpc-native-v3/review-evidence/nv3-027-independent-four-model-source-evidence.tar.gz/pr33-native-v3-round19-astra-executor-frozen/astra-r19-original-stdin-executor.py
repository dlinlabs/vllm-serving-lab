from pathlib import Path
report=Path('/home/daniel_lin/gt/pr32/polecats/jade/pr32/experiments/mpc-research/native-v3/astra.md').read_text()
source=report.rsplit('\n### R19 analysis source\n',1)[1].split('```python\n',1)[1].split('\n```',1)[0]
exec(compile(source,'owned-report-r19-analysis','exec'),{'ANALYSIS_SOURCE':source})
