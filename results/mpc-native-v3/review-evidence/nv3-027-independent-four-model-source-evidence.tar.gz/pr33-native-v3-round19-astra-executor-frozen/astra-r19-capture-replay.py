import contextlib
import hashlib
import io
import json
from pathlib import Path
import sys
from unittest.mock import patch

source_bytes = Path(__file__).with_name("astra-r19-executed-source.py").read_bytes()
assert len(source_bytes) == 18979
assert hashlib.sha256(source_bytes).hexdigest() == "cd9644c4512af5c89a836cc4c1d3adf23f8e2ed7fbe2a3318dd14f94bda01ac9"
source = source_bytes.decode("utf-8")
original_out = Path("/home/daniel_lin/gt/pr32/polecats/jade/pr32/.runtime/astra-r19-baseline04-analysis.json")
captured = []


def capture_write(path, data):
    if path != original_out or captured:
        raise RuntimeError("Unexpected analysis write")
    captured.append(bytes(data))
    return len(data)


analysis_stdout = io.StringIO()
with contextlib.redirect_stdout(analysis_stdout):
    with patch.object(Path, "write_bytes", capture_write):
        exec(compile(source, "owned-report-r19-analysis", "exec"), {"ANALYSIS_SOURCE": source})

assert len(captured) == 1
raw = captured[0]
digest = hashlib.sha256(raw).hexdigest()
assert len(raw) == 149913
assert digest == "ca1779eb9fb4fbb4398f226395904cfbaa29c3be3bbe1bd002e8cb145b00a3db"
original_print = json.loads(analysis_stdout.getvalue())
assert original_print["raw_sha256"] == digest
assert original_print["raw_bytes"] == len(raw)
assert original_print["raw_path"] == str(original_out)
sys.stderr.write(json.dumps({
    "source_sha256": hashlib.sha256(source_bytes).hexdigest(),
    "raw_sha256": digest,
    "raw_bytes": len(raw),
    "original_OUT_write_intercepted": True,
    "raw_destination": "stdout",
}, sort_keys=True) + "\n")
sys.stdout.buffer.write(raw)
