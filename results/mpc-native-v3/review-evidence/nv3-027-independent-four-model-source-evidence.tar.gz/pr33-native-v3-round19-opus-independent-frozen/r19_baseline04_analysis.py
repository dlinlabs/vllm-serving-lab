"""NV3 R19 Opus independent CPU analysis of COMPLETE baseline04 (stdlib only, read-only)."""
import hashlib, json, math, os, statistics, sys
from collections import defaultdict
from pathlib import Path

D = Path(sys.argv[1]); RECEIPT = Path(sys.argv[2]); OUT = Path(sys.argv[3])
RECEIPT_SHA = "00fb93ff8e5d8afd3eb06e23b2e4e1b77ffb7917e31a52e11072ca9159155694"
TTFT, TPOT, WINDOW = .5, .05, 120
POLICIES = ("fixed-count16", "fixed-count32", "fixed-cost16", "fixed-cost32")
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(RECEIPT) == RECEIPT_SHA
rec = json.loads(RECEIPT.read_text())
man = {a["artifact"]: a["sha256"] for a in rec["artifact_manifest"]}
mismatch = sorted(a for a, h in man.items() if sha(D / a) != h)
extra = {str(p.relative_to(D)): sha(p) for p in sorted(D.rglob("*"))
         if p.is_file() and str(p.relative_to(D)) not in man}
index = json.loads((D / "latest-index.json").read_text())
assert sha(D / "latest-index.json") == rec["index_sha256"] and not mismatch

def q(xs, p):
    if not xs: return None
    xs = sorted(xs); k = (len(xs) - 1) * p; f = math.floor(k)
    return xs[f] + (xs[min(f + 1, len(xs) - 1)] - xs[f]) * (k - f)

def legacy_summary(rows, start):
    complete = [r for r in rows if r["status"] == "complete"]
    natural = [r for r in complete if r["finish_reason"] == "stop"]
    def good(r):
        o = r["usage"]["completion_tokens"]
        return (o > 1 and 0 <= r["first_content_at"] - r["scheduled_at"] <= TTFT
                and 0 <= (r["terminal_at"] - r["first_content_at"]) / (o - 1) <= TPOT)
    return dict(offered=len(rows), complete=len(complete), natural_eos=len(natural),
                capped=sum(r["finish_reason"] == "length" for r in complete),
                rejected=sum(r["status"] == "rejected" for r in rows),
                other=sum(r["status"] not in ("complete", "rejected") for r in rows),
                natural_cohort_good=sum(good(r) for r in natural),
                natural_in_window_good=sum(good(r) and r["terminal_at"] <= start + WINDOW
                                           for r in natural),
                metric_scope="Identification labels, not a frozen MPC superiority outcome")

episodes, failures = {}, []
for ent in index["episodes"]:
    e = json.loads((D / ent["artifact"]).read_text())
    rows = e["rows"]; ids = [r["request_id"] for r in rows]
    checks = dict(
        all_offered_ids=len(ids) == len(set(ids)) == len(e["expected_ids"]) == len(e["offered_tape"])
        and set(ids) == set(e["expected_ids"]),
        summary_reproduced=legacy_summary(rows, e["start"]) == e["summary"],
        duration=e["duration_s"] == WINDOW,
        no_ignore_eos=all(r["requested_ignore_eos"] is False for r in rows),
        reject_mode_consistent=all(
            (r["admission"]["budget_version"] is None) == e["policy"].startswith("fixed-count")
            for r in rows if r["status"] == "rejected"),
        telemetry_receipt=bool(e.get("gateway_telemetry_receipt")),
        final_drain=len(e["final_drain"]) == 2 and len(e["initial_drain"]) == 2)
    if not all(checks.values()):
        failures.append(dict(episode=e["episode_id"], checks=checks))
    natural = [r for r in rows if r["status"] == "complete" and r["finish_reason"] == "stop"]
    ttft = [r["first_content_at"] - r["scheduled_at"] for r in natural if r["first_content_at"] is not None]
    tpot = [(r["terminal_at"] - r["first_content_at"]) / (r["usage"]["completion_tokens"] - 1)
            for r in natural if r["usage"]["completion_tokens"] > 1]
    out_tok = sum(r["usage"]["completion_tokens"] for r in natural)
    s = e["summary"]
    status_counts = defaultdict(int)
    for r in rows: status_counts[r["status"]] += 1
    episodes[e["episode_id"]] = dict(
        seed=e["seed_block"], cell=e["cell"], policy=e["policy"], checks=checks,
        status_counts=dict(sorted(status_counts.items())), summary=s,
        good_rate=s["natural_in_window_good"] / s["offered"],
        cohort_good_rate=s["natural_cohort_good"] / s["offered"],
        reject_rate=s["rejected"] / s["offered"],
        in_window_goodput_per_s=s["natural_in_window_good"] / WINDOW,
        natural_output_tokens=out_tok,
        ttft_slo_violations=sum(not 0 <= x <= TTFT for x in ttft),
        tpot_slo_violations=sum(not 0 <= x <= TPOT for x in tpot),
        output_le_1=sum(r["usage"]["completion_tokens"] <= 1 for r in natural),
        ttft_s={k: q(ttft, p) for k, p in (("p50", .5), ("p90", .9), ("p99", .99))} | {"max": max(ttft, default=None)},
        tpot_s={k: q(tpot, p) for k, p in (("p50", .5), ("p90", .9), ("p99", .99))} | {"max": max(tpot, default=None)})

cells = sorted({v["cell"] for v in episodes.values()}); seeds = sorted({v["seed"] for v in episodes.values()})
grid = {(v["seed"], v["cell"], v["policy"]): v for v in episodes.values()}
assert len(grid) == 80 == len(seeds) * len(cells) * len(POLICIES)

def seed_stats(vals):
    return dict(per_seed=vals, mean=statistics.fmean(vals), min=min(vals), max=max(vals),
                sd_across_seeds=statistics.stdev(vals))

KEYS = ("offered", "complete", "natural_eos", "capped", "rejected", "other",
        "natural_cohort_good", "natural_in_window_good")
cell_table = {}
for c in cells:
    for p in POLICIES:
        eps = [grid[(s, c, p)] for s in seeds]
        cell_table[f"{c}|{p}"] = dict(
            totals={k: sum(e["summary"][k] for e in eps) for k in KEYS},
            good_rate=seed_stats([e["good_rate"] for e in eps]),
            reject_rate=seed_stats([e["reject_rate"] for e in eps]),
            goodput_per_s=seed_stats([e["in_window_goodput_per_s"] for e in eps]),
            ttft_p90_s=seed_stats([e["ttft_s"]["p90"] for e in eps]),
            tpot_p90_s=seed_stats([e["tpot_s"]["p90"] for e in eps]),
            ttft_slo_violations=sum(e["ttft_slo_violations"] for e in eps),
            tpot_slo_violations=sum(e["tpot_slo_violations"] for e in eps))
policy_table = {}
for p in POLICIES:
    per_seed = [sum(grid[(s, c, p)]["summary"]["natural_in_window_good"] for c in cells) for s in seeds]
    offered = [sum(grid[(s, c, p)]["summary"]["offered"] for c in cells) for s in seeds]
    policy_table[p] = dict(
        totals={k: sum(grid[(s, c, p)]["summary"][k] for s in seeds for c in cells) for k in KEYS},
        in_window_good_per_seed=seed_stats(per_seed),
        good_rate_per_seed=seed_stats([g / o for g, o in zip(per_seed, offered)]),
        goodput_per_s_per_seed=seed_stats([g / (WINDOW * len(cells)) for g in per_seed]))
# paired by seed (and seed x cell) against fixed-count16; descriptive, n=4 seeds, no inference
paired = {}
for p in POLICIES[1:]:
    d = [policy_table[p]["in_window_good_per_seed"]["per_seed"][i]
         - policy_table["fixed-count16"]["in_window_good_per_seed"]["per_seed"][i] for i in range(len(seeds))]
    cellwise = {c: [grid[(s, c, p)]["summary"]["natural_in_window_good"]
                    - grid[(s, c, "fixed-count16")]["summary"]["natural_in_window_good"] for s in seeds]
                for c in cells}
    paired[f"{p}-minus-fixed-count16"] = dict(
        per_seed=d, seeds_positive=sum(x > 0 for x in d), seeds_negative=sum(x < 0 for x in d),
        cell_seed=cellwise,
        cells_all_four_seeds_same_sign={c: (all(x > 0 for x in v) and "+") or (all(x < 0 for x in v) and "-") or "mixed"
                                        for c, v in cellwise.items()})
result = dict(
    schema="nv3-opus-r19-baseline04-analysis-v1", receipt_sha256=RECEIPT_SHA,
    published_commit="fee9f28f69731a4db648597a5a62dbc4f824d8aa",
    protocol_sha256=index["protocol_sha256"], index_sha256=rec["index_sha256"],
    analysis_script_sha256=sha(__file__),
    rehash=dict(manifest_artifacts=len(man), mismatched=mismatch, unmanifested_files=extra),
    slo=dict(ttft_s=TTFT, tpot_s=TPOT, http_attempt_timeout_s=30, window_s=WINDOW,
             good="natural EOS, output>1, TTFT from scheduled_at, in-window terminal"),
    seeds=seeds, cells=cells, policies=list(POLICIES), episode_check_failures=failures,
    cell_policy_table=cell_table, policy_table=policy_table, paired_vs_fixed_count16=paired,
    episodes=episodes,
    scope=dict(unit_of_replication="seed block (n=4), not request", units_note=
               "count16/32 cap in-flight requests; cost16/32 cap admitted cost units; labels are not comparable magnitudes",
               mpc_permit=False, superiority_claim=False, statistical_guarantee=False,
               calval_or_source03_used=False))
OUT.write_text(json.dumps(result, indent=1, sort_keys=True, allow_nan=False) + "\n")
print(sha(OUT), OUT)
