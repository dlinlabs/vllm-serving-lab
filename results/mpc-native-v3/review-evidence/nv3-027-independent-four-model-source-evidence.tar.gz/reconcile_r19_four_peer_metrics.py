import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
manifest = json.loads((BASE / "pr33-native-v3-round19-crosscritique-inputs.json").read_text())
peers = {}
for peer, entry in manifest["peers"].items():
    raw = (BASE / entry["raw"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == entry["raw_sha256"]
    peers[peer] = json.loads(raw)

opus, astra, sol, gemini = (peers[name] for name in ("opus", "astra", "sol", "gemini"))
sol_episodes = {row["episode_id"]: row for row in sol["episodes"]}
assert len(sol_episodes) == 80
assert set(sol_episodes) == set(opus["episodes"]) == set(astra["episodes"])
assert not sol["failures"]
aliases = {
    "offered": "offered",
    "complete": "complete",
    "rejected": "rejected",
    "natural_eos": "natural_eos",
    "capped": "capped",
    "natural_cohort_good": "cohort_good",
    "natural_in_window_good": "window_good",
}
matched = {}
for episode_id, row in opus["episodes"].items():
    right = sol_episodes[episode_id]
    assert (row["seed"], row["cell"], row["policy"]) == (
        right["seed"], right["cell"], right["policy"])
    for field, alias in aliases.items():
        assert row["summary"][field] == astra["episodes"][episode_id]["counts"][field]
        assert row["summary"][field] == right["totals"][alias], (episode_id, field)
    matched[episode_id] = {field: row["summary"][field] for field in aliases}

policy_rows = {}
for policy, row in opus["policy_table"].items():
    totals = row["totals"]
    aggregate = gemini["policy_summary"][policy]
    for field, alias in aliases.items():
        if alias in aggregate:
            assert totals[field] == aggregate[alias], (policy, field)
    policy_rows[policy] = totals
    for seed in opus["seeds"]:
        selected = [entry for entry in opus["episodes"].values()
                    if entry["seed"] == seed and entry["policy"] == policy]
        assert len(selected) == 5
        recorded = gemini["seed_summary"][f"seed_{seed}__{policy}"]
        for field, alias in (
            ("offered", "offered"), ("complete", "complete"),
            ("rejected", "rejected"), ("natural_in_window_good", "window_good"),
        ):
            assert sum(entry["summary"][field] for entry in selected) == recorded[alias]

global_counts = {field: sum(row[field] for row in matched.values()) for field in aliases}
for field in ("offered", "complete", "rejected", "natural_eos", "capped"):
    assert global_counts[field] == gemini["dataset"]["total_" + field]
assert gemini["dataset"]["total_other"] == 0
assert global_counts["offered"] == 112652
assert global_counts["complete"] == global_counts["natural_eos"] == 77064
assert global_counts["rejected"] == 35588
assert global_counts["natural_cohort_good"] == 64188
assert global_counts["natural_in_window_good"] == 63633

result = {
    "schema": "r19-four-peer-common-count-agreement-v1",
    "input_raw_sha256": {peer: entry["raw_sha256"] for peer, entry in manifest["peers"].items()},
    "three_independent_replays_all80_seven_fields_match": True,
    "fourth_summary_aggregation_all_four_policies_and16_seed_policy_groups_match": True,
    "matched_episode_counts": matched,
    "policy_totals": policy_rows,
    "global_counts": global_counts,
    "qualifications": {
        "gemini_independent_slo_replay": False,
        "percentile_estimators_identical": False,
        "complete_wire_payload_identity_verified": False,
        "physical_release_qualified": False,
        "mpc_superiority_claim": False,
        "four_model_crosscritique_complete": False,
    },
}
target = BASE / "pr33-native-v3-round19-four-peer-metric-agreement.json"
with target.open("x") as stream:
    stream.write(json.dumps(result, indent=2) + "\n")
print("Three independent per-episode count replays and fourth aggregate/seed tables agree exactly.")
print(json.dumps(global_counts, indent=2))
