import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
INPUTS = {
    "opus": (
        "pr33-native-v3-round19-opus-independent-frozen/opus-r19-baseline04-analysis.json",
        "7a2666007744396dc47e6ab70245df00b343a9108ee5805f8b19eb2fc8f2716c",
    ),
    "astra": (
        "pr33-native-v3-round19-astra-independent-frozen/astra-r19-baseline04-analysis.json",
        "ca1779eb9fb4fbb4398f226395904cfbaa29c3be3bbe1bd002e8cb145b00a3db",
    ),
}
data = {}
for peer, (name, digest) in INPUTS.items():
    raw = (BASE / name).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == digest
    data[peer] = json.loads(raw)
    assert data[peer]["receipt_sha256"] == "00fb93ff8e5d8afd3eb06e23b2e4e1b77ffb7917e31a52e11072ca9159155694"

opus, astra = data["opus"], data["astra"]
assert opus["protocol_sha256"] == astra["protocol_sha256"]
assert set(opus["episodes"]) == set(astra["episodes"])
assert len(opus["episodes"]) == 80
fields = (
    "offered", "complete", "rejected", "natural_eos", "capped",
    "natural_cohort_good", "natural_in_window_good",
)
matched = {}
for episode_id, left in opus["episodes"].items():
    right = astra["episodes"][episode_id]
    assert (left["seed"], left["cell"], left["policy"]) == (
        right["seed"], right["cell"], right["policy"])
    assert right["offered_seconds"] == 120
    assert left["summary"]["other"] == 0
    assert set(right["fates"]) <= {"complete", "rejected"}
    assert sum(right["fates"].values()) == right["counts"]["offered"]
    for field in fields:
        assert left["summary"][field] == right["counts"][field], (episode_id, field)
    matched[episode_id] = {field: right["counts"][field] for field in fields}

seeds = sorted({row["seed"] for row in opus["episodes"].values()})
assert seeds == astra["independent_seeds"] and len(seeds) == 4
contrasts = {}
for field in ("natural_cohort_good", "natural_in_window_good"):
    differences = []
    for seed in seeds:
        totals = {}
        for policy in ("fixed-cost32", "fixed-count32"):
            selected = [row for row in opus["episodes"].values()
                        if row["seed"] == seed and row["policy"] == policy]
            assert len(selected) == 5
            totals[policy] = sum(row["summary"][field] for row in selected)
        differences.append(totals["fixed-cost32"] - totals["fixed-count32"])
    contrasts[field] = {
        "cost32_minus_count32_by_seed": differences,
        "positive_seeds": sum(value > 0 for value in differences),
        "negative_seeds": sum(value < 0 for value in differences),
        "offered_seconds_per_policy_seed": 600,
    }

assert contrasts["natural_cohort_good"]["cost32_minus_count32_by_seed"] == [-19, 25, 62, 74]
assert contrasts["natural_in_window_good"]["cost32_minus_count32_by_seed"] == [-27, 17, 60, 70]
result = {
    "schema": "r19-two-independent-estimands-reconciled-v1",
    "input_sha256": {peer: pair[1] for peer, pair in INPUTS.items()},
    "verified_episodes": 80,
    "matched_fields": list(fields),
    "matched_episode_counts": matched,
    "contrast_estimands": contrasts,
    "explanation": "Cohort SLO successes and successes terminal within the offered window are distinct estimands; both independently reported counts agree for all 80 episodes.",
    "independent_units": "Four seed blocks, not requests or cells.",
    "all_four_model_consensus_complete": False,
    "mpc_superiority_claim": False,
}
output = BASE / "pr33-native-v3-round19-two-peer-metric-reconciliation.json"
with output.open("x") as stream:
    stream.write(json.dumps(result, indent=2) + "\n")
print("All 80 episodes match on all seven shared counts; both distinct estimands reconciled.")
print(json.dumps(contrasts, indent=2))
