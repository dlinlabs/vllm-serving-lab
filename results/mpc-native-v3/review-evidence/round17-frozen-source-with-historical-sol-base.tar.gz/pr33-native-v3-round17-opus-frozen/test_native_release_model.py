"""Focused contract tests for native_release_model. Fixtures exercise accounting and
causality only; they are not native measurements or performance evidence."""
import copy
from collections import Counter, defaultdict
import hashlib
import json
import math
import random
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import native_release_model as m  # noqa: E402

DOMAIN, RUN, NATIVE_RUN, OBSERVER = "clock-a", "run-a", "native-a", "f" * 64


def _uuid(i):
    return f"{i:032x}"


def episode(requests, *, block=170001, partition="train", step=0.25, until=None,
            episode_id=None, ledger=True, grid=None):
    """requests: (index, cost, prompt, max_tokens, admit, first, release)."""
    events = sorted([(r[4], 1, r) for r in requests] + [(r[6], -1, r) for r in requests],
                    key=lambda e: (e[0], -e[1]))
    ledger_frames, live, reserved, seq = [], {}, 0.0, 0
    for at, sign, r in events:
        seq += 1
        if sign > 0:
            live[_uuid(r[0])] = r
            reserved += r[1]
        else:
            live.pop(_uuid(r[0]))
            reserved -= r[1]
        ledger_frames.append(dict(event="mpc_ledger", run_id=RUN, clock_domain=DOMAIN, complete=True,
                           sequence=seq, effective_at=at, reserved_cost=max(reserved, 0.0)))
    end = until if until is not None else max(e[0] for e in events) + 0.5
    observations, t = [], 0.0
    while t <= end + 1e-9:
        seq_t = sum(1 for e in events if e[0] <= t)
        alive = [e[2] for e in events[:seq_t] if e[1] > 0
                 and not any(x[1] < 0 and x[2] is e[2] for x in events[:seq_t])]
        marks = [dict(request_id=_uuid(r[0]), cost=r[1], prompt_tokens=r[2], max_tokens=r[3],
                      received_at=r[4], admitted_at=r[4],
                      first_at=r[5] if r[5] <= t else None, scheduled_at=None) for r in alive]
        native = dict(schema="pr33-native-read-only-v1", complete=True, sampled_at=t + 0.01,
                      frontend_sampled_at=t + 0.011, run_id=NATIVE_RUN, clock_domain=DOMAIN,
                      observer_sha256=OBSERVER, running=len(alive), waiting=0,
                      pending_batches=0, kv_cache_usage=0.0,
                      requests=[dict(request_id=f"chatcmpl-{_uuid(r[0])}-0000abcd",
                                     prompt_tokens=r[2], maximum_output_tokens=r[3],
                                     output_tokens=min(r[3], max(0, int((t - r[5]) * 50))))
                                for r in alive])
        observations.append(dict(
            gateway=dict(run_id=RUN, clock_domain=DOMAIN, complete=True, sequence=seq_t,
                         sampled_at=t, budget=16.0, requests=marks),
            received_at=t + 0.005, native=native, native_received_at=t + 0.02))
        t += step
    return dict(episode_id=episode_id or f"ep-{block}-{partition}", seed_block=block,
                partition=partition, clock_domain=DOMAIN, run_id=RUN,
                native_run_id=NATIVE_RUN, observer_sha256=OBSERVER,
                origin_grid_s=step if grid is None else grid,
                observations=observations, ledger=ledger_frames if ledger else None)


def random_requests(seed, n=24):
    rng = random.Random(seed)
    out, t = [], 0.0
    for i in range(n):
        t += rng.uniform(0.1, 0.6)
        prompt = rng.choice((128, 4096))
        first = t + (0.05 if prompt == 128 else 0.3)
        out.append((seed * 1000 + i, 1.0 + 0.5 * (prompt == 4096), prompt, 128, t, first,
                    first + rng.uniform(0.5, 6.0)))
    return out


def test_truth_is_exact_for_distinct_costs_and_counts_observation_lag():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.30), (2, 2.0, 128, 128, 0.0, 0.1, 2.6)])
    rows = m.build_dataset([ep])
    origin = rows[0]                       # sampled 0.0, t0 0.02
    assert origin["reserved"] == 3.0
    assert origin["truth"][1.0] == (1.0, 1.0)
    assert origin["truth"][3.0] == (3.0, 3.0)
    late = next(o for o in rows if o["sampled_at"] == 0.25)
    # release at 0.30 happens after sampling but before t0+1 and is counted.
    assert late["truth"][1.0] == (1.0, 1.0)


def test_tied_costs_with_noncohort_release_yield_bounds_not_guesses():
    # Cohort mark 1 and non-cohort mark 3 (same cost) both release between snapshots.
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.05, 1.10), (2, 1.5, 128, 128, 0.0, 0.05, 4.0),
                  (3, 1.0, 128, 128, 1.01, 1.02, 1.05)], step=0.5)
    rows = m.build_dataset([ep])
    origin = next(o for o in rows if o["sampled_at"] == 0.0)
    # target 1.02+ ... t0=0.02 so h=1 target=1.02: neither 1.05 nor 1.10 released yet.
    assert origin["truth"][1.0] == (0.0, 0.0)
    mid = next(o for o in rows if o["sampled_at"] == 0.5 and _uuid(1) in o["cohort"])
    mid["t0"] = 0.5
    groups, unresolved = m.release_groups(mid, *_parsed_and_releases(ep))
    lo, hi = m.cumulative_truth(mid, groups, unresolved, 6.0, 0.57)  # target 1.07
    assert (lo, hi) == (0.0, 1.0)
    assert m.mark_label(_uuid(1), groups, unresolved, 6.0, 1.07) is None
    assert m.mark_label(_uuid(1), groups, unresolved, 6.0, 1.2) == 1


def _parsed_and_releases(ep):
    _, parsed, _ = m.build_origins(ep)
    releases, _ = m.ledger_releases(ep, parsed)
    return parsed, releases


def _raises(fn, text):
    try:
        fn()
    except ValueError as error:
        assert text in str(error), error
    else:
        raise AssertionError("expected ValueError " + text)


def test_ledger_gap_and_snapshot_mismatch_are_rejected():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.6), (2, 2.0, 128, 128, 0.1, 0.2, 1.1)])
    gap = copy.deepcopy(ep)
    del gap["ledger"][2]
    _raises(lambda: m.build_dataset([gap]), "ledger_identity_or_gap")
    bad = copy.deepcopy(ep)
    bad["ledger"][1]["reserved_cost"] = 5.0
    _raises(lambda: m.build_dataset([bad]), "snapshot_ledger_mismatch")


def test_final_heldout_and_partition_leakage_are_refused():
    reqs = [(1, 1.0, 128, 128, 0.0, 0.1, 0.6)]
    _raises(lambda: m.build_dataset([episode(reqs, block=160022)]), "final_heldout_reserved")
    _raises(lambda: m.build_dataset([episode(reqs, block=170001, episode_id="a"),
                                     episode(reqs, block=170001, partition="development",
                                             episode_id="b")]),
            "seed_block_partition_leakage")
    rows = m.build_dataset([episode(reqs, partition="calibration")])
    _raises(lambda: m.fit(rows), "fit_requires_train_only")


def test_unjoined_native_frame_is_rejected_and_stale_grid_points_abstain():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.6)])
    alien = copy.deepcopy(ep)
    alien["observations"][1]["native"]["requests"] = [
        dict(request_id=f"chatcmpl-{_uuid(99)}-0000abcd", output_tokens=0, prompt_tokens=128,
             maximum_output_tokens=128)]
    alien["observations"][1]["native"]["running"] = 1
    origins, _, stats = m.build_origins(alien)
    assert stats["rejected_native_frames"] == {"native_unjoined_or_ambiguous": 1}
    assert all(o["index"] != 1 for o in origins)
    stale = copy.deepcopy(ep)
    for obs in stale["observations"][1:3]:
        obs["native"] = None
    origins, _, stats = m.build_origins(stale)
    assert stats["stale_grid_points"] == 1                # grid 0.52 would reuse sample 0.0
    noncausal = copy.deepcopy(ep)
    noncausal["observations"][0]["native_received_at"] = noncausal["observations"][0]["received_at"] - 0.01
    _raises(lambda: m.build_dataset([noncausal]), "observation_stale_or_noncausal")


def test_features_do_not_depend_on_future_observations():
    ep = episode(random_requests(3))
    base = m.build_origins(ep)[0][8]
    future = copy.deepcopy(ep)
    for obs in future["observations"][9:]:
        for request in obs["native"]["requests"]:
            request["output_tokens"] = 0
    changed = m.build_origins(future)[0][8]
    for rid in base["cohort"]:
        for h in m.HORIZONS:
            assert m.mark_features(base, rid, h) == m.mark_features(changed, rid, h)


def test_end_to_end_train_only_fit_calibration_and_ood_abstention():
    episodes = [episode(random_requests(s), block=170000 + s, partition=p)
                for s, p in ((1, "train"), (2, "train"), (3, "train"), (4, "calibration"),
                             (5, "development"))]
    unseen = episode([(9001, 1.0, 999, 64, 0.0, 0.1, 3.0)], block=170099,
                     partition="development", episode_id="ood")
    result = m.evaluate(episodes + [unseen])
    assert result["train_blocks"] == [170001, 170002, 170003]
    dev = result["scores"]["development"]
    assert set(dev["models"]) == {"train_fraction", "fluid_history", "batch_aware"}
    assert dev["counts"]["ood_joint_work_mix"] >= 1
    assert set(dev["models"]["batch_aware"]["blocks"]) == {170005}
    assert result["calibration"]["blocks"] == [170004]
    assert set(result["development_coverage"]) == {170005}
    assert not result["native_performance_accepted"] and not result["statistical_guarantee"]
    rows = m.build_dataset(episodes[:3])
    params = m.fit(rows)
    for origin in rows:
        pred, _ = m.predict(params, origin)
        if pred:
            values = [pred["batch_aware"][h] for h in m.HORIZONS]
            assert values == sorted(values) and values[-1] <= origin["reserved"] + 1e-9


def _baseline_4096_32(tail_start_offset=-0.001, extra_tail=0, drop=None):
    rid, steps, rows, t = "r", [], [], 0.0
    work = [(0, 2048), (2048, 2048)] + [(4096 + i, 1) for i in range(32 + extra_tail)]
    for i, (pos, n) in enumerate(work):
        if drop == i:
            continue
        steps.append(dict(step_id=f"s{i}", start=t, end=t + 0.01,
                          work=[dict(request_id=rid, position=pos, tokens=n)]))
        rows.append(dict(step_id=f"s{i}", executed_positions={rid: pos}, executed_counts={rid: n}))
        t += 0.01
    finished = steps[-1]["start"] - tail_start_offset
    request = dict(input_tokens=4096, output_tokens=32, finish_reason="stop", finished=finished)
    return m.forward_work_accounting(request, steps, rows, request_id=rid)


def test_tail_accounting_keeps_legacy_audit_false_and_explains_one_prefinish_position():
    report = _baseline_4096_32()
    assert (report["useful_positions"], report["physical_positions"], report["tail_positions"]) \
        == (4127, 4128, 1)
    assert (report["useful_steps"], report["tail_steps"]) == (33, 1)
    assert report["legacy_strict_audit_valid"] is False
    assert report["tail_accounted"] is True


def test_tail_accounting_falsifiers():
    assert "tail_scheduled_after_finish" in _baseline_4096_32(tail_start_offset=0.001)["problems"]
    assert "unexplained_tail_work" in _baseline_4096_32(extra_tail=1)["problems"]
    assert "position_gap_repeat_or_split" in _baseline_4096_32(drop=5)["problems"]
    assert not _baseline_4096_32(extra_tail=1)["tail_accounted"]
    late_commit = _baseline_4096_32(tail_start_offset=-0.02)   # start < finish, end < finish
    assert "tail_commit_before_finish" in late_commit["problems"]
    assert not late_commit["tail_accounted"]


# ---------------------------------------------------------------------------
# Round 2: reproducible counterexamples against the frozen peer R1 bytes.
# NV3_PEER_ROOT points at Mayor's byte-verified freeze; absent files => skipped.
# ---------------------------------------------------------------------------
import importlib.util  # noqa: E402
import os  # noqa: E402

PEER_ROOT = Path(os.environ.get("NV3_PEER_ROOT", "/home/daniel_lin/.copilot/session-state/"
                 "73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-round1-frozen"))
PEER_FILES = dict(
    gemini=("gemini/native_campaign_protocol.py",
            "087c68868f48f6bac9d1ac829c9dc3cb8b749f1c40b87f6d5364bb2d2f4bad79"),
    sol=("sol/experiments/mpc-research/native-v3/native_experiment_audit.py",
         "6abb94a4fbc1f3e238cd2d4687e996829304afe669b38efba14f2ca29074a554"),
)


class Skip(Exception):
    pass


def _peer(name):
    import hashlib
    rel, sha = PEER_FILES[name]
    path = PEER_ROOT / rel
    if not path.exists():
        raise Skip(f"frozen {name} bytes unavailable")
    assert hashlib.sha256(path.read_bytes()).hexdigest() == sha, "peer bytes are not the R1 freeze"
    spec = importlib.util.spec_from_file_location(f"nv3_peer_{name}", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def test_peer_gemini_work_accounting_hides_missing_and_invents_tail_cause():
    g = _peer("gemini")
    short = g.compute_work_accounting(worker_forward_end_position=4100)
    assert short.tail_work_tokens == 0          # 27 missing useful positions clamped away, no error
    long = g.compute_work_accounting(worker_forward_end_position=4200)
    assert long.tail_work_tokens == 73 and "placeholder 1" in long.tail_work_cause
    base = g.compute_work_accounting()
    assert base.physical_executed_positions == base.useful_total_tokens + 1 == 4129  # off-by-one units


def test_peer_gemini_superiority_accepts_one_block_relabelled_six_times():
    g = _peer("gemini")
    blocks = [g.IndependentSeedBlockOutcome(
        block_id=f"clone-{i}", seed=900 + i, workload_family="x", split="final", duration_s=90.0,
        control_decisions=90, offered_requests=500, policy_a_good_completions=300,
        policy_a_rejections=10, policy_a_solver_overruns=0,
        policy_b_good_completions=360 + (i % 2), policy_b_rejections=10,
        policy_b_solver_overruns=0) for i in range(6)]
    assert g.SuperiorityEvaluator().evaluate(blocks)["verdict"] == "CONFIRMED_SUPERIOR"


def test_peer_gemini_protocol_counts_planned_drain_and_trains_on_its_ood_family():
    g = _peer("gemini")
    protocol = g.build_native_campaign_protocol()
    summary = protocol["duration_summary"]
    assert summary["hours_requirement_satisfied"] is True
    assert summary["total_active_and_drain_seconds"] == summary["total_episodes"] * (90 + 30)
    ood_train = [b for b in protocol["groups"].values()
                 if b["family"] == "unseen_ood_mix" and b["split"] == "train"]
    assert len(ood_train) == 10
    mixed = protocol["groups"][next(k for k, v in protocol["groups"].items()
                                    if v["family"] == "mixed_short_long")]
    assert mixed["prompt_tokens"] == 2048       # declared 80/20 p128/p4096 mix is not represented


def test_peer_gemini_empty_origin_and_missing_horizon_score_as_zero_error():
    g = _peer("gemini")
    empty = g.compute_normalized_absolute_error({}, {}, 0.0)
    assert empty["mean_normalized_absolute_error"] == 0.0
    missing = g.compute_normalized_absolute_error({1: 0.0, 3: 0.0, 5: 0.0}, {}, 10.0)
    assert missing["mean_normalized_absolute_error"] == 0.0   # absent labels become perfect


def test_peer_gemini_one_move_ignores_its_continuation():
    g = _peer("gemini")
    state = g.ObservableBatchState()
    assert all(g.StrongOneMoveController(c).decide(state, q) ==
               g.StrongOneMoveController(48.0 - c).decide(state, q)
               for c in (16.0, 32.0) for q in range(10))


def test_peer_sol_censored_upper_bound_ignores_elapsed_ttft_deadline():
    sol = _peer("sol")
    rid = "a" * 32
    offer = dict(request_id=rid, logical_id="l0", offset_s=0.0, prompt_sha256="b" * 64,
                 prompt_tokens=128, max_tokens=128)
    row = dict(request_id=rid, requested_max_tokens=128, clock_domain="c", scheduled_at=10.0,
               status="censored", sent_at=10.0, first_content_at=None, last_content_at=None,
               terminal_at=None, stream_done=False, observed_until=40.0)
    result = sol.audit_arm([offer], [row], origin=10.0, window_s=5.0, clock_domain="c")
    # No first content after 30s, so TTFT<=0.5s is already impossible; upper should be 0.
    assert result["good_upper"] == 1



# ---------------------------------------------------------------------------
# Round 3: regressions for peer witnesses O1-O7 against this module's R1/R2 bytes.
# ---------------------------------------------------------------------------

def test_r3_o1_foreign_native_run_clock_or_observer_is_not_joined():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.6)])
    for key, value in (("run_id", "native-b"), ("clock_domain", "clock-b"),
                       ("observer_sha256", "0" * 64)):
        bad = copy.deepcopy(ep)
        bad["observations"][1]["native"][key] = value
        origins, _, stats = m.build_origins(bad)
        assert stats["rejected_native_frames"] == {"native_source_or_clock": 1}, key
        assert all(o["index"] != 1 for o in origins)
    wide = copy.deepcopy(ep)
    wide["observations"][1]["native"]["frontend_sampled_at"] += 0.2
    assert m.build_origins(wide)[2]["rejected_native_frames"] == {"native_frame_time": 1}


def test_r3_o2_retroactive_and_negative_ledger_release_is_rejected():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.6), (2, 2.0, 128, 128, 0.1, 0.2, 1.1)])
    # Astra: release recorded after the 0.5 snapshot but effective before it.
    retro = copy.deepcopy(ep)
    frame = next(f for f in retro["ledger"] if f["effective_at"] == 0.6)
    frame["effective_at"] = 0.45
    _raises(lambda: m.build_dataset([retro]), "ledger_snapshot_chronology")
    # Sol: an effective_at far in the past.
    negative = copy.deepcopy(ep)
    negative["ledger"][-1]["effective_at"] = -100.0
    _raises(lambda: m.build_dataset([negative]), "ledger_chronology")


def test_r3_o3_plan_order_is_encoded_and_off_grid_plans_are_refused():
    a = [(0.0, 16.0), (1.0, 16.0), (2.0, 32.0), (3.0, 16.0)]
    b = [(0.0, 16.0), (1.0, 32.0), (2.0, 16.0), (3.0, 16.0)]
    fa, fb = m.plan_features(a, 0.5, 5.0, 16.0), m.plan_features(b, 0.5, 5.0, 16.0)
    assert fa != fb and sum(fa[1:]) == sum(fb[1:])          # same average, different order
    assert fa == (0.5, 16.0, 16.0, 32.0, 16.0, 16.0, 16.0)
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.6)])
    ep["cap_plan"] = [(0.0, 16.0), (0.5, 32.0), (1.0, 16.0)]
    _raises(lambda: m.build_origins(ep), "cap_plan_off_slot_grid")


def _cal_rows(block, residuals):
    return [dict(partition="calibration", seed_block=block, episode_id=f"e{block}", t0=float(i),
                 reserved=1.0, truth={h: (r, r) for h in m.HORIZONS})
            for i, r in enumerate(residuals)]


def test_r3_o4_calibration_is_block_level_and_ignores_duplicated_origins():
    original = m.predict
    m.predict = lambda params, o: ({"batch_aware": {h: 0.0 for h in m.HORIZONS}}, [])
    try:
        # Astra: 100 zero-residual origins in one block cannot erase another block's 1.
        astra = _cal_rows(1, [0.0] * 100) + _cal_rows(2, [1.0])
        assert m.calibrate({}, astra)["bands"][1.0]["upper"] == 1.0
        # Sol: duplicating origins cannot move the lower band.
        rows = _cal_rows(3, [-0.5, 0.5])
        base = m.calibrate({}, rows)
        dup = m.calibrate({}, rows + [copy.deepcopy(rows[1]) for _ in range(50)])
        assert base["bands"] == dup["bands"] and base["bands"][1.0]["lower"] == -0.5
    finally:
        m.predict = original


def test_r3_o4_origin_grid_is_invariant_to_duplicated_observations():
    ep = episode(random_requests(5), grid=0.5)
    doubled = copy.deepcopy(ep)
    doubled["observations"] = [copy.deepcopy(o) for o in ep["observations"] for _ in (0, 1)]
    a, b = m.build_dataset([ep]), m.build_dataset([doubled])
    assert [o["t0"] for o in a] == [o["t0"] for o in b]
    for x, y in zip(a, b):
        assert x["truth"] == y["truth"]
        for rid in x["cohort"]:
            assert [m.mark_features(x, rid, h) for h in m.HORIZONS] == \
                   [m.mark_features(y, rid, h) for h in m.HORIZONS]


def test_r3_o5_age_history_and_joint_mixture_leave_support():
    short = [(s * 100 + i, 1.0, 128, 128, 0.3 * i, 0.3 * i + 0.05, 0.3 * i + 1.5)
             for s in (1, 2) for i in range(8)]
    long = [(s * 100 + 50 + i, 1.5, 4096, 128, 0.3 * i, 0.3 * i + 0.3, 0.3 * i + 2.0)
            for s in (3, 4) for i in range(8)]
    train = m.build_dataset([episode([r for r in short if r[0] // 100 == s], block=170000 + s,
                                     episode_id=f"s{s}") for s in (1, 2)]
                            + [episode([r for r in long if r[0] // 100 == s], block=170000 + s,
                                       episode_id=f"l{s}") for s in (3, 4)])
    params = m.fit(train)
    mixed = m.build_dataset([episode([short[0], long[0]], block=170099, partition="development",
                                     episode_id="mix")])
    assert "joint_work_mix" in m.ood_reasons(mixed[0], params["support"])
    probe = copy.deepcopy(next(o for o in train if o["history_rate"] is not None))
    probe["history_rate"] = 10 * max(o["history_rate"] or 0.0 for o in train) + 1.0
    assert "range_history_rate" in m.ood_reasons(probe, params["support"])
    aged = copy.deepcopy(train[0])
    rid = next(iter(aged["cohort"]))
    aged["cohort"][rid] = dict(aged["cohort"][rid], admitted_at=aged["sampled_at"] - 600)
    assert "range_age_s" in m.ood_reasons(aged, params["support"])


def test_r3_o6_tail_flag_is_not_mechanism_or_authority_and_duplicates_fail():
    report = _baseline_4096_32()
    assert report["tail_accounted"] and not report["tail_mechanism_evidenced"]
    assert report["native_qualification_authority"] is False
    rid, steps, rows, t = "r", [], [], 0.0
    for i, (pos, n) in enumerate([(0, 2048), (2048, 2048)] + [(4096 + j, 1) for j in range(32)]):
        steps.append(dict(step_id=f"s{i}", start=t, end=t + 0.01,
                          work=[dict(request_id=rid, position=pos, tokens=n)]))
        rows.append(dict(step_id=f"s{i}", executed_positions={rid: pos}, executed_counts={rid: n}))
        t += 0.01
    finished = steps[-1]["start"] + 0.001
    evidence = dict(placeholder_tokens=1, cuda_completed=True, delivered_output_from_step=False,
                    output_commit_at=finished + 0.005)
    request = dict(input_tokens=4096, output_tokens=32, finish_reason="stop", finished=finished,
                   tail_evidence=evidence)
    full = m.forward_work_accounting(request, steps, rows, request_id=rid)
    assert full["tail_mechanism_evidenced"] and full["native_qualification_authority"] is False
    dup = m.forward_work_accounting(request, steps, rows + [dict(rows[-1])], request_id=rid)
    assert "duplicate_worker_step" in dup["problems"] and not dup["tail_accounted"]


def test_r3_o7_interval_labels_are_not_selected_and_fraction_is_monotone():
    # Snapshot brackets straddling t0+h create interval truth; no origin may be dropped.
    rows = m.build_dataset([episode(random_requests(7), step=0.5, grid=0.25, ledger=False)])
    assert any(o["truth"][h][0] < o["truth"][h][1] for o in rows for h in m.HORIZONS)
    params = m.fit(rows, sensitivity=True)
    fractions = [params["fraction"][h] for h in m.HORIZONS]
    assert fractions == sorted(fractions)
    for h in m.HORIZONS:
        lo, hi = params["fraction_bounds"][h]
        assert lo <= params["fraction"][h] <= hi
        assert params["label_counts"][h]["marks"] == sum(len(o["cohort"]) for o in rows)


def test_r3_snapshot_bracket_truth_without_ledger():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.30), (2, 2.0, 128, 128, 0.0, 0.1, 2.6)],
                 ledger=False)
    origin = m.build_dataset([ep])[0]
    assert origin["truth_source"] == "snapshot_bracket"
    assert origin["truth"][1.0] == (1.0, 1.0) and origin["truth"][3.0] == (3.0, 3.0)
    assert (m.bracket_label((0.25, 0.5), 0.4), m.bracket_label((0.25, 0.5), 0.5),
            m.bracket_label((0.25, 0.5), 0.25)) == (None, 1, 0)
    reappear = copy.deepcopy(ep)
    reappear["observations"][3]["gateway"]["requests"].append(
        copy.deepcopy(ep["observations"][0]["gateway"]["requests"][0]))
    reappear["observations"][3]["native"] = None
    _raises(lambda: m.build_dataset([reappear]), "mark_reappeared")


def test_r3_unconverged_fit_abstains_and_single_class_horizon_is_flagged():
    rows = m.build_dataset([episode(random_requests(s), block=170000 + s, episode_id=f"e{s}")
                            for s in (1, 2)])
    params = m.fit(rows)
    origin = next(o for o in rows if m.predict(params, o)[0] is not None)
    broken = copy.deepcopy(params)
    broken["logistic"][3.0]["converged"] = False
    assert "fit_not_converged" in m.predict(broken, origin)[1]
    constant = m._fit_or_constant([(0.0,), (1.0,)], [1, 1], [1.0, 1.0])
    assert constant["degenerate"] and constant["constant"] == 1.0
    assert all("degenerate" in params["logistic"][h] for h in m.HORIZONS)



def _with_actions(applied_at=1.6, planned_at=1.0):
    ep = episode(random_requests(4), grid=0.25)
    ep["actions"] = [dict(planned_at=None, budget=16.0, budget_version=1, applied_at=-1.0,
                          ack_received_at=-0.99, attempts=1),
                     dict(planned_at=planned_at, budget=16.0, budget_version=2,
                          applied_at=applied_at, ack_received_at=applied_at + 0.02, attempts=2)]
    for obs in ep["observations"]:
        obs["gateway"]["budget_version"] = 1 if obs["gateway"]["sampled_at"] < applied_at else 2
    return ep


def test_r3b_cut_precedes_ack_and_outstanding_command_abstains():
    ep = _with_actions()
    origins, _, stats = m.build_origins(ep)
    assert stats["rejected_native_frames"] == {}
    late = [round(o["t0"], 6) for o in origins if o["outstanding_actions"]]
    assert late == [1.02, 1.27, 1.52]      # sent at 1.0, ACK received 1.62: knowable online
    rows = m.build_dataset([ep, episode(random_requests(5), block=170005, episode_id="b")])
    params = m.fit(rows)
    origin = next(o for o in rows if o["outstanding_actions"])
    assert "outstanding_action_at_cut" in m.predict(params, origin)[1]
    _raises(lambda: m.build_origins(_with_actions(applied_at=1.01, planned_at=1.02)),
            "cut_after_action_ack")


def test_r3b_snapshot_budget_must_match_ack_in_force():
    ep = _with_actions()
    ep["observations"][2]["gateway"]["budget_version"] = 2      # sampled 0.5, ACK v2 at 1.6
    assert m.build_origins(ep)[2]["rejected_native_frames"] == {"gateway_budget_provenance": 1}

REPLICA = Path(os.environ.get("NV3_REPLICA", "/home/daniel_lin/.copilot/session-state/"
               "73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-long01-replica"))


def test_r3_actual_replica_adapter_reproduces_reference_join_counts():
    name = "nv3-181001-p128-m128-arm0.json"
    if not (REPLICA / name).exists():
        raise Skip("read-only native replica unavailable")
    import json
    index = json.loads((REPLICA / "latest-index.json").read_text())
    listed = {json.loads(line)["artifact"]: json.loads(line)["sha256"]
              for line in (REPLICA / "verified-artifact-sha256.jsonl").read_text().splitlines()
              if line.strip()}
    import hashlib
    assert hashlib.sha256((REPLICA / name).read_bytes()).hexdigest() == listed[name]
    ep = m.episode_from_replica(json.loads((REPLICA / name).read_text()), index)
    _, _, stats = m.build_origins(ep)
    assert (stats["joined_frames"], stats["joined_frame_marks_not_native_visible"],
            stats["joined_frame_marks"]) == (765, 3034, 13280)
    assert stats["rejected_native_frames"] == {}
    final = dict(json.loads((REPLICA / name).read_text()), seed_block=160021)
    _raises(lambda: m.episode_from_replica(final, index), "replica_seed_block_not_train")


# ---------------------------------------------------------------------------
# R4: short-step joint transition candidate (nv3-opus-joint-transition-v1)
# ---------------------------------------------------------------------------

def joint_episode(requests, rejected=(), block=170001, episode_id=None, duration=4.0):
    """requests as episode(); rejected: (index, sent_at). Client rows are fixtures."""
    ep = episode(requests, block=block, episode_id=episode_id, until=duration + 0.5)
    rows = [dict(request_id=_uuid(r[0]), clock_domain=DOMAIN, scheduled_at=r[4] - 0.002,
                 sent_at=r[4] - 0.001, first_content_at=r[5], terminal_at=r[6], status="complete",
                 finish_reason="stop", admission_rejection=False,
                 usage=dict(completion_tokens=50)) for r in requests]
    rows += [dict(request_id=_uuid(i), clock_domain=DOMAIN, scheduled_at=t - 0.001, sent_at=t,
                  first_content_at=None, terminal_at=t + 0.01, status="rejected",
                  finish_reason=None, admission_rejection=True, usage=None) for i, t in rejected]
    ep.update(start=0.0, duration_s=duration, cell="fixture", client_rows=rows,
              expected_ids=[r["request_id"] for r in rows])
    return ep


def test_r4_stock_flow_identity_and_receipt_labels():
    ep = joint_episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.7), (2, 2.0, 128, 128, 0.6, 0.65, 3.0)],
                       rejected=[(3, 0.8)])
    steps, good = m.joint_steps(ep)
    by_k = {s["k"]: s for s in steps}
    labelled = [s for s in steps if s["labels"]]
    for s in labelled:
        nxt, y = by_k[s["k"] + 1]["gateway"], s["labels"]
        assert abs(nxt["reserved"] - (s["gateway"]["reserved"] - y["released_cost"]
                                      + y["born_cost"])) < 1e-9
        assert y["offers"] >= y["admitted"]
    totals = {c: sum(s["labels"][c] for s in labelled) for c in m.CLIENT_KINDS}
    assert (totals["rejected"], totals["good"], totals["ttft_miss"]) == (1, 2, 0)
    assert [rid for _, rid in good] == [_uuid(1), _uuid(2)]


def test_r4_counterexample_marginal_release_cannot_be_goodput_kernel():
    """Identical original cohort at the cut => identical R3 marginal features, yet past
    offered/rejected receipts and future births differ, and so does future good."""
    base = [(1, 1.0, 128, 128, 0.0, 0.1, 2.0)]
    a = joint_episode(base, episode_id="a")
    b = joint_episode(base + [(2, 1.0, 128, 128, 1.6, 1.7, 1.9)], rejected=[(8, 0.3), (9, 0.35)],
                      episode_id="b")
    ra = {o["t0"]: o for o in m.build_origins(dict(a, origin_grid_s=0.5, origin_grid_start=0.0))[0]}
    rb = {o["t0"]: o for o in m.build_origins(dict(b, origin_grid_s=0.5, origin_grid_start=0.0))[0]}
    oa, ob = ra[1.0], rb[1.0]
    assert set(oa["cohort"]) == set(ob["cohort"]) == {_uuid(1)}
    assert all(m.mark_features(oa, _uuid(1), h) == m.mark_features(ob, _uuid(1), h)
               for h in m.HORIZONS)
    ja = next(s for s in m.joint_steps(a)[0] if s["t0"] == 1.0)
    jb = next(s for s in m.joint_steps(b)[0] if s["t0"] == 1.0)
    assert (ja["gateway"]["hist_offers"], jb["gateway"]["hist_offers"]) == (1.0, 3.0)
    assert (ja["gateway"]["hist_rejected"], jb["gateway"]["hist_rejected"]) == (0.0, 2.0)
    future = lambda ep: sum(1 for t, _ in m.joint_steps(ep)[1] if 1.0 < t <= 3.0)
    assert (future(a), future(b)) == (1, 2)


def test_r4_client_fencing_and_snapshot_consistency():
    ep = joint_episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.7)], rejected=[(3, 0.8)])
    foreign = copy.deepcopy(ep)
    foreign["client_rows"][0]["clock_domain"] = "clock-b"
    _raises(lambda: m.joint_steps(foreign), "client_row_identity_or_clock")
    missing = copy.deepcopy(ep)
    missing["client_rows"].pop()
    _raises(lambda: m.joint_steps(missing), "client_rows_incomplete")
    contradict = copy.deepcopy(ep)
    row = contradict["client_rows"][0]
    row.update(status="rejected", admission_rejection=True, first_content_at=None,
               finish_reason=None, usage=None)
    _raises(lambda: m.joint_steps(contradict), "snapshot_client_inconsistent")


def test_r4_features_and_rollout_ignore_future_receipts():
    reqs = random_requests(11, n=16)
    ep = joint_episode(reqs, rejected=[(900 + i, 0.2 + 0.4 * i) for i in range(8)], duration=6.0)
    k0 = next(s for s in m.joint_steps(ep)[0] if s["t0"] == 2.0)
    later = copy.deepcopy(ep)
    for row in later["client_rows"]:
        if row["admission_rejection"] and row["sent_at"] > 2.0:
            row["sent_at"] = row["scheduled_at"] = 5.9
            row["terminal_at"] = 5.95
    k1 = next(s for s in m.joint_steps(later)[0] if s["t0"] == 2.0)
    assert k0["gateway"] == k1["gateway"] and k0["hist_steps"] == k1["hist_steps"]
    model = dict(mean=[0.0] * len(m.GATEWAY_FEATURES), scale=[1.0] * len(m.GATEWAY_FEATURES),
                 betas={t: [0.1] + [0.0] * len(m.GATEWAY_FEATURES) for t in m.TARGETS})
    runs = [[{t: 0.0 for t in m.TARGETS}] * m.ROLLOUT_STEPS]
    assert m._rollout(model, k0, runs, random.Random(1), 4) == \
        m._rollout(model, k1, runs, random.Random(1), 4)


def test_r4_crossfit_is_train_only_block_grouped_and_unqualified():
    eps = [joint_episode(random_requests(s, n=30), rejected=[(5000 + s * 10 + i, 0.3 + i)
                                                             for i in range(5)],
                         block=170000 + s // 2, episode_id=f"j{s}", duration=8.0)
           for s in (2, 3, 4, 5)]
    out = m.joint_crossfit(eps)
    assert sorted(out["folds"]) == ["170001", "170002"]
    for held, fold in out["folds"].items():
        assert int(held) not in fold["train_blocks"]
    assert not (out["calibration_result"] or out["mpc_result"] or out["statistical_guarantee"])
    assert out["marginal_release_model_is_joint"] is False and "unqualified" in out["scenario_status"]
    cal = copy.deepcopy(eps)
    cal[0]["partition"] = "calibration"
    _raises(lambda: m.joint_crossfit(cal), "joint_requires_train_only")
    _raises(lambda: m.joint_crossfit(eps[:2]), "crossfit_needs_two_blocks")


def test_r4_actual_replica_joint_steps_are_consistent():
    name = "nv3-181001-p128-m128-arm0.json"
    if not (REPLICA / name).exists():
        raise Skip("read-only native replica unavailable")
    import json
    index = json.loads((REPLICA / "latest-index.json").read_text())
    document = json.loads((REPLICA / name).read_text())
    steps, good = m.joint_steps(m.episode_from_replica(document, index))
    assert len(good) == document["summary"]["natural_cohort_good"] == 2540
    by_k = {s["k"]: s for s in steps}
    labelled = [s for s in steps if s["labels"]]
    assert len(labelled) >= 230
    for s in labelled:
        y = s["labels"]
        assert abs(by_k[s["k"] + 1]["gateway"]["reserved"]
                   - (s["gateway"]["reserved"] - y["released_cost"] + y["born_cost"])) < 1e-6
    assert sum(s["labels"]["offers"] for s in labelled) <= document["summary"]["offered"]


# ---------------------------------------------------------------------------
# R5: exogenous common arrival law (nv3-opus-exogenous-arrival-v2)
# ---------------------------------------------------------------------------

def _r5_step():
    reqs = random_requests(11, n=16)
    ep = joint_episode(reqs, rejected=[(900 + i, 0.2 + 0.4 * i) for i in range(8)], duration=6.0)
    return next(s for s in m.joint_steps(ep)[0] if s["t0"] == 2.0)


def test_r5_arrival_path_is_independent_of_candidate_plan_and_state():
    step = _r5_step()
    k = len(m.GATEWAY_FEATURES)
    model = dict(mean=[0.0] * (k + 1), scale=[1.0] * (k + 1),
                 betas={t: [0.0] * (k + 1) + [0.5] for t in m.TARGETS})
    model["betas"]["born_cost"] = [0.0] * (k + 1) + [3.0]
    model["betas"]["offers"] = [0.0, 1.0] + [0.0] * k  # would couple offers to reserved
    runs = [[{t: 0.1 * j for t in m.TARGETS} for j in range(m.ROLLOUT_STEPS)]]
    law = m.arrival_law(step)
    assert law == statistics.fmean(h["offers"] for h in step["hist_steps"])
    arrivals = lambda r, o: [max(0.0, law + r[o + j]["offers"]) for j in range(m.ROLLOUT_STEPS)]
    paths = {}
    for cap in (16.0, 32.0):
        alt = copy.deepcopy(step)
        alt["plan"] = [cap] * (m.ROLLOUT_STEPS + 1)
        alt["gateway"]["reserved"] += cap  # different state too
        paths[cap] = m._rollout(model, alt, runs, random.Random(3), m.ROLLOUT_STEPS, arrivals)
        assert m.arrival_law(alt) == law
    offers = {c: [[p[j]["offers"] for j in range(m.ROLLOUT_STEPS)] for p in ps]
              for c, ps in paths.items()}
    assert offers[16.0] == offers[32.0]
    assert [p[-1]["reserved"] for p in paths[16.0]] != [p[-1]["reserved"] for p in paths[32.0]]
    # v1 recursion lets the same coefficients move offers with state: the contract differs
    v1 = dict(mean=[0.0] * k, scale=[1.0] * k,
              betas={t: [0.0, 1.0] + [0.0] * (k - 1) for t in m.TARGETS})
    a, b = copy.deepcopy(step), copy.deepcopy(step)
    b["gateway"]["reserved"] += 8.0
    off = lambda st: m._rollout(v1, st, runs, random.Random(3), 2)[0][-1]["offers"]
    assert off(a) != off(b)


def test_r5_oracle_disturbance_is_separate_and_dev_block_gate_refuses_incomplete():
    eps = [joint_episode(random_requests(s, n=30), rejected=[(5000 + s * 10 + i, 0.3 + i)
                                                             for i in range(5)],
                         block=181000 + s // 2, episode_id=f"x{s}", duration=8.0)
           for s in (2, 3, 4, 5)]
    fresh = copy.deepcopy(eps[0])
    fresh.update(seed_block=181003, episode_id="fresh")
    out = m.exogenous_report(eps + [fresh], train_blocks=(181001, 181002))
    assert out["development"]["status"] == "not_run: incomplete"
    cross = out["cross_fit"]
    assert cross["exogenous_schema"] == m.EXO_VERSION and "independent of the candidate" \
        in cross["arrival_contract"] and "unqualified" in cross["exo_scenario_status"]
    assert sorted(cross["folds"]) == ["181001", "181002"]
    for fold in cross["folds"].values():
        oracle = fold["oracle_disturbance_diagnostic"]
        assert oracle["status"].startswith("ORACLE DISTURBANCE")
        assert all("oracle" not in name for name in fold["one_step_mae"])
        assert all("oracle" not in key for per in fold["free_running_mae"].values()
                   for key in per)
        assert oracle["one_step_mae"]["offers"] == 0.0
    base = m.joint_crossfit(eps)
    for held in base["folds"]:
        v1 = base["folds"][held]["free_running_mae"]
        v2 = cross["folds"][held]["free_running_mae"]
        assert all(v2[h][k] == v for h in v1 for k, v in v1[h].items())


# ---------------------------------------------------------------------------
# R6: ID-level progress hybrid (nv3-opus-progress-hybrid-v3)
# ---------------------------------------------------------------------------

def _r6_step(joined, running=4, waiting=0):
    return dict(t0=10.0, cell="c", joined=joined, cohort=set(joined) | {"u"},
                native=dict(running=running, waiting=waiting),
                gateway=dict(reserved=8.0, live=3.0))


def test_r6_counterexample_same_aggregate_state_different_progress_and_future_good():
    """Same Gateway aggregate (R, n, budget, history) -> any aggregate cohort model is
    forced to one prediction; per-ID TTFT/progress state makes future good differ."""
    step = _r6_step({"a": 100, "b": 100})
    ok = dict(scheduled=9.8, first=9.9, terminal=None)
    late = dict(scheduled=9.0, first=None, terminal=None)
    done = dict(scheduled=8.0, first=8.1, terminal=9.5)
    table = {(5.0, "c", True, True, 3, (0, False)): (40, 38),
             (5.0, "c", False, False): (40, 30), (5.0,): (100, 50)}
    rows_a = dict(a=ok, b=ok, u=dict(scheduled=9.9, first=None, terminal=None))
    rows_b = dict(a=late, b=late, u=done)
    prob = lambda rows: sum(m.progress_probability(table, 5.0, m.id_progress_state(step, r, rows[r]))[0]
                            for r in step["cohort"])
    assert abs(prob(rows_a) - (2 * 38 / 40 + 30 / 40)) < 1e-12
    assert prob(rows_b) == 0.0
    assert m.id_progress_state(step, "a", late) == "ttft_impossible"
    assert m.id_progress_state(step, "u", done) == "client_terminal"
    # a first content received after the cut is not used (no future receipt)
    future_first = dict(scheduled=9.8, first=10.3, terminal=None)
    assert m.id_progress_state(step, "a", future_first)[0][2] is False


def test_r6_hazard_fit_rejects_impossible_good_and_backs_off_declared_levels():
    keys = m.id_progress_state(_r6_step({"a": 3}), "a", dict(scheduled=9.8, first=9.9,
                                                              terminal=None))
    assert keys[0] == ("c", True, True, 1, (0, False))
    table = m.fit_progress_hazard([(1.0, keys, 1)] * 5 + [(1.0, keys, 0)] * 25)
    assert m.progress_probability(table, 1.0, keys) == (5 / 30, "level0")
    sparse = m.fit_progress_hazard([(1.0, keys, 1)] * 3)
    assert m.progress_probability(sparse, 1.0, keys) == (1.0, "level3")
    _raises(lambda: m.progress_probability({}, 1.0, keys), "progress_hazard_unsupported")
    _raises(lambda: m.fit_progress_hazard([(1.0, "ttft_impossible", 1)]),
            "deterministic_state_became_good")


def test_r6_diagnostic_refuses_incomplete_block_and_non_train():
    eps = [joint_episode(random_requests(s, n=20), block=181000 + s // 2, episode_id=f"p{s}",
                         duration=8.0) for s in (2, 3, 4, 5, 6)]
    _raises(lambda: m.progress_diagnostic(eps), "development_block_incomplete")
    bad = copy.deepcopy(eps)
    bad[0]["partition"] = "validation"
    _raises(lambda: m.progress_diagnostic(bad), "progress_requires_train_only")


def test_r6_frozen_three_block_origins_match_r5_rollout_origins():
    root = REPLICA.parent / "pr33-native-v3-first-three-complete-train-blocks-frozen"
    if not (root / "verified-artifact-sha256.jsonl").exists():
        raise Skip("frozen three-block Train data unavailable")
    out = m.progress_diagnostic(m.load_replica(root)[0])
    assert out["counts"]["origins"] == 544  # = R5.8 held-out 181003 rollout origins
    assert round(out["summary"]["5s"]["total|history_mean"]["mae"], 2) == 8.76
    for h in ("1s", "3s", "5s"):
        assert abs(out["summary"][h]["ORACLE|oracle_cohort"]["mae"]
                   - out["summary"][h]["part|birth_reduced_form"]["mae"]) < 1e-9


# ---------------------------------------------------------------------------
# R7: paired common-tape plan-response diagnostic (nv3-opus-plan-response-v4)
# ---------------------------------------------------------------------------

def test_r7_plan_inputs_are_exact_planned_sequence_masked_and_receipt_only():
    step = _r5_step()
    step["plan"] = [16.0, 32.0, 32.0, 16.0, 16.0, 32.0, 32.0, 16.0, 16.0, 32.0, 32.0]
    base = m.plan_inputs(step, 5, "r6_next")
    blind = m.plan_inputs(step, 5, "blind")
    assert len(blind) == len(base) - 1
    assert m.plan_inputs(step, 5, "full_plan") == blind + step["plan"][:10]
    assert m.plan_inputs(step, 1, "masked_plan") == blind + step["plan"][:2]
    late = copy.deepcopy(step)
    late["plan"][9] = 16.0                       # differs only after 3 s
    assert m.plan_inputs(late, 3, "masked_plan") == m.plan_inputs(step, 3, "masked_plan")
    assert m.plan_inputs(late, 5, "full_plan") != m.plan_inputs(step, 5, "full_plan")
    assert m.plan_inputs(late, 5, "blind") == blind
    future = copy.deepcopy(step)
    future["labels"] = {t: 99.0 for t in m.TARGETS}
    assert all(m.plan_inputs(future, 5, v) == m.plan_inputs(step, 5, v) for v in m.PLAN_VARIANTS)


def test_r7_schedule_design_and_pair_gates():
    ep = dict(cap_plan=[(0.0, 16), (1.0, 32), (2.0, 32), (3.0, 16), (4.0, 16), (5.0, 32)],
              actions=[dict(planned_at=None, attempts=1, applied_at=0.0, ack_received_at=0.0),
                       dict(planned_at=1.0, attempts=2, applied_at=1.05, ack_received_at=1.06)])
    d = m._schedule_design([ep])
    assert d["repeat_probability"] == 2 / 5 and d["five_slot_patterns"] == 2
    assert d["retried_actions"] == 1 and abs(d["ack_lag_s"]["max"] - 0.06) < 1e-12
    bad = dict(ep, cap_plan=[(0.0, 16), (1.5, 32)])
    _raises(lambda: m._schedule_design([bad]), "schedule_slot_not_1s")
    eps = [joint_episode(random_requests(s, n=20), block=181000 + s // 2, episode_id=f"p{s}",
                         duration=8.0) for s in (2, 3, 4, 5, 6)]
    _raises(lambda: m.plan_response_diagnostic(eps), "development_block_incomplete")
    nontrain = copy.deepcopy(eps)
    nontrain[0]["partition"] = "validation"
    _raises(lambda: m.plan_response_diagnostic(nontrain), "plan_requires_train_only")


def test_r7_frozen_paired_contrast_negatives():
    root = REPLICA.parent / "pr33-native-v3-first-three-complete-train-blocks-frozen"
    if not (root / "verified-artifact-sha256.jsonl").exists():
        raise Skip("frozen three-block Train data unavailable")
    out = m.plan_response_diagnostic(m.load_replica(root)[0])
    assert out["counts"]["origins"] == 544 and out["counts"]["pairs"] == 264
    p = out["paired_difference"]
    for h in ("1s", "3s", "5s"):
        assert p[f"{h}|offers|zero_predictor"] < 0.05      # common tape is real
        assert p[f"{h}|offers|full_plan"] > 0.5             # state ridge breaks invariance
    assert p["5s|good|full_plan"] > p["5s|good|zero_predictor"]   # contrast negative
    assert p["1s|rejected|full_plan"] < p["1s|rejected|blind"]
    assert p["5s|good|masked_plan"] == p["5s|good|full_plan"]


def _r8_world():
    cut = dict(t0=0.0, cell="c", law=3.0, mix=[(128, 3), (256, 1)],
               live=[("a", 1.0, None, [("k",)]), ("b", 1.0, "client_terminal", [("x",)])],
               pending=[("p", 2.0, 256, 0.3)])
    birth = {("c", 128): [(0.7, 0.7, 0.7)] * 20,
             ("c", 256): [(1.2, None, 1.1)] * 10 + [(2.0, 2.0, 2.0)] * 10,
             ("c", 128, 0): [(0.4, 0.4, 0.4)] * 20, ("c", 128, 1): [(3.0, None, 3.0)] * 20}
    kernels = dict(cohort={("k",): [(1.5, 1.5, 1.5)] * 20,
                           ("x",): [(0.2, None, -0.1)] * 20}, birth=birth)
    return cut, kernels, {("c", 128): 1.0, ("c", 256): 2.0}


def test_r8_common_law_and_cap_only_through_admission():
    cut, kernels, costs = _r8_world()
    a = m.draw_common_law(cut, "181004|c|8", 3)
    assert a == m.draw_common_law(cut, "181004|c|8", 3)          # keyed, plan-free
    assert a != m.draw_common_law(cut, "181004|c|8", 4)
    loose = m.simulate_plan(cut, [1e3] * 10, a, kernels, costs)
    looser = m.simulate_plan(cut, [2e3] * 10, a, kernels, costs)
    assert loose == looser            # non-binding plans: identical service and outcomes
    tight = m.simulate_plan(cut, [1.0] * 10, a, kernels, costs)
    for h in ("1", "3", "5"):
        assert tight[f"offers_{h}"] == loose[f"offers_{h}"]      # offers never cap-caused
    closed = m.simulate_plan(cut, [0.0] * 10, a, kernels, costs)
    # zero budget: every offer and the pending ID rejected, only the live cohort is good
    assert closed["rejected_5"] == closed["offers_5"] + 1 and closed["good_5"] == 1.0
    assert closed["max_reserved_after_admission"] == 0.0
    # a client-terminal owner still holds its cost until its drawn Gateway release (0.2s)
    cut1 = dict(cut, live=[cut["live"][1]], pending=[])
    early = dict(arrivals=[(0.1, 256, 0.0), (0.3, 256, 0.0)], live_u=[0.0], pending_u=[])
    held = m.simulate_plan(cut1, [2.5] * 10, early, kernels, costs)
    assert held["rejected_1"] == 1.0 and held["max_reserved_after_admission"] == 2.0


def test_r8_exact_ledger_and_load_pathway():
    cut, kernels, costs = _r8_world()
    cut = dict(cut, live=[], pending=[], mix=[(128, 1)])
    draw = dict(arrivals=[(0.1, 128, 0.0), (0.2, 128, 0.0), (0.3, 128, 0.0)],
                live_u=[], pending_u=[])
    out = m.simulate_plan(cut, [2.0] * 10, draw, kernels, costs)
    assert out["rejected_1"] == 1.0 and out["max_reserved_after_admission"] == 2.0
    many = dict(draw, arrivals=[(0.01 * i, 128, 0.0) for i in range(1, 11)])
    loaded = m.simulate_plan(cut, [100.0] * 10, many, kernels, costs)
    flat = m.simulate_plan(cut, [100.0] * 10, many, kernels, costs, load_aware=False)
    # the 9th/10th admissions see 8+ live IDs -> load bin 1 (slow, not good)
    assert loaded["good_1"] == 8.0 and flat["good_1"] == 10.0
    budget16 = m.simulate_plan(cut, [4.0] * 10, many, kernels, costs)
    assert budget16["good_1"] == 4.0 and budget16["rejected_1"] == 6.0


def test_r8_kernel_backoff_and_pending_survival():
    table = {("a", 1): [(0.2, None, 0.2)] * 3,
             ("a",): [(0.1, 0.1, 0.1)] * 5 + [(0.3, 0.9, 0.9)] * 15}
    rec, level = m.kernel_draw(table, [("a", 1), ("a",)], 0.0)
    assert level == 1 and rec == (0.1, 0.1, 0.1)
    # pending survival conditions on the client terminal (last field), not on release
    rec, _ = m.kernel_draw(table, [("a", 1), ("a",)], 0.0, min_alive=0.5)
    assert rec == (0.3, 0.9, 0.9)
    _raises(lambda: m.kernel_draw(table, [("a",)], 0.0, min_alive=5.0), "kernel_unsupported")
    _raises(lambda: m.kernel_draw({}, [("z",)], 0.0), "kernel_unsupported")


def test_r8_payload_cost_and_assignment_binding_refusals():
    ep = dict(cell="c", client_rows=[dict(request_id="1", requested_max_tokens=128,
                                          admission_rejection=True,
                                          admission=dict(estimated_request_cost=1.0)),
                                     dict(request_id="2", requested_max_tokens=128,
                                          admission_rejection=True,
                                          admission=dict(estimated_request_cost=1.5))],
              observations=[])
    _raises(lambda: m.payload_costs([ep]), "payload_cost_not_unique")
    ack = lambda b, v, t, op: dict(status="applied", acknowledgment=dict(
        budget=b, budget_version=v, applied_at=t, operation_id=op, run_id="r", clock_domain="c"))
    obs = dict(run_id="r", clock_domain="c", budget_version=2, get_started_at=1.0,
               sampled_at=1.1, get_received_at=1.2)
    doc = dict(gateway_run_id="r", start=0.0,
               schedule=[dict(at_s=0, budget=32), dict(at_s=1, budget=16),
                         dict(at_s=2, budget=16)],
               preassignment=[dict(reply=ack(32, 1, 0.0, "o1"))],
               actions=[dict(at_s=1, attempts=[dict(reply=ack(16, 2, 1.01, "o2"))])],
               held_assignments=[dict(at_s=2, budget=16, status="confirmed_hold", run_id="r",
                                      clock_domain="c", budget_version=2, confirmed_at=2.01,
                                      reference_operation_id="o2", state_observation=obs)])
    assert m.bind_assignments(doc, True, "c")["holds"] == 1
    _raises(lambda: m.bind_assignments(doc, False, "c"), "replica_holds_not_in_binding")
    stale = copy.deepcopy(doc)
    stale["held_assignments"][0]["reference_operation_id"] = "o1"
    _raises(lambda: m.bind_assignments(stale, True, "c"), "replica_hold_not_bound_to_ack")
    gap = copy.deepcopy(doc)
    gap["held_assignments"] = []
    _raises(lambda: m.bind_assignments(gap, True, "c"), "replica_assignment_coverage")
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        _raises(lambda: m.bind_source(Path(tmp)), "replica_index_ambiguous_or_missing")
        (Path(tmp) / "index.json").write_text(json.dumps(dict(
            source_commit="729b144a0c5885d702a6a49c655f61c62513ed30",
            schema=m.COMMON_BINDING["schema"], collector_sha256="other")))
        _raises(lambda: m.bind_source(Path(tmp)), "replica_source_binding")


def test_r8_actual_recovery_source_binding():
    root = REPLICA.parent / "pr33-native-v3-recovery-first-two-train-blocks-frozen"
    if not (root / "verified-artifact-sha256.jsonl").exists():
        raise Skip("frozen recovery Train data unavailable")
    eps, _ = m.load_replica(root)
    assert len(eps) == 20 and {e["source_commit"][:7] for e in eps} == {"729b144"}
    assert sum(e["assignment_evidence"]["holds"] for e in eps) == 1196
    assert all(e["assignment_evidence"]["holds"] + e["assignment_evidence"]["commands"] == 119
               for e in eps)
    ep = eps[0]
    _, _, rows = m.joint_steps(ep, with_rows=True)
    iv = m.release_intervals(ep, rows)
    assert set(iv) == {r for r, v in rows.items() if not v["rejected"]}
    assert all(v is None or v[0] < v[1] for v in iv.values())
    _raises(lambda: m.admission_birth_diagnostic(eps, eps, train_blocks=(181004,),
                                                 eval_blocks=(181004,)), "train_eval_overlap")


def test_r9_mean_truth_uses_every_origin_per_episode():
    sel = {("e1", 0): dict(truth={"good_5": 2.0}), ("e1", 4): dict(truth={"good_5": 4.0}),
           ("e1", 8): dict(truth={"good_5": 9.0}), ("e2", 0): dict(truth={"good_5": 1.0})}
    # episode means 5 and 1 -> 3; the frozen v5 aggregation gave (9 + 1) / 2 = 5
    assert m._mean_truth(sel) == {"good_5": 3.0}
    audit = REPLICA.parent / "pr33-native-v3-r9-mayor-origin-audit.json"
    if audit.exists():
        doc = json.loads(audit.read_text())
        rows = {(r["episode_id"], r["k"]): dict(truth=r["truth"]) for r in doc["scored_origins"]}
        got = m._mean_truth(rows)
        assert all(abs(got[k] - v) < 1e-12 for k, v in doc["corrected_mean_truth"].items())


def test_r9_release_endpoint_changes_only_release_field():
    ep = dict(episode_id="e", cell="c", observations=[
        dict(gateway=dict(sampled_at=t, requests=[dict(request_id=r) for r in ids]))
        for t, ids in ((1.0, ["a"]), (2.0, ["a"]), (3.0, []))],
        client_rows=[dict(request_id="a", requested_max_tokens=128)])
    rows = {"a": dict(rejected=False, sent=0.5, terminal=2.4, good_at=2.4)}
    assert m.release_intervals(ep, rows) == {"a": (2.0, 3.0)}
    entries = [(ep, [], [], rows)]
    up = m.fit_admission_kernels(entries, "upper")["birth"][("c", 128, 0)]
    lo = m.fit_admission_kernels(entries, "lower")["birth"][("c", 128, 0)]
    assert up == [(2.5, 1.9, 1.9)] and lo == [(1.5, 1.9, 1.9)]
    _raises(lambda: m.fit_admission_kernels(entries, "mid"), "release_endpoint")


def test_r9_sensitivity_refuses_without_complete_eval_blocks():
    root = REPLICA.parent / "pr33-native-v3-first-three-complete-train-blocks-frozen"
    if not (root / "verified-artifact-sha256.jsonl").exists():
        raise Skip("frozen three-block Train data unavailable")
    eps, _ = m.load_replica(root)
    # pre-registered eval blocks 181008/181009 are absent from these directories
    _raises(lambda: m.release_endpoint_sensitivity(eps, eps), "block_incomplete")


def _r10_table():
    # Sol/Mayor counterexample: records A(terminal 2), D(.5), B(3); pending age 1
    a, d, b = (2.0, None, 2.0), (0.5, None, 0.5), (3.0, None, 3.0)
    return {("k",): [a, d, b]}, a, d, b


def test_r10_eligible_draw_is_conditionally_uniform_and_v5_bias_is_retained():
    table, a, d, b = _r10_table()
    old = [m.kernel_draw(table, [("k",)], u, min_alive=1.0)[0] for u in (0.1, 0.5, 0.9)]
    assert old == [a, b, b]                      # frozen v5 cyclic survivor bias, preserved
    new = [m.kernel_draw_eligible(table, [("k",)], u, min_alive=1.0)[0]
           for u in (0.1, 0.5, 0.9)]
    assert new == [a, b, b]
    grid = [(i + 0.5) / 1000 for i in range(1000)]
    for fn, share_a in ((m.kernel_draw, 1 / 3), (m.kernel_draw_eligible, 1 / 2)):
        picks = Counter(fn(table, [("k",)], u, min_alive=1.0)[0] for u in grid)
        assert abs(picks[a] / 1000 - share_a) < 2e-3 and picks[d] == 0
    # without a survival condition the repair is exactly v5, for every u
    assert all(m.kernel_draw(table, [("k",)], u) == m.kernel_draw_eligible(table, [("k",)], u)
               for u in grid)


def test_r10_empty_eligible_set_and_age_boundary_and_backoff_level():
    table, a, d, b = _r10_table()
    _raises(lambda: m.kernel_draw_eligible(table, [("k",)], 0.3, min_alive=3.0),
            "kernel_no_eligible_survivor")
    # strict survival: terminal == age + EPS is NOT alive, just above it is
    edge = {("k",): [(1.0, None, 1.0 + m.EPS)]}
    _raises(lambda: m.kernel_draw_eligible(edge, [("k",)], 0.0, min_alive=1.0),
            "kernel_no_eligible_survivor")
    edge = {("k",): [(1.0, None, 1.0 + 2 * m.EPS)]}
    assert m.kernel_draw_eligible(edge, [("k",)], 0.0, min_alive=1.0)[0][2] > 1.0
    # level is chosen on TOTAL count as in v5: a full fine level with no survivor is
    # unsupported even though the coarse level has one (no silent fall-through)
    tab = {("f",): [(0.2, None, 0.2)] * m.HAZARD_MIN, ("c",): [(5.0, None, 5.0)]}
    _raises(lambda: m.kernel_draw_eligible(tab, [("f",), ("c",)], 0.5, min_alive=1.0),
            "kernel_no_eligible_survivor")
    # a thin fine level backs off to the coarse level before filtering
    tab[("f",)] = [(0.2, None, 0.2)]
    assert m.kernel_draw_eligible(tab, [("f",), ("c",)], 0.5, min_alive=1.0) == \
        ((5.0, None, 5.0), 1)
    _raises(lambda: m._drawer("cyclic_v8"), "draw_rule")


def test_r10_draw_rule_only_touches_pending_ids():
    cut, kernels, costs = _r8_world()
    draw = m.draw_common_law(cut, "181010|c|8", 2)
    for plan in ([1e3] * 10, [1.0] * 10, [3.0] * 10):
        no_pending = dict(cut, pending=[])
        assert m.simulate_plan(no_pending, plan, draw, kernels, costs) == \
            m.simulate_plan(no_pending, plan, draw, kernels, costs,
                            draw_rule="eligible_uniform")
        assert m.simulate_plan(cut, plan, draw, kernels, costs) == \
            m.simulate_plan(cut, plan, draw, kernels, costs, draw_rule="v5_cyclic")


def test_r10_fixed_crn_interference_witness():
    for rule in m.DRAW_RULES:
        w = m.interference_witness(rule)
        assert w["open"]["admitted_after_0_5s"] == 6 and w["shut"]["admitted_after_0_5s"] == 0
        # frozen simulator: marks are fixed at the cut / at admission
        assert w["future_admissions_change_live_cohort_mark"] is False
        assert w["later_admissions_change_birth_mark"] is False
        assert w["open"]["good_5"] == w["shut"]["good_5"]
        # the ONLY batch pathway: load already owned when the birth is admitted
        assert w["pre_admission_load_changes_birth_mark"] is True


def test_r10_comparison_refuses_without_complete_eval_blocks():
    root = REPLICA.parent / "pr33-native-v3-first-three-complete-train-blocks-frozen"
    if not (root / "verified-artifact-sha256.jsonl").exists():
        raise Skip("frozen three-block Train data unavailable")
    eps, _ = m.load_replica(root)
    assert m.R10_EVAL_BLOCKS == (181010, 181011)
    _raises(lambda: m.eligible_draw_comparison(eps, eps), "block_incomplete")



def _r11_model(aware_rec, blind_rec):
    cell, cls = "w", 128
    table = {}
    for rb in range(m.RUNNING_CAP + 1):
        for pb in range(len(m.PREFILL_EDGES_K) + 1):
            for ph in ("H", "P", "D1"):
                table[(cell, cls, ph, "ok", rb, pb)] = [aware_rec(rb, pb)] * m.HAZARD_MIN
            for half in (0, 1):
                table[("entry", cell, cls, half, rb, pb)] = [("H", "ok", 0)] * m.HAZARD_MIN
    for ph in ("H", "P", "D1"):
        table[(cell, cls, ph, "ok")] = [blind_rec] * m.HAZARD_MIN
    for half in (0, 1):
        table[("entry", cell, cls, half)] = [("H", "ok", 0)] * m.HAZARD_MIN
    return dict(cell=cell, table=table, prompt_k={(cell, cls): 4.096}), {(cell, cls): 2.0}


def test_r11_batch_state_is_current_population_only():
    pk = {("c", 1): 4.096, ("c", 2): 0.128}
    assert m.r11_batch([], pk) == (0, 0)
    pop = [("P", "c", 2)] * 8 + [("H", "c", 1), ("Q", "c", 1), ("T", "c", 1), ("Z", "c", 1)]
    # 8 running; prefill work = 8*0.128 (P) + 2*4.096 (H,Q) = 9.216k -> bin 3
    assert m.r11_batch(pop, pk) == (1, 3)
    assert m.r11_batch([("D4", "c", 2)] * 100, pk) == (m.RUNNING_CAP, 0)
    row = dict(scheduled=0.0, first=0.4, terminal=None)
    assert m.ttft_state(row, 0.3) == "open" and m.ttft_state(row, 0.45) == "ok"
    assert m.ttft_state(dict(row, first=0.7), 0.6) == "dead"


def test_r11_fixed_crn_witness_batch_pathway():
    w = m.r11_interference_witness()
    assert w["aware_future_admissions_change_live_cohort"] is True
    assert w["blind_future_admissions_change_live_cohort"] is False
    assert w["aware|shut"]["live_L_path"] == ["D2", "GONE"]
    assert w["aware|open"]["live_L_path"] == ["D2"] * m.ROLLOUT_STEPS
    assert w["aware|open"]["rejected_1"] == 0 and w["aware|shut"]["rejected_1"] == 9


def test_r11_plan_only_through_admission_and_exact_ledger():
    model, costs = _r11_model(lambda rb, pb: ("D1", "ok", 0) if pb else ("GONE", "end", 1),
                              ("D1", "ok", 0))
    arrivals = [(0.1 * (i + 1), 128, 0.0) for i in range(40)]
    uni = [[0.5] * m.ROLLOUT_STEPS for _ in range(1 + len(arrivals))]
    start = [("D1", "ok", 128)]
    runs = {u: m.r11_simulate(start, [u] * m.ROLLOUT_STEPS, arrivals, uni, model, costs)
            for u in (16.0, 32.0)}
    for h in m.SIM_HORIZONS:
        assert runs[16.0][f"offers_{h:g}"] == runs[32.0][f"offers_{h:g}"]
    for u, r in runs.items():
        assert r["max_reserved_after_admission"] <= u + 1e-9
    # same plan, batch-blind tables: births no longer change the live owner
    assert runs[16.0]["rejected_5"] > runs[32.0]["rejected_5"]
    blind = m.r11_simulate(start, [32.0] * m.ROLLOUT_STEPS, arrivals, uni, model, costs,
                           aware=False)
    assert blind["good_5"] == 0.0
    model["table"].pop(("entry", "w", 128, 0))
    model["table"] = {k: v for k, v in model["table"].items() if k[0] != "entry"}
    _raises(lambda: m.r11_simulate(start, [32.0] * m.ROLLOUT_STEPS, arrivals, uni, model,
                                   costs), "r11_unsupported")


def test_r11_logloss_smoothing_and_backoff():
    table = {("a", 1, "P", "ok", 0, 0): [("P", "ok", 0)] * 3,
             ("a", 1, "P", "ok"): [("P", "ok", 0)] * m.HAZARD_MIN,
             ("P", "ok"): [("P", "ok", 0)] * m.HAZARD_MIN}
    keys = m._r11_keys("a", 1, "P", "ok", (0, 0))
    ll, level = m._r11_logloss(table, keys, ("GONE", "end", 1), 4)
    assert level == 1 and abs(ll - (-math.log(0.5 / (m.HAZARD_MIN + 2)))) < 1e-12


def test_r11_actual_train_transitions_conserve_population():
    root = REPLICA.parent / "pr33-native-v3-first-three-complete-train-blocks-frozen"
    if not (root / "verified-artifact-sha256.jsonl").exists():
        raise Skip("frozen three-block Train data unavailable")
    eps, _ = m.load_replica(root)
    e = sorted((x for x in eps if x["seed_block"] == 181001 and x["cell"] == "mixed"),
               key=lambda x: x["episode_id"])[0]
    entries = m._r8_entries([e])
    fit = m.fit_batch_progress(entries)
    assert set(fit["prompt_k"].values()) == {0.128, 4.096}
    _, steps, _, rows = entries[0]
    cls_of = {r["request_id"]: m.payload_class(r) for r in e["client_rows"]}
    phases = Counter()
    for kind, keys, rec in m.r11_transition_records(e["cell"], steps, rows, cls_of,
                                                    fit["prompt_k"]):
        assert len(keys) == 3 and rec[0] in m.COST_PHASES | {"Z", "GONE"}
        assert rec[2] in (0, 1) and (rec[2] == 0 or rec[0] in ("GONE", "T"))
        phases[(kind, keys[1][2] if kind == "trans" else "entry")] += 1
    assert min(phases[("trans", p)] for p in ("H", "P", "D1", "D2", "D3", "T", "Q")) > 0
    assert m.R11_EVAL_BLOCKS == (181012, 181013)
    _raises(lambda: m.batch_progress_diagnostic(eps, eps), "block_incomplete")



def test_r12_stock_sweep_event_order_and_endpoints():
    admitted = [("a", 0.0, 2.0, (0.30, 0.45)), ("b", 0.1, 1.0, None),
                ("c", 0.35, 4.0, (0.6, 0.7))]
    q = [("x", 0.2), ("y", 0.30), ("z", 0.40), ("w", 0.65)]
    up = m._stock_sweep(admitted, q, "upper")
    lo = m._stock_sweep(admitted, q, "lower")
    assert up == {"x": 3.0, "y": 3.0, "z": 7.0, "w": 5.0}
    # release at exactly the query time applies first; unidentified (None) never released
    assert lo == {"x": 3.0, "y": 1.0, "z": 5.0, "w": 1.0}


def _r12_offsets(off):
    return {("w", 128): [off] * m.HAZARD_MIN}


def test_r12_within_step_release_admits_after_release_only():
    model, costs = _r11_model(lambda rb, pb: ("GONE", "end", 1), ("GONE", "end", 1))
    start, plan = [("D1", "ok", 128)], [2.0] * m.ROLLOUT_STEPS
    arrivals = [(0.2, 128, 0.0)]
    uni = [[0.5] * m.ROLLOUT_STEPS for _ in range(2)]
    v8t, v9t, latet = {}, {}, {}
    v8 = m.r11_simulate(start, plan, arrivals, uni, model, costs, trace=v8t)
    v9 = m.r12_simulate(start, plan, arrivals, uni, uni, model, costs, _r12_offsets(0.1),
                        trace=v9t)
    late = m.r12_simulate(start, plan, arrivals, uni, uni, model, costs, _r12_offsets(0.5),
                          trace=latet)
    assert v8["rejected_1"] == 1.0 and v9["rejected_1"] == 0.0
    # a release offset at the step end reproduces the frozen v8 grid rule exactly
    assert late == v8 and latet == v8t
    # member transitions are the SAME draws; only admission ordering changed
    assert v9t[0] == v8t[0] and v9["max_reserved_after_admission"] <= 2.0 + 1e-9
    # releases strictly before the offer only: offset 0.2 == arrival applies, 0.25 does not
    at = m.r12_simulate(start, plan, arrivals, uni, uni, model, costs, _r12_offsets(0.2))
    after = m.r12_simulate(start, plan, arrivals, uni, uni, model, costs, _r12_offsets(0.25))
    assert at["rejected_1"] == 0.0 and after["rejected_1"] == 1.0
    _raises(lambda: m._r12_pool({("w", 128): [0.1]}, "w", 128),
            "release_offset_unsupported")
    assert m._r12_pool({(): [0.3] * m.HAZARD_MIN}, "w", 128) == [0.3] * m.HAZARD_MIN


def test_r12_actual_train_replay_and_offsets_are_ordered():
    root = REPLICA.parent / "pr33-native-v3-first-three-complete-train-blocks-frozen"
    if not (root / "verified-artifact-sha256.jsonl").exists():
        raise Skip("frozen three-block Train data unavailable")
    eps, _ = m.load_replica(root)
    e = sorted((x for x in eps if x["seed_block"] == 181001 and x["cell"] == "p128-m128"),
               key=lambda x: x["episode_id"])[0]
    entries = m._r8_entries([e])
    costs = m.payload_costs([e])
    _, steps, _, rows = entries[0]
    replay, _, _ = m.admission_replay(e, steps, rows, costs)
    for row in replay.values():
        # step-start stock never below the event-ordered stock on the same factual tape
        for end in m.RELEASE_ENDPOINTS:
            assert row[f"grid_{end}"] >= row[f"event_{end}"]
        assert row["event_lower"] <= row["event_upper"] <= row["offers"]
        assert row["actual_rejected"] <= row["offers"]
    offs = {end: m.fit_release_offsets(entries, end) for end in m.RELEASE_ENDPOINTS}
    for end, pools in offs.items():
        assert all(0.0 <= x <= m.STEP_S for x in pools[()])
    assert len(offs["upper"][()]) == len(offs["lower"][()]) > m.HAZARD_MIN
    assert statistics.median(offs["lower"][()]) <= statistics.median(offs["upper"][()])


def test_r13_stable_uniforms_are_identity_keyed():
    a = m.StableUniforms("t", "b|c|1", 0, ["rid:x", "rid:y"])
    b = m.StableUniforms("t", "b|c|1", 0, ["rid:y", "rid:q1", "rid:q2", "rid:x"])
    # same member / same law arrival -> same stream, whatever the start length/order
    assert a[0] == b[3] and a[1] == b[0]
    assert a[2] == b[4] and a.identity(2) == b.identity(4) == "arrival:0"
    assert len(a[0]) == m.ROLLOUT_STEPS and a[0] != a[1] and a[2] != a[3]
    assert m.StableUniforms("t", "b|c|1", 1, ["rid:x"])[0] != a[0]
    assert m.StableUniforms("u", "b|c|1", 0, ["rid:x"])[0] != a[0]


def test_r13_used_cuts_repair_plan_dependent_birth_index_shift():
    tr_root = REPLICA.parent / "pr33-native-v3-first-three-complete-train-blocks-frozen"
    ev_root = REPLICA.parent / "pr33-native-v3-recovery-train-six-seven-frozen"
    if not all((r / "verified-artifact-sha256.jsonl").exists() for r in (tr_root, ev_root)):
        raise Skip("frozen USED Train data unavailable")
    tr, _ = m.load_replica(tr_root)
    ev, _ = m.load_replica(ev_root)
    entries = m._r8_entries(tr)
    costs = m.payload_costs([e for e, _, _, _ in entries])
    model = dict(m.fit_batch_progress(entries))
    # Astra R12 witness cuts (USED 6/7): positional first-birth step-0 uniforms
    expected = {("nv3-181006-mixed-arm0", 12): ((5, 8), (0.7252071343450393,
                                                          0.8078238380389821)),
                ("nv3-181007-mixed-arm0", 32): ((6, 7), (0.6713822373807942,
                                                          0.7042321837779066))}
    for (eid, k), (lengths, positional) in expected.items():
        e = next(x for x in ev if x["episode_id"] == eid)
        _, steps, _, rows = m._r8_entries([e])[0]
        raw = {r["request_id"]: r for r in e["client_rows"]}
        cls_of = {i: m.payload_class(r) for i, r in raw.items()}
        order = sorted((r["sent"], i) for i, r in rows.items())
        by_class = defaultdict(list)
        for t, i in order:
            by_class[cls_of[i]].append(t)
        index = ([t for t, _ in order], [i for _, i in order], dict(by_class))
        s, seen = next((s, seen) for s, seen, _, _ in m._r11_walk(steps, rows)
                       if s["k"] == k)
        cut = m.admission_cut_state(s, rows, raw, costs, index)
        key = f"{e['seed_block']}|{e['cell']}|{k}"
        stable, starts = [], []
        for u, n_expected, u_expected in zip((16.0, 32.0), lengths, positional):
            plan = [u] * m.ROLLOUT_STEPS
            start, ids = m.r13_cut_start(s, rows, cls_of, seen - s["cohort"], cut, plan,
                                         costs)
            assert start == m.r11_cut_start(s, rows, cls_of, seen - s["cohort"], cut,
                                            plan, costs)
            assert len(start) == n_expected == len(ids) == len(set(ids))
            law = m.draw_common_law(cut, key, 0)
            rng = random.Random(int(hashlib.sha256(
                f"{m.R11_SEED}|{key}|0".encode()).hexdigest()[:16], 16))
            pos = [[rng.random() for _ in range(m.ROLLOUT_STEPS)]
                   for _ in range(len(start) + len(law["arrivals"]))]
            assert pos[len(start)][0] == u_expected
            stable.append(m.StableUniforms(m.R13_SEED + "|member", key, 0, ids)[len(start)])
            starts.append((start, ids, plan))
        assert stable[0] == stable[1]
        # positional mode reproduces the frozen v8 response exactly
        start, ids, plan = starts[1]
        ref = m.r11_response(start, plan, cut, key, dict(model, cell=e["cell"]), costs,
                             scenarios=4)
        got = m._r13_band(m.r13_runs(start, ids, plan, cut, key, dict(model, cell=e["cell"]),
                                     costs, scenarios=4, stable=False))
        assert got == ref
        offsets = m.fit_release_offsets(entries, "upper")
        for st, ids_, pl in starts:
            for off in (None, offsets):
                runs = m.r13_runs(st, ids_, pl, cut, key, dict(model, cell=e["cell"]),
                                  costs, scenarios=2, offsets=off)
                assert len(runs) == 2 and all(r["good_5"] >= 0 for r in runs)


def test_r14_used_train_owner_marks_explain_every_gateway_decision():
    root = REPLICA.parent / "pr33-native-v3-first-three-complete-train-blocks-frozen"
    if not (root / "verified-artifact-sha256.jsonl").exists():
        raise Skip("frozen USED Train data unavailable")
    tr, _ = m.load_replica(root)
    out = m.owner_stock_audit_summary(tr, m.payload_costs(tr))
    assert sorted(out) == ["181001", "181002", "181003"]
    for blk, d in out.items():
        assert d["admitted"] > 8000 and d["never_snapshotted"] == 0
        assert d["violation_accepted_but_must_reject"] == 0
        assert d["violation_rejected_but_must_accept"] == 0
        assert d["violation_rejected_exact_budget_unexplained"] == 0
        assert 0.6 < d["frac_offers_determined"] < 0.75
    assert [out[b]["floor_contradicted_by_actual_accept"] for b in sorted(out)] == [0, 1, 0]


def test_r14_decision_lag_bins_pool_backoff_and_zero_lag_equals_v10():
    assert [m._r14_bin(n) for n in (0, 3, 4, 7, 8, 15, 16, 40)] == [0, 0, 1, 1, 2, 2, 3, 3]
    lags = {("c", 1): [0.1] * m.HAZARD_MIN, ("c",): [0.2] * m.HAZARD_MIN,
            (): [0.3] * m.HAZARD_MIN, ("d", 0): [9.0]}
    assert m._r14_pool(lags, "c", 1)[0] == 0.1 and m._r14_pool(lags, "c", 2)[0] == 0.2
    assert m._r14_pool(lags, "d", 0)[0] == 0.3
    try:
        m._r14_pool({}, "c", 0)
        raise AssertionError("expected unsupported")
    except ValueError as error:
        assert str(error) == "decision_lag_unsupported"
    tr_root = REPLICA.parent / "pr33-native-v3-first-three-complete-train-blocks-frozen"
    ev_root = REPLICA.parent / "pr33-native-v3-recovery-train-six-seven-frozen"
    if not all((r / "verified-artifact-sha256.jsonl").exists() for r in (tr_root, ev_root)):
        raise Skip("frozen USED Train data unavailable")
    tr, _ = m.load_replica(tr_root)
    ev, _ = m.load_replica(ev_root)
    entries = m._r8_entries(tr)
    fitted = m.fit_decision_lags(entries)
    assert all(v == sorted(v) and v[0] >= 0 for v in fitted.values())
    assert len(fitted[()]) == sum(len(v) for k, v in fitted.items() if len(k) == 1)
    costs = m.payload_costs([e for e, _, _, _ in entries])
    model = m.fit_batch_progress(entries)
    offsets = m.fit_release_offsets(entries, "upper")
    e = next(x for x in ev if x["episode_id"] == "nv3-181006-mixed-arm0")
    _, steps, _, rows = m._r8_entries([e])[0]
    raw = {r["request_id"]: r for r in e["client_rows"]}
    cls_of = {i: m.payload_class(r) for i, r in raw.items()}
    order = sorted((r["sent"], i) for i, r in rows.items())
    by_class = defaultdict(list)
    for t, i in order:
        by_class[cls_of[i]].append(t)
    index = ([t for t, _ in order], [i for _, i in order], dict(by_class))
    s, seen = next((s, seen) for s, seen, _, _ in m._r11_walk(steps, rows) if s["k"] == 12)
    cut = m.admission_cut_state(s, rows, raw, costs, index)
    key, mdl = f"181006|{e['cell']}|12", dict(model, cell=e["cell"])
    plan = [16.0] * m.ROLLOUT_STEPS
    start, ids = m.r13_cut_start(s, rows, cls_of, seen - s["cohort"], cut, plan, costs)
    zero = {(): [0.0] * m.HAZARD_MIN}
    # zero decision lag: v11 is exactly v10 within-step (same member/release streams)
    assert m.r14_runs(start, ids, plan, cut, key, mdl, costs, offsets, zero, scenarios=4) \
        == m.r13_runs(start, ids, plan, cut, key, mdl, costs, True, offsets, scenarios=4)
    stats = Counter()
    late = {(): [m.STEP_S * 2] * m.HAZARD_MIN}
    runs = m.r14_runs(start, ids, plan, cut, key, mdl, costs, offsets, late, scenarios=2,
                      stats=stats)
    assert stats["v11_lag_draws"] > 0
    assert stats["v11_lag_clipped_to_step_end"] == stats["v11_lag_draws"]
    assert all(r["offers_5"] == z["offers_5"] for r, z in zip(runs, m.r14_runs(
        start, ids, plan, cut, key, mdl, costs, offsets, zero, scenarios=2)))

def _s144_episode():
    """Synthetic Source144 episode: snapshots at 0.0, 1.0, 2.0 (budget 10)."""
    def snap(seq, t, owners):
        return dict(sampled_at=t + 0.01, available=True, running=0, waiting=0,
                    kv_cache_usage=0.0, requests=[],
                    gateway_snapshot=dict(run_id="R", sequence=seq, sampled_at=t, budget=10.0,
                                          requests=[dict(request_id=i, cost=c, admitted_at=a)
                                                    for i, c, a in owners]))
    frames = [snap(1, 0.0, [("a", 2.0, -0.5), ("b", 2.0, -0.4), ("c", 3.0, -0.3)]),
              snap(2, 1.0, [("c", 3.0, -0.3), ("d", 1.5, 0.6)]),
              snap(3, 2.0, [("d", 1.5, 0.6)])]
    rows = [dict(request_id=i, sent_at=s, first_content_at=s + 0.1, terminal_at=t,
                 status=st, admission_rejection=st == 503,
                 admission=dict(estimated_request_cost=9.0) if st == 503 else None)
            for i, s, t, st in [("a", -0.6, 0.31, 200), ("b", -0.5, 0.71, 200),
                                ("c", -0.4, 1.51, 200), ("d", 0.55, 2.6, 200),
                                ("e", 0.58, 0.7, 503)]]
    return dict(gateway_run_id="R", start=0.0, duration_s=1.0, rows=rows,
                native_frames=frames)


def test_source144_ledger_interval_resolution_and_decisions():
    d = _s144_episode()
    led, seq = [], iter(range(1, 99))

    def row(t, stock):
        led.append(dict(event="mpc_ledger", run_id="R", sequence=next(seq), effective_at=t,
                        reserved_cost=stock, clock_domain="X"))
    for t, s in [(-0.5, 2.0), (-0.4, 4.0), (-0.3, 7.0), (0.3, 5.0), (0.6, 6.5),
                 (0.7, 4.5), (1.5, 1.5)]:
        row(t, s)
    per = [dict(event="accepted", run_id="R", request_id="d", monotonic=0.6 + 1e-5,
                request_cost=1.5, budget=10.0),
           dict(event="rejected", run_id="R", request_id="e", monotonic=0.65,
                request_cost=9.0, budget=10.0),
           dict(event="completed", run_id="R", request_id="a", monotonic=0.3 + 1e-5)]
    c, lag = m.s144_ledger_audit(d, led + per)
    assert c["snapshot_stock_equal"] == c["snapshots"] == 3
    # (0,1]: a,b (cost 2,2) depart, d born: times identified, no owner identity
    # (1,2]: c (cost 3) departs alone: owner identified
    assert c["releases_snapshot"] == 3 and c["releases_time_identified"] == 3
    assert c["releases_owner_identified"] == 1
    assert sorted(round(u, 6) for u in lag["release_u_in_interval"]) == [0.3, 0.5, 0.7]
    assert c["violation_reject_but_fits"] == 0 and c["violation_accept_stock_after_gt_budget"] == 0
    assert c["adjacency_preceding_delta_equals_minus_cost"] == 0   # a's cost unknown here
    # cut 0.5: ledger 5.0 vs stale snapshot (t=0) 7.0
    assert lag["cut_ledger_minus_snapshot_stock"] == [0.0, -2.0]
    # an unmatched interval is counted, never forced
    bad = [dict(e, reserved_cost=e["reserved_cost"] + (0.5 if e["effective_at"] == 0.3 else 0))
           for e in led]
    c2, _ = m.s144_ledger_audit(d, bad + per)
    assert c2["intervals_ledger_ne_snapshot_multiset"] == 1
    assert c2["releases_time_identified"] == 1
    # a rejection that would have fit is a violation
    fit = [dict(per[1], request_cost=1.0)]
    c3, _ = m.s144_ledger_audit(d, led + fit)
    assert c3["violation_reject_but_fits"] == 1


def test_source144_pending_proxy_and_owner_join():
    d = _s144_episode()
    p = m.s144_pending_proxy_audit(d)
    # cut 0.0: nothing pending (a,b,c owners). cut 0.5: a released (terminal .31 <= .5 so
    # not pending); d not sent; nothing pending -> 0.  Shift d/e earlier to be pending at .5
    assert p["cuts"] == 2 and sum(v for k, v in p.items() if k.startswith("pending|")) == 0
    for r in d["rows"]:
        if r["request_id"] in ("d", "e"):
            r["sent_at"] -= 0.2
    p = m.s144_pending_proxy_audit(d)
    assert p["pending|admitted"] == 1 and p["pending|rejected"] == 1
    # stale snapshot stock 7 + d 1.5 <= 10 -> Q; e 9.0 does not fit -> drop
    assert p["proxy_Q|admitted"] == 1 and p["proxy_drop|rejected"] == 1
    assert p["pending_admitted|admitted_at_le_t0"] == 0
    c, lag = m.s144_owner_native_audit(d)
    assert c["owners"] == 4 and c["rejected"] == 1 and c["rejected_later_gateway_owner"] == 0
    assert c["terminal_inside_release_interval"] == 3 and \
        c["owner_release_or_terminal_unobserved"] == 1


def test_source144_used_fifteen_sixteen_audit_invariants():
    root = REPLICA.parent / "pr33-native-v3-new-source-train-fifteen-sixteen-frozen"
    if not (root / "verified-artifact-sha256.jsonl").exists():
        raise Skip("USED Source144 15/16 unavailable")
    out = m.source144_state_audit(root)
    assert out["receipt"]["verified_artifacts"] == 40 and out["fitted_parameters"] is None
    for blk, b in out["per_block"].items():
        j = b["join"]
        assert j["rejected_later_gateway_owner"] == 0 == j["rejected_later_native_visible"]
        assert j["offered_duplicate_ids"] == 0 and j.get("native_tag_not_offered", 0) == 0
        assert b["ledger"] == {"episodes_without_journal": 10}


def _owner_journal(tmp, events, run="RUN", drop_last=False, status_over=None, extra=()):
    """Emulate Gateway a4ec4e3 mpc_changed(): sequence advances on every change, rows carry
    schema-v2 owner fields; shutdown status seals final sequence + exact file bytes/SHA."""
    owners, rows, seq = {}, [], 0
    for t, kind, rid, cost, budget in events:
        seq += 1
        if kind == "admission":
            owners[rid] = cost
        elif kind == "terminal":
            owners.pop(rid, None)
        row = dict(event="mpc_ledger", run_id=run, clock_domain="X", sequence=seq,
                   effective_at=t, reserved_cost=math.fsum(owners.values()),
                   running=len(owners), complete=True, budget=budget, budget_version=1,
                   ledger_schema_version=2, change_kind=kind)
        if rid is not None:
            row.update(request_id=rid, request_cost=cost)
        rows.append(row)
    if drop_last:
        rows.pop()          # emitted after the final flush / while telemetry disabled
    rows.extend(extra)
    raw = "".join(json.dumps(r) + "\n" for r in rows).encode()
    path, status_path = Path(tmp) / "t.jsonl", Path(tmp) / "s.json"
    path.write_bytes(raw)
    status = dict(run_id=run, status="closed", dropped=0, write_errors=0,
                  mpc_ledger_schema_version=2, mpc_final_sequence=seq,
                  mpc_remaining_requests=len(owners), mpc_ledger_complete=True,
                  telemetry_file_sha256=hashlib.sha256(raw).hexdigest(),
                  telemetry_file_bytes=len(raw))
    status.update(status_over or {})
    status_path.write_text(json.dumps(status))
    return path, status_path


_OJ = [(0.0, "control", None, None, 16.0), (0.1, "admission", "a", 2.0, 16.0),
       (0.2, "admission", "b", 2.0, 16.0), (0.3, "first_content", "a", 2.0, 16.0),
       (0.5, "terminal", "b", 2.0, 16.0), (0.9, "terminal", "a", 2.0, 16.0)]


def test_owner_journal_verifier_accepts_exact_replay_and_fails_closed():
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        out = m.verify_owner_journal(*_owner_journal(tmp, _OJ))
        assert out["ok"] and out["failures"] == {} and out["owners"] == 2
        assert out["lifetimes"]["a"]["first_content"] == 0.3        # first content keeps cost
        assert round(out["lifetimes"]["b"]["terminal"] - out["lifetimes"]["b"]["admitted"], 9) == 0.3
        assert out["budget_controls"][0]["budget"] == 16.0
        # counterexample: last terminal row lost after the final flush; status is still
        # 'closed', remaining 0, complete, and SHA/bytes match the (short) file
        out = m.verify_owner_journal(*_owner_journal(tmp, _OJ, drop_last=True,
                                                     status_over=dict(mpc_remaining_requests=0)))
        assert not out["ok"] and out["failures"] == dict(final_sequence_mismatch=1,
                                                         owners_left_after_replay=1)
        bad = [e if e[2] != "b" or e[1] != "terminal" else (0.5, "terminal", "b", 3.0, 16.0)
               for e in _OJ]
        assert "terminal_cost_ne_admitted_cost" in m.verify_owner_journal(
            *_owner_journal(tmp, bad))["failures"]
        dup = _OJ[:2] + [(0.15, "admission", "a", 2.0, 16.0)] + _OJ[2:]
        assert "duplicate_admission" in m.verify_owner_journal(*_owner_journal(tmp, dup))["failures"]
        anon = [(0.1, "admission", None, 2.0, 16.0)]
        assert "owner_row_without_id_or_cost" in m.verify_owner_journal(
            *_owner_journal(tmp, anon))["failures"]
        over = [(0.1, "admission", "a", 20.0, 16.0), (0.2, "terminal", "a", 20.0, 16.0)]
        assert m.verify_owner_journal(*_owner_journal(tmp, over))["failures"] == \
            dict(admission_stock_over_budget=1)
        foreign = [dict(event="snapshot", run_id="OLD", sequence=1)]
        assert m.verify_owner_journal(*_owner_journal(tmp, _OJ, extra=foreign))["failures"] == \
            dict(foreign_run_rows=1)
        p, sp = _owner_journal(tmp, _OJ)
        p.write_bytes(p.read_bytes() + b"\n")
        assert "file_sha256_mismatch" in m.verify_owner_journal(p, sp)["failures"]
        assert "status_not_closed" in m.verify_owner_journal(*_owner_journal(
            tmp, _OJ, status_over=dict(status="failed")))["failures"]


def test_v1_aggregate_ledger_cannot_identify_owner_lifetimes():
    w = m.v1_aggregate_ambiguity_witness()
    assert w["v1_rows_identical"] and not w["v2_rows_identical"]
    assert w["lifetimes_h1"] != w["lifetimes_h2"]
    # same multiset of lifetimes would be needed for a lifetime-only fit; it differs too
    assert sorted(round(v, 9) for v in w["lifetimes_h1"].values()) != \
        sorted(round(v, 9) for v in w["lifetimes_h2"].values())
    # R15 interval matching on these snapshots identifies both release times, no owner
    d = dict(gateway_run_id="R", start=0.0, duration_s=0.0, rows=[], native_frames=[
        dict(gateway_snapshot=dict(run_id="R", sequence=i + 1, sampled_at=t, budget=16.0,
                                   requests=[dict(request_id=r, cost=c, admitted_at=-0.3)
                                             for r, c in o.items()]))
        for i, (t, o) in enumerate(w["snapshots"])])
    events = [dict(r, run_id="R", clock_domain="X") for r in w["v2_h1"]]
    c, _ = m.s144_ledger_audit(d, events)
    assert c["releases_time_identified"] == 2 and c["releases_owner_identified"] == 0


def test_r16_used_cost_budget_count_support():
    root = REPLICA.parent / "pr33-native-v3-new-source-train-fifteen-sixteen-frozen"
    if not (root / "verified-artifact-sha256.jsonl").exists():
        raise Skip("USED Source144 15/16 unavailable")
    eps, _ = m.load_source144(root)
    out = m.r16_count_support(eps)
    assert set(out) == {"16", "32"}
    # >=16 owners under budget 16 occur only as non-evicted carry-over (stock > budget)
    assert out["16"]["ge16_owners"] > 0 and out["16"]["ge16_owners_stock_le_budget"] == 0
    assert out["32"]["stock_gt_budget"] == 0
    assert out["16"]["long_owner_cost_bound"] == 3 and out["32"]["long_owner_cost_bound"] == 7
    assert out["32"]["long_max"] <= 7


def test_r16_decision_contrast_uses_pre_decision_ledger_stock():
    d = dict(gateway_run_id="R", cell="mixed", rows=[dict(request_id=i) for i in "abc"])
    led = [dict(event="mpc_ledger", run_id="R", sequence=k, effective_at=t, reserved_cost=s)
           for k, (t, s) in enumerate([(0.0, 14.0), (1.0, 17.0)], 1)]
    ev = [dict(event="accepted", run_id="R", request_id="a", monotonic=1.0 + 1e-5,
               request_cost=3.0, budget=32.0),          # 14 + 3 = 17: contrast zone
          dict(event="rejected", run_id="R", request_id="b", monotonic=2.0,
               request_cost=16.0, budget=32.0),         # 17 + 16 = 33: both reject
          dict(event="accepted", run_id="R", request_id="z", monotonic=2.0,
               request_cost=1.0, budget=32.0)]          # not this episode's offer
    out = m.r16_decision_contrast([d], led + ev)
    assert out["decisions"] == 2 == out["consistent_with_actual_budget"]
    assert out["all|contrast_16_32"] == 1 and out["all|both_reject"] == 1


def _written_journal(tmp, events, status_over=None):
    """events: ('ctl', B) | ('offer', id, cost) | ('refuse', id, cost) | ('first', id) |
    ('finish', id, outcome); rows follow the d1bd1e5 Gateway emit order."""
    run, rows, owners, seq, budget = "R17", [], {}, 0, None

    def ledger(kind, rid=None, cost=None):
        nonlocal seq
        seq += 1
        row = dict(event="mpc_ledger", run_id=run, clock_domain="X", sequence=seq,
                   effective_at=float(seq), reserved_cost=math.fsum(owners.values()),
                   running=len(owners), complete=True, budget=budget, budget_version=1,
                   ledger_schema_version=2, change_kind=kind)
        if rid is not None:
            row.update(request_id=rid, request_cost=cost)
        rows.append(row)
    for e in events:
        if e[0] == "ctl":
            budget = e[1]
            ledger("control")
        elif e[0] in ("offer", "refuse"):
            rid, cost = e[1], e[2]
            rows.append(dict(event="received", run_id=run, request_id=rid))
            if e[0] == "refuse":
                rows.append(dict(event="mpc_owner_ledger_refused", run_id=run))
            elif math.fsum(owners.values()) + cost <= budget:
                owners[rid] = cost
                ledger("admission", rid, cost)
                rows.append(dict(event="accepted", run_id=run, request_id=rid,
                                 request_cost=cost, budget=budget))
                continue
            rows.append(dict(event="rejected", run_id=run, request_id=rid,
                             request_cost=cost, budget=budget))
        elif e[0] == "first":
            ledger("first_content", e[1], owners[e[1]])
        else:
            cost = owners.pop(e[1])
            ledger("terminal", e[1], cost)
            rows.append(dict(event=e[2], run_id=run, request_id=e[1]))
    raw = "".join(json.dumps(r) + "\n" for r in rows).encode()
    path, status_path = Path(tmp) / "w.jsonl", Path(tmp) / "ws.json"
    path.write_bytes(raw)
    status = dict(run_id=run, status="closed", dropped=0, write_errors=0,
                  mpc_ledger_schema_version=2, mpc_final_sequence=seq,
                  mpc_producer_final_sequence=seq, mpc_ledger_rows_written=seq,
                  mpc_unflushed_records=0, mpc_remaining_requests=len(owners),
                  mpc_ledger_complete=True, telemetry_file_sha256=hashlib.sha256(raw).hexdigest(),
                  telemetry_file_bytes=len(raw))
    status.update(status_over or {})
    status_path.write_text(json.dumps(status))
    return path, status_path


_WJ = [("ctl", 32.0), ("offer", "a", 5.0), ("offer", "b", 20.0), ("offer", "c", 10.0),
       ("ctl", 16.0), ("first", "a"), ("finish", "a", "completed"), ("finish", "b", "failed")]


def test_r17_written_verifier_replays_decisions_outcomes_and_seal():
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        out = m.verify_owner_written_journal(*_written_journal(tmp, _WJ))
        assert out["ok"] and out["accepted"] == 2 and out["budget_rejections"] == 1
        assert out["min_budget_reject_margin"] == 3.0          # 25 + 10 - 32
        assert out["outcomes"] == dict(completed=1, failed=1) and not out["online_cut_available"]
        # an a4ec4e3-schema status (no written/producer/unflushed fields) is refused
        p, sp = _written_journal(tmp, _WJ)
        st = json.loads(sp.read_text())
        for k in ("mpc_producer_final_sequence", "mpc_ledger_rows_written",
                  "mpc_unflushed_records"):
            st.pop(k)
        sp.write_text(json.dumps(st))
        assert m.verify_owner_journal(p, sp)["ok"]           # R16 verifier cannot tell
        assert "status_not_written_seal_schema" in m.verify_owner_written_journal(p, sp)["failures"]
        f = m.verify_owner_written_journal(*_written_journal(
            tmp, _WJ, dict(mpc_producer_final_sequence=99)))["failures"]
        assert f == dict(producer_ne_written_sequence=1)
        # a 'rejected' row whose replayed stock + cost fits the ledger budget
        cheap = [e if e[:2] != ("offer", "c") else ("offer", "c", 10.0) for e in _WJ]
        p, sp = _written_journal(tmp, cheap)
        rows = [json.loads(x) for x in p.read_text().splitlines()]
        for r in rows:
            if r["event"] == "rejected":
                r["request_cost"] = 1.0
        raw = "".join(json.dumps(r) + "\n" for r in rows).encode()
        p.write_bytes(raw)
        st = json.loads(sp.read_text())
        st.update(telemetry_file_bytes=len(raw), telemetry_file_sha256=hashlib.sha256(raw).hexdigest())
        sp.write_text(json.dumps(st))
        assert m.verify_owner_written_journal(p, sp)["failures"] == dict(budget_reject_within_budget=1)
        # admitted owner released in the ledger but without a client-facing outcome row
        p, sp = _written_journal(tmp, _WJ)
        rows = [json.loads(x) for x in p.read_text().splitlines() if '"failed"' not in x]
        raw = "".join(json.dumps(r) + "\n" for r in rows).encode()
        p.write_bytes(raw)
        st = json.loads(sp.read_text())
        st.update(telemetry_file_bytes=len(raw), telemetry_file_sha256=hashlib.sha256(raw).hexdigest())
        sp.write_text(json.dumps(st))
        assert m.verify_owner_written_journal(p, sp)["failures"] == dict(
            admitted_without_single_outcome=1)
        # owner-ledger refusal is attributed only via its adjacent 'rejected' row
        out = m.verify_owner_written_journal(*_written_journal(
            tmp, _WJ[:1] + [("refuse", "r", 1.0)] + _WJ[1:]))
        assert out["ok"] and [r["request_id"] for r in out["owner_ledger_refusals"]] == ["r"]
        p, sp = _written_journal(tmp, _WJ[:1] + [("refuse", "r", 1.0)] + _WJ[1:])
        rows = [json.loads(x) for x in p.read_text().splitlines()]
        rows = [r for r in rows if not (r["event"] == "rejected" and r["request_id"] == "r")]
        raw = "".join(json.dumps(r) + "\n" for r in rows).encode()
        p.write_bytes(raw)
        st = json.loads(sp.read_text())
        st.update(telemetry_file_bytes=len(raw), telemetry_file_sha256=hashlib.sha256(raw).hexdigest())
        sp.write_text(json.dumps(st))
        f = m.verify_owner_written_journal(p, sp)["failures"]
        assert f["refusal_unattributed"] == 1 and f["offer_without_single_decision"] == 1


_MAYOR = Path("/home/daniel_lin/gt/pr32/mayor")


def test_r17_actual_written_seal_witness():
    new, old = _MAYOR / "mpc-native-owner-written-journal", _MAYOR / "mpc-native-owner-journal"
    if not ((new / "gateway.py").exists() and (old / "gateway.py").exists()):
        raise Skip("Mayor owner-journal sources unavailable")
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        s = m.r17_written_seal_witness(new, old, tmp)["scenarios"]
    assert s["clean_new"]["verifier_ok"] and s["clean_new"]["status"] == "closed"
    assert (s["clean_new"]["accepted_a"], s["clean_new"]["accepted_c"]) == (True, False)
    late = s["late_terminal_first_final_flush_new"]
    assert late["verifier_ok"] and late["to_thread_calls"].count("write") == 3
    old_late = s["late_terminal_first_final_flush_a4ec"]
    assert old_late["status"] == "closed" and not old_late["verifier_ok"]
    assert old_late["file_ledger_rows"] == old_late["status_final_sequence"] - 1
    assert s["terminal_after_status_capture_new"]["status"] == "failed"
    both = s["late_terminals_both_final_flushes_new"]
    assert both["status"] == "failed" and both["status_unflushed"] == 2    # ledger + outcome rows
    assert both["status_producer_final_sequence"] == both["status_final_sequence"] + 1
    foreign = s["append_foreign_nonledger_row_new"]
    assert foreign["status"] == "closed" and foreign["verifier_failures"] == dict(foreign_run_rows=1)
    refusal = s["none_mark_and_closing_refusal_new"]
    assert not refusal["accepted_none_mark"] and not refusal["accepted_while_closing"]
    assert refusal["file_ledger_rows"] == 1 and all(
        r["request_id"] is None for r in refusal["refusal_rows"])
    assert s["reseal_tampered_reject_cost"]["verifier_failures"] == dict(
        budget_reject_within_budget=1)


def test_r17_source144_count16_not_runnable_unchanged():
    import subprocess
    import tempfile
    repo, rev = _MAYOR / "mpc-native-integration", "144cef32a9b51c3a74355ff67f5eafdfac6e075f"
    new = _MAYOR / "mpc-native-owner-written-journal" / "gateway.py"
    if not (repo.exists() and new.exists()):
        raise Skip("Source144 / owner-written sources unavailable")
    paths = ("gateway.py", "experiments/mpc-research/native-v2/launch_batch_service.py",
             "experiments/mpc-research/native-v3/collect_identification.py")
    with tempfile.TemporaryDirectory() as tmp:
        files = []
        for i, rel in enumerate(paths):
            out = Path(tmp) / f"{i}.py"
            out.write_bytes(subprocess.run(["git", "-C", str(repo), "show", f"{rev}:{rel}"],
                                           check=True, capture_output=True).stdout)
            files.append(out)
        r = m.r17_count16_feasibility(*files, new)
    burst = r["gateway"]["executed_bursts"]["protected16_cost1e6"]
    assert (burst["in_flight"], burst["waiting"], burst["returned_rejected"]) == (16, 2, 2)
    assert burst["after_one_finish"] == dict(in_flight=16, waiting=1)
    assert r["gateway"]["executed_bursts"]["cost_aware16_cost1e6"]["returned_rejected"] == 20
    assert r["gateway"]["uuid_tag_injection"]["active_in_protected"]
    assert "ADMISSION_MODE" not in r["gateway"]["uuid_tag_injection"]["test_names"]
    assert r["gateway"]["mpc_access"]["protected"]["status_code"] == 409
    assert r["launcher"]["native_scheduler"]["--max-num-seqs"] == "32"
    assert not r["runnable_unchanged"] and len(r["blockers"]) == 4


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    skipped = 0
    for test in tests:
        try:
            test()
            print("PASS", test.__name__)
        except Skip as reason:
            skipped += 1
            print("SKIP", test.__name__, reason)
    print(f"{len(tests) - skipped} passed, {skipped} skipped")
