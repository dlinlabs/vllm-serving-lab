"""Adversarial CPU contracts only; fixtures are not native measurements."""

import copy
import asyncio
import hashlib
import itertools
import json
import statistics
import unittest

from native_experiment_audit import (
    CaptureReceiptBridge, OfferedReceiptHistory, OnlineModelInputAdapter, audit_arm, comparison_digest, paired_effect,
    batch_progress_input_refusal, evolving_batch_progress, fit_batch_progress_artifacts,
    output_counter_stayer_diagnostic,
    audit_controlled_cohort, controlled_cohort_spec,
    _capture_reference_source, TaggedNativeInputAdapter, audit_gateway_ledger_prefix,
    audit_gateway_ledger_boundaries, controlled_geometry_proposals,
    load_source144_replica, _register_source144, SOURCE144_BINDING, SOURCE144_IDENTITY,
    controlled_dispatch_preflight, controlled_window_bounds,
    audit_owner_journal_epoch, OWNER_JOURNAL_GATEWAY_SHA256,
    audit_written_journal_seal, WRITTEN_JOURNAL_GATEWAY_SHA256, audit_server_counter_bracket,
    cap_plan_support_audit, future_api_good_partition, train_schema_audit, work_accounting,
)


def uid(value):
    return hashlib.sha256(value.encode()).hexdigest()[:32]


class ReceiptClock:
    def __init__(self):
        self.value = 0.

    def __call__(self):
        return self.value


class CallbackReplay:
    """Deterministic callback publications only; no native-file receipt reconstruction."""

    def __init__(self):
        self.clock = ReceiptClock()
        self.history = OfferedReceiptHistory(
            publisher_run_id=uid("callback-publisher"),
            observer_run_id=uid("callback-observer"), clock_domain="test-clock",
            clock=self.clock)
        self.sequence = 0

    def callback(self, kind, rid, event_at, published_at, received_at, **fields):
        publication = dict(
            schema=OfferedReceiptHistory.SCHEMA, publisher_run_id=uid("callback-publisher"),
            clock_domain="test-clock", publication_seq=self.sequence + 1,
            kind=kind, request_id=rid, event_at=event_at, published_at=published_at,
            **fields)
        self.clock.value = received_at
        receipt = self.history.receive(publication)
        self.sequence += 1
        return receipt

    def offered(self, rid, event, published, received, scheduled, cost):
        return self.callback("offered", rid, event, published, received,
                             scheduled_at=scheduled, original_cost=cost,
                             cost_spec_sha256="a" * 64)

    def cut(self, at, *, now=None):
        if now is not None:
            self.clock.value = now
        return self.history.cut(at)


class OfferedReceiptTests(unittest.TestCase):
    def replay(self):
        replay = CallbackReplay()
        a, b, c = (uid(name) for name in ("callback-a", "callback-b", "callback-c"))
        replay.offered(a, 0., .01, .02, .1, 2.)
        replay.offered(b, .03, .04, .05, .2, 3.)
        replay.offered(c, .06, .07, .08, .3, 5.)
        replay.callback("sent", a, .1, .11, .12)
        replay.callback("terminal", b, .15, .16, .17, status="cancelled")
        replay.callback("sent", c, .5, .51, .52)
        replay.callback("terminal", c, .55, .56, .57, status="rejected")
        replay.callback("first", a, .6, .61, .62)
        replay.callback("terminal", a, .7, .71, .72, status="complete")
        return replay

    def test_callback_replay_is_deterministic_and_keeps_unsent_rejected_and_late_offers(self):
        first, second = self.replay().cut(1., now=1.), self.replay().cut(1., now=1.)
        self.assertEqual(first, second)
        self.assertEqual(first["counts"]["offered"], 3)
        self.assertEqual(first["counts"]["sent"], 2)
        self.assertEqual(first["counts"]["late_sent"], 1)
        self.assertEqual(first["counts"]["pending"], 0)
        self.assertEqual(first["counts"]["terminal"],
                         dict(complete=1, rejected=1, cancelled=1, failed=0, timeout=0))
        self.assertEqual([r["original_cost"] for r in first["requests"]], [2., 3., 5.])
        self.assertIsNone(first["requests"][1]["sent"])
        self.assertEqual(first["requests"][0]["first"]["published_at"], .61)
        self.assertEqual(first["requests"][0]["first"]["received_at"], .62)
        self.assertFalse(first["active_mpc_permit"])
        self.assertFalse(first["independent_native_eos_verified"])

    def test_delayed_first_publication_cannot_backfill_a_cut_or_expose_future_terminal(self):
        replay = CallbackReplay()
        rid = uid("delayed")
        replay.offered(rid, 0., .01, .02, .1, 2.)
        replay.callback("sent", rid, .1, .11, .12)
        sealed = replay.cut(.3, now=.3)
        replay.callback("first", rid, .2, .5, .6)
        self.assertEqual(replay.cut(.3), sealed)
        self.assertIsNone(sealed["requests"][0]["first"])
        replay.callback("terminal", rid, .7, .8, .9, status="complete")
        before_terminal = replay.cut(.65, now=1.)
        self.assertIsNone(before_terminal["requests"][0]["terminal"])
        self.assertEqual(before_terminal["requests"][0]["first"]["event_at"], .2)
        self.assertEqual(before_terminal["requests"][0]["first"]["received_at"], .6)
        self.assertEqual(before_terminal["counts"]["pending"], 1)

    def test_due_offer_filter_and_equal_clock_seals_do_not_leak_later_publications(self):
        replay = CallbackReplay()
        rid = uid("future-intent")
        replay.offered(rid, 0., .01, .02, 1., 2.)
        replay.callback("terminal", rid, .1, .11, .12, status="cancelled")
        early = replay.cut(.5, now=.5)
        self.assertEqual(early["counts"]["offered"], 0)
        due = replay.cut(1., now=1.)
        self.assertEqual(due["counts"]["terminal"]["cancelled"], 1)
        tied = CallbackReplay()
        sealed = tied.cut(1., now=1.)
        tied.offered(uid("same-tick"), .8, .9, 1., 1., 2.)
        self.assertEqual(tied.cut(1.), sealed)
        self.assertEqual(sealed["receipt_watermark"], 0)
        self.assertEqual(tied.cut(1.1, now=1.1)["receipt_watermark"], 1)
        with self.assertRaisesRegex(ValueError, "Future"):
            tied.cut(1.2)
        with self.assertRaisesRegex(ValueError, "regressing"):
            tied.cut(1.)

    def test_publications_and_returned_cuts_cannot_mutate_original_cost_or_history(self):
        replay = CallbackReplay()
        rid = uid("immutable")
        returned = replay.offered(rid, 0., .01, .02, .1, 2.)
        returned["original_cost"] = 999
        snapshot = replay.cut(.2, now=.2)
        snapshot["requests"][0]["original_cost"] = 999
        self.assertEqual(replay.cut(.2)["requests"][0]["original_cost"], 2.)
        with self.assertRaisesRegex(ValueError, "UUID reused"):
            replay.offered(rid, .21, .22, .23, .1, 3.)
        with self.assertRaisesRegex(ValueError, "schema"):
            replay.callback("sent", rid, .21, .22, .23, original_cost=3.)
        replay.callback("sent", rid, .21, .22, .23)
        replay.callback("terminal", rid, .24, .25, .26, status="failed")
        with self.assertRaisesRegex(ValueError, "after terminal"):
            replay.callback("first", rid, .27, .28, .29)
        self.assertEqual(replay.cut(.3, now=.3)["requests"][0]["original_cost"], 2.)

    def test_sequence_identity_clock_and_lifecycle_chronology_fail_closed(self):
        for mutation in ("gap", "publisher", "domain", "future", "cost", "receive_stamp"):
            replay = CallbackReplay()
            publication = dict(
                schema=OfferedReceiptHistory.SCHEMA, publisher_run_id=uid("callback-publisher"),
                clock_domain="test-clock", publication_seq=1, kind="offered",
                request_id=uid("invalid"), event_at=0., published_at=.1,
                scheduled_at=.2, original_cost=2., cost_spec_sha256="a" * 64)
            replay.clock.value = .2
            if mutation == "gap":
                publication["publication_seq"] = 2
            elif mutation == "publisher":
                publication["publisher_run_id"] = uid("foreign")
            elif mutation == "domain":
                publication["clock_domain"] = "foreign-clock"
            elif mutation == "future":
                publication["published_at"] = .3
            elif mutation == "cost":
                publication["original_cost"] = True
            else:
                publication["received_at"] = .15
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                replay.history.receive(publication)
            self.assertEqual(replay.cut(.2)["receipt_watermark"], 0)
        replay = CallbackReplay()
        rid = uid("chronology")
        replay.offered(rid, .1, .11, .12, .2, 2.)
        with self.assertRaisesRegex(ValueError, "precedes send"):
            replay.callback("first", rid, .13, .14, .15)
        with self.assertRaisesRegex(ValueError, "scheduled"):
            replay.callback("sent", rid, .16, .17, .18)
        replay.callback("sent", rid, .2, .21, .22)
        with self.assertRaisesRegex(ValueError, "regressed"):
            replay.callback("terminal", rid, .19, .23, .24, status="timeout")
        replay.clock.value = .1
        with self.assertRaisesRegex(ValueError, "clock regressed"):
            replay.cut(.2)

    def test_final_rows_are_not_receipts_and_terminal_complete_is_not_endpoint_authority(self):
        replay = CallbackReplay()
        with self.assertRaisesRegex(ValueError, "final rows are not receipts"):
            replay.history.receive(arm()["rows"][0])
        rid = uid("empty-complete")
        replay.offered(rid, 0., .01, .02, .1, 2.)
        replay.callback("sent", rid, .1, .11, .12)
        replay.callback("terminal", rid, .2, .21, .22, status="complete")
        result = replay.cut(.3, now=.3)
        self.assertIsNone(result["requests"][0]["first"])
        self.assertEqual(result["counts"]["terminal"]["complete"], 1)
        self.assertFalse(result["publisher_complete_through_cut"])
        self.assertFalse(result["callback_source_authenticated"])
        self.assertFalse(result["independent_native_eos_verified"])

    def test_missing_cost_is_explicit_unknown_not_zero_or_post_outcome_imputation(self):
        replay = CallbackReplay()
        rid = uid("unknown-cost")
        replay.callback("offered", rid, 0., .01, .02, scheduled_at=.1,
                        original_cost=None, cost_spec_sha256=None)
        replay.callback("terminal", rid, .2, .21, .22, status="cancelled")
        result = replay.cut(.3, now=.3)
        self.assertEqual(result["counts"]["offered"], 1)
        self.assertEqual(result["counts"]["unknown_original_cost"], 1)
        self.assertIsNone(result["requests"][0]["original_cost"])
        self.assertIsNone(result["requests"][0]["cost_spec_sha256"])
        with self.assertRaisesRegex(ValueError, "schema"):
            replay.callback("terminal", rid, .31, .32, .33, status="cancelled", original_cost=2.)


class CaptureTimeline:
    def __init__(self):
        self.now = 0.
        self.reads = []

    def clock(self, name):
        def read():
            self.now += .001
            self.reads.append((name, self.now))
            return self.now
        return read


class CaptureBridgeIntegrationTests(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls):
        import importlib
        import sys
        from pathlib import Path

        root = Path("/home/daniel_lin/gt/pr32/mayor/mpc-native-integration")
        sys.path.insert(0, str(root))
        cls.capture_module = importlib.import_module("mpc_lab.http_capture")
        actual, reference, live_matches = _capture_reference_source(Path(cls.capture_module.__file__))
        if not live_matches:
            from types import ModuleType
            cls.capture_module = ModuleType("mpc_lab._frozen_capture_r8")
            cls.capture_module.__file__ = reference
            cls.capture_module.__package__ = "mpc_lab"
            sys.modules[cls.capture_module.__name__] = cls.capture_module
            exec(compile(actual, reference, "exec"), cls.capture_module.__dict__)
        import httpx
        cls.httpx = httpx

    def bridge(self, timeline, **kwargs):
        return CaptureReceiptBridge(
            publisher_run_id=uid("r8-publisher"), observer_run_id=uid("r8-observer"),
            clock_domain="r8-clock", publisher_clock=timeline.clock("publisher"),
            observer_clock=timeline.clock("observer"), **kwargs)

    def payload(self):
        return dict(model="cpu-fixture", max_tokens=2,
                    messages=[dict(role="user", content="unit fixture")])

    async def capture(self, bridge, timeline, transport, rid, **kwargs):
        async with self.httpx.AsyncClient(transport=transport) as client:
            return await self.capture_module.capture_chat(
                client, "https://capture-fixture.invalid/v1/chat/completions",
                self.payload(), rid, kwargs.pop("scheduled_at", 0.),
                enabled=True, domain=kwargs.pop("domain", "r8-clock"),
                clock=timeline.clock("capture"), observe=kwargs.pop("observe", bridge.observe),
                **kwargs)

    def stream(self, after_first=None):
        httpx = self.httpx

        class SSE(httpx.AsyncByteStream):
            async def __aiter__(self):
                yield b'data: {"choices":[{"index":0,"delta":{"content":"hello"}}]}\n\n'
                if after_first is not None:
                    after_first()
                yield (b'data: {"choices":[{"index":0,"delta":{},"finish_reason":"stop"}],'
                       b'"usage":{"prompt_tokens":128,"completion_tokens":2}}\n\n'
                       b'data: [DONE]\n\n')
        return SSE()

    def public_metadata(self):
        return dict(schema="native-v3-public-payload-v1", requested_max_tokens=2,
                    prompt_class="short", prompt_token_estimate=100,
                    source_sha256="b" * 64, prompt_estimator_sha256="c" * 64)

    def model_adapter(self, timeline, bridge):
        from mpc_lab.contracts import CostSpec, Identity
        from mpc_lab.native_state import NativeBinding
        binding = NativeBinding(
            "r8-clock", "gateway-run", "native-run", "d" * 64,
            Identity("unfitted", "unqualified", "support", CostSpec().fingerprint, "core"))
        return OnlineModelInputAdapter(bridge, binding, clock=timeline.clock("model-observer"))

    def native_frame(self, timeline, adapter, rid, sequence=1):
        from mpc_lab.contracts import RequestMark, Snapshot
        from mpc_lab.runtime import snapshot_to_dict
        t = timeline.now
        snapshot = Snapshot(
            "gateway-run", "r8-clock", t, 16., 0,
            (RequestMark(rid, 17., 100, 2, t, t),),
            adapter._binding.identity, sequence=sequence)
        return dict(
            schema="pr33-native-read-only-v1", clock_domain="r8-clock", run_id="native-run",
            observer_sha256="d" * 64, vllm_version="0.30.0",
            gateway_snapshot=snapshot_to_dict(snapshot), complete=True,
            sampled_at=t, frontend_sampled_at=t, received_at=t, gateway_received_at=t,
            running=1, waiting=2, pending_batches=1, frontend_unfinished=4,
            kv_cache_usage=.4,
            requests=[dict(request_id=f"chatcmpl-{rid}-deadbeef", prompt_tokens=100,
                           computed_tokens=80, output_tokens=0, maximum_output_tokens=2)])

    def actual_gateway(self, *, source_path=None, settings=None,
                       source_sha256=OWNER_JOURNAL_GATEWAY_SHA256):
        from contextlib import contextmanager, ExitStack
        import importlib.util
        import ast
        import os
        from pathlib import Path
        import sys
        from types import SimpleNamespace
        from unittest.mock import patch

        @contextmanager
        def loaded():
            with ExitStack() as stack:
                stack.enter_context(patch.dict(os.environ, dict(
                    MPC_LAB_ENABLED="true", ADMISSION_MODE="cost_aware", MAX_ADMITTED_COST="80",
                    BENCHMARK_REQUEST_IDS="1", SHARED_UPSTREAM_CLIENT="1",
                    ADMIN_API_KEY="cpu-fixture-key", WEB_CONCURRENCY="1", UVICORN_WORKERS="1",
                    PREFILL_LAB_RAW_COMPLETIONS="0", TELEMETRY_JSONL="", TELEMETRY_STATUS_JSON="")))
                stack.enter_context(patch.dict(os.environ, {"MPC_OWNER_LEDGER_ENABLED": "false",
                                                            **(settings or {})}))

                def offline(*args, **kwargs):
                    raise OSError("CPU test intentionally has no tokenizer")

                stack.enter_context(patch.dict(sys.modules, {"transformers": SimpleNamespace(
                    AutoTokenizer=SimpleNamespace(from_pretrained=offline))}))
                path = Path(source_path or "/home/daniel_lin/gt/pr32/mayor/mpc-native-integration/gateway.py")
                if source_path is not None:
                    self.assertIn(source_sha256, (OWNER_JOURNAL_GATEWAY_SHA256,
                                                 WRITTEN_JOURNAL_GATEWAY_SHA256,
                                                 R17SerializedSourceTests.SOURCE_SHA256))
                    self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),
                                     source_sha256)
                    for name in ("contracts", "runtime"):
                        module_name = "mpc_lab." + name
                        module_spec = importlib.util.spec_from_file_location(
                            module_name, path.parent / "mpc_lab" / (name + ".py"))
                        module = importlib.util.module_from_spec(module_spec)
                        stack.enter_context(patch.dict(sys.modules, {module_name: module}))
                        module_spec.loader.exec_module(module)
                spec = importlib.util.spec_from_file_location("nv3_r10_actual_gateway", path)
                gateway = importlib.util.module_from_spec(spec)
                stack.enter_context(patch.dict(sys.modules, {spec.name: gateway}))
                from starlette.applications import Starlette
                from starlette.requests import Request
                from starlette.responses import JSONResponse, StreamingResponse
                from starlette.routing import Route
                clock_path = path.parent / "prefill_lab/live_http.py"
                self.assertEqual(hashlib.sha256(clock_path.read_bytes()).hexdigest(),
                                 "cbbd1f338e0d078d5c5eacdfbcec725dcfe2ed9b46c1ee1ed68ad2f26de24e1f")
                clock_node = next(n for n in ast.parse(clock_path.read_text()).body
                                  if isinstance(n, ast.FunctionDef) and n.name == "clock_domain")
                clock_globals = dict(Path=Path, os=os)
                exec(compile(ast.Module(body=[clock_node], type_ignores=[]),
                             str(clock_path), "exec"), clock_globals)
                tree = ast.parse(path.read_text(), filename=str(path))
                class ClockImport(ast.NodeTransformer):
                    def visit_ImportFrom(self, node):
                        if node.module == "prefill_lab.live_http" and any(
                                name.asname == "mpc_local_clock_domain" for name in node.names):
                            return None
                        return node
                tree = ClockImport().visit(tree)
                body = []
                for node in tree.body:
                    if isinstance(node, ast.ImportFrom) and node.module in ("fastapi", "fastapi.responses"):
                        continue
                    if isinstance(node, ast.Assign) and any(
                            isinstance(target, ast.Name) and target.id == "app" for target in node.targets):
                        continue
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        node.decorator_list = [
                            d for d in node.decorator_list if not (
                                isinstance(d, ast.Call) and isinstance(d.func, ast.Attribute)
                                and isinstance(d.func.value, ast.Name) and d.func.value.id == "app")]
                    body.append(node)
                gateway.__dict__.update(
                    Request=Request, JSONResponse=JSONResponse, StreamingResponse=StreamingResponse,
                    app=Starlette(), mpc_local_clock_domain=clock_globals["clock_domain"],
                    clock_domain=clock_globals["clock_domain"])
                exec(compile(ast.Module(body=body, type_ignores=[]), str(path), "exec"), gateway.__dict__)

                async def state_endpoint(request):
                    result = await gateway.mpc_snapshot(request)
                    return JSONResponse(result) if isinstance(result, dict) else result

                gateway.app.routes.extend([
                    Route("/v1/chat/completions", gateway.proxy_chat_completions, methods=["POST"]),
                    Route("/admin/mpc/state", state_endpoint, methods=["GET"])])
                gateway.telemetry.enabled = True
                yield gateway
        return loaded()

    def actual_gateway_adapter(self, gateway, rid):
        from mpc_lab.native_state import NativeBinding
        bridge = CaptureReceiptBridge(
            publisher_run_id=uid("r10-publisher"), observer_run_id=uid("r10-observer"),
            clock_domain=gateway.mpc_clock_domain)
        # Historical R8 callbacks + independently versioned changed Gateway producer.
        adapter = TaggedNativeInputAdapter(bridge, NativeBinding(
            gateway.mpc_clock_domain, gateway.telemetry.run_id, "cpu-native-run",
            "d" * 64, gateway.mpc_identity))
        bridge.register(rid, 0., original_offered_estimate=42.,
                        estimate_provenance=dict(source_sha256="a" * 64))
        return bridge, adapter

    def frame_from_real_gateway(self, gateway, snapshot, rid):
        import time
        now = time.monotonic()
        return dict(
            schema="pr33-native-read-only-v1", clock_domain=gateway.mpc_clock_domain,
            run_id="cpu-native-run", observer_sha256="d" * 64, vllm_version="0.30.0",
            gateway_snapshot=copy.deepcopy(snapshot), complete=True, sampled_at=now,
            frontend_sampled_at=now, received_at=now, gateway_received_at=now,
            running=1, waiting=0, pending_batches=0, frontend_unfinished=1,
            kv_cache_usage=.1, requests=[dict(
                request_id=f"opaque-native-{rid}", prompt_tokens=100,
                computed_tokens=80, output_tokens=0, maximum_output_tokens=2)])

    async def test_r10_actual_gateway_uuid_trace_before_outcome_and_snapshot_races(self):
        import time
        rid = uid("r10-trace")
        with self.actual_gateway() as gateway:
            bridge, adapter = self.actual_gateway_adapter(gateway, rid)
            saved = {}
            async with self.httpx.AsyncClient(
                    transport=self.httpx.ASGITransport(app=gateway.app),
                    base_url="https://gateway-fixture.invalid") as downstream:
                initial = (await downstream.get("/admin/mpc/state", headers={
                    "x-admin-api-key": "cpu-fixture-key"})).json()

                async def upstream(request):
                    self.assertEqual(request.headers["x-request-id"], rid)
                    self.assertNotIn("x-benchmark-request-id", request.headers)
                    self.assertIn(rid, gateway.benchmark_ids)
                    events = [r for r in gateway.telemetry.records if r.get("request_id") == rid]
                    self.assertEqual([r["event"] for r in events],
                                     ["received", "accepted", "backend_sent"])
                    proof = adapter.receive_gateway_uuid_binding(gateway, rid)
                    self.assertTrue(proof["accepted_observed"])
                    proof["accepted_observed"] = False
                    adapter.receive_native(self.frame_from_real_gateway(gateway, initial, rid))
                    self.assertEqual(adapter.cut(saved["pre"]["cut_at"]), saved["pre"])
                    before_charge = adapter.cut(time.monotonic())
                    item = before_charge["attempts"][0]
                    self.assertTrue(item["known_gateway_accepted"])
                    self.assertFalse(item["readmission_allowed"])
                    self.assertIsNone(item["actual_gateway_charge"])
                    snapshot = (await downstream.get("/admin/mpc/state", headers={
                        "x-admin-api-key": "cpu-fixture-key"})).json()
                    adapter.receive_native(self.frame_from_real_gateway(gateway, snapshot, rid))
                    self.assertEqual(adapter.cut(before_charge["cut_at"]), before_charge)
                    saved["joined"] = adapter.cut(time.monotonic())
                    saved["charge"] = snapshot["requests"][0]["cost"]
                    self.assertEqual(snapshot["requests"][0]["request_id"], rid)
                    self.assertIsNone(snapshot["requests"][0]["scheduled_at"])
                    item = saved["joined"]["attempts"][0]
                    self.assertEqual(item["actual_gateway_charge"], saved["charge"])
                    self.assertNotEqual(item["original_offered_estimate"], saved["charge"])
                    self.assertTrue(item["gateway_owned_at_last_sample"])
                    self.assertIsNone(item["engine_request_id"])
                    self.assertIsNone(item["first"])
                    self.assertIsNone(item["terminal"])
                    return self.httpx.Response(
                        200, headers={"content-type": "text/event-stream",
                                      "x-request-id": "not-native-lineage-proof"},
                        stream=self.stream())

                async with self.httpx.AsyncClient(
                        transport=self.httpx.MockTransport(upstream)) as upstream_client:
                    gateway.app.state.upstream_client = upstream_client

                    def observe(kind, receipt):
                        bridge.observe(kind, receipt)
                        if kind == "offered":
                            saved["pre"] = adapter.cut(time.monotonic())

                    row = await self.capture_module.capture_chat(
                        downstream, "/v1/chat/completions", self.payload(), rid, 0.,
                        enabled=True, domain=gateway.mpc_clock_domain, observe=observe)
                    self.assertEqual(row["status"], "complete")
                    self.assertEqual(row["response_request_id"], rid)
                    final_snapshot = (await downstream.get("/admin/mpc/state", headers={
                        "x-admin-api-key": "cpu-fixture-key"})).json()
                    self.assertEqual(final_snapshot["requests"], [])
                    adapter.receive_native(self.frame_from_real_gateway(gateway, final_snapshot, rid))
                    self.assertEqual(adapter.cut(saved["joined"]["cut_at"]), saved["joined"])
                    final = adapter.cut(time.monotonic())
                    item = final["attempts"][0]
                    self.assertTrue(item["known_gateway_accepted"])
                    self.assertFalse(item["readmission_allowed"])
                    self.assertFalse(item["gateway_owned_at_last_sample"])
                    self.assertEqual(item["actual_gateway_charge"], saved["charge"])
                    self.assertIsNone(item["engine_request_id"])
                    self.assertFalse(final["callback_source_authenticated"])
                    self.assertFalse(final["independent_native_eos_verified"])
                    self.assertIsNone(final["v5_input"])
                    with self.assertRaisesRegex(ValueError, "pre-terminal"):
                        adapter.receive_gateway_uuid_binding(gateway, rid)

    async def test_r10_wrong_source_domain_configuration_and_missing_header_proof_refuse(self):
        from unittest.mock import patch
        rid = uid("r10-refusal")
        with self.actual_gateway() as gateway:
            bridge, adapter = self.actual_gateway_adapter(gateway, rid)
            with self.assertRaisesRegex(ValueError, "Actual Gateway module"):
                adapter.receive_gateway_uuid_binding({}, rid)
            with patch.object(gateway, "__file__", __file__):
                with self.assertRaisesRegex(ValueError, "source mismatch"):
                    adapter.receive_gateway_uuid_binding(gateway, rid)
            with patch.object(gateway, "mpc_clock_domain", "foreign"):
                with self.assertRaisesRegex(ValueError, "run/domain/identity"):
                    adapter.receive_gateway_uuid_binding(gateway, rid)
            with patch.object(gateway, "BENCHMARK_REQUEST_IDS", False):
                with self.assertRaisesRegex(ValueError, "configuration"):
                    adapter.receive_gateway_uuid_binding(gateway, rid)
            with self.assertRaisesRegex(ValueError, "actual pre-terminal"):
                adapter.receive_gateway_uuid_binding(gateway, rid)
            def observe(kind, receipt):
                bridge.observe(kind, receipt)
                if kind == "offered":
                    with self.assertRaisesRegex(ValueError, "validated benchmark UUID"):
                        adapter.receive_gateway_uuid_binding(gateway, rid)

            async with self.httpx.AsyncClient(transport=self.httpx.MockTransport(
                    lambda request: self.httpx.Response(
                        200, headers={"content-type": "text/event-stream", "x-request-id": rid},
                        stream=self.stream()))) as client:
                await self.capture_module.capture_chat(
                    client, "https://fixture.invalid/v1/chat/completions", self.payload(), rid, 0.,
                    enabled=True, domain=gateway.mpc_clock_domain, observe=observe)
            self.assertEqual(adapter._gateway_bindings, {})

    async def test_r10_bound_charge_mutation_refuses_without_changing_sealed_cut(self):
        import time
        rid = uid("r10-charge")
        with self.actual_gateway() as gateway:
            bridge, adapter = self.actual_gateway_adapter(gateway, rid)
            async with self.httpx.AsyncClient(
                    transport=self.httpx.ASGITransport(app=gateway.app),
                    base_url="https://gateway-fixture.invalid") as downstream:

                async def upstream(request):
                    adapter.receive_gateway_uuid_binding(gateway, rid)
                    snapshot = (await downstream.get("/admin/mpc/state", headers={
                        "x-admin-api-key": "cpu-fixture-key"})).json()
                    adapter.receive_native(self.frame_from_real_gateway(gateway, snapshot, rid))
                    good = adapter.cut(time.monotonic())
                    snapshot["requests"][0]["cost"] += 1.
                    adapter.receive_native(self.frame_from_real_gateway(gateway, snapshot, rid))
                    self.assertEqual(adapter.cut(good["cut_at"]), good)
                    with self.assertRaisesRegex(ValueError, "original Gateway owner"):
                        adapter.cut(time.monotonic())
                    return self.httpx.Response(
                        200, headers={"content-type": "text/event-stream"}, stream=self.stream())

                async with self.httpx.AsyncClient(
                        transport=self.httpx.MockTransport(upstream)) as upstream_client:
                    gateway.app.state.upstream_client = upstream_client
                    row = await self.capture_module.capture_chat(
                        downstream, "/v1/chat/completions", self.payload(), rid, 0.,
                        enabled=True, domain=gateway.mpc_clock_domain, observe=bridge.observe)
                    self.assertEqual(row["status"], "complete")

    async def test_r9_actual_capture_and_parent_state_build_only_receipt_visible_inputs(self):
        timeline = CaptureTimeline()
        bridge = self.bridge(timeline)
        adapter = self.model_adapter(timeline, bridge)
        rid = uid("r9-live")
        metadata = self.public_metadata()
        bridge.register(rid, 0., original_offered_estimate=2.,
                        estimate_provenance=dict(source_sha256="a" * 64),
                        public_metadata=metadata)
        metadata["requested_max_tokens"] = 999
        bridge.register(uid("r9-planned-only"), 10., public_metadata=self.public_metadata())
        frame = self.native_frame(timeline, adapter, rid)
        native_receipt = adapter.receive_native(frame)
        self.assertGreater(native_receipt["received_at"], frame["received_at"])
        frame["requests"][0]["computed_tokens"] = 999
        saved = {}

        def during_sse():
            saved["at"] = timeline.now
            saved["view"] = adapter.cut(saved["at"])
            self.assertIsNotNone(saved["view"]["attempts"][0]["first"])
            self.assertIsNone(saved["view"]["attempts"][0]["terminal"])

        def handler(request):
            view = adapter.cut(timeline.now)
            self.assertEqual(len(view["attempts"]), 1)
            self.assertEqual(view["past_offered_payload_mix"], [(2, 1)])
            self.assertEqual(view["past_offered_public_payload_mix"],
                             [dict(public_metadata=self.public_metadata(), count=1)])
            self.assertIsNone(view["attempts"][0]["first"])
            self.assertEqual(view["native"]["gateway"]["requests"][0]["cost"], 17.)
            self.assertEqual(view["attempts"][0]["original_offered_estimate"], 2.)
            self.assertIsNone(view["attempts"][0]["actual_gateway_charge"])
            self.assertEqual(view["native"]["progress"][0]["computed_tokens"], 80)
            self.assertEqual(view["native"]["waiting"], 2)
            self.assertIsNone(view["native"]["waiting_work"])
            self.assertIsNone(view["native"]["accepted_not_native_visible_work"])
            self.assertLessEqual(view["native"]["received_at"], view["cut_at"])
            self.assertIsNone(view["attempts"][0]["engine_request_id"])
            return self.httpx.Response(
                200, headers={"content-type": "text/event-stream", "x-request-id": rid},
                stream=self.stream(during_sse))

        row = await self.capture(bridge, timeline, self.httpx.MockTransport(handler), rid)
        self.assertEqual(row["status"], "complete")
        later = self.native_frame(timeline, adapter, rid, sequence=2)
        later["requests"][0]["computed_tokens"] = 101
        adapter.receive_native(later)
        self.assertEqual(adapter.cut(saved["at"]), saved["view"])
        final = adapter.cut(timeline.now)
        self.assertEqual(final["attempts"][0]["terminal"]["status"], "complete")
        self.assertIsNone(final["attempts"][0]["engine_request_id"])
        self.assertIsNone(final["v5_input"])
        self.assertEqual(final["native"]["progress"][0]["computed_tokens"], 101)
        final["native"]["progress"][0]["computed_tokens"] = 999
        final["attempts"][0]["public_metadata"]["prompt_token_estimate"] = 999
        sealed = adapter.cut(final["cut_at"])
        self.assertEqual(sealed["native"]["progress"][0]["computed_tokens"], 101)
        self.assertEqual(sealed["attempts"][0]["public_metadata"]["prompt_token_estimate"], 100)
        for item in sealed["attempts"]:
            self.assertLessEqual(item["registration_received_at"], sealed["cut_at"])
            self.assertLessEqual(item["sent_received_at"], sealed["cut_at"])
        self.assertFalse(sealed["publisher_complete_through_cut"])
        self.assertFalse(sealed["callback_source_authenticated"])
        self.assertFalse(sealed["independent_native_eos_verified"])
        self.assertFalse(sealed["active_mpc_permit"])

    async def test_r9_registration_is_explicitly_versioned_and_not_reinterpreted_as_v1(self):
        timeline = CaptureTimeline()
        bridge = None
        publications = []

        def deliver(publication):
            publications.append(copy.deepcopy(publication))
            return bridge.history.receive(publication)

        bridge = self.bridge(timeline, deliver=deliver)
        bridge.register(uid("r9-v2"), 0., public_metadata=self.public_metadata())
        bridge.register(uid("r9-v1"), 0.)
        self.assertEqual(publications[0]["schema"], OfferedReceiptHistory.REGISTRATION_V2)
        self.assertEqual(publications[1]["schema"], OfferedReceiptHistory.SCHEMA)
        self.assertNotIn("public_metadata", bridge.cut(timeline.now)["requests"][1])
        wrong = copy.deepcopy(publications[0])
        wrong["schema"] = OfferedReceiptHistory.SCHEMA
        history = OfferedReceiptHistory(
            publisher_run_id=uid("r8-publisher"), observer_run_id=uid("r8-observer"),
            clock_domain="r8-clock", clock=timeline.clock("other-consumer"))
        with self.assertRaisesRegex(ValueError, "schema"):
            history.receive(wrong)
        wrong = copy.deepcopy(publications[1])
        wrong["schema"] = OfferedReceiptHistory.REGISTRATION_V2
        with self.assertRaisesRegex(ValueError, "schema"):
            history.receive(wrong)
        for change in (dict(prompt_text="not accepted"),
                       dict(requested_max_tokens=True), dict(prompt_class="free text"),
                       dict(prompt_token_estimate=10 ** 400),
                       dict(prompt_estimator_sha256=None)):
            with self.subTest(change=list(change)):
                other = self.bridge(CaptureTimeline())
                metadata = self.public_metadata() | change
                with self.assertRaises(ValueError):
                    other.register(uid("r9-invalid"), 0., public_metadata=metadata)

    async def test_r9_native_receiver_refuses_future_cross_source_stale_and_unbound_inputs(self):
        timeline = CaptureTimeline()
        bridge = self.bridge(timeline)
        adapter = self.model_adapter(timeline, bridge)
        rid = uid("r9-native-validation")
        frame = self.native_frame(timeline, adapter, rid)
        for change in (dict(received_at=10.), dict(run_id="foreign"),
                       dict(clock_domain="foreign"), dict(observer_sha256="e" * 64)):
            with self.subTest(change=change):
                with self.assertRaises(ValueError):
                    adapter.receive_native(frame | change)
        before = adapter.cut(timeline.now)
        self.assertEqual(before["native_refusal"], "native_observation_missing")
        receipt = adapter.receive_native(frame)
        with self.assertRaisesRegex(ValueError, "frame required"):
            adapter.receive_native(receipt["state"])
        self.assertEqual(adapter.cut(before["cut_at"]), before)
        with self.assertRaisesRegex(ValueError, "regressed or reused"):
            adapter.receive_native(frame)
        timeline.now += 1.
        view = adapter.cut(timeline.now)
        self.assertIsNone(view["native"])
        self.assertEqual(view["native_refusal"], "native_observation_stale")
        with self.assertRaises(ValueError):
            adapter.cut(view["cut_at"], history_window_s=10.)
        with self.assertRaises(ValueError):
            adapter.cut(timeline.now + 10.)

    async def test_r9_missing_public_metadata_and_disappearance_never_invent_cost_or_eos(self):
        timeline = CaptureTimeline()
        bridge = self.bridge(timeline)
        adapter = self.model_adapter(timeline, bridge)
        rid = uid("r9-unknown-pending")
        bridge.register(rid, 0., original_offered_estimate=None)
        adapter.receive_native(self.native_frame(timeline, adapter, rid))
        saved = {}

        def during_sse():
            gone = self.native_frame(timeline, adapter, rid, sequence=2)
            gone["gateway_snapshot"]["requests"] = []
            gone["running"], gone["requests"] = 0, []
            adapter.receive_native(gone)
            saved["view"] = adapter.cut(timeline.now)

        transport = self.httpx.MockTransport(lambda request: self.httpx.Response(
            200, headers={"content-type": "text/event-stream", "x-request-id": rid},
            stream=self.stream(during_sse)))
        await self.capture(bridge, timeline, transport, rid)
        view = saved["view"]
        self.assertEqual(view["past_offered_payload_mix"], [])
        self.assertEqual(view["unknown_payload_attempts"], 1)
        self.assertEqual(view["native"]["gateway"]["requests"], ())
        self.assertEqual(len(view["pending_client_attempts"]), 1)
        self.assertEqual(view["pending_client_attempts"][0]["gateway_status"], "unknown")
        self.assertIsNone(view["pending_client_attempts"][0]["actual_gateway_charge"])
        self.assertIsNone(view["pending_client_attempts"][0]["terminal"])
        self.assertEqual(adapter.cut(view["cut_at"]), view)

    async def test_r9_wrong_registered_payload_latches_measurement_error_not_http_failure(self):
        timeline = CaptureTimeline()
        bridge = self.bridge(timeline)
        rid = uid("r9-payload-mismatch")
        metadata = self.public_metadata() | dict(requested_max_tokens=3)
        bridge.register(rid, 0., public_metadata=metadata)
        transport = self.httpx.MockTransport(lambda request: self.httpx.Response(
            200, headers={"content-type": "text/event-stream", "x-request-id": rid},
            stream=self.stream()))
        row = await self.capture(bridge, timeline, transport, rid)
        self.assertEqual(row["status"], "complete")
        self.assertEqual(bridge.observation_error, "ValueError")
        self.assertEqual(bridge.cut(timeline.now)["counts"]["offered"], 0)

    def frozen_v5(self):
        import importlib.util
        import sys
        from pathlib import Path
        path = Path("/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d"
                    "/files/pr33-native-v3-round8-frozen/opus/native_release_model.py")
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),
                         "b1d83f7af2956d51b5f9d9b014ecff50b2b3a6915c5f10cdb52f034ed8a920b5")
        spec = importlib.util.spec_from_file_location("nv3_r9_frozen_v5", path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module

    async def test_r9_frozen_v5_pending_readmission_and_conditional_draw_counterexamples(self):
        module = self.frozen_v5()
        cut = dict(cell="fixture", live=[], pending=[(uid("past-pending"), 17., 2, 1.)])
        draw = dict(live_u=[], pending_u=[.5], arrivals=[])
        result = module.simulate_plan(cut, [16.] * 10, draw, {}, {})
        self.assertEqual(result["offers_5"], 0.)
        self.assertEqual(result["rejected_5"], 1.)
        first, dead, last = (2., 1.5, 2.), (.5, None, .5), (3., None, 3.)
        table = {("fixture",): [first, dead, last]}
        draws = [module.kernel_draw(table, [("fixture",)], u, min_alive=1.)[0]
                 for u in (.1, .5, .9)]
        self.assertEqual(draws, [first, last, last])

    async def test_r10_fixed_crn_later_admission_never_updates_live_or_earlier_birth_marks(self):
        module = self.frozen_v5()
        live_key = ("live-fixture",)
        cut = dict(cell="fixture", live=[(uid("live-cohort"), 1., None, [live_key])], pending=[])
        draw = dict(live_u=[.2], pending_u=[], arrivals=[(.1, 2, .3), (.2, 128, .4)])
        kernels = dict(cohort={live_key: [(2., 1.5, 1.5)]},
                       birth={("fixture", 2): [(2., .8, .8)],
                              ("fixture", 128): [(.5, None, .5)]})
        costs = {("fixture", 2): 1., ("fixture", 128): 17.}
        original = module.kernel_draw
        results, traces = {}, {}
        for cap in (16., 32.):
            trace = []

            def observed(table, keys, u, min_alive=None):
                result = original(table, keys, u, min_alive=min_alive)
                trace.append((tuple(keys), u, result))
                return result

            module.kernel_draw = observed
            try:
                results[cap] = module.simulate_plan(cut, [cap] * 10, draw, kernels, costs)
            finally:
                module.kernel_draw = original
            traces[cap] = trace
        self.assertEqual(len(traces[16.]), 2)
        self.assertEqual(len(traces[32.]), 3)
        self.assertEqual(traces[16.], traces[32.][:2])
        self.assertEqual(results[16.]["rejected_5"], 1.)
        self.assertEqual(results[32.]["rejected_5"], 0.)
        for horizon in (1, 3, 5):
            self.assertEqual(results[16.][f"good_{horizon}"], results[32.][f"good_{horizon}"])
        self.assertEqual(results[16.]["good_1"], 1.)
        self.assertEqual(results[16.]["good_3"], 2.)

    async def test_actual_attempt_precedes_post_first_is_visible_during_sse_and_copies_are_nested(self):
        timeline = CaptureTimeline()
        bridge = self.bridge(timeline)
        rid = uid("r8-complete")
        provenance = dict(source_sha256="a" * 64, context=dict(estimator="offer-only"))
        bridge.register(rid, 0., original_offered_estimate=2., estimate_provenance=provenance)
        provenance["context"]["estimator"] = "mutated"
        bridge.register(uid("r8-future-a"), 10.)
        bridge.register(uid("r8-future-b"), 20.)
        registered = bridge.cut(timeline.now)
        self.assertEqual((registered["counts"]["registered"], registered["counts"]["offered"]), (3, 0))
        cuts = {}

        def during_sse():
            cuts["at"] = timeline.now
            cuts["first"] = bridge.cut(cuts["at"])
            self.assertEqual(cuts["first"]["counts"]["first"], 1)
            self.assertIsNone(cuts["first"]["requests"][0]["terminal"])

        def handler(request):
            self.assertEqual(request.method, "POST")
            self.assertTrue(json.loads(request.content)["stream"])
            self.assertEqual(request.headers["x-benchmark-request-id"], rid)
            view = bridge.cut(timeline.now)
            self.assertEqual(view["counts"]["offered"], 1)
            self.assertEqual(view["counts"]["first"], 0)
            self.assertIsNone(view["requests"][0]["terminal"])
            return self.httpx.Response(
                200, headers={"content-type": "text/event-stream", "x-request-id": rid},
                stream=self.stream(during_sse))

        def observe(kind, receipt):
            bridge.observe(kind, receipt)
            if kind == "terminal":
                receipt["usage"]["completion_tokens"] = 999

        row = await self.capture(bridge, timeline, self.httpx.MockTransport(handler), rid,
                                 observe=observe)
        self.assertEqual((row["status"], row["usage"]["completion_tokens"]), ("complete", 2))
        self.assertEqual(bridge.cut(cuts["at"]), cuts["first"])
        final = bridge.cut(timeline.now)
        self.assertEqual((final["counts"]["offered"], final["counts"]["pending"]), (1, 0))
        self.assertEqual(final["counts"]["planned_pending"], 2)
        self.assertEqual(final["counts"]["terminal"]["complete"], 1)
        record = final["requests"][0]
        self.assertIsNone(record["gateway_reservation_charge"])
        self.assertEqual(record["original_offered_estimate"], 2.)
        self.assertEqual(record["estimate_provenance"]["context"]["estimator"], "offer-only")
        self.assertEqual(record["terminal"]["capture"]["row"]["usage"]["completion_tokens"], 2)
        for kind in ("sent", "first", "terminal"):
            stamp = record[kind]
            self.assertLess(stamp["capture"]["row"]["published_at"], stamp["published_at"])
            self.assertLess(stamp["published_at"], stamp["received_at"])
            self.assertEqual(stamp["capture"]["source_sha256"], CaptureReceiptBridge.CAPTURE_SHA256)
        record["terminal"]["capture"]["row"]["usage"]["completion_tokens"] = 777
        final["arrival_attempts"][0]["capture"]["row"]["request_model"] = "changed"
        self.assertEqual(bridge.cut(final["cut_at"])["requests"][0]["terminal"]
                         ["capture"]["row"]["usage"]["completion_tokens"], 2)
        self.assertFalse(final["publisher_complete_through_cut"])
        self.assertFalse(final["callback_source_authenticated"])
        self.assertFalse(final["independent_native_eos_verified"])
        self.assertFalse(final["active_mpc_permit"])

    async def test_real_unsent_cancel_closes_plan_without_actual_offer_or_send(self):
        timeline = CaptureTimeline()
        bridge = self.bridge(timeline)
        rid = uid("r8-unsent-cancel")
        bridge.register(rid, 1000.)
        calls = []
        transport = self.httpx.MockTransport(lambda request: calls.append(request))
        task = asyncio.create_task(self.capture(bridge, timeline, transport, rid, scheduled_at=1000.))
        await asyncio.sleep(0)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        view = bridge.cut(timeline.now)
        self.assertFalse(calls)
        self.assertEqual(view["counts"]["offered"], 0)
        self.assertEqual(view["counts"]["sent"], 0)
        self.assertEqual(view["counts"]["terminal"]["cancelled"], 1)
        self.assertEqual(view["counts"]["unsent_cancelled"], 1)
        self.assertEqual(view["counts"]["planned_due"], 0)
        self.assertIsNone(view["requests"][0]["terminal"]["capture"]["row"]["sent_at"])

    async def test_actual_late_rejection_does_not_recost_unknown_estimate_from_admission_budget(self):
        timeline = CaptureTimeline()
        bridge = self.bridge(timeline)
        rid = uid("r8-rejected")
        bridge.register(rid, 0.)
        body = dict(detail="request rejected: admission capacity exceeded",
                    budget_version=1, max_admitted_cost=32.)
        transport = self.httpx.MockTransport(lambda request: self.httpx.Response(
            503, headers={"x-request-id": rid}, json=body))
        row = await self.capture(bridge, timeline, transport, rid)
        self.assertEqual(row["status"], "rejected")
        view = bridge.cut(timeline.now)
        self.assertEqual(view["counts"]["offered"], 1)
        self.assertEqual(view["counts"]["late_sent"], 1)
        self.assertEqual(view["counts"]["terminal"]["rejected"], 1)
        record = view["requests"][0]
        self.assertIsNone(record["original_offered_estimate"])
        self.assertIsNone(record["gateway_reservation_charge"])
        self.assertEqual(record["terminal"]["capture"]["row"]["admission"]["max_admitted_cost"], 32.)

    async def test_real_cancellation_after_attempt_counts_one_arrival_not_unsent_cancel(self):
        timeline = CaptureTimeline()
        bridge = self.bridge(timeline)
        rid = uid("r8-sent-cancel")
        bridge.register(rid, 0.)
        entered = asyncio.Event()

        async def handler(request):
            entered.set()
            await asyncio.Event().wait()

        task = asyncio.create_task(self.capture(
            bridge, timeline, self.httpx.MockTransport(handler), rid))
        await entered.wait()
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        view = bridge.cut(timeline.now)
        self.assertEqual(view["counts"]["offered"], 1)
        self.assertEqual(view["counts"]["terminal"]["cancelled"], 1)
        self.assertEqual(view["counts"]["unsent_cancelled"], 0)
        self.assertEqual(view["counts"]["pending"], 0)

    async def test_dropped_first_causes_sequence_failure_without_changing_http_success_or_backfill(self):
        timeline = CaptureTimeline()
        bridge = None

        def deliver(publication):
            if publication["kind"] != "first":
                return bridge.history.receive(publication)

        bridge = self.bridge(timeline, deliver=deliver)
        rid = uid("r8-dropped")
        bridge.register(rid, 0.)
        early = {}

        def handler(request):
            early["at"] = timeline.now
            early["view"] = bridge.cut(early["at"])
            return self.httpx.Response(
                200, headers={"content-type": "text/event-stream", "x-request-id": rid},
                stream=self.stream())

        transport = self.httpx.MockTransport(handler)
        row = await self.capture(bridge, timeline, transport, rid)
        self.assertEqual(row["status"], "complete")
        self.assertEqual(row["observation_error"], "ValueError")
        self.assertEqual(bridge.observation_error, "ValueError")
        self.assertEqual(bridge.cut(early["at"]), early["view"])
        view = bridge.cut(timeline.now)
        self.assertIsNone(view["requests"][0]["first"])
        self.assertIsNone(view["requests"][0]["terminal"])
        self.assertEqual(view["counts"]["pending"], 1)
        self.assertEqual(view["receipt_watermark"], 2)
        timeline = CaptureTimeline()
        bridge = self.bridge(timeline)
        rid = uid("r8-missing-callback")
        bridge.register(rid, 0.)
        captured = {}

        def before_terminal():
            captured["at"] = timeline.now
            captured["view"] = bridge.cut(captured["at"])

        def lose_callback(kind, receipt):
            if kind != "first_content":
                bridge.observe(kind, receipt)

        transport = self.httpx.MockTransport(lambda request: self.httpx.Response(
            200, headers={"content-type": "text/event-stream", "x-request-id": rid},
            stream=self.stream(before_terminal)))
        row = await self.capture(bridge, timeline, transport, rid, observe=lose_callback)
        self.assertEqual(row["status"], "complete")
        self.assertEqual(bridge.cut(captured["at"]), captured["view"])
        after = bridge.cut(timeline.now)
        self.assertIsNone(after["requests"][0]["first"])
        self.assertEqual(after["counts"]["missing_first_publication"], 1)
        self.assertIsNotNone(after["requests"][0]["terminal"]["capture"]["row"]["first_content_at"])
        timeline = CaptureTimeline()
        bridge = None

        def fail_delivery(publication):
            if publication["kind"] == "sent":
                raise OSError("observer transport failed")
            return bridge.history.receive(publication)

        bridge = self.bridge(timeline, deliver=fail_delivery)
        rid = uid("r8-root-delivery-error")
        bridge.register(rid, 0.)
        transport = self.httpx.MockTransport(lambda request: self.httpx.Response(
            200, headers={"content-type": "text/event-stream", "x-request-id": rid},
            stream=self.stream()))
        row = await self.capture(bridge, timeline, transport, rid)
        self.assertEqual(row["status"], "complete")
        self.assertEqual(bridge.observation_error, "OSError")
        self.assertEqual(row["observation_error"], "ValueError")
        self.assertEqual(bridge.cut(timeline.now)["counts"]["planned_pending"], 1)

    async def test_real_timeout_and_transport_failure_keep_actual_attempts_and_terminal_labels(self):
        for status in ("timeout", "failed"):
            with self.subTest(status=status):
                timeline = CaptureTimeline()
                bridge = self.bridge(timeline)
                rid = uid("r8-" + status)
                bridge.register(rid, 0.)

                async def handler(request):
                    if status == "timeout":
                        await asyncio.Event().wait()
                    raise self.httpx.ConnectError("CPU fake transport failure")

                row = await self.capture(bridge, timeline, self.httpx.MockTransport(handler),
                                         rid, timeout_s=.01)
                view = bridge.cut(timeline.now)
                self.assertEqual(row["status"], status)
                self.assertEqual(view["counts"]["offered"], 1)
                self.assertEqual(view["counts"]["terminal"][status], 1)
                self.assertEqual(view["counts"]["pending"], 0)

    async def test_unregistered_foreign_and_final_row_callbacks_or_invalid_estimates_fail_closed(self):
        for domain, registered in (("r8-clock", False), ("foreign-clock", True)):
            timeline = CaptureTimeline()
            bridge = self.bridge(timeline)
            rid = uid("r8-invalid")
            if registered:
                bridge.register(rid, 0.)
            transport = self.httpx.MockTransport(lambda request: self.httpx.Response(
                200, headers={"content-type": "text/event-stream", "x-request-id": rid},
                stream=self.stream()))
            row = await self.capture(bridge, timeline, transport, rid, domain=domain)
            self.assertEqual(row["status"], "complete")
            self.assertIn("observation_error", row)
            self.assertEqual(bridge.cut(timeline.now)["counts"]["offered"], 0)
        for estimate in (0, -1, True, float("inf")):
            bridge = self.bridge(CaptureTimeline())
            with self.subTest(estimate=estimate), self.assertRaises(ValueError):
                bridge.register(uid("invalid-estimate"), 0., original_offered_estimate=estimate)
        bridge = self.bridge(CaptureTimeline())
        bridge.register(uid("final-row"), 0.)
        with self.assertRaises(ValueError):
            bridge.observe("offered", dict(arm()["rows"][0], request_id=uid("final-row")))
        timeline = CaptureTimeline()
        bound = None

        def tamper(publication):
            if "capture" in publication:
                publication["capture"]["source_sha256"] = "f" * 64
            return bound.history.receive(publication)

        bound = self.bridge(timeline, deliver=tamper)
        rid = uid("foreign-source")
        bound.register(rid, 0.)
        transport = self.httpx.MockTransport(lambda request: self.httpx.Response(
            200, headers={"content-type": "text/event-stream", "x-request-id": rid},
            stream=self.stream()))
        row = await self.capture(bound, timeline, transport, rid)
        self.assertEqual(row["status"], "complete")
        self.assertEqual(bound.cut(timeline.now)["counts"]["offered"], 0)
        self.assertEqual(bound.observation_error, "ValueError")


class TaggedProducerTests(unittest.IsolatedAsyncioTestCase):
    actual_gateway = CaptureBridgeIntegrationTests.actual_gateway
    stream = CaptureBridgeIntegrationTests.stream
    payload = CaptureBridgeIntegrationTests.payload

    @classmethod
    def setUpClass(cls):
        import importlib
        import sys
        from pathlib import Path
        sys.path.insert(0, "/home/daniel_lin/gt/pr32/mayor/mpc-native-integration")
        cls.httpx = importlib.import_module("httpx")
        cls.capture_module = importlib.import_module("mpc_lab.http_capture")
        if hashlib.sha256(Path(cls.capture_module.__file__).read_bytes()).hexdigest() != TaggedNativeInputAdapter.CAPTURE_SOURCE_SHA256:
            raise ValueError("R13 live capture bytes changed")

    def adapter(self, domain, *, gateway=None):
        from mpc_lab.native_state import NativeBinding
        from mpc_lab.contracts import CostSpec, Identity
        bridge = CaptureReceiptBridge(
            publisher_run_id=uid("r13-publisher"), observer_run_id=uid("r13-receiver"),
            clock_domain=domain, capture_source_sha256=TaggedNativeInputAdapter.CAPTURE_SOURCE_SHA256)
        identity = (gateway.mpc_identity if gateway else
                    Identity("cpu", "none", "none", CostSpec().fingerprint, "none"))
        binding = NativeBinding(domain, gateway.telemetry.run_id if gateway else "cpu-gateway",
                                uid("r13-core"), TaggedNativeInputAdapter.OBSERVER_SOURCE_SHA256, identity)
        return bridge, TaggedNativeInputAdapter(bridge, binding)

    def observed_frame(self, gateway, snapshot, request_id, extra, *, copies=1):
        import ast
        import importlib.metadata
        import math
        from pathlib import Path
        import re
        import time
        from types import SimpleNamespace
        import uuid
        from unittest.mock import patch

        path = Path("/home/daniel_lin/gt/pr32/mayor/mpc-native-integration/experiments/"
                    "mpc-research/native_observer/pr33_native_observer.py")
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),
                         TaggedNativeInputAdapter.OBSERVER_SOURCE_SHA256)
        tree = ast.parse(path.read_text())
        functions = [n for n in tree.body if isinstance(n, ast.FunctionDef)
                     and n.name in ("observe", "sampling_identifier", "sampling_ignore_eos")]
        namespace = dict(hashlib=hashlib, importlib=importlib, math=math, Path=Path, re=re,
                         time=time, uuid=uuid, __file__=str(path), clock_domain=gateway.mpc_local_clock_domain)
        exec(compile(ast.Module(body=functions, type_ignores=[]), str(path), "exec"), namespace)
        requests = [SimpleNamespace(
            request_id=request_id + str(i), num_prompt_tokens=128, num_computed_tokens=128,
            num_output_tokens=0, max_tokens=2,
            sampling_params=SimpleNamespace(extra_args=copy.deepcopy(extra), ignore_eos=True))
            for i in range(copies)]
        core = SimpleNamespace(
            _pr33_observer_run=uid("r13-core"), batch_queue=[object()],
            scheduler=SimpleNamespace(running=requests, waiting=[], skipped_waiting=[],
                                      num_waiting_for_streaming_input=0,
                                      kv_cache_manager=SimpleNamespace(usage=.1)))
        with patch("importlib.metadata.version", return_value="0.30.0"):
            frame = namespace["observe"](core)
        frame.update(gateway_snapshot=copy.deepcopy(snapshot), gateway_received_at=time.monotonic(),
                     frontend_sampled_at=time.monotonic(), frontend_unfinished=copies,
                     received_at=time.monotonic())
        return frame

    async def test_actual_new_producers_preoutcome_tags_charge_and_sealed_cut(self):
        import time
        rid, cohort, saved = uid("r13-attempt"), uid("r13-cohort"), {}
        with self.actual_gateway() as gateway:
            bridge, adapter = self.adapter(gateway.mpc_clock_domain, gateway=gateway)
            metadata = adapter.register_controlled(rid, 0., cohort_id=cohort, max_tokens=2, ignore_eos=True)
            metadata["cohort_id"] = uid("mutated-return")
            original = adapter.cut(time.monotonic())
            self.assertEqual(original["attempts"], [])
            self.assertEqual(len(original["controlled_registrations"]), 1)
            async with self.httpx.AsyncClient(
                    transport=self.httpx.ASGITransport(app=gateway.app),
                    base_url="https://gateway-fixture.invalid") as downstream:
                async def upstream(request):
                    body = json.loads(request.content)
                    extra = body["vllm_xargs"]
                    self.assertEqual(extra["pr33_gateway_request_id"], rid)
                    self.assertEqual(extra["pr33_cohort_id"], cohort)
                    self.assertNotEqual(extra["pr33_gateway_request_id"], uid("caller-spoof"))
                    snapshot = (await downstream.get("/admin/mpc/state", headers={
                        "x-admin-api-key": "cpu-fixture-key"})).json()
                    frame = self.observed_frame(gateway, snapshot, "opaque-engine-id", extra)
                    adapter.receive_tagged_native(frame)
                    before_binding = adapter.cut(time.monotonic())
                    self.assertFalse(before_binding["sampling_params_matches"])
                    historical = OnlineModelInputAdapter(bridge, adapter._binding)
                    with self.assertRaisesRegex(ValueError, "source mismatch"):
                        historical.receive_gateway_uuid_binding(gateway, rid)
                    adapter.receive_gateway_uuid_binding(gateway, rid)
                    self.assertEqual(adapter.cut(before_binding["cut_at"]), before_binding)
                    saved["joined"] = adapter.cut(time.monotonic())
                    match = saved["joined"]["sampling_params_matches"][0]
                    self.assertEqual(match["engine_request_id"], "opaque-engine-id0")
                    self.assertEqual(match["cohort_id"], cohort)
                    self.assertEqual(match["original_gateway_charge"], snapshot["requests"][0]["cost"])
                    self.assertIsNone(saved["joined"]["attempts"][0]["original_offered_estimate"])
                    self.assertNotEqual(match["native_prompt_tokens"], match["gateway_prompt_estimate"])
                    self.assertFalse(saved["joined"]["attempts"][0]["readmission_allowed"])
                    self.assertFalse(saved["joined"]["trusted_end_to_end_join"])
                    self.assertIsNone(saved["joined"]["native"]["waiting_work"])
                    for mutate in ("domain", "source", "tag", "duplicate", "replacement"):
                        with self.subTest(mutate=mutate):
                            bad = self.observed_frame(gateway, snapshot, "opaque-engine-id", extra,
                                                      copies=2 if mutate == "duplicate" else 1)
                            if mutate == "domain":
                                bad["clock_domain"] = "foreign"
                            if mutate == "source":
                                bad["observer_sha256"] = "d" * 64
                            if mutate == "tag":
                                bad["requests"][0]["cohort_id"] = uid("foreign")
                            if mutate == "replacement":
                                bad["requests"][0]["request_id"] = "new-native-actor"
                            with self.assertRaises(ValueError):
                                adapter.receive_tagged_native(bad)
                    frame["requests"][0]["gateway_request_id"] = uid("mutated-input")
                    self.assertEqual(adapter.cut(saved["joined"]["cut_at"]), saved["joined"])
                    return self.httpx.Response(
                        200, headers={"content-type": "text/event-stream"}, stream=self.stream())

                def observe(kind, receipt):
                    adapter.observe(kind, receipt)
                    saved[kind] = adapter.cut(time.monotonic())

                gateway.app.state.upstream_client = self.httpx.AsyncClient(
                    transport=self.httpx.MockTransport(upstream))
                try:
                    payload = {**self.payload(), "ignore_eos": True,
                               "vllm_xargs": dict(pr33_gateway_request_id=uid("caller-spoof"),
                                                 pr33_cohort_id=cohort)}
                    row = await self.capture_module.capture_chat(
                        downstream, "/v1/chat/completions", payload, rid, 0.,
                        enabled=True, domain=gateway.mpc_clock_domain, observe=observe)
                finally:
                    await gateway.app.state.upstream_client.aclose()
            self.assertIsNone(row.get("observation_error"))
            self.assertIsNone(saved["offered"]["attempts"][0]["terminal"])
            self.assertIsNotNone(saved["first_content"]["attempts"][0]["first"])
            self.assertIsNone(saved["first_content"]["attempts"][0]["terminal"])
            self.assertIsNotNone(saved["terminal"]["attempts"][0]["terminal"])
            self.assertEqual(original["attempts"], [])
            with self.assertRaises(ValueError):
                adapter.cut(original["cut_at"])
            self.assertFalse(saved["terminal"]["active_mpc_permit"])

    async def test_actual_preheader_failure_and_unsent_cancel_remain_all_assigned(self):
        import time
        bridge, adapter = self.adapter("r13-test-domain")
        rid, cancelled, cohort, saved = uid("preheader"), uid("unsent"), uid("cohort"), {}
        scheduled_cancel = time.monotonic() + 3600.
        adapter.register_controlled(rid, 0., cohort_id=cohort, max_tokens=2, ignore_eos=True)
        adapter.register_controlled(cancelled, scheduled_cancel, cohort_id=cohort, max_tokens=2, ignore_eos=True)

        def failed(request):
            saved["before"] = adapter.cut(time.monotonic())
            raise self.httpx.ReadError("private exception message must not be retained")

        async with self.httpx.AsyncClient(transport=self.httpx.MockTransport(failed)) as client:
            row = await self.capture_module.capture_chat(
                client, "https://fixture.invalid/chat", {**self.payload(), "ignore_eos": True},
                rid, 0., enabled=True, domain="r13-test-domain", observe=adapter.observe)
            task = asyncio.create_task(self.capture_module.capture_chat(
                client, "https://fixture.invalid/chat", {**self.payload(), "ignore_eos": True},
                cancelled, scheduled_cancel, enabled=True, domain="r13-test-domain",
                observe=adapter.observe))
            await asyncio.sleep(0)
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task
        now = adapter.cut(time.monotonic())
        self.assertEqual(len(now["controlled_registrations"]), 2)
        self.assertEqual(len(now["attempts"]), 1)
        self.assertEqual(now["arrival_rate_approximation"]["observed_attempts"], 1)
        attempt = now["attempts"][0]
        self.assertEqual(attempt["gateway_status"], "unknown")
        self.assertEqual(attempt["capture_failure"]["exception_class"], "ReadError")
        self.assertEqual(attempt["capture_failure"]["stage"], "response_headers")
        self.assertIsNone(attempt["actual_gateway_charge"])
        self.assertNotIn("private exception", json.dumps(bridge.history._records))
        self.assertIsNone(saved["before"]["attempts"][0]["terminal"])
        self.assertEqual(row["capture_error_stage"], "response_headers")
        unsent = next(r for r in bridge.cut(time.monotonic())["requests"] if r["request_id"] == cancelled)
        self.assertIsNone(unsent["sent"])
        self.assertEqual(unsent["terminal"]["status"], "cancelled")

    async def test_capture_metadata_error_is_not_future_cut_evidence_or_traffic_rejection(self):
        import time
        bridge, adapter = self.adapter("r13-errors")
        rid = uid("metadata-error")
        adapter.register_controlled(rid, 0., cohort_id=uid("cohort"), max_tokens=2, ignore_eos=True)
        cutoff = time.monotonic()
        calls = []
        def respond(request):
            calls.append(request)
            return self.httpx.Response(
                200, headers={"content-type": "text/event-stream", "x-request-id": rid}, stream=self.stream())
        async with self.httpx.AsyncClient(transport=self.httpx.MockTransport(respond)) as client:
            row = await self.capture_module.capture_chat(
                client, "https://fixture.invalid/chat", self.payload(), rid, 0.,
                enabled=True, domain="r13-errors", observe=adapter.observe)
        self.assertEqual(len(calls), 1)
        self.assertEqual(row["status"], "complete")
        self.assertEqual(row["observation_error"], "ValueError")
        old = adapter.cut(cutoff)
        self.assertEqual(old["callback_error_receipts"], [])
        later = adapter.cut(time.monotonic())
        self.assertTrue(later["callback_error_receipts"])
        self.assertFalse(later["publisher_complete_through_cut"])
        self.assertEqual(len(later["controlled_registrations"]), 1)
        self.assertEqual(later["attempts"], [])

    async def test_actual_ledger_CAS_flush_and_clean_suffix_truncation(self):
        from dataclasses import asdict
        from pathlib import Path
        import tempfile
        import time
        from unittest.mock import AsyncMock
        from starlette.responses import JSONResponse
        from starlette.routing import Route

        with self.actual_gateway() as gateway, tempfile.TemporaryDirectory(
                prefix="sol-r13-test-", dir=str(Path(__file__).parent.resolve())) as directory:
            raw_path, status_path = Path(directory) / "ledger.jsonl", Path(directory) / "status.json"
            gateway.TELEMETRY_JSONL, gateway.TELEMETRY_STATUS_JSON = str(raw_path), str(status_path)
            gateway.snapshot_metrics = AsyncMock(return_value={})

            async def budget_endpoint(request):
                result = await gateway.mpc_update_budget(request)
                return JSONResponse(result) if isinstance(result, dict) else result

            gateway.app.routes.append(Route("/admin/mpc/budget", budget_endpoint, methods=["POST"]))
            async with self.httpx.AsyncClient(transport=self.httpx.ASGITransport(app=gateway.app),
                                             base_url="https://fixture.invalid") as downstream:
                async def apply(budget):
                    command = dict(schema=gateway.SCHEMA, run_id=gateway.telemetry.run_id,
                                   clock_domain=gateway.mpc_clock_domain, identity=asdict(gateway.mpc_identity),
                                   expected_version=gateway.state["budget_version"], not_after=time.monotonic() + .1,
                                   operation_id=uid(f"{budget}-{gateway.state['budget_version']}"), budget=budget)
                    response = await downstream.post("/admin/mpc/budget", json=command,
                                                     headers={"x-admin-api-key": "cpu-fixture-key"})
                    self.assertEqual(response.status_code, 200)
                    self.assertEqual(response.json()["status"], "applied")

                async def upstream(request):
                    before = gateway.state["current_admitted_cost"]
                    await apply(16.)
                    self.assertEqual(gateway.state["current_admitted_cost"], before)
                    return self.httpx.Response(200, headers={"content-type": "text/event-stream"},
                                               stream=self.stream())

                gateway.create_upstream_client = lambda: self.httpx.AsyncClient(
                    transport=self.httpx.MockTransport(upstream))
                async with gateway.lifespan(gateway.app):
                    initial_raw = (await downstream.get("/admin/mpc/state", headers={
                        "x-admin-api-key": "cpu-fixture-key"})).content
                    gemini_shape = dict(
                        operation_id=uid("frozen-Gemini-shape"), run_id=gateway.telemetry.run_id,
                        clock_domain=gateway.mpc_clock_domain, expected_version=0,
                        budget=16., not_after=time.monotonic() + .1)
                    refused = await downstream.post("/admin/mpc/budget", json=gemini_shape,
                                                    headers={"x-admin-api-key": "cpu-fixture-key"})
                    self.assertEqual(refused.status_code, 422)
                    self.assertEqual(gateway.state["budget_version"], 0)
                    await apply(32.)
                    for i in range(2):
                        response = await downstream.post("/v1/chat/completions", json=self.payload(),
                                                         headers={"x-benchmark-request-id": uid(f"ledger-{i}")})
                        self.assertEqual(response.status_code, 200)
                    final_raw = (await downstream.get("/admin/mpc/state", headers={
                        "x-admin-api-key": "cpu-fixture-key"})).content
            raw, status_raw = raw_path.read_bytes(), status_path.read_bytes()
            def audit(candidate=raw, status=status_raw):
                return audit_gateway_ledger_prefix(
                    candidate, hashlib.sha256(candidate).hexdigest(), status, hashlib.sha256(status).hexdigest(),
                    run_id=gateway.telemetry.run_id, clock_domain=gateway.mpc_clock_domain,
                    identity=gateway.mpc_identity, cost_spec=gateway.mpc_cost_spec)
            result = audit()
            self.assertTrue(result["prefix_conditions_satisfied"], result["prefix_refusals"])
            kinds = [r["kind"] for r in result["stock_transitions"]]
            self.assertEqual(kinds.count("one_admission_whole_charge"), 2)
            self.assertEqual(kinds.count("one_release_whole_charge_not_GPU_completion"), 2)
            self.assertIn("no_stock_change_first_content_budget_or_other", kinds)
            lines, cutoff = raw.splitlines(keepends=True), None
            for i, line in enumerate(lines):
                row = json.loads(line)
                if row["event"] == "mpc_ledger" and row["running"] == 0 and row["sequence"] > 1:
                    cutoff = i
                    break
            truncated = b"".join(lines[:cutoff + 1])
            witness = audit(truncated)
            self.assertTrue(witness["prefix_conditions_satisfied"])
            self.assertLess(witness["ledger_count"], result["ledger_count"])
            self.assertFalse(witness["full_run_complete"])
            self.assertFalse(result["exact_per_UUID_release"])
            expected = dict(admissions=2, first_content_updates=2, releases=2,
                            applied_budget_updates=3, other=0)
            def bounded(candidate=raw, first=initial_raw, last=final_raw, counts=expected):
                return audit_gateway_ledger_boundaries(
                    candidate, hashlib.sha256(candidate).hexdigest(),
                    status_raw, hashlib.sha256(status_raw).hexdigest(),
                    run_id=gateway.telemetry.run_id, clock_domain=gateway.mpc_clock_domain,
                    identity=gateway.mpc_identity, cost_spec=gateway.mpc_cost_spec,
                    initial_raw=first, initial_sha256=None if first is None else hashlib.sha256(first).hexdigest(),
                    final_raw=last, final_sha256=None if last is None else hashlib.sha256(last).hexdigest(),
                    expected_updates=counts)
            closed_interval = bounded()
            self.assertTrue(closed_interval["conditional_sequence_interval_complete"])
            self.assertFalse(closed_interval["full_run_complete"])
            truncated_interval = bounded(truncated)
            self.assertFalse(truncated_interval["boundary_sequence_consistent"])
            self.assertIn("final_watermark_mismatch", truncated_interval["refusals"])
            self.assertFalse(truncated_interval["expected_count_consistent"])
            missing = bounded(last=None)
            self.assertFalse(missing["conditional_sequence_interval_complete"])
            self.assertIn("independently_acquired_raw_boundaries_missing", missing["refusals"])
            self.assertTrue(bounded(counts=None)["conditional_sequence_interval_complete"])
            wrong_counts = {**expected, "releases": 1}
            self.assertFalse(bounded(counts=wrong_counts)["conditional_sequence_interval_complete"])
            from mpc_lab.contracts import RequestMark
            impossible_initial = json.loads(initial_raw)
            timestamp = impossible_initial["sampled_at"]
            impossible_initial["requests"] = [
                asdict(RequestMark(uid(f"counterexample-owner-{i}"), gateway.mpc_cost_spec.estimate(1, 2),
                                   1, 2, timestamp, timestamp))
                for i in range(2)]
            impossible = bounded(first=json.dumps(impossible_initial).encode())
            self.assertIn("initial_not_a_single_source_stock_transition", impossible["refusals"])
            self.assertFalse(impossible["conditional_sequence_interval_complete"])
            # A log-derived fake final is structurally consistent, not independent execution evidence.
            fake_final = json.loads(final_raw)
            last_cropped = json.loads(lines[cutoff])
            for key in ("sequence", "budget", "budget_version"):
                fake_final[key] = last_cropped[key]
            fake = bounded(truncated, last=json.dumps(fake_final).encode(), counts=None)
            self.assertTrue(fake["boundary_sequence_consistent"])
            self.assertFalse(fake["independent_snapshot_execution_authenticated"])
            self.assertFalse(fake["full_run_complete"])
            for mutate in ("run", "domain", "budget", "sequence"):
                with self.subTest(boundary_mutation=mutate):
                    document = json.loads(final_raw)
                    if mutate == "run":
                        document["run_id"] = uid("other-epoch")
                    if mutate == "domain":
                        document["clock_domain"] = "other-domain"
                    if mutate == "budget":
                        document["budget"] *= 2
                    if mutate == "sequence":
                        document["sequence"] += 1
                    encoded = json.dumps(document).encode()
                    if mutate in ("run", "domain"):
                        with self.assertRaises(ValueError):
                            bounded(last=encoded)
                    else:
                        self.assertFalse(bounded(last=encoded)["conditional_sequence_interval_complete"])
            projection = dict(
                evidence="CPU actual Gateway/Telemetry handlers; time-free offline witness, not GPU data",
                transitions=[{k: r[k] for k in ("owner_delta", "cost_delta", "kind", "request_id")}
                             for r in result["stock_transitions"]],
                accepted_original_charges=sorted(result["accepted_charges"].values()),
                full_prefix=result["prefix_conditions_satisfied"],
                truncated_prefix=witness["prefix_conditions_satisfied"],
                full_run_complete=result["full_run_complete"], exact_per_UUID_release=False)
            canonical = json.dumps(projection, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
            type(self).ledger_receipt = dict(
                raw_sha256=hashlib.sha256(raw).hexdigest(), status_sha256=hashlib.sha256(status_raw).hexdigest(),
                truncated_raw_sha256=hashlib.sha256(truncated).hexdigest(),
                canonical_projection_sha256=hashlib.sha256(canonical).hexdigest(), projection=projection,
                r14_boundaries=dict(
                    initial_raw_sha256=hashlib.sha256(initial_raw).hexdigest(),
                    final_raw_sha256=hashlib.sha256(final_raw).hexdigest(),
                    complete_interval=closed_interval["conditional_sequence_interval_complete"],
                    truncated_with_actual_final=truncated_interval["boundary_sequence_consistent"],
                    fake_final_structurally_consistent=fake["boundary_sequence_consistent"],
                    full_run_complete=False))
            for mutation in ("drop", "gap", "incomplete", "charge", "clock"):
                with self.subTest(mutation=mutation):
                    doc, records = json.loads(status_raw), [json.loads(line) for line in lines]
                    ledger = next(r for r in records if r["event"] == "mpc_ledger")
                    if mutation == "drop":
                        doc["dropped"] = 1
                    if mutation == "gap":
                        ledger["sequence"] += 1
                    if mutation == "incomplete":
                        ledger["complete"] = False
                    if mutation == "charge":
                        next(r for r in records if r["event"] == "accepted")["request_cost"] *= 2
                    if mutation == "clock":
                        ledger["clock_domain"] = "foreign"
                    encoded = b"".join((json.dumps(r) + "\n").encode() for r in records)
                    if mutation in ("charge", "clock"):
                        with self.assertRaises(ValueError):
                            audit(encoded, json.dumps(doc).encode())
                    else:
                        self.assertFalse(audit(encoded, json.dumps(doc).encode())["prefix_conditions_satisfied"])

    async def test_actual_flush_failure_drops_swapped_batch_even_after_partial_write(self):
        import io
        from telemetry import Telemetry
        from unittest.mock import MagicMock, patch
        producer, partial = Telemetry(), io.StringIO()
        producer.enabled = True
        producer.emit("first")
        producer.emit("second")
        handle = MagicMock()
        handle.__enter__.return_value = handle
        calls = []
        def write(line):
            calls.append(line)
            if len(calls) == 2:
                raise OSError("CPU injected write failure")
            partial.write(line)
        handle.write.side_effect = write
        with patch("pathlib.Path.open", return_value=handle):
            await producer.flush("unused-cpu-path")
        self.assertEqual(len(partial.getvalue().splitlines()), 1)
        self.assertEqual(producer.records, [])
        self.assertEqual((producer.dropped, producer.write_errors), (2, 1))
        await producer.flush("unused-cpu-path")
        self.assertEqual((producer.dropped, producer.write_errors), (2, 1))


class R15LiveRunnerTests(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls):
        import sys
        sys.path.insert(0, "/home/daniel_lin/gt/pr32/mayor/mpc-native-integration")

    async def asyncSetUp(self):
        import ast
        import os
        import sys
        from pathlib import Path
        from types import ModuleType
        from unittest.mock import patch
        # The clock function is pure stdlib; do not stub incompatible NumPy or its algorithms.
        path = Path("/home/daniel_lin/gt/pr32/mayor/mpc-native-integration/prefill_lab/live_http.py")
        node = next(n for n in ast.parse(path.read_text()).body
                    if isinstance(n, ast.FunctionDef) and n.name == "clock_domain")
        clock_module = ModuleType("prefill_lab.live_http")
        clock_module.__dict__.update(Path=Path, os=os)
        exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), "exec"),
             clock_module.__dict__)
        context = patch.dict(sys.modules, {"prefill_lab.live_http": clock_module})
        context.start()
        self.addCleanup(context.stop)

    def frozen_runner(self):
        import ast
        import __future__
        import time
        import uuid
        import tempfile
        import httpx
        from pathlib import Path
        from types import SimpleNamespace
        from mpc_lab.contracts import CostSpec
        path = Path("/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/"
                    "files/pr33-native-v3-round14-frozen/gemini/native_campaign_protocol.py")
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),
                         "a2adf55bc57e2e6f3f02310cef2c950d066d1caa5cfa0e6f4304252e1551007b")
        tree = ast.parse(path.read_text())
        node = next(n for n in tree.body if isinstance(n, ast.ClassDef)
                    and n.name == "LiveNativeCohortRunner")
        namespace = dict(asyncio=asyncio, httpx=httpx, time=time, uuid=uuid, tempfile=tempfile,
                         Path=Path, ensure_integration_paths=lambda: None,
                         get_sourced_cost_spec=CostSpec, LiveNativeCohortRunnerReceipt=SimpleNamespace)
        exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), "exec",
                     flags=__future__.annotations.compiler_flag), namespace)
        protocol = SimpleNamespace(
            initial_budget=32., actuator_ttl_ms=100., anchor_cohort_count=9,
            anchor_prompt_tokens=128, anchor_max_tokens=256, anchor_ignore_eos=True,
            evaluation_window_s=1., peak_decode_rate_tok_s=90.,
            burst_request_count=4, burst_prompt_tokens=4096, burst_max_tokens=128,
            burst_arrival_offset_s=.03, lineage_refusal_reason="no physical lineage permit",
            aggregate_cohort_provenance="CPU shaped receipts only")
        return namespace["LiveNativeCohortRunner"](protocol=protocol)

    def fixture(self, *, proper_runs=False, gate_empty=False, missing_counter=False,
                disappear=False, cost=None, hold_bursts=False):
        import time
        from dataclasses import asdict
        from types import SimpleNamespace
        import httpx
        from mpc_lab.contracts import CostSpec, ModelParameters, RequestMark, Snapshot
        from mpc_lab.native_state import NativeBinding
        from mpc_lab.runtime import snapshot_to_dict, local_clock_domain
        cost = cost or CostSpec()
        identity = ModelParameters(cost_spec=cost, model_version="native-id-unfitted-v1",
                                   calibration_version="unfitted-not-validated",
                                   supported_budgets=(16., 32.)).identity
        domain = local_clock_domain()
        binding = NativeBinding(domain, uid("r15-gateway") if proper_runs else "live-gw-run-001",
                                uid("r15-native") if proper_runs else "live-native-run-001",
                                "b" * 64, identity)
        finish = asyncio.Event()
        from pathlib import Path
        state = SimpleNamespace(binding=binding, cost=cost, posts=[], anchors={}, frames=[],
                                burst_starts=[], burst_finishes=[], finish=finish,
                                assignment_at=None, end_at=None, gate_empty=gate_empty,
                                pending_dir=Path(__file__).resolve().parent)

        def snapshot(at):
            marks = tuple(RequestMark(rid, cost.estimate(128, 256), 128, 256, born, born)
                          for rid, (_, born) in state.anchors.items())
            result = snapshot_to_dict(Snapshot(binding.gateway_run_id, domain, at, 32., 0,
                                               marks, identity))
            result["cost_spec"] = asdict(cost)
            return result

        def frame(at):
            rows = [dict(request_id="opaque-native:" + str(i), prompt_tokens=128,
                         computed_tokens=129, output_tokens=8 if state.assignment_at else 1,
                         maximum_output_tokens=256, cohort_id=tag, gateway_request_id=rid,
                         ignore_eos=True)
                    for i, (rid, (tag, _)) in enumerate(state.anchors.items())]
            if len(state.frames) == 1 and missing_counter:
                for row in rows:
                    row.pop("output_tokens")
            if gate_empty or len(state.frames) >= 3 and disappear:
                rows = []
            doc = dict(schema="pr33-native-read-only-v1", available=True, complete=True,
                       run_id=binding.native_run_id, observer_sha256=binding.observer_sha256,
                       clock_domain=domain, vllm_version="0.30.0",
                       sampled_at=at, frontend_sampled_at=at, received_at=at,
                       gateway_received_at=at, gateway_snapshot=snapshot(at),
                       running=len(rows), waiting=0, orphaned=0, pending_batches=0,
                       frontend_unfinished=len(rows), kv_cache_usage=0., requests=rows)
            state.frames.append(doc)
            return doc

        class Stream(httpx.AsyncByteStream):
            def __init__(self, rid, anchor):
                self.rid, self.anchor = rid, anchor
            async def __aiter__(self):
                await asyncio.sleep(.01)
                yield b'data: {"choices":[{"index":0,"delta":{"content":"x"}}]}\n\n'
                if self.anchor or hold_bursts:
                    await finish.wait()
                if not self.anchor:
                    if not hold_bursts:
                        await asyncio.sleep(.03)
                    state.burst_finishes.append(time.monotonic())
                yield b'data: {"choices":[{"index":0,"finish_reason":"length"}]}\n\ndata: [DONE]\n\n'

        async def handle(request):
            at = time.monotonic()
            if request.url.path == "/admin/mpc/state":
                return httpx.Response(200, json=snapshot(at))
            if request.url.path == "/pr33-native/state":
                document = frame(at)
                if len(state.frames) == 4:
                    state.end_at = at
                    finish.set()
                return httpx.Response(200, json=document)
            if request.method == "POST" and request.url.path == "/v1/chat/completions":
                payload = json.loads(request.content)
                rid = request.headers["x-benchmark-request-id"]
                state.posts.append((rid, at, payload))
                anchor = payload["ignore_eos"]
                if anchor:
                    state.anchors[rid] = (payload["vllm_xargs"]["pr33_cohort_id"], at)
                else:
                    state.burst_starts.append(at)
                return httpx.Response(200, stream=Stream(rid, anchor), headers={
                    "content-type": "text/event-stream", "x-request-id": rid})
            raise AssertionError("Unexpected CPU request")
        state.snapshot, state.frame = snapshot, frame
        state.client = httpx.AsyncClient(transport=httpx.MockTransport(handle), base_url="http://cpu.test")
        return state

    def actuator(self, state, status):
        import time
        from types import SimpleNamespace
        from mpc_lab.runtime import snapshot_from_dict
        async def snapshot():
            return snapshot_from_dict(state.snapshot(time.monotonic()))
        async def submit(before, decision):
            state.assignment_at = time.monotonic()
            return dict(status=status, applied=False, reason="CPU unknown/failure receipt")
        return SimpleNamespace(_state=snapshot, submit=submit)

    async def test_supplied_binding_failed_drain_and_empty_gate_still_dispatch_frozen_runner(self):
        from mpc_lab.contracts import CostSpec
        state = self.fixture(proper_runs=True, gate_empty=True,
                             cost=CostSpec(intercept=1.5, input_per_token=.0001, output_per_token=.001))
        async with state.client:
            result = await self.frozen_runner().run_arm(
                "assigned_failed", 16., client=state.client, native_client=state.client,
                binding=state.binding, actuator=self.actuator(state, "unknown"),
                pending_dir=state.pending_dir)
        self.assertFalse(result.drain_verified)
        self.assertEqual(len(state.posts), 13)
        self.assertEqual(result.preassigned_engine_ids, ())
        self.assertTrue(result.gateway_tag_matches_client)
        self.assertEqual(result.anchor_mean_progress, 0)
        self.assertEqual(result.censored_count, 0)
        self.assertNotEqual(result.anchor_cost_per_request, state.cost.estimate(128, 256))
        ids = result.anchor_client_request_ids
        checked = controlled_dispatch_preflight(
            state.binding, state.frames[0], state.frames[1], cohort_tag=result.cohort_tag,
            client_ids=ids, maximum_output_tokens=256, now=state.frames[1]["received_at"])
        self.assertFalse(checked["conditional_gate_ready"])
        self.assertIn("gate:cohort_phase_inventory", checked["refusal_reasons"])
        self.assertFalse(checked["dispatch_permit"])
        type(self).binding_witness = dict(
            posts=len(state.posts), drain_verified=result.drain_verified,
            empty_gate_tag_all_true=result.gateway_tag_matches_client,
            empty_gate_censored_count=result.censored_count, empty_gate_mean=result.anchor_mean_progress,
            supplied_cost_ignored=result.anchor_cost_per_request != state.cost.estimate(128, 256))

    async def test_unknown_CAS_serial_full_SSE_wait_and_wrong_end_origin_zero_imputation(self):
        state = self.fixture(missing_counter=True, disappear=True)
        async with state.client:
            result = await self.frozen_runner().run_arm(
                "assigned_unknown", 32., client=state.client, native_client=state.client,
                binding=state.binding, actuator=self.actuator(state, "unknown"),
                pending_dir=state.pending_dir)
        self.assertTrue(result.drain_verified)
        self.assertEqual(result.actuator_submission["status"], "unknown")
        self.assertEqual(len(state.burst_starts), 4)
        self.assertTrue(all(state.burst_starts[i + 1] >= state.burst_finishes[i] for i in range(3)))
        self.assertGreater(state.end_at - state.assignment_at, 1.12)
        self.assertGreaterEqual(state.end_at - state.burst_finishes[-1], .99)
        self.assertEqual(result.censored_count, 9)
        self.assertEqual(result.anchor_mean_progress, 0.)
        self.assertTrue(result.all_assigned_fates_retained)
        self.assertTrue(result.measured_max512_survival_verified)
        self.assertTrue(all(f["start_output"] == 1 for f in result.anchor_fates.values()))
        bounds = controlled_window_bounds(
            result.preassigned_engine_ids, {}, {}, maximum_output_tokens=256,
            assignment_status="unknown", applied_at=state.assignment_at, sampled_at=state.end_at)
        self.assertEqual(bounds["mean_interval"], (0, 256))
        self.assertEqual(bounds["assigned_count"], 9)
        self.assertIsNone(bounds["point_mean"])
        self.assertFalse(bounds["primary_reporter_window_qualified"])
        self.assertFalse(bounds["causal_effect_permit"])
        type(self).timing_witness = dict(
            status=result.actuator_submission["status"], bursts=len(state.burst_starts),
            full_HTTP_serial=True, end_after_last_HTTP_plus_1=True,
            late_relative_to_assignment=True, missing_gate_counter_default=1,
            censored_count=result.censored_count, zero_imputed_mean=result.anchor_mean_progress,
            purported_survival_verified=result.measured_max512_survival_verified,
            corrected_mean_bounds=list(bounds["mean_interval"]))

    async def test_reference_actual_capture_concurrent_attempts_and_apply_relative_sample(self):
        import time
        from mpc_lab.http_capture import capture_chat
        state = self.fixture(hold_bursts=True)
        receipts, completions = [], []
        applied = time.monotonic()
        due = applied + .03
        # Block HTTP completion beyond the sample; sampling must not await full captures.
        async with state.client:
            tasks = []
            for i in range(4):
                rid = uid("concurrent-r15-" + str(i))
                payload = dict(model="CPU-Qwen", messages=[dict(role="user", content="CPU fixture")],
                               max_tokens=128, ignore_eos=False)
                tasks.append(asyncio.create_task(capture_chat(
                    state.client, "/v1/chat/completions", payload, rid, due, enabled=True,
                    domain=state.binding.clock_domain, record=completions.append,
                    observe=lambda kind, receipt: receipts.append((kind, receipt)))))
            await asyncio.sleep(max(0, applied + 1. - time.monotonic()))
            sampled = time.monotonic()
            self.assertTrue(all(not task.done() for task in tasks))
            self.assertEqual(len(state.posts), 4)
            sends = [r["sent_at"] for kind, r in receipts if kind == "offered"]
            self.assertEqual(len(sends), 4)
            self.assertTrue(all(t >= due for t in sends))
            self.assertLess(max(sends) - min(sends), .03)
            self.assertTrue(any(kind == "first_content" for kind, _ in receipts))
            finish_times = [r["terminal_at"] for kind, r in receipts if kind == "terminal"]
            self.assertEqual(finish_times, [])
            state.finish.set()
            await asyncio.gather(*tasks)
        self.assertEqual(len(completions), 4)
        self.assertTrue(all(r["terminal_at"] >= sampled for r in completions))
        check = controlled_window_bounds(
            tuple(str(i) for i in range(9)), {str(i): 1 for i in range(9)},
            {str(i): 8 for i in range(9)}, maximum_output_tokens=256,
            assignment_status="applied", applied_at=applied, sampled_at=sampled)
        self.assertTrue(check["timing_within_20ms"])
        self.assertEqual(check["point_mean"], 7.)
        self.assertFalse(check["statistical_permit"])
        self.assertFalse(check["physical_survival_verified"])

    async def test_failed_CAS_still_bursts_and_counts_pre_assignment_progress_as_window_effect(self):
        state = self.fixture()
        async with state.client:
            result = await self.frozen_runner().run_arm(
                "assigned_failed_CAS", 16., client=state.client, native_client=state.client,
                binding=state.binding, actuator=self.actuator(state, "failed"),
                pending_dir=state.pending_dir)
        self.assertEqual(result.actuator_submission["status"], "failed")
        self.assertEqual(len(state.burst_starts), 4)
        self.assertEqual(result.anchor_mean_progress, 7.)
        self.assertTrue(all(row["output_tokens"] == 8 for row in state.frames[2]["requests"]))
        self.assertTrue(all(row["output_tokens"] == 8 for row in state.frames[3]["requests"]))
        checked = controlled_window_bounds(
            result.preassigned_engine_ids,
            {row["request_id"]: row["output_tokens"] for row in state.frames[2]["requests"]},
            {row["request_id"]: row["output_tokens"] for row in state.frames[3]["requests"]},
            maximum_output_tokens=256, assignment_status="failed",
            applied_at=state.assignment_at, sampled_at=state.end_at)
        self.assertEqual(checked["mean_interval"], (0, 0))
        self.assertIsNone(checked["point_mean"])
        self.assertFalse(checked["causal_effect_permit"])
        type(self).origin_witness = dict(status="failed", bursts=len(state.burst_starts),
                                         gate_origin_mean=result.anchor_mean_progress,
                                         apply_origin_bounds=list(checked["mean_interval"]))

    async def test_preflight_source_drain_gate_refusals_cannot_authorize_dispatch(self):
        import time
        state = self.fixture(proper_runs=True)
        initial = state.frame(time.monotonic())
        ids, tag = tuple(uid("preflight-" + str(i)) for i in range(9)), uid("preflight-cohort")
        for rid in ids:
            state.anchors[rid] = (tag, time.monotonic())
        gate = state.frame(time.monotonic())
        original = copy.deepcopy((initial, gate))
        check = lambda a, b: controlled_dispatch_preflight(
            state.binding, a, b, cohort_tag=tag, client_ids=ids,
            maximum_output_tokens=256, now=gate["received_at"])
        self.assertTrue(check(initial, gate)["conditional_gate_ready"])
        for mutation in ("source", "domain", "drain", "empty", "missing_counter", "cost", "phase",
                         "initial_budget", "orphans", "unavailable"):
            a, b = copy.deepcopy(original)
            if mutation == "source":
                b["observer_sha256"] = "c" * 64
            elif mutation == "domain":
                b["clock_domain"] = "foreign-clock"
            elif mutation == "drain":
                a["pending_batches"] = 1
            elif mutation == "empty":
                b["requests"] = []
                b["running"] = 0
            elif mutation == "missing_counter":
                b["requests"][0].pop("output_tokens")
            elif mutation == "cost":
                b["gateway_snapshot"]["cost_spec"]["intercept"] += .1
            elif mutation == "phase":
                b["requests"][0]["computed_tokens"] = 0
            elif mutation == "initial_budget":
                a["gateway_snapshot"]["budget"] = 16.
            elif mutation == "orphans":
                b["orphaned"] = 1
            else:
                b["available"] = False
            with self.subTest(mutation=mutation):
                result = check(a, b)
                self.assertFalse(result["conditional_gate_ready"])
                self.assertFalse(result["dispatch_permit"])
                if result["conditional_gate_ready"]:
                    self.fail("Negative preflight must not dispatch")
                self.assertEqual(state.posts, [])
        self.assertEqual((initial, gate), original)
        await state.client.aclose()

    async def test_all_assigned_reset_missing_and_failure_keep_bounds_not_ITT_points(self):
        ids = tuple(str(i) for i in range(9))
        start = {rid: 10 for rid in ids}
        end = {rid: 20 for rid in ids}
        end.pop("0")
        end["1"] = 5
        for status in ("applied", "unknown", "failed", "not_dispatched"):
            with self.subTest(status=status):
                result = controlled_window_bounds(
                    ids, start, end, maximum_output_tokens=256,
                    assignment_status=status, applied_at=10., sampled_at=11.)
                self.assertEqual(result["assigned_count"], 9)
                self.assertEqual(len(result["censored_ids"]), 2)
                self.assertEqual(result["mean_interval"], (70 / 9, (70 + 512) / 9))
                self.assertIsNone(result["point_mean"])
                self.assertFalse(result["causal_effect_permit"])
                self.assertFalse(result["goodput_permit"])
        for applied, sampled in ((float("nan"), 11.), (10., 10.5), (10., 10 ** 1000), (False, 11.)):
            with self.subTest(clock="invalid_or_wrong_horizon"):
                result = controlled_window_bounds(
                    ids, start, {rid: 20 for rid in ids}, maximum_output_tokens=256,
                    assignment_status="applied", applied_at=applied, sampled_at=sampled)
                self.assertEqual(result["assigned_count"], 9)
                self.assertIsNone(result["point_mean"])
                self.assertFalse(result["timing_within_20ms"])


class R16JournalPeerTests(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls):
        import sys
        sys.path.insert(0, "/home/daniel_lin/gt/pr32/mayor/mpc-native-integration")

    def peer_tree(self):
        import ast
        from pathlib import Path
        root = Path("/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/"
                    "files/pr33-native-v3-round15-frozen")
        manifest = json.loads((root / "manifest.json").read_bytes())
        for owner, entry in manifest.items():
            for path, digest in entry["files"].items():
                self.assertEqual(hashlib.sha256((root / owner / Path(path).name).read_bytes()).hexdigest(),
                                 digest)
        path = root / "gemini/native_campaign_protocol.py"
        return path, ast.parse(path.read_text())

    async def journal(self, *, leftover=False):
        from pathlib import Path
        from tempfile import TemporaryDirectory
        from dataclasses import asdict
        source = "/home/daniel_lin/gt/pr32/mayor/mpc-native-owner-journal/gateway.py"
        with TemporaryDirectory(dir=Path(__file__).resolve().parent) as folder:
            log, status_path = Path(folder) / "log.jsonl", Path(folder) / "status.json"
            context = CaptureBridgeIntegrationTests.actual_gateway(
                self, source_path=source, settings=dict(
                    MPC_OWNER_LEDGER_ENABLED="true", MAX_ADMITTED_COST="32",
                    SHARED_UPSTREAM_CLIENT="0",
                    TELEMETRY_JSONL=str(log), TELEMETRY_STATUS_JSON=str(status_path)))
            with context as gateway:
                a, b = uid("journal-a"), uid("journal-b")
                cost_a = gateway.mpc_cost_spec.estimate(128, 4096)
                cost_b = gateway.mpc_cost_spec.estimate(4096, 128)
                identity = asdict(gateway.mpc_identity)
                async with gateway.lifespan(gateway.app):
                    self.assertTrue((await gateway.begin_request(
                        cost_a, False, mpc_mark=(a, gateway.mpc_now(), 128, 4096))).accepted)
                    self.assertTrue((await gateway.begin_request(
                        cost_b, False, mpc_mark=(b, gateway.mpc_now(), 4096, 128))).accepted)
                    await gateway.mpc_first_content(a)
                    self.assertEqual(gateway.state["current_admitted_cost"], cost_a + cost_b)
                    async with gateway.state_lock:
                        gateway.state["admission_budget"] = 16.
                        gateway.state["budget_version"] += 1
                        gateway.mpc_changed()
                    self.assertGreater(gateway.state["current_admitted_cost"], 16.)
                    self.assertEqual(gateway.state["current_in_flight"], 2)
                    await gateway.finish_request(cost_b, request_id=b)
                    if not leftover:
                        await gateway.finish_request(cost_a, request_id=a)
                raw, status_raw = log.read_bytes(), status_path.read_bytes()
                binding = dict(gateway_source_sha256=hashlib.sha256(Path(source).read_bytes()).hexdigest(),
                               identity=identity, clock_domain=gateway.mpc_clock_domain,
                               run_id=gateway.telemetry.run_id)
                # The original strict producer join must not certify the new epoch.
                rid = uid("unaccepted-new-source")
                _, adapter = CaptureBridgeIntegrationTests.actual_gateway_adapter(self, gateway, rid)
                with self.assertRaises(ValueError):
                    adapter.receive_gateway_uuid_binding(gateway, rid)
        return raw, status_raw, binding

    async def test_actual_new_epoch_non_FIFO_whole_cost_and_independent_byte_watermark(self):
        raw, status_raw, binding = await self.journal()
        result = audit_owner_journal_epoch(raw, status_raw, **binding)
        events = result["owner_transitions"]
        self.assertEqual([event["kind"] for event in events],
                         ["admission", "admission", "first_content", "terminal", "terminal"])
        self.assertEqual(events[3]["request_id"], events[1]["request_id"])
        self.assertEqual(events[2]["original_charge"], events[0]["original_charge"])
        self.assertTrue(result["per_UUID_whole_cost_release_replay"])
        self.assertEqual(result["final_sequence"], 6)
        self.assertFalse(result["online_cut_available"])
        self.assertFalse(result["source_execution_authenticated"])
        self.assertFalse(result["active_mpc_permit"])
        type(self).epoch_receipt = dict(
            final_sequence=result["final_sequence"], kinds=[e["kind"] for e in events],
            non_FIFO_release=True, byte_seal_verified=True, online_cut_available=False,
            source_execution_authenticated=False, active_mpc_permit=False)
        records, seal = [json.loads(line) for line in raw.splitlines()], json.loads(status_raw)
        for row in records:
            if row.get("event") == "mpc_ledger" and "request_id" in row:
                row["request_id"] = uid("forged-" + row["request_id"])
        forged = b"".join((json.dumps(row) + "\n").encode() for row in records)
        seal.update(telemetry_file_sha256=hashlib.sha256(forged).hexdigest(),
                    telemetry_file_bytes=len(forged))
        merely_consistent = audit_owner_journal_epoch(forged, json.dumps(seal).encode(), **binding)
        self.assertTrue(merely_consistent["conditional_closed_epoch_replay"])
        self.assertFalse(merely_consistent["source_execution_authenticated"])

    async def test_prefix_tampering_wrong_source_cost_owner_and_status_refusals(self):
        raw, status_raw, binding = await self.journal()
        records, status = [json.loads(line) for line in raw.splitlines()], json.loads(status_raw)
        for mutation in ("prefix", "resealed_prefix", "owner", "cost", "first_release", "domain",
                         "source", "drop", "boolean_drop", "legacy_status"):
            rows, seal, source = copy.deepcopy(records), copy.deepcopy(status), dict(binding)
            if mutation in ("prefix", "resealed_prefix"):
                rows = [r for r in rows if not (r.get("event") == "mpc_ledger" and r["sequence"] == 6)]
            elif mutation == "owner":
                next(r for r in rows if r.get("change_kind") == "terminal")["request_id"] = uid("unknown")
            elif mutation == "cost":
                next(r for r in rows if r.get("change_kind") == "terminal")["request_cost"] *= 2
            elif mutation == "first_release":
                next(r for r in rows if r.get("change_kind") == "first_content")["change_kind"] = "terminal"
            elif mutation == "domain":
                next(r for r in rows if r.get("event") == "mpc_ledger")["clock_domain"] = "foreign"
            elif mutation == "source":
                source["gateway_source_sha256"] = "a4a8229b0f636b64c945881d062c3ee925ef5fccc5ba2e6fc7629657d3575ea7"
            elif mutation == "drop":
                seal["dropped"] = 1
            elif mutation == "boolean_drop":
                seal["dropped"] = False
            else:
                seal.pop("mpc_final_sequence")
            changed = b"".join((json.dumps(r) + "\n").encode() for r in rows)
            if mutation != "prefix":
                seal.update(telemetry_file_sha256=hashlib.sha256(changed).hexdigest(),
                            telemetry_file_bytes=len(changed))
            with self.subTest(mutation=mutation):
                with self.assertRaises(ValueError):
                    audit_owner_journal_epoch(changed, json.dumps(seal).encode(), **source)

    async def test_leftover_status_failed_even_when_owner_integrity_true(self):
        raw, status_raw, binding = await self.journal(leftover=True)
        status = json.loads(status_raw)
        self.assertEqual(status["status"], "failed")
        self.assertTrue(status["mpc_ledger_complete"])
        self.assertEqual(status["mpc_remaining_requests"], 1)
        with self.assertRaisesRegex(ValueError, "closure"):
            audit_owner_journal_epoch(raw, status_raw, **binding)

    async def test_frozen_Gem_R15_gate_still_accepts_wrong_source_duplicate_tags_and_missing_counters(self):
        import ast
        from types import SimpleNamespace
        path, tree = self.peer_tree()
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "LiveNativeCohortRunner")
        method = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == "run_arm")
        block = next(n for n in method.body if isinstance(n, ast.Try))
        start = next(i for i, n in enumerate(block.body) if isinstance(n, ast.Assign)
                     and any(isinstance(t, ast.Name) and t.id == "poll_timeout_s" for t in n.targets))
        stop = next(i for i, n in enumerate(block.body) if isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == "t_gate" for t in n.targets))
        body = block.body[start:stop]
        func = ast.AsyncFunctionDef(name="gate", args=ast.arguments(posonlyargs=[], args=[], kwonlyargs=[],
                                   kw_defaults=[], defaults=[]),
                                   body=body + [ast.Return(value=ast.Name(id="gate_satisfied", ctx=ast.Load()))],
                                   decorator_list=[])
        rid, tag = uid("gate-client"), uid("gate-cohort")
        wrong = dict(complete=True, run_id="foreign", clock_domain="foreign",
                     observer_sha256="wrong", requests=[
                         dict(request_id="opaque-" + str(i), cohort_id=tag, phase="decode",
                              prompt_tokens=4096, computed_tokens=128, gateway_request_id=rid)
                         for i in range(9)])
        async def get(*args, **kwargs):
            return SimpleNamespace(json=lambda: wrong)
        import time
        namespace = dict(asyncio=asyncio, proto=SimpleNamespace(anchor_cohort_count=9,
                         anchor_prompt_tokens=128, gate_poll_timeout_s=.1),
                         self=SimpleNamespace(clock=time.monotonic), nat_cli=SimpleNamespace(get=get),
                         observer_key="CPU", cohort_tag=tag, anchor_client_rids=(rid,))
        exec(compile(ast.fix_missing_locations(ast.Module(body=[func], type_ignores=[])),
                     str(path), "exec"), namespace)
        self.assertTrue(await namespace["gate"]())
        import hashlib
        import math
        import uuid
        from pathlib import Path
        observer_path = Path("/home/daniel_lin/gt/pr32/mayor/mpc-native-integration/"
                             "experiments/mpc-research/native_observer/pr33_native_observer.py")
        self.assertEqual(hashlib.sha256(observer_path.read_bytes()).hexdigest(),
                         "77633dc7652066e45b7680d297d3e36ddb97a3e12222de9f526a76b9a01d66b4")
        names = ("sampling_ignore_eos", "sampling_identifier", "observe")
        observer_nodes = [n for n in ast.parse(observer_path.read_text()).body
                          if isinstance(n, ast.FunctionDef) and n.name in names]
        import re
        env = dict(math=math, uuid=uuid, time=time, clock_domain=lambda: "CPU-clock",
                   hashlib=hashlib, Path=Path, re=re, __file__=str(observer_path),
                   importlib=SimpleNamespace(metadata=SimpleNamespace(version=lambda name: "0.30.0")))
        exec(compile(ast.Module(body=observer_nodes, type_ignores=[]), str(observer_path), "exec"), env)
        actual_ids = tuple(uid("actual-observer-" + str(i)) for i in range(9))
        requests = [SimpleNamespace(
            request_id="opaque:" + str(i), num_prompt_tokens=128, num_computed_tokens=129,
            num_output_tokens=1, max_tokens=256, sampling_params=SimpleNamespace(
                ignore_eos=True, extra_args=dict(pr33_cohort_id=tag, pr33_gateway_request_id=rid)))
                    for i, rid in enumerate(actual_ids)]
        core = SimpleNamespace(_pr33_observer_run=uid("CPU-native"), batch_queue=[],
                               scheduler=SimpleNamespace(running=requests, waiting=[], skipped_waiting=[],
                               num_waiting_for_streaming_input=0,
                               kv_cache_manager=SimpleNamespace(usage=.1)))
        actual = env["observe"](core)
        self.assertTrue(all("phase" not in row for row in actual["requests"]))
        wrong.clear()
        wrong.update(actual)
        namespace["anchor_client_rids"] = actual_ids
        self.assertFalse(await namespace["gate"]())

    async def test_frozen_Gem_R15_survivor_mean_and_client_apply_clock_remain_unqualified(self):
        import ast
        from types import SimpleNamespace
        path, tree = self.peer_tree()
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "LiveNativeCohortRunner")
        method = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == "run_arm")
        block = next(n for n in method.body if isinstance(n, ast.Try))
        def assignment(name):
            return next(n for n in block.body if isinstance(n, ast.Assign)
                        and any(isinstance(t, ast.Name) and t.id == name for t in n.targets))
        counter_loop = next(n for n in block.body if isinstance(n, ast.For)
                            and isinstance(n.target, ast.Name) and n.target.id == "eid")
        mean_if = next(n for n in block.body if isinstance(n, ast.If)
                       and isinstance(n.test, ast.Name) and n.test.id == "anchor_progress")
        namespace = dict(preassigned_engine_ids=("a", "b"), gate_output_tokens=dict(a=1, b=1),
                         end_matching=dict(a=dict(output_tokens=11)), anchor_progress={},
                         anchor_fates={}, censored_count=0, proto=SimpleNamespace(anchor_max_tokens=256,
                         evaluation_window_s=1.), self=SimpleNamespace(clock=lambda: 10.2),
                         act_res=dict(status="applied", response=dict(applied_at=10.)))
        nodes = [assignment("t_apply"), assignment("target_window_end"), counter_loop, mean_if]
        exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), "exec"), namespace)
        self.assertEqual(namespace["target_window_end"], 11.2)
        self.assertEqual(namespace["mean_prog"], 10.)
        self.assertEqual(namespace["censored_count"], 1)
        bound = controlled_window_bounds(("a", "b"), dict(a=1, b=1), dict(a=11),
                                        maximum_output_tokens=256, assignment_status="applied",
                                        applied_at=10., sampled_at=11.2)
        self.assertEqual(bound["mean_interval"], (5., 133.))
        self.assertIsNone(bound["point_mean"])

    async def test_actual_counter_gate_max512_uses_actual_prompt_bijection_and_charged_stock(self):
        import time
        from dataclasses import asdict
        from mpc_lab.contracts import CostSpec, ModelParameters, RequestMark, Snapshot
        from mpc_lab.native_state import NativeBinding
        from mpc_lab.runtime import snapshot_to_dict
        cost = CostSpec()
        identity = ModelParameters(cost_spec=cost).identity
        binding = NativeBinding("CPU-counter-clock", uid("CPU-counter-gw"), uid("CPU-counter-native"),
                                "77633dc7652066e45b7680d297d3e36ddb97a3e12222de9f526a76b9a01d66b4",
                                identity)
        ids = tuple(uid("counter-512-" + str(i)) for i in range(5))
        tag = uid("counter-512-cohort")
        t = time.monotonic()
        initial_snapshot = snapshot_to_dict(Snapshot(
            binding.gateway_run_id, binding.clock_domain, t, 32., 0, (), identity))
        initial_snapshot["cost_spec"] = asdict(cost)
        initial = dict(schema="pr33-native-read-only-v1", available=True, complete=True,
                       run_id=binding.native_run_id, observer_sha256=binding.observer_sha256,
                       vllm_version="0.30.0", clock_domain=binding.clock_domain,
                       sampled_at=t, frontend_sampled_at=t, received_at=t, gateway_received_at=t,
                       gateway_snapshot=initial_snapshot, running=0, waiting=0, orphaned=0,
                       pending_batches=0, frontend_unfinished=0, kv_cache_usage=0., requests=[])
        marks = tuple(RequestMark(rid, cost.estimate(512, 512), 512, 512, t + .001, t + .001)
                      for rid in ids)
        snapshot = snapshot_to_dict(Snapshot(
            binding.gateway_run_id, binding.clock_domain, t + .01, 32., 0, marks, identity))
        snapshot["cost_spec"] = asdict(cost)
        # Exactly the actual observer's request fields; no fabricated phase attribute.
        rows = [dict(request_id="opaque-counter-" + str(i), prompt_tokens=256,
                     computed_tokens=257, output_tokens=1, maximum_output_tokens=512,
                     ignore_eos=True, cohort_id=tag, gateway_request_id=rid)
                for i, rid in enumerate(ids)]
        gate = dict(initial, gateway_snapshot=snapshot, sampled_at=t + .01,
                    frontend_sampled_at=t + .01, received_at=t + .01, gateway_received_at=t + .01,
                    running=5, frontend_unfinished=5, requests=rows)
        check = lambda frame: controlled_dispatch_preflight(
            binding, initial, frame, cohort_tag=tag, client_ids=ids,
            maximum_output_tokens=512, now=t + .01)
        result = check(gate)
        self.assertTrue(result["conditional_gate_ready"])
        self.assertFalse(result["dispatch_permit"])
        actual_stock = sum(result["original_charges"].values())
        nominal_stock = 5 * cost.estimate(128, 512)
        bursts = 4 * cost.estimate(4096, 128)
        self.assertLess(nominal_stock + bursts, 32.)
        self.assertGreater(actual_stock + bursts, 32.)
        for mutation in ("actual_prompt", "output_zero", "EOS", "bijection", "maximum"):
            changed = copy.deepcopy(gate)
            row = changed["requests"][0]
            if mutation == "actual_prompt":
                row["computed_tokens"] = 255  # Still exceeds nominal128, not actual256.
            elif mutation == "output_zero":
                row["output_tokens"] = 0
            elif mutation == "EOS":
                row["ignore_eos"] = False
            elif mutation == "bijection":
                row["gateway_request_id"] = ids[1]
            else:
                row["maximum_output_tokens"] = 256
            with self.subTest(mutation=mutation):
                self.assertFalse(check(changed)["conditional_gate_ready"])
        self.assertTrue(all("phase" not in row for row in gate["requests"]))
        self.assertFalse(result["physical_survival_verified"])


class R17SerializedSourceTests(unittest.IsolatedAsyncioTestCase):
    SOURCE_SHA256 = "0b1a80ade258d8875ba80a072c4f360bfa5d4a7ac312bd222c0571380b341570"

    @classmethod
    def setUpClass(cls):
        import sys
        sys.path.insert(0, "/home/daniel_lin/gt/pr32/mayor/mpc-native-integration")

    def gateway(self, settings=None):
        return CaptureBridgeIntegrationTests.actual_gateway(
            self, source_path="/home/daniel_lin/gt/pr32/mayor/mpc-native-owner-serialized-journal/gateway.py",
            source_sha256=self.SOURCE_SHA256,
            settings=dict(MPC_OWNER_LEDGER_ENABLED="true", SHARED_UPSTREAM_CLIENT="0",
                          **(settings or {})))

    async def test_both_actual_handlers_recheck_closing_after_json(self):
        import dataclasses
        import types
        receipts = {}
        for endpoint in ("update_budget", "mpc_update_budget"):
            with self.subTest(endpoint=endpoint), self.gateway() as gateway:
                payload = dict(budget=16)
                if endpoint == "mpc_update_budget":
                    payload.update(schema=gateway.SCHEMA, run_id=gateway.telemetry.run_id,
                                   clock_domain=gateway.mpc_clock_domain,
                                   identity=dataclasses.asdict(gateway.mpc_identity),
                                   expected_version=0, not_after=gateway.mpc_now() + .1,
                                   operation_id=uid("serialized-closing-control"))
                async def json_after_closing():
                    async with gateway.state_lock:
                        gateway.telemetry.owner_ledger_closing = True
                    gateway.telemetry.enabled = False
                    return payload
                request = types.SimpleNamespace(headers={"x-admin-api-key": "cpu-fixture-key"},
                                                json=json_after_closing)
                original_budget = gateway.state["admission_budget"]
                response = await getattr(gateway, endpoint)(request)
                self.assertEqual(response.status_code, 503)
                self.assertEqual(gateway.state["budget_version"], 0)
                self.assertEqual(gateway.state["admission_budget"], original_budget)
                self.assertEqual(gateway.mpc_sequence, 0)
                self.assertEqual(gateway.telemetry.records, [])
                receipts[endpoint] = dict(http_status=503, budget_version=0,
                                          producer_sequence=0, buffered_rows=0)
        type(self).closing_receipt = receipts

    async def test_actual_status_rejects_foreign_nonledger_row(self):
        from pathlib import Path
        from tempfile import TemporaryDirectory
        receipts = {}
        for foreign in (False, True):
            with self.subTest(foreign=foreign), TemporaryDirectory(
                    dir=Path(__file__).resolve().parent) as folder:
                log, status_path = Path(folder) / "log.jsonl", Path(folder) / "status.json"
                with self.gateway(dict(TELEMETRY_JSONL=str(log),
                                       TELEMETRY_STATUS_JSON=str(status_path))) as gateway:
                    log.write_text(json.dumps(dict(event="cpu-nonledger",
                        run_id=uid("foreign-nonledger") if foreign else gateway.telemetry.run_id)) + "\n")
                    async with gateway.lifespan(gateway.app):
                        pass
                    status = json.loads(status_path.read_bytes())
                    raw = log.read_bytes()
                    self.assertEqual(status["status"], "failed" if foreign else "closed")
                    self.assertIs(status["mpc_ledger_complete"], not foreign)
                    self.assertEqual(status["mpc_producer_final_sequence"], 0)
                    self.assertEqual(status["mpc_final_sequence"], 0)
                    self.assertEqual(status["mpc_ledger_rows_written"], 0)
                    self.assertEqual(status["telemetry_file_bytes"], len(raw))
                    self.assertEqual(status["telemetry_file_sha256"], hashlib.sha256(raw).hexdigest())
                    receipts["foreign" if foreign else "same_run"] = dict(
                        status=status["status"], ledger_complete=status["mpc_ledger_complete"],
                        producer_sequence=0, written_sequence=0, written_rows=0)
        type(self).nonledger_receipt = receipts


class R17WrittenSourceTests(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls):
        import sys
        sys.path.insert(0, "/home/daniel_lin/gt/pr32/mayor/mpc-native-integration")

    def gateway(self, settings=None):
        return CaptureBridgeIntegrationTests.actual_gateway(
            self, source_path="/home/daniel_lin/gt/pr32/mayor/mpc-native-owner-written-journal/gateway.py",
            source_sha256=WRITTEN_JOURNAL_GATEWAY_SHA256,
            settings=dict(MPC_OWNER_LEDGER_ENABLED="true", SHARED_UPSTREAM_CLIENT="0",
                          **(settings or {})))

    async def written_run(self, *, unwritten=False, second_cleanup=False):
        from dataclasses import asdict
        from pathlib import Path
        from tempfile import TemporaryDirectory
        with TemporaryDirectory(dir=Path(__file__).resolve().parent) as folder:
            log, status_path = Path(folder) / "log.jsonl", Path(folder) / "status.json"
            with self.gateway(dict(TELEMETRY_JSONL=str(log),
                                   TELEMETRY_STATUS_JSON=str(status_path))) as gateway:
                if unwritten:
                    gateway.telemetry.enabled = False
                    gateway.mpc_changed()
                rid = uid("written-owner")
                cost = gateway.mpc_cost_spec.estimate(128, 256)
                original_flush = gateway.telemetry.flush
                injected = 0
                async def late_flush(path):
                    nonlocal injected
                    await original_flush(path)
                    if (getattr(gateway.telemetry, "owner_ledger_closing", False)
                            and injected < (2 if second_cleanup else 1)):
                        owner = rid if injected == 0 else uid("second-written-owner")
                        injected += 1
                        await gateway.mpc_first_content(owner)
                        await gateway.finish_request(cost, request_id=owner)
                gateway.telemetry.flush = late_flush
                async with gateway.lifespan(gateway.app):
                    self.assertTrue((await gateway.begin_request(
                        cost, False, mpc_mark=(rid, gateway.mpc_now(), 128, 256))).accepted)
                    if second_cleanup:
                        self.assertTrue((await gateway.begin_request(
                            cost, False, mpc_mark=(uid("second-written-owner"),
                                                  gateway.mpc_now(), 128, 256))).accepted)
                self.assertTrue(injected)
                binding = dict(gateway_source_sha256=WRITTEN_JOURNAL_GATEWAY_SHA256,
                               run_id=gateway.telemetry.run_id, clock_domain=gateway.mpc_clock_domain,
                               identity=asdict(gateway.mpc_identity))
                raw, status = log.read_bytes(), status_path.read_bytes()
        return raw, status, binding

    async def test_cleanup_after_second_flush_fails_closed_with_unflushed_rows(self):
        raw, status_raw, binding = await self.written_run(second_cleanup=True)
        status = json.loads(status_raw)
        self.assertEqual(status["status"], "failed")
        self.assertEqual(status["mpc_remaining_requests"], 0)
        self.assertEqual(status["dropped"], 0)
        self.assertEqual(status["mpc_unflushed_records"], 2)
        self.assertEqual(status["mpc_producer_final_sequence"], 6)
        self.assertEqual(status["mpc_final_sequence"], 4)
        self.assertEqual(status["mpc_ledger_rows_written"], 4)
        with self.assertRaises(ValueError):
            audit_written_journal_seal(raw, status_raw, **binding)
        type(self).second_flush_receipt = dict(status="failed", producer_sequence=6,
                                               written_sequence=4, written_rows=4, unflushed=2)

    async def test_actual_corrected_source_flushes_late_cleanup_and_binds_written_rows(self):
        raw, status_raw, binding = await self.written_run()
        result = audit_written_journal_seal(raw, status_raw, **binding)
        status = json.loads(status_raw)
        ledger = [json.loads(line) for line in raw.splitlines()
                  if json.loads(line).get("event") == "mpc_ledger"]
        self.assertEqual([row["change_kind"] for row in ledger], ["admission", "first_content", "terminal"])
        self.assertEqual(status["mpc_producer_final_sequence"], 3)
        self.assertEqual(status["mpc_final_sequence"], 3)
        self.assertEqual(status["mpc_ledger_rows_written"], 3)
        self.assertEqual(status["mpc_unflushed_records"], 0)
        self.assertEqual(result["written_rows"], 3)
        self.assertFalse(result["online_cut_available"])
        self.assertFalse(result["active_mpc_permit"])
        with self.assertRaisesRegex(ValueError, "Unregistered owner"):
            audit_owner_journal_epoch(raw, status_raw, **binding)
        type(self).written_receipt = dict(status="closed", producer_sequence=3, written_sequence=3,
                                          written_rows=3, unflushed=0, late_cleanup_preserved=True)

    async def test_actual_unwritten_initial_sequence_is_failed_not_relabelled_complete(self):
        raw, status_raw, binding = await self.written_run(unwritten=True)
        status = json.loads(status_raw)
        self.assertEqual(status["status"], "failed")
        self.assertFalse(status["mpc_ledger_complete"])
        self.assertEqual(status["mpc_producer_final_sequence"], 4)
        self.assertEqual(status["mpc_final_sequence"], 4)
        self.assertEqual(status["mpc_ledger_rows_written"], 3)
        with self.assertRaises(ValueError):
            audit_written_journal_seal(raw, status_raw, **binding)
        type(self).gap_receipt = dict(status="failed", producer_sequence=4,
                                     written_sequence=4, written_rows=3)

    async def test_actual_disabled_writer_NoneMark_and_closing_refuse_admission_and_control(self):
        import httpx
        from starlette.routing import Route
        with self.gateway() as gateway:
            rid = uid("refused-written-owner")
            cost = gateway.mpc_cost_spec.estimate(128, 256)
            mark = (rid, gateway.mpc_now(), 128, 256)
            self.assertFalse((await gateway.begin_request(cost, False)).accepted)
            gateway.telemetry.enabled = False
            self.assertFalse((await gateway.begin_request(cost, False, mpc_mark=mark)).accepted)
            gateway.telemetry.enabled = True
            gateway.telemetry.owner_ledger_closing = True
            self.assertFalse((await gateway.begin_request(cost, False, mpc_mark=mark)).accepted)
            gateway.app.routes.extend([
                Route("/admin/budget", gateway.update_budget, methods=["POST"]),
                Route("/admin/mpc/budget", gateway.mpc_update_budget, methods=["POST"])])
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app=gateway.app),
                                         base_url="http://CPU-written.test") as client:
                for url in ("/admin/budget", "/admin/mpc/budget"):
                    response = await client.post(url, json={}, headers={"x-admin-api-key": "cpu-fixture-key"})
                    self.assertEqual(response.status_code, 503)
            self.assertEqual(gateway.state["current_in_flight"], 0)
            self.assertEqual(gateway.mpc_sequence, 0)
            self.assertEqual(gateway.state["budget_version"], 0)
        type(self).refusal_receipt = dict(NoneMark=True, disabled_writer=True, closing=True,
                                         control_http_status=503, producer_sequence=0)

    async def test_control_guard_checked_before_json_does_not_cover_closing_race(self):
        import dataclasses
        import types
        receipts = {}
        for endpoint in ("update_budget", "mpc_update_budget"):
            with self.subTest(endpoint=endpoint), self.gateway() as gateway:
                payload = dict(budget=16)
                if endpoint == "mpc_update_budget":
                    payload.update(schema=gateway.SCHEMA, run_id=gateway.telemetry.run_id,
                                   clock_domain=gateway.mpc_clock_domain,
                                   identity=dataclasses.asdict(gateway.mpc_identity),
                                   expected_version=0, not_after=gateway.mpc_now() + .1,
                                   operation_id=uid("closing-control-race"))
                async def json_after_closing():
                    gateway.telemetry.owner_ledger_closing = True
                    gateway.telemetry.enabled = False
                    return payload
                request = types.SimpleNamespace(headers={"x-admin-api-key": "cpu-fixture-key"},
                                                json=json_after_closing)
                response = await getattr(gateway, endpoint)(request)
                self.assertEqual(getattr(response, "status_code", 200), 200)
                self.assertEqual(gateway.state["budget_version"], 1)
                self.assertEqual(gateway.state["admission_budget"], 16)
                self.assertEqual(gateway.mpc_sequence, 1)
                self.assertEqual(gateway.telemetry.records, [])
                receipts[endpoint] = dict(http_status=200, budget_version=1,
                                          producer_sequence=1, buffered_rows=0)
        type(self).closing_race_receipt = receipts

    def gem_source(self):
        import ast
        import subprocess
        raw = subprocess.check_output([
            "git", "show", "5aecb10c2bd2af543a3e0ad19ceec9cac4f5cc77:"
            "experiments/mpc-research/native-v3/native_campaign_protocol.py"])
        self.assertEqual(hashlib.sha256(raw).hexdigest(),
                         "7b6e48e6e163686c33f964260ad3d8c4734bea923892e77c748ac554c187b60d")
        tree = ast.parse(raw)
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "LiveNativeCohortRunner")
        method = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == "run_arm")
        return method, next(n for n in method.body if isinstance(n, ast.Try))

    async def test_exact_repaired_Gem_remaining_clock_counter_survivor_schedule_and_auto_permit(self):
        import ast
        from types import SimpleNamespace
        method, block = self.gem_source()
        def assignment(name):
            return next(n for n in block.body if isinstance(n, ast.Assign)
                        and any(isinstance(t, ast.Name) and t.id == name for t in n.targets))
        permit_node = next(n for n in method.body if isinstance(n, ast.Assign)
                           and any(isinstance(t, ast.Name) and t.id == "prm" for t in n.targets))
        loop = next(n for n in block.body if isinstance(n, ast.For)
                    and isinstance(n.target, ast.Name) and n.target.id == "eid")
        mean_if = next(n for n in block.body if isinstance(n, ast.If)
                       and isinstance(n.test, ast.Name) and n.test.id == "anchor_progress")
        namespace = dict(self=SimpleNamespace(clock=lambda: 10.2), permit=None,
                         IdentificationPermit=lambda **kw: kw, id_obj="CPU-identity",
                         gw_run="CPU-run", clock_dom="CPU-domain",
                         proto=SimpleNamespace(evaluation_window_s=1., anchor_max_tokens=512),
                         preassigned_engine_ids=("a", "b"), gate_output_tokens=dict(a=1, b=1),
                         end_matching=dict(a=dict(output_tokens=11)), anchor_progress={},
                         anchor_fates={}, censored_count=0,
                         act_res=dict(status="applied", response=dict(applied_at=10.)))
        nodes = [permit_node, assignment("t_apply"), assignment("target_window_end"), loop, mean_if]
        exec(compile(ast.Module(body=nodes, type_ignores=[]), "git:5aecb10", "exec"), namespace)
        self.assertTrue(namespace["prm"]["approved"])
        self.assertEqual(namespace["target_window_end"], 11.2)
        self.assertEqual(namespace["mean_prog"], 10.)
        self.assertEqual(namespace["censored_count"], 1)
        namespace["self"] = SimpleNamespace(clock=lambda: 10.45)
        exec(compile(ast.Module(body=[assignment("t_bursts_dispatched")], type_ignores=[]),
                     "git:5aecb10", "exec"), namespace)
        scheduled = next(kw.value for n in ast.walk(block) if isinstance(n, ast.Call)
                         and isinstance(n.func, ast.Name) and n.func.id == "capture_chat"
                         for kw in n.keywords if kw.arg == "scheduled_at"
                         and isinstance(kw.value, ast.Name) and kw.value.id == "t_bursts_dispatched")
        self.assertEqual(eval(compile(ast.Expression(scheduled), "git:5aecb10", "eval"), namespace), 10.45)
        type(self).gem_receipt = dict(consumer_apply=10.2, server_apply=10., wrong_target=11.2,
                                     gate_origin_mean=10., censored_count=1, auto_approved=True,
                                     receipt_relative_burst_due=10.45, server_relative_burst_due=10.1)

    async def test_explicit_matching_permit_server_apply_all_assigned_bracket_reference(self):
        binding = dict(gateway_source_sha256=WRITTEN_JOURNAL_GATEWAY_SHA256,
                       run_id=uid("counter-ref-run"), clock_domain="counter-ref-domain",
                       identity=dict(model="measurement-only"))
        permit = dict(binding, approved=True, expires_at=12.)
        command = dict(binding, status="applied", applied_at=10., issued_at=9.95, not_after=10.05,
                       expected_version=0, budget_version=1, budget=32.)
        before = dict(binding, sampled_at=10.99, received_at=11., counts=dict(a=8, b=6))
        after = dict(binding, sampled_at=11.01, received_at=11.02, counts=dict(a=12))
        result = audit_server_counter_bracket(binding, permit, command, dict(a=2, b=2),
                                             before, after, assigned_ids=("a", "b"),
                                             maximum_output_tokens=512)
        self.assertEqual(result["server_target"], 11.)
        self.assertEqual(result["assigned_count"], 2)
        self.assertEqual(result["mean_interval"], (3., 261.))
        self.assertEqual(result["censored_ids"], ["b"])
        self.assertIsNone(result["point_mean"])
        self.assertFalse(result["native_permit"])
        self.assertFalse(result["active_mpc_permit"])
        for mutation in ("no_permit", "wrong_domain", "noncompliant", "expired_TTL", "unbracketed"):
            p, c, lo, hi = copy.deepcopy((permit, command, before, after))
            if mutation == "no_permit":
                p = None
            elif mutation == "wrong_domain":
                p["clock_domain"] = "wrong"
            elif mutation == "noncompliant":
                c["status"] = "unknown"
            elif mutation == "expired_TTL":
                c["not_after"] = 9.99
            else:
                lo["sampled_at"] = 11.05
                lo["received_at"] = 11.06
            with self.subTest(mutation=mutation):
                with self.assertRaises(ValueError):
                    audit_server_counter_bracket(binding, p, c, dict(a=2, b=2), lo, hi,
                                                 assigned_ids=("a", "b"), maximum_output_tokens=512)
        type(self).positive_receipt = dict(server_target=11., all_assigned=2, mean_interval=[3., 261.],
                                          point_mean=None, native_permit=False, active_mpc_permit=False)


class R14ProposalTests(unittest.TestCase):
    def peer_tree(self):
        import ast
        from pathlib import Path
        path = Path("/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/"
                    "files/pr33-native-v3-round13-frozen/gemini/native_campaign_protocol.py")
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),
                         "21103b14840397bc37de82d00274a61463d53f2d681b5de57ba5fe169bd4aecb")
        return path, ast.parse(path.read_text())

    def test_sourced_geometries_do_not_select_survival_or_statistical_power(self):
        from mpc_lab.contracts import CostSpec
        proposal = controlled_geometry_proposals(CostSpec())
        nine, five = proposal["candidates"]
        for candidate in (nine, five):
            self.assertTrue(candidate["initial32_fits"])
            self.assertTrue(candidate["low16_first_rejects_while_all_held"])
            self.assertTrue(candidate["high32_four_fit_while_no_foreign_stock"])
            self.assertEqual(candidate["first_release_count_allowing_low_admission"], 2)
            self.assertFalse(candidate["survival_through_1s_verified"])
            self.assertIsNone(candidate["physical_rate_upper_bound"])
            self.assertFalse(candidate["actual_Gateway_charge_geometry_qualified"])
            self.assertEqual(candidate["independent_pair_unit"], 12)
            maximum = candidate["max_tokens"]
            # Hypothetical rate, not fitted/native: both allowed finite maxima can expire within1s.
            time_to_max = (maximum - 1) / (2 * maximum)
            self.assertLess(time_to_max, candidate["primary_horizon_s"])
        self.assertLess(five["after_one_release_low_margin"], nine["after_one_release_low_margin"])
        self.assertEqual(five["per_pair_reported_counter_range"][1],
                         2 * nine["per_pair_reported_counter_range"][1])
        self.assertIsNone(proposal["selected_geometry"])

    def test_exact_peer_mock_retains_ignore_EOS_request_past_its_maximum(self):
        import ast
        import __future__
        import httpx
        from mpc_lab.contracts import CostSpec
        path, tree = self.peer_tree()
        node = next(n for n in tree.body if isinstance(n, ast.ClassDef)
                    and n.name == "RealNativeCohortTransport")
        namespace = dict(httpx=httpx, get_sourced_cost_spec=CostSpec)
        exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), "exec",
                     flags=__future__.annotations.compiler_flag), namespace)
        transport = namespace["RealNativeCohortTransport"]()
        transport.active_requests["mock-ID"] = dict(
            phase="decode", prompt_tokens=128, computed_tokens=128,
            output_tokens=0, output_tokens_float=0., max_tokens=2, ignore_eos=True)
        transport.advance_clock(1.)
        request = transport.active_requests["mock-ID"]
        self.assertGreater(request["output_tokens"], request["max_tokens"])
        self.assertEqual(request["phase"], "decode")
        self.assertIn("mock-ID", transport.active_requests)

    def test_exact_peer_rewrite_assertion_rejects_actual_validated_client_UUID_equality(self):
        import ast
        path, tree = self.peer_tree()
        assignment = next(n for n in ast.walk(tree) if isinstance(n, ast.Assign)
                          and any(isinstance(t, ast.Name) and t.id == "gw_rewritten" for t in n.targets))
        rid = uid("actual-validated-client-UUID")
        namespace = dict(matching_at_gate=[dict(gateway_request_id=rid)], anchor_client_rids=[rid])
        wrong = eval(compile(ast.Expression(assignment.value), str(path), "eval"), namespace)
        self.assertFalse(wrong)
        self.assertIn(namespace["matching_at_gate"][0]["gateway_request_id"], namespace["anchor_client_rids"])

    def test_exact_peer_pair_wrapper_loses_failed_arm_instead_of_an_all_assigned_receipt(self):
        import ast
        import __future__
        from types import SimpleNamespace
        path, tree = self.peer_tree()
        node = next(n for n in tree.body if isinstance(n, ast.AsyncFunctionDef)
                    and n.name == "run_real_native_cohort_pipeline")
        calls, paired = [], []
        class FailingRunner:
            def __init__(self, **kwargs):
                pass
            async def run_arm(self, arm, budget, transport):
                calls.append((arm, budget))
                if arm == "arm_b":
                    raise RuntimeError("CPU missing ACK counterexample")
                return SimpleNamespace(anchor_mean_progress=1.)
        namespace = dict(RealNativeCohortRunner=FailingRunner,
                         RealNativeCohortPairedReceipt=lambda **kwargs: paired.append(kwargs))
        exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), "exec",
                     flags=__future__.annotations.compiler_flag), namespace)
        protocol = SimpleNamespace(post_gate_assigned_budget_arm_a=16., post_gate_assigned_budget_arm_b=32.)
        with self.assertRaisesRegex(RuntimeError, "missing ACK"):
            asyncio.run(namespace["run_real_native_cohort_pipeline"](protocol, object(), object()))
        self.assertEqual(calls, [("arm_a", 16.), ("arm_b", 32.)])
        self.assertEqual(paired, [])


class Source144LoaderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import importlib.util
        from pathlib import Path
        import sys
        cls.folder = Path("/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/"
                          "files/pr33-native-v3-new-source-train-fifteen-sixteen-frozen")
        path = Path("/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/"
                    "files/pr33-native-v3-round13-frozen/opus/native_release_model.py")
        spec = importlib.util.spec_from_file_location("sol_source144_frozen_opus", path)
        cls.model = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = cls.model
        spec.loader.exec_module(cls.model)
        cls.index_raw = (cls.folder / "index.json").read_bytes()
        cls.manifest_raw = (cls.folder / "verified-artifact-sha256.jsonl").read_bytes()

    def temporary_folder(self):
        from pathlib import Path
        import tempfile
        return tempfile.TemporaryDirectory(prefix="sol-source144-test-", dir=str(Path(__file__).parent.resolve()))

    def write_metadata(self, folder, *, index=None, manifest=None):
        from pathlib import Path
        root = Path(folder)
        (root / "index.json").write_bytes(self.index_raw if index is None else json.dumps(index).encode())
        (root / "verified-artifact-sha256.jsonl").write_bytes(self.manifest_raw if manifest is None else manifest)
        return root

    def test_actual_complete_TRAIN15_16_source_registered_without_frozen_model_mutation(self):
        common, sources = copy.deepcopy(self.model.COMMON_BINDING), copy.deepcopy(self.model.SOURCE_BINDINGS)
        with self.assertRaisesRegex(ValueError, "replica_source_binding"):
            self.model.load_replica(self.folder)
        episodes, receipt = load_source144_replica(self.model, self.folder)
        self.assertEqual(len(episodes), 20)
        self.assertEqual(receipt["verified_artifacts"], 40)
        self.assertEqual({e["seed_block"] for e in episodes}, {181015, 181016})
        self.assertTrue(all(e["identity"] == SOURCE144_IDENTITY for e in episodes))
        self.assertTrue(all(e["source_commit"] == SOURCE144_BINDING["source_commit"] for e in episodes))
        self.assertTrue(all(e["ledger"] is None for e in episodes))
        self.assertEqual(self.model.COMMON_BINDING, common)
        self.assertEqual(self.model.SOURCE_BINDINGS, sources)
        self.assertNotIn(SOURCE144_BINDING["source_commit"], sources)
        self.assertFalse(receipt["forecast_scored"])
        self.assertFalse(receipt["fit_performed"])
        self.assertFalse(receipt["gates_changed"])
        type(self).source144_receipt = receipt

    def test_actual_public_smoke_same_source_but_different_protocol_is_not_TRAIN15_16(self):
        from pathlib import Path
        import tarfile
        path = Path("/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/"
                    "files/observation-smoke-144cef3-public.tar.gz")
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),
                         "cdcb249b397c9bab2c11a8beeb05dc360eaa9444cc1db872319f824dc4a8eafa")
        with tarfile.open(path) as archive:
            raw = archive.extractfile("index.json").read()
            index = json.loads(raw)
            self.assertEqual(index["source_commit"], SOURCE144_BINDING["source_commit"])
            self.assertEqual(index["model_identity"], SOURCE144_IDENTITY)
            self.assertNotEqual(index["protocol_sha256"], SOURCE144_BINDING["protocol_sha256"])
            with self.assertRaisesRegex(ValueError, "source144_source_protocol_domain"):
                _register_source144(index)
            with self.temporary_folder() as directory:
                root = Path(directory)
                (root / "index.json").write_bytes(raw)
                # The actual smoke must refuse before accessing any Train artifact/manifest.
                with self.assertRaisesRegex(ValueError, "source144_source_protocol_domain"):
                    load_source144_replica(self.model, root)

    def test_strict_model_core_flags_clock_and_scope_reject_before_any_artifact_read(self):
        for mutation in ("source", "core", "cost", "support", "collector", "protocol", "domain",
                         "model", "calibrated", "active", "launch", "split17", "split37", "missing-arm"):
            with self.subTest(mutation=mutation), self.temporary_folder() as directory:
                index = json.loads(self.index_raw)
                if mutation == "source":
                    index["source_commit"] = "729b144a0c5885d702a6a49c655f61c62513ed30"
                if mutation in ("core", "cost", "support", "model"):
                    key = dict(core="implementation_hash", cost="cost_hash",
                               support="support_hash", model="model_version")[mutation]
                    index["model_identity"][key] = "invalid-source-value"
                if mutation in ("collector", "protocol"):
                    index[mutation + "_sha256"] = "f" * 64
                if mutation == "domain":
                    index["clock_domain"] = "other-domain"
                if mutation == "calibrated":
                    index["calibrated"] = True
                if mutation == "active":
                    index["mpc_active"] = True
                if mutation == "launch":
                    index["gpu_environment"]["native_launch"]["arguments"].append("--enable-prefix-caching")
                if mutation in ("split17", "split37"):
                    index["episodes"][0]["split"] = "calibration" if mutation == "split17" else "validation"
                if mutation == "missing-arm":
                    index["episodes"].pop()
                root = self.write_metadata(directory, index=index)
                with self.assertRaisesRegex(ValueError, "source144_"):
                    load_source144_replica(self.model, root)

    def test_all_events_manifest_missing_events_and_changed_bytes_refuse_before_parser(self):
        from pathlib import Path
        listed = [json.loads(line) for line in self.manifest_raw.splitlines()]
        for mutation in ("missing-event-entry", "changed-SHA", "outside-TRAIN", "missing-event-file", "changed-event-bytes"):
            with self.subTest(mutation=mutation), self.temporary_folder() as directory:
                rows = copy.deepcopy(listed)
                manifest = None
                if mutation == "missing-event-entry":
                    rows.pop(0)
                if mutation == "changed-SHA":
                    rows[0]["sha256"] = "f" * 64
                if mutation == "outside-TRAIN":
                    rows[0]["artifact"] = "../nv3-181017-p128-m128-arm0.json"
                if mutation in ("missing-event-entry", "changed-SHA", "outside-TRAIN"):
                    manifest = b"".join((json.dumps(r) + "\n").encode() for r in rows)
                root = self.write_metadata(directory, manifest=manifest)
                if mutation == "changed-event-bytes":
                    (Path(root) / listed[0]["artifact"]).write_bytes(b"CPU changed event bytes\n")
                with self.assertRaisesRegex(ValueError, "source144_"):
                    load_source144_replica(self.model, root)


class ControlledCohortTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import sys
        sys.path.insert(0, "/home/daniel_lin/gt/pr32/mayor/mpc-native-integration")

    def receipt(self):
        from dataclasses import asdict
        from mpc_lab.contracts import CostSpec, Identity, RequestMark, Snapshot
        from mpc_lab.runtime import snapshot_to_dict
        cost = CostSpec(tokenizer_identity="cpu-fixture-only")
        identity = Identity("fixture", "unqualified", "support", cost.fingerprint, "core")
        spec = controlled_cohort_spec()
        doc = dict(schema=spec["schema"], protocol_sha256=hashlib.sha256(json.dumps(
            spec, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest(),
            evidence_scope="cpu_fixture", collector_source_sha256=None,
            manifest_published_at=1., cost_spec=asdict(cost), cost_hash=cost.fingerprint,
            source_pins=dict(
                contracts="f39f6b73b41b1433a220f182679852df5c4332d9022ce903dba9863375236e23",
                native_state=OnlineModelInputAdapter.NATIVE_SOURCE_SHA256,
                runtime=OnlineModelInputAdapter.RUNTIME_SOURCE_SHA256,
                gateway=OnlineModelInputAdapter.GATEWAY_SOURCE_SHA256,
                capture=CaptureReceiptBridge.CAPTURE_SHA256), pairs=[])
        for pair_index in range(12):
            order = [16., 32.] if pair_index % 2 == 0 else [32., 16.]
            pair = dict(pair_id=f"pair-{pair_index}", sampling_unit=f"independent-fixture-{pair_index}",
                        order=order, episodes=[])
            for budget in order:
                key = f"{pair_index}-{budget}"
                run = f"gateway-{key}"
                anchors = [uid(f"anchor-{key}-{i}") for i in range(9)]
                bursts = [uid(f"burst-{key}-{i}") for i in range(4)]
                native_ids = [f"opaque-cpu-native-{key}-{i}" for i in range(9)]
                registrations = [
                    dict(schema="native-v3-controlled-public-payload-v1", request_id=rid,
                         group=group, prompt_tokens=p, max_tokens=m, ignore_eos=ignore,
                         published_at=8.)
                    for group, ids, p, m, ignore in (
                        ("anchor", anchors, 128, 256, True), ("burst", bursts, 4096, 128, False))
                    for rid in ids]
                a, b = cost.estimate(128, 256), cost.estimate(4096, 128)
                marks = tuple(RequestMark(rid, a, 128, 256, 9.1 + i * .02, 9.101 + i * .02)
                              for i, rid in enumerate(anchors))
                burst_marks = tuple(RequestMark(rid, b, 4096, 128, 10.1 + i * .003,
                                                10.101 + i * .003)
                                    for i, rid in enumerate(bursts))

                def frame(received, *, empty=False, step=0):
                    live = [] if empty else [
                        dict(request_id=rid, prompt_tokens=128, computed_tokens=148 + step,
                             output_tokens=20 + step * (4 if budget == 16 else 3),
                             maximum_output_tokens=256) for rid in native_ids]
                    held = () if empty else marks
                    if budget == 32 and step > 1:
                        held += burst_marks
                        live += [dict(request_id=f"opaque-burst-{key}-{i}", prompt_tokens=4096,
                                      computed_tokens=0, output_tokens=0, maximum_output_tokens=128)
                                 for i in range(4)]
                    snap = Snapshot(run, "clock", received - .003, 32. if not step else budget,
                                    int(bool(step)), held, identity)
                    return dict(schema="pr33-native-read-only-v1", clock_domain="clock",
                                run_id=f"native-{key}",
                                observer_sha256="29fc1ebd875ccc1a53b9584fd0f3b002c518e3653c9b4238877b67b7ec13802e",
                                vllm_version="0.30.0", gateway_snapshot=snapshot_to_dict(snap),
                                sampled_at=received - .002, frontend_sampled_at=received - .001,
                                received_at=received, gateway_received_at=received - .0025,
                                complete=True, running=len(live), waiting=0,
                                pending_batches=0 if empty else 1, frontend_unfinished=len(live),
                                kv_cache_usage=0. if empty else .1, requests=live)

                events, reserved = [], 0.
                def event(t, rid, kind, **fields):
                    events.append(dict(event_at=t, published_at=t + .0001,
                                       received_at=t + .0002, request_id=rid, kind=kind,
                                       clock_domain="clock", run_id=run,
                                       source_sha256=doc["source_pins"]["gateway"], **fields))
                for i, rid in enumerate(anchors):
                    t = 9.1 + i * .02
                    event(t, rid, "attempt")
                    event(t + .001, rid, "admitted", original_charge=a,
                          reserved_before=reserved, budget_in_force=32.)
                    reserved += a
                for i, rid in enumerate(bursts):
                    t = 10.1 + i * .003
                    event(t, rid, "attempt")
                    if budget == 32:
                        event(t + .001, rid, "admitted", original_charge=b,
                              reserved_before=reserved, budget_in_force=32.)
                        reserved += b
                    else:
                        event(t + .001, rid, "rejected")
                for i, rid in enumerate(anchors + (bursts if budget == 32 else [])):
                    event(11.2 + i * .01, rid, "complete")
                events.sort(key=lambda e: e["event_at"])
                for seq, item in enumerate(events, 1):
                    item["sequence"] = seq
                gate = frame(9.99)
                payload = dict(schema=gate["gateway_snapshot"]["schema"], run_id=run,
                               clock_domain="clock", identity=asdict(identity), expected_version=0,
                               not_after=10.11, operation_id=f"op-{key}", budget=budget)
                command = dict(sent_at=10.01, planned_at=10., payload=payload,
                               pending_before=False, source_sha256=doc["source_pins"]["gateway"],
                               ack_received_at=10.08, response=dict(
                                   status="applied", applied_at=10.06, budget_version=1,
                                   budget=budget, operation_id=payload["operation_id"],
                                   run_id=run, clock_domain="clock"))
                pair["episodes"].append(dict(
                    episode_id=f"episode-{key}", assigned_at=10., assigned_budget=budget,
                    clock_domain="clock", registrations=registrations, gateway_events=events,
                    gate=gate, drain=frame(9., empty=True), native_ids=native_ids,
                    native_ids_sealed_at=9.995, command=command,
                    native_frames=[frame(10. + step * .1, step=step) for step in range(1, 11)]))
            doc["pairs"].append(pair)
        return doc

    def audit(self, doc):
        raw = json.dumps(doc, sort_keys=True, separators=(",", ":")).encode()
        return audit_controlled_cohort(raw, hashlib.sha256(raw).hexdigest())

    def test_actual_cost_source_and_aggregate_identity_without_per_uuid_join(self):
        doc = self.receipt()
        sealed = copy.deepcopy(doc)
        result = self.audit(doc)
        self.assertEqual(doc, sealed)
        self.assertAlmostEqual(result["sourced_costs"]["anchor_charge"], 1.6893573248)
        self.assertAlmostEqual(result["sourced_costs"]["burst_charge"], 4.0304346624)
        self.assertAlmostEqual(result["sourced_costs"]["anchor_stock"], 15.2042159232)
        self.assertEqual(result["all_assigned_mean_interval"], [-10., -10.])
        self.assertEqual(result["censor_fraction"], 0)
        self.assertTrue(result["all_fates_complete"])
        self.assertTrue(result["margin_and_censor_met"])
        reordered = copy.deepcopy(doc)
        for pair in reordered["pairs"]:
            for arm in pair["episodes"]:
                arm["native_ids"].reverse()
        self.assertEqual(self.audit(reordered)["all_assigned_mean_interval"], [-10., -10.])
        for key in ("inference_qualified", "aggregate_cohort_provenance_qualified",
                    "per_gateway_native_join_verified", "natural_good", "active_mpc_permit"):
            self.assertFalse(result[key])
        doc["pairs"][0]["episodes"][0]["native_ids"][0] = "future-forged-id"
        with self.assertRaisesRegex(ValueError, "sealed"):
            self.audit(doc)

    def test_all_assigned_failure_widens_mean_no_ack_or_survivor_selection(self):
        doc = self.receipt()
        failed = doc["pairs"][0]["episodes"][1]
        failed.update(gate=None, drain=None, command=None, gateway_events=[], native_frames=[])
        result = self.audit(doc)
        self.assertEqual(len(result["pairs"]), 12)
        self.assertEqual(result["pairs"][0]["arms"][1]["actual_attempts"], 0)
        self.assertGreater(result["all_assigned_mean_interval"][1], 0)
        self.assertIsNone(result["conditional_exact_pair_signflip_p"])
        self.assertFalse(result["margin_and_censor_met"])
        self.assertFalse(result["all_fates_complete"])
        doc = self.receipt()
        command = doc["pairs"][0]["episodes"][1]["command"]
        command.update(response=None, ack_received_at=None)
        retained = self.audit(doc)
        self.assertEqual(retained["all_assigned_mean_interval"], [-10., -10.])
        self.assertTrue(retained["pairs"][0]["arms"][1]["pending"])
        doc = self.receipt()
        doc["pairs"][0]["episodes"][0]["command"]["ack_received_at"] = 10.3
        late_ack = self.audit(doc)
        self.assertEqual(late_ack["all_assigned_mean_interval"], [-10., -10.])
        self.assertAlmostEqual(late_ack["pairs"][0]["arms"][0]["ack_delay"], .29)

    def test_disappearance_reappearance_reset_and_future_terminal_cannot_fill(self):
        for mutation, expected in (
                (lambda frame: frame["requests"].pop(0), "disappeared"),
                (lambda frame: frame["requests"][0].update(output_tokens=0), "reset_or_overhang"),
                (lambda frame: frame.update(complete=False), "missing_or_source_gap")):
            doc = self.receipt()
            arm = doc["pairs"][0]["episodes"][0]
            mutation(arm["native_frames"][4])
            if expected == "disappeared":
                arm["native_frames"][4]["running"] -= 1
                arm["native_frames"][4]["frontend_unfinished"] -= 1
            result = self.audit(doc)
            original_id = arm["native_ids"][0]
            self.assertEqual(result["pairs"][0]["arms"][0]["statuses"][original_id], expected)
            self.assertGreater(result["censor_fraction"], 0)
            self.assertIsNone(result["conditional_exact_pair_signflip_p"])
            before = result["pairs"][0]["high_minus_low"]
            for event in arm["gateway_events"]:
                if event["kind"] == "complete":
                    event["finish_reason"] = "stop"
                    event["future_delivered_tokens"] = 256
            self.assertEqual(self.audit(doc)["pairs"][0]["high_minus_low"], before)
        doc = self.receipt()
        arm = doc["pairs"][0]["episodes"][0]
        arm["native_frames"][4]["requests"][0]["output_tokens"] = 0
        arm["native_frames"] = arm["native_frames"][:8]
        arm["native_frames"][-1]["requests"].pop(0)
        arm["native_frames"][-1]["running"] -= 1
        arm["native_frames"][-1]["frontend_unfinished"] -= 1
        result = self.audit(doc)
        self.assertAlmostEqual(result["pairs"][0]["arms"][0]["bounds"][0], 8 * 32 / 9)

    def test_source_clock_ttl_cas_cost_and_pseudoreplication_falsifiers(self):
        for mutate, match in (
                (lambda d: d["pairs"][1].update(sampling_unit=d["pairs"][0]["sampling_unit"]), "pseudoreplicated"),
                (lambda d: d["pairs"].pop(), "all-assigned"),
                (lambda d: d["pairs"][0]["episodes"][0]["command"]["payload"].update(not_after=10.21), "TTL"),
                (lambda d: d["pairs"][0]["episodes"][0]["command"].update(pending_before=True), "pending"),
                (lambda d: d["pairs"][0]["episodes"][0]["command"]["response"].update(budget_version=2), "ACK"),
                (lambda d: d["pairs"][0]["episodes"][0]["command"]["response"].update(clock_domain="foreign"), "ACK"),
                (lambda d: d["pairs"][0]["episodes"][0]["command"]["response"].update(applied_at=10.12), "ACK"),
                (lambda d: d["pairs"][0]["episodes"][0]["gateway_events"][1].update(original_charge=1.), "charge"),
                (lambda d: d["pairs"][0]["episodes"][0]["gateway_events"][0].update(sequence=2), "sequence")):
            doc = self.receipt()
            mutate(doc)
            with self.subTest(match=match):
                with self.assertRaisesRegex(ValueError, match):
                    self.audit(doc)
        doc = self.receipt()
        doc["pairs"][0]["episodes"][0]["native_frames"][3]["clock_domain"] = "foreign"
        self.assertGreater(self.audit(doc)["censor_fraction"], 0)

    def test_frozen_opus_step_start_stock_cannot_identify_within_step_order(self):
        import importlib.util
        from pathlib import Path
        from mpc_lab.contracts import CostSpec
        path = Path("/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/"
                    "pr33-native-v3-round11-frozen/opus/native_release_model.py")
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),
                         "aa927973f4cf6a6ba96a10c09bb77eb9fdef63dda80ad70b78c87b768dab12c7")
        source_spec = importlib.util.spec_from_file_location("frozen_opus_r11_sol_witness", path)
        m = importlib.util.module_from_spec(source_spec)
        source_spec.loader.exec_module(m)
        cost = CostSpec()
        a, b = cost.estimate(128, 256), cost.estimate(4096, 128)
        model = dict(cell="fixture", prompt_k={("fixture", 256): .128, ("fixture", 128): 4.096},
                     table={("fixture", 256, "D1", "ok"): [("GONE", "end", 0)] * 20,
                            ("entry", "fixture", 128, 1): [("GONE", "end", 0)] * 20})
        start = [("D1", "ok", 256)] * 9
        uniforms = [[.5] * m.ROLLOUT_STEPS for _ in range(10)]
        result = m.r11_simulate(start, [16.] * m.ROLLOUT_STEPS, [(.4, 128, 0.)],
                               uniforms, model, {("fixture", 256): a, ("fixture", 128): b},
                               aware=False)
        self.assertEqual(result["rejected_1"], 1)
        actual_early = (0 if .01 < .4 and b <= 16 else 1)
        actual_late = (1 if .49 > .4 and 9 * a + b > 16 else 0)
        self.assertEqual((actual_early, actual_late), (0, 1))
        self.assertEqual(m.r11_simulate(start, [16.] * m.ROLLOUT_STEPS, [(.4, 128, 0.)],
                                       uniforms, model, {("fixture", 256): a, ("fixture", 128): b},
                                       aware=False), result)

    def test_frozen_gemini_negative_gamma_and_no_data_fallback_are_not_causal_fit(self):
        import ast
        from pathlib import Path
        from types import SimpleNamespace
        path = Path("/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/"
                    "pr33-native-v3-round11-frozen/gemini/native_campaign_protocol.py")
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),
                         "ade3dfcea281f811ecfe989c8c03e1c48980b4e4ff2b4052cd62120493c290ca")
        tree = ast.parse(path.read_text())
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef)
                   and n.name == "BatchAwareHazardTransitionModel")
        method = next(n for n in cls.body if isinstance(n, ast.FunctionDef)
                      and n.name == "compute_service_rates")
        fit = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                   and n.name == "fit_batch_aware_hazard_model_on_train13")
        namespace = dict(Path=Path, FittedBatchAwareParameters=SimpleNamespace)
        code = "from __future__ import annotations\n" + ast.unparse(method) + "\n" + ast.unparse(fit)
        exec(compile(code, str(path), "exec"), namespace)
        parameters = namespace["fit_batch_aware_hazard_model_on_train13"](
            str(Path(__file__).parent))
        self.assertEqual(parameters.n_decode_samples, 121079)
        self.assertEqual(parameters.n_episodes_fitted, 30)
        small = SimpleNamespace(decode_count=9, prefill_count=0, kv_cache_usage=0.)
        large = SimpleNamespace(decode_count=18, prefill_count=0, kv_cache_usage=0.)
        rate = namespace["compute_service_rates"]
        self.assertGreater(rate(parameters, large)[0], rate(parameters, small)[0])
        # Both types slow under competition; survivor composition reverses the association.
        self.assertLess(50., 100.)
        self.assertLess(5., 10.)
        self.assertGreater(statistics.fmean([5., 50.]), statistics.fmean([10.]))


class BatchProgressTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import sys
        sys.path.insert(0, "/home/daniel_lin/gt/pr32/mayor/mpc-native-integration")

    def actor(self, name, cost=1., prefill=0):
        return dict(request_id=uid(name), original_gateway_charge=cost,
                    prefill_remaining=prefill, native_output_tokens=0, maximum_output_tokens=100)

    def state(self, actors):
        return dict(actors=actors, kv_cache_usage=0., waiting_work_unknown=False, unmapped_work=False)

    def test_fixed_crn_later_admission_changes_existing_and_earlier_birth_progress(self):
        a, b, c = self.actor("r11-a"), self.actor("r11-b"), self.actor("r11-c", 17., 100)
        state = self.state([a])
        offers = [dict(step=0, actor=b), dict(step=1, actor=c)]
        parameters = dict(prefill_rate=8., decode_rate=9.)
        results = {}
        for evolving in (False, True):
            for cap in (16., 32.):
                results[evolving, cap] = evolving_batch_progress(
                    state, offers, [cap] * 10, parameters, seed="fixed-r11", evolving=evolving)
        low, high = results[True, 16.]["path"], results[True, 32.]["path"]
        self.assertEqual(low[0]["actors"], high[0]["actors"])
        self.assertEqual(low[1]["rejected"], [c["request_id"]])
        self.assertEqual(high[1]["admitted"], [c["request_id"]])
        for actor in (a, b):
            rid = actor["request_id"]
            self.assertLess(high[-1]["actors"][rid]["native_output_tokens"],
                            low[-1]["actors"][rid]["native_output_tokens"])
            self.assertEqual(results[False, 16.]["path"][-1]["actors"][rid],
                             results[False, 32.]["path"][-1]["actors"][rid])
        self.assertEqual(evolving_batch_progress(
            state, offers, [32.] * 10, parameters, seed="fixed-r11"), results[True, 32.])
        self.assertEqual(state, self.state([a]))
        self.assertIsNone(results[True, 32.]["good_predictions"])
        self.assertFalse(results[True, 32.]["active_mpc_permit"])

    def test_cap_exclusion_non_eviction_and_phase_updates_are_simultaneous(self):
        a = self.actor("r11-owner", 17., 1)
        state = self.state([a])
        parameters = dict(prefill_rate=8., decode_rate=4.)
        low = evolving_batch_progress(state, [], [16.] * 10, parameters, seed="same")
        high = evolving_batch_progress(state, [], [32.] * 10, parameters, seed="same")
        self.assertEqual(low, high)
        self.assertEqual(low["path"][0]["actors"][a["request_id"]]["prefill_remaining"], 0)
        self.assertEqual(low["path"][0]["actors"][a["request_id"]]["native_output_tokens"], 0)
        self.assertGreater(low["path"][1]["actors"][a["request_id"]]["native_output_tokens"], 0)
        self.assertTrue(all(p["reserved"] == 17. for p in low["path"]))
        a, b = self.actor("r11-order-a"), self.actor("r11-order-b", prefill=3)
        first = evolving_batch_progress(self.state([a, b]), [], [32.] * 6, parameters, seed="order")
        second = evolving_batch_progress(self.state([b, a]), [], [32.] * 6, parameters, seed="order")
        self.assertEqual(first, second)

    def test_one_move_multistep_and_frozen_comparator_share_origin_mask_and_noise(self):
        a = self.actor("r11-plan-origin")
        state = self.state([a])
        offers = [dict(step=1, actor=self.actor("r11-first-offer", 17., 100)),
                  dict(step=3, actor=self.actor("r11-second-offer", 2., 100))]
        parameters = dict(prefill_rate=8., decode_rate=9.)
        one = [32.] * 10
        multi = [32., 32., 16., 16., 32., 32., 16., 16., 32., 32.]
        runs = {name: evolving_batch_progress(state, offers, plan, parameters, seed="same-mask",
                                               evolving=mode)
                for name, plan, mode in (("one", one, True), ("multi", multi, True),
                                        ("frozen", one, False))}
        rid = a["request_id"]
        for horizon in (1, 3, 5):
            step = 2 * horizon - 1
            self.assertTrue(all(rid in run["path"][step]["actors"] for run in runs.values()))
        self.assertEqual(runs["one"]["path"][0]["actors"], runs["multi"]["path"][0]["actors"])
        self.assertEqual(runs["multi"]["path"][3]["reserved"], 18.)
        self.assertEqual(runs["one"]["path"][3]["reserved"], 20.)
        self.assertGreater(runs["multi"]["path"][-1]["actors"][rid]["native_output_tokens"],
                           runs["one"]["path"][-1]["actors"][rid]["native_output_tokens"])

    def test_unknown_work_cost_future_labels_and_duplicate_ids_refuse(self):
        parameters = dict(prefill_rate=8., decode_rate=4.)
        actor = self.actor("r11-invalid")
        for state in (self.state([actor]) | dict(waiting_work_unknown=True),
                      self.state([actor]) | dict(unmapped_work=True),
                      self.state([actor | dict(original_gateway_charge=None)]),
                      self.state([actor | dict(terminal_at=10.)]),
                      self.state([actor, actor])):
            with self.subTest(state=list(state)):
                with self.assertRaises(ValueError):
                    evolving_batch_progress(state, [], [16.], parameters, seed="invalid")
        refusal = batch_progress_input_refusal(dict(schema=OnlineModelInputAdapter.SCHEMA))
        self.assertIsNone(refusal["state"])
        self.assertFalse(refusal["active_mpc_permit"])

    def fit_artifacts(self, *, unknown=False):
        from mpc_lab.contracts import CostSpec, Identity, Snapshot
        from mpc_lab.runtime import snapshot_to_dict
        identity = Identity("fixture", "unqualified", "support", CostSpec().fingerprint, "core")
        records = []
        for index, (computed, output) in enumerate(((80, 0), (90, 0), (100, 0), (101, 1), (102, 2))):
            t = 10. + index * .1
            snapshot = Snapshot("gateway", "clock", t - .001, 16., 0, (), identity)
            frame = dict(
                schema="pr33-native-read-only-v1", clock_domain="clock", run_id="native",
                observer_sha256="29fc1ebd875ccc1a53b9584fd0f3b002c518e3653c9b4238877b67b7ec13802e",
                vllm_version="0.30.0", gateway_snapshot=snapshot_to_dict(snapshot),
                sampled_at=t, frontend_sampled_at=t + .001, received_at=t + .002,
                gateway_received_at=t + .0005, complete=True,
                running=1, waiting=0, pending_batches=1 if unknown else 0,
                frontend_unfinished=1, kv_cache_usage=0.,
                requests=[dict(request_id="opaque-engine", prompt_tokens=100,
                               computed_tokens=computed, output_tokens=output, maximum_output_tokens=8)])
            records.append(dict(kind="native_frame", value=frame))
        raw = b"\n".join(json.dumps(r).encode() for r in records)
        digest = hashlib.sha256(raw).hexdigest()
        return {f"nv3-{b}-p4096-m128-arm0.events.jsonl": (raw, digest)
                for b in (181001, 181002, 181003)}

    def test_source_bound_phase_fit_uses_future_native_labels_not_future_inputs(self):
        fit = fit_batch_progress_artifacts(self.fit_artifacts())
        self.assertAlmostEqual(fit["parameters"]["prefill_rate"], 200.)
        self.assertAlmostEqual(fit["parameters"]["decode_rate"], 10.)
        self.assertEqual(fit["totals"]["prefill"]["observations"], 6)
        self.assertEqual(fit["totals"]["decode"]["observations"], 6)
        self.assertIsNone(fit["lifecycle_model"])
        self.assertFalse(fit["active_mpc_permit"])
        artifacts = self.fit_artifacts()
        name = next(iter(artifacts))
        artifacts[name] = (artifacts[name][0] + b"\n", artifacts[name][1])
        with self.assertRaisesRegex(ValueError, "bytes"):
            fit_batch_progress_artifacts(artifacts)
        artifacts = self.fit_artifacts()
        artifacts["nv3-181012-p4096-m128-arm0.events.jsonl"] = artifacts.pop(name)
        with self.assertRaisesRegex(ValueError, "already-used"):
            fit_batch_progress_artifacts(artifacts)

    def test_unknown_pending_work_withholds_fit_instead_of_filling_zero_rates(self):
        fit = fit_batch_progress_artifacts(self.fit_artifacts(unknown=True))
        self.assertIsNone(fit["parameters"]["prefill_rate"])
        self.assertIsNone(fit["parameters"]["decode_rate"])
        self.assertEqual(fit["totals"]["decode"]["exposure"], 0.)
        for count in fit["counts"].values():
            self.assertEqual(count["eligible_intervals"], 0)
            self.assertEqual(count["refusal_reasons"]["unknown_waiting_pending_frontend_work"], 4)

    def counter_artifacts(self, *, development=False, mutate=None):
        raw = next(iter(self.fit_artifacts(unknown=True).values()))[0]
        template = json.loads(raw.splitlines()[0])
        records = []
        for index in range(41):
            record = copy.deepcopy(template)
            frame = record["value"]
            t = 10. + index * .2
            frame.update(sampled_at=t, frontend_sampled_at=t + .001,
                         received_at=t + .002, gateway_received_at=t + .0005)
            frame["gateway_snapshot"]["sampled_at"] = t - .001
            frame["requests"][0].update(
                computed_tokens=80 + index * 10, output_tokens=min(30, max(0, index - 2)),
                maximum_output_tokens=30)
            if mutate is not None:
                mutate(index, frame)
            records.append(record)
        raw = b"\n".join(json.dumps(r).encode() for r in records)
        value = (raw, hashlib.sha256(raw).hexdigest())
        blocks = range(181004, 181010) if development else range(181001, 181004)
        return {f"nv3-{b}-p4096-m128-arm0.events.jsonl": value for b in blocks}

    def test_counter_target_retains_normal_pending_and_separate_empty_closed_fit(self):
        result = output_counter_stayer_diagnostic(
            self.counter_artifacts(), self.counter_artifacts(development=True))
        self.assertGreater(result["fit_labels"], 0)
        for stats in result["development"].values():
            for h, stat in stats.items():
                self.assertGreater(stat["comparable"], 0)
                self.assertLess(stat["availability"], 1)
                self.assertIn("right_censored", stat["statuses"])
                self.assertIn("past_rate_available", stat["strata"])
                witness = stat["forecast_witness"]
                self.assertLessEqual(witness["model_increment"], witness["headroom"])
                self.assertLessEqual(witness["past_increment"], witness["headroom"])
                self.assertTrue(witness["keys"][0][3])
        self.assertFalse(result["active_mpc_permit"])
        self.assertFalse(result["native_gateway_lineage_verified"])
        self.assertFalse(result["source_authenticated"])
        self.assertIsNone(fit_batch_progress_artifacts(
            self.fit_artifacts(unknown=True))["parameters"]["decode_rate"])

    def test_future_counter_phase_and_inventory_change_labels_not_cut_forecast(self):
        fit = self.counter_artifacts()
        original = output_counter_stayer_diagnostic(fit, self.counter_artifacts(development=True))

        def future(index, frame):
            if index >= 2:
                frame["requests"][0]["output_tokens"] = min(30, max(0, 2 * (index - 2)))
                frame["requests"][0]["computed_tokens"] = 90
                frame["requests"].append(frame["requests"][0] | dict(request_id="new-native-id"))
                frame["running"] = frame["frontend_unfinished"] = 2

        changed = output_counter_stayer_diagnostic(
            fit, self.counter_artifacts(development=True, mutate=future))
        self.assertEqual(original["fit_table_sha256"], changed["fit_table_sha256"])
        for name in original["development"]:
            for h in original["horizons"]:
                before, after = original["development"][name][h], changed["development"][name][h]
                self.assertEqual(before["forecast_witness"], after["forecast_witness"])
                self.assertNotEqual(before["model_mae_rate"], after["model_mae_rate"])
                self.assertGreater(after["birth_context"], 0)

    def test_interval_disappearance_reset_and_identity_change_are_not_filled(self):
        fit = self.counter_artifacts()
        for expected, mutation in (
                ("interval_disappearance_censored",
                 lambda frame: frame.update(requests=[], running=0, frontend_unfinished=0)),
                ("counter_regressed", lambda frame: frame["requests"][0].update(output_tokens=0)),
                ("identity_changed", lambda frame: frame["requests"][0].update(maximum_output_tokens=31)),
                ("observation_gap_censored", lambda frame: frame.update(complete=False))):
            def mutate(index, frame):
                if index == 10:
                    mutation(frame)
            with self.subTest(status=expected):
                result = output_counter_stayer_diagnostic(
                    fit, self.counter_artifacts(development=True, mutate=mutate))
                stat = next(iter(result["development"].values()))[3.]
                self.assertGreater(stat["statuses"].get(expected, 0), 0)

    def test_counter_bytes_scope_and_source_domain_refusal(self):
        fit, dev = self.counter_artifacts(), self.counter_artifacts(development=True)
        name = next(iter(dev))
        bad = dev | {name: (dev[name][0] + b"\n", dev[name][1])}
        with self.assertRaisesRegex(ValueError, "hash mismatch"):
            output_counter_stayer_diagnostic(fit, bad)
        bad = dict(dev)
        bad["nv3-181012-p4096-m128-arm0.events.jsonl"] = bad.pop(name)
        with self.assertRaisesRegex(ValueError, "scope"):
            output_counter_stayer_diagnostic(fit, bad)
        for field, value, reason in (
                ("observer_sha256", "f" * 64, "native_source_mismatch"),
                ("clock_domain", "wrong-domain", "clock_domain_mismatch")):
            def mutate(index, frame):
                if index == 10:
                    frame[field] = value
            result = output_counter_stayer_diagnostic(
                fit, self.counter_artifacts(development=True, mutate=mutate))
            self.assertEqual(result["parser_refusals"][name], {reason: 1})
            self.assertIsNone(result["development"][name][1.]["model_mae_rate"])


def configuration():
    return dict(model_revision="a" * 40, observer_mode="off",
                deployment_id="test-pod", boot_id="test-boot", gpu_uuid="test-gpu",
                driver_version="test-driver", vllm_version="test-vllm",
                torch_version="test-torch", transformers_version="test-transformers",
                dtype="test-dtype",
                **{key: hashlib.sha256(key.encode()).hexdigest()
                   for key in ("native_source_sha256", "gateway_source_sha256",
                               "core_sha256", "cost_model_sha256", "scheduler_config_sha256")})


def arm(seed=1, side="left", status="complete", output=2):
    rid = uid(f"{seed}-{side}")
    offer = dict(request_id=rid, logical_id="offer-0", offset_s=0,
                 prompt_tokens=128, max_tokens=4,
                 prompt_sha256=hashlib.sha256(f"prompt-{seed}".encode()).hexdigest())
    row = dict(request_id=rid, response_request_id=rid, clock_domain="client-epoch",
               requested_max_tokens=4,
               scheduled_at=10, sent_at=10.01, first_content_at=10.1,
               last_content_at=10.11, terminal_at=10.12, status=status,
               stream_done=True, stream_error=False, http_status=200,
               finish_reason="stop", native_eos_verified=True,
               usage=dict(prompt_tokens=128, completion_tokens=output))
    if status == "rejected":
        row.update(first_content_at=None, last_content_at=None, http_status=503,
                   admission_rejection=True, stream_done=False,
                   finish_reason=None, usage=None)
    if status == "censored":
        row.update(terminal_at=None, observed_until=10.2, stream_done=False,
                   finish_reason=None, usage=None, client_prefix_complete=True)
    return dict(offers=[offer], rows=[row], origin=10, window_s=1,
                clock_domain="client-epoch", configuration=configuration(),
                policy_sha256=hashlib.sha256(f"policy-{side}".encode()).hexdigest())


def blocks(n=4):
    return [dict(seed=i, block_id=f"block-{i}", randomization_unit=f"unit-{i}",
                 partition="development",
                 independent_sampling=True, pair_order_randomized=True,
                 pair_order="left-first" if i % 2 == 0 else "right-first",
                 randomization_scheme="independent-fair-pair-order",
                 frozen_comparison_sha256=comparison_digest(
                     configuration=configuration(), window_s=1,
                     left_policy_sha256=arm(side="left")["policy_sha256"],
                     right_policy_sha256=arm(side="right")["policy_sha256"]),
                 left=arm(i, "left", "rejected"),
                 right=arm(i, "right")) for i in range(n)]


def train_episode():
    """Synthetic schema witnesses, not native receipts or experiment measurements."""
    ids = [uid("train-a"), uid("train-b"), uid("train-c")]
    spec = dict(intercept=10.72, input_per_token=.01, output_per_token=0,
                minimum=.1, default_max_tokens=128,
                tokenizer_identity="test-tokenizer", estimator_version="test-estimator")
    identity = dict(model_version="test-model", calibration_version="unqualified",
                    support_hash="a" * 64, implementation_hash="b" * 64,
                    cost_hash=hashlib.sha256(json.dumps(
                        {"formula": "max-min-affine-v1", **spec}, sort_keys=True,
                        separators=(",", ":")).encode()).hexdigest())

    def frame(sampled, members):
        marks = [dict(request_id=rid, cost=12., prompt_tokens=128, max_tokens=128,
                      received_at=.1, admitted_at=.2, first_at=None, scheduled_at=None)
                 for rid in members]
        return dict(schema="pr33-native-read-only-v1", complete=True, available=True,
                    clock_domain="test-clock", run_id=uid("native-run"), observer_sha256="c" * 64,
                    gateway_received_at=sampled + .01, sampled_at=sampled + .02,
                    frontend_sampled_at=sampled + .03, received_at=sampled + .04,
                    gateway_snapshot=dict(schema="mpc-admission-v1", complete=True,
                        clock_domain="test-clock", run_id=uid("gateway-run"),
                        sampled_at=sampled, budget=16, budget_version=2, sequence=int(sampled * 10),
                        identity=copy.deepcopy(identity), cost_spec=copy.deepcopy(spec), requests=marks),
                    requests=[dict(request_id=f"chatcmpl-{members[0]}-1234abcd",
                                   prompt_tokens=128, output_tokens=2, computed_tokens=130,
                                   maximum_output_tokens=128)],
                    running=1, waiting=0, pending_batches=0, kv_cache_usage=.1)

    rows = []
    for i, rid in enumerate(ids[:2]):
        row = arm()["rows"][0]
        row.update(request_id=rid, response_request_id=rid, clock_domain="test-clock",
                   requested_max_tokens=128, scheduled_at=.1 + i * .1, sent_at=.3,
                   first_content_at=2.2, last_content_at=2.3, terminal_at=2.4)
        rows.append(row)
    return dict(episode_id="nv3-181001-test-arm0", seed_block=181001, split="train",
                start=0., duration_s=3., gateway_run_id=uid("gateway-run"),
                expected_ids=ids[:2], offered_tape=[.1, .2], rows=rows,
                native_frames=[frame(.8, ids[:2]), frame(2., [ids[1], ids[2]])],
                preassignment=[], actions=[], schedule=[])


def audit_train(case, **kwargs):
    raw = json.dumps(case, sort_keys=True, allow_nan=False).encode()
    return train_schema_audit(raw, expected_sha256=hashlib.sha256(raw).hexdigest(),
                              cut_at=kwargs.pop("cut_at", 1.), **kwargs)


def train_ack(case, *, received_at, applied_at, operation):
    return dict(received_at=received_at, reply=dict(status="applied",
        command=dict(identity=case["native_frames"][0]["gateway_snapshot"]["identity"],
                     run_id=uid("gateway-run"), clock_domain="test-clock",
                     operation_id=uid(operation), budget=32, expected_version=2,
                     not_after=received_at + .1),
        acknowledgment=dict(status="applied", applied_at=applied_at,
                            budget=32, budget_version=3, operation_id=uid(operation),
                            clock_domain="test-clock", run_id=uid("gateway-run"))))


class TrainSchemaTests(unittest.TestCase):
    def test_bytes_and_train_partition_are_required_without_source_authority(self):
        case = train_episode()
        raw = json.dumps(case).encode()
        with self.assertRaisesRegex(ValueError, "digest mismatch"):
            train_schema_audit(raw, expected_sha256="0" * 64, cut_at=1.)
        for split, seed in (("final", 181001), ("train", 160021), ("train", 181017)):
            bad = copy.deepcopy(case)
            bad.update(split=split, seed_block=seed)
            with self.subTest(split=split, seed=seed), self.assertRaisesRegex(ValueError, "Only Train"):
                audit_train(bad)
        self.assertFalse(any(audit_train(case)["authority"].values()))

    def test_future_client_labels_native_samples_and_unreceived_ack_cannot_enter_features(self):
        case = train_episode()
        original = audit_train(case)
        changed = copy.deepcopy(case)
        changed["rows"][0]["first_content_at"] = .4
        changed["native_frames"][1]["requests"][0]["output_tokens"] = 17
        changed["actions"] = [dict(at_s=.9, attempts=[
            train_ack(changed, received_at=1.1, applied_at=.95, operation="action")])]
        result = audit_train(changed)
        self.assertEqual(original["observations"], result["observations"])
        self.assertNotEqual(original["offline_labels"]["offline_client_first_by_cut"],
                            result["offline_labels"]["offline_client_first_by_cut"])
        self.assertIsNone(result["observations"]["admitted_marks"][0]["first_at"])

    def test_receipt_not_event_time_and_received_ack_fence_define_available_prefix(self):
        case = train_episode()
        original = audit_train(case)["observations"]
        late = case["native_frames"][1]
        late.update(gateway_received_at=.91, sampled_at=.92,
                    frontend_sampled_at=.93, received_at=1.01)
        late["gateway_snapshot"]["sampled_at"] = .9
        late["gateway_snapshot"]["sequence"] = 9
        self.assertEqual(audit_train(case)["observations"], original)
        case["preassignment"] = [train_ack(case, received_at=.96, applied_at=.95, operation="ack")]
        self.assertTrue(audit_train(case)["observations"]["received_ack_conflicts_with_snapshot"])
        case["preassignment"][0]["reply"]["command"]["expected_version"] = 1
        with self.assertRaisesRegex(ValueError, "CAS"):
            audit_train(case)
        with self.assertRaisesRegex(ValueError, "stale"):
            audit_train(train_episode(), cut_at=1.4)

    def test_full_offered_past_is_offline_not_admitted_rate_or_physical_eos(self):
        case = train_episode()
        case["rows"][1].update(status="rejected", finish_reason=None)
        case["expected_ids"].append(uid("rejected-extra"))
        case["offered_tape"].append(.3)
        extra = copy.deepcopy(case["rows"][1])
        extra.update(request_id=uid("rejected-extra"), scheduled_at=.3)
        case["rows"].append(extra)
        case["rows"][0]["native_eos_verified"] = True
        result = audit_train(case)
        self.assertEqual(result["observations"]["admitted_snapshot_count"], 2)
        self.assertEqual(result["offline_labels"]["offline_planned_offers_by_cut"], 3)
        self.assertIsNone(result["observations"]["all_offered_client_history"])
        self.assertIsNone(result["offline_labels"]["independent_physical_eos_receipts"])
        self.assertFalse(result["authority"]["native_comparison_accepted"])
        case["rows"].pop()
        missing = audit_train(case)
        self.assertIn("Missing full-offered", missing["offline_labels"]["client_labels_withheld"])
        self.assertEqual(missing["observations"], result["observations"])

    def test_original_whole_cost_cohort_not_net_stock_and_cap_drop_never_evicts(self):
        result = audit_train(train_episode())
        self.assertEqual(result["observations"]["applied_cap"], 16)
        self.assertEqual(result["observations"]["reserved_cost"], 24)
        self.assertEqual(result["offline_labels"]["released_cost_bounds"], [12., 12.])
        bounds = result["offline_labels"]["cohort_disappearance"]
        self.assertEqual([b["released_count_bounds"] for b in bounds], [[1, 1], [0, 0]])
        self.assertTrue(result["observations"]["accepted_not_native_visible"])
        self.assertFalse(result["authority"]["same_state_causal_effect_qualified"])

    def test_disappearance_is_interval_censored_not_interpolated_release_or_eos(self):
        case = train_episode()
        frame = case["native_frames"][1]
        frame["gateway_snapshot"]["sampled_at"] = 2.1
        frame.update(gateway_received_at=2.11, sampled_at=2.12,
                     frontend_sampled_at=2.13, received_at=2.14)
        labels = audit_train(case)["offline_labels"]
        self.assertEqual(labels["released_cost_bounds"], [0., 12.])
        self.assertEqual(labels["cohort_disappearance"][0]["released_count_bounds"], [0, 1])

    def test_exact_id_cost_and_future_label_errors_fail_without_rewriting_features(self):
        case = train_episode()
        for field, value in (("clock_domain", "foreign"), ("running", True)):
            bad = copy.deepcopy(case)
            bad["native_frames"][0][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                audit_train(bad)
        bad = copy.deepcopy(case)
        bad["native_frames"][0]["requests"][0]["request_id"] += "-extra"
        with self.assertRaisesRegex(ValueError, "UUID"):
            audit_train(bad)
        changed = copy.deepcopy(case)
        mark = changed["native_frames"][1]["gateway_snapshot"]["requests"][0]
        mark.update(prompt_tokens=228, cost=13.)
        result = audit_train(changed)
        self.assertIn("changed original", result["offline_labels"]["disappearance_withheld"])
        self.assertEqual(result["observations"], audit_train(case)["observations"])


class MarkedDynamicsCounterexampleTests(unittest.TestCase):
    def episode(self):
        case = train_episode()
        rid = case["expected_ids"][0]
        case.update(expected_ids=[rid], offered_tape=[.1], rows=case["rows"][:1])
        case["rows"][0].update(sent_at=.11, first_content_at=.2,
                               last_content_at=1.19, terminal_at=1.2,
                               usage=dict(prompt_tokens=128, completion_tokens=24))
        case["rows"][0].pop("native_eos_verified")
        for frame in case["native_frames"]:
            snapshot = frame["gateway_snapshot"]
            if frame["received_at"] < 1.:
                snapshot["requests"] = snapshot["requests"][:1]
                snapshot["requests"][0].update(received_at=.12, admitted_at=.13)
            else:
                snapshot["requests"] = []
                frame.update(requests=[], running=0, kv_cache_usage=0.)
        return case

    def partition(self, case):
        raw = json.dumps(case, sort_keys=True, allow_nan=False).encode()
        return future_api_good_partition(
            raw, expected_sha256=hashlib.sha256(raw).hexdigest(), cut_at=1.)

    def test_perfect_incumbent_labels_do_not_remove_exogenous_birth_error(self):
        baseline = self.episode()
        births = copy.deepcopy(baseline)
        rid = uid("future-exogenous-offer")
        row = copy.deepcopy(births["rows"][0])
        row.update(request_id=rid, response_request_id=rid, scheduled_at=1.4,
                   sent_at=1.41, first_content_at=1.5, last_content_at=1.51,
                   terminal_at=1.52, usage=dict(prompt_tokens=128, completion_tokens=2))
        births["rows"].append(row)
        births["expected_ids"].append(rid)
        births["offered_tape"].append(1.4)
        old, new = self.partition(baseline), self.partition(births)
        self.assertEqual(old["observations"], new["observations"])
        self.assertEqual(new["observations"]["raw_native_progress"][0]["computed_tokens"], 130)
        for horizon in (1, 3, 5):
            a, b = old["future_api_good"][horizon], new["future_api_good"][horizon]
            self.assertEqual(a["cohort_native_visible"], b["cohort_native_visible"])
            self.assertEqual(a["total"], 1)
            self.assertEqual(b["total"], 2)
            self.assertEqual(b["total"] - a["total"], b["post_cut_offered_birth"])
        self.assertIsNone(new["physical_natural_good"])
        self.assertFalse(new["active_mpc_permit"])

    def test_same_arrivals_and_progress_do_not_identify_eos_or_terminal_slo(self):
        natural = self.episode()
        truncated = copy.deepcopy(natural)
        row = truncated["rows"][0]
        row.update(finish_reason="length", last_content_at=5.49, terminal_at=5.5,
                   usage=dict(prompt_tokens=128, completion_tokens=128))
        frame = truncated["native_frames"][1]
        frame.update(gateway_received_at=6.01, sampled_at=6.02,
                     frontend_sampled_at=6.03, received_at=6.04)
        frame["gateway_snapshot"].update(sampled_at=6., sequence=60)
        a, b = self.partition(natural), self.partition(truncated)
        self.assertEqual(natural["offered_tape"], truncated["offered_tape"])
        self.assertEqual(a["observations"], b["observations"])
        self.assertEqual(a["future_api_good"][5]["total"], 1)
        self.assertEqual(b["future_api_good"][5]["total"], 0)
        late = copy.deepcopy(natural)
        late["rows"][0].update(last_content_at=2.49, terminal_at=2.5)
        self.assertEqual(self.partition(late)["future_api_good"][5]["total"], 0)
        spoof = copy.deepcopy(natural)
        spoof["rows"][0]["native_eos_verified"] = True
        self.assertIsNone(self.partition(spoof)["physical_natural_good"])

    def test_unseen_past_and_marked_invisible_cohorts_are_not_post_cut_births_or_zero(self):
        case = self.episode()
        frame = case["native_frames"][0]
        frame.update(requests=[], running=0, kv_cache_usage=0.)
        rid = uid("past-unseen-offer")
        row = copy.deepcopy(case["rows"][0])
        row.update(request_id=rid, response_request_id=rid)
        case["rows"].append(row)
        case["expected_ids"].append(rid)
        case["offered_tape"].append(.1)
        result = self.partition(case)
        self.assertEqual(result["observations"]["accepted_not_native_visible"],
                         [case["expected_ids"][0]])
        counts = result["future_api_good"][1]
        self.assertEqual(counts["cohort_native_unknown"], 1)
        self.assertEqual(counts["past_offer_outside_snapshot"], 1)
        self.assertEqual(counts["post_cut_offered_birth"], 0)
        self.assertEqual(counts["total"], 2)

    def test_bad_future_labels_withhold_points_without_rewriting_progress_or_history(self):
        baseline = self.episode()
        expected = self.partition(baseline)["observations"]
        for field, value in (("usage", dict(prompt_tokens=128, completion_tokens=0)),
                             ("usage", dict(prompt_tokens=128, completion_tokens=True)),
                             ("terminal_at", .15), ("status", "censored"),
                             ("clock_domain", "foreign")):
            case = copy.deepcopy(baseline)
            case["rows"][0][field] = value
            with self.subTest(field=field, value=value):
                result = self.partition(case)
                self.assertEqual(result["observations"], expected)
                self.assertIsNone(result["future_api_good"])
                self.assertIn("labels_withheld", result)
        case = copy.deepcopy(baseline)
        case["rows"].clear()
        self.assertIsNone(self.partition(case)["future_api_good"])

    def test_equal_receipt_times_preserve_the_same_latest_frame_as_the_train_audit(self):
        case = self.episode()
        first = case["native_frames"][0]
        first["received_at"] = .99
        later = copy.deepcopy(first)
        later.update(gateway_received_at=.91, sampled_at=.92, frontend_sampled_at=.93)
        later["gateway_snapshot"].update(sampled_at=.9, sequence=9)
        later["requests"][0].update(computed_tokens=132, output_tokens=4)
        case["native_frames"].insert(1, later)
        result = self.partition(case)["observations"]
        self.assertEqual(result["native_visible"][0]["output_tokens"], 4)
        self.assertEqual(result["raw_native_progress"][0]["output_tokens"], 4)


class CapPlanIdentificationTests(unittest.TestCase):
    """Hypothetical admission-mediated laws, never native EOS/performance receipts."""

    def plans(self):
        return tuple(itertools.product((16, 32), repeat=5))

    def response(self, plan, *, congested=False):
        # One old charge persists; five cost-one offers arrive, one per slot.
        owners = {"old": 16}
        rejected = []
        for slot, cap in enumerate(plan):
            rid = f"future-{slot}"
            if sum(owners.values()) + 1 <= cap:
                owners[rid] = 1
            else:
                rejected.append(rid)
        admitted = tuple(rid for rid in owners if rid != "old")
        # Two batch laws coincide up to four births. Only the unseen five-birth
        # batch stalls past 5s in the second law. Neither law receives the cap.
        completions = () if congested and len(admitted) == 5 else admitted
        released_cost = sum(owners[rid] for rid in completions)
        for rid in completions:
            del owners[rid]
        self.assertEqual(16 + len(admitted) - released_cost, sum(owners.values()))
        self.assertEqual(6, len(completions) + len(rejected) + len(owners))
        return dict(good=(0, 0, len(completions)), reserved=sum(owners.values()),
                    admitted=admitted, rejected=tuple(rejected), unresolved=tuple(owners))

    def test_randomized_marginals_do_not_identify_unsupported_full_plans_or_batches(self):
        plans = self.plans()
        law = {p: 1 for p in plans if p.count(32) % 2 == 0}
        for slot in range(5):
            self.assertEqual(sum(w for p, w in law.items() if p[slot] == 32), 8)
        audit = cap_plan_support_audit(law, plans)
        self.assertEqual([audit["horizons"][h]["supported_prefixes"] for h in (1, 3, 5)],
                         [2, 8, 16])
        for horizon in (1, 3):
            masses = {}
            for row in audit["horizons"][horizon]["candidates"]:
                prefix = row["prefix"]
                mass = row["declared_prefix_probability"]
                self.assertEqual(masses.setdefault(prefix, mass), mass)
        for p in law:
            self.assertEqual(self.response(p), self.response(p, congested=True))
        all_high = (32,) * 5
        self.assertEqual(self.response(all_high)["good"][2], 5)
        self.assertEqual(self.response(all_high, congested=True)["good"][2], 0)
        row = next(r for r in audit["horizons"][5]["candidates"] if r["plan"] == all_high)
        self.assertFalse(row["declared_prefix_supported"])
        self.assertEqual(row["declared_prefix_probability"], [0, 1])
        self.assertFalse(audit["active_mpc_permit"])

    def test_positive_plan_support_and_random_policy_coverage_do_not_authorize_selection(self):
        plans = self.plans()
        audit = cap_plan_support_audit(dict.fromkeys(plans, 1), plans)
        self.assertTrue(all(r["declared_prefix_supported"]
                            for r in audit["horizons"][5]["candidates"]))
        predictions = {p: self.response(p)["good"][2] for p in plans}
        truths = {p: self.response(p, congested=True)["good"][2] for p in plans}
        covered = sum(predictions[p] == truths[p] for p in plans)
        self.assertEqual(covered, 31)
        selected = max(plans, key=predictions.get)
        self.assertEqual(selected, (32,) * 5)
        self.assertNotEqual(predictions[selected], truths[selected])
        self.assertFalse(audit["selected_policy_coverage_verified"])
        self.assertFalse(audit["conditional_history_support_verified"])

    def test_declared_weights_are_not_empirical_counts_and_invalid_designs_are_refused(self):
        low, high = (16,) * 5, (32,) * 5
        audit = cap_plan_support_audit({low: 3, high: 1}, (low, high))
        self.assertEqual(audit["horizons"][5]["candidates"][1]
                         ["declared_prefix_probability"], [1, 4])
        for law in ({}, {low: 0}, {low: True}, {low: -1}, {low: 1.5},
                    {(16,) * 4: 1}, {(16, 16, 16, 16, 24): 1}):
            with self.subTest(law=law), self.assertRaises(ValueError):
                cap_plan_support_audit(law, (low, high))
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            cap_plan_support_audit({low: 1}, (low, low))


class OutcomeTests(unittest.TestCase):
    def test_natural_truncated_censored_and_failures_keep_full_offered_denominator(self):
        case = arm()
        natural = audit_arm(**case)
        self.assertEqual((natural["good_lower"], natural["good_upper"]), (1, 1))
        case["rows"][0].update(finish_reason="length")
        case["rows"][0]["usage"]["completion_tokens"] = 4
        truncated = audit_arm(**case)
        self.assertEqual(truncated["outcomes"][0]["label"], "truncated")
        self.assertEqual(truncated["good_upper"], 0)
        censored = audit_arm(**arm(status="censored"))
        self.assertEqual((censored["good_lower"], censored["good_upper"]), (0, 1))
        for status in ("rejected", "failed", "cancelled", "timeout"):
            result = audit_arm(**arm(status=status))
            self.assertEqual(result["offered"], 1)
            self.assertEqual(result["good_upper"], 0)
        cohort = arm()
        cohort["offers"], cohort["rows"] = [], []
        for i, status in enumerate(("complete", "rejected", "failed", "cancelled",
                                    "timeout", "censored")):
            item = arm(i, status=status)
            item["offers"][0]["logical_id"] = f"offer-{i}"
            cohort["offers"].extend(item["offers"])
            cohort["rows"].extend(item["rows"])
        result = audit_arm(**cohort)
        self.assertEqual((result["offered"], result["good_lower"], result["good_upper"]),
                         (6, 1, 2))

    def test_zero_bool_float_and_missing_successful_output_are_invalid(self):
        for output in (0, True, 1.5, None):
            with self.subTest(output=output), self.assertRaises(ValueError):
                audit_arm(**arm(output=output))
        self.assertEqual(audit_arm(**arm(output=1))["outcomes"][0]["request_mean_tpot_s"], 0)

    def test_all_timestamps_are_finite_and_ordered_even_single_token(self):
        mutations = [("scheduled_at", float("nan")), ("sent_at", True),
                     ("first_content_at", float("inf")), ("last_content_at", 9),
                     ("terminal_at", 10.05)]
        for field, value in mutations:
            case = arm(output=1)
            case["rows"][0][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                audit_arm(**case)
        with self.assertRaises(ValueError):
            audit_arm(**{**arm(), "origin": float("nan")})

    def test_slo_uses_scheduled_origin_and_terminal_not_last_chunk(self):
        case = arm()
        case["rows"][0]["terminal_at"] = 10.3
        self.assertEqual(audit_arm(**case)["good_lower"], 0)
        case = arm()
        case["rows"][0].update(sent_at=10.6, first_content_at=10.7,
                               last_content_at=10.71, terminal_at=10.72)
        self.assertEqual(audit_arm(**case)["good_lower"], 0)

    def test_missing_extra_duplicate_clock_identity_and_unverified_eos_fail_closed(self):
        for kind in ("missing", "extra", "duplicate", "clock", "identity", "eos",
                     "stream", "limit"):
            case = arm()
            if kind == "missing":
                case["rows"] = []
            elif kind == "extra":
                case["rows"][0]["request_id"] = uid("not-offered")
            elif kind == "duplicate":
                case["rows"] *= 2
            else:
                field, value = {"clock": ("clock_domain", "worker-epoch"),
                                "identity": ("response_request_id", uid("other")),
                                "eos": ("native_eos_verified", False),
                                "limit": ("requested_max_tokens", 8),
                                "stream": ("stream_done", False)}[kind]
                case["rows"][0][field] = value
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                audit_arm(**case)

    def test_censored_late_first_cannot_become_good_and_invalid_cutoff_fails(self):
        case = arm(status="censored")
        case["rows"][0].update(first_content_at=10.6, last_content_at=10.6,
                               observed_until=10.7)
        self.assertEqual(audit_arm(**case)["good_upper"], 0)
        case["rows"][0]["observed_until"] = 10.5
        with self.assertRaises(ValueError):
            audit_arm(**case)

    def test_no_first_after_deadline_tightens_only_complete_client_prefix(self):
        case = arm(status="censored")
        case["rows"][0].update(first_content_at=None, last_content_at=None,
                               observed_until=11)
        result = audit_arm(**case)
        self.assertEqual((result["good_lower"], result["good_upper"]), (0, 0))
        self.assertEqual(result["outcomes"][0]["label"], "censored")
        case["rows"][0]["client_prefix_complete"] = False
        self.assertEqual(audit_arm(**case)["good_upper"], 1)
        case["rows"][0].update(client_prefix_complete=True, observed_until=10.5)
        self.assertEqual(audit_arm(**case)["good_upper"], 1)

    def test_semantic_tape_excludes_labels_but_preserves_tied_offer_order(self):
        case = arm()
        renamed = copy.deepcopy(case)
        renamed["offers"][0].update(request_id=uid("new-id"), logical_id="new-label",
                                   offset_s=0.0)
        renamed["rows"][0].update(request_id=uid("new-id"), response_request_id=uid("new-id"))
        original, relabeled = audit_arm(**case), audit_arm(**renamed)
        self.assertEqual(original["semantic_tape_sha256"], relabeled["semantic_tape_sha256"])
        self.assertNotEqual(original["tape_sha256"], relabeled["tape_sha256"])
        second = arm(2)
        second["offers"][0]["logical_id"] = "offer-1"
        case["offers"].extend(second["offers"])
        case["rows"].extend(second["rows"])
        reversed_case = copy.deepcopy(case)
        reversed_case["offers"].reverse()
        self.assertNotEqual(audit_arm(**case)["semantic_tape_sha256"],
                            audit_arm(**reversed_case)["semantic_tape_sha256"])

    def test_configuration_requires_actual_fields_not_an_opaque_hash(self):
        for change in ({}, {"configuration_sha256": "a" * 64},
                       {**configuration(), "model_revision": True},
                       {**configuration(), "torch_version": None},
                       {**configuration(), "runtime_extra": float("nan")}):
            case = arm()
            case["configuration"] = change
            with self.subTest(configuration=change), self.assertRaises(ValueError):
                audit_arm(**case)


class BlockTests(unittest.TestCase):
    def test_four_blocks_have_exact_two_sided_floor_not_request_level_significance(self):
        result = paired_effect(blocks(), bootstrap_samples=200)
        self.assertEqual(result["effect_good_per_s"], 1)
        self.assertEqual(result["exact_two_sided_signflip_p"], .125)
        self.assertEqual(result["percentile_bootstrap_ci95"], [1, 1])
        self.assertFalse(result["native_performance_accepted"])
        self.assertFalse(result["independent_sampling_verified"])

    def test_nonsignificance_has_no_equivalence_or_superiority_label(self):
        cases = blocks()
        for i in (0, 1):
            cases[i]["left"], cases[i]["right"] = arm(i, "left"), arm(i, "right", "rejected")
        result = paired_effect(cases, bootstrap_samples=200)
        self.assertEqual(result["effect_good_per_s"], 0)
        self.assertEqual(result["exact_two_sided_signflip_p"], 1)
        self.assertLess(result["percentile_bootstrap_ci95"][0], 0)
        self.assertGreater(result["percentile_bootstrap_ci95"][1], 0)
        self.assertNotIn("equivalent", result)
        self.assertNotIn("superior", result)

    def test_cloned_block_is_rejected_even_after_cosmetic_relabeling(self):
        for kind in ("clone", "seed", "unit", "tape", "physical", "declaration"):
            cases = blocks()
            if kind == "clone":
                cases[1] = copy.deepcopy(cases[0])
            elif kind == "seed":
                cases[1]["seed"] = cases[0]["seed"]
            elif kind == "unit":
                cases[1]["randomization_unit"] = cases[0]["randomization_unit"]
            elif kind == "tape":
                for side in ("left", "right"):
                    cases[1][side]["offers"][0]["prompt_sha256"] = (
                        cases[0][side]["offers"][0]["prompt_sha256"])
            elif kind == "physical":
                for field in ("offers", "rows"):
                    cases[1]["right"][field] = copy.deepcopy(cases[1]["left"][field])
            else:
                cases[1]["independent_sampling"] = False
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                paired_effect(cases, bootstrap_samples=20)

    def test_pair_requires_identical_tape_window_and_slo(self):
        for field in ("window_s", "ttft_s", "prompt_sha256"):
            cases = blocks()
            if field == "prompt_sha256":
                cases[0]["right"]["offers"][0][field] = "a" * 64
            else:
                cases[0]["right"][field] = 2
            with self.subTest(field=field), self.assertRaises(ValueError):
                paired_effect(cases, bootstrap_samples=20)

    def test_unrandomized_or_changed_policy_design_cannot_get_permutation_p(self):
        for field, value in (("pair_order_randomized", False),
                             ("pair_order", "unknown"),
                             ("randomization_scheme", "balanced-permuted-order"),
                             ("frozen_comparison_sha256", "a" * 64)):
            cases = blocks()
            cases[1][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                paired_effect(cases, bootstrap_samples=20)

    def test_unresolved_outcomes_withhold_ci_and_permutation_not_impute_success(self):
        cases = blocks()
        cases[0]["right"] = arm(0, "right", "censored")
        result = paired_effect(cases)
        self.assertEqual(result["effect_bounds_good_per_s"], [.75, 1])
        self.assertIsNone(result["effect_good_per_s"])
        self.assertIsNone(result["exact_two_sided_signflip_p"])
        self.assertIsNone(result["percentile_bootstrap_ci95"])

    def test_exact_permutation_is_scale_invariant_not_absolute_epsilon_dependent(self):
        for duration in (1, 10 ** 15):
            cases = blocks()
            for case in cases:
                for side in ("left", "right"):
                    case[side]["window_s"] = duration
                case["frozen_comparison_sha256"] = comparison_digest(
                    configuration=configuration(), window_s=duration,
                    left_policy_sha256=case["left"]["policy_sha256"],
                    right_policy_sha256=case["right"]["policy_sha256"])
            self.assertEqual(paired_effect(cases, bootstrap_samples=20)
                             ["exact_two_sided_signflip_p"], .125)

    def test_partitions_and_old_final_seed_cannot_leak_into_block_analysis(self):
        for mutation in ("mixed", "missing", "heldout"):
            cases = blocks()
            if mutation == "mixed":
                cases[1]["partition"] = "train"
            elif mutation == "missing":
                cases[1].pop("partition")
            else:
                cases[1]["seed"] = 160022
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                paired_effect(cases)

    def test_bootstrap_interpolation_remains_finite_at_opposite_large_effects(self):
        cases = blocks(2)
        cases[1]["left"], cases[1]["right"] = arm(1, "left"), arm(1, "right", "rejected")
        for case in cases:
            for side in ("left", "right"):
                item = case[side]
                item.update(origin=0, window_s=1e-308)
                for name in ("scheduled_at", "sent_at", "first_content_at",
                             "last_content_at", "terminal_at"):
                    if item["rows"][0][name] is not None:
                        item["rows"][0][name] = 0
            case["frozen_comparison_sha256"] = comparison_digest(
                configuration=configuration(), window_s=1e-308,
                left_policy_sha256=case["left"]["policy_sha256"],
                right_policy_sha256=case["right"]["policy_sha256"])
        result = paired_effect(cases, bootstrap_samples=2, random_seed=0)
        import math
        self.assertTrue(all(math.isfinite(v) for v in result["percentile_bootstrap_ci95"]))

    def test_actual_global_slo_config_window_and_policy_cannot_hide_behind_same_hash(self):
        for field in ("ttft_s", "tpot_s", "window_s", "configuration",
                      "runtime_version", "policy_sha256"):
            cases = blocks()
            if field == "configuration":
                for side in ("left", "right"):
                    cases[1][side][field]["native_source_sha256"] = "b" * 64
            elif field == "runtime_version":
                for side in ("left", "right"):
                    cases[1][side]["configuration"]["torch_version"] = "changed-runtime"
            elif field == "policy_sha256":
                cases[1]["right"][field] = "b" * 64
            else:
                for side in ("left", "right"):
                    cases[1][side][field] = (
                        .01 if field == "tpot_s" else .05 if field == "ttft_s" else 2)
            with self.subTest(field=field), self.assertRaisesRegex(ValueError, "frozen comparison"):
                paired_effect(cases)
        cases = blocks()
        for case in cases:
            case["frozen_comparison_sha256"] = "a" * 64
        with self.assertRaisesRegex(ValueError, "frozen comparison"):
            paired_effect(cases)

    def test_new_hash_per_block_does_not_legalize_changing_actual_comparison(self):
        cases = blocks()
        for side in ("left", "right"):
            cases[1][side]["ttft_s"] = .05
        cases[1]["frozen_comparison_sha256"] = comparison_digest(
            configuration=configuration(), window_s=1, ttft_s=.05,
            left_policy_sha256=cases[1]["left"]["policy_sha256"],
            right_policy_sha256=cases[1]["right"]["policy_sha256"])
        with self.assertRaisesRegex(ValueError, "configuration changed"):
            paired_effect(cases)

    def test_semantic_duplicate_tapes_rejected_after_all_identity_labels_change(self):
        cases = []
        for i in range(6):
            case = copy.deepcopy(blocks(2)[0])
            case.update(seed=i, block_id=f"block-{i}", randomization_unit=f"unit-{i}")
            for side in ("left", "right"):
                rid = uid(f"relabeled-{i}-{side}")
                case[side]["offers"][0].update(request_id=rid, logical_id=f"label-{i}")
                case[side]["rows"][0].update(request_id=rid, response_request_id=rid)
            cases.append(case)
        with self.assertRaisesRegex(ValueError, "Repeated offered tape"):
            paired_effect(cases)

    def test_censor_known_bad_never_becomes_success_or_inferential_completion(self):
        cases = blocks()
        cases[0]["right"] = arm(0, "right", "censored")
        cases[0]["right"]["rows"][0].update(first_content_at=None, last_content_at=None,
                                            observed_until=11)
        result = paired_effect(cases)
        self.assertEqual(result["effect_bounds_good_per_s"], [.75, .75])
        self.assertIsNone(result["effect_good_per_s"])
        self.assertIsNone(result["exact_two_sided_signflip_p"])


def physical_steps(prompt=4096, output=32):
    lengths = [2048, prompt - 2048] + [1] * (output - 1)
    position, steps = 0, []
    for i, count in enumerate(lengths):
        steps.append(dict(step_id=f"step-{i}", position=position, tokens=count,
                          executed_position=position, executed_tokens=count,
                          cuda_forward_matched=True, clock_domain="native-host",
                          host_forward_start=1 + i * .01,
                          output_commit_at=1.1 + i * .01))
        position += count
    steps.append(dict(step_id="tail", position=position, tokens=1,
                      executed_position=position, executed_tokens=1,
                      cuda_forward_matched=True, clock_domain="native-host",
                      host_forward_start=1.9, output_commit_at=2.1,
                      pre_finish_placeholder=1, delivered_output_from_step=False))
    return dict(prompt_tokens=prompt, output_tokens=output, steps=steps,
                eos_at=2, clock_domain="native-host")


class WorkTests(unittest.TestCase):
    def test_physical_tail_is_reported_without_turning_old_equality_true(self):
        result = work_accounting(**physical_steps())
        self.assertEqual(result["useful_input_minimum"], 4127)
        self.assertEqual(result["physical_input_tokens"], 4128)
        self.assertEqual(result["undelivered_tail_input_tokens"], 1)
        self.assertFalse(result["old_final_progress_equal"])
        self.assertFalse(result["native_qualification_accepted"])
        case = physical_steps()
        case["steps"].pop()
        self.assertTrue(work_accounting(**case)["old_final_progress_equal"])

    def test_tail_needs_full_join_and_not_placeholder_or_elapsed_time_alone(self):
        for field, value in (("pre_finish_placeholder", 0),
                             ("pre_finish_placeholder", True),
                             ("cuda_forward_matched", False),
                             ("executed_tokens", 2),
                             ("delivered_output_from_step", True),
                             ("host_forward_start", 2.01),
                             ("output_commit_at", 1.99),
                             ("clock_domain", "gpu-relative")):
            case = physical_steps()
            case["steps"][-1][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                work_accounting(**case)

    def test_gaps_duplicate_steps_missing_work_and_more_excess_are_not_relaxed(self):
        for kind in ("gap", "duplicate", "missing", "extra"):
            case = physical_steps()
            if kind == "gap":
                case["steps"][2]["position"] += 1
            elif kind == "duplicate":
                case["steps"][-1]["step_id"] = "step-0"
            elif kind == "missing":
                case["steps"] = case["steps"][:2]
            else:
                case["steps"][-1].update(tokens=2, executed_tokens=2)
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                work_accounting(**case)

    def test_useful_forward_cannot_start_after_eos_or_regress_in_host_order(self):
        for index, start in ((0, 3), (2, 0)):
            case = physical_steps()
            case["steps"][index].update(host_forward_start=start, output_commit_at=4)
            with self.subTest(index=index), self.assertRaises(ValueError):
                work_accounting(**case)


def peer_counterexamples(frozen_root):
    """Replay pinned peer defects read-only; run separately from portable unit tests."""
    import importlib.util
    import sys
    from dataclasses import replace
    from pathlib import Path

    root = Path(frozen_root)
    receipts = {}

    def load(name, relative, expected=None):
        path = root / relative
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if expected is not None and digest != expected:
            raise ValueError(f"Frozen peer source changed: {relative}")
        receipts[relative] = digest
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        return module

    base = "experiments/mpc-research/native-v3/"
    opus = load("native_release_model", "opus/" + base + "native_release_model.py",
                "86f45ab851a446b4a903c8e5f0991acb198ecc4fc5d9d0d9bd0d05e38e77411b")
    ot = load("nv3_opus_r1_tests", "opus/" + base + "test_native_release_model.py",
              "1f38d3cb88d9c89d9acf2296b94278f02ed4f73a7e3e98caf5f7f045f902bed3")
    astra = load("native_response_planner", "astra/" + base + "native_response_planner.py",
                 "e19db180e1fb06c6c34ff21e9b76131e85749edc7f403d4aa65acf366b7a3326")
    at = load("nv3_astra_r1_tests", "astra/" + base + "test_native_response_planner.py",
              "862bc1db7a9baba167f8cf0baa7997c93201cfb7fdce47152e4a6dadaf8e3f08")
    gemini = load("native_campaign_protocol", "gemini/native_campaign_protocol.py",
                  "087c68868f48f6bac9d1ac829c9dc3cb8b749f1c40b87f6d5364bb2d2f4bad79")
    load("nv3_gemini_r1_tests", "gemini/test_native_campaign_protocol.py",
         "a94770f63e58e68e2046b98876831e609d98a6e595ec204402465620f5864d42")
    findings = {}

    ep = ot.episode([(1, 1., 128, 128, 0., .1, .6)])
    foreign = copy.deepcopy(ep)
    for obs in foreign["observations"]:
        obs["native"].update(clock_domain="foreign-clock", run_id="foreign-run")
    findings["opus_foreign_native_identity_accepted"] = bool(opus.build_origins(foreign)[0])
    assert findings["opus_foreign_native_identity_accepted"]
    bad_time = copy.deepcopy(ep)
    bad_time["ledger"][-1]["effective_at"] = -100
    findings["opus_release_before_live_origin_accepted"] = opus.build_dataset([bad_time])[0]["truth"][1.]
    assert findings["opus_release_before_live_origin_accepted"] == (1., 1.)
    plans = ([(0, 16), (.5, 32), (1, 16)], [(0, 32), (.5, 16), (1, 16)])
    averages = [{h: opus._planned_budget({"cap_plan": p}, 0, h, 16)
                 for h in opus.HORIZONS} for p in plans]
    findings["opus_order_distinct_plans_same_all_horizon_features"] = averages
    assert averages[0] == averages[1]
    train_origins = []
    for prompt in (128, 4096):
        train_origins.extend(opus.build_origins(ot.episode([
            (1, 1., prompt, 128, 0., .1, 1.),
            (2, 1., prompt, 128, 0., .1, 1.)]))[0])
    mixed = opus.build_origins(ot.episode([
        (1, 1., 128, 128, 0., .1, 1.),
        (2, 1., 4096, 128, 0., .1, 1.)]))[0][0]
    findings["opus_unseen_mixture_passes_marginal_ood_envelope"] = opus.ood_reasons(
        mixed, opus.support_envelope(train_origins))
    assert findings["opus_unseen_mixture_passes_marginal_ood_envelope"] == []
    findings["opus_tail_accounted_without_cuda_placeholder_commit_clock"] = (
        ot._baseline_4096_32()["tail_accounted"])
    assert findings["opus_tail_accounted_without_cuda_placeholder_commit_clock"]
    previous_predict = opus.predict
    try:
        opus.predict = lambda params, origin: (
            {"batch_aware": {h: .5 for h in opus.HORIZONS}}, [])
        calibration = [dict(partition="calibration", seed_block=i, reserved=1,
                            truth={h: (value, value) for h in opus.HORIZONS})
                       for i, value in ((1, 0), (2, 1))]
        a = opus.calibrate({}, calibration)["bands"][1.]["lower"]
        b = opus.calibrate({}, calibration[:1] + calibration[1:] * 20)["bands"][1.]["lower"]
        findings["opus_same_two_blocks_origin_resampling_changes_band"] = [a, b]
        assert (a, b) == (-.5, .5)
    finally:
        opus.predict = previous_predict

    contradiction = replace(at.state(), native_running=0)
    decision = astra.plan_response(
        contradiction, at.evaluation(), at.StubModel(), expected_identity=at.IDENTITY,
        timing=astra.Timing("test-clock", 10.1, .02, .5, .05), clock=lambda: 10.)
    findings["astra_decode_mark_with_zero_native_running"] = dict(
        status=decision.status, active_permit=decision.active_permit)
    assert decision.status == "shadow" and decision.active_permit is False

    template = gemini.RequestOutcome("r", 128, 2, 10., 10.01, 10.1, 10.12,
                                     10., "stop", True)
    bool_good = gemini.validate_request_outcome(replace(template, output_tokens=True))["is_good"]
    post_good = gemini.validate_request_outcome(replace(template, client_post_at=100.))["is_good"]
    findings["gemini_boolean_output_and_post_after_terminal_good"] = [bool_good, post_good]
    assert bool_good and post_good
    accounting = gemini.compute_work_accounting()
    findings["gemini_exclusive_end_off_by_one"] = accounting.physical_executed_positions
    assert accounting.physical_executed_positions == 4129
    missing = gemini.compute_work_accounting(worker_forward_end_position=100)
    findings["gemini_missing_useful_work_tail_clipped_to_zero"] = missing.tail_work_tokens
    assert missing.tail_work_tokens == 0
    findings["gemini_concurrency_alone_serial_falsification"] = gemini.verify_gpu_elapsed_clock_semantics(
        .2, .1, 2)["serial_service_model_falsified"]
    assert findings["gemini_concurrency_alone_serial_falsification"]
    ledger = gemini.ObservableBatchState()
    record = gemini.MarkedReservationRecord("duplicate", 8., 10., 128, 128)
    assert ledger.admit(record) and ledger.admit(record)
    ledger.release("duplicate", 11.)
    findings["gemini_duplicate_admission_orphan_reservation"] = [
        ledger.reserved_cost, len(ledger.active_reservations)]
    assert findings["gemini_duplicate_admission_orphan_reservation"] == [8., 0]

    aggregate = [gemini.IndependentSeedBlockOutcome(
        f"block-{i}", 180000 + i, "short_homogeneous", "development", 10.,
        10, 1, 10, 0, 0, good, 0, 0) for i, good in enumerate((22, 24, 21, 25))]
    inference = gemini.SuperiorityEvaluator(min_blocks=4).evaluate(aggregate, num_permutations=1)
    findings["gemini_four_impossible_aggregates_one_draw"] = {
        k: inference[k] for k in ("verdict", "two_sided_permutation_p_value")}
    assert inference["verdict"] == "CONFIRMED_SUPERIOR"
    assert inference["two_sided_permutation_p_value"] == 0
    protocol = gemini.build_native_campaign_protocol(offers_duration_s=0, max_drain_duration_s=120)
    findings["gemini_zero_offers_planned_max_drain_satisfies_hours"] = dict(
        summary=protocol["duration_summary"],
        all_schedules_empty=all(not e["actuator_schedule"] for e in protocol["episodes"]))
    assert protocol["duration_summary"]["hours_requirement_satisfied"]
    assert findings["gemini_zero_offers_planned_max_drain_satisfies_hours"]["all_schedules_empty"]
    state = gemini.ObservableBatchState()
    findings["gemini_horizon_and_continuation_parameters_unused"] = [
        gemini.RecedingHorizonMPCController(horizon_steps=h).decide(state, 5) for h in (1, 5)]
    assert findings["gemini_horizon_and_continuation_parameters_unused"] == [32., 32.]
    return dict(scope="Pinned CPU counterexamples; not native performance or safety evidence",
                source_sha256=receipts, counterexamples=findings)


def round3_counterexamples(frozen_root):
    """Replay R2 bytes, including substantive old-Sol failures, without native data."""
    import importlib.util
    import math
    import sys
    from dataclasses import replace
    from pathlib import Path

    root = Path(frozen_root)
    base = "experiments/mpc-research/native-v3/"
    expected = {
        "sol/" + base + "native_experiment_audit.py":
            "44423a5d76782da9d9118ddacbdb94e82d6963b70a65dfdf95d4e82d5487251d",
        "sol/" + base + "test_native_experiment_audit.py":
            "336d298fdc766618e126ce19c952ee1ccb3057f061041a575d07d6e53aeb6bf6",
        "opus/" + base + "native_release_model.py":
            "6e277d09c2ccfded2bb11e31164f97515c4bbdcc838f3df3f5a917864b297270",
        "opus/" + base + "test_native_release_model.py":
            "fd120e927353d4eec18c88b48711d68168a9bf3aa034138206b2b789b4ca1379",
        "astra/" + base + "native_response_planner.py":
            "61fed73aa44057dbfd15b4f337e67caffa29695d9aa80052b20f94e0e3e00b23",
        "astra/" + base + "test_native_response_planner.py":
            "abaedf4af5b6d428437cd0c27727a9b890ad178445f9212746f3888f34a44b07",
        "gemini/" + base + "native_campaign_protocol.py":
            "de51b0af0fd1d02db3c960162a82693df3620751944373c2e697b913c55ca38e",
        "gemini/" + base + "test_native_campaign_protocol.py":
            "f36f174d9f0f2db328dac7b3c4e18f30767f06d8bff9c264c1143599b14a0e03",
    }
    for relative, digest in expected.items():
        if hashlib.sha256((root / relative).read_bytes()).hexdigest() != digest:
            raise ValueError(f"Frozen R2 bytes changed: {relative}")

    def load(name, relative):
        spec = importlib.util.spec_from_file_location(name, root / relative)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        return module

    sol = load("nv3_sol_r2", "sol/" + base + "native_experiment_audit.py")
    opus = load("native_release_model", "opus/" + base + "native_release_model.py")
    ot = load("nv3_opus_r2_tests", "opus/" + base + "test_native_release_model.py")
    astra = load("native_response_planner", "astra/" + base + "native_response_planner.py")
    at = load("nv3_astra_r2_tests", "astra/" + base + "test_native_response_planner.py")
    gemini = load("nv3_gemini_r2", "gemini/" + base + "native_campaign_protocol.py")
    findings = {}

    def legacy(cases):
        for case in cases:
            for side in ("left", "right"):
                case[side].pop("configuration")
                case[side].pop("policy_sha256")
        return cases

    cases = legacy(blocks(2))
    for side in ("left", "right"):
        cases[1][side]["ttft_s"] = .05
    effects = sol.paired_effect(cases, bootstrap_samples=20)["block_effects_good_per_s"]
    findings["sol_r2_changed_global_ttft_with_same_hash"] = effects
    assert effects == [1., 0.]
    cases = []
    for i in range(6):
        case = copy.deepcopy(blocks(2)[0])
        case.update(seed=i, block_id=f"block-{i}", randomization_unit=f"unit-{i}")
        for side in ("left", "right"):
            rid = uid(f"relabeled-{i}-{side}")
            case[side]["offers"][0].update(request_id=rid, logical_id=f"label-{i}")
            case[side]["rows"][0].update(request_id=rid, response_request_id=rid)
        cases.append(case)
    p = sol.paired_effect(legacy(cases), bootstrap_samples=20)["exact_two_sided_signflip_p"]
    findings["sol_r2_six_relabeled_identical_semantic_tapes_p"] = p
    assert p == .03125
    case = arm(status="censored")
    case.pop("configuration")
    case.pop("policy_sha256")
    case["rows"][0].update(first_content_at=None, last_content_at=None, observed_until=11)
    upper = sol.audit_arm(**case)["good_upper"]
    findings["sol_r2_complete_no_first_beyond_ttft_upper"] = upper
    assert upper == 1

    ep = ot.episode([(1, 1., 128, 128, 0., .1, .6)])
    foreign = copy.deepcopy(ep)
    for obs in foreign["observations"]:
        obs["native"].update(clock_domain="foreign-clock", run_id="foreign-run")
    findings["opus_r2_foreign_native_identity_accepted"] = bool(opus.build_origins(foreign)[0])
    assert findings["opus_r2_foreign_native_identity_accepted"]
    bad_time = copy.deepcopy(ep)
    bad_time["ledger"][-1]["effective_at"] = -100
    truth = opus.build_dataset([bad_time])[0]["truth"][1.]
    findings["opus_r2_retroactive_release_truth"] = truth
    assert truth == (1., 1.)
    averages = [{h: opus._planned_budget({"cap_plan": plan}, 0, h, 16)
                 for h in opus.HORIZONS}
                for plan in ([(0, 16), (.5, 32), (1, 16)],
                             [(0, 32), (.5, 16), (1, 16)])]
    findings["opus_r2_order_distinct_plans_same_features"] = averages
    assert averages[0] == averages[1]
    decision = astra.plan_response(
        replace(at.state(), native_running=0), at.evaluation(), at.StubModel(),
        expected_identity=at.IDENTITY, timing=astra.Timing("test-clock", 10.1, .02, .5, .05),
        clock=lambda: 10.)
    findings["astra_r2_decode_mark_zero_running"] = dict(
        status=decision.status, active_permit=decision.active_permit)
    assert decision.status == "shadow" and decision.active_permit is False

    tail = gemini.audit_native_qualification_tail_distribution([])
    findings["gemini_r2_empty_records_stochastic_tail_claim"] = tail
    assert tail["tail_is_stochastic"] is True
    epochs = gemini.plan_gateway_epochs([
        dict(episode_id=str(i), offers_duration_s=120) for i in range(4)])
    findings["gemini_r2_default_first_epoch_episode_count"] = len(epochs[0].episode_ids)
    assert len(epochs[0].episode_ids) == 4
    qualified, reason = gemini.ExperimentDurationAccounting(
        400, 120, 48000, float("nan"), 0, 0, 0).validate_actual_10h_milestone()
    findings["gemini_r2_nan_actual_duration_qualified"] = dict(qualified=qualified, reason=reason)
    assert qualified is True and "nan" in reason
    p = gemini.robust_paired_permutation_test([1e-15] * 4)["p_value"]
    findings["gemini_r2_four_scaled_positive_effects_p"] = p
    assert p == 1.

    try:
        paired_effect(blocks(32), bootstrap_samples=20)
    except ValueError as exc:
        assert "bounded exact enumeration" in str(exc)
        findings["sol_retained_32_block_exact_protocol_refusal"] = str(exc)
    else:
        raise AssertionError("Exact inference was silently replaced beyond its declared bound")

    case = arm()
    case.update(origin=1700000000.123)
    case["offers"][0]["offset_s"] = .1
    scheduled = case["origin"] + .1
    case["rows"][0].update(scheduled_at=scheduled, sent_at=scheduled + .01,
                           first_content_at=scheduled + .1, last_content_at=scheduled + .11,
                           terminal_at=scheduled + .12)
    assert audit_arm(**case)["good_lower"] == 1
    case["rows"][0]["scheduled_at"] = 1700000000.223
    try:
        audit_arm(**case)
    except ValueError as exc:
        assert "Row origin differs" in str(exc)
    else:
        raise AssertionError("Exact source-origin contract unexpectedly relaxed")
    difference = case["rows"][0]["scheduled_at"] - scheduled
    assert math.isfinite(difference) and difference > 0
    findings["sol_retained_independently_rounded_origin_refusal_delta_s"] = difference
    return dict(scope="Pinned R2 CPU witnesses; no native inference or consensus",
                source_sha256=expected, counterexamples=findings)


def round7_peer_counterexamples(frozen_root):
    """Pinned R6 source witnesses only; no native data, fitting or intervention."""
    import importlib.util
    import sys
    from dataclasses import replace
    from pathlib import Path

    root = Path(frozen_root)
    manifest = json.loads((root / "manifest.json").read_text())
    expected = {
        "opus": ("native_release_model.py",
                 "53acdff61b71bd974c83054653ea78ad1797d430602653048e1af9604dafe3bc"),
        "astra": ("native_response_planner.py",
                  "deff252986a704ed461e5ee16cbea9abbe76f07ac6ec0132afc9b02b6a7a4d7b"),
        "gemini": ("native_campaign_protocol.py",
                   "7a1a18fd96cb7b53f527d83044f5b1dd9f458c2705e532bd7773f1eebf45ee87"),
        "sol": ("native_experiment_audit.py",
                "79226047437dcf35f9d6bfcc54382ec6c05c7d31866313d1b4f012c3143746d6"),
    }
    for model, (filename, digest) in expected.items():
        assert hashlib.sha256((root / model / filename).read_bytes()).hexdigest() == digest
        for relative, declared in manifest[model]["files"].items():
            assert hashlib.sha256((root / model / Path(relative).name).read_bytes()).hexdigest() == declared

    def load(model):
        path = root / model / expected[model][0]
        name = "nv3_r7_frozen_" + model
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        return module

    opus, astra, gemini = (load(model) for model in ("opus", "astra", "gemini"))
    findings = {}
    rid = uid("r7-source-witness")
    step = dict(t0=1., cell="fixture", joined={rid: 2},
                cohort={rid}, native=dict(running=1, waiting=0))
    row = dict(scheduled=.1, first=.2, terminal=None,
               first_published_at=1.1, first_received_at=1.2)
    assert opus.id_progress_state(step, rid, row)[0][2] is True
    unseen = dict(row, first=None, client_prefix_complete=False)
    assert opus.id_progress_state(step, rid, unseen) == "ttft_impossible"
    findings["opus_final_row_first_is_not_publication_cut_and_incomplete_prefix_zero"] = True
    other = uid("past-offer-outside-snapshot")
    _, cohort, birth = opus._horizon_good(step, [1.2], [(1.2, other)], 1.)
    assert (cohort, birth) == (0, 1)
    findings["opus_snapshot_complement_is_not_verified_post_cut_offered_birth"] = True
    client = dict(
        request_id=rid, response_request_id=other, clock_domain="fixture",
        scheduled_at=.1, sent_at=.11, first_content_at=.2, terminal_at=.25,
        status="complete", finish_reason="stop", usage=dict(completion_tokens=2),
        stream_done=False, stream_error=True, http_status=500)
    events, _ = opus._client_events(dict(
        clock_domain="fixture", expected_ids=[rid], client_rows=[client]))
    assert len(events["good"]) == 1
    findings["opus_api_labels_do_not_verify_wire_or_independent_physical_eos"] = True

    model = gemini.StructuralBatchProgressHybridModel()
    decoder = gemini.DecodeRequestState(rid, 128, 31, 32, 1., 0., 0., .1)
    state = gemini.StructuralBatchProgressState(1., 16., 1., (), (decoder,))
    _, obs = model.step(state, 16., (), natural_eos_probability=0.)
    assert obs["good"] == 1
    findings["gemini_output_limit_scores_good_without_natural_eos"] = True
    empty = gemini.StructuralBatchProgressState(0., 16., 0., (), ())
    after, _ = model.step(empty, 16., [dict(
        request_id=rid, original_cost=1., prompt_tokens=128,
        maximum_output_tokens=32, scheduled_at=0.)])
    assert after.decode_cohort[0].maximum_output_tokens == 128
    findings["gemini_offer_output_limit32_promotes_to128"] = True
    hidden = gemini.StructuralBatchProgressState(
        0., 16., 2., (), (), accepted_not_native_visible_cost=2.)
    after, _ = model.step(hidden, 16., ())
    assert after.active_reserved_cost == 2. and after.accepted_not_native_visible_cost == 1.6
    findings["gemini_unseen_mass_decays_without_owner_transition"] = True
    fallback = gemini.run_structural_progress_vs_scalar_diagnostic()
    assert fallback["birth_dominance_confirmed"]
    findings["gemini_missing_data_returns_embedded_native_diagnostic_constants"] = True

    request = astra.BatchProgress(rid, 8, 1, 7, 0, 0, None)
    length, = astra.advance_joint_forward((request,), ((rid, 1, 0, 0),))
    natural, = astra.advance_joint_forward(
        (replace(request, eos_at=1),), ((rid, 1, 0, 0),))
    assert (length.finish_reason, natural.finish_reason) == ("length", "stop")
    findings["astra_restricted_helper_preserves_length_vs_latent_eos"] = True
    return dict(scope="Hypothetical/source-contract R6 witnesses, not native results",
                source_sha256={model: digest for model, (_, digest) in expected.items()},
                verified_manifest_files=12, counterexamples=findings)


if __name__ == "__main__":
    unittest.main()
