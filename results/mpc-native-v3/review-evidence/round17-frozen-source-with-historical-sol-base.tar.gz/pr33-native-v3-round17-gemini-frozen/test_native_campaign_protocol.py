"""Unit and regression tests for native_campaign_protocol.

Validates ground-truth accounting, R3 rejection guards, observable state,
and >=10h campaign protocol generation.
"""

import asyncio
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
import unittest
import uuid

# Ensure module can be imported whether tests are run from native-v3 dir or repo root
sys.path.insert(0, str(Path(__file__).parent.resolve()))

from native_campaign_protocol import (
    WORKLOAD_FAMILIES,
    ActionableAcceptanceCriteria,
    ActuationComplianceAnalyzer,
    BenchmarkEpisodeResult,
    CausalActionPathwayValidator,
    CausalGatedPlanResponseModel,
    ClosedLoopBenchmarkHarness,
    ControllerDecision,
    DecodeRequestState,
    DeliveredTokensAuditResult,
    ExperimentDurationAccounting,
    FINAL_WORKLOAD_CLASSES,
    Fixed16Controller,
    GatewayEpoch,
    HeuristicBacklogController,
    HeuristicThresholdController,
    IndependentSeedBlockOutcome,
    MarkedReservationRecord,
    MeasuredIntervalReceipt,
    MultiHorizonPlan,
    ObservableBatchState,
    OnlineCutObservationAdapter,
    PolicyBestTrainSelectedFixed,
    PolicyFixed16,
    PolicyOneMove,
    PolicyReactive,
    PolicyRecedingHorizonMPC,
    PrefillRequestState,
    PreregisteredFinalProtocol,
    PublishedHistoryView,
    RecedingHorizonMPCController,
    RequestOutcome,
    StreamedRequest,
    StrongOneMoveController,
    StructuralBatchProgressHybridModel,
    StructuralBatchProgressState,
    SuperiorityEvaluator,
    UnconstrainedDirectPlanModel,
    WorkAccounting,
    audit_native_qualification_tail_distribution,
    audit_train_block_diagnostics,
    build_native_campaign_protocol,
    build_preregistered_final_protocol,
    calculate_benchmark_outcomes,
    canonical_digest,
    canonical_join_observations,
    compute_normalized_absolute_error,
    compute_work_accounting,
    demonstrate_astra_selection_defect,
    demonstrate_sol_block_ceiling_and_float_defect,
    ensure_integration_paths,
    generate_workload_tape,
    holm_bonferroni_step_down,
    is_finite_real,
    plan_gateway_epochs,
    robust_paired_permutation_test,
    run_direct_plan_vs_causal_hybrid_discriminator,
    run_legacy_delivered_tokens_audit,
    run_real_pipeline_episode,
    run_simulate_plan_causal_interference_witness,
    run_structural_progress_vs_scalar_diagnostic,
    RealPipelineControlHarness,
    RealPipelineServingTransport,
    is_foreign_abi_site_packages,
    validate_request_outcome,
    verify_gpu_elapsed_clock_semantics,
    MinimalObservableBatchState,
    BatchAwareRequestState,
    BatchAwareHazardTransitionModel,
    BatchAwareWitnessResult,
    run_batch_aware_causal_interference_witness,
    run_used_train_progress_diagnostic,
    PreregisteredTrain1213Protocol,
    Train1213IdentificationForecastPilotProtocol,
    ClosedLoopBenchmarkHarnessProtocolDraft,
    FittedBatchAwareParameters,
    fit_batch_aware_hazard_model_on_train13,
    ERRATUM_R11_COMMIT_7C3B209,
    ControlledCohortIdentificationProtocol,
    ControlledCohortIdentificationResult,
    SufficientLivedGeometrySpecification,
    create_legacy_9x256_protocol,
    create_sufficient_lived_5x512_protocol,
    run_controlled_cohort_identification_harness,
    RealNativeCohortRunnerReceipt,
    RealNativeCohortPairedReceipt,
    RealNativeCohortTransport,
    RealNativeCohortRunner,
    run_real_native_cohort_pipeline,
    get_sourced_cost_spec,
    SOURCE_144_ACTUAL_FACTS,
    LiveNativeCohortRunnerReceipt,
    LiveNativeCohortPairedReceipt,
    LiveNativeServingTransport,
    LiveNativeCohortRunner,
    run_live_native_cohort_pipeline,
)

import httpx


class TestGroundTruthAccounting(unittest.TestCase):
    """Test verification of the ground-truth baseline fact and work accounting."""

    def test_legacy_strict_audit_remains_false(self):
        """The strict v2 audit must evaluate to FALSE and not be silently relaxed."""
        audit = run_legacy_delivered_tokens_audit(
            prompt_tokens=4096,
            delivered_tokens=32,
            worker_forward_end_position=4128,
            total_forward_steps=34,
            prefill_steps=2,
            decode_steps=32,
        )
        self.assertIsInstance(audit, DeliveredTokensAuditResult)
        self.assertFalse(audit.strict_v2_match, "Strict audit must be False per ground truth")
        self.assertEqual(audit.delivered_token_minimum_position, 4127)
        self.assertEqual(audit.worker_forward_end_position, 4128)
        self.assertIn("Strict audit FALSE", audit.reason)

    def test_explicit_work_accounting(self):
        """Useful, physical, and tail work must be explicitly decomposed without masking."""
        acct = compute_work_accounting(
            prompt_tokens=4096,
            delivered_tokens=32,
            worker_forward_end_position=4128,
            total_forward_steps=34,
            prefill_steps=2,
            decode_steps=32,
        )
        self.assertIsInstance(acct, WorkAccounting)
        self.assertEqual(acct.useful_prompt_tokens, 4096)
        self.assertEqual(acct.useful_output_tokens, 32)
        self.assertEqual(acct.useful_prompt_tokens + acct.useful_output_tokens, 4128)
        self.assertEqual(acct.useful_token_minimum_position, 4127)
        self.assertEqual(acct.physical_executed_positions, 4128)
        self.assertEqual(acct.tail_work_tokens, 1)
        self.assertEqual(acct.missing_work_tokens, 0)
        self.assertEqual(acct.tail_work_steps, 1)
        self.assertTrue(acct.accounted)
        self.assertIn("pre-finish scheduler placeholder 1", acct.tail_work_cause)
        self.assertAlmostEqual(acct.tail_work_tokens / acct.useful_output_tokens, 1.0 / 32.0)

        # Missing work case (physical < useful minimum)
        acct_miss = compute_work_accounting(
            prompt_tokens=4096,
            delivered_tokens=32,
            worker_forward_end_position=4100,
            total_forward_steps=30,
            prefill_steps=2,
            decode_steps=28,
        )
        self.assertEqual(acct_miss.missing_work_tokens, 27)
        self.assertEqual(acct_miss.tail_work_tokens, -27)
        self.assertFalse(acct_miss.accounted)

        # Unexplained tail case (tail > 1)
        acct_excess = compute_work_accounting(
            prompt_tokens=4096,
            delivered_tokens=32,
            worker_forward_end_position=4200,
            total_forward_steps=40,
            prefill_steps=2,
            decode_steps=38,
        )
        self.assertEqual(acct_excess.tail_work_tokens, 73)
        self.assertFalse(acct_excess.accounted)

    def test_gpu_elapsed_and_serial_falsification(self):
        """GPU elapsed is not an exclusive single-tenant service duration."""
        res = verify_gpu_elapsed_clock_semantics(
            http_residence_s=1.2,
            gpu_kernel_forward_elapsed_s=0.4,
            active_concurrent_requests=8,
            measured_throughput_completions=2449,
            measurement_window_s=90.0,
            serial_max_theoretical_completions=2004,
        )
        self.assertFalse(res["kernel_exceeds_residence"])
        self.assertFalse(res["concurrency_alone_falsifies_serial"])
        self.assertTrue(res["serial_service_model_falsified_by_throughput"])


class TestOutcomeValidationAndR3Rejection(unittest.TestCase):
    """Test outcome validation rejecting R3 flaws (zero tokens, NaN origin, pseudoreplication)."""

    def test_zero_completion_tokens_rejected(self):
        """0 output tokens must be rejected as invalid and not scored as good."""
        outcome = RequestOutcome(
            request_id="req-zero",
            prompt_tokens=128,
            output_tokens=0,  # Flaw in R3
            scheduled_at=10.0,
            client_post_at=10.05,
            first_content_at=10.2,
            terminal_at=10.25,
            origin_s=10.0,
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertFalse(val["valid"])
        self.assertFalse(val["is_good"])
        self.assertIn("invalid_output_token_count_must_be_positive_integer_not_bool", val["rejection_reasons"])

    def test_boolean_tokens_rejected(self):
        """Boolean tokens (bool is subclass of int in Python) must be explicitly rejected."""
        outcome = RequestOutcome(
            request_id="req-bool",
            prompt_tokens=True,  # Flaw: boolean prompt
            output_tokens=True,  # Flaw: boolean output
            scheduled_at=10.0,
            client_post_at=10.05,
            first_content_at=10.2,
            terminal_at=10.25,
            origin_s=10.0,
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertFalse(val["valid"])
        self.assertIn("invalid_prompt_token_count_must_be_positive_integer_not_bool", val["rejection_reasons"])
        self.assertIn("invalid_output_token_count_must_be_positive_integer_not_bool", val["rejection_reasons"])

    def test_chronology_inversion_rejected(self):
        """Client POST timestamp occurring after first token or terminal must be rejected."""
        outcome = RequestOutcome(
            request_id="req-chrono",
            prompt_tokens=128,
            output_tokens=32,
            scheduled_at=10.0,
            client_post_at=100.0,  # Flaw: client POST at 100 after first at 10.1
            first_content_at=10.1,
            terminal_at=10.2,
            origin_s=10.0,
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertFalse(val["valid"])
        self.assertIn("chronology_inversion_post_after_first", val["rejection_reasons"])

    def test_nan_origin_rejected(self):
        """NaN origin timestamp must be rejected as invalid."""
        outcome = RequestOutcome(
            request_id="req-nan",
            prompt_tokens=128,
            output_tokens=16,
            scheduled_at=10.0,
            client_post_at=10.05,
            first_content_at=10.2,
            terminal_at=10.5,
            origin_s=float("nan"),  # Flaw in R3
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertFalse(val["valid"])
        self.assertFalse(val["is_good"])
        self.assertIn("nonfinite_origin_timestamp", val["rejection_reasons"])

    def test_valid_good_outcome(self):
        """A properly formatted request meeting SLOs must be scored good."""
        outcome = RequestOutcome(
            request_id="req-valid",
            prompt_tokens=128,
            output_tokens=32,
            scheduled_at=10.0,
            client_post_at=10.01,
            first_content_at=10.15,  # TTFT = 0.15s <= 0.5s
            terminal_at=10.77,       # TPOT = (10.77 - 10.15) / 31 = 0.02s <= 0.05s
            origin_s=10.0,
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertTrue(val["valid"])
        self.assertTrue(val["is_good"])
        self.assertAlmostEqual(val["ttft_s"], 0.15)
        self.assertAlmostEqual(val["tpot_s"], 0.02)

    def test_evaluator_rejects_pseudoreplication(self):
        """Duplicating the identical block (R3 flaw) must trigger pseudoreplication rejection."""
        evaluator = SuperiorityEvaluator(min_blocks=6)
        single_block = IndependentSeedBlockOutcome(
            block_id="block-dup",
            seed=170001,
            workload_family="short_homogeneous",
            split="development",
            duration_s=10.0,
            control_decisions=10,
            offered_requests=100,
            policy_a_good_completions=10,
            policy_a_rejections=5,
            policy_a_solver_overruns=0,
            policy_b_good_completions=20,
            policy_b_rejections=5,
            policy_b_solver_overruns=0,
        )
        # Duplicate identical block 6 times
        replicated_blocks = [single_block] * 6
        res = evaluator.evaluate(replicated_blocks)
        self.assertEqual(res["verdict"], "REJECTED_PSEUDOREPLICATION")
        self.assertFalse(res["statistically_significant"])

    def test_impossible_aggregates_rejected(self):
        """Aggregates with more good completions than offered requests must raise ValueError."""
        with self.assertRaises(ValueError):
            IndependentSeedBlockOutcome(
                block_id="block-impossible",
                seed=170001,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=10,
                offered_requests=5,
                policy_a_good_completions=10,  # 10 > 5 is physically impossible
                policy_a_rejections=0,
                policy_a_solver_overruns=0,
                policy_b_good_completions=2,
                policy_b_rejections=0,
                policy_b_solver_overruns=0,
            )

    def test_evaluator_exact_permutation_and_zero_variance_handling(self):
        """Equal independent differences are evaluated by exact sign-flip without artificial crash."""
        evaluator = SuperiorityEvaluator(min_blocks=6, pre_registered_margin_req_s=0.5)
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"block-{i}",
                seed=170000 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=10,
                offered_requests=100,
                policy_a_good_completions=10,
                policy_a_rejections=5,
                policy_a_solver_overruns=0,
                policy_b_good_completions=20,  # Exactly +1.0 req/s difference across all
                policy_b_rejections=5,
                policy_b_solver_overruns=0,
            )
            for i in range(6)
        ]
        res = evaluator.evaluate(blocks)
        # For N=6 identical signs, two-sided exact sign-flip p-value is 2 / (2^6) = 2/64 = 0.03125
        self.assertEqual(res["verdict"], "DISTINGUISHABLE_FROM_NULL")
        self.assertAlmostEqual(res["two_sided_permutation_p_value"], 0.03125)
        self.assertGreaterEqual(res["two_sided_permutation_p_value"], 1.0 / (2 ** (6 - 1)))
        self.assertAlmostEqual(res["bootstrap_ci95"][0], 1.0)
        self.assertAlmostEqual(res["bootstrap_ci95"][1], 1.0)

    def test_evaluator_confirms_valid_superiority(self):
        """Independent blocks with natural variance and genuine margin can achieve confirmation."""
        evaluator = SuperiorityEvaluator(
            min_blocks=6,
            pre_registered_margin_req_s=0.5,
        )
        # 8 independent blocks with positive mean improvement and natural variance
        good_b = [22, 24, 21, 25, 23, 26, 22, 24]
        good_a = [12, 11, 13, 10, 12, 11, 13, 12]
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"valid-block-{i}",
                seed=170010 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=10,
                offered_requests=100,
                policy_a_good_completions=good_a[i],
                policy_a_rejections=5,
                policy_a_solver_overruns=0,
                policy_b_good_completions=good_b[i],
                policy_b_rejections=5,
                policy_b_solver_overruns=0,
            )
            for i in range(8)
        ]
        res = evaluator.evaluate(blocks)
        self.assertEqual(res["verdict"], "DISTINGUISHABLE_FROM_NULL")
        self.assertTrue(res["statistically_significant"])
        self.assertTrue(res["margin_satisfied"])
        self.assertGreater(res["std_goodput_difference"], 0.0)
        self.assertGreaterEqual(res["two_sided_permutation_p_value"], 1.0 / (2 ** (8 - 1)))

    def test_holm_bonferroni_correction(self):
        """Holm-Bonferroni step-down must correctly control FWER."""
        raw_p = [0.005, 0.02, 0.03, 0.10]
        adj = holm_bonferroni_step_down(raw_p, familywise_alpha=0.05)
        # Sorted: 0.005 (x4=0.02 <= 0.05 -> True), 0.02 (x3=0.06 > 0.05 -> False), ...
        self.assertTrue(adj[0]["significant_after_correction"])
        self.assertFalse(adj[1]["significant_after_correction"])
        self.assertFalse(adj[2]["significant_after_correction"])
        self.assertFalse(adj[3]["significant_after_correction"])


class TestObservableBatchState(unittest.TestCase):
    """Test observable Gateway state, soft-cap behavior, and conservation."""

    def test_soft_cap_reduction_does_not_evict(self):
        """Lowering applied cap from 32 to 16 must NOT evict existing reservations."""
        state = ObservableBatchState(initial_cap=32.0)
        
        # Admit 3 requests with cost 8.0 each -> total 24.0
        for i in range(3):
            admitted = state.admit(MarkedReservationRecord(
                request_id=f"r-{i}",
                original_cost=8.0,
                admitted_at=10.0 + i,
                prompt_tokens=256,
                max_tokens=128,
            ))
            self.assertTrue(admitted)
            
        self.assertEqual(state.reserved_cost, 24.0)
        
        # Lower cap to 16.0
        state.update_cap(16.0)
        self.assertEqual(state.applied_cap, 16.0)
        # Invariant: existing reservations survive
        self.assertEqual(state.reserved_cost, 24.0)
        self.assertEqual(len(state.active_reservations), 3)
        
        # New admission is throttled because 24.0 + 4.0 > 16.0
        new_admitted = state.admit(MarkedReservationRecord(
            request_id="r-new",
            original_cost=4.0,
            admitted_at=15.0,
            prompt_tokens=128,
            max_tokens=128,
        ))
        self.assertFalse(new_admitted)

    def test_release_and_conservation(self):
        """Releasing terminal reservations strictly decreases reserved cost without duplicate reuse."""
        state = ObservableBatchState(initial_cap=32.0)
        rec = MarkedReservationRecord(
            request_id="r-term",
            original_cost=6.5,
            admitted_at=10.0,
            prompt_tokens=512,
            max_tokens=128,
        )
        state.admit(rec)
        self.assertEqual(state.reserved_cost, 6.5)

        # Duplicate admission of the active request must raise ValueError
        with self.assertRaises(ValueError):
            state.admit(rec)

        released = state.release("r-term", timestamp_s=12.5)
        self.assertIsNotNone(released)
        self.assertEqual(state.reserved_cost, 0.0)
        self.assertEqual(len(state.history_released), 1)

        # Re-releasing non-active request returns None
        self.assertIsNone(state.release("r-term", timestamp_s=13.0))
        self.assertEqual(state.reserved_cost, 0.0)

    def test_normalized_absolute_error_computation(self):
        """NAE across multi-step horizons must be correctly normalized."""
        pred = {1: 4.0, 3: 8.0, 5: 12.0}
        actual = {1: 5.0, 3: 8.0, 5: 10.0}
        origin_r = 16.0
        
        res = compute_normalized_absolute_error(pred, actual, origin_r)
        self.assertFalse(res["empty_origin"])
        # |4-5|/16 = 1/16, |8-8|/16 = 0, |12-10|/16 = 2/16 -> mean = (3/16)/3 = 1/16 = 0.0625
        self.assertAlmostEqual(res["mean_normalized_absolute_error"], 0.0625)


class TestCampaignProtocolBuilder(unittest.TestCase):
    """Test campaign protocol builder properties (duration, workloads, splits, immutability)."""

    def test_protocol_builder_duration_exceeds_10_hours(self):
        """The protocol must schedule >= 10.0 hours of active execution."""
        protocol = build_native_campaign_protocol()
        hours = protocol["duration_summary"]["total_active_hours"]
        self.assertGreaterEqual(hours, 10.0, f"Scheduled hours {hours:.2f}h must be >= 10.0h")
        self.assertTrue(protocol["duration_summary"]["hours_requirement_satisfied"])
        self.assertEqual(protocol["duration_summary"]["total_episodes"], 320)

    def test_eight_workload_families_present(self):
        """All 8 workload families must be declared and populated in the protocol."""
        protocol = build_native_campaign_protocol()
        self.assertEqual(len(protocol["workload_families"]), 8)
        for fam in WORKLOAD_FAMILIES:
            self.assertIn(fam, protocol["workload_families"])

    def test_splits_and_seed_isolation(self):
        """Train, calibration, development, and final splits must be populated with fresh seeds."""
        protocol = build_native_campaign_protocol(base_seed=180001)
        groups = protocol["groups"]
        all_seeds = [g["seed"] for g in groups.values()]
        
        # Verify no duplicate seeds
        self.assertEqual(len(all_seeds), len(set(all_seeds)))
        
        # Verify historical held-out seeds 160021-160024 are NOT used
        for seed in all_seeds:
            self.assertFalse(
                160021 <= seed <= 160024,
                f"Seed {seed} must not overlap with historical final held-out seeds 160021-160024!",
            )

    def test_matched_arms_share_tape(self):
        """Matched arms (0 and 1) must share identical arrival and prompt tape keys."""
        protocol = build_native_campaign_protocol()
        episodes = protocol["episodes"]
        
        # Group episodes by block_id
        by_block = {}
        for ep in episodes:
            by_block.setdefault(ep["block_id"], []).append(ep)
            
        for block_id, eps in by_block.items():
            self.assertEqual(len(eps), 2, f"Block {block_id} must have exactly 2 matched arms")
            arm0, arm1 = sorted(eps, key=lambda x: x["arm"])
            self.assertEqual(arm0["arm"], 0)
            self.assertEqual(arm1["arm"], 1)
            self.assertEqual(arm0["arrival_tape_key"], arm1["arrival_tape_key"])
            self.assertEqual(arm0["prompt_tape_key"], arm1["prompt_tape_key"])

    def test_canonical_digest_immutability(self):
        """Protocol hash must be a deterministic 64-character SHA-256 hex string."""
        p1 = build_native_campaign_protocol()
        p2 = build_native_campaign_protocol()
        self.assertEqual(p1["protocol_hash"], p2["protocol_hash"])
        self.assertEqual(len(p1["protocol_hash"]), 64)

    def test_protocol_json_serialization_roundtrip(self):
        """Protocol must serialize to valid JSON without NaN or Inf and roundtrip exactly."""
        protocol = build_native_campaign_protocol()
        json_str = json.dumps(protocol, allow_nan=False)
        roundtrip = json.loads(json_str)
        self.assertEqual(protocol["protocol_hash"], roundtrip["protocol_hash"])
        self.assertEqual(len(roundtrip["episodes"]), 320)

    def test_overrun_guard_rejection(self):
        """Excessive decision overruns must trigger REJECTED_OVERRUN_GUARD."""
        evaluator = SuperiorityEvaluator(min_blocks=6, max_decision_overrun_rate=0.01)
        good_b = [22, 24, 21, 25, 23, 26]
        good_a = [12, 11, 13, 10, 12, 11]
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"overrun-block-{i}",
                seed=170050 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=100,
                offered_requests=100,
                policy_a_good_completions=good_a[i],
                policy_a_rejections=5,
                policy_a_solver_overruns=0,
                policy_b_good_completions=good_b[i],
                policy_b_rejections=5,
                policy_b_solver_overruns=5,  # 5% overrun rate > 1% threshold
            )
            for i in range(6)
        ]
        res = evaluator.evaluate(blocks)
        self.assertEqual(res["verdict"], "REJECTED_OVERRUN_GUARD")
        self.assertFalse(res["overrun_guard_passed"])

    def test_rejection_guard_rejection(self):
        """Excessive relative rejection increase must trigger REJECTED_REJECTION_GUARD."""
        evaluator = SuperiorityEvaluator(min_blocks=6, max_relative_rejection_increase=0.05)
        good_b = [22, 24, 21, 25, 23, 26]
        good_a = [12, 11, 13, 10, 12, 11]
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"rej-block-{i}",
                seed=170060 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=100,
                offered_requests=100,
                policy_a_good_completions=good_a[i],
                policy_a_rejections=10,
                policy_a_solver_overruns=0,
                policy_b_good_completions=good_b[i],
                policy_b_rejections=15,  # 50% relative increase > 5% threshold
                policy_b_solver_overruns=0,
            )
            for i in range(6)
        ]
        res = evaluator.evaluate(blocks)
        self.assertEqual(res["verdict"], "REJECTED_REJECTION_GUARD")
        self.assertFalse(res["rejection_guard_passed"])

    def test_controllers_produce_valid_budgets(self):
        """All supported valid baseline controllers must produce allowed budgets in {16.0, 32.0}."""
        state = ObservableBatchState(initial_cap=16.0)
        controllers = [
            Fixed16Controller(),
            HeuristicBacklogController(),
            HeuristicThresholdController(),
        ]
        for ctrl in controllers:
            decision = ctrl.decide(state, queue_length=5)
            self.assertIn(decision, (16.0, 32.0))

    def test_misleading_mpc_aliases_rejected(self):
        """Calling StrongOneMoveController or RecedingHorizonMPCController must raise RuntimeError."""
        with self.assertRaises(RuntimeError):
            StrongOneMoveController()
        with self.assertRaises(RuntimeError):
            RecedingHorizonMPCController()


class TestRound2PeerCounterexamplesAndSurgicalFixes(unittest.TestCase):
    """Round 2 tests: reproducible counterexamples, peer bug demonstrations, and surgical fixes."""

    def test_astra_selection_defect_reproduced_and_fixed(self):
        """Astra's decision tree drops resolved Two-Move actions when One-Move is unresolved."""
        res = demonstrate_astra_selection_defect()
        # Verify Astra unfixed status falls back to uncertainty despite Two-Move being resolved
        self.assertFalse(res["one_resolved"], "One-move should be unresolved")
        self.assertTrue(res["two_resolved"], "Two-move should be resolved")
        self.assertGreater(res["gain_lower"], 0.0, "Two-move has strictly positive lower gain")
        self.assertEqual(res["astra_unfixed_status"], "fallback")
        self.assertEqual(res["astra_unfixed_reason"], "first-action uncertainty")
        self.assertIsNone(res["astra_unfixed_cap"], "Astra sends no command despite resolved action")
        
        # Verify surgical fix resolves to shadow action with cap 16
        self.assertEqual(res["surgical_fixed_status"], "shadow")
        self.assertEqual(res["surgical_fixed_chosen"], "two")
        self.assertEqual(res["surgical_fixed_cap"], 16)

    def test_sol_block_ceiling_and_float_defect_reproduced_and_fixed(self):
        """Sol's paired_effect crashes on N > 16 blocks, and its scheduled float check is brittle."""
        res = demonstrate_sol_block_ceiling_and_float_defect()
        self.assertTrue(res["sol_crashes_on_dev_split_32_blocks"])
        self.assertTrue(res["exact_float_inequality_triggered"])
        self.assertGreater(res["float_difference"], 0.0)

        # Test robust permutation test on small N (exact rational enumeration)
        effects_small = [0.1, 0.2, 0.15, 0.3, -0.05, 0.25]
        res_exact = robust_paired_permutation_test(effects_small, max_exact_n=16)
        self.assertEqual(res_exact["n_blocks"], 6)
        self.assertTrue(res_exact["method"].startswith("exact_sign_flip_rational"))
        self.assertLess(res_exact["p_value"], 0.1)

        # Test robust permutation test on large N=32 (development split scale) via Monte Carlo
        effects_dev = [0.15 + (0.02 * (i % 5) - 0.04) for i in range(32)]
        res_mc = robust_paired_permutation_test(effects_dev, max_exact_n=16, mc_samples=1000)
        self.assertEqual(res_mc["n_blocks"], 32)
        self.assertTrue(res_mc["method"].startswith("conservative_monte_carlo_permutation"))
        self.assertTrue(res_mc["statistically_significant"])

    def test_robust_permutation_exact_rational_regression_491c42b7(self):
        """Regression test for 491c42b7: exact rational sign arithmetic must not collapse at 1e-15."""
        # On 491c42b7 with 1e-12 tolerance, [1e-15]*4 returned p=1.0 instead of exact 0.125
        res_tiny = robust_paired_permutation_test([1e-15, 1e-15, 1e-15, 1e-15])
        self.assertEqual(res_tiny["n_blocks"], 4)
        self.assertAlmostEqual(res_tiny["p_value"], 0.125)
        self.assertTrue(res_tiny["exact_rational_arithmetic"])

        # Identical result for [1.0, 1.0, 1.0, 1.0]
        res_unit = robust_paired_permutation_test([1.0, 1.0, 1.0, 1.0])
        self.assertAlmostEqual(res_unit["p_value"], 0.125)

        # Reject non-finite inputs
        with self.assertRaises(ValueError):
            robust_paired_permutation_test([1.0, float("nan"), 1.0])

    def test_actual_duration_accounting_falsifies_planned_time(self):
        """Planned time, setup, idle, and drain cannot be counted as completed >=10h science."""
        # Case A: 48,000s planned, but only 18,000s realized active measurement
        acct_partial = ExperimentDurationAccounting(
            planned_windows_count=400,
            window_duration_seconds=120.0,
            planned_active_measurement_seconds=48000.0,
            realized_active_measurement_seconds=18000.0,  # 5 hours
            drain_duration_seconds=6000.0,
            epoch_rollover_duration_seconds=1200.0,
            setup_and_idle_seconds=14400.0,
            verified_interval_durations_s=(120.0,) * 150,
        )
        passed, reason = acct_partial.validate_actual_10h_milestone()
        self.assertFalse(passed, "Planned 48ks and idle time cannot pass 10h threshold")
        self.assertIn("Falsified", reason)

        # Case B: 36,050s realized active measurement WITH verified interval evidence (meets requirement)
        intervals_300 = (120.16666666666667,) * 300
        acct_complete = ExperimentDurationAccounting(
            planned_windows_count=320,
            window_duration_seconds=120.0,
            planned_active_measurement_seconds=38400.0,
            realized_active_measurement_seconds=36050.0,  # > 10.0h
            drain_duration_seconds=2400.0,
            epoch_rollover_duration_seconds=600.0,
            setup_and_idle_seconds=1800.0,
            verified_interval_durations_s=intervals_300,
        )
        passed_comp, reason_comp = acct_complete.validate_actual_10h_milestone()
        self.assertTrue(passed_comp)
        self.assertIn("Qualified", reason_comp)

    def test_actual_duration_accounting_regression_nan_inf_and_naked_scalar(self):
        """Regression test for 491c42b7: reject NaN, Inf, and naked unverified caller scalars."""
        # 1. Reject NaN in constructor
        with self.assertRaises(ValueError):
            ExperimentDurationAccounting(
                planned_windows_count=400,
                window_duration_seconds=120.0,
                planned_active_measurement_seconds=48000.0,
                realized_active_measurement_seconds=float("nan"),
                drain_duration_seconds=100.0,
                epoch_rollover_duration_seconds=100.0,
                setup_and_idle_seconds=100.0,
            )

        # 2. Reject Inf in constructor
        with self.assertRaises(ValueError):
            ExperimentDurationAccounting(
                planned_windows_count=400,
                window_duration_seconds=120.0,
                planned_active_measurement_seconds=48000.0,
                realized_active_measurement_seconds=float("inf"),
                drain_duration_seconds=100.0,
                epoch_rollover_duration_seconds=100.0,
                setup_and_idle_seconds=100.0,
            )

        # 3. Reject naked caller scalar 36050.0 lacking verified interval evidence
        acct_naked = ExperimentDurationAccounting(
            planned_windows_count=400,
            window_duration_seconds=120.0,
            planned_active_measurement_seconds=48000.0,
            realized_active_measurement_seconds=36050.0,
            drain_duration_seconds=100.0,
            epoch_rollover_duration_seconds=100.0,
            setup_and_idle_seconds=100.0,
            verified_interval_durations_s=None,  # Naked scalar without interval receipts
        )
        passed_naked, reason_naked = acct_naked.validate_actual_10h_milestone()
        self.assertFalse(passed_naked)
        self.assertIn("lacks verified interval evidence", reason_naked)

    def test_gateway_epoch_rollovers_respect_1024_op_ceiling(self):
        """Gateway epochs must bound operations below 1024 without restarting native engine."""
        protocol = build_native_campaign_protocol()
        episodes = protocol["episodes"]
        epochs = plan_gateway_epochs(episodes, episodes_per_epoch=2, max_ops_per_epoch=1024)
        
        # 320 episodes / 2 episodes per epoch = 160 epochs
        self.assertEqual(len(epochs), 160)
        for ep in epochs:
            self.assertEqual(len(ep.episode_ids), 2)
            self.assertLess(ep.estimated_operations, 1024)
            self.assertTrue(ep.requires_strict_drain_before_rollover)
            self.assertFalse(ep.requires_native_restart)
            self.assertFalse(ep.evict_idempotency_tables)
            self.assertTrue(ep.clock_domain.startswith("linux-monotonic:"))
            self.assertEqual(ep.clock_domain, epochs[0].clock_domain)
            self.assertEqual(ep.cache_type, "in_memory")

    def test_qualification_tail_distribution_audit(self):
        """Authoritative qualification receipt 2587d2b proves 100% tail incidence on LIGHT requests."""
        audit = audit_native_qualification_tail_distribution()
        self.assertEqual(audit["qualification_commit"], "2587d2b")
        self.assertEqual(audit["total_requests"], 40)
        self.assertEqual(audit["natural_eos_count"], 40)
        self.assertEqual(audit["v3_audits_valid"], 16)
        self.assertEqual(audit["legacy_v2_audits_retained_false"], 8)
        self.assertEqual(audit["light_requests_measured"], 20)
        self.assertEqual(audit["light_requests_with_tail"], 20)
        self.assertAlmostEqual(audit["measured_tail_incidence_rate"], 1.0)
        self.assertEqual(audit["off_requests_unmeasured"], 20)
        self.assertFalse(audit["tail_is_stochastic_0_1"])

    def test_canonical_join_observations(self):
        """Canonical observation joiner must resolve chatcmpl-<32hex>-<8hex> to <32hex>."""
        gw_marks = [
            {"request_id": "a" * 32, "client_post_at": 10.0, "status": "accepted"},
            {"request_id": "b" * 32, "client_post_at": 10.1, "status": "accepted"},
            {"request_id": "c" * 32, "client_post_at": 10.2, "status": "accepted"},
        ]
        native_frame = {
            "requests": [
                {
                    "request_id": f"chatcmpl-{'a' * 32}-12345678",
                    "computed_tokens": 128,
                    "output_tokens": 16,
                }
            ]
        }
        res = canonical_join_observations(gw_marks, native_frame)
        self.assertEqual(res["total_gateway_marks"], 3)
        self.assertEqual(res["joined_native_running"], 1)
        # 2 marks were accepted by Gateway but not visible in native running
        self.assertEqual(res["accepted_not_native_visible_count"], 2)
        self.assertAlmostEqual(res["accepted_not_native_visible_ratio"], 2.0 / 3.0)
        self.assertTrue(res["canonical_normalization_verified"])


class TestTrainDiagnosticsAndCausalOnlineCut(unittest.TestCase):
    """Test online cut causal conditioning and Train seedblock 181001 diagnostics."""

    def test_online_cut_filters_strictly_before_cut(self):
        """Observations after cut timestamp must be excluded to prevent future leakage."""
        adapter = OnlineCutObservationAdapter(
            cut_time_s=100.0,
            applied_action_sequence=(16.0, 32.0),
            cas_delay_s=0.05,
        )
        observations = [
            {"request_id": "r1", "receipt_at": 99.5, "status": "accepted"},
            {"request_id": "r2", "receipt_at": 100.0, "status": "accepted"},
            {"request_id": "r3", "receipt_at": 100.05, "status": "accepted"},  # Future
            {"request_id": "r4", "status": "accepted"},  # Missing receipt
        ]
        filtered = adapter.filter_observations(observations)
        self.assertEqual(len(filtered), 2)
        self.assertEqual([o["request_id"] for o in filtered], ["r1", "r2"])
        self.assertTrue(adapter.verify_no_post_action_leakage(filtered, action_application_time_s=100.05))

    def test_online_cut_rejects_post_action_causal_inversion(self):
        """Action applied before cut timestamp must raise a causal violation ValueError."""
        adapter = OnlineCutObservationAdapter(
            cut_time_s=100.0,
            applied_action_sequence=(16.0, 32.0),
        )
        filtered = [{"request_id": "r1", "receipt_at": 99.0}]
        with self.assertRaises(ValueError):
            adapter.verify_no_post_action_leakage(filtered, action_application_time_s=98.0)

    def test_sequence_order_preserved_no_average_aliasing(self):
        """Sequence [16, 32] is not aliased to scalar average 24.0 or reversed order [32, 16]."""
        adapter1 = OnlineCutObservationAdapter(cut_time_s=10.0, applied_action_sequence=(16.0, 32.0))
        adapter2 = OnlineCutObservationAdapter(cut_time_s=10.0, applied_action_sequence=(32.0, 16.0))
        self.assertNotEqual(adapter1.applied_action_sequence, adapter2.applied_action_sequence)
        with self.assertRaises(ValueError):
            OnlineCutObservationAdapter(cut_time_s=10.0, applied_action_sequence=(24.0,))  # Average cap invalid

    def test_train_block_diagnostics_audit(self):
        """Train seedblock 181001 diagnostics demonstrate transient memory and KV usage."""
        diag_path = "/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-long01-replica/first-train-block-descriptive-diagnostics.json"
        if os.path.exists(diag_path):
            with open(diag_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            audit = audit_train_block_diagnostics(data)
            self.assertEqual(audit["seedblock"], 181001)
            self.assertEqual(audit["cells_audited"], 5)
            self.assertAlmostEqual(audit["max_overall_kv_usage"], 0.37247, places=3)
            # Short p128-m128 transient ratio ~14% (112 / 795)
            self.assertAlmostEqual(audit["short_p128_m128_transient_ratio"], 112 / 795, places=3)
            # Prefill-heavy p4096-m128 transient ratio ~40% (363 / 909)
            self.assertAlmostEqual(audit["prefill_p4096_m128_transient_ratio"], 363 / 909, places=3)
            self.assertIn("1.25s to 3.24s", audit["control_timescale_justification"])


class TestRound4IndependentCritiqueAndReceiptHardening(unittest.TestCase):
    """Round 4 tests validating interval non-overlap, clock domain homogeneity, and finite-B conservatism."""

    def test_duration_accounting_rejects_overlapping_intervals_double_count(self):
        """Overlapping execution intervals on the same Pod cannot be counted twice toward 10h."""
        # Two arms running concurrently during [0, 20000s].
        # Naive sum is 40,000s (> 10h), but disjoint union duration is only 20,000s (< 10h).
        receipts = (
            MeasuredIntervalReceipt(
                start_s=0.0,
                end_s=20000.0,
                epoch_id="epoch-001",
                clock_domain="linux-monotonic:pod1",
                arm=0,
            ),
            MeasuredIntervalReceipt(
                start_s=0.0,
                end_s=20000.0,
                epoch_id="epoch-001",
                clock_domain="linux-monotonic:pod1",
                arm=1,
            ),
        )
        # Caller claims naive sum 40000.0 as realized measurement time
        acct = ExperimentDurationAccounting(
            planned_windows_count=400,
            window_duration_seconds=120.0,
            planned_active_measurement_seconds=48000.0,
            realized_active_measurement_seconds=40000.0,
            drain_duration_seconds=100.0,
            epoch_rollover_duration_seconds=100.0,
            setup_and_idle_seconds=100.0,
            verified_interval_receipts=receipts,
        )
        passed, reason = acct.validate_actual_10h_milestone()
        self.assertFalse(passed)
        self.assertIn("double-counts overlapping intervals", reason)

    def test_duration_accounting_rejects_mismatched_clock_domain_or_unrelated_epoch(self):
        """Interval receipts from unrelated source epochs or mismatched clock domains must be rejected."""
        receipts = (
            MeasuredIntervalReceipt(
                start_s=0.0,
                end_s=18000.0,
                epoch_id="epoch-001",
                clock_domain="linux-monotonic:pod1-valid",
                arm=0,
            ),
            MeasuredIntervalReceipt(
                start_s=18000.0,
                end_s=36500.0,
                epoch_id="epoch-unrelated",
                clock_domain="linux-monotonic:pod2-alien-reboot",
                arm=0,
            ),
        )
        acct = ExperimentDurationAccounting(
            planned_windows_count=400,
            window_duration_seconds=120.0,
            planned_active_measurement_seconds=48000.0,
            realized_active_measurement_seconds=36500.0,
            drain_duration_seconds=100.0,
            epoch_rollover_duration_seconds=100.0,
            setup_and_idle_seconds=100.0,
            verified_interval_receipts=receipts,
        )
        passed, reason = acct.validate_actual_10h_milestone(expected_clock_domain="linux-monotonic:pod1-valid")
        self.assertFalse(passed)
        self.assertIn("unrelated clock domain", reason)

    def test_duration_accounting_qualifies_disjoint_intervals_exceeding_10h(self):
        """Disjoint interval receipts exceeding 36,000s under constant clock domain must qualify."""
        receipts = (
            MeasuredIntervalReceipt(
                start_s=0.0,
                end_s=18000.0,
                epoch_id="epoch-001",
                clock_domain="linux-monotonic:pod1-valid",
                arm=0,
            ),
            # Gap of 100s between epochs
            MeasuredIntervalReceipt(
                start_s=18100.0,
                end_s=36200.0,
                epoch_id="epoch-002",
                clock_domain="linux-monotonic:pod1-valid",
                arm=0,
            ),
        )
        # Disjoint union: 18000 + 18100 = 36100s (> 10h)
        acct = ExperimentDurationAccounting(
            planned_windows_count=400,
            window_duration_seconds=120.0,
            planned_active_measurement_seconds=48000.0,
            realized_active_measurement_seconds=36100.0,
            drain_duration_seconds=100.0,
            epoch_rollover_duration_seconds=100.0,
            setup_and_idle_seconds=100.0,
            verified_interval_receipts=receipts,
        )
        passed, reason = acct.validate_actual_10h_milestone()
        self.assertTrue(passed)
        self.assertIn("Qualified", reason)
        self.assertIn("10.03h", reason)

    def test_monte_carlo_permutation_finite_b_is_conservative_not_unbiased(self):
        """Finite-B Monte Carlo permutation inference is explicitly conservative, bounding FWER."""
        # N = 17 blocks (> max_exact_n=16) with all equal positive effects
        diffs = [1.0] * 17
        res = robust_paired_permutation_test(diffs, max_exact_n=16, mc_samples=1000, random_seed=42)
        self.assertFalse(res["exact_rational_arithmetic"])
        self.assertIn("conservative_monte_carlo", res["method"])
        # Even if 0 sampled permutations exceed observed sum, p-value cannot be 0
        # Formula: (1 + extreme) / (1 + B) >= 1 / 1001 ≈ 0.000999
        self.assertGreater(res["p_value"], 0.0)
        self.assertAlmostEqual(res["p_value"], (1.0 + 0.0) / (1.0 + 1000.0), places=5)


class TestRound6StructuralBatchProgressArchitecture(unittest.TestCase):
    """Round 6 tests: Structural batch progress, causal action pathway, and progress vs scalar diagnostic."""

    def test_structural_batch_progress_state_invariants(self):
        """Minimal observable state validates physical bounds and cohort structures."""
        state = StructuralBatchProgressState(
            timestamp_s=10.0,
            applied_cap=16.0,
            active_reserved_cost=12.0,
            prefill_cohort=(
                PrefillRequestState(
                    request_id="pref-1",
                    prompt_tokens=512,
                    computed_tokens=256,
                    original_cost=6.0,
                    admitted_at=9.5,
                    scheduled_at=9.4,
                ),
            ),
            decode_cohort=(
                DecodeRequestState(
                    request_id="dec-1",
                    prompt_tokens=128,
                    output_tokens=15,
                    maximum_output_tokens=32,
                    original_cost=6.0,
                    admitted_at=9.0,
                    scheduled_at=8.9,
                    first_token_at=9.2,
                ),
            ),
            kv_cache_usage=0.25,
        )
        self.assertEqual(state.timestamp_s, 10.0)
        self.assertEqual(state.applied_cap, 16.0)
        self.assertEqual(state.active_reserved_cost, 12.0)
        self.assertEqual(state.prefill_cohort[0].remaining_prompt_tokens, 256)
        self.assertEqual(state.decode_cohort[0].remaining_output_tokens, 17)
        self.assertEqual(state.kv_cache_usage, 0.25)

        # Invariant: Invalid cap raises ValueError
        with self.assertRaises(ValueError):
            StructuralBatchProgressState(
                timestamp_s=10.0,
                applied_cap=24.0,  # Invalid cap
                active_reserved_cost=12.0,
                prefill_cohort=(),
                decode_cohort=(),
            )

    def test_causal_action_pathway_zero_direct_gpu_edge(self):
        """Gateway cap u_t enters ONLY at admission; GPU hardware service rate has ZERO direct cap edge."""
        model = StructuralBatchProgressHybridModel()
        mock_state = StructuralBatchProgressState(
            timestamp_s=10.0,
            applied_cap=16.0,
            active_reserved_cost=16.0,
            prefill_cohort=(
                PrefillRequestState("p1", 512, 0, 8.0, 10.0, 10.0),
            ),
            decode_cohort=(
                DecodeRequestState("d1", 128, 10, 32, 8.0, 9.0, 9.0, 9.2),
            ),
        )
        # Verify across candidate caps {16.0, 32.0}
        invariant_holds = CausalActionPathwayValidator.validate_causal_graph(
            candidate_caps=[16.0, 32.0],
            service_rate_fn=model.compute_gpu_service_rate,
            mock_state=mock_state,
        )
        self.assertTrue(invariant_holds)

    def test_structural_progress_vs_scalar_counterexample(self):
        """State A (decode near EOS) vs State B (prefill 4096) with identical R=16 diverge in goodput."""
        diag = run_structural_progress_vs_scalar_diagnostic()
        self.assertTrue(diag["birth_dominance_confirmed"])
        self.assertGreater(diag["birth_share_5s"], 0.80)
        self.assertTrue(diag["oracle_offers_still_loses_to_history"])

        # Counterexample checks
        cx = diag["counterexample"]
        self.assertTrue(cx["identical_scalar_cost"])
        self.assertEqual(cx["scalar_cost_state_a"], 16.0)
        self.assertEqual(cx["scalar_cost_state_b"], 16.0)
        # State A finishes decode and admits arrivals; State B stays saturated and rejects arrivals
        self.assertGreater(cx["state_a_good_completed"], 0)
        self.assertEqual(cx["state_b_good_completed"], 0)
        self.assertGreater(cx["state_b_rejected"], 0)
        self.assertTrue(cx["goodput_divergence"])

    def test_train1_2_fit_train3_descriptive_diagnostic_receipt(self):
        """Descriptive audit of Train 1/2 vs Train 3 confirms ~81% G5 birth share and R5 performance."""
        json_path = "/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-round5-frozen/mayor-r5-dev-181003.json"
        diag = run_structural_progress_vs_scalar_diagnostic(json_path)
        self.assertAlmostEqual(diag["birth_share_5s"], 0.8109, places=3)
        self.assertTrue(diag["birth_dominance_confirmed"])


class TestRound7AdversarialArchitectureExchange(unittest.TestCase):
    """Round 7 tests: Multi-horizon full-plan response vs causal hybrid kernel discriminator."""

    def test_multi_horizon_plan_invariants(self):
        """MultiHorizonPlan validates exactly 5 binary steps in {16.0, 32.0}."""
        valid_plan = MultiHorizonPlan(budgets=(16.0, 32.0, 16.0, 32.0, 16.0))
        self.assertEqual(len(valid_plan.budgets), 5)
        self.assertEqual(valid_plan.step_duration_s, 1.0)

        # Invalid length
        with self.assertRaises(ValueError):
            MultiHorizonPlan(budgets=(16.0, 32.0, 16.0))

        # Invalid budget value
        with self.assertRaises(ValueError):
            MultiHorizonPlan(budgets=(16.0, 32.0, 24.0, 16.0, 32.0))

        # Non-positive step duration
        with self.assertRaises(ValueError):
            MultiHorizonPlan(budgets=(16.0, 16.0, 16.0, 16.0, 16.0), step_duration_s=-1.0)

    def test_unconstrained_direct_plan_spurious_cap_effect(self):
        """Unconstrained direct IO model predicts a spurious positive treatment effect in uncongested regime."""
        model = UnconstrainedDirectPlanModel(beta_per_step=0.05)
        plan_16 = MultiHorizonPlan((16.0, 16.0, 16.0, 16.0, 16.0))
        plan_32 = MultiHorizonPlan((32.0, 32.0, 32.0, 32.0, 32.0))

        # In uncongested regime, increasing cap from 16 to 32 should have ZERO physical effect
        pred_16 = model.predict_5s_goodput(r_initial=4.0, arrival_rate=2.0, plan=plan_16)
        pred_32 = model.predict_5s_goodput(r_initial=4.0, arrival_rate=2.0, plan=plan_32)
        spurious_tau = pred_32 - pred_16

        # Direct model incorrectly predicts positive effect (5 * 0.05 * 16 = 4.0)
        self.assertGreater(spurious_tau, 0.0)
        self.assertAlmostEqual(spurious_tau, 4.0)

    def test_causal_gated_plan_model_zero_uncongested_treatment_effect(self):
        """Causal admission-gated model maintains strictly ZERO treatment effect when gate is non-binding."""
        model = CausalGatedPlanResponseModel(request_cost=2.0, slo_pass_prob=0.95)
        plan_16 = MultiHorizonPlan((16.0, 16.0, 16.0, 16.0, 16.0))
        plan_32 = MultiHorizonPlan((32.0, 32.0, 32.0, 32.0, 32.0))

        # Uncongested: 2 arrivals per step (cost 4.0), R_init = 4.0 -> easily fits under 16
        uncongested_arrivals = (2.0, 2.0, 2.0, 2.0, 2.0)
        res_16 = model.evaluate_plan_response(4.0, uncongested_arrivals, plan_16)
        res_32 = model.evaluate_plan_response(4.0, uncongested_arrivals, plan_32)

        # Both admit all 10 arrivals; zero rejections; treatment effect tau == 0.0
        self.assertEqual(res_16["total_rejected"], 0.0)
        self.assertEqual(res_32["total_rejected"], 0.0)
        self.assertEqual(res_16["predicted_good"], res_32["predicted_good"])
        tau_uncongested = res_32["predicted_good"] - res_16["predicted_good"]
        self.assertEqual(tau_uncongested, 0.0)

        # Congested: 8 arrivals per step (cost 16.0), R_init = 14.0 -> severely bound under 16
        congested_arrivals = (8.0, 8.0, 8.0, 8.0, 8.0)
        c_res_16 = model.evaluate_plan_response(14.0, congested_arrivals, plan_16)
        c_res_32 = model.evaluate_plan_response(14.0, congested_arrivals, plan_32)
        self.assertGreater(c_res_16["total_rejected"], 0.0)
        self.assertGreater(c_res_32["predicted_good"], c_res_16["predicted_good"])

    def test_itt_vs_ack_compliance_dilution(self):
        """Actuation compliance analyzer computes exact dilution between scheduled plan and actual ACK."""
        comp = ActuationComplianceAnalyzer.compute_itt_compliance_dilution(
            scheduled_step_duration_s=1.0,
            actual_cas_lag_s=0.15,
            true_step_effect=2.0,
        )
        self.assertEqual(comp["compliance_ratio"], 0.85)
        self.assertAlmostEqual(comp["itt_observed_effect"], 1.70)
        self.assertAlmostEqual(comp["dilution_percentage"], 15.0)

    def test_actionable_acceptance_criteria_validation(self):
        """Actionable acceptance criteria correctly enforces all 5 mandatory preregistered checks."""
        # Case 1: All criteria met
        valid = ActionableAcceptanceCriteria.validate_acceptance_criteria(
            uncongested_treatment_effect=0.0,
            future_arrival_law_is_exogenous=True,
            compliance_corrected=True,
            positivity_verified_32_paths=True,
            dev_5s_good_mae=8.20,
            history_mean_5s_mae=8.757,
        )
        self.assertTrue(valid["all_criteria_met"])

        # Case 2: Fails uncongested check (spurious cap effect)
        invalid_c1 = ActionableAcceptanceCriteria.validate_acceptance_criteria(
            uncongested_treatment_effect=2.5,
            future_arrival_law_is_exogenous=True,
            compliance_corrected=True,
            positivity_verified_32_paths=True,
            dev_5s_good_mae=8.20,
        )
        self.assertFalse(invalid_c1["all_criteria_met"])
        self.assertFalse(invalid_c1["criterion_1_zero_uncongested_effect"]["passed"])

        # Case 3: Fails 5s Goodput MAE check (worse than history mean)
        invalid_c5 = ActionableAcceptanceCriteria.validate_acceptance_criteria(
            uncongested_treatment_effect=0.0,
            future_arrival_law_is_exogenous=True,
            compliance_corrected=True,
            positivity_verified_32_paths=True,
            dev_5s_good_mae=9.40,
        )
        self.assertFalse(invalid_c5["all_criteria_met"])
        self.assertFalse(invalid_c5["criterion_5_beats_history_mean_5s"]["passed"])

    def test_direct_plan_vs_causal_hybrid_discriminator_run(self):
        """Full discriminating diagnostic executes and validates physical divergence and compliance dilution."""
        diag = run_direct_plan_vs_causal_hybrid_discriminator()
        self.assertTrue(diag["uncongested_regime"]["causal_zero_effect_verified"])
        self.assertTrue(diag["uncongested_regime"]["direct_model_falsified"])
        self.assertTrue(diag["congested_regime"]["positive_treatment_effect_verified"])
        self.assertGreater(diag["actuation_compliance"]["dilution_percentage"], 0.0)


class TestRound8FairClosedLoopBenchmarkAndPreregisteredProtocol(unittest.TestCase):
    """Round 8 tests: Fair CPU-executable closed-loop benchmark harness & preregistered protocol."""

    def test_future_hidden_controller(self):
        """Controller callback receives strictly pre-cut published history; future tape is invisible."""
        tape = generate_workload_tape("stationary", seed=101, duration_s=10.0)
        harness = ClosedLoopBenchmarkHarness(control_slot_s=1.0, max_drain_duration_s=2.0)

        inspected_cuts = []

        def inspecting_controller(view: PublishedHistoryView) -> ControllerDecision:
            # 1. Assert internal consistency and future-hidden invariant
            view.assert_no_future_leakage()
            inspected_cuts.append(view.cut_time_s)

            # 2. Verify all visible offers have scheduled_at <= view.cut_time_s
            for offer in view.published_offers_history:
                self.assertLessEqual(offer["scheduled_at"], view.cut_time_s + 1e-9)

            # 3. Verify future offers from tape are NOT in the view
            future_tape_ids = {
                req.request_id for req in tape
                if req.scheduled_at > view.cut_time_s
            }
            visible_ids = {
                offer["request_id"] for offer in view.published_offers_history
            }
            self.assertTrue(future_tape_ids.isdisjoint(visible_ids))

            return ControllerDecision(
                decision_time_s=view.cut_time_s,
                requested_budget=16.0,
                candidate_plan=(16.0,) * 5,
                first_action=16.0,
                status="active",
                active_mpc=False,
            )

        result = harness.run_episode(tape, inspecting_controller, episode_duration_s=10.0)
        self.assertGreater(len(inspected_cuts), 5)

        # 4. Injected future leakage triggers immediate failure
        leaked_view = PublishedHistoryView(
            cut_time_s=5.0,
            applied_cap=16.0,
            active_reserved_cost=0.0,
            admitted_active_requests=(),
            completed_requests_history=(),
            rejected_requests_history=(),
            published_offers_history=({"request_id": "future-leak", "scheduled_at": 5.5, "original_cost": 2.0},),
        )
        with self.assertRaises(ValueError):
            leaked_view.assert_no_future_leakage()

    def test_same_tape_across_competing_policies(self):
        """All 5 candidate policies receive the exact same offered tape and initial drain state."""
        tape = generate_workload_tape("mixed", seed=202, duration_s=12.0)
        harness = ClosedLoopBenchmarkHarness(control_slot_s=1.0, max_drain_duration_s=3.0)

        policies = {
            "fixed16": PolicyFixed16(),
            "best_train_fixed32": PolicyBestTrainSelectedFixed(selected_budget=32.0),
            "reactive": PolicyReactive(high_cost_threshold=10.0),
            "one_move": PolicyOneMove(cost_headroom_target=6.0),
            "mpc": PolicyRecedingHorizonMPC(),
        }

        results = {}
        for name, pol in policies.items():
            results[name] = harness.run_episode(tape, pol, episode_duration_s=12.0)

        # Invariant 1: Total offered and request sequence are identical across all runs
        base_records = sorted(results["fixed16"].records, key=lambda x: x["scheduled_at"])
        base_rids = [r["request_id"] for r in base_records]
        base_sched = [r["scheduled_at"] for r in base_records]

        for name, res in results.items():
            self.assertEqual(res.summary["secondary_panels"]["total_offered"], len(base_records))
            res_sorted = sorted(res.records, key=lambda x: x["scheduled_at"])
            res_rids = [r["request_id"] for r in res_sorted]
            res_sched = [r["scheduled_at"] for r in res_sorted]
            self.assertEqual(res_rids, base_rids)
            self.assertEqual(res_sched, base_sched)

        # Invariant 2: Candidate policies produce different budget actions under the same tape
        fixed16_budgets = [d.requested_budget for d in results["fixed16"].controller_logs]
        fixed32_budgets = [d.requested_budget for d in results["best_train_fixed32"].controller_logs]
        self.assertTrue(all(b == 16.0 for b in fixed16_budgets))
        self.assertTrue(all(b == 32.0 for b in fixed32_budgets))

    def test_incomplete_late_and_rejection_accounting(self):
        """Preserves and distinguishes in-window good, late good, pending, rejections, and length caps."""
        # Custom tape with known outcome dynamics
        tape = [
            # 1. In-window good completion (scheduled at 1.0, completes at ~1.2)
            StreamedRequest(
                request_id="req-in-window-good",
                workload_class="stationary",
                scheduled_at=1.0,
                prompt_tokens=128,
                max_tokens=128,
                original_cost=2.0,
                ground_truth_output_tokens=32,
                ground_truth_finish_reason="stop",
                base_service_s=0.1,
            ),
            # 2. Length-capped completion (scheduled at 2.0, finish="length")
            StreamedRequest(
                request_id="req-length-capped",
                workload_class="stationary",
                scheduled_at=2.0,
                prompt_tokens=128,
                max_tokens=128,
                original_cost=2.0,
                ground_truth_output_tokens=32,
                ground_truth_finish_reason="length",
                base_service_s=0.1,
            ),
            # 3. Late good completion (scheduled at 9.8 in a 10s window, completes at ~10.4 during drain)
            StreamedRequest(
                request_id="req-late-good",
                workload_class="stationary",
                scheduled_at=9.8,
                prompt_tokens=128,
                max_tokens=128,
                original_cost=2.0,
                ground_truth_output_tokens=32,
                ground_truth_finish_reason="stop",
                base_service_s=0.1,
            ),
            # 4. Massive cost request to fill reservation ledger to 16.0; output=1 fails output>=2 SLO rule
            StreamedRequest(
                request_id="req-fill-ledger",
                workload_class="stationary",
                scheduled_at=3.0,
                prompt_tokens=128,
                max_tokens=128,
                original_cost=14.0,
                ground_truth_output_tokens=1,  # Fails minimum output tokens >= 2
                ground_truth_finish_reason="stop",
                base_service_s=4.0,  # runs from 3.0 to ~5.0
            ),
            # 5. Overflow request while ledger is 16.0 -> rejected at admission gate
            StreamedRequest(
                request_id="req-rejected-overflow",
                workload_class="stationary",
                scheduled_at=3.2,
                prompt_tokens=128,
                max_tokens=128,
                original_cost=2.0,
                ground_truth_output_tokens=32,
                ground_truth_finish_reason="stop",
                base_service_s=0.1,
            ),
        ]

        harness = ClosedLoopBenchmarkHarness(control_slot_s=1.0, max_drain_duration_s=2.0)
        res = harness.run_episode(tape, PolicyFixed16(), episode_duration_s=10.0)
        summary = res.summary

        # Check primary metric: only req-in-window-good should qualify
        primary = summary["primary_metric"]
        self.assertEqual(primary["in_window_natural_good_count"], 1)
        self.assertEqual(primary["endpoint_classification"], "natural_api_stop")
        self.assertFalse(primary["physical_eos_verified"])

        # Check secondary panels
        secondary = summary["secondary_panels"]
        self.assertEqual(secondary["endpoint_classification"], "natural_api_stop")
        self.assertFalse(secondary["physical_eos_verified"])
        self.assertEqual(secondary["late_good_count"], 1)  # req-late-good
        self.assertEqual(secondary["cohort_good_count"], 2)  # req-in-window-good + req-late-good
        self.assertEqual(secondary["length_capped_count"], 1)  # req-length-capped
        self.assertEqual(secondary["rejected_count"], 1)  # req-rejected-overflow
        self.assertGreater(secondary["rejection_rate"], 0.0)

        # Check controller overhead and offline CPU boundary
        overhead = summary["controller_overhead"]
        self.assertFalse(overhead["active_native_permit"])
        self.assertTrue(res.is_cpu_simulation)
        self.assertFalse(res.active_native_permit)
        self.assertFalse(res.physical_eos_verified)
        self.assertEqual(res.harness_scope, "offline_deterministic_cpu_simulation_not_live_http_gpu")

    def test_genuine_fallback_and_inactive_separation(self):
        """Simulated solver timeout/failure triggers genuine fallback; never disguised as active MPC."""
        tape = generate_workload_tape("stationary", seed=303, duration_s=6.0)
        harness = ClosedLoopBenchmarkHarness(control_slot_s=1.0, max_drain_duration_s=1.0)

        failing_mpc = PolicyRecedingHorizonMPC(simulate_failure=True)
        res = harness.run_episode(tape, failing_mpc, episode_duration_s=6.0)

        logs = res.controller_logs
        self.assertGreater(len(logs), 0)

        # All decisions must be explicitly marked as fallback, active_mpc=False
        for dec in logs:
            self.assertEqual(dec.status, "fallback")
            self.assertEqual(dec.fallback_reason, "simulated_solver_timeout_or_error")
            self.assertFalse(dec.active_mpc)
            self.assertEqual(dec.requested_budget, 16.0)

        overhead = res.summary["controller_overhead"]
        self.assertEqual(overhead["fallback_count"], len(logs))
        self.assertEqual(overhead["active_mpc_decisions"], 0)
        self.assertFalse(overhead["silent_substitution_detected"])

        # Invariant: Attempting to disguise fallback as active_mpc must raise ValueError
        with self.assertRaises(ValueError):
            ControllerDecision(
                decision_time_s=1.0,
                requested_budget=16.0,
                status="fallback",
                active_mpc=True,  # Misleading disguise forbidden
            )

    def test_eight_workload_classes_tape_generation(self):
        """Verify deterministic generation and distinct profiles for all 8 workload classes."""
        for w_class in FINAL_WORKLOAD_CLASSES:
            tape = generate_workload_tape(w_class, seed=404, duration_s=25.0)
            self.assertGreater(len(tape), 0)
            # Determinism check
            tape_repeat = generate_workload_tape(w_class, seed=404, duration_s=25.0)
            self.assertEqual([r.request_id for r in tape], [r.request_id for r in tape_repeat])
            self.assertEqual([r.scheduled_at for r in tape], [r.scheduled_at for r in tape_repeat])

            # Class-specific invariants
            if w_class == "prefill":
                self.assertTrue(all(r.prompt_tokens == 4096 for r in tape))
            elif w_class == "decode":
                self.assertTrue(all(r.ground_truth_output_tokens == 256 for r in tape))
            elif w_class == "unseen":
                self.assertTrue(all(r.prompt_tokens == 2048 for r in tape))
                self.assertTrue(any(r.ground_truth_finish_reason == "length" for r in tape))

        # Check alias resolution
        tape_alias = generate_workload_tape("short_homogeneous", seed=505, duration_s=10.0)
        self.assertEqual(tape_alias[0].workload_class, "stationary")

    def test_preregistered_final_protocol_invariants(self):
        """Verify preregistered Final protocol specification rules, metrics, and lift thresholds."""
        protocol = build_preregistered_final_protocol()

        self.assertIn("protocol_digest", protocol)
        self.assertEqual(len(protocol["protocol_digest"]), 64)
        self.assertEqual(len(protocol["workload_classes"]), 8)
        self.assertEqual(set(protocol["workload_classes"]), set(FINAL_WORKLOAD_CLASSES))

        # Draft status and Mayor sealing invariant
        self.assertEqual(protocol["status"], "draft_unsealed_proposal")
        self.assertFalse(protocol["mayor_sealed_before_final"])

        # Primary metric invariants
        prim = protocol["primary_metric"]
        self.assertEqual(prim["name"], "api_stop_natural_in_window_goodput_per_second")
        self.assertEqual(prim["endpoint_classification"], "natural_api_stop")
        self.assertFalse(prim["physical_eos_verified"])
        self.assertEqual(prim["ttft_threshold_s"], 0.5)
        self.assertEqual(prim["mean_tpot_threshold_s"], 0.05)
        self.assertEqual(prim["minimum_output_tokens"], 2)
        self.assertTrue(prim["natural_eos_only"])
        self.assertTrue(prim["in_window_only"])
        self.assertEqual(prim["per_token_tpot_note"], "per-token TPOT is unavailable on native vLLM; per-request mean TPOT is used")

        # Proposed minimum lift invariant
        rules = protocol["decision_rules"]
        self.assertEqual(rules["proposed_minimum_meaningful_lift_pct"], 5.0)
        self.assertEqual(rules["multiplicity_correction"], "holm_bonferroni_step_down")
        self.assertEqual(rules["block_unit"], "independent arrival/action seedblock")

        # Zero Final leakage invariant
        boundaries = protocol["preregistration_boundaries"]
        self.assertFalse(boundaries["final_data_accessed"])
        self.assertFalse(boundaries["proved_risk_guarantees_asserted"])
        self.assertTrue(boundaries["protocol_frozen_before_final"])
        self.assertEqual(boundaries["protocol_status"], "draft_unsealed_proposal")
        self.assertFalse(boundaries["mayor_sealed_before_final"])


class TestRound9RealPipelineQualification(unittest.TestCase):
    """Round 9 test suite verifying genuine CPU end-to-end control and capture pipeline qualification."""

    @classmethod
    def setUpClass(cls):
        ensure_integration_paths()

    def test_source_or_clock_changed_before_time_comparisons(self):
        """Native state adapter rejects clock domain and run ID changes before evaluating timestamps."""
        from mpc_lab.native_state import estimate_native_state, NativeBinding
        import httpx

        transport = RealPipelineServingTransport()
        client = httpx.Client(transport=httpx.MockTransport(transport), base_url="http://test")
        binding = NativeBinding(
            clock_domain=transport.clock_domain,
            gateway_run_id=transport.gateway_run_id,
            native_run_id=transport.native_run_id,
            observer_sha256=transport.observer_sha256,
            identity=transport.parameters.identity,
        )

        # 1. Normal state passes estimation
        resp = client.get("/native/state").json()
        est_normal = estimate_native_state(resp, binding, now=transport.clock())
        self.assertIsNotNone(est_normal.state)
        self.assertIsNone(est_normal.reason)

        # 2. Clock domain changed before time comparisons
        transport.simulate_clock_mismatch = True
        resp_clock = client.get("/native/state").json()
        est_clock = estimate_native_state(resp_clock, binding, now=transport.clock())
        self.assertIsNone(est_clock.state)
        self.assertEqual(est_clock.reason, "clock_domain_mismatch")

        # 3. Native run ID changed before time comparisons
        transport.simulate_clock_mismatch = False
        transport.simulate_source_mismatch = True
        resp_source = client.get("/native/state").json()
        est_source = estimate_native_state(resp_source, binding, now=transport.clock())
        self.assertIsNone(est_source.state)
        self.assertEqual(est_source.reason, "native_source_mismatch")

        # 4. Harness execution under clock/source mismatch triggers clean fallback without disguising as MPC
        res_mismatch = run_real_pipeline_episode("mpc", transport_override=transport, episode_duration_s=2.0)
        self.assertGreater(len(res_mismatch.controller_logs), 0)
        for dec in res_mismatch.controller_logs:
            self.assertEqual(dec.status, "fallback")
            self.assertFalse(dec.active_mpc)
            self.assertIn("native_source_mismatch", dec.fallback_reason)

    def test_one_pending_operation_blocks_next(self):
        """GuardedActuator pending file fence strictly blocks subsequent commands from overlapping."""
        import tempfile
        from mpc_lab.contracts import SCHEMA, asdict

        with tempfile.TemporaryDirectory() as td:
            pending_dir = Path(td)
            pending_file = pending_dir / "pending.json"
            transport = RealPipelineServingTransport()

            # Pre-populate pending.json with an uncompleted operation
            pending_cmd = {
                "schema": SCHEMA,
                "run_id": transport.gateway_run_id,
                "clock_domain": transport.clock_domain,
                "identity": asdict(transport.parameters.identity),
                "expected_version": 0,
                "operation_id": "op-pending-blocker-1234",
                "budget": 16.0,
                "not_after": transport.clock() + 100.0,
            }
            pending_file.write_text(json.dumps(pending_cmd))

            # Run episode through harness with the pending blocker
            res = run_real_pipeline_episode(
                "mpc",
                transport_override=transport,
                pending_dir=pending_dir,
                episode_duration_s=2.0,
            )
            self.assertGreater(len(res.controller_logs), 0)
            for dec in res.controller_logs:
                self.assertEqual(dec.status, "fallback")
                self.assertFalse(dec.active_mpc)
                self.assertIn("actuator_pending", dec.fallback_reason)

    def test_ttl_expired_recorded_fallback(self):
        """Actuator command TTL expiry returns 409 / stale snapshot and records fallback without silent disguise."""
        transport = RealPipelineServingTransport()
        transport.simulate_ttl_expired = True

        res = run_real_pipeline_episode("mpc", transport_override=transport, episode_duration_s=2.0)
        logs = res.controller_logs
        self.assertGreater(len(logs), 0)
        for dec in logs:
            self.assertEqual(dec.status, "fallback")
            self.assertFalse(dec.active_mpc)
            self.assertIn("actuator_pending", dec.fallback_reason)

        overhead = res.summary["controller_overhead"]
        self.assertEqual(overhead["fallback_count"], len(logs))
        self.assertEqual(overhead["active_mpc_decisions"], 0)
        self.assertFalse(overhead["silent_substitution_detected"])

    def test_partial_sse_rejected_unsent_cancel_and_late_kept(self):
        """Whole offered fate accounting retains fragmented SSE, admission rejections, errors, and late arrivals."""
        import hashlib
        import asyncio

        def mkhex(name: str) -> str:
            return hashlib.sha256(name.encode()).hexdigest()[:32]

        r_normal = mkhex("req-normal")
        r_length = mkhex("req-length")
        r_partial = mkhex("req-partial")
        r_reject = mkhex("req-reject")
        r_error = mkhex("req-error")
        r_late = mkhex("req-late")

        tape = [
            StreamedRequest(r_normal, "stationary", 0.5, 128, 128, 2.0, 32, "stop", 0.1),
            StreamedRequest(r_length, "stationary", 0.6, 128, 128, 2.0, 32, "length", 0.1),
            StreamedRequest(r_partial, "stationary", 0.7, 128, 128, 2.0, 32, "stop", 0.1),
            StreamedRequest(r_reject, "stationary", 0.8, 128, 128, 2.0, 32, "stop", 0.1),
            StreamedRequest(r_error, "stationary", 0.9, 128, 128, 2.0, 32, "stop", 0.1),
            StreamedRequest(r_late, "stationary", 1.9, 128, 128, 2.0, 32, "stop", 0.1),
        ]

        transport = RealPipelineServingTransport()
        transport.mode_overrides[r_partial] = "partial"
        transport.mode_overrides[r_reject] = "reject"
        transport.mode_overrides[r_error] = "error"

        harness = RealPipelineControlHarness()
        res_custom = asyncio.run(
            harness.run_episode(
                PolicyFixed16(),
                tape,
                episode_duration_s=2.0,
                transport_override=transport,
            )
        )
        fates = res_custom.whole_offered_fates
        self.assertEqual(fates["total_offered"], 6)
        self.assertEqual(fates["completed_natural_api_stop"], 2)  # r_normal + r_late
        self.assertEqual(fates["completed_length"], 1)  # r_length
        self.assertEqual(fates["rejected_admission"], 1)  # r_reject
        self.assertEqual(fates["failed_partial_or_error"], 2)  # r_partial + r_error
        self.assertGreaterEqual(fates["late_good"], 1)

    def test_all_five_policies_share_real_pipeline_transport(self):
        """All five matched policies execute over the genuine mock transport and produce sound accounting."""
        policies = ["fixed_16", "best_train_fixed_16_or_32", "reactive", "strong_one_move", "mpc"]
        for p in policies:
            res = run_real_pipeline_episode(p, episode_duration_s=2.0)
            self.assertEqual(res.policy_name, p)
            self.assertEqual(res.harness_scope, "offline_deterministic_cpu_simulation_not_live_http_gpu")
            self.assertFalse(res.active_native_permit)
            self.assertFalse(res.physical_eos_verified)
            self.assertGreater(len(res.records), 0)
            self.assertGreater(len(res.controller_logs), 0)
            self.assertIn("api_stop_natural_in_window_goodput_per_second", res.summary["primary_metric"]["name"])


class TestRound10PortabilityAndSolR9Qualification(unittest.TestCase):
    """Round 10 tests: ABI portability, Sol R9 metadata/cut adapter, missing-lineage refusal, and simulate_plan witness."""

    def test_abi_portability_sanitizes_foreign_site_packages(self):
        """Sanitizer rejects foreign ABI site-packages and preserves current ABI."""
        curr_ver = f"{sys.version_info.major}.{sys.version_info.minor}"
        foreign_ver = "3.12" if curr_ver != "3.12" else "3.14"

        foreign_path = f"/custom/venv/lib/python{foreign_ver}/site-packages"
        native_path = f"/custom/venv/lib/python{curr_ver}/site-packages"

        self.assertTrue(is_foreign_abi_site_packages(foreign_path))
        self.assertFalse(is_foreign_abi_site_packages(native_path))

        # Test that ensure_integration_paths purges foreign path if injected into sys.path
        sys.path.append(foreign_path)
        self.assertIn(foreign_path, sys.path)
        ensure_integration_paths()
        self.assertNotIn(foreign_path, sys.path)

    def test_sol_r9_metadata_and_registration_v2(self):
        """Sol R9 prospective registration accepts valid public_metadata and rejects mismatches."""
        from native_experiment_audit import CaptureReceiptBridge

        clock = time.monotonic
        bridge = CaptureReceiptBridge(
            publisher_run_id="a" * 32,
            observer_run_id="b" * 32,
            clock_domain="test-domain",
            publisher_clock=clock,
            observer_clock=clock,
        )

        valid_meta = {
            "schema": "native-v3-public-payload-v1",
            "requested_max_tokens": 64,
            "prompt_class": "short",
            "prompt_token_estimate": 128,
            "source_sha256": "c" * 64,
            "prompt_estimator_sha256": "d" * 64,
        }
        rid = "0" * 31 + "1"
        bridge.register(
            rid,
            0.0,
            original_offered_estimate=1.0,
            estimate_provenance={"source_sha256": "e" * 64},
            public_metadata=valid_meta,
        )

        # Confirm published with REGISTRATION_V2
        cut = bridge.cut(clock())
        req = next(r for r in cut["requests"] if r["request_id"] == rid)
        self.assertEqual(req["registration_schema"], "native-v3-offered-registration-v2")
        self.assertEqual(req["public_metadata"]["requested_max_tokens"], 64)

        # Invalid metadata (missing field or wrong schema) must raise ValueError
        invalid_meta = dict(valid_meta, schema="invalid-schema")
        with self.assertRaises(ValueError):
            bridge.register(
                "0" * 31 + "2",
                0.1,
                original_offered_estimate=1.0,
                estimate_provenance={"source_sha256": "e" * 64},
                public_metadata=invalid_meta,
            )

    def test_sol_r9_cut_adapter_refuses_v5_input_missing_lineage(self):
        """OnlineModelInputAdapter seals cut with supported V1/V2 schema, v5_input=None, all 5 refusal reasons, and active_mpc_permit=False."""
        from mpc_lab.native_state import NativeBinding
        from mpc_lab.contracts import ModelParameters
        from native_experiment_audit import CaptureReceiptBridge, OnlineModelInputAdapter

        clock = time.monotonic
        bridge = CaptureReceiptBridge(
            publisher_run_id="a" * 32,
            observer_run_id="b" * 32,
            clock_domain="test-domain",
            publisher_clock=clock,
            observer_clock=clock,
        )
        binding = NativeBinding(
            clock_domain="test-domain",
            gateway_run_id="g" * 32,
            native_run_id="n" * 32,
            observer_sha256="c" * 64,
            identity=ModelParameters().identity,
        )
        adapter = OnlineModelInputAdapter(bridge, binding, clock=clock)
        cut = adapter.cut(clock())

        # Test consumer's source-bound advertised supported V2 lineage schema and actual refusals against Sol R10 (with R9 V1 compatibility)
        self.assertEqual(cut["schema"], OnlineModelInputAdapter.SCHEMA)
        self.assertIn(cut["schema"], ("native-v3-online-model-input-v1", "native-v3-online-model-input-v2"))
        self.assertIsNone(cut["v5_input"])
        self.assertFalse(cut["active_mpc_permit"])
        self.assertIn(
            cut["request_lineage"],
            ("unverified_no_namespace_joins", "source_contract_client_gateway_only_native_unverified"),
        )

        expected_refusals = [
            "verified_engine_gateway_client_lineage_missing",
            "pending_original_gateway_charge_unknown",
            "all_offered_completeness_and_v5_arrival_law_unqualified",
            "cell_payload_cost_table_and_prompt_estimator_transfer_unqualified",
            "planned_assignment_ACK_compliance_and_plan_support_unqualified",
        ]
        self.assertEqual(cut["v5_refusals"], expected_refusals)

    def test_pinned_sol_r9_adapter_v1_schema_contract(self):
        """Explicitly pin and verify Sol R9 frozen module schema v1 contract in isolation."""
        r9_path = Path("/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-round9-frozen/sol/native_experiment_audit.py")
        if not r9_path.exists():
            self.skipTest("Frozen Sol R9 path unavailable")
        import importlib.util
        spec = importlib.util.spec_from_file_location("sol_r9_audit_pinned", str(r9_path))
        r9_mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(r9_mod)
        self.assertEqual(r9_mod.OnlineModelInputAdapter.SCHEMA, "native-v3-online-model-input-v1")

    def test_mpc_policy_explicitly_falls_back_when_v5_input_refused(self):
        """When v5_input is refused, MPC policy records fallback without masquerading as active MPC."""
        res = run_real_pipeline_episode("mpc", episode_duration_s=2.0)
        self.assertEqual(res.policy_name, "mpc")
        self.assertFalse(res.active_native_permit)
        self.assertIsNone(res.v5_input)
        self.assertIn("verified_engine_gateway_client_lineage_missing", res.v5_refusals)

        # Every MPC decision must be recorded as fallback with explicit refusal reason
        for decision in res.controller_logs:
            self.assertEqual(decision.status, "fallback")
            self.assertFalse(decision.active_mpc)
            self.assertTrue(decision.fallback_reason.startswith("v5_input_refused:"))

    def test_simulate_plan_fixed_crn_causal_non_interference_witness(self):
        """Executable witness proves cohort and earlier-birth service non-interference in frozen simulate_plan."""
        witness = run_simulate_plan_causal_interference_witness()
        self.assertEqual(witness.schema, "native-v3-simulate-plan-witness-v1")
        self.assertTrue(witness.cohort_invariance)
        self.assertTrue(witness.earlier_birth_invariance)
        self.assertEqual(witness.live_cohort_delay_s, 0.0)
        self.assertEqual(witness.earlier_birth_delay_s, 0.0)
        self.assertIn("marked renewal", witness.interpretation)
        self.assertIn("Minimal observable batch-aware", witness.gap_specification)


class TestRound11BatchAwareTransitionAndPreregistration(unittest.TestCase):
    """Round 11: Batch-aware dynamic hazard transition, executable causal witness, and preregistration."""

    def test_minimal_observable_batch_state_and_unknowns(self):
        """MinimalObservableBatchState captures physical observables, explicit guards, and unknown flags."""
        b_state = MinimalObservableBatchState(
            timestamp_s=10.0,
            running_count=8,
            waiting_count=None,
            prefill_count=2,
            decode_count=6,
            kv_cache_usage=0.25,
            active_cost=None,
            accepted_not_visible_count=1,
            state_qualification="unqualified_surrogate",
        )
        self.assertEqual(b_state.running_count, 8)
        self.assertEqual(b_state.decode_count, 6)
        self.assertIsNone(b_state.waiting_count)
        self.assertIsNone(b_state.active_cost)
        self.assertEqual(b_state.observability_guards["waiting_count"], "unobserved_at_native_frame")
        self.assertEqual(b_state.observability_guards["active_cost"], "gateway_cost_unjoined")
        self.assertTrue(b_state.unknown_flags["scheduler_queue_depth_unknown"])
        self.assertTrue(b_state.unknown_flags["physical_native_eos_unknown"])
        self.assertTrue(b_state.unknown_flags["client_gateway_lineage_unverified"])

    def test_batch_aware_hazard_transition_service_rate_contention(self):
        """Service rate decreases monotonically with concurrent decode and prefill population."""
        model = BatchAwareHazardTransitionModel(
            base_decode_rate=66.987,
            gamma_decode=0.035,
            gamma_prefill=6.9944,
            gamma_kv=1.1156,
        )

        state_uncontended = MinimalObservableBatchState(
            timestamp_s=0.0, running_count=1, waiting_count=None, prefill_count=0,
            decode_count=1, kv_cache_usage=0.01, active_cost=None,
        )
        state_contended = MinimalObservableBatchState(
            timestamp_s=0.0, running_count=8, waiting_count=None, prefill_count=2,
            decode_count=6, kv_cache_usage=0.15, active_cost=None,
        )

        r_iso, _ = model.compute_service_rates(state_uncontended)
        r_contended, _ = model.compute_service_rates(state_contended)

        self.assertLess(r_contended, r_iso)
        # Prefill and decode contention causes massive reduction in decode speed
        self.assertGreater(r_iso - r_contended, 40.0)

    def test_fractional_prefill_accumulation_regression(self):
        """Regression test for 7c3b209: float accumulation prevents fractional progress stall at small dt."""
        dt = 0.0001
        rate = 1800.0

        # Flawed 7c3b209 integer truncation: int(rate * dt) = int(0.18) = 0 (stalls completely)
        int_prog = 0
        for _ in range(100):
            int_prog += int(rate * dt)
        self.assertEqual(int_prog, 0, "Flawed integer truncation stalls at 0 progress")

        # Repaired continuous float accumulation
        model = BatchAwareHazardTransitionModel(base_prefill_chunk_rate=rate)
        req = BatchAwareRequestState(
            request_id="test_req",
            prompt_tokens=100,
            max_tokens=100,
            computed_tokens=0.0,
            phase="prefill",
        )
        active = [req]
        for _ in range(100):
            active, _, _ = model.step(0.0, dt, active, candidate_budget=32.0, incoming_offers=[])

        self.assertGreater(active[0].computed_tokens, 10.0, "Continuous float accumulation advances smoothly")
        self.assertAlmostEqual(active[0].computed_tokens, 17.88, places=1)

    def test_batch_aware_causal_interference_witness_proves_cohort_delay(self):
        """Executable fixed-CRN witness confirms later admitted requests causally delay already-live cohort."""
        witness = run_batch_aware_causal_interference_witness()
        self.assertEqual(witness.schema, "native-v3-batch-aware-causal-interference-witness-v1")
        self.assertTrue(witness.proves_causal_interference)
        self.assertGreater(witness.causal_delay_delta_s, 0.0)
        self.assertEqual(witness.frozen_simulate_plan_delta_s, 0.0)
        self.assertTrue(witness.admission_to_population_to_service_strictly)
        self.assertFalse(witness.http_serial_gpu_service)
        self.assertFalse(witness.future_eos_used)
        self.assertGreater(witness.plan_b_delay_s, witness.plan_a_delay_s)

    def test_used_train_progress_diagnostic_execution_or_blocker(self):
        """Progress diagnostic on USED data executes on common mask with honest censoring and baselines."""
        diag = run_used_train_progress_diagnostic(max_episodes=2)
        self.assertEqual(diag["schema"], "native-v3-train-progress-diagnostic-v2")
        self.assertIn(diag["status"], ("success", "data_interface_blocker"))

        if diag["status"] == "success":
            self.assertIn("0.15s", diag["horizons"])
            self.assertIn("0.25s", diag["horizons"])
            h1 = diag["horizons"]["0.15s"]
            self.assertGreater(h1["surviving_samples"], 0)
            self.assertGreater(h1["censored_samples"], 0)
            self.assertGreater(h1["censoring_rate"], 0.0)
            self.assertLess(h1["batch_aware_mae"], h1["causal_past_baseline_mae"])
            self.assertIn("batch_vs_causal_past_reduction_pct", h1)
            self.assertEqual(h1["forecast_type"], "frozen_state_horizon_rate_forecast")
            self.assertIn("causal_baseline_definition", diag)
            self.assertIn("oracle_reference_definition", diag)
            self.assertIn("censoring_handling", diag)

    def test_fitted_parameters_train13(self):
        """fit_batch_aware_hazard_model_on_train13 estimates empirical parameters across USED Train 1-3."""
        params = fit_batch_aware_hazard_model_on_train13()
        self.assertGreater(params.base_decode_rate, 50.0)
        self.assertLess(params.base_decode_rate, 85.0)
        self.assertGreater(params.gamma_prefill, 1.0)
        self.assertGreater(params.gamma_kv, 0.5)
        self.assertGreater(params.base_prefill_chunk_rate, 1000.0)
        self.assertGreater(params.n_decode_samples, 100000)

    def test_train1213_forecast_pilot_protocol_and_closed_loop_draft(self):
        """Preregistration separates Train 12/13 forecast pilot from unsealed closed-loop draft."""
        pilot = Train1213IdentificationForecastPilotProtocol()
        self.assertEqual(pilot.schema, "native-v3-train1213-forecast-pilot-protocol-v1")
        self.assertEqual(pilot.architecture, "identification_prescheduled_5_cells_2_arms")
        self.assertEqual(pilot.target_primary_metric, "surviving_pair_progress_mae_common_mask")
        self.assertEqual(pilot.comparator_baseline, "train_fitted_causal_past_rate")
        self.assertEqual(pilot.censoring_accounting, "right_censored_at_frame_boundary")
        self.assertFalse(pilot.active_mpc_permit_granted)
        self.assertIn("prescheduled identification blocks", pilot.gating_statement)

        draft = ClosedLoopBenchmarkHarnessProtocolDraft()
        self.assertEqual(draft.schema, "native-v3-closed-loop-benchmark-protocol-draft-v1")
        self.assertEqual(draft.status, "unsealed_draft")
        self.assertEqual(draft.target_primary_metric, "api_stop_natural_in_window_goodput_per_second")
        self.assertEqual(draft.minimum_meaningful_lift_margin, 0.05)
        self.assertEqual(len(draft.workload_families), 8)
        self.assertFalse(draft.active_mpc_permit_granted)

    def test_erratum_r11_commit_7c3b209_documented(self):
        """All 7 audit errata on commit 7c3b209 are explicitly documented and disclosed."""
        from native_campaign_protocol import ERRATUM_R11_COMMIT_7C3B209
        self.assertEqual(ERRATUM_R11_COMMIT_7C3B209["audit_status"], "disclosed_erratum_repaired_in_local_source")
        for i in range(1, 8):
            key = [k for k in ERRATUM_R11_COMMIT_7C3B209 if k.startswith(f"erratum_{i}_")][0]
            self.assertIn(key, ERRATUM_R11_COMMIT_7C3B209)


class TestControlledCohortIdentificationProtocolAndHarness(unittest.TestCase):
    """Controlled-cohort identification protocol and CPU mock harness tests."""

    def test_protocol_predeclared_invariants(self):
        """Protocol pre-declares all identification invariants, gates, and non-permit status."""
        proto = ControlledCohortIdentificationProtocol()
        self.assertEqual(proto.schema, "native-v3-controlled-cohort-identification-protocol-v3")
        self.assertEqual(proto.geometry_name, "sufficient_lived_5x512")
        self.assertIn("Future prefill admission causally alters", proto.hypothesis)
        self.assertEqual(proto.initial_drain_s, 5.0)
        self.assertEqual(proto.initial_budget, 32.0)
        self.assertEqual(proto.anchor_cohort_count, 5)
        self.assertEqual(proto.anchor_prompt_tokens, 128)
        self.assertEqual(proto.anchor_max_tokens, 512)
        self.assertAlmostEqual(proto.anchor_cost_per_request, 3.0226906666666667, places=6)
        self.assertAlmostEqual(proto.total_anchor_cost, 15.113453333333334, places=6)
        self.assertTrue(proto.anchor_ignore_eos)
        self.assertIn("IDENTIFICATION ONLY", proto.identification_only_semantics)
        self.assertEqual(proto.predeclared_gate, "anchor_decode_ready_gate")
        self.assertEqual(proto.post_gate_assigned_budget_arm_a, 16.0)
        self.assertEqual(proto.post_gate_assigned_budget_arm_b, 32.0)
        self.assertEqual(proto.burst_request_count, 4)
        self.assertEqual(proto.burst_prompt_tokens, 4096)
        self.assertEqual(proto.burst_max_tokens, 128)
        self.assertAlmostEqual(proto.burst_cost_per_request, 4.0304346624, places=6)
        self.assertAlmostEqual(proto.total_burst_cost, 16.1217386496, places=6)

        # Capacity discrimination check
        self.assertGreater(proto.total_anchor_cost + proto.burst_cost_per_request, proto.post_gate_assigned_budget_arm_a)
        self.assertLessEqual(proto.total_anchor_cost + proto.total_burst_cost, proto.post_gate_assigned_budget_arm_b)

        self.assertEqual(proto.actuator_ttl_ms, 100.0)
        self.assertTrue(proto.actuator_cas_required)
        self.assertTrue(proto.pending_fence_enforced)
        self.assertEqual(proto.tracking_id_scheme, "raw_native_id_preassigned_closed_set")
        self.assertIn("unjoined_opaque_engine_ids", proto.lineage_refusal_reason)
        self.assertIn("all_running_ids_at_preassignment_gate", proto.aggregate_cohort_provenance)
        self.assertEqual(proto.primary_estimand, "itt_paired_anchor_output_token_progress")
        self.assertEqual(proto.evaluation_window_s, 1.0)
        self.assertFalse(proto.active_mpc_permit_granted)
        self.assertIn("NOT for benchmark victory", proto.gating_statement)

        # Legacy 9x256 protocol verification
        legacy_proto = create_legacy_9x256_protocol()
        self.assertEqual(legacy_proto.geometry_name, "legacy_9x256")
        self.assertEqual(legacy_proto.anchor_cohort_count, 9)
        self.assertEqual(legacy_proto.anchor_prompt_tokens, 128)
        self.assertEqual(legacy_proto.anchor_max_tokens, 256)
        self.assertAlmostEqual(legacy_proto.anchor_cost_per_request, 1.6893573248, places=6)
        self.assertAlmostEqual(legacy_proto.total_anchor_cost, 15.2042159232, places=6)

    def test_controlled_cohort_harness_falsifies_fixed_mark_invariance(self):
        """CPU mock harness executes Arm A vs Arm B and demonstrates mock-plant falsification of fixed-mark invariance."""
        res = run_controlled_cohort_identification_harness()
        self.assertEqual(res.schema, "native-v3-controlled-cohort-identification-receipt-v2")
        self.assertEqual(res.arm_a_assigned_budget, 16.0)
        self.assertEqual(res.arm_b_assigned_budget, 32.0)
        self.assertEqual(len(res.raw_native_anchor_ids), 5)

        # Explicit evidence scope: CPU mock only, physical Native hardware hypothesis UNTESTED
        self.assertEqual(res.evidence_scope, "cpu_mock_pipeline_witness_not_hardware_truth")
        self.assertEqual(res.native_hardware_hypothesis_status, "UNTESTED_requires_mayor_native_pilot")

        # Arm A (uncontended decode): anchors progress significantly in mock simulation
        self.assertGreater(res.arm_a_anchor_mean_progress, 50.0)
        # Arm B (prefill-contended decode): anchors progress is slowed drastically in mock simulation
        self.assertLess(res.arm_b_anchor_mean_progress, 20.0)

        # Delta is strictly negative in mock simulation
        self.assertLess(res.mock_observed_progress_delta, -40.0)
        self.assertEqual(res.observed_progress_delta, res.mock_observed_progress_delta)

        # Fixed-mark renewal models predict Delta == 0.0 identically (proved structural property in code)
        self.assertEqual(res.fixed_mark_predicted_delta, 0.0)
        self.assertTrue(res.fixed_mark_mock_plant_invariance_falsified)
        self.assertTrue(res.fixed_mark_invariance_falsified)
        self.assertIn("NOT an observed GPU effect", res.interpretation)

    def test_strict_raw_native_id_tracking_and_no_client_uuid_guessing(self):
        """Anchors must be tracked strictly by preassigned closed-set RawNativeIDs without client UUID guessing."""
        res = run_controlled_cohort_identification_harness()
        expected_ids = tuple(f"anchor_native_req_{i:02d}" for i in range(5))
        self.assertEqual(res.raw_native_anchor_ids, expected_ids)
        self.assertEqual(tuple(res.arm_a_anchor_progress.keys()), expected_ids)
        self.assertEqual(tuple(res.arm_b_anchor_progress.keys()), expected_ids)

        for rid in res.raw_native_anchor_ids:
            self.assertTrue(rid.startswith("anchor_native_req_"))
            self.assertNotIn("-", rid[18:])  # No UUID hyphenated parts

    def test_itt_preservation_and_burst_fates_accounting(self):
        """Harness preserves ITT and records all burst fates without dropping rejections."""
        res = run_controlled_cohort_identification_harness()
        self.assertTrue(res.itt_preserved)

        # Arm A rejects all 4 burst requests (capacity 16.0 fully occupied by 9 anchors)
        self.assertEqual(res.arm_a_burst_rejections, 4)
        self.assertEqual(res.arm_a_burst_admissions, 0)

        # Arm B admits all 4 burst requests (capacity 32.0 accommodates anchors + burst)
        self.assertEqual(res.arm_b_burst_rejections, 0)
        self.assertEqual(res.arm_b_burst_admissions, 4)

        # Verify all fates dict retains full accounts for both arms
        self.assertIn("arm_a", res.all_fates_recorded)
        self.assertIn("arm_b", res.all_fates_recorded)
        self.assertEqual(res.all_fates_recorded["arm_a"]["burst_fate"], "all_rejected_capacity_exceeded")
        self.assertEqual(res.all_fates_recorded["arm_b"]["burst_fate"], "all_admitted_contention_induced")

    def test_actuator_compliance_and_cas_ttl_recording(self):
        """Actuator mechanics record 100ms TTL, CAS delay, and pending fence enforcement."""
        res = run_controlled_cohort_identification_harness()
        act_a = res.actuator_compliance_arm_a
        act_b = res.actuator_compliance_arm_b

        self.assertEqual(act_a["ttl_ms"], 100.0)
        self.assertFalse(act_a["expired"])
        self.assertTrue(act_a["ack_success"])
        self.assertFalse(act_a["pending_fence_held"])

        self.assertEqual(act_b["ttl_ms"], 100.0)
        self.assertFalse(act_b["expired"])
        self.assertTrue(act_b["ack_success"])
        self.assertFalse(act_b["pending_fence_held"])


class TestRealNativeCohortRunnerAndHttpPipeline(unittest.TestCase):
    """Real HTTP/Native runner and pipeline qualification tests."""

    def test_real_native_cohort_pipeline_paired_execution(self):
        """Real HTTP runner executes paired Arm A vs Arm B over genuine MockTransport endpoints."""
        res = asyncio.run(run_real_native_cohort_pipeline())
        self.assertEqual(res.schema, "native-v3-real-native-cohort-paired-receipt-v2")
        self.assertEqual(res.arm_a_receipt.assigned_budget, 16.0)
        self.assertEqual(res.arm_b_receipt.assigned_budget, 32.0)
        self.assertEqual(res.arm_a_receipt.anchor_count, 5)
        self.assertEqual(res.arm_b_receipt.anchor_count, 5)

        # Check exact runtime-sourced CostSpec arithmetic (5x512 geometry)
        self.assertAlmostEqual(res.arm_a_receipt.anchor_cost_per_request, 3.0226906666666667, places=6)
        self.assertAlmostEqual(res.arm_a_receipt.total_anchor_cost, 15.113453333333334, places=6)
        self.assertAlmostEqual(res.arm_a_receipt.burst_cost_per_request, 4.0304346624, places=6)
        self.assertAlmostEqual(res.arm_a_receipt.total_burst_cost, 16.1217386496, places=6)

        # Arm A rejects all 4 burst requests (15.1135 + 4.0304 > 16.0)
        self.assertEqual(res.arm_a_receipt.burst_rejections, 4)
        self.assertEqual(res.arm_a_receipt.burst_admissions, 0)
        for resp in res.arm_a_receipt.burst_responses:
            self.assertEqual(resp["status_code"], 503)

        # Arm B admits all 4 burst requests (15.1135 + 16.1217 <= 32.0)
        self.assertEqual(res.arm_b_receipt.burst_rejections, 0)
        self.assertEqual(res.arm_b_receipt.burst_admissions, 4)
        for resp in res.arm_b_receipt.burst_responses:
            self.assertEqual(resp["status_code"], 200)

        # Contention slows down anchor progress in Arm B relative to Arm A
        self.assertGreater(res.arm_a_mean_progress, 50.0)
        self.assertLess(res.arm_b_mean_progress, 20.0)
        self.assertLess(res.runner_observed_progress_delta, -40.0)

        # Invariant checks
        self.assertTrue(res.itt_preserved)
        self.assertTrue(res.lineage_refusal_enforced)
        self.assertTrue(res.aggregate_provenance_verified)
        self.assertTrue(res.ignore_eos_forwarding_verified)
        self.assertTrue(res.censoring_bounds_enforced)
        self.assertTrue(res.forced_outputs_labeled)

        # R13 features: Sufficient lifetime, Gateway UUID rewrite, no retry
        self.assertTrue(res.arm_a_receipt.sufficient_lifetime_verified)
        self.assertFalse(res.arm_a_receipt.early_completion_hazard_detected)
        self.assertTrue(res.arm_b_receipt.sufficient_lifetime_verified)
        self.assertFalse(res.arm_b_receipt.early_completion_hazard_detected)
        self.assertTrue(res.arm_a_receipt.gateway_uuid_rewrite_verified)
        self.assertTrue(res.arm_a_receipt.no_retry_enforced)

        # Evidence scope verification (preserves R13 mock and retracts deployable claims)
        self.assertEqual(res.evidence_scope, "r13_cpu_mock_pipeline_witness_not_live_adapter")
        self.assertEqual(res.native_hardware_status, "UNTESTED_requires_mayor_native_pilot")
        self.assertEqual(res.arm_a_receipt.evidence_scope, "r13_cpu_mock_pipeline_witness_not_live_adapter")
        self.assertTrue(res.arm_a_receipt.forced_outputs_never_goodput)

    def test_real_cohort_transport_cas_ttl_and_clock_guards(self):
        """Transport enforces CAS expected_version, 100ms TTL, and clock domain matching."""
        transport = RealNativeCohortTransport(simulate_cas_mismatch=True)
        client = httpx.AsyncClient(transport=transport, base_url="http://real-native-cohort.local")

        async def _test():
            # CAS mismatch
            resp = await client.post("/admin/mpc/budget", json={
                "operation_id": "op_test",
                "run_id": transport.gateway_run_id,
                "clock_domain": transport.clock_domain,
                "expected_version": 999,
                "budget": 16.0,
                "not_after": 1000.0,
            })
            self.assertEqual(resp.status_code, 409)
            self.assertIn("cas_version_mismatch", resp.text)

            # TTL expiration
            t_expired = RealNativeCohortTransport(simulate_ttl_expired=True)
            c_expired = httpx.AsyncClient(transport=t_expired, base_url="http://real-native-cohort.local")
            resp_ttl = await c_expired.post("/admin/mpc/budget", json={
                "operation_id": "op_test",
                "run_id": t_expired.gateway_run_id,
                "clock_domain": t_expired.clock_domain,
                "expected_version": 1,
                "budget": 16.0,
                "not_after": 0.0,
            })
            self.assertEqual(resp_ttl.status_code, 409)
            self.assertIn("command_ttl_expired", resp_ttl.text)

            # Clock domain mismatch
            resp_clk = await client.post("/admin/mpc/budget", json={
                "operation_id": "op_test",
                "run_id": transport.gateway_run_id,
                "clock_domain": "wrong-domain",
                "expected_version": 1,
                "budget": 16.0,
                "not_after": 1000.0,
            })
            self.assertEqual(resp_clk.status_code, 409)
            self.assertIn("clock_domain_or_run_id_mismatch", resp_clk.text)

            await client.aclose()
            await c_expired.aclose()

        asyncio.run(_test())

    def test_real_cohort_runner_censoring_on_disappeared_and_counter_reset(self):
        """When anchor requests disappear or counters reset, runner records honest censoring with bounds."""
        proto = ControlledCohortIdentificationProtocol()
        runner = RealNativeCohortRunner(protocol=proto)

        # Fault injection: raw engine id 2 disappears, raw engine id 3 resets counter to 0 (after gate)
        target_missing_raw_id = "chatcmpl-engine-0002"
        target_reset_raw_id = "chatcmpl-engine-0003"

        transport = RealNativeCohortTransport(
            initial_budget=32.0,
            missing_native_id=target_missing_raw_id,
            reset_native_id=target_reset_raw_id,
            missing_after_s=6.0,  # Disappears post-gate during evaluation window
            reset_after_s=6.0,    # Resets post-gate during evaluation window
        )

        receipt = asyncio.run(runner.run_arm("arm_test_fault", 16.0, transport))

        self.assertEqual(receipt.censored_count, 2)
        fates = receipt.anchor_fates

        # Check disappeared request
        matched_missing = [k for k in fates if target_missing_raw_id in k][0]
        self.assertEqual(fates[matched_missing]["status"], "censored_disappeared")
        self.assertEqual(fates[matched_missing]["censor_bounds"], (0, proto.anchor_max_tokens - fates[matched_missing]["start_output"]))

        # Check reset counter request
        matched_reset = [k for k in fates if target_reset_raw_id in k][0]
        self.assertEqual(fates[matched_reset]["status"], "censored_counter_reset")
        self.assertEqual(fates[matched_reset]["censor_bounds"], (0, proto.anchor_max_tokens - fates[matched_reset]["start_output"]))

    def test_lineage_refusal_and_aggregate_provenance_contract(self):
        """Runner enforces explicit 1-to-1 client-engine lineage refusal and aggregate closed cohort provenance."""
        proto = ControlledCohortIdentificationProtocol()
        runner = RealNativeCohortRunner(protocol=proto)
        transport = RealNativeCohortTransport(initial_budget=32.0)

        receipt = asyncio.run(runner.run_arm("arm_lineage", 16.0, transport))

        self.assertEqual(
            receipt.lineage_refusal_reason,
            "unjoined_opaque_engine_ids_require_native_creation_assignment_provenance",
        )
        self.assertEqual(
            receipt.aggregate_cohort_provenance,
            "all_running_ids_at_preassignment_gate_after_verified_drain",
        )
        self.assertEqual(len(receipt.preassigned_raw_native_ids), 5)
        for rid in receipt.preassigned_raw_native_ids:
            self.assertTrue(rid.startswith("chatcmpl-engine-"))
            self.assertNotIn("-client_req_", rid)  # No client UUID suffix guessing

    def test_sufficient_lived_geometry_hazard_counterexample(self):
        """Counterexample: legacy 9x256 suffers premature completion under slow ACK lag, whereas 5x512 safely survives."""
        # 1. Legacy 9x256 under slow ACK lag (3.5s delay simulates slow ACK / network scheduling lag)
        legacy_proto = create_legacy_9x256_protocol()
        legacy_runner = RealNativeCohortRunner(protocol=legacy_proto)
        legacy_transport = RealNativeCohortTransport(initial_budget=32.0, cas_ack_delay_s=3.5)

        legacy_receipt = asyncio.run(legacy_runner.run_arm("arm_legacy_slow_ack", 16.0, legacy_transport))
        self.assertTrue(legacy_receipt.early_completion_hazard_detected)
        self.assertFalse(legacy_receipt.sufficient_lifetime_verified)
        self.assertGreater(legacy_receipt.actual_pre_apply_lag_s, 1.84)
        # Verify that at apply time, remaining tokens dropped below evaluation demand
        min_rem = min(legacy_receipt.remaining_tokens_at_apply.values())
        self.assertLess(min_rem, 90)

        # 2. Sealed 5x512 under same slow ACK lag (3.5s)
        sealed_proto = create_sufficient_lived_5x512_protocol()
        sealed_runner = RealNativeCohortRunner(protocol=sealed_proto)
        sealed_transport = RealNativeCohortTransport(initial_budget=32.0, cas_ack_delay_s=3.5)

        sealed_receipt = asyncio.run(sealed_runner.run_arm("arm_sealed_slow_ack", 16.0, sealed_transport))
        self.assertFalse(sealed_receipt.early_completion_hazard_detected)
        self.assertTrue(sealed_receipt.sufficient_lifetime_verified)
        min_rem_sealed = min(sealed_receipt.remaining_tokens_at_apply.values())
        self.assertGreater(min_rem_sealed, 90)

    def test_parent_adapter_pr33_cohort_tag_sampling_and_gateway_uuid_rewrite(self):
        """Verify Gateway rewrites pr33_gateway_request_id while preserving pr33_cohort_id, sampled by observer."""
        proto = create_sufficient_lived_5x512_protocol()
        runner = RealNativeCohortRunner(protocol=proto)
        transport = RealNativeCohortTransport(initial_budget=32.0)

        receipt = asyncio.run(runner.run_arm("arm_tag_test", 16.0, transport))
        self.assertTrue(receipt.gateway_uuid_rewrite_verified)
        self.assertIsNotNone(receipt.cohort_tag)
        self.assertEqual(len(receipt.cohort_tag), 32)  # 32-hex UUID

        # Source 144: Gateway sets pr33_gateway_request_id to validated client UUID; all tags match client IDs
        for r in transport.active_requests.values():
            self.assertEqual(r["cohort_id"], receipt.cohort_tag)
            self.assertEqual(r["gateway_request_id"], r["client_request_id"])
            self.assertEqual(len(r["gateway_request_id"]), 32)

    def test_parent_adapter_typed_error_stage_and_no_retry(self):
        """Verify HTTP capture records typed errors ('admission_capacity_exceeded', 'response_headers') with no retry."""
        proto = create_sufficient_lived_5x512_protocol()
        runner = RealNativeCohortRunner(protocol=proto)
        transport = RealNativeCohortTransport(initial_budget=16.0)  # Low budget ensures immediate rejection

        receipt = asyncio.run(runner.run_arm("arm_typed_err", 16.0, transport))
        self.assertTrue(receipt.no_retry_enforced)
        self.assertEqual(receipt.burst_rejections, 4)
        for resp in receipt.burst_responses:
            self.assertEqual(resp["status_code"], 503)
            self.assertEqual(resp.get("capture_error_type"), "admission_capacity_exceeded")
            self.assertEqual(resp.get("capture_error_stage"), "response_headers")


class TestLiveNativeCohortAdapterAndRuntimeRepair(unittest.TestCase):
    """Round 14 tests: Production Live Native Adapter and Runtime Repairs."""

    def test_source_144_facts_and_r13_mock_retraction(self):
        """Verifies Source 144 ground truth baseline facts and explicit retraction of R13 deployable claims."""
        facts = SOURCE_144_ACTUAL_FACTS
        self.assertEqual(facts["total_offered"], 922)
        self.assertEqual(facts["completed"], 649)
        self.assertEqual(facts["rejected"], 273)
        self.assertEqual(facts["known_uuid_matches"], 3346)
        self.assertFalse(facts["baseline_ignore_eos"])
        self.assertEqual(facts["hardware_ignore_eos_probe"], "PENDING_REQUIRES_MAYOR_NATIVE_PILOT")
        self.assertTrue(facts["gateway_tag_matches_client"])
        self.assertTrue(facts["all_assigned_failures_and_censors_retained"])
        self.assertTrue(facts["retraction_of_r13_deployable_claims"])
        self.assertEqual(facts["r13_scope"], "r13_cpu_mock_pipeline_witness_not_live_adapter")

    def test_mock_plant_completes_at_max_tokens_even_with_ignore_eos(self):
        """Mock plant request at output_tokens >= max_tokens MUST complete even if ignore_eos=True."""
        transport = LiveNativeServingTransport(initial_budget=32.0)
        client_rid = "test_max_completion"
        transport.active_requests[client_rid] = {
            "client_request_id": client_rid,
            "gateway_request_id": client_rid,
            "raw_engine_id": "engine_test_01",
            "prompt_tokens": 128,
            "max_tokens": 256,
            "cost": 1.68,
            "admitted_at": transport.clock(),
            "phase": "decode",
            "computed_tokens": 128.0,
            "output_tokens_float": 255.0,
            "output_tokens": 255,
            "ignore_eos": True,
        }
        transport.clock_offset += 1.0
        transport._update_progress(transport.clock())
        req = transport.active_requests[client_rid]
        self.assertEqual(req["output_tokens"], 256)
        self.assertEqual(req["phase"], "completed")

    def test_gateway_writes_same_client_uuid_and_smoke_match(self):
        """Gateway validates x-benchmark-request-id and writes same UUID to pr33_gateway_request_id matching smoke."""
        transport = LiveNativeServingTransport(initial_budget=32.0)
        client = httpx.AsyncClient(transport=transport, base_url="http://live-native.local")

        async def _test():
            req_uuid = "a" * 32
            payload = {
                "model": "qwen-4b",
                "messages": [{"role": "user", "content": "Hello"}],
                "prompt_tokens": 128,
                "max_tokens": 128,
                "stream": True,
                "vllm_xargs": {"pr33_cohort_id": "cohort_tag_01"},
            }
            async with client.stream(
                "POST",
                "/v1/chat/completions",
                json=payload,
                headers={"x-benchmark-request-id": req_uuid},
            ) as resp:
                self.assertEqual(resp.status_code, 200)

                state_resp = await client.get("/pr33-native/state")
                state_data = state_resp.json()
                matching = [r for r in state_data["requests"] if r["cohort_id"] == "cohort_tag_01"]
                self.assertEqual(len(matching), 1)
                self.assertEqual(matching[0]["gateway_request_id"], req_uuid)
            await client.aclose()

        asyncio.run(_test())

    def test_live_adapter_concurrent_capture_chat_streams(self):
        """LiveNativeCohortRunner runs concurrent capture_chat stream tasks with standard chat payload and drain."""
        runner = LiveNativeCohortRunner()
        transport = LiveNativeServingTransport(initial_budget=32.0)
        permit = transport.create_permit()

        async def _test():
            receipt = await runner.run_arm("arm_test_concurrent", 32.0, transport=transport, permit=permit)
            self.assertTrue(receipt.drain_verified)
            self.assertEqual(receipt.anchor_count, 5)
            self.assertEqual(len(receipt.anchor_stream_outcomes), 5)
            for outcome in receipt.anchor_stream_outcomes:
                self.assertIn(outcome["status"], ("complete", "cancelled"))

        asyncio.run(_test())

    def test_live_adapter_guarded_actuator_cas_and_measured_max512_survival(self):
        """GuardedActuator CAS submission and measured (not virtual) max 512 token survival at apply time."""
        runner = LiveNativeCohortRunner()
        transport = LiveNativeServingTransport(initial_budget=32.0)
        permit = transport.create_permit()

        async def _test():
            receipt = await runner.run_arm("arm_test_cas_survival", 16.0, transport=transport, permit=permit)
            act_sub = receipt.actuator_submission
            self.assertEqual(act_sub["status"], "applied")
            self.assertEqual(act_sub["scope"], "identification")
            self.assertEqual(act_sub["command"]["budget"], 16.0)
            self.assertEqual(act_sub["command"]["schema"], "mpc-admission-v1")

            self.assertTrue(receipt.measured_max512_survival_verified)
            self.assertFalse(receipt.early_completion_hazard_detected)
            for eid, rem in receipt.measured_remaining_tokens_at_apply.items():
                self.assertGreater(rem, 90)

        asyncio.run(_test())

    def test_live_native_cohort_pipeline_paired_execution(self):
        """Paired pipeline execution over Live Native Adapter: Arm A rejects burst, Arm B admits burst."""
        res = asyncio.run(run_live_native_cohort_pipeline())
        self.assertEqual(res.schema, "native-v3-live-native-cohort-paired-receipt-v1")
        self.assertEqual(res.arm_a_receipt.assigned_budget, 16.0)
        self.assertEqual(res.arm_b_receipt.assigned_budget, 32.0)

        # Arm A rejects all 4 burst requests (15.1135 + 4.0304 > 16.0)
        self.assertEqual(res.arm_a_receipt.burst_rejections, 4)
        self.assertEqual(res.arm_a_receipt.burst_admissions, 0)

        # Arm B admits all 4 burst requests (15.1135 + 16.1217 <= 32.0)
        self.assertEqual(res.arm_b_receipt.burst_rejections, 0)
        self.assertEqual(res.arm_b_receipt.burst_admissions, 4)

        # Contention slows down anchor progress in Arm B relative to Arm A
        self.assertGreater(res.arm_a_mean_progress, 50.0)
        self.assertLess(res.arm_b_mean_progress, 20.0)
        self.assertLess(res.runner_observed_progress_delta, -40.0)

        # Invariant checks
        self.assertTrue(res.itt_preserved)
        self.assertTrue(res.lineage_refusal_enforced)
        self.assertTrue(res.gateway_tag_matches_client_verified)
        self.assertTrue(res.all_assigned_fates_retained)
        self.assertTrue(res.measured_survival_verified)
        self.assertFalse(res.early_completion_hazard_detected)

        # Evidence scope
        self.assertEqual(res.evidence_scope, "cpu_qualified_live_adapter_contract_test_not_gpu_pilot")
        self.assertEqual(res.native_hardware_status, "UNTESTED_requires_mayor_native_pilot")
        self.assertTrue(res.arm_a_receipt.forced_outputs_never_goodput)

    def test_source_144_cost_held_full_http_terminal_and_gate5_decode_cost(self):
        """Verifies Source 144 cost contract: firstcontent239 marks first_at only, cleanup529 releases.

        Also verifies Gate 5 anchors decode cost (14.26) is held at gate, directly gating burst capacity.
        """
        facts = SOURCE_144_ACTUAL_FACTS
        self.assertTrue(facts["cost_held_full_http_terminal"])
        self.assertTrue(facts["firstcontent_only_marks_first_at"])
        self.assertTrue(facts["cleanup_and_finish_request_releases"])
        self.assertTrue(facts["gate5_anchors_decode_cost_matters"])
        self.assertTrue(facts["true_ignore_eos_max512_ends"])
        self.assertEqual(facts["calibration_blocks"], "17-36 (strictly non-train)")
        self.assertEqual(facts["validation_blocks"], "37-40 (strictly non-train)")
        self.assertTrue(facts["no_fresh_raw_outside_frozen_15_16_smoke"])
        self.assertTrue(facts["budget_16_32_is_reservation_cost_not_concurrency"])
        self.assertTrue(facts["forced_cohort_counter_effect_not_mpc_goodput"])

        # Test live cost holding across streaming lifecycle
        transport = LiveNativeServingTransport(initial_budget=16.0)
        client = httpx.AsyncClient(transport=transport, base_url="http://test-gw")

        async def _test():
            from mpc_lab.http_capture import capture_chat
            outcomes = []
            req_uuid = uuid.uuid4().hex
            payload = {
                "model": "qwen-4b",
                "messages": [{"role": "user", "content": "hello"}],
                "prompt_tokens": 128,
                "max_tokens": 512,
                "ignore_eos": True,
            }
            # Launch streaming request
            task = asyncio.create_task(
                capture_chat(
                    client,
                    "/v1/chat/completions",
                    payload,
                    req_uuid,
                    scheduled_at=0.0,
                    enabled=True,
                    record=outcomes.append,
                )
            )
            await asyncio.sleep(0.01)

            # Check that cost is held and first_at is marked while stream is active (line 239 contract)
            state_resp = await client.get("/admin/mpc/state")
            state_doc = state_resp.json()
            self.assertEqual(len(state_doc["requests"]), 1)
            mark = state_doc["requests"][0]
            self.assertIsNotNone(mark["first_at"])
            self.assertGreater(state_doc["requests"][0]["cost"], 2.8)

            # Await stream completion and verify full HTTP terminal release (line 529 cleanup contract)
            await task
            self.assertEqual(len(outcomes), 1)
            self.assertEqual(outcomes[0]["status"], "complete")

            state_after = await client.get("/admin/mpc/state")
            self.assertEqual(len(state_after.json()["requests"]), 0)
            await client.aclose()

        asyncio.run(_test())

    def test_supplied_client_root_capture_chat_guarded_actuator_contract(self):
        """Verifies LiveNativeCohortRunner operates over supplied CLIENT verifying Root contracts before GPU."""
        proto = ControlledCohortIdentificationProtocol()
        runner = LiveNativeCohortRunner(protocol=proto)
        transport = LiveNativeServingTransport(initial_budget=32.0)
        supplied_client = httpx.AsyncClient(transport=transport, base_url="http://supplied-gateway")
        supplied_native_client = httpx.AsyncClient(transport=transport, base_url="http://supplied-native")
        permit = transport.create_permit()

        async def _test():
            receipt = await runner.run_arm(
                "arm_supplied_client",
                16.0,
                client=supplied_client,
                native_client=supplied_native_client,
                transport=transport,
                permit=permit,
            )
            # Verifies Root capture_chat executed without error
            self.assertEqual(len(receipt.anchor_stream_outcomes), 5)
            # Verifies GuardedActuator executed CAS submission with IdentificationPermit
            self.assertEqual(receipt.actuator_submission["status"], "applied")
            self.assertEqual(receipt.actuator_submission["scope"], "identification")
            # Verifies Gate 5 anchors decode cost (14.26) caused all bursts to be rejected on budget 16
            self.assertEqual(receipt.burst_rejections, 4)
            self.assertEqual(receipt.burst_admissions, 0)
            # Verifies all assigned fates are retained
            self.assertTrue(receipt.all_assigned_fates_retained)
            self.assertTrue(receipt.measured_max512_survival_verified)
            await supplied_client.aclose()
            await supplied_native_client.aclose()

        asyncio.run(_test())


class TestRound15LiveAdapterDeploymentHardening(unittest.TestCase):
    """Round 15 tests: Live Native Adapter Deployment Hardening and Fault-Tree Gates."""

    def test_real_shaped_nonmock_provenance_and_binding_validation(self):
        """Validates real-shaped non-mock server IDs dominate and supplied binding mismatch aborts setup."""
        runner = LiveNativeCohortRunner()
        transport = LiveNativeServingTransport(
            initial_budget=32.0,
            gateway_run_id="gw-prod-729b4e18",
            native_run_id="nat-engine-c81f092a",
            observer_sha256="729b4e18320498acfe74b210dcfa7240182649afce7210492837492817492847",
        )
        permit = transport.create_permit()
        cli = httpx.AsyncClient(transport=transport, base_url="http://real-gw.local")

        from mpc_lab.native_state import NativeBinding

        matching_bnd = NativeBinding(
            clock_domain=transport.clock_domain,
            gateway_run_id="gw-prod-729b4e18",
            native_run_id="nat-engine-c81f092a",
            observer_sha256="729b4e18320498acfe74b210dcfa7240182649afce7210492837492817492847",
            identity=transport.identity,
        )

        async def _test():
            receipt = await runner.run_arm("arm_matching", 16.0, client=cli, binding=matching_bnd, permit=permit)
            self.assertTrue(receipt.drain_verified)
            self.assertEqual(receipt.actuator_submission["command"]["run_id"], "gw-prod-729b4e18")
            self.assertEqual(receipt.actuator_submission["status"], "applied")

            mismatched_bnd = NativeBinding(
                clock_domain=transport.clock_domain,
                gateway_run_id="foreign-gateway-run-id",
                native_run_id="nat-engine-c81f092a",
                observer_sha256="729b4e18320498acfe74b210dcfa7240182649afce7210492837492817492847",
                identity=transport.identity,
            )
            aborted_receipt = await runner.run_arm("arm_mismatch", 16.0, client=cli, binding=mismatched_bnd, permit=permit)
            self.assertFalse(aborted_receipt.drain_verified)
            self.assertEqual(aborted_receipt.lineage_refusal_reason, "supplied_binding_provenance_mismatch")
            self.assertEqual(aborted_receipt.anchor_count, 0)
            self.assertEqual(aborted_receipt.burst_count_offered, 0)
            self.assertEqual(aborted_receipt.actuator_submission["status"], "aborted_lineage_refusal")
            await cli.aclose()

        asyncio.run(_test())

    def test_drain_failure_halts_before_anchor_dispatch(self):
        """Drain verification failure MUST halt before any anchor POSTs, CAS, or burst dispatches."""
        runner = LiveNativeCohortRunner()
        transport = LiveNativeServingTransport(initial_budget=32.0)
        permit = transport.create_permit()
        # Undrained state: active request in backend
        transport.active_requests["undrained_req"] = {
            "client_request_id": "undrained_req",
            "raw_engine_id": "chatcmpl-engine-9999-undrained",
            "model": "qwen-4b",
            "prompt_tokens": 128,
            "computed_tokens": 128.0,
            "output_tokens": 5,
            "max_tokens": 128,
            "cost": 1.689,
            "admitted_at": transport.clock(),
            "phase": "decode",
            "ignore_eos": False,
            "cohort_id": "stray",
            "gateway_request_id": "stray",
        }
        cli = httpx.AsyncClient(transport=transport, base_url="http://drain-fail.local")

        async def _test():
            receipt = await runner.run_arm("arm_drain_fail", 16.0, client=cli, permit=permit)
            self.assertFalse(receipt.drain_verified)
            self.assertEqual(receipt.anchor_count, 0)
            self.assertEqual(len(receipt.anchor_client_request_ids), 0)
            self.assertEqual(receipt.burst_count_offered, 0)
            self.assertEqual(receipt.actuator_submission["status"], "aborted_drain_failed")
            await cli.aclose()

        asyncio.run(_test())

    def test_gate_failure_halts_before_cas_submission(self):
        """Preassignment gate failure MUST abort setup before CAS submission and burst dispatch."""
        proto = ControlledCohortIdentificationProtocol(gate_poll_timeout_s=0.05)
        runner = LiveNativeCohortRunner(protocol=proto)
        transport = LiveNativeServingTransport(initial_budget=32.0)
        permit = transport.create_permit()

        class GateFailingTransport(httpx.AsyncBaseTransport):
            def __init__(self):
                super().__init__()
                self.call_count = 0

            async def handle_async_request(self, request):
                resp = await transport.handle_async_request(request)
                if request.url.path == "/pr33-native/state":
                    self.call_count += 1
                    if self.call_count > 1:  # After initial drain
                        data = resp.json()
                        data["complete"] = False
                        return httpx.Response(200, json=data)
                return resp

        nat_cli = httpx.AsyncClient(transport=GateFailingTransport(), base_url="http://live-native-cohort.local")

        async def _test():
            receipt = await runner.run_arm("arm_gate_fail", 16.0, transport=transport, native_client=nat_cli, permit=permit)
            self.assertTrue(receipt.drain_verified)
            self.assertEqual(receipt.anchor_count, 5)
            self.assertEqual(receipt.actuator_submission["status"], "aborted_gate_unsatisfied")
            self.assertEqual(receipt.burst_count_offered, 0)
            self.assertEqual(receipt.lineage_refusal_reason, "gate_not_satisfied")
            for fate in receipt.anchor_fates.values():
                self.assertEqual(fate["status"], "setup_failed_gate_unsatisfied")
            await nat_cli.aclose()

        asyncio.run(_test())

    def test_cas_failure_halts_before_burst_dispatch(self):
        """CAS failure (e.g. version mismatch or TTL expired) MUST abort before burst dispatch."""
        runner = LiveNativeCohortRunner()
        transport = LiveNativeServingTransport(initial_budget=32.0, simulate_cas_mismatch=True)
        permit = transport.create_permit()

        async def _test():
            receipt = await runner.run_arm("arm_cas_fail", 16.0, transport=transport, permit=permit)
            self.assertTrue(receipt.drain_verified)
            self.assertEqual(receipt.anchor_count, 5)
            self.assertNotEqual(receipt.actuator_submission.get("status"), "applied")
            self.assertEqual(receipt.burst_count_offered, 0)
            self.assertEqual(len(receipt.burst_fates), 0)
            self.assertEqual(receipt.lineage_refusal_reason, "cas_submission_failed")
            for eid, fate in receipt.anchor_fates.items():
                self.assertEqual(fate["status"], "assignment_failed_cas")

        asyncio.run(_test())

    def test_slow_stream_survival_and_independent_window_sampling(self):
        """Verifies slow streams decode through evaluation window and sample at Tapply+1s independent of stream end."""
        runner = LiveNativeCohortRunner()
        transport = LiveNativeServingTransport(initial_budget=32.0)
        permit = transport.create_permit()

        async def _test():
            receipt = await runner.run_arm("arm_slow_streams", 32.0, transport=transport, permit=permit)
            self.assertTrue(receipt.measured_max512_survival_verified)
            self.assertFalse(receipt.early_completion_hazard_detected)
            self.assertEqual(receipt.censored_count, 0)
            self.assertGreater(receipt.anchor_mean_progress, 0.0)
            for eid, fate in receipt.anchor_fates.items():
                self.assertEqual(fate["status"], "observed")
                self.assertLess(fate["end_output"], 512)

        asyncio.run(_test())

    def test_geometry_action_contrast_preflight_and_zero_contrast_hazard(self):
        """Verifies physical possibility preflight: informative ITT action contrast vs zero action contrast hazard."""
        proto = ControlledCohortIdentificationProtocol()
        from mpc_lab.contracts import CostSpec

        # 1. Nominal sourced CostSpec produces informative action contrast
        nominal_spec = get_sourced_cost_spec()
        preflight_nom = proto.check_geometry_action_contrast(nominal_spec)
        self.assertTrue(preflight_nom["action_contrast_valid"])
        self.assertTrue(preflight_nom["informative_geometry"])
        self.assertFalse(preflight_nom["zero_action_contrast_hazard"])
        self.assertTrue(preflight_nom["arm_a_burst_rejection_expected"])
        self.assertTrue(preflight_nom["arm_b_burst_admission_expected"])

        # 2. Inflated CostSpec (e.g. intercept=4.0): anchors alone exceed budget 32 (5 * 4.0 > 20, bursts rejected everywhere)
        inflated_spec = CostSpec(intercept=4.0, input_per_token=0.002, output_per_token=0.01)
        preflight_inf = proto.check_geometry_action_contrast(inflated_spec)
        self.assertFalse(preflight_inf["action_contrast_valid"])
        self.assertTrue(preflight_inf["zero_action_contrast_hazard"])
        self.assertFalse(preflight_inf["arm_b_burst_admission_expected"])

        # 3. Under-costed CostSpec: bursts fit into budget 16 alongside anchors (zero contrast because Arm A also admits)
        undercost_spec = CostSpec(intercept=0.01, input_per_token=0.00001, output_per_token=0.0001)
        preflight_under = proto.check_geometry_action_contrast(undercost_spec)
        self.assertFalse(preflight_under["action_contrast_valid"])
        self.assertTrue(preflight_under["zero_action_contrast_hazard"])
        self.assertFalse(preflight_under["arm_a_burst_rejection_expected"])


class TestRound16OwnerLedgerAndHistoricalRefusal(unittest.TestCase):
    """Round 16 test suite verifying historical source registry integrity and Owner Ledger Schema V2 qualification."""

    @classmethod
    def setUpClass(cls):
        ensure_integration_paths()

    def test_historical_source_registry_refuses_new_owner_journal_gateway(self):
        """HistoricalSourceRegistry strictly refuses the new owner-journal gateway source and preserves Source144 immutability."""
        from native_campaign_protocol import (
            HistoricalSourceRegistry,
            SourceRegistryRefusalError,
            SOURCE144_CANONICAL_BINDING,
            NEW_OWNER_JOURNAL_CANONICAL_BINDING,
        )

        owner_journal_gw = Path("/home/daniel_lin/gt/pr32/mayor/mpc-native-owner-journal/gateway.py")
        source144_gw = Path("/home/daniel_lin/gt/pr32/mayor/mpc-native-integration/gateway.py")

        if owner_journal_gw.exists():
            new_gw_bytes = owner_journal_gw.read_bytes()
            new_sha = hashlib.sha256(new_gw_bytes).hexdigest()
            self.assertNotEqual(new_sha, SOURCE144_CANONICAL_BINDING["gateway_sha256"])

            # Must refuse new owner journal source under historical Source144 registry
            with self.assertRaises(SourceRegistryRefusalError) as ctx:
                HistoricalSourceRegistry.verify_source144_gateway(
                    new_gw_bytes,
                    source_commit=NEW_OWNER_JOURNAL_CANONICAL_BINDING["source_commit"],
                )
            self.assertIn("Historical Source144 gateway SHA mismatch", str(ctx.exception))

        if source144_gw.exists():
            source144_bytes = source144_gw.read_bytes()
            source144_sha = hashlib.sha256(source144_bytes).hexdigest()
            self.assertEqual(source144_sha, SOURCE144_CANONICAL_BINDING["gateway_sha256"])

            # Must accept genuine Source144
            verified = HistoricalSourceRegistry.verify_source144_gateway(
                source144_bytes,
                source_commit=SOURCE144_CANONICAL_BINDING["source_commit"],
            )
            self.assertTrue(verified)

    def test_owner_ledger_schema_v2_parsing_and_sequence_monotonicity(self):
        """OwnerLedgerTrace parses schema-v2 events, verifies contiguous sequences, and achieves 100% owner identification."""
        from native_campaign_protocol import OwnerLedgerTrace

        events = [
            {
                "event": "mpc_ledger", "clock_domain": "test-domain", "sequence": 1,
                "effective_at": 100.0, "reserved_cost": 10.0, "budget": 32.0, "budget_version": 1,
                "change_kind": "admission", "ledger_schema_version": 2,
                "request_id": "req-1", "request_cost": 10.0,
            },
            {
                "event": "mpc_ledger", "clock_domain": "test-domain", "sequence": 2,
                "effective_at": 100.2, "reserved_cost": 10.0, "budget": 32.0, "budget_version": 1,
                "change_kind": "first_content", "ledger_schema_version": 2,
                "request_id": "req-1", "request_cost": 10.0,
            },
            {
                "event": "mpc_ledger", "clock_domain": "test-domain", "sequence": 3,
                "effective_at": 100.8, "reserved_cost": 0.0, "budget": 32.0, "budget_version": 1,
                "change_kind": "terminal", "ledger_schema_version": 2,
                "request_id": "req-1", "request_cost": 10.0,
            },
        ]
        jsonl = "\n".join(json.dumps(e) for e in events) + "\n"
        raw_bytes = jsonl.encode("utf-8")
        status = {
            "run_id": "test-run", "status": "closed", "closed_at": 101.0,
            "dropped": 0, "write_errors": 0, "mpc_ledger_schema_version": 2,
            "mpc_final_sequence": 3, "mpc_remaining_requests": 0, "mpc_ledger_complete": True,
            "telemetry_file_sha256": hashlib.sha256(raw_bytes).hexdigest(),
            "telemetry_file_bytes": len(raw_bytes),
        }
        trace = OwnerLedgerTrace.from_jsonl(jsonl, json.dumps(status))
        receipt = trace.verify_trace_integrity()

        self.assertEqual(receipt["total_events"], 3)
        self.assertEqual(receipt["owner_events"], 3)
        self.assertEqual(receipt["owner_identified_events"], 3)
        self.assertEqual(receipt["owner_identification_rate"], 1.0)
        self.assertTrue(receipt["status_verified"])
        self.assertIn("req-1", receipt["lifecycles"])
        self.assertEqual(receipt["lifecycles"]["req-1"]["cost"], 10.0)

    def test_owner_ledger_non_fifo_lifecycle_and_whole_cost_preservation(self):
        """Owner ledger preserves non-FIFO departure order and verifies whole cost is held past first_content."""
        from native_campaign_protocol import OwnerLedgerTrace

        events = [
            {"event": "mpc_ledger", "sequence": 1, "effective_at": 10.0, "reserved_cost": 30.0, "budget": 64.0, "budget_version": 1, "change_kind": "admission", "request_id": "req-A", "request_cost": 30.0, "ledger_schema_version": 2},
            {"event": "mpc_ledger", "sequence": 2, "effective_at": 10.1, "reserved_cost": 37.0, "budget": 64.0, "budget_version": 1, "change_kind": "admission", "request_id": "req-B", "request_cost": 7.0, "ledger_schema_version": 2},
            {"event": "mpc_ledger", "sequence": 3, "effective_at": 10.3, "reserved_cost": 37.0, "budget": 64.0, "budget_version": 1, "change_kind": "first_content", "request_id": "req-A", "request_cost": 30.0, "ledger_schema_version": 2},
            {"event": "mpc_ledger", "sequence": 4, "effective_at": 10.4, "reserved_cost": 37.0, "budget": 16.0, "budget_version": 2, "change_kind": "control", "ledger_schema_version": 2},
            {"event": "mpc_ledger", "sequence": 5, "effective_at": 10.5, "reserved_cost": 30.0, "budget": 16.0, "budget_version": 2, "change_kind": "terminal", "request_id": "req-B", "request_cost": 7.0, "ledger_schema_version": 2},
            {"event": "mpc_ledger", "sequence": 6, "effective_at": 10.8, "reserved_cost": 0.0, "budget": 16.0, "budget_version": 2, "change_kind": "terminal", "request_id": "req-A", "request_cost": 30.0, "ledger_schema_version": 2},
        ]
        jsonl = "\n".join(json.dumps(e) for e in events) + "\n"
        raw_bytes = jsonl.encode("utf-8")
        status = {
            "run_id": "test-run", "status": "closed", "closed_at": 11.0,
            "dropped": 0, "write_errors": 0, "mpc_ledger_schema_version": 2,
            "mpc_final_sequence": 6, "mpc_remaining_requests": 0, "mpc_ledger_complete": True,
            "telemetry_file_sha256": hashlib.sha256(raw_bytes).hexdigest(),
            "telemetry_file_bytes": len(raw_bytes),
        }
        trace = OwnerLedgerTrace.from_jsonl(jsonl, json.dumps(status))
        receipt = trace.verify_trace_integrity()

        # Non-FIFO departure verification: req-B completed before req-A
        life_a = receipt["lifecycles"]["req-A"]
        life_b = receipt["lifecycles"]["req-B"]
        self.assertLess(life_a["admission_at"], life_b["admission_at"])
        self.assertLess(life_b["terminal_at"], life_a["terminal_at"])

        # Cost held past first_content: reserved cost at event 3 (first_content of A) is 37.0, identical to event 2
        self.assertEqual(life_a["first_content_held_cost"], 37.0)

    def test_owner_ledger_shutdown_sealing_digest_and_byte_tampering_refusal(self):
        """OwnerLedgerTrace refuses traces when telemetry file bytes, SHA256 digest, or sequence watermarks are tampered."""
        from native_campaign_protocol import OwnerLedgerTrace, OwnerLedgerIntegrityError

        events = [
            {"event": "mpc_ledger", "sequence": 1, "effective_at": 10.0, "reserved_cost": 10.0, "budget": 32.0, "budget_version": 1, "change_kind": "admission", "request_id": "r1", "request_cost": 10.0, "ledger_schema_version": 2},
            {"event": "mpc_ledger", "sequence": 2, "effective_at": 10.5, "reserved_cost": 0.0, "budget": 32.0, "budget_version": 1, "change_kind": "terminal", "request_id": "r1", "request_cost": 10.0, "ledger_schema_version": 2},
        ]
        jsonl = "\n".join(json.dumps(e) for e in events) + "\n"
        raw_bytes = jsonl.encode("utf-8")

        # 1. Tampered digest
        status_bad_sha = {
            "run_id": "test-run", "status": "closed", "closed_at": 11.0,
            "dropped": 0, "write_errors": 0, "mpc_ledger_schema_version": 2,
            "mpc_final_sequence": 2, "mpc_remaining_requests": 0, "mpc_ledger_complete": True,
            "telemetry_file_sha256": "0" * 64,  # Incorrect hash
            "telemetry_file_bytes": len(raw_bytes),
        }
        trace_bad_sha = OwnerLedgerTrace.from_jsonl(jsonl, json.dumps(status_bad_sha))
        with self.assertRaises(OwnerLedgerIntegrityError) as ctx:
            trace_bad_sha.verify_trace_integrity()
        self.assertIn("Telemetry SHA256 digest mismatch", str(ctx.exception))

        # 2. Tampered byte count
        status_bad_len = dict(status_bad_sha, telemetry_file_sha256=hashlib.sha256(raw_bytes).hexdigest(), telemetry_file_bytes=len(raw_bytes) + 10)
        trace_bad_len = OwnerLedgerTrace.from_jsonl(jsonl, json.dumps(status_bad_len))
        with self.assertRaises(OwnerLedgerIntegrityError) as ctx:
            trace_bad_len.verify_trace_integrity()
        self.assertIn("Telemetry file byte count mismatch", str(ctx.exception))

        # 3. Tampered sequence watermark
        status_bad_seq = dict(status_bad_sha, telemetry_file_sha256=hashlib.sha256(raw_bytes).hexdigest(), mpc_final_sequence=99)
        trace_bad_seq = OwnerLedgerTrace.from_jsonl(jsonl, json.dumps(status_bad_seq))
        with self.assertRaises(OwnerLedgerIntegrityError) as ctx:
            trace_bad_seq.verify_trace_integrity()
        self.assertIn("Final sequence mismatch", str(ctx.exception))

    def test_owner_ledger_unreleased_owners_fails_closed(self):
        """OwnerLedgerTrace fails closed when remaining unreleased owners exist at shutdown."""
        from native_campaign_protocol import OwnerLedgerTrace, OwnerLedgerIntegrityError

        events = [
            {"event": "mpc_ledger", "sequence": 1, "effective_at": 10.0, "reserved_cost": 10.0, "budget": 32.0, "budget_version": 1, "change_kind": "admission", "request_id": "r1", "request_cost": 10.0, "ledger_schema_version": 2},
        ]
        jsonl = "\n".join(json.dumps(e) for e in events) + "\n"
        raw_bytes = jsonl.encode("utf-8")
        status_failed = {
            "run_id": "test-run", "status": "failed", "closed_at": 11.0,
            "dropped": 0, "write_errors": 0, "mpc_ledger_schema_version": 2,
            "mpc_final_sequence": 1, "mpc_remaining_requests": 1, "mpc_ledger_complete": False,
            "telemetry_file_sha256": hashlib.sha256(raw_bytes).hexdigest(),
            "telemetry_file_bytes": len(raw_bytes),
        }
        trace = OwnerLedgerTrace.from_jsonl(jsonl, json.dumps(status_failed))
        with self.assertRaises(OwnerLedgerIntegrityError) as ctx:
            trace.verify_trace_integrity()
        self.assertIn("Shutdown status indicates failure", str(ctx.exception))

    def test_actual_source144_observer_shape_qualification_without_phase(self):
        """LiveNativeCohortRunner gates successfully on actual Source144 observer shape emitting only 8 fields (NO phase)."""
        from native_campaign_protocol import (
            LiveNativeCohortRunner,
            LiveNativeServingTransport,
            ControlledCohortIdentificationProtocol,
        )
        from mpc_lab.actuator import IdentificationPermit

        runner = LiveNativeCohortRunner()
        transport = LiveNativeServingTransport(initial_budget=32.0)
        permit = IdentificationPermit(
            identity=transport.identity,
            run_id=transport.gateway_run_id,
            clock_domain=transport.clock_domain,
            expires_at=transport.clock() + 3600.0,
            approved=True,
        )

        # Verify that LiveNativeServingTransport emits only the 8 actual Source144 observer fields
        client = httpx.AsyncClient(transport=transport, base_url="http://live-native.local")

        async def _test():
            # Run arm with actual observer shape and explicit approved permit
            receipt = await runner.run_arm(
                "arm_actual_observer",
                32.0,
                transport=transport,
                client=client,
                native_client=client,
                permit=permit,
            )
            self.assertTrue(receipt.drain_verified)
            self.assertEqual(receipt.actuator_submission.get("status"), "applied")
            self.assertEqual(receipt.anchor_count, 5)
            self.assertTrue(receipt.gateway_tag_matches_client)
            self.assertIsNotNone(receipt.anchor_mean_progress)
            self.assertGreater(receipt.anchor_mean_progress, 0.0)

            # Inspect raw observer frame returned by transport
            obs_resp = await client.get("/pr33-native/state", headers={"x-observer-key": "test-key"})
            frame = obs_resp.json()
            for r in frame.get("requests", []):
                self.assertNotIn("phase", r)
                expected_keys = {
                    "cohort_id", "computed_tokens", "gateway_request_id",
                    "ignore_eos", "maximum_output_tokens", "output_tokens",
                    "prompt_tokens", "request_id",
                }
                self.assertEqual(set(r.keys()), expected_keys)

        asyncio.run(_test())

    def test_flawed_r15_phase_requiring_gate_refuses_actual_observer_frame(self):
        """Preserve R15 failure evidence: a gate requiring r.get('phase') == 'decode' fails on actual observer frames."""
        actual_observer_request = {
            "cohort_id": "test-cohort",
            "computed_tokens": 128,
            "gateway_request_id": "client-uuid-001",
            "ignore_eos": True,
            "maximum_output_tokens": 512,
            "output_tokens": 10,
            "prompt_tokens": 128,
            "request_id": "chatcmpl-engine-001",
        }
        self.assertNotIn("phase", actual_observer_request)
        self.assertIsNone(actual_observer_request.get("phase"))

        # Flawed R15 gate requirement fails:
        r15_gate_passed = (actual_observer_request.get("phase") == "decode" and actual_observer_request.get("computed_tokens", 0) >= 128)
        self.assertFalse(r15_gate_passed)

        # Corrected R16 derived decode gate succeeds:
        r16_derived_gate_passed = (
            actual_observer_request.get("prompt_tokens", 0) > 0
            and actual_observer_request.get("computed_tokens", 0) >= actual_observer_request.get("prompt_tokens", 0)
            and actual_observer_request.get("output_tokens", 0) >= 1
            and actual_observer_request.get("output_tokens", 0) < actual_observer_request.get("maximum_output_tokens", 0)
            and actual_observer_request.get("ignore_eos") is True
        )
        self.assertTrue(r16_derived_gate_passed)

    def test_gate_enforces_exact_uuid_bijection_not_membership_only(self):
        """Preassignment gate requires exact 1-to-1 UUID bijection and rejects duplicates/omissions."""
        from native_campaign_protocol import ControlledCohortIdentificationProtocol

        proto = ControlledCohortIdentificationProtocol()
        anchor_client_rids = ("uuid-1", "uuid-2", "uuid-3", "uuid-4", "uuid-5")

        # 1. Duplicate gateway_request_id (membership-only would pass, bijection must fail)
        duplicate_matching = [
            {"gateway_request_id": "uuid-1", "request_id": f"eng-{i}", "prompt_tokens": 128, "computed_tokens": 128, "output_tokens": 5, "maximum_output_tokens": 512, "ignore_eos": True}
            for i in range(5)
        ]
        gw_ids_dup = [r.get("gateway_request_id") for r in duplicate_matching]
        # Membership-only:
        self.assertTrue(all(gid in anchor_client_rids for gid in gw_ids_dup))
        # Bijection:
        bijection_passed = (set(gw_ids_dup) == set(anchor_client_rids) and len(set(gw_ids_dup)) == proto.anchor_cohort_count)
        self.assertFalse(bijection_passed)

        # 2. Exact bijection passes
        valid_matching = [
            {"gateway_request_id": f"uuid-{i+1}", "request_id": f"eng-{i+1}", "prompt_tokens": 128, "computed_tokens": 128, "output_tokens": 5, "maximum_output_tokens": 512, "ignore_eos": True}
            for i in range(5)
        ]
        gw_ids_valid = [r.get("gateway_request_id") for r in valid_matching]
        valid_bijection_passed = (set(gw_ids_valid) == set(anchor_client_rids) and len(set(gw_ids_valid)) == proto.anchor_cohort_count)
        self.assertTrue(valid_bijection_passed)

    def test_geometry_preflight_uses_actual_owner_cost_and_real_token_length(self):
        """check_geometry_action_contrast incorporates actual Gateway whole cost / real token length."""
        from native_campaign_protocol import ControlledCohortIdentificationProtocol, get_sourced_cost_spec

        proto = ControlledCohortIdentificationProtocol()
        cost_spec = get_sourced_cost_spec()

        # Supply actual Gateway owner cost from actual tokenized text (e.g. 32 tokens instead of nominal 128)
        actual_charged_cost = cost_spec.estimate(32, 512)
        res = proto.check_geometry_action_contrast(cost_spec, actual_anchor_cost=actual_charged_cost)

        self.assertTrue(res["actual_cost_sourced"])
        self.assertEqual(res["c_anchor"], actual_charged_cost)
        self.assertTrue(res["action_contrast_valid"])


class TestRound17GenuineServerClockAndBracketedCounter(unittest.TestCase):
    """Round 17 qualification: server apply clock, absolute timing, missing permit refusal, and ITT counter brackets."""

    def test_missing_permit_aborts_early_without_any_post_requests(self):
        """Missing or unapproved permit immediately refuses and aborts before ANY POST requests are issued."""
        from native_campaign_protocol import (
            LiveNativeCohortRunner,
            LiveNativeServingTransport,
        )
        from mpc_lab.actuator import IdentificationPermit

        async def _test():
            runner = LiveNativeCohortRunner()
            transport = LiveNativeServingTransport(initial_budget=32.0)
            async with httpx.AsyncClient(transport=transport, base_url="http://live-native.local") as client:
                # 1. permit is None -> aborted_missing_permit, 0 POST requests issued
                receipt_none = await runner.run_arm("arm_no_permit", 32.0, transport=transport, client=client, permit=None)
                self.assertEqual(receipt_none.actuator_submission.get("status"), "aborted_missing_permit")
                self.assertEqual(receipt_none.anchor_count, 0)
                self.assertEqual(len(receipt_none.anchor_client_request_ids), 0)
                self.assertEqual(len(transport.active_requests), 0)
                self.assertEqual(len(transport.received_budget_commands), 0)

                # 2. permit.approved is False -> aborted_missing_permit, 0 POST requests issued
                unapproved_permit = IdentificationPermit(
                    identity=transport.identity,
                    run_id=transport.gateway_run_id,
                    clock_domain=transport.clock_domain,
                    expires_at=transport.clock() + 3600.0,
                    approved=False,
                )
                receipt_unapp = await runner.run_arm("arm_unapproved_permit", 32.0, transport=transport, client=client, permit=unapproved_permit)
                self.assertEqual(receipt_unapp.actuator_submission.get("status"), "aborted_missing_permit")
                self.assertEqual(receipt_unapp.anchor_count, 0)
                self.assertEqual(len(receipt_unapp.anchor_client_request_ids), 0)
                self.assertEqual(len(transport.active_requests), 0)
                self.assertEqual(len(transport.received_budget_commands), 0)

        asyncio.run(_test())

    def test_genuine_server_apply_clock_and_absolute_timing_apply10_receive10_2_target11(self):
        """Test apply at 10.0, receive ACK at 10.2, target window end 11.0 (absolute timing, not receipt-relative)."""
        from native_campaign_protocol import (
            LiveNativeCohortRunner,
            LiveNativeServingTransport,
            ControlledCohortIdentificationProtocol,
        )

        # 1. Direct arithmetic test of apply10/receive10.2 target11
        t_apply = 10.0
        t_ack_received = 10.2
        proto = ControlledCohortIdentificationProtocol(evaluation_window_s=1.0)
        t_target_window_end = t_apply + proto.evaluation_window_s
        self.assertEqual(t_target_window_end, 11.0)
        apply_ack_lag = t_ack_received - t_apply
        self.assertAlmostEqual(apply_ack_lag, 0.2, places=4)
        # Remaining sleep is target - receive (0.8s), NOT receipt-relative 1.0s
        remaining_sleep = max(0.0, t_target_window_end - t_ack_received)
        self.assertAlmostEqual(remaining_sleep, 0.8, places=4)

        # 2. Integration run with LiveNativeServingTransport and 200ms CAS ACK delay
        async def _test():
            transport = LiveNativeServingTransport(
                initial_budget=32.0,
                cas_ack_delay_s=0.2,  # 200ms ACK lag
            )
            runner = LiveNativeCohortRunner(protocol=proto)
            permit = transport.create_permit()
            async with httpx.AsyncClient(transport=transport, base_url="http://live-native.local") as client:
                receipt = await runner.run_arm(
                    "arm_timing",
                    16.0,
                    transport=transport,
                    client=client,
                    native_client=client,
                    permit=permit,
                )
                # Verify server apply clock extraction and lag
                self.assertIsNotNone(receipt.t_ack_received_s)
                self.assertIsNotNone(receipt.t_target_window_end_s)
                self.assertIsNotNone(receipt.apply_ack_lag_s)

                # Apply lag is >= 0.19s due to 200ms delay
                self.assertGreaterEqual(receipt.apply_ack_lag_s, 0.19)
                # Target window end is exactly t_apply + evaluation_window_s (1.0s)
                self.assertAlmostEqual(
                    receipt.t_target_window_end_s,
                    round(receipt.t_apply_s + receipt.evaluation_window_s, 4),
                    places=3,
                )
                # Server apply clock is earlier than ACK receive clock by the lag
                self.assertAlmostEqual(
                    receipt.t_ack_received_s - receipt.t_apply_s,
                    receipt.apply_ack_lag_s,
                    places=3,
                )

        asyncio.run(_test())

    def test_all_assigned_itt_counter_brackets_and_survivor_mean_discarded_on_censor(self):
        """Monotone ITT counter brackets with conservative censor interval and survivor mean strictly discarded."""
        from native_campaign_protocol import (
            LiveNativeCohortRunner,
            LiveNativeServingTransport,
        )

        async def _test():
            # Anchor chatcmpl-engine-0002 disappears during the evaluation window (after gate)
            transport = LiveNativeServingTransport(
                initial_budget=32.0,
                missing_native_id="chatcmpl-engine-0002",
                missing_after_s=time.monotonic() + 0.3,
            )
            runner = LiveNativeCohortRunner()
            permit = transport.create_permit()
            async with httpx.AsyncClient(transport=transport, base_url="http://live-native.local") as client:
                receipt = await runner.run_arm(
                    "arm_censored",
                    16.0,
                    transport=transport,
                    client=client,
                    native_client=client,
                    permit=permit,
                )
                self.assertGreater(receipt.censored_count, 0)
                self.assertTrue(receipt.survivor_mean_discarded)
                self.assertIsNone(receipt.anchor_mean_progress)

                # Verify all-assigned denominator N=5 ITT brackets
                self.assertIsNotNone(receipt.itt_mean_lower)
                self.assertIsNotNone(receipt.itt_mean_upper)
                self.assertLessEqual(receipt.itt_mean_lower, receipt.itt_mean_upper)

                # Check individual anchor fates
                censored_fates = [f for f in receipt.anchor_fates.values() if f.get("status") == "censored_disappeared"]
                self.assertEqual(len(censored_fates), 1)
                cf = censored_fates[0]
                self.assertEqual(cf["censor_bounds"][0], 0)
                self.assertGreater(cf["censor_bounds"][1], 0)

        asyncio.run(_test())

        asyncio.run(_test())

    def test_historical_source_registry_refuses_d1bd1e5_candidate_for_source144_train_41_42(self):
        """HistoricalSourceRegistry preserves immutable Source144 for Train 41/42 and verifies candidate for 43/44."""
        from native_campaign_protocol import (
            HistoricalSourceRegistry,
            SourceRegistryRefusalError,
            SOURCE144_CANONICAL_BINDING,
            CORRECTED_OWNER_WRITTEN_JOURNAL_BINDING,
            NEW_OWNER_JOURNAL_CANONICAL_BINDING,
        )
        from pathlib import Path

        # Read actual candidate gateway bytes from mpc-native-owner-written-journal
        candidate_path = Path("/home/daniel_lin/gt/pr32/mayor/mpc-native-owner-written-journal/gateway.py")
        if candidate_path.exists():
            candidate_bytes = candidate_path.read_bytes()
            # 1. Historical Source144 strictly refuses candidate d1bd1e5
            with self.assertRaises(SourceRegistryRefusalError) as ctx:
                HistoricalSourceRegistry.verify_source144_gateway(candidate_bytes)
            self.assertIn("Historical Source144 gateway SHA mismatch", str(ctx.exception))

            # 2. Candidate verifier qualifies candidate d1bd1e5 for future Train 43/44 (no deployment)
            valid = HistoricalSourceRegistry.verify_owner_written_journal_candidate(candidate_bytes)
            self.assertTrue(valid)

        # Read detached historical owner journal bytes
        detached_path = Path("/home/daniel_lin/gt/pr32/mayor/mpc-native-owner-journal/gateway.py")
        if detached_path.exists():
            detached_bytes = detached_path.read_bytes()
            with self.assertRaises(SourceRegistryRefusalError) as ctx:
                HistoricalSourceRegistry.verify_source144_gateway(detached_bytes)
            self.assertIn("Historical Source144 gateway SHA mismatch", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()



