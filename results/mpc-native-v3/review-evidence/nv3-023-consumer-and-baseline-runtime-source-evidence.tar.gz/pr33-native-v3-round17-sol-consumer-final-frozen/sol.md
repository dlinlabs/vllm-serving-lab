# Sol NV3 independent round 1: identifiable outcomes before predictive control

## Status and evidence boundary

Independent proposal and bounded offline audit, not a new synthetic benchmark,
native model fit, ten-hour receipt, qualification pass, or MPC win. No NV3 peer
proposal was read. Scope is this report and its sibling
`native_experiment_audit.py` / `test_native_experiment_audit.py` only.
No Gateway, observer, core, configuration, remote, or GPU change.
Mayor owns Beads, SSH, execution, and paid-resource decisions.

Read campaign at base `10f2fb0`, native-v2
`decision-and-next-native-protocol.zh-TW.md`, my previous
`round3/sol-revision.md`, actual
`../native-identification-and-model-falsification.zh-TW.md`,
`prefill_lab/contracts.py`, and the native-v2 collector.
The serial HTTP-service interpretation remains falsified: the old empty-start
90s arm delivered 2449 natural completions against that model's upper bound
2004. That does not falsify predictive control or all queueing models.
The old commit-progress model did not beat persistence consistently and used
realized sampling gaps, not fixed future horizons.

Mayor's shared new observation is treated as reported native evidence, not
reproduced locally: exact joined UUID, prompt4096/output32/natural EOS; 34
physical steps, two prefill and 32 decode; contiguous executed end4128 versus
delivered input minimum4127. The final placeholder was1, its host forward
wrapper started before EOS and output commit followed EOS, with a matched
executed CUDA forward. The v2 audit is still FALSE. No local raw capture for
this new observation was supplied; the executable test reproduces the
accounting case with explicitly artificial timestamps, not native timing.

Authorized deployment is the sole user Pod RTX4090/24564MiB/driver595.91.07,
vLLM0.30.0, Torch2.13.0, Transformers5.22.1 and restored pinned Qwen4B.
These shared environment facts are not a loaded-revision or performance
attestation. Final heldout160021-160024 is not read, fitted, or evaluated.

## 1. Observable batch state and transition

Use a receipt-cut history, not a claimed fully observed GPU Markov state.
At origin k retain:

| Component | Available state and provenance | Unresolved part |
|---|---|---|
| Admission | Exact UUID/original-cost ledger; pending/applied cap version; command fence; receipt timestamp | Accepted but unmatched native work stays explicitly unknown |
| Queue | Prompt tokens and recipe, admission age, waiting/admitted-not-first bins | Scheduler order not inferred from HTTP residence |
| Decode | Joined physical request, delivered output so far, context/progress bins, most recent batch participation | Residual output/EOS and pending physical work remain latent |
| Batch history | Last received prefill query-token/chunk-size distribution, decoder/context distribution, placeholder count if observable | Post-drain execution spans are labels, not live features |
| Capture health | Source/epoch/clock, dropped/pending/overflow flags, receipt age/width | Missing values are not zero workload |
| Environment | Receipt-qualified runtime identity and available temperature/clock timeline | Old/partial NVML is not complete environmental control |

Costs16/32 are whole-request reservation budgets, NOT concurrency, scheduler
token limits, or KV bytes. Exact transitions retain old costs on cap reduction:

```
R_next = R + sum(actual admitted original costs) - sum(actual released original costs)
admit only when R + original_cost <= actually_applied_cap
```

No extra overshoot allowance and no forced eviction when `R > reduced_cap`.
Engine EOS, HTTP terminal, output commit, and ledger release remain separate
events. Use native host timestamps only within their qualified domain; join
client/native clocks by exact identity and receipt brackets, not subtraction.

Predict the distribution of cost release, first-content deadline passage,
natural complete-good count, physical progress, and tail incidence jointly
conditioned on this history and a supported assigned cap program. A bounded
stratified/regularized direct response model is the first candidate; a
batch-aware semi-Markov extension is warranted only if phase/history ablation
improves block-held-out forecasts. This report does not implement or fit either.
Latent EOS/tail uncertainty is retained rather than assigning every output
token a deterministic exclusive-service coefficient.

## 2. Useful, physical, and tail-work accounting

Keep the v2 `audit_capture` untouched, including its equality failure. A new
versioned descriptive ledger can reconcile without retrospectively passing it:

* **Delivered-useful input minimum**: `prompt + delivered_output - 1` under the
  declared no-cache/no-speculation protocol. This is a token-position minimum,
  not measured GPU demand or exclusive service duration.
* **Physical input work**: contiguous, exact matched scheduler/worker input
  positions/counts with resolved executed CUDA forward evidence. Preserve
  all34 steps and their identity; do not delete the final step.
* **Undelivered tail input**: physical positions beyond that minimum, with
  request/step evidence that no delivered output came from that work. A
  placeholder alone is insufficient. Label unexplained excess as failed,
  not generic "async tolerance."

The bounded `work_accounting` diagnostic supports only the shared
one-placeholder extra-input case: exact single extra position, matched
execution, native host clock, forward wrapper start before EOS, commit at/after
EOS, and independently determined no delivered output from that step.
It outputs4127/4128/1 and `old_final_progress_equal=False` for the structural
fixture, with qualification explicitly false. Extra/gapped/replayed/unmatched
work fails closed. Those timestamps do NOT place GPU execution on the host
clock: GPUelapsed is a relative current-stream span, not an absolute clock,
other-stream coverage, or complete sampling/transport service.

Mayor's future adapter must retain raw scheduler and worker rows, verify
actual_tokens/counts/positions, EOS/output mapping, step digest and worker/run
identity before normalization. Caller-provided booleans are attestations, not
independently verified native joins. OFF captures without step evidence can
qualify outcomes but cannot qualify this physical ledger.

Falsification experiments, not relaxed acceptance:

1. Repeat natural EOS with different actual output lengths, prompt lengths
   and observed batch compositions. Predict zero/one tail incidence before
   seeing labels; distinguish useful decode steps from physical decode steps.
2. Include mixed prefill/decode and pending-async cases. Test whether excess
   is always the last one-placeholder input or sometimes an earlier/multi-step
   phenomenon; the latter invalidates this bounded reconciliation contract.
3. Stop/abort/length-finish controls remain separate cohorts. Their drain work
   must not be mislabeled as natural EOS or dropped from costs.
4. Independently verify no repeated/gapped positions, no mismatched actual
   worker counts, and executed versus merely scheduled extra work. Deep-trace
   confirmation in a separate diagnostic epoch may qualify execution scope,
   but does not establish unprofiled timing or observer equivalence.

## 3. Response, uncertainty, and full-offered outcomes

Freeze every offered logical ID, physical HTTP-attempt UUID, prompt recipe
SHA, prompt/output limits, scheduled origin and window before execution.
Each physical attempt occurs once globally; identical logical trace IDs across
paired arms are intentional. Do not reoffer after ambiguous BEGIN/POST.
Retain a terminal/censor row for every offer; missing/extra/duplicate rows fail
the audit rather than improving a conditional denominator.

Natural complete-good requires positive integer output, exact successful Chat
UUID, complete non-error stream, finite ordered same-client-clock chronology,
matching prompt/limits, stop reason plus independent native EOS evidence,
scheduled-origin TTFT<=0.5s and request-mean
`(terminal-first)/(output-1)<=0.05s`; one token has TPOT0.
Last chunk is NOT substituted for terminal. Token-gap/P99 claims are absent.
Length-finished outputs are labeled truncated and count0 for this frozen
natural-complete primary outcome; report their complete response counts
separately rather than discarding them. Reject/error/cancel/client timeout
count0. Timeout is a resolved HTTP failure, not proof the engine drained:
physical-work and release labels may remain censored.

Right-censoring yields lower/upper good-count bounds, not assumed success or
imputed native completion. A first token already past TTFT has upper0.
Otherwise conservative upper1 is retained. Report late drain completions in
the original offered cohort; dividing cohort good by its offered window is
not a steady-state capacity claim.

Joint predictive uncertainty should use whole held-out block trajectories,
not independent token/request residuals. Fit on Train; choose features on
grouped Train folds; calibrate on disjoint Calibration blocks; select policy
and continuation only on Development. Report empirical coverage and miss
rates with the block count, not certified chance constraints.

## 4. One-step, multi-step, action ranking, and OOD evaluation

Log forecasts at fixed origins before labels exist, with source hash, model
hash, feature receipt cut, plan, and prediction publication time. Do not input
realized future sampling gaps, final output lengths, post-drain spans, future
offered tapes, or outcomes of paired counterfactual arms.

Primary predictive endpoint: then-live cumulative original-cost release at
1/3/5s, normalized by positive origin reservation and averaged per independent
block. Zero-reservation origins are a separate stratum. Secondary: natural-good
count errors, deadline Brier/reliability, physical/tail incidence, joint
trajectory coverage and ranking of actually supported plans. Predicting token
progress well does not establish release accuracy or control goodput.

Compare ledger/history-only, persistence, hold-current empirical response and
batch-history extension under identical origins and labels. Publish one-step
and free-running multi-step errors separately; do not feed actual intermediate
states to a purported multi-step rollout. Assess calibration before maximizing
over plans, because ranking/selection can exploit model error.

OOD: withheld prompt/output combinations, unseen mixture/order, burst and
recovery, accepted-unmatched work, altered observer source/epoch and available
thermal/clock shifts. Bounds must come from qualified Train/Calibration support,
not invented KV thresholds. Abstain on missing identity, stale/unknown work,
unseen history/action support, unresolved labels or capture overflow.
Reject fitting if supported binding states are too few; state aliasing is a
measurable limitation, not a reason to invent latent features.

## 5. Strong One-move versus MPC, causal support, safe deployment

Only after model qualification, compare Fixed16, development-selected
best-supported-fixed, development-selected reactive, strong One-move, and MPC.
One-move and MPC share 5s forecast window, same uncertainty trajectories,
future-arrival LAW (not realized tape), constraints, tail scoring, control
frequency, and development-frozen continuation. One-move frees its first move;
MPC may free two/three future moves only where sequence support exists.
Both apply just their first move and replan at the same rate. No deliberately
poor Fixed16 continuation or short-window straw baseline.

First run randomized open-loop LL/LH/HL/HH cap16/32 sequences from verified
drained starts, paired common offered tapes within fresh independent workload
blocks, randomized arm order with washout/drain and exact application fences.
Include literal-disabled/enabled-OFF/LIGHT ablations in separate service
epochs and same-action repeats. Repeats estimate within-block EOS/observer
variation, NOT independent seeds. Actual batch composition is a mediator:
randomized nominal bursts do not make a batch-duration causal coefficient.
Sequence ITT effects do not license rolling same-state counterfactuals after
states have diverged; unsupported policy plans remain masked.

Before closed-loop outcomes: freeze configuration hashes, metric, contrasts,
minimum useful effect, independent-block sampling and randomization, handling
of censoring, multiplicity and precision plan from Development variance.
The paired module estimates equal-block right-minus-left natural-good/window,
block-resampled approximate percentile95% CI and exact two-sided block
sign-flip p for a sharp no-effect null under the stated exchangeability design.
This exact enumeration specifically requires independent fair pair-order
coins and no carryover/order-by-policy effect after qualified washout. A
balanced/constrained randomization has a different assignment space and must
not be passed to this routine as independent flips.
It rejects cloned block/seed/randomization unit, repeated logical tapes,
physical UUID reuse, mismatched paired tapes/windows/SLOs, changed frozen
comparison configuration and unrandomized declarations. It withholds CI/p
whenever any offered outcome is censored.

These are guards against obvious pseudoreplication, NOT proof of physical
independence, random assignment, or truthful provenance. Mayor must verify raw
receipts and actual independent block generation. Equal synthetic effects can
produce a degenerate bootstrap interval; it is not a variance or significance
guarantee. Four independent pairs have minimum two-sided exact p0.125, not
0.05. No "superior", "equivalent", or "MPC impossible" classifier exists.
The exact sign-flip routine intentionally caps at16 blocks; a larger frozen
final protocol needs a separately reviewed inference implementation, not
splitting into batches or silently treating approximate p as exact.
Do not take this exploratory pairwise p as multiplicity-adjusted evidence for
winning against all baselines.

Report offered/accept/reject/failure/natural/truncated/censored counts, SLO
quantiles, tail work, action binding incidence, affected offered mass, ranking
errors, full observation-to-solve-to-persist-to-POST-to-fence cost, deadline
fallback, oscillation and recovery. Small first-action disagreement is not a
bound on benefit without affected mass and outcome consequences.

No deployment authority from this module. Candidate first runs shadow-only,
then a separately permitted bounded trial with rollback to the best
development-supported fixed/reactive policy. Keep existing expiry, memory,
timeout, observation completeness and source fences. Unknown work or OOD
invokes qualified fallback; lowering cap does not evict old reservations.
Uncalibrated KV/joint risk is not declared hard-safe. Mayor alone runs GPU/API
work and manages paid time; no claimed ten-hour elapsed experiment or quote.

## Local source/test receipt

Owned directory: `experiments/mpc-research/native-v3/`.
Exact implementation/test SHA256:

```
6abb94a4fbc1f3e238cd2d4687e996829304afe669b38efba14f2ca29074a554  native_experiment_audit.py
da6705c687e8d4fa8aa3df072e751f6c141d1f300e4d9eb5f374b51c289ee96e  test_native_experiment_audit.py
```

Executed local command:

```
python3 -m unittest discover -s experiments/mpc-research/native-v3 \
  -p test_native_experiment_audit.py -v
```

Result: **15 tests passed**, CPython3.14.4; outcome, clone/leakage,
randomization, exact four-block p floor, censored inference, and physical
tail counterexamples. These are standard-library CPU unit tests, not native
measurements. `python` was absent and `python3 -m pytest` reported missing
pytest, so the existing unittest-compatible tests were run with the built-in
runner without installing or changing dependencies.

Full Linux CPU acceptance was not executed: it requires CPython3.12, a clean
checkout and local port checks; this assigned offline scope forbids socket
exploration and includes pre-existing untracked `.beads/` / `.runtime/`.
No full-suite, lint-tool, GPU, deployment or statistical qualification claim.
Those pre-existing paths remain untouched. Only the three owned files are
staged for a local commit with the Copilot trailer, retained for Mayor review.
Mayor can retrieve its exact commit from this branch's HEAD and independently
check the recorded implementation/test hashes. Bead status is not mutated:
Mayor retains in_progress for peer review.

Persistence receipt: the environment automatically checkpointed the owned
source/tests/report before the explicit commit attempt; that attempt found
nothing staged. Verified checkpoint
`c8ef4ce06a36d381882ecf68799913855923bcde` contains the exact source/test hashes
above and matches the worktree. This receipt update is committed separately
with the required Copilot trailer; existing automatic commits are not amended.

## Round 2: frozen-peer review and owned surgical corrections

### Evidence update and review boundary

Read all three frozen reports, complete implementations and focused tests,
not just their passing receipts. Reviewed R1 commits:
Opus `17f62c71aadd8fdcea8d017498ce34fdb13e08cc`,
Astra `a51404649e5fcec8338720371abc3d842ebd5b7b`,
Gemini `4c53d40ed7a8300a0d5eb8c1b0b5ab590d503e15`.
The replay helper verifies all six source/test SHA256s before importing them;
it never patches or writes peer files. Findings refer to those frozen bytes,
not a peer's later repair. No new experiment or peer agreement is invented.

Mayor now reports actual qualification at `2587d2b`:16 executed arms,
40 HTTP complete,40 natural EOS, all16 v3 audits valid,8 old v2 audits FALSE
retained,20 explicit tail tokens. Accept this as **reported capture/HTTP/drain
qualification**, superseding the R1 "not yet qualified" status at that time.
I did not rerun it or inspect the separate Mayor accounting implementation.
It is NOT prediction, MPC, observer-overhead, absolute GPU-clock, exclusive
service, independent efficacy, or ten-hour qualification.

In the tables, `Opus`, `Astra`, `Gemini` source abbreviations mean respectively
`native_release_model.py`, `native_response_planner.py`,
`native_campaign_protocol.py` in their frozen artifacts. Replay output contains
15 named counterexample groups; bool-output and post chronology are two
distinct cases grouped in one result.

### Opus: useful response candidate, incomplete qualification

| Source | Finding / reproduced witness | Disposition |
|---|---|---|
| `Opus:72`, `_native` | Adding foreign native clock and run IDs to every otherwise valid frame still produces origins. Gateway identity is checked; native clock/epoch/source is not. | Reject the report's same-run/same-clock qualification claim for this parser. Require actual native provenance before feature availability or any cross-domain arithmetic. |
| `Opus:169`, `ledger_releases` | Change a release effective time to -100 while the mark remains live at origin0: dataset truth is still `(1,1)` released by1s. Sequence conservation does not enforce event-time chronology or release-after-admit. `_marks:49` also does not require positive prompt count or first-after-admit. | A negative/retroactive release is not exact ground truth. Preserve the failure; require monotonic effective times and consistent snapshot/event brackets. |
| `Opus:93`, `_planned_budget` | Plans L-at0/H-at.5/L-at1 and H-at0/L-at.5/L-at1 have identical averaged cap features at1/3/5s:24,18.6667,17.6. | Order-dependent responses cannot be distinguished by these plan features. This is a representational alias, not proof that their native outcomes differ. Keep assigned sequence/order features or abstain if a native contrast separates them. |
| `Opus:320-331`, support envelope | Two-short and two-long homogeneous Train origins admit an unobserved short+long mixture with `ood_reasons=[]`. Marginal ranges and a set of individual shapes are not joint mixture/history/sequence support. | Reject "never extrapolate outside Train support" as a general guarantee. Report the actual envelope and test joint-support failures separately. |
| `Opus:460`, calibration | With the same two Calibration blocks, repeat origins of the positive-residual block20 times: lower band changes from-.5 to+.5. No independent block was added. | It pools origin residuals, not block residuals. This is not block-balanced calibration or a split-conformal guarantee. Freeze cadence/weighting and use block trajectory scores for a block-level claim. |
| `Opus:523`, tail accounting | The peer's baseline fixture returns `tail_accounted=True` without CUDA resolution, placeholder, clock or output-commit/discard evidence. Duplicate worker keys are also collapsed into a dict. | Counts/positions and schedule-before-finish are necessary but do not prove the asserted executed/discarded tail mechanism. Do not promote this thin accounting flag into raw native qualification. |

Accept the Train-only fit and reserved-final seed guard, equal-block evaluation,
whole-origin-cost bounds, exact cost-tie ambiguity rather than invented UUID
release assignment, and explicit absence of native/MPC acceptance. The stable
sigmoid is preferable to naïve exponentiation. However, the Newton fitter has
no reported convergence/conditioning certificate; model predictions still
need finite/convergence diagnostics on actual Train data. Fitting pooled
origin/mark rows is not independent-block fitting simply because final scores
are aggregated by block.

Per-horizon mean release forecasts are not a joint stochastic transition
kernel. Three-offset cummax is useful monotonicity, not calibrated whole-cost
trajectory scenarios. A time-average cap coefficient is not a causal slope,
especially after differently assigned histories diverge. Passing individual
shape/range checks does not qualify new rolling MPC sequences.

### Astra: strongest interface boundaries, still not an adapter or model

| Source | Finding / review | Disposition |
|---|---|---|
| `Astra:212`, state validator | A known decode mark with `native_running=0` still gives `status="shadow"` under the peer's stub, with `active_permit=False`. There is no consistency check between native counts and marked native stages. | Reproducible adapter-validation gap, not an active-actuation exploit. An atomically joined physical prefix must reconcile stages/counts; if timestamps make the relationship uncertain, retain unknown work and abstain. |
| `Astra:248,276` | IDs bind supplied objects and aggregate counts, not loaded source/revision, received history, raw natural-EOS outcomes, support, or calibrated uncertainty. | Accept the explicit external-artifact boundary. Nonempty receipt IDs are not independently verified attestations; the future adapter/model owner must audit them. |
| `Astra:326` | Six calls and checks before/after callbacks do not preempt a hung callback. Planner elapsed excludes upstream observation/features and downstream persist/POST/fence. The report explicitly says so. | Accept this limitation; do not claim a native100ms/full-path runtime guarantee. Deadline origin, watchdog and last-moment epoch/version recheck remain deployment prerequisites. |

Accept exact whole-cost admission/release, preserving reservations on a cap
drop, shared immutable evaluation/scenario pairing, original-ID release sets,
tail-versus-model-error separation, missing-plan abstention, strong common
continuation and always-inactive permit. No new synthetic plant is hidden
behind the planner. Bounds are reporting envelopes, not proven risk limits.

Important mathematical boundary: the one-prefix and two-prefix families start
the same reactive continuation at different times and are not automatically
nested. Even with exact forecasts, open-loop two-move value is not a theorem
about gain when both algorithms replan every second. Keeping One-move for the
same first action is reasonable; empirical closed-loop gain still requires
randomized full algorithms. The planner's actual model/support/OOD behavior
is delegated to `predict`, not implemented by its string IDs. I do not claim
this interface already predicts or enforces native KV safety.

### Gemini: reject the implemented superiority/campaign claims

| Source | Finding / reproduced witness | Disposition |
|---|---|---|
| `Gemini:120`, work accounting | It converts exclusive forward end4128 into4129 physical positions, and `P+O-1` into `P+O` "useful" work. End100 clips missing useful work to tail0 while returning the same placeholder-cause string. | Off-by-one and missing-work concealment. A scalar endpoint/default constant cannot validate contiguous worker steps or a CUDA/EOS mechanism. Correct shared count is4127 minimum/4128 physical/1 tail. |
| `Gemini:172`, clock semantics | `active_concurrent_requests=2` alone sets serial-model-falsified. Two simultaneous HTTP offers can queue behind valid serial .1s service intervals `[0,.1]`, `[.1,.2]`; residence .1/.2 includes waiting. | Retain the actual old drained-start capacity falsification, not this generic concurrency test. Aggregate elapsed cannot establish GPU/host order or exclusive per-request demand. |
| `Gemini:232`, outcome validator | Both boolean output and a POST at100 after first10.1/terminal10.12 are scored good. `stop` alone does not audit a complete exact-UUID native-EOS response. | Zero and NaN fixes are insufficient: strict integer type, POST chronology, full stream/UUID/EOS joins and explicit full-offered censoring remain necessary. |
| `Gemini:488`, ledger | Admit the same cost8 record twice, release once: reserved8 with zero live marks. Mutable records can also change the cost subsequently subtracted. | Fails UUID uniqueness/original-cost conservation. Do not mask negative/corrupt releases with `max(0,...)`; retain immutable admission costs and fail on duplicate/reuse. |
| `Gemini:319,344`, evaluator | Four distinct-ID aggregates with offered1 but10–25 good completions, `min_blocks=4`, one Monte Carlo draw return `CONFIRMED_SUPERIOR`, p0. Exact four-pair floor is.125. | Aggregate counts are not validated against raw offers. Monte Carlo p0 is not an exact p or defensible superiority receipt. Default6 is not power, and configurable minima are not independent sampling proof. |
| `Gemini:344`, statistical claims | Zero variance is called artificial replication; no CI or Holm implementation exists in the complete source. Mean>=margin plus a zero-effect p does not establish a statistically supported minimum practical effect. | Equal independently generated differences can be genuine. Identify blocks/physical provenance rather than rejecting all equal outcomes. Freeze contrasts/multiplicity and distinguish null0 from a useful-effect margin. |
| `Gemini:640,653`, comparators | "MPC" returns the same cap32 for horizon1 or5; both horizon and One-move continuation parameters are unused in decisions. Functions contain backlog heuristics, no forecast/sequence objective. | Reject these labels as implementations of strong One-move/MPC. Merely returning16/32 does not test predictive control or a fair common continuation. |
| `Gemini:737`, duration | With offered duration0 and maximum drain120, all320 schedules are empty but hours_requirement_satisfied=True at10.6667h. Default offered time is only8h; the remaining2.6667h is maximum drain. | Planning capacity is not actual informative duration. This output cannot satisfy the user's actual>=10h requirement or account for execution, setup, idle, failures or real drain. |

Further source-based limits: the purported immutable protocol is a mutable
dict with a stored hash, no later verification/freeze enforcement. Episode
tape keys are not emitted frozen arrival/prompt contents or physical UUIDs.
Mixed/burst/shift descriptions/rates do not become executable mixture/arrival
laws in the generated episodes. The same `unseen_ood_mix`2048/384 shape is
included in Train and Final; that alone is not withheld-shape OOD. No actual
state-support validator or OOD abstention precedes the heuristic decisions.
Calling Fixed16 "safe" without current epoch/expiry/unknown-tail/recovery
evidence is unsupported; lowering cap never evicts old costs. Unsupported24
in a best-fixed example needs fresh action qualification, not promotion from
the16/32 grid. Nominal6req/s is not measured120% native capacity.
These flaws do not imply that predictive control is impossible.

### Owned Sol corrections and limits retained

The replay also confirmed two defects in my frozen R1:

1. Four positive effects scaled to1e-15 give p1 instead of.125 because of the
   absolute1e-12 comparison tolerance. Round2 enumerates sign swaps using exact
   `Fraction(count_difference)/Fraction(recorded_window)` sums; effect/CI
   reporting remains floating point. This preserves ties and scale invariance
   for the declared input numbers, without making independence a theorem.
2. Interpolating between -1e308/+1e308 overflows their difference: frozen R1
   emits `[inf,inf]`. Round2 uses convex weighted interpolation; the adversarial
   test selects both endpoints and now requires finite intervals.

Also require an explicit common partition before paired analysis, reject the
reserved old final seeds before reading outcomes, reject oversized nonfinite
integer timestamps as ValueError, and require per-request host forward starts
not to regress or begin at/after natural EOS. The last rule is a conservative
host-order consistency gate, NOT a GPU execution-before-EOS assertion.
No other path, old audit, peer source, controller or native collector changed.

Remaining limitations are intentional and explicit: declared independence,
pair randomization/config hashes and `native_eos_verified` do not authenticate
raw events by themselves. Missing rows fail; censoring withholds inference;
bootstrap95% is approximate and can degenerate for genuine equal effects.
The exact null concerns zero effect under independent fair label/order swaps
and qualified no-carryover, not equivalence, power, useful-margin proof or
joint superiority against five baselines. Larger/constrained assignment
spaces need a separately frozen analysis. This module has no actuation permit.

### Unresolved disagreements and discriminating native experiments

| Question | Discriminating experiment / required outcome |
|---|---|
| Does one-placeholder accounting explain all qualified natural cases? | Keep all raw steps/EOS/commit lineage in short/long/mixed repeats and cancel/length controls. Test extra0/1/multiple positions, post-EOS launches and duplicate/gapped/unresolved workers. A generic+1 allowance is not an explanation. |
| Does cap order matter beyond its1/3/5s average? | Randomize the equal-average LH/HL first-second pair with identical origin/tape and common continuation. Publish release/good forecasts before outcomes. If responses separate by order, average-only plan features are falsified; if not, report precision, not universal equivalence. |
| Can marginal feature boxes qualify mixtures? | Train on homogeneous short/long, withhold mixtures and burst/recovery histories. Log support flags and block-held-out release/count/ranking errors plus abstention coverage. This tests the demonstrated accepted-unseen-mixture alias. |
| Are calibration bands stable under cadence/blocks? | On the same sealed data, change offline origin sampling cadence without adding blocks; compare origin-pooled and whole-block trajectory calibration, then evaluate fresh independent Calibration/Development blocks. No extra GPU time is needed for the resampling diagnostic. |
| Are count/stage/tail observations complete at the decision cut? | Join Gateway/native snapshots by exact IDs and recorded receipt brackets; replay delayed observation, accepted-not-visible, cap-drop and reservation-empty-but-pending-forward cases. Count/stage conflicts must become unknown/abstain, not fabricated fully observed state. |
| Does extra planning improve actual closed-loop outcomes? | After model/continuation support, randomize complete strong One-move/MPC algorithms at the same cadence, law, horizon/tail, offered cohort and full-path runtime cost. Report binding mass, policy disagreement consequences and independent block effects, not the stub's open-loop scores. |
| Has informative native experimentation actually reached10h? | Maintain actual start/end/clock/epoch/source-linked intervention and executed-drain receipts, union overlapping intervals on the sole GPU and retain invalid arms. Separate actual experiment duration, GPU span labels, setup, idle and billing time. Planned schedules/max drain alone are never added as executed time. |

Mayor alone executes these interventions. Current16-arm capture qualification
does not answer these model, observer, causal, precision, duration or deployment
questions. No physical decomposition or elaborate predictor is accepted by
consensus, and no peer's passing unit suite supplies missing native evidence.

### Round2 source/test receipt

Final owned implementation/test SHA256s:

```
44423a5d76782da9d9118ddacbdb94e82d6963b70a65dfdf95d4e82d5487251d  native_experiment_audit.py
336d298fdc766618e126ce19c952ee1ccb3057f061041a575d07d6e53aeb6bf6  test_native_experiment_audit.py
```

Executed `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover
-s experiments/mpc-research/native-v3 -p test_native_experiment_audit.py -v`:
**19 tests passed**, no skips. Separately, all15 named peer witness groups and
all six frozen source/test digests verified successfully:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=experiments/mpc-research/native-v3 \
python3 -c 'import json,sys; from test_native_experiment_audit import peer_counterexamples; print(json.dumps(peer_counterexamples(sys.argv[1]), sort_keys=True, indent=2, allow_nan=False))' \
  /path/to/pr33-native-v3-round1-frozen
```

Executed against Mayor's supplied frozen directory. Portable unit tests do not
require that external archive; the pinned-peer replay deliberately does.
The two numerical regression cases were separately run against frozen Sol R1
and produced p1 / `[inf,inf]`, so they are not tests that only restate the fix.
All reproduction is CPU contract evidence, not new native performance.
Local commit only; Mayor retains in_progress for peer review.

## Round 3: actual comparison binding and individual peer responses

### Frozen evidence and corrected native facts

Read all other R2 reports and their actual source/tests. Reviewed commits:
Opus `fb7e517904bc001802010271972954198a8532f2`,
Astra `d0ad27503f1b7a59bffaadebcffcafa0ceff7715`,
Gemini `c04cd0ab1265fc97930d63e8692a30a3504bf0e8`.
The new `round3_counterexamples` verifies eight frozen R2 source/test digests,
including my own R2, before executing thirteen named CPU witnesses. These are
reproducible contract findings, not a consensus or native performance result.

Mayor's correction is decisive: of the forty qualifier requests, only twenty
LIGHT requests have physical GPU-work labels, and all twenty have one overhang.
The twenty OFF requests have **no physical tail measurement**, not zero tail.
Thus twenty tail tokens divided by forty HTTP completions is neither a tail
probability of0.5 nor evidence of stochastic zero/one variation. The sixteen
arms/forty HTTP/natural EOS qualification at native source `2587d2b` establishes
capture/HTTP/drain, not a universal one-token mechanism or MPC benefit.
The old v2 failures remain preserved; GPU elapsed is not an absolute timestamp
or an exclusive service duration.

Additional Mayor-reported execution facts, not independently rerun here:
controlled `87` smoke922 offered/648 EOS/274 rejected/48s; managed `6c`
smoke922 offered/650 EOS/272 rejected/48s, two Gateway epochs, cleanup verified.
The long `6c` driver is running;400x120 offered windows/48000 planned seconds
do not establish ten actual experimental hours. Native source is `2587`,
collector/Gateway `6c`, core unchanged. The operation cache is **in memory**,
rollover occurs every two episodes/one paired cell, and the1024 ceiling is
unchanged without relaxation or eviction. Gateway run ID changes at rollover;
the same Pod boot/time namespace retains the same ClockDomain.

First-Train diagnostics reported by Mayor:765 strict receipt-joined frames;
3034/13280 mark observations are accepted-but-not-native-visible even after
canonical ID normalization. This is a mark-observation count, not an origin
abstention rate, independent sample size, or forecast error. Full joint data
availability does not imply all physical work is visible. The established
`state_sample.join_observations` and `native_prediction.native_running` use
exact fullmatch of native `chatcmpl-<32hex>-<8hex>` IDs and their Gateway32hex
canonical identity; naive equality and substring matching are invalid adapters.
Online availability uses receipt stamps, not retrospective event knowledge.
Gateway `scheduled_at=None` cannot serve as my HTTP offered-origin timestamp.

Individual-episode inspection was limited to the first Train181001 artifact's
identity/schema and byte digest, without fitting, joining or requalifying its765 frames:
`nv3-181001-p128-m128-arm0.json`,
SHA256 `d633b4e402e453238b0d612b3b64c198d61fe572eb9c3b171cbb76a616187c23`.
No Calibration/Validation/Final outcome was read or tuned against in R3;
Train181001..181016 is the authorized diagnostic range and old
Final160021..160024 remains unused.

### Additional first-Train descriptive evidence, without metric retuning

Read Mayor's `first-train-block-descriptive-diagnostics.json`, source
`6c11fe7e683439f379f0dfdbd21b05f5873b2c90`, SHA256
`0f072b7f2d0feb64e21bae78b943b6ad1845e8cd85e12bf6b2585b3fa92156e9`.
The five cells each describe two120s episodes in one seedblock181001:

| Cell | Offered / natural EOS / reject / reported good | TTFT p50 / p95 (s) | E2E p95 (s) | Maximum observed KV |
|---|---|---|---|---|
| p128/m128 | 7850 / 5346 / 2504 / 5015 | .232 / .519 | 1.249 | .064 |
| p128/m256 | 2588 / 1840 / 748 / 1839 | .126 / .219 | 1.563 | .046 |
| p4096/m128 | 1850 / 584 / 1266 / 213 | .607 / 1.097 | 2.829 | .371 |
| p4096/m256 | 648 / 344 / 304 / 222 | .423 / .776 | 3.241 | .322 |
| mixed | 1146 / 826 / 320 / 675 | .331 / .684 | 2.605 | .372 |

These are correlated assigned-sequence descriptions, not five independent
seedblocks, per-arm causal effects, Fixed-cap results or a native MPC result.
The supplied good counts are reported diagnostics, not a rerun of this auditor's
raw-wire/source/config/EOS checks. TPOT in the artifact is a request-level
mean, not a physical decode-step distribution. Neither native capacity nor a
120% capacity anchor is inferred from the prespecified offered-rate references.
TTFT SLO.5s and TPOT SLO.05s remain unchanged despite these quantiles.

Cap16 observations still carry prior reservations>16 in112/795 short
p128/m128 observations and363/909 prefill-heavy p4096/m128 observations
(about14%/40%). These time-correlated descriptions support the actual
non-eviction/transient-reservation-memory observation, not independent
Bernoulli probabilities or the effect of Fixed16. Observed KV maximum.372
does not qualify full-pressure/preemption/OOM behavior or a hard safety bound.
The ten displayed episodes imply1200 offered seconds; the artifact separately
records a snapshot-level1560 completed actual offered-window seconds without
allocating the extra360 to its displayed first-block cells. Keep those scopes
separate and verify raw interval/epoch coverage before duration qualification.
Neither quantity is ten hours, and neither is GPU-exclusive demand or paid time.

The current one-second move interval is a hypothesis, not a proven control
timescale. These1-3s residence descriptions suggest earlier reservations may
persist across successive decisions. Falsify that hypothesis with
receipt-cut/action-conditioned release responses at1/2/3s and the same
continuation, recording whether a second move can alter still-live offered
work and whether lag/uncertainty erases ranking separation. Do not automatically
increase horizon or modify the running protocol from pooled E2E quantiles.

For a future adapter, prospectively select receipt-stamped cuts before the
next assignment/planned action and verify the prefix against actual applied
ACK/version fences. Preserve CAS delay, actual applied prefix and published
full assigned sequence; do not backdate a delayed action or select a favorable
cut retrospectively. Every input receipt must be<=cut; later releases/EOS and
physical tail labels remain separate outcomes. Gateway marks contain accepted
traffic with `scheduled_at=None`, not the full offered client history: online
arrival-law and offered-origin SLO features need an explicit client-receipt
adapter and availability audit, not an offline oracle.

A future randomized action can have sequential causal support conditional on
pre-assignment history when assignment probabilities, positivity, no
anticipation and actual execution are qualified. Post-action batch composition
is a mediator and cannot be treated as the same pre-treatment state across
different earlier prefixes. For a full preassigned sequence, conditional suffix
support must follow its actual randomization design; average-cap aliases do
not preserve order. None of this descriptive evidence supplies calibration,
conditional support, a causal coefficient or a controller win.

### Astra: accept S1/S2/S3 and repair the actual defects

| Counterexample on frozen Sol R2 | Owned R3 repair and regression |
|---|---|
| S1: offer10, no first content through11, otherwise complete client prefix, retains good upper1. Opus raises the same issue. | Censored absence tightens upper to0 only with `client_prefix_complete=True` and cutoff strictly beyond the scheduled-origin TTFT deadline. Missing/incomplete prefixes retain1; equality at the inclusive deadline retains1. The row remains censored and CI/p remain withheld, including when aggregate bounds collapse. Client timeout already scores0 but does not prove native drain. |
| S2: both arms of block2 change actual TTFT from.5 to.05 behind the same opaque hash; effects `[1,0]` are pooled. | Require substantive configuration and side-specific policy SHA256s; recompute the semantic comparison digest from each actual pair and match the one globally frozen digest. Tests reject changed TTFT, TPOT, window, native source, Torch version or policy, an arbitrary shared hash, and independently re-frozen per-block settings. |
| S3: six identical tapes with renamed logical IDs/UUIDs/seeds/block IDs produce exact p.03125. | Retain identity-sensitive within-pair tape matching, but add a label-free ordered semantic digest for cross-block replay rejection. It binds offset, prompt recipe hash, prompt count and output limit, normalizes numeric offset representations, preserves tied-offer ordering, and rejects out-of-order offers. Relabeled copies now fail before inference. |

The replay calls the immutable Sol R2 implementation, rather than a simplified
replacement. It drops only the two newly required API keywords when preparing
old-schema arguments; the substantive witnesses remain different actual SLOs,
identical semantic tapes, and observed late absence, not API TypeErrors.

`configuration` now requires the pinned40hex model revision; deployment,
boot, GPU UUID, driver, vLLM, Torch, Transformers and dtype identifiers;
native/Gateway/core/cost-model/scheduler SHA256s; and observer mode.
Additional stable settings are also hashed and must match. Process run IDs
belong in episode provenance, not the stable comparison configuration.
This policy comparator intentionally cannot pool changing observer/source/boot
regimes. An observer-overhead contrast needs a separately frozen protocol that
explicitly designates observer mode as treatment, not hidden configuration
differences passed through this API.
`comparison_digest` additionally binds left/right policy hashes, actual
window and both SLOs, the natural-complete endpoint and equal-fresh-block
weighting. It binds declarations, not truth: source-bound receipts and
pre-outcome freeze timing still require external verification.
The bootstrap draw count/seed, assignment space, contrasts, multiplicity and
minimum practical effect must be frozen separately in the analysis protocol;
this digest is not a complete experiment preregistration.

Astra R2's clock-domain/availability/freshness checks are real improvements
over R1. However, a decode mark with zero native-running count still reaches
`shadow` under the frozen stub; `active_permit` remains false. The state adapter
must reconcile the received physical prefix or mark the disagreement unknown.
Cooperative callback checks are not a hard watchdog, and planner elapsed does
not include observation/features/persist/POST/fence. The response model,
joint uncertainty, support and deployment receipts remain external interfaces.
The repaired Sol audit supplies none of those missing native qualifications.

### Opus: accepted censor criticism, retained provenance/support boundaries

Accept S1 conditionally as above. A no-first complete observation beyond TTFT
proves natural-good is impossible; an incomplete SSE prefix does not.
This is endpoint-bound tightening, not a native EOS/drain assertion.

R2 improves missing-history representation and requires tail commit at/after
finish. Both are useful. The new replay still obtains origins with explicitly
foreign native clock/run fields, accepts a retroactive release time-100 as
truth `(1,1)`, and aliases order-distinct LH/HL plans at all three average-cap
horizons. These are thin-adapter/representation limitations, not proof that
the real native LH/HL outcomes differ. Use the established receipt join and
exact canonical IDs before presenting a physical qualification; validate
ledger chronology before using releases as training truth.

Marginal shape/range envelopes still do not prove joint mixture, history,
sequence or unknown-work support. Horizon-specific censor exclusion can
change the cohort and make a reported train release fraction decrease with
horizon; it is not a coherent joint trajectory probability without an explicit
common cohort/selection model. Origin-pooled calibration is not block-balanced
or a whole-block coverage guarantee. Missing-native and missing-history flags
may support a useful partial-observation predictor, but only demonstrated
Train-conditioned support and later sealed block evaluation can justify that
use; the3034/13280 visibility diagnostic alone cannot qualify or falsify it.

Tail count/positions and commit brackets remain insufficient to authenticate
the discarded-placeholder mechanism without matched raw scheduler/worker/CUDA
and output lineage. My own booleans are also attestations: the bounded
diagnostic does not independently authenticate a native trace.

### Gemini: distinguish deliberate limits from numerical/factual defects

The exact routine's2..16-block bound is a documented fail-closed boundary, not
permission to split thirty-two blocks into pseudo-experiments. A new
preregistered Monte Carlo protocol can be legitimate, but must explicitly
declare approximate inference, assignment space, draw count, seed, resolution
and Monte Carlo uncertainty. It must not silently replace exact enumeration.
The frozen R2 Gemini exact branch still reports p1 for four positive1e-15
effects; the scale-invariant correct exact p is.125. My R2 rational comparison
and its regression remain unchanged.

The independently rounded timestamp example is real:
`1700000000.123 + .1` differs from literal `1700000000.223` by
`2.384185791015625e-7` seconds. The new replay uses the actual current auditor:
the source-computed scheduled stamp passes, the independently rounded literal
fails. I retain that explicit source-copied planned-origin contract, not a
claim that independent floating arithmetic is identical. A future raw adapter
needs a declared exact tick/source stamp representation or reviewed bounded
absolute quantization rule; broad relative tolerance at epoch-sized values
would mask materially wrong schedules. This interoperability limitation is
not silently fixed by weakening chronology.

Four additional actual-source witnesses: empty qualification records still
produce the hardcoded stochastic-tail claim; the default epoch contains four
episodes rather than the actual two; NaN "realized" duration is classified
`Qualified`; and its scaled exact-p defect persists. The first is refuted by
twenty LIGHT/all-one-overhang versus twenty OFF/unmeasured, not by another
model's opinion. Planned duration or an unattested scalar cannot establish
actual>=10h, and a nonfinite scalar cannot even pass numerical validation.
R2's SQLite/new-ClockDomain narrative is also contradicted by actual runtime
facts stated above. None of these diagnostics constitutes a GPU experiment.

The original full-offered/boolean/POST-chronology/ledger/count-conservation and
heuristic-controller concerns remain. Helpers that restate simplified
Sol/Astra logic do not demonstrate how the frozen implementations behave.
A minimum practical effect is a different null from zero; point mean>=margin
plus a zero-null p is not margin-supported superiority. No manufactured
agreement against all t/asymptotic methods, universal tail law, or impossibility
of MPC is endorsed.

### RETAINED DISAGREEMENTS and discriminating experiments

**Fresh-workload versus fixed-tape estimand.** Independently randomized
executions of one genuinely fixed tape can be legitimate stochastic replications
for a conditional fixed-workload effect. They are not fresh-workload blocks;
this module deliberately rejects semantic repeats for its declared estimand.
Unique hashes cannot prove independence: the actual block generator,
randomization and no-carryover evidence remain externally verified.
Fresh independent discrete workload draws can also coincide; duplicate
rejection is not proof of dependence. This routine rejects the whole comparison,
not selected blocks. Any uniqueness-screened workload law must be preregistered
as a distinct target from unrestricted IID workloads, never selected after
seeing outcomes or disguised by relabeling.

**Known-bad censor versus terminal completion.** A separately preregistered
analysis might permit inference when the binary endpoint is identified despite
an unresolved native lifecycle. This conservative routine still withholds
point inference on every censored full-offered row; it never imputes success.

**Tail mechanism and partial observation.** The bounded useful/physical/tail
ledger accepts zero excess or the explicitly evidenced one-placeholder case,
not arbitrary+1 relaxation or a universal stochastic distribution. Keep old
audit failures and test other excess/launch/commit patterns. Partial state can
be predictively useful, but missing physical work must stay represented and
must not turn receipt availability into full observability.

**Prediction versus causal closed-loop value.** Conditional release forecasts,
open-loop plan ranking and same-first-action scores do not establish gain over
strong One-move when both algorithms replan. Freeze identical continuation,
outcome definition, robust joint support and full-path deadline accounting;
then Mayor can run randomized full-policy comparisons with washed-out paired
cells. No active permit, hard KV safety or native solver-overhead bound is
granted by any current CPU contract.

Discriminating native work remains Mayor-owned: order-matched LH/HL contrasts
with pre-outcome forecasts; joint-mixture/history/missing-visible support
ablations using exact receipt cuts; raw tail-lineage checks on measured LIGHT
and appropriately instrumented controls; block/cadence sensitivity of release
calibration; watchdog and late persist/POST/fence failure injection; and actual
source/clock-linked informative-duration receipts. These are proposed tests,
not R3 execution receipts or permission to fit held-out partitions now.

The exact null remains zero effect under independent fair pair-order swaps
and qualified absence of carryover/order-by-policy effects. The bootstrap
percentile95% interval is approximate, may degenerate legitimately, and has
no guaranteed coverage/power. Nonsignificance is not equivalence; pairwise p
is not multiplicity-adjusted superiority or minimum-useful-effect support.
`independent_sampling_verified=False` and `native_performance_accepted=False`
remain unconditional. No native prediction/MPC, observer-overhead, deployment
or ten-hour claim is introduced.

### Round3 exact source/test and replay receipt

Final owned implementation/test SHA256s:

```
40feecfc7b2c5f2b3954f1a997cac570f2a19dc6b78845350ff74f589bd363ad  native_experiment_audit.py
1e95d2c898c9bc526ff5f4362de02a2299ed0f034cb7f48cf398d5dd83d2291a  test_native_experiment_audit.py
```

Executed the existing standard-library focused runner:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s experiments/mpc-research/native-v3 -p test_native_experiment_audit.py -v
```

**26 tests passed**, no skips. The historical R1 helper still verifies six
digests and fifteen named witness groups. R3 replay verified eight R2 digests
and all thirteen named witnesses, including three substantive old-Sol failures
and the current implementation's explicit thirty-two-block refusal:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=experiments/mpc-research/native-v3 \
python3 -c 'import json,sys; from test_native_experiment_audit import round3_counterexamples; print(json.dumps(round3_counterexamples(sys.argv[1]), sort_keys=True, indent=2, allow_nan=False))' \
  /path/to/pr33-native-v3-round2-frozen
```

The executable helper pins exact frozen source/tests and requires the supplied
external archive; portable unit tests do not. No native data fixture or invented
native result was added. Whitespace checks passed; full CPU acceptance/native
quality gates were not run for the previously recorded scope/environment reasons.
Only the three owned paths changed across the R3 local history. The environment
checkpointed initial R3 source/tests at `6e28a83`; this report and final replay
receipt are committed locally with the Copilot trailer, without amending it.
Mayor retains Beads/in_progress and peer-review management; no push/merge or
database mutation is part of this deliverable.

## Bounded follow-on: real Train6c schema and frozen methodology proposal

### Deliverable and evidence boundary

R3 commit `475eb855dada59cb40d8c96d09368befcedadc92` remains historical/frozen.
Added one portable standard-library capability adapter,
`train_schema_audit(episode_bytes, expected_sha256=..., cut_at=..., horizon_s=1)`,
and seven focused regression methods. It verifies exact artifact bytes, refuses
non-Train/out-of-range seeds, and separates `observations`, `offline_labels`
and `authority`. No fit, benchmark, controller, protocol change or fabricated
source field is supplied. The bounded short-step target is1s by default,
at most3s; this is an audit interface, not an empirically selected optimal horizon.

Only Train181001 p128/m128 arms0/1 and their read-only event/verification
receipts were examined for this follow-on. Sources:

```
d633b4e402e453238b0d612b3b64c198d61fe572eb9c3b171cbb76a616187c23  nv3-181001-p128-m128-arm0.json
467887df4445c5f20aea1376d40ce07b59671c6326a3c8e88b04bd18008a1a7f  nv3-181001-p128-m128-arm1.json
```

Both digests match the supplied artifact verification ledger. The6c Git object
is unavailable locally; older `collect_interventions.py` was read for schema
context, not falsely presented as byte verification of6c. Frame clock/run,
observer hash, Gateway identity and CostSpec consistency are checked, but
producer authenticity remains external. A dataset/source hash is not a proof
of genuine randomness, independence, pre-outcome publication or calibration.

### What the schema supports, and what it does not

| Distinction | Concrete adapter/evidence result |
|---|---|
| Received observations versus future labels | Only native frames with recorded native receipt<=cut enter observations; Gateway receipt, clock, epoch, sample skew and current freshness are checked. Earlier event/sample time cannot admit a late receipt. Final client rows and later frames enter only `offline_labels`. Mutating a later client first time to before cut, later native output and an unreceived ACK leaves observations unchanged. |
| Live admitted stock versus all-offered past/rate | At arm0 cut `start+.9`:15 live Gateway marks,14 native-visible, one accepted-not-visible; offline planned offers by cut17. Fifteen live marks are neither all-offered arrivals nor cumulative admissions. The schema contains the final all-offered ID/offset/row cohort, but does not establish an online model consumer's receipt of in-progress client offers/first-content history. `all_offered_client_history=None`; no first time or scheduling origin is backfilled into Gateway marks from future rows. |
| API stop versus independent physical EOS | Arm0 reports3925 outcomes:2681 complete/stop,1244 rejected. Arm1 reports2665 complete/stop,1260 rejected. No independent per-request physical EOS receipt accompanies these Train rows. A stop label or injected boolean never establishes EOS/CUDA/output lineage; `independent_physical_eos_receipts=None`, not measured zero. |
| Disappearance versus a physical finish time | A complete same-epoch Gateway mark lost between snapshots yields an open-left/closed-right sampled disappearance interval, conditional on those snapshot attestations and no ID reuse. If it straddles `cut+horizon`, whole-request release bounds are `[0,1]`, not fractional interpolation or a natural-EOS timestamp. Missing endpoint coverage stays interval-censored; corrupt future snapshots withhold labels without rewriting valid pre-cut observations. |
| Original cost versus net stock change | Every UUID retains its original charge, charged shape and admission/ingress stamps. CostSpec is checked, but original charges are never replaced by costs of delivered tokens. Two equal-cost old requests followed by one surviving old request plus one new equal-cost request have unchanged total stock and one complete old-cohort release. The regression produces12 released cost, not zero or a fractional six. |
| Cap drop versus eviction | A synthetic, explicitly non-native schema witness preserves original reservation24 when the observed cap is16. The cap governs further admission; it does not erase prior costs or cancel requests. Real Train non-eviction facts remain those recorded in R3, not this fixture's values. |
| Actual prefix versus nominal/average cap | Receipt-qualified command/ACK pairs must match clock/run/identity, operation, budget, CAS version and expiry. Actual application/receipt times are retained. A received newer ACK conflicting with the sampled state is flagged, not silently reconciled into fabricated state. The full declared assigned sequence remains separate offline metadata until its model-consumer publication is qualified. |
| Same offered tape versus same-state causal effect | The two real arms share offered-offset digest `dc602d910983ecb8d76d37f8b1d69563d7003e89fde31a910ffd79f94dabcb26`, but their assigned prefixes and observed stocks diverge, as shown below. Offset equality does not authenticate common prompt payloads or a same-state contrast. |

At identical relative receipt cuts, the actual partial states differ:

| Arm / relative cut | Assigned first three caps | Observed current cap | Original reserved cost | Live / native-visible / accepted-not-visible |
|---|---|---|---|---|
| 0 / .9s | 32,16,16 | 32 | 15.340359936 | 15 / 14 / 1 |
| 1 / .9s | 16,32,32 | 16 | 12.2722879488 | 12 / 10 / 2 |
| 0 / 2.9s | 32,16,16 | 16 | 8.1815252992 | 8 / 8 / 0 |
| 1 / 2.9s | 16,32,32 | 32 | 20.453813248000003 | 20 / 20 / 0 |

The first planned1s applications occurred with actual planned-to-apply lags
.04942819394636899s / .033400297979824245s. Those are observed planned-origin
lags, not exclusive CAS/POST processing times; command POST-send latency is
not manufactured from GET or expiry stamps. Actual prefix and full assigned
sequence must be preserved rather than averaged into a cap coefficient.
These manually chosen descriptive cuts supply no forecast or causal fit.

At arm0 `start+.9`, the sampled cohort anchor is996887.719384979; by the
target996888.776386528, all its original15.340359936 charged cost has disappeared
in complete later snapshots. This is sampled-Gateway-cohort ownership evidence,
not physical EOS, useful GPU demand or release exactly after the decision:
the anchor precedes the decision receipt, and some releases may occur in that
skew interval. Unknown transient admissions/releases between snapshots and
accepted-but-not-native-visible work remain unobserved. Individual intervals
must not be sampled independently to invent a joint transition distribution.

The real arm0 event envelope has24 GPU samples,765 native frames,3925
`http_outcome` records and119 action records. Native frames/actions carry their
specific receipts; `http_outcome` is an eventual outcome row, without a separate
model-consumer publication receipt for its earlier scheduled/send/first events.
The client driver may internally know its offered plan, but the current
export does not prove that an online policy consumed that history at a cut.
Source timestamps alone must not become a retrospective online oracle.

### Joint short-step model and honest comparison eligibility

**Supported as a partial, unqualified modeling dataset:** received marked-cost
stocks, whole-cost cohort disappearance intervals, explicit accepted-not-visible
work, reported native running/waiting/pending/KV and per-visible-request
prompt/output/computed progress. `computed_tokens` is reported scheduler
progress, not authenticated contiguous executed CUDA positions or exclusive
GPU demand. Retain physical visibility, receipt skew and pending-ACK uncertainty
as state uncertainty rather than zero-filling missing work.

**Not supplied:** a fully observed physical stock-flow kernel, exact per-request
native EOS, coherent joint scenarios, support/calibration, independent blocks,
same-state counterfactuals, complete online all-offered history, exact prompt
payload hashes, or all stable run/policy freeze fields required by my strict
comparator. The adapter does not derive prompt SHA256 from a cell label, physical
EOS from `stop`, configuration from unrelated identity hashes, or client
scheduling from `Gateway.scheduled_at=None`.

The all-offered rows can be reconciled offline against exact recorded physical
UUIDs and source-copied planned origins, retaining reject/fail/cancel/censor
labels. That is not full wire/source/EOS qualification:
`client_wire_outcomes_qualified=False` and `native_comparison_accepted=False`.
The new adapter does not loosen `audit_arm` or feed counterfeit required fields
into it. Reported API stops remain descriptive, not the frozen physical-natural
primary endpoint. No existing40-request qualification UUID is presumed to
authenticate these thousands of different Train requests.

A model conditioned on receipt-qualified pre-assignment history can support
sequential randomized-action contrasts under verified assignment probabilities,
positivity, nonanticipation and execution. State after different earlier
prefixes is a mediator; these paired arm states are not one common pre-treatment
state. Current randomized sequence identification is not implementation of
strong One-move/MPC policies. Whole-policy effects require the corresponding
qualified full-policy randomization and offered cohort, not paired snapshot
differences. All authority flags remain false; identifiers/hashes are provenance
metadata, not memorization features or independent sampling units.

### Frozen primary/statistical proposal before Final

This local commit freezes the following **proposal**, without changing the
running identification protocol or claiming a complete executable Final
preregistration. No Calibration/Validation/Final outcome was opened or used.

| Item | Frozen proposal |
|---|---|
| Primary endpoint | Right-minus-left physical-natural complete-good per prespecified offered-window second: positive integer output, complete exact-UUID HTTP response, independently joined physical EOS, scheduled-origin TTFT<=.5s and terminal-based request-mean TPOT<=.05s. One-token TPOT=0. Reject/fail/cancel/timeout/length-finish contribute0; missing rows fail; unresolved censor/EOS/source qualification withholds confirmatory inference. Do not redefine it to fit6c's absent EOS fields. |
| Primary contrast | MPC minus strong One-move, sharing the same qualified model, joint uncertainty, common continuation, constraints, offered law, window and native runtime. Neither existing Train arm is relabeled as one of these policies. |
| Sampling unit/statistic | One independent seedblock contains both policy arms across all five cells. Compute each cell's paired good/window difference, then equal-weight the five cells, then equal-weight independent seedblocks. Origins, requests, steps, cells and repeated arms are not independent replicates. Never split one seedblock or forge a single concatenated scheduled origin to satisfy the flat audit API. |
| Planned sample size | Eight prospectively selected independent complete blocks per contrast, not eight surviving blocks chosen from a larger outcome pool. Actual seed IDs and immutable experiment/assignment manifest must be bound by Mayor before Final execution. Missing/invalid planned blocks withhold the comparison; no optional stopping, dropping, outcome-selected extensions or retrospective manifest. If the existing Final plan differs, this proposal cannot silently reshape it. |
| Minimum practical effect | Delta=.10 physical-natural good/s on the equal-cell standardized endpoint, fixed here independently of fitting these Train outcomes. This is a design threshold, not observed gain, a capacity anchor or a guaranteed detectable effect. |
| Multiplicity | Predeclared family of three contrasts: MPC versus strong One-move, Train-selected best qualified Fixed16/32, and Train-selected best qualified reactive policy. Holm family-wise alpha.05 for valid zero-effect tests; cross-contrast independence is not presumed. Baseline identities/settings/selection rule must be sealed before Final, not chosen as weak controls or selected from Final winners. |
| Inference boundary | Exact block sign-flip zero-null inference is usable only after its actual assignment space, fair block label swaps and qualified no-carryover/order effects are verified. Eight pairs' minimum two-sided exact p is1/128; this is not power. Approximate block percentile bootstrap remains exploratory, not guaranteed coverage. |
| Practical-effect claim | Zero-null rejection plus point mean>=Delta is insufficient. A qualified practical-superiority claim additionally needs a valid simultaneous lower-effect bound aboveDelta or a separately preregistered valid margin-null analysis. Neither is currently implemented/qualified here. Do not silently shift sign-flips byDelta and claim exact inference for a composite mean null. |

Only the endpoint, unit, weights, threshold and contrast/multiplicity proposal
are frozen here. Missing native capture authority, baseline/model artifacts,
prospective cut/sequence publication, source-bound manifest and verified
independent sampling are real prerequisites, not filled by an opaque hash.
The existing `paired_effect` accepts flat single-window paired arms; it does
not yet audit this five-cell native seedblock aggregation or its assignment
space. Any complete Final analysis protocol must resolve those prerequisites
before Final outcomes are generated/viewed, without retrofitting current data.
No native win, equivalence, calibration, sample-size power, full-pressure
safety, solver overhead or ten-hour claim follows from this proposal.

### Exact local adapter/regression receipt

```
4fc5fd5e81ba495e67c96aadc7f0d531874b6262e32edd6d0f5a18f3df33db34  native_experiment_audit.py
e2e7945f3bc641d698519d5bbfa5856b8fc250234f53a79914c83e700e6ae046  test_native_experiment_audit.py
```

Executed the existing standard-library runner:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s experiments/mpc-research/native-v3 -p test_native_experiment_audit.py -q
```

**33 tests passed**, including seven new schema regression methods; no skips.
Preserved R1/R3 pinned replays still pass15/13 named witnesses and6/8 byte
checks. The real two-arm probes above executed through the portable adapter
against ledger-verified bytes; neither granted native comparison authority.
The environment automatically checkpointed part of the work at `d8a64d2`;
the final report/receipt is committed locally with the Copilot trailer, without
amending the frozen R3 history. Only the three owned paths change, with no
push/merge, database mutation, GPU process or live protocol alteration.
Full project/native gates were not run for the previously recorded scope
restrictions; focused contracts and whitespace checks are the local receipt.

## R5: standalone online all-offered publication/receipt interface

### Small API and publication contract

Implemented `OfferedReceiptHistory` with construction, `receive(publication)`
and `cut(cut_at)`. It has no network, GPU, model, dependency installation or
active-control path. The observer captures its own `received_at` with an
injected/default monotonic clock; producer-supplied receive stamps and final
HTTP rows are rejected. Producer and observer must declare the same verified
ClockDomain: no clock-offset inference or GPU-elapsed conversion is supported.

The versioned producer envelope is:

```
schema: native-v3-offered-publication-v1
publisher_run_id: exact hex32 client publisher epoch
clock_domain: producer host monotonic ClockDomain
publication_seq: contiguous positive integer, starting at1
request_id: exact hex32 offered UUID
kind: offered | sent | first | terminal
event_at: actual client callback event stamp
published_at: actual producer publication stamp
```

`offered` additionally supplies the original `scheduled_at`, `original_cost`
and `cost_spec_sha256`. `terminal` additionally supplies a client lifecycle
status: complete/rejected/cancelled/failed/timeout. Unknown cost/provenance is
explicit `None`, not zero, a fixture default or an estimate backfilled from
delivered output/Gateway rejection data. Known cost must be positive/finite
with its source CostSpec digest. Known and unknown original values remain
immutable; a later admission charge is separate evidence, not permission to
rewrite the original offered declaration. An offered cost is not an admitted
reservation, GPU seconds or KV bytes.

Each unique publication is identified by publisher epoch/sequence; each
offered UUID may be registered only once in that epoch, including after
terminal closure. Publications are FIFO/loss-detecting: gaps, duplicates,
foreign epochs/domains, nonfinite/boolean times/costs, publication before
event, publication after observer receive and clock regressions fail closed.
Per-request send/first/terminal event order is checked. `sent` means client
attempt initiation, not successful wire transmission, Gateway admission or
native execution. First requires a preceding send; cancellation/failure/
timeout/rejection may close an unsent intent. Empty complete responses can
still be recorded as lifecycle completions; no positive-output/SLO/EOS
benchmark authority is inferred.

`receive` returns a copied receipt with the observer run/domain and the
observer-generated receive stamp. Original producer objects, returned
receipts and returned cut records cannot mutate stored cost/history.
There is no API that turns present final rows into publications or manufactures
callbacks that were not executed.

### Cut semantics and deterministic evidence

`cut_at` cannot exceed the observer clock or regress after a sealed cut.
Only receipts available by the cut participate. Presubmitted future intents
are excluded from the due-offer history until their original scheduled time.
When a first/terminal event happened before a cut but its publication reached
the observer later, it does not retroactively fill that cut.

Cuts carry a receipt sequence watermark and immutable copies. Repeating the
same time returns the same sealed prefix, including when a subsequent callback
shares that clock tick; a strictly later cut can include it. Thus a timestamp
tie cannot change a previously published decision prefix. The watermark is
transport provenance, not a predictor feature or proof that all producer
events through wall-clock time were received.

All due registered offers remain in the history: rejected, cancelled,
unsent, delayed and completed. Counts distinguish known sends, late sends,
pending requests, terminal statuses and unknown original costs; there is no
accepted-only filtering or terminal-triggered deletion. Global publisher
completeness remains unverified: an unseen/in-flight publication or missing
prospective registration is not evidence that no offer existed.

Seven new CPU regression methods demonstrate deterministic callback-driven
replay, separate publication/receive stamps, late-send and unsent cancellation
inclusion, delayed first/terminal noninterference, future-intent exclusion,
equal-tick prefix sealing, original-cost/copy immutability, malformed
sequence/clock/lifecycle rejection, final-row refusal and explicit unknown
cost preservation. The deterministic stream contains three due offers, two
send attempts, one late send, one completion, one rejection and one unsent
cancellation, retaining original declared costs2/3/5. These are explicitly
synthetic interface inputs, not native measurements or performance constants.

### Exact Mayor source context and integration still required

After the exact path was clarified, read the requested Mayor collector and
its optional synchronous capture hook, without editing either. Read-only
source hashes at inspection:

```
069a58b6c2e15081acaaf70c73a9465fdb64da694d47fbc5b20f35c2560d7422  Mayor native-v3/collect_identification.py
a8bbafd6a84f8a1581a2f0e0d0fe11a086c542e392a45c1466fa9071df93fb6c  Mayor mpc_lab/http_capture.py
```

`collect_identification.py:350-364` creates/persists IDs and the offered tape,
then records eventual `http_outcome` rows. Its `capture_chat` call at391-393
passes `record=record`, **not** the optional HTTP `observe` hook.
Its existing `async def observe()` is the native-frame sampler, not a
synchronous HTTP callback and must not be reused as one.

The inspected `http_capture.py` calls optional synchronous `observe(kind,
receipt)` with a copied receipt containing `published_at` and ClockDomain:
`offered` after assigning the client attempt `sent_at` and before entering
`client.stream`; `first_content` when actual SSE content first becomes
available; `terminal` in `finally`, including timeout/rejection/cancellation.
An unsent cancellation has `sent_at=None`. Callback errors latch
`observation_error` without changing the offered HTTP traffic, and awaitable
callbacks are rejected. This is source-level interface context, not a claim
that these callbacks were attached/executed on the native continuation.

A future authorized integration must:

1. Prospectively publish unique offer-intent registrations before task
   queueing/validation/cancellation, using actual publication clocks and
   source-bound cost metadata or explicit unknowns. Persisting a manifest
   alone is not a model-consumer receipt. Do not create a retrospective
   offered receipt when an unregistered terminal arrives.
2. Add a separate synchronous normalizer/publisher with a serialized
   per-client-epoch sequence. Map the capture hook's `offered` attempt event
   to this interface's `sent`, `first_content` to `first`, and `terminal` to
   `terminal`, preserving actual hook event/publication times. A standalone
   offer-intent registration remains necessary for unsent requests.
3. Attach that callback explicitly to `capture_chat(observe=...)`, deliver
   through an ordered channel, and capture the policy observer's own receipt
   clock at consumption. The current collector call site does not do this.
4. Preserve callback failure/gap evidence and withhold completeness/model
   authority; do not swallow bad measurement into a purported complete
   history. A terminal callback containing an old first timestamp cannot
   recreate the missing first publication or its earlier receive stamp.

This integration is deliberately **not implemented in the collector or live
capture module**. No fake cost, send, first, terminal or publication receipt
was added to existing files/data. R5's receipt interface is standalone, not a
native qualification. Source declarations and syntactically valid callback
packets are not source authentication, complete transport or physical EOS.
`publisher_complete_through_cut`, `callback_source_authenticated`,
`independent_native_eos_verified` and `active_mpc_permit` remain false.

The byte-bound Train capability audit remains unchanged and continues to
withhold absent online/physical authority. The physical-natural endpoint and
statistical design remain **proposals**, not binding benchmark rules or
reinterpretations of current identification labels. The inspected collector
itself describes open-loop identification, correlated cells/arms and no MPC
acceptance. Mayor reports native729 unchanged and continuation02 actually
running/replicated; this task did not execute or independently requalify it.
No Calibration/Validation/Final outcome was opened or fitted in R5.

### R5 exact local source/test receipt

```
b476424aa892ceeaef63f6a67c7e28e45923090cb53db8aeec2f4acbcc1ef10a  native_experiment_audit.py
10a1315117b774eca7531c76067205e9332fc14c1114ecd145b748b6914872ba  test_native_experiment_audit.py
```

Executed the existing standard-library runner with
`PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover
-s experiments/mpc-research/native-v3 -p test_native_experiment_audit.py -q`:
**40 tests passed**, no skips, including seven new receipt methods and all
preserved Train/endpoint/block/work tests. Frozen R1/R3 replays still verify
six/eight digests and pass fifteen/thirteen witnesses. Whitespace checks
passed. No new third-party dependency, native hook execution, active permit
or full/native quality-gate claim. The environment checkpointed source/tests
automatically; this report and exact receipt are committed locally with the
Copilot trailer. Only the three owned paths change; no push/merge, Beads
mutation, GPU process or live protocol change. Mayor retains in_progress/
peer-review management.

## R6 independent architecture: partially observed hybrid marked-batch dynamics

This proposal was written without inspecting another model's R6 conclusions.
I choose a **hybrid marked-event belief kernel**, not exclusive serial
HTTP-first-residence service or a cap-to-GPU-rate regression. The family is
structurally useful but **not point-identified, fitted, calibrated or authorized**
by this round. The runnable deliverable is a source-bound endpoint-attribution
counterexample/diagnostic, not a synthetic performance benchmark or an executable
native dynamical simulator. R5's receipt interface and byte-bound Train audit
remain unchanged.

### Minimal x, u, w, f, h

The directly observable state `x_obs(t)` contains only receipts available at the
cut: Gateway whole-cost owners, prompt/max marks, received/admitted/first times,
current reservation stock and cap/version; exact joined native request IDs and
raw `(computed_tokens, output_tokens, prompt_tokens, maximum_output_tokens)`;
native running/waiting/pending/KV reports, visibility masks and snapshot ages;
and received command/application ACK fences. A published-prefix action history
and R5 all-offered client history are required inputs when actually available.
Present raw final rows do **not** supply those online client receipts.

Use separate latent components `z(t)`, not invented zeros: accepted-but-unseen
ingress/native membership, waiting identities, useful/cache-resident progress,
scheduled versus executed work, possible replay/preemption, physical EOS and
unfinished tail, client delivery/terminal state, and missed inter-snapshot
birth/death pairs. The prediction state is `(x_obs, b_t(z))`, a belief over coherent
marked states. This is not a claim that the observed vector alone is Markov or
that its latent posterior is identified. Native counts with unknown identity and
marked-not-visible work must remain explicit constraints/unknown mass.

`u(t)` is the **actually applied whole-request reservation budget 16 or 32**.
Planned changes and actual CAS/ACK delay are separate events, not instantaneous
control. Each offer has immutable charge `c_i`, Gateway/native prompt marks,
output limit, payload identity, intended-offer time and lifecycle identity.
An unqualified future charge is unknown. A hypothetical scenario charge obtained
from a fixed CostSpec/payload is a prediction, never a fabricated original-cost
callback receipt.

`w` is a COMMON, cap-exogenous offered point process with joint payload marks,
client/ingress timing disturbances and common primitive model randomness. The
future payload/output-limit law does not change to help a candidate cap. EOS
continuation uncertainty is conditional on payload/native prefix and actual
batch state, not a direct budget effect or an asserted independent coin flip.
Common random numbers must preserve that joint dependence. Fitting the birth
law from admitted marks alone would introduce cap-dependent selection; future
final rows are labels, never pre-cut arrivals. Neither intended offer nor client
attempt receipt is proof of native ingress. The current unexecuted R5 callback
integration leaves online all-offered input authority withheld.

The event kernel `f` operates on one marked population with separate Gateway,
native and HTTP lifecycle coordinates. Admission/rejection follows the actual
reservation gate, with no eviction on a cap decrease:

```text
admit i only if reservation_stock + c_i <= applied_u
delta admitted_count = admitted_births - releases
delta reservation_stock = sum(original c_i for admissions)
                        - sum(original c_i for releases)
```

Every release belongs to one exact owner; no fractional releases, duplicate
terminal rewards or independently sampled count/cost flows. A released Gateway
owner need not imply independently verified native EOS or drained physical work.
Conversely, API completion is not the exclusive native service interval.
Unseen between-snapshot flows cannot be recovered from a net stock change.

After admission, ingress/queue events expose native jobs. A common joint
batch-allocation/transition kernel uses actual admitted native composition,
prompt/decode progress, payload/prefix, waiting work, cache residency/KV and
shared resource noise. It **does not receive cap as a service-rate coefficient**.
For a native forward step, nonnegative integer token allocations must respect
the pinned scheduler's physical configuration, which is not the cost budget.
Prefill and decode compete in that same allocation and batch shape:

```text
sum_i allocated_native_tokens_i <= K_scheduler(configuration)
executed_inputs = useful_prefill + useful_decode + tail + replay
```

The second line is a mutually exclusive accounting partition, not extra
independent work generators. Tail is classified relative to useful delivery/
finish lineage and can be unknown online. Replay/preemption cannot be assumed
absent merely because these Train examples do not qualify high KV pressure.
Batch progression/time depends jointly on the allocation/mix and readiness.
There is no sum of per-request HTTP durations equated to GPU service and no
conversion of GPU elapsed into an absolute/exclusive host-clock interval.
`K_scheduler`, progression/time parameters and observation-delay parameters
are **not estimated or numerically invented here**.

EOS/length events, possible pending tail and client delivery/terminal events
complete the same trajectory. Output limit is an upper bound, not realized
natural EOS. Native output counters, client completion usage/content receipts
and executed inputs remain distinct. A pre-finish placeholder may execute
without another useful output. The LIGHT qualifier's 20 measured one-overhang
requests do not identify a random tail law; the other 20 OFF requests are
unmeasured, not measured zero. The old v2 failure is retained.

The observation map `h` emits exact reported token fields, visible masks,
Gateway reservations and client receipt prefixes, with their own source and
sampling/receive clocks. Raw computed-token reports are genuine covariates,
but are **not silently declared executed CUDA counts**. Absent physical EOS
receipts remain absent. Observation loss/delay is part of `h`, not zero service.
A practical future implementation could initially fit receipt-to-receipt
joint reported-progress transitions without claiming physical execution
identification. Physical-natural endpoint qualification still needs its
independent native source.

**Exclusion falsifier:** with common arrivals/payloads/primitive noise, identical
actual admission and native-state paths, and nonbinding 16/32 gates, the service
sample path must be identical. A predictor changing service solely because the
budget label changed violates this family. Budget effects through admission,
batch mix, queue/cache history and later releases remain legitimate. Different
post-action arms are not a matched pre-treatment state or a same-state causal
effect.

### Focused runnable counterexample: incumbent information versus birth error

Added `future_api_good_partition(bytes, expected_sha256=..., cut_at=...)`.
It uses the existing Train181001..181016 byte/receipt audit, preserves the raw
five request fields at the same last received frame (including tied receipt
ordering), and reports **offline labels** for fixed horizons **1/3/5 seconds**.
It does not fit anything or expose future rows as observations.

For each horizon, the API-stop/SLO candidate count partitions exactly into:

```text
G_api = G_visible_snapshot_cohort + G_marked_native_unknown
      + G_past_offered_outside_snapshot + G_post_cut_intended_birth
```

Past offers outside the sampled Gateway cohort may involve transient/gap/
ingress histories; they are not relabeled native-visible incumbents or
post-cut exogenous births. Marked-but-unseen members are their own group,
not zero work. Birth classification uses intended scheduled origin, not
cap-selected admission or retrospective native visibility. This partition
alone does not identify wire ingress or a physical service mechanism.

Candidate labels retain the existing scheduled-origin TTFT <= .5s,
terminal-based request-mean TPOT <= .05s, positive integer completion usage,
one-token TPOT=0, complete exact-ID/HTTP200/SSE and API `stop` conditions.
Length/truncated, rejected/failed/cancelled/timeout contribute no candidate;
all offered IDs/statuses remain reconciled. Missing/duplicate, unresolved
censored or invalid successful rows withhold the point partition. Source
hashes authenticate neither a callback nor an independent physical EOS:
`physical_natural_good` is always **None**, and performance/online-history/
source-authentication/active-permit flags stay false. This API candidate
diagnostic is **not** promoted into the primary physical-natural metric or
a binding reinterpretation of the collector's benchmark rules.

The reproducible two-world witness keeps the same pre-cut progress state and
the exact same incumbent completion. One world has no future offer; the other
adds one later exogenous birth after the incumbent's terminal. The diagnostic
changes total future candidates from one to two while incumbent attribution
remains one. Thus even perfect incumbent prediction leaves the birth-error
term:

```text
total prediction error = incumbent error + unseen-past error + birth error
```

This is an accounting counterexample over hypothetical feasible histories,
not native timing/capacity measurements. Within each world the offered law is
common to candidate caps; changing worlds illustrates arrival-model error,
not cap-induced arrivals. It proves no predictive value for progress by itself.
A separate same-arrival/same-progress continuation changes EOS-at-limit or
terminal TPOT and therefore incumbent candidates. Arrival knowledge alone
does not determine that continuation; the delayed terminal does not identify
exclusive GPU service. Spoofing an EOS Boolean still supplies no physical
receipt. Additional regressions retain unseen-past/marked-unknown groups,
withhold bad future labels without rewriting observations, and align tied
receive-time progress with the original Train audit.

### Actual raw Train check, descriptive only

Independently byte-verified exactly three p4096/m128 arm0 JSONs against the
provided frozen ledger, using one preselected `start + 40s` cut, not a cut/horizon
search. The directory is
`pr33-native-v3-first-three-complete-train-blocks-frozen` in Mayor's supplied
session files. No other outcome partition was opened. These are three
descriptive cuts, **not Train1/2 fitting, fresh Train3 evaluation, causal policy
effects or calibrated coverage**; Train181003 was already used development.

| Train seed | Applied budget / reserved cost | Marked / native visible | G_api at 1/3/5s | 5s visible / marked-unknown / unseen-past / post-cut birth |
|---|---|---|---|---|
| 181001 | 16 / 16.1217386496 | 4 / 4 | 0 / 2 / 2 | 1 / 0 / 0 / 1 |
| 181002 | 32 / 24.1826079744 | 6 / 4 | 1 / 5 / 6 | 4 / 0 / 0 / 2 |
| 181003 | 32 / 28.2130426368 | 7 / 5 | 1 / 2 / 3 | 2 / 0 / 0 / 1 |

Train181002 actually reports a `(computed=4090, output=0, prompt=4096,
max=128)` member alongside decode prefixes. Train181003 reports
`(2039,0,4096,128)` alongside `(4150,54,4096,128)`. These raw observables exist:
older transforms omitting them are not evidence of raw unavailability.
Their executed/useful-work interpretation remains separately unqualified.
The two unseen marks in each latter cut are retained unknown current state;
zero *realized candidate completions* for their group is not zero latent work.
The first cut's reserved cost exceeds its current budget without deletion,
consistent with non-eviction/history rather than concurrency=16.

These selected-cut candidate fractions are not a reproduction/rebuttal of
Mayor's earlier source407a1b46 G5 target/aggregate, its reported post-cut-born
share or its under-covering bands. Better whole-target error with better
arrival inputs would not by itself qualify a service/progress model. No
prediction superiority, native capacity/120% anchor, high-pressure/preemption
qualification, 10-hour actual-duration completion or MPC win is inferred.

Exact input byte receipts:

```text
74da77e6bc936d887da0605085695021827851d38736faf62d512e611579a584  nv3-181001-p4096-m128-arm0.json
3d4f681e0ef0a2e6b45d90bba38c59c945ff6cd918767dbf5dfec5bc1bbf04d7  nv3-181002-p4096-m128-arm0.json
0fadab534bd331afb08090bfde1b2d1a6b8599db77483ec5c7f672553c709215  nv3-181003-p4096-m128-arm0.json
```

Reproduce by reading the frozen ledger, passing each exact JSON byte string
and its ledger digest to `future_api_good_partition`, with
`cut_at=json.loads(raw)["start"] + 40`. The returned observations include raw
progress; `future_api_good` is the separate future-label partition. No final
row publication/send receipt backfill or live collector modification is needed
or performed. R5 native callback integration remains unexecuted.

### Evaluation, support, uncertainty and deployment boundaries

Before any control authority, distinguish three diagnostics at fixed 1/3/5s:
receipt-aligned same-ID native progress/visibility and whole-owner lifecycle;
incumbent versus unseen-past versus future-birth endpoints; and total all-offered
outcomes. Compare inclusion/ablation of progress with the **same exogenous
arrival/payload law**, not a future-arrival oracle secretly supplying service
skill. Joint scenarios must conserve counts/costs and carry tail/replay/visibility
uncertainty. EOS or release marginals sampled independently of that trajectory
can produce impossible stock-flow/outcome combinations. No calibrated bands
or finite-sample guarantees are claimed here.

Future strongOneMove must use the same kernel, admissible single-change
timings/hold, horizons, replanning cadence, SLOs, cost/ACK/observer overhead
and uncertainty as MPC. It may search its qualified one-change possibilities,
not be weakened to a naive immediate-step baseline. MPC's added sequence
choices require native-supported transitions and uncertainty, not arbitrary
average-cap aliases. Native prefix progress information is available, but
its predictive gain and usable horizon must be demonstrated rather than
assumed from the 1--3s response descriptions.

Sequential causal support conditions future randomized actions on **pre**
assignment receipt history, with actual ACK delay and published-prefix/full
assignment sequence retained. Conditioning on a later batch state instead
would remove/change the admission mediation. Current arm divergence does not
qualify same-state effects. OOD includes unseen payload/length mixtures, stale
or missing receipt prefixes, transient/unknown native membership, replay or
KV pressure outside observed support, and unsupported rapid switching.
Out-of-support models withhold authority; native fixed/reactive fallback must
be independently qualified, not improvised from this report.

The earlier frozen physical-natural/statistical **proposal** stays unchanged:
primary MPC-minus-strongOne effect, equal-five-cell then independent complete
seed-block weighting; proposed eight blocks; practical margin .10 good/s;
Holm .05 family across strongOne, best qualified Fixed and best reactive.
Source hashes are custody, **not statistical independence**. Actual independent
sampling/randomization, final manifest, comparison policies, missing/censor
handling and a valid margin/simultaneous-bound method still need sealing before
any Final. A zero-null sign flip plus mean above margin is not a practical-effect
claim. Existing exact 2..16-block refusal and source/configuration/tape guards
are not relaxed. No Calibration/Validation/Final fitting or old reserved
160021..160024 access occurred. This is an independent proposal, not consensus.

### R6 exact local source/test receipt

```text
79226047437dcf35f9d6bfcc54382ec6c05c7d31866313d1b4f012c3143746d6  native_experiment_audit.py
10ec86d4a94996debc9839fb8b63a19a7de597119b508fe047cd58213132bc61  test_native_experiment_audit.py
```

The existing standard-library unittest command passed **45 methods**, no skips,
including five new R6 methods and all preserved receipt/Train/endpoint/block/work
contracts. Frozen R1/R3 replays also passed six/eight pinned digests and
fifteen/thirteen witnesses. Whitespace checks passed. No third-party dependency, native simulator
qualification, model fit, active permit or full/native quality-gate claim.
Only the three owned paths change, committed locally with the Copilot trailer.
No GPU process, push/merge, DB mutation or live protocol change. Mayor retains
in_progress and independent-freeze/peer-exchange management.

## R7 adversarial exchange: support-qualified full-plan response versus marked kernel

Read all four frozen R6 report sections, relevant implementations and tests.
Verified all **12** files against `pr33-native-v3-round6-frozen/manifest.json`,
including Sol's final **df00f30**, not the early dirty-report auto-checkpoint.
The independent exchange boundary is retained. This round fits no model,
opens no raw Calibration/Validation/Final or GPU data, and changes no live
protocol. Counterexamples below are hypothetical/source-contract evidence,
not GPU interventions or native MPC wins.

### Concrete four-source review

| Frozen proposal | Retained contribution | Concrete limitation / required next correction |
|---|---|---|
| Opus `53acdff6` | Same-origin direct-horizon cohort/birth point diagnostic; explicit reduced-form birth caveat and unfit structural kernel. | `id_progress_state` reads final-row first/terminal event timestamps, not client publication/observer receipts. Its absent-first exact zero assumes a complete client prefix that the current collector does not qualify. `_client_events` does not validate response UUID/HTTP/SSE or independent physical EOS. `_horizon_good` calls every non-snapshot-cohort completion a birth, including possible past-offered unobserved/transient work. |
| Astra `deff2529` | Restricted atomic forward helper separates length/latent EOS, preserves queued overhang and excludes cap/cost from the service helper. | The producer still supplies allocation feasibility and time; this is not a fitted shared-resource law or native initializer. Raw scheduler `computed_tokens` cannot be assigned directly to physical `prompt_done`. Atomic/no-recompute/non-speculative states and the existing client/release composer do not cover all native lag/unknown states. |
| Gemini `7a1a18fd` | The scalar-state ambiguity is a possible countermodel and cap must affect admission rather than hardware clocks. | `step` scores output-limit termination as good even with EOS probability zero; promotion replaces the offered output limit using prompt length; unseen cost decays by .8 without an owner transition; waiting identities are not carried forward. Decode advancement does not debit the shared prefill token budget, and `max_num_seqs` is unused. The diagnostic returns hard-coded native figures when source data are absent. These are not a qualified coherent batch kernel or source-bound fit. |
| Sol `79226047` | Byte/receipt-safe raw progress path; four-way endpoint attribution; no physical-EOS or online receipt backfill. | R6 supplied no fitted transition, EOS belief, calibrated uncertainty or plan response. Its three fixed-cut API candidates and logical arrival-error identity do not explain the actual aggregate G5 loss, establish progress benefit, or qualify the physical-natural endpoint. |

`round7_peer_counterexamples(frozen_root)` reproduces eight named witnesses
against those pinned source bytes, without native data: Opus's publication-cut/
incomplete-prefix problem, snapshot-complement birth label, and missing wire
validation; Gemini's length-good, output-limit mutation, unseen-mass decay and
source-free native-figure fallback; and Astra's correctly retained length/
latent-EOS distinction. The latter is a positive semantic control, not a bug.
Peer files were not edited.

The Opus timestamp-cut analysis can remain a **retrospective descriptive
diagnostic**, conditional on its availability assumptions; it must not be
advertised as qualified online receipts. A first event occurring before the
cut but published/received later is unavailable. Conversely, a missing first
publication does not prove TTFT impossible unless prefix completeness is
qualified. Native API `stop` and delivered usage are not independent physical
EOS. A snapshot complement is not automatically an exogenous *post-cut
offered* population. Keep the reported large complement/later-birth
contribution, but retain those origin distinctions when interpreting it.

Gemini's equal-rate callback check proves only invariance of that supplied
function at that one mock state. It does not verify an arbitrary causal graph,
batch-resource conservation, EOS law or observability. Hard-coded 2048/.5s/
1024 assumptions are not newly identified native rates. Its logical scalar
ambiguity does not prove that every fluid/direct model inevitably fails at
5s or that progress uniquely explains the oracle residual.

### What the reproduced point evidence does, and does not, establish

Independently compared the supplied worker/Mayor R6 diagnostic JSONs:

```text
016456f6eab563bc2f0573ba2b0f90db6789fd3a45a9c7660019de780ae8ed7a  opus-r6-progress-diagnostic.json
b987310fe835476c8d9629cfe51a8118eb01f0b31271b7368c6361a376e480b2  mayor-r6-progress-diagnostic.json
```

Exactly eight float fields differ, maximum **5.551115123125783e-17**; all
other parsed fields are exact. This is numerical reproduction, not statistical
independence or causal identification. The already-used Train181003 numbers:

| Total-target MAE | 1s | 3s | 5s |
|---|---|---|---|
| history | 2.7014 | 5.6858 | 8.7573 |
| aggregate cohort + direct birth | 1.4158 | 3.7025 | 6.0043 |
| progress cohort + same direct birth | 1.0666 | 3.4472 | 5.9029 |

Incremental G5 gain over the stronger aggregate hybrid is only about **1.69%**,
not the whole history-to-hybrid improvement. Original-cohort .1235 is not
full-target 5.9029. The comparison changes direct birth/endpoint representation
as well as cohort information; it does not isolate recursive error accumulation
as the unique cause. An oracle interval offer count/rate does not supply exact
arrival timing, payload, EOS or future batch state. The R5 recursive negative
**9.84 versus history 8.76**, oracle 8.78, undercoverage and unknown-work facts
remain retained. No predictive confidence, service identification or policy
performance conclusion follows from these used-development point values.

The cohort ablation bundles first/terminal logic, visibility, output bins and
batch features; it is not a computed-token-only gain. Opus's R6 same-aggregate
unit witness actually leaves joined native output values unchanged and varies
client first/terminal states. A token-specific benefit requires a matched
availability/feature ablation, not renaming that witness.

### Two competing hypotheses: neither is selected as native authority

**H: fitted causal marked-progress kernel.** Fit receipt-aligned native
progress/visibility and whole-owner admission/release/client transitions,
with raw computed/output/prompt/max and explicit latent uncertainty. Cap acts
through actual ACK/application and admission; service depends on resulting
batch/queue/cache/prefix, not a cap coefficient. This is an interpretable
structural restriction, not proof that partial observations identify the
latent kernel. It requires coverage of the physical states/plans it simulates,
not merely a passing atomic-forward unit test.

**D: direct multi-horizon full-plan response.** A legitimate proposed estimand is

```text
F_N(H_pre, Z_full_future, q_offer_payload, protocol)
  = E[future all-offered outcome at N under assigned plan Z | H_pre, common q]
```

Use all five timed future 1s assignments, not only `next_plan_budget`, and
N=1/3/5s. This is a **total response**, marginalized over actual application,
admission and batch histories. Budget features in D are therefore not by
themselves an inadmissible direct GPU-service edge. An identified,
support-qualified learned IO response can be an MPC model without reconstructing
every physical latent. It may not be called GPU throughput, exclusive service
time or a physically identified kernel.

The two hypotheses share the same exogenous offer/payload law and outcome
contract. Neither may condition deployable predictions on realized future
offers, EOS, good counts, native snapshots or ACK outcomes. D must not replace
the unresolved compliance/unknown-state law with an event-time oracle; H must
not hide it in deterministic stages.

### Random assignment is not universal plan identification

For **planned-assignment ITT**, include every assigned request/window and its
actual retries, delay, failure and compliance as outcomes of that protocol.
Known randomization can identify supported assignment effects under the
appropriate pre-assignment history. Selecting only successful ACKs, using the
future applied schedule as a predictor, or discarding delayed/noncompliant
paths changes that estimand. The R6 common 544-origin rule helps point-model
comparability; its future usable-path/ACK gates can still select a factual
subset and do not certify full all-offered causal support.

For **actual-applied-cap/per-protocol** effects, actual ACK time is a
post-assignment variable, often affected by queue/host/control history.
Simply regressing on it is not randomized treatment. Either model its
application/compliance mechanism under ITT, or supply separate sequential
identification assumptions and evidence. No instrument/exclusion/monotonicity
claim is manufactured here.

A whole sequence randomized before an episode supports an episode-level
assignment contrast, not automatically arbitrary history-conditioned
continuations. Retain the assigned past prefix and pre-next-assignment
receipt history, the true conditional randomizer probabilities and any
sequence constraints. Later batch state is a mediator, not a substitute
pre-treatment state. Marginal budget balance, feature min/max and many
correlated snapshot occurrences do not establish joint/history positivity.
Nor does a finite absent path prove zero probability when the true design
gives it positive mass.

Direct D still needs supported complete plans and histories. Structural H
can extrapolate through a declared invariant kernel only if its resulting
admission/batch/missingness states are supported or uncertainty/refusal covers
them. Native computed-token fields exist despite old joins dropping them;
adding them does not manufacture that coverage.

### One high-information runnable identification/selection counterexample

Added `cap_plan_support_audit(declared_law, candidates)`: positive integer
**randomizer weights**, not empirical trace counts; exact rational prefix
mass for five binary assignments and N=1/3/5. It is explicitly one marginal
stratum. Source authentication, conditional-history support, sequential
randomization, ACK compliance, selected-policy coverage and active permit
remain false even when every declared plan has positive mass.

The abstract slot convention is budget in `[cut+j,cut+j+1)`, j=0..4.
Native integration must bind actual assignment boundaries, current/incumbent
budget, phase and delayed ACK times; it cannot silently equate tuple position
with a real applied action.

The witness draws uniformly from the **16 even-parity five-slot plans**.
Every slot has 16/32 probability .5; all 1s and 3s prefixes have support,
but only 16 of 32 full plans do. Constant all32 is unsupported. This is
a hypothetical randomizer counterexample, **not a claim that the actual
collector used parity randomization**.

One old cost16 owner persists, and the common future law offers one cost1
request per slot. The cap gate alone chooses admissions, with no eviction
and original charges retained. Two batch-continuation laws complete the
same admitted jobs near the end of 5s whenever at most four future jobs
were admitted. With five admitted jobs, one law completes all five and
the other stalls that previously unseen larger batch beyond 5s. Neither
service law receives cap; cap changes the admitted physical population.
Both laws agree on **every supported plan** but give G5=5 versus0 for
all32. Exact whole-owner release, reservation stock and offered/rejected/
unfinished count conservation are checked. Randomized per-slot variation
therefore cannot choose between the two full-plan counterfactual laws.
Both D and H would need extra support/evidence or refusal there.

A separate uncertainty check uses **full uniform 32-plan support**. Predict
the first batch law, take the second as truth, and give point-sized prediction
sets. Random-policy coverage is31/32 (96.875%), but the unique predicted-best
all32 plan misses: selected-policy coverage is0. In this full-support example
the laws are no longer observationally equivalent in the population; the
point is distribution/selection coverage, not nonidentification. A high
random-policy residual average does not authorize optimization.

These three portable R7 test methods also validate exact unequal randomizer
weights, same-prefix masks, invalid weights/caps, and duplicate candidates.
There are no native timings, fitted service constants, future receipt
backfills or empirical statistical guarantees in the witness.

### Minimal next usable interface and actionable acceptance gates

Next deliver **one offline fitted full-plan response interface**, with D and H
as alternative implementations behind the same contract, not a new active
controller:

```text
predict(receipt_prefix, timed_assigned_plan[5], common_offer_payload_law,
        target_contract, fitted_source_receipt)
 -> means at 1/3/5; explicit origin components; joint-scenario/set status;
    per-horizon/per-plan support masks; unknown-state/compliance diagnostics;
    input/fit provenance and always-inactive deployment status
```

Means may be fractional expectations. Integer lifecycle counts, unique IDs,
whole original-cost stock and mutually coherent outcomes are required of
**scenario trajectories**, not obtained by clipping independent mean flows.
API-stop labels and the proposed physical-natural endpoint retain distinct
authority; absent independent EOS withholds the latter. R5 online all-offered
callback integration remains unexecuted and must not be forged from final rows.

| Gate on newly complete Train blocks | Testable acceptance / refusal |
|---|---|
| Freeze before looking | Mayor seals complete Train IDs/exposure ledger, source/fit hashes, feature/mask definitions, losses, candidate plans, target/SLO rules and comparisons. Already-used181003 is not fresh evidence. No horizon/weight search. |
| Bind ITT and application | Five timed assignment inputs, published past prefix, actual ACK/CAS/retry/delay records and protocol-specific compliance law; no future ACK input or success-only selection. Unbound timing/target refuses. |
| Conditional plan/state support | Check known design probabilities and observed joint pre-history/plan/missingness cells with independent complete-block counts. Prespecify minimum evidence; do not substitute request/bin occurrences for blocks. Zero/unknown or inadequately observed support masks the candidate, not an extrapolated control recommendation. |
| Nonanticipation/exclusion | D's N-output cannot exploit assignments that cannot act before N under the bound protocol; same relevant prefix/common law gives the same response. H's service excludes cap/cost/headroom labels and changes only through physical state. Certified nonbinding/common admitted paths provide a negative control, not a universal zero total-effect theorem. |
| Keep actual progress/unknowns | Retain all raw five request fields and receipt ages/masks. Validate same-ID reported transitions without equating scheduler counters, delivered tokens or GPU execution. Unseen/transient/tail/replay mass stays unknown rather than decaying or zeroing. |
| Honest comparative prediction | Same pre-cut eligibility, full-offered target and masks for D/H, history and the stronger direct-birth aggregate hybrid; report future-label/ACK exclusions, all 1/3/5 results and four origin groups. Primary next prediction diagnostic is full G5 block-weighted MAE, not original-cohort loss. A claimed incremental benefit must appear over the stronger comparator on the sealed new complete Train blocks; otherwise retain the negative. |
| Joint feasibility and uncertainty | G1<=G3<=G5 for the same future-terminal definition; scenarios conserve counts/cost/owners and preserve natural/length/censor distinctions. Test plan/history-conditional and selected-plan or simultaneous candidate/horizon coverage. Random-policy marginal bands alone fail this gate. |
| Authority boundary | Passing an offline prediction check qualifies only that scoped diagnostic. Physical-natural labels, online callback availability, off-policy/optimizer risk, native overhead and safe fallback still require their own evidence. No active permit follows from this receipt. |

A comparable fit experiment is thus narrowly specified: freeze the next
previously unexposed **complete Train** block set; fit D with full-plan
interactions/history and H with qualified joint progress, using the same
common future law and origin/availability contract; compare total and
component losses/support-refusals against the stronger aggregate hybrid.
Publish signed per-block differences and exclusions, not a vote or a new
statistical victory from correlated frames. Future One-move and MPC must
share that model, horizon/SLO/cost/ACK/observer/risk contract and strong
continuation; only the admissible plan family differs.

The frozen physical-natural performance/statistical proposal, practical
.10 good/s margin and multiplicity family remain proposals, not this
prediction gate. Source hashes do not prove independent blocks or replace
the exact2..16 comparison boundary. Old Final160021..160024 remains untouched.

### R7 exact source/test receipt

```text
36d24ec54b111fa2137ab7745b83f8068be389f978b98fd90e9c3b42ffe824f1  native_experiment_audit.py
913beaa8384e9a9167b3b3e09a8d6284c4205e43519458fa120bc8415bef4f56  test_native_experiment_audit.py
```

Existing standard-library runner: **48 portable methods passed**, no skips;
three new R7 methods plus all R5/R6 and earlier contracts. Separate pinned
R7 replay verified12 manifest files/four module digests and eight named
source witnesses. Whitespace passed. Source-bound diagnostic JSON comparison
verified the eight roundoff-only differences described above. No model fit,
new dependency, native/GPU call, active permit or full/native quality-gate
claim. Only the three owned paths change; final ordinary local commit carries
the Copilot trailer and exact bytes, not an auto-WIP completion. No push/merge
or DB mutation; Mayor retains in_progress and adjudication.

## R8: prospective actual-capture publisher/consumer bridge

**Bounded result:** `CaptureReceiptBridge` passes directly as the actual
`capture_chat(..., observe=bridge.observe)` callback. Its CPU integration
executes Mayor's real capture implementation with HTTPX `MockTransport` and
an `AsyncByteStream`, not a capture shim or retrospective final-row adapter.
No native collector/runtime integration, GPU experiment, hot patch or
endpoint/model authority promotion was performed.

### Interface and accounting

Create a bridge with publisher/observer run UUIDs, the common clock domain,
and separately invoked publisher and consumer clock callables. Before
spawning or validating each capture task, call
`register(request_id, scheduled_at, original_offered_estimate=...,
estimate_provenance=...)`. The UUID and original estimate are immutable;
an estimate can be unknown (`None`). A known estimate requires positive
finite non-Boolean value and source-hashed provenance, with nested finite
metadata copied rather than shared. It is never promoted to a Gateway
reservation charge or GPU-work estimate. Both charge and charge-provenance
fields remain explicitly unknown.

| Actual capture callback | Published history event | Meaning |
|---|---|---|
| `offered` | `sent` | Actual client attempt initiation, before POST; not wire delivery proof |
| `first_content` | `first` | Actual first SSE content callback |
| `terminal` | `terminal` | Current terminal callback, including rejection, timeout, failure and cancellation |

The prospective registration publishes the legacy R5 `offered` **intent**;
it is not an actual offer/send. R5 `history.cut()` semantics remain available.
The bridge's `cut()` makes the distinction explicit: `registered`,
`planned_due` and `planned_pending` describe registrations, while
`offered`, `sent`, `pending` and `arrival_attempts` describe receipt-visible
actual attempts. External arrival history must use `arrival_attempts`, not
the count of planned rows. Future-scheduled registrations remain visible
as known plans without being counted as attempts. Late attempts are retained.
Terminal status counts include all registered outcomes, including unsent
cancellation; an unsent cancellation adds no actual offer/send.

These are counts of **observed receipts**, not a certificate that no omitted
attempt occurred. Cancellation before the coroutine starts, or validation
failure before the source's callback scope, can leave a planned registration
pending/unknown. Neither terminal nor send is invented to close that gap.

### Receipt chronology, loss and source boundary

Each bridge publication is stamped NOW by the publisher, then independently
received/stamped by `OfferedReceiptHistory`. The source callback's own
publication stamp and copied row are retained separately. Source/run/domain,
UUID, scheduled origin, event/status consistency and contiguous publication
sequence are checked; producer-supplied receive times and future/regressing
clock cuts remain invalid. Matching publication declarations do not
authenticate execution of the declared source.

Nested rows and estimate provenance are copied on publication and cut.
Monotone sealed cuts retain their original prefix after subsequent callbacks,
terminal outcomes or live errors. A final row cannot masquerade as an
`offered` or `first_content` callback. A terminal row may disclose an earlier
first-content fact only at that terminal receipt: if no first publication was
observed, `missing_first_publication` is counted and the `first` receipt
remains absent. No earlier cut is backfilled.

Dropped numbered publications fail at the next delivered sequence gap.
Delivery exceptions latch their original bridge error type; subsequent
callbacks fail closed without replacing that root cause. The actual capture
can still complete HTTP and record its own later callback error, which is
distinct from the bridge root error. `observation_error` is a live diagnostic,
not information available to an earlier as-of cut. A silently lost final
publication cannot be excluded without heartbeat/acknowledgment or another
qualified completeness protocol.

Accordingly `publisher_complete_through_cut`,
`callback_source_authenticated`, `independent_native_eos_verified` and
`active_mpc_permit` all remain **false**. API completion/stop is not independent
physical EOS. The byte-bound Train audit and physical-natural endpoint,
primary metric, sample unit, margin and multiplicity proposal are preserved
as proposals, not binding benchmark rules or native-controller permission.

### Executed CPU integration and exact receipt

Pinned actual source, read-only interface context:

```text
/home/daniel_lin/gt/pr32/mayor/mpc-native-integration/mpc_lab/http_capture.py
a8bbafd6a84f8a1581a2f0e0d0fe11a086c542e392a45c1466fa9071df93fb6c
```

Seven integration methods execute that digest-checked implementation with
fake HTTP transport and clock callables. They establish that the attempt
callback is visible before POST, first-content is visible during SSE, and
terminal is delivered after finish; check immutable earlier cuts and nested
copies; exercise unsent and sent cancellation, late rejection, timeout and
transport failure; distinguish numbered delivery loss from a callback lost
before bridge publication; retain a delivery `OSError` through later
fail-closed callbacks without changing HTTP completion; and refuse foreign
domains, unregistered UUIDs, final-row callback substitution, invalid
estimates and mismatched source envelopes.

The supplied Python3.12 executable was attempted but its uv-managed base
interpreter was unavailable here. Earlier default Python lacked HTTPX/pip;
one dependency installation attempt failed under sandbox network policy.
There was no installation retry or dependency skip. The successful execution
used available **CPython3.14.4** with already-provisioned **HTTPX0.28.1** from
the supplied environment's site-packages and the actual Mayor package.
This qualifies the stated CPU behavior on that environment, not Python3.12
or native/full-project quality gates. The known failed-install scratch venv
was removed.

```text
PYTHONPATH=/home/daniel_lin/gt/pr32/mayor/mpc-native-integration:/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr32-mpc-py312/lib/python3.12/site-packages \
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s experiments/mpc-research/native-v3 -p test_native_experiment_audit.py -q

07204d573c5ab42fb9bed5b4db2ec57d57f5ffb1b4c755bbbcd2a981b5d40b98  native_experiment_audit.py
ad332a82def6ea3c73efe8ce75817987ac05aad626d8869f6997dd64c555f8a6  test_native_experiment_audit.py
```

**55 methods passed, no skips**, including all existing portable contracts.
Whitespace passed. Only the three owned files change; ordinary local commit
with Copilot trailer is the receipt. No Calibration/Validation/Final outcome
read, GPU/native HTTP call, DB mutation, push or merge. Actual runtime hookup
still requires independently qualified source-bound stages, real client
receipt delivery and completeness/error handling; no retrospective
publication backfill or active permit follows from these CPU tests.

## R9: source-bound online model-input cuts, with explicit v5 refusal

**Bounded result:** `OnlineModelInputAdapter` consumes the real R8
`CaptureReceiptBridge` and frames parsed by Mayor's actual
`estimate_native_state`. It supplies receipt-visible public payloads, actual
attempt/first/terminal history, immutable Gateway owner charges and native
reported progress in separate namespaces. It deliberately returns
`v5_input=None` and named refusals rather than forge a fully qualified
`admission_cut_state`. No final client rows, terminal-header lineage,
native/GPU call, fit or controller permission is used.

### Versioned public registration and model-input interface

`bridge.register(..., public_metadata=metadata)` publishes
`native-v3-offered-registration-v2`; subsequent actual callback publications
retain their explicitly declared v1 envelopes. Legacy registration without
metadata remains v1 and unknown, not silently upgraded. The v2 consumer rejects
missing metadata and rejects metadata smuggled into a v1 envelope.

The closed `native-v3-public-payload-v1` metadata has exactly:
`requested_max_tokens`, `prompt_class`, `prompt_token_estimate`,
`source_sha256`, `prompt_estimator_sha256` and its `schema`. Requested maximum
is a positive finite integer. Prompt class is unknown or one of the public
labels `short`, `prefill_heavy`, `mixed`; token estimate is unknown or a finite
nonnegative integer. Any known prompt class/estimate requires an estimator
source digest. No prompt text, arbitrary labels, secrets or extra metadata
fields are accepted. Source digests declare provenance, not authenticated
execution or successful estimator transfer. The model input labels that
distinction explicitly. Callback maximum must match the prospective
registration; a mismatch latches measurement error without converting actual
HTTP completion into a model-qualified observation.

Register before task creation, then pass `observe=bridge.observe` to actual
capture. Construct `OnlineModelInputAdapter(bridge, native_binding, clock=...)`;
call `receive_native(frame)` for contemporaneous frames and `cut(cut_at)` for
monotone model-input prefixes. A bare `NativeState` or final row cannot replace
the bound frame because `NativeState` alone does not retain native run/source
lineage. The adapter calls the actual parent parser and retains the resulting
immutable state. Native source/run/domain, observer digest, identity,
sampling chronology, age and Gateway sequence are checked. This receiver
stamps NOW independently of the upstream frame's receipt; upstream receipt
must already be in the past. Native source publication time is explicitly
unknown, not synthesized from sample or receive time. Duplicate/regressing
native samples and regressing Gateway sequences refuse.

`cut()` contains source/run/domain and both receipt watermarks, registration
schema/sequence and actual-event publication/receive stamps; current client
API lifecycle observations; pending **client** attempts; native/Gateway
sampled reports and their receipt; and two all-observed-attempt payload mixes.
The coarse mix counts requested maxima, while the joint public mix preserves
prompt class/estimate and their source definitions. Planned-only registrations
contribute to neither mix. Missing metadata contributes to an explicit unknown
count, not a guessed class. The receipt-count/30s arrival proxy is labeled an
**incomplete approximation**, not the fitted v5 law or measured native
capacity. Old/empty prefixes cannot prove a zero arrival process.

### Exact observable versus missing feature boundary

| Component | Honest adapter output / boundary |
|---|---|
| Original Gateway cost | Each current source-bound Gateway mark keeps its whole owner charge and cost identity. Offered estimate/None is separate; client attempts have unknown actual charge. No class-cost lookup substitutes an estimate. A reported cost17 under budget16 is retained, not clipped or evicted. |
| Native progress | All reported prompt/computed/output/maximum fields remain present for engine IDs. Reported computed progress and output headroom are not delivered tokens, physical execution or remaining EOS work. |
| Namespace coupling | No engine/Gateway/client join is made, even for a whole engine ID containing the client UUID or a later successful response header. Source context binding is not request lineage. |
| Waiting/invisible work | Waiting/pending/frontend counts remain reported counts. Waiting-work and accepted-not-native-visible work are explicitly unknown. Snapshot age and transient births/deaths prevent treating a sampled inventory as complete instantaneous cut state. |
| Pending/lifecycle | A sent client without terminal receipt is pending with unknown Gateway status and unknown original charge. It is not automatically added to stock, re-admitted, rejected or declared native-invisible. Snapshot disappearance and API terminal do not independently certify release or EOS. |
| v5 progress keys and cost table | Unverified request lineage, per-cell cost uniqueness/identity and prompt-estimator transfer withhold an exact v5 input. Equal requested maxima do not prove equal prompt class or charge. |
| Plan/compliance/support | A reported budget/version is not the full pre-assignment command/ACK history. Future ACKs, randomized-plan conditional support and optimizer risk are not fabricated. |

All snapshot and client records are copied. Later receipt delivery, native
progress, terminal classification, response headers and caller mutations do
not change a sealed equal-time cut. Changing the feature window at an already
sealed cut refuses. Terminal status appears only after its actual callback
receipt and remains an API label; no future outcome or EOS is an input.
Source authentication, global completeness, independent physical EOS and
active MPC flags remain **false**. Missing exact features produce explicit
v5 refusals, not an admissible replacement benchmark.

### Independent frozen-v5 critique and executable witnesses

Reviewed the same frozen `nv3-opus-admission-birth-v5` implementation:

```text
b1d83f7af2956d51b5f9d9b014ecff50b2b3a6915c5f10cdb52f034ed8a920b5
```

The new pinned CPU witness executes its actual `simulate_plan` and
`kernel_draw`, without Train outcome reads or changing peer code:

1. **Pending status is not identified by re-admission.** A past pending
   cost17 attempt, no current visible owner and no future offers, under the
   all16 plan produces offers5=0 and rejected5=1. This is not by itself a
   conservation violation: the target counts rejection terminal receipts,
   which can follow past sends. It instead exposes the declared latent-status
   approximation. The same receipt prefix/older empty snapshot is compatible
   with already admitted work awaiting response, or an attempt still in
   transit. Lowering the cap cannot reject the former's original admission;
   it can reject the latter when it arrives. Re-testing both at the cut
   selects one unverified latent pathway. Neither a same-state causal effect
   nor a universal non-eviction guarantee for actual pending work follows.
2. **Cyclic conditioning biases the empirical kernel draw.** With ordered
   records A=(release2,good1.5,terminal2), D=(.5,None,.5),
   B=(3,None,3), and pending age1, D is ineligible. Uniform start positions
   followed by cyclic next-alive search produce A,B,B: probabilities1/3,2/3,
   rather than uniform conditional probabilities1/2,1/2 over A,B. The three
   equally wide start-index strata are reproduced by uniforms .1,.5,.9.
   This biases release and good draws before any coverage/transfer issue.
   Filtering eligible records first and drawing uniformly from that set is
   the minimal separately reviewed repair; it would change frozen v5 and
   therefore must not silently replace the existing Train6/7 result.

Further source-bound boundaries:

- `id_progress_state` uses joined output bins, first/terminal lifecycle and
  running/waiting bins, but not computed-token progress. Those raw observables
  are available in parent NativeState; old keys losing them are not evidence
  that they are unobservable. Missing first publication under incomplete
  history does not prove a TTFT miss. API stop/mean-TPOT labels remain
  different from the proposed independent physical-natural endpoint.
- `_load_bin` counts reconstructed Gateway owners in bins8 capped4, not
  native running competition, waiting work, phase or KV pressure. Back-off
  to a coarsest nonempty table and HAZARD_MIN occurrence counts do not prove
  conditional plan/state positivity or independent block support. Upper
  release bounds are a stated convention, not a universal safe bound after
  admission/load/service trajectories change.
- Simulated planned slots use immediate admission budgets. Actual ACK/CAS
  timing, retry, holds and delayed application need a prospective compliance
  contract. Same pre-cut observations are required for a causal candidate
  contrast; paired arms have diverged histories. Marginal randomized-path
  excitation does not certify constant/multistep plans in every state or
  coverage under optimizer-selected plans.
- Mayor reports unchanged Train6/7 G5 MAE4.42/4.23 and band coverage.577/.614.
  Those are retained positive point-prediction development diagnostics,
  **not independently re-executed here**. Coverage remains below nominal.80;
  correlated frame counts, source hashes and the two reused Train blocks
  do not turn these bands into calibrated or optimized-policy intervals.
  No horizon/SLO/weight change, statistical rescue or Final claim follows.

Minimal next acceptance is therefore a genuine receipt/lineage and
charge-qualified integration stage first, then a separately frozen numerical
conditioning repair and latent-state/ACK contract tested on previously unused
complete Train blocks. Keep the current v5 results as frozen evidence.
Use identical receipt eligibility, SLO/target definitions and common
exogenous future law for comparisons; publish refusal, per-block prediction
and selected-plan uncertainty rather than infer deployment permission.
The earlier primary metric, independent-block sample unit, .10 good/s margin,
multiplicity family and physical-natural endpoint remain proposals.

### R9 executed source/test receipt

Read-only actual parent sources: capture SHA
`a8bbafd6a84f8a1581a2f0e0d0fe11a086c542e392a45c1466fa9071df93fb6c`;
NativeState SHA
`835df8ebaa58c773074e65cedba4627b468d14b560233a7655bf9cd2240b83d6`.
Six new methods execute real capture/mock HTTP and the real parent parser;
exercise pre-POST and during-SSE cuts, later native/terminal receipts,
copies, explicit schema versions, public-field rejection, foreign/future/
stale/unbound native inputs, missing payloads and owner disappearance;
and reproduce the pinned v5 witnesses. All **61 methods passed, no skips**;
whitespace passed.

```text
7779662df37424c40ae64216aa9bcf8fd86bad4714ee5e110e1520ed0e11e181  native_experiment_audit.py
cae37069cec4c848083950b8e09d5a2aa5894bc785e77fa00a7f55a4284b979a  test_native_experiment_audit.py
```

The requested provisioned Python3.12 executable was attempted once and remains
unavailable (exit127). Validation used the already working R8 command:
CPython3.14.4 plus provisioned HTTPX0.28.1/site-packages and MayorRoot on
PYTHONPATH, with PYTHONDONTWRITEBYTECODE=1. No dependency installation, skip,
native-source modification or Python3.12/full-project gate claim. Only the
three owned files change, with an ordinary local Copilot-trailer commit.
No Calibration/Validation/Final read, live native/GPU request, DB mutation,
push, merge or runtime hookup.

## R10: conditional client/Gateway lineage and fixed-mark interference audit

**Bounded result:** a pre-outcome, local producer-read interface qualifies
client/Gateway UUID equality under a proved source contract, not an
authenticated runtime certificate. Known accepted work cannot be re-admitted;
original charges remain separate from offered estimates. Native IDs remain
unjoined. A fixed-CRN executable witness also establishes that frozen v5
cannot update previously drawn service/completion marks after later
admissions. Neither result promotes native MPC or changes the frozen model.

### Actual producer dataflow and minimal contract

Read the actual parent implementations, not only earlier reports:

| Source | Proven path / boundary |
|---|---|
| `gateway.py:488-498` | With BENCHMARK_REQUEST_IDS enabled, a supplied exact lowercase hex32 header is validated, checked against the non-evicting per-run registry and registered before `telemetry.received(request_id)`. Invalid/duplicate/capacity-refused IDs do not enter that path. Missing headers still generate IDs and are **not** equivalent evidence. |
| `telemetry.py:320-330` | A nonempty supplied UUID is returned unchanged; current active state records receive time and subsequently sets the admitted bit. Ordinary records have run/time but no complete versioned domain/publication receipt contract. |
| `gateway.py:399-410,585-589` | In cost-aware MPC-lab mode, the same request_id becomes the RequestMark owner under the admission lock, with immutable original charge and receive/admission clocks. No original charge is obtained from a client offered estimate. |
| `gateway.py:565-568,621-625,672-673` | The benchmark header is removed upstream and outgoing x-request-id uses the same UUID. Downstream x-request-id is overwritten with that UUID, even when the upstream response supplied a different one. This echo is not NativeID lineage. |
| `gateway.py:741-761`, parent parser | Atomic source-bound snapshots retain owner IDs, cost identity, sequence and run/domain. Snapshot receipt before the cut, not a later terminal header, is the observable mark evidence. |

The resulting conditional join contract needs: the real capture attempt
publication; a same-run/domain/identity producer observation proving that
this UUID entered the validated benchmark registry and telemetry active
state; and, for a charge/owner join, a received source-bound Gateway mark with
the **whole exact UUID**, consistent chronology and payload maximum.
The experiment's non-reused physical UUID assumption remains necessary.
Source hashes and registry logic do not authenticate execution, request
origin or an untrusted remote peer.

`receive_gateway_uuid_binding(gateway_module, request_id)` accepts only the
local producer object, not a declared binding dictionary. It checks pinned
Gateway/Telemetry/runtime/clock-helper sources, benchmark/cost-aware/MPC-lab
and single-worker configuration, exact run/domain/identity, and a real
capture-source attempt before client terminal. The UUID must be in the actual
producer's validated registry and active telemetry state before Gateway
outcome. The observer stamps its read independently NOW; producer publication
time/sequence remain **None**, not invented from receive time.
The versioned receipt preserves current observed admission bit: true means
accepted was observed, false means admission remains unknown, not rejection.
Only one such UUID observation is accepted per adapter.

Model-input schema advances explicitly to
`native-v3-online-model-input-v2`. A receipt-visible accepted bit or matched
mark gives `known_gateway_accepted=True` and `readmission_allowed=False`,
even if its charge has not yet appeared in a snapshot. Matching marks provide
actual charge and observation provenance; all earlier accepted marks are
retained for original-cost knowledge, with cost/prompt/maximum/receive/admission
invariants checked across snapshots. A changed original owner charge refuses.
Missing/stale/currently absent marks do not undo known acceptance or turn
the client into a new offered arrival. `gateway_owned_at_last_sample` describes
only the last sampled report, not complete instantaneous cut ownership or an
exact release time. Client terminal and owner disappearance still do not
prove native release/EOS.

Before binding, after wrong source/domain/run, or without individual header
evidence, the R9 unknown/no-join behavior remains. New binding/mark/terminal
receipts cannot change an equal-time sealed cut; old charges are never
backfilled into a cut that could not observe them. Native engine IDs are not
joined by equality guesses, contained UUIDs, suffix stripping or later
response headers. All source-authentication/global-completeness/physical-EOS/
active-MPC flags remain false and v5_input remains None.

### Producer observations still genuinely required

The local interface is executable qualification scaffolding, **not** a
remote runtime integration. For remote/asynchronous consumers, the current
snapshot schema does not carry individual benchmark-header acceptance.
Publish a versioned `benchmark_uuid_received` diagnostic at the actual
validation/telemetry receive boundary with UUID, Gateway run, domain,
source contract, publication sequence and NOW publication stamp; independently
stamp observer receipt. An accepted diagnostic after the actual admission
lock should carry the original charge/cost identity if accepted-but-not-yet-
snapshotted traffic must be resolved. A header-received diagnostic alone
cannot declare admission. Delivery/error/drop/completeness handling needs
separate qualification; none is inferred from hashes.

Remaining NativeID lineage needs a source-bound observation **at native
request creation/assignment** linking the consumed upstream API UUID to the
exact opaque engine ID (and explicit parent/child lineage if requests split).
Outgoing x-request-id only proves what Gateway transmitted, not what the
engine assigned. A creation mapping received later becomes usable only at
that later cut. This is an observable producer instrumentation requirement,
not a demand for physical EOS. EOS is unnecessary for identity/admission
qualification and remains a separate endpoint/work-label question.

### Independent physical audit of unchanged frozen v5

The additional witness executes the pinned b1d83f7 frozen `simulate_plan`,
with identical uniform draws/common arrivals under all16 and all32:
one live owner cost1, an early birth at.1 cost1, and a later birth at.2 cost17.
The later birth rejects under16 but is admitted under32. The live cohort
mark is (release2,good1.5,terminal1.5); the early birth mark is
(relative release2,good.8,terminal.8). The late birth has no good mark.
These are hypothetical kernel inputs, **not native results or fixture-fit
claims**.

Instrumenting the actual kernel_draw calls yields two draws under16 and
three under32; the first two calls and returned marks are exactly equal.
Rejected5 is1 versus0, but good1=1 and good3/good5=2 under both plans.
No min_alive conditioning is used, so this witness is separate from the
retained R9 survivor-selection bias.

**Independent conclusion:** future admitted composition cannot change an
already-live cohort's drawn release/good/terminal marks in this simulator.
After an earlier birth's mark is drawn at admission, a later admission cannot
change that mark either. The loop only pops fixed owner expirations and
assigns new birth marks; it never advances/reconditions existing progress or
hazards under the changed batch. Admission-time owner-count bins can change
a *new* birth's mark, but do not represent subsequent mutual interference.

That representational gap is **not automatic physical invalidity**. Fixed
conditional marks can be useful reduced-form factual predictions: they can
marginalize typical future load under the observed policy, or approximate a
regime with negligible incremental interference. The retained Train6/7 point
diagnostics and under-covering bands remain unchanged evidence. Prediction
improvement alone does not establish invariance to counterfactual batch
composition, repeated cap switches or optimizer-selected plans. If service
depends materially on subsequent shared prefill/decode competition, that
feedback is outside frozen v5's transition family, rather than fixed by a
more accurate one-time mark table. No observed GPU interference magnitude
or causal policy win is asserted here.

### Minimal batch-aware transition hypothesis, not a refit

Keep the frozen horizons1/3/5 and v5 step.5s. Maintain an observable/masked
state X_k with source-qualified owner charges, current engine-reported
prompt/computed/output/maximum progress, running/waiting/pending/KV summaries,
client receipt phase and ages, plus explicit unknown/unmapped mass.
Admit common/exogenous future payloads through the actual ACK-in-force
reservation budget; do not give the budget a direct GPU service effect.

Update **all active cohort and born IDs**, not just the newest one:

```text
(progress increments, first/terminal/release competing events)_k
  ~ K(X_k, current batch phases/payloads, request ages, common service noise)
X_{k+1} = coupled progress + admitted births - qualified/latent exits
```

A minimal survival version recomputes lambda_i(X_k,phase_i,age_i) every step,
accumulates integrated hazard and crosses a fixed request/scenario uniform
threshold. Fixed latent thresholds/common exogenous arrivals preserve CRN
comparability while later admissions can change future hazards for earlier
work. Progress increments and lifecycle events need joint feasible scenarios,
immutable whole-cost owners and separate API/native/tail/release meanings;
unmapped or snapshot-transient work is not zeroed. Service/progress is not
exclusive serial HTTP-first residence or absolute GPUelapsed.

This is only a separately sealable transition hypothesis. Qualify lineage/
receipt stages first; then freeze a progress/hazard diagnostic on previously
unused complete Train blocks, with pre-assignment histories, ACK timing,
common future law, same target/masks and support refusals. Test existing
cohort/earlier-birth transition prediction conditional on later batch changes,
without post-action state masquerading as identical pre-treatment state.
No source/model/SLO/horizon search, new block10/11/12/13 scoring or Final
access occurred. The original endpoint/statistical/practical-margin proposal
and frozen conditioning negative remain unchanged.

### R10 executed receipt and precise environment limitation

Source pins:

```text
5e3e2f45a20ed66afed21b93b79f217138edc771493ecca7e963e102c4a94c7d  parent gateway.py
46d6fb923e558f6435d269dd6fa5cfd5b0d71eb1fd91cbb3aaca8a82385e6370  parent telemetry.py
f04c58eb9b5a81e7e1c7a22aaea1cd6b59de88c568ec77d51f1487af4c85b727  parent mpc_lab/runtime.py
cbbd1f338e0d078d5c5eacdfbcec725dcfe2ed9b46c1ee1ed68ad2f26de24e1f  parent clock helper
b3352af84f17b4d23bdc9120da8907a0fed785309936740f42ecda0a36ec05b0  native_experiment_audit.py
72946e3568fab053790722e43b18e14bae7578b961d821a4e92ef536b4326e34  test_native_experiment_audit.py
```

**65 scoped CPU methods passed, no skips**; four new R10 methods plus all
previous contracts. Whitespace passed. The lineage trace executes the actual
chat/admission/cleanup/snapshot function bodies, actual Telemetry,
capture_chat and parent native_state through real HTTPX mock/ASGI transports;
Native reports are explicitly CPU mocks, not GPU captures.

Full Gateway/FastAPI import was attempted and failed because provisioned
Pydantic native bindings cannot load here. The first source-body harness also
encountered the NumPy CPython3.12 extension incompatibility under available
CPython3.14.4. No package installation, ABI trick, dependency skip or
Pydantic/NumPy shim was used. The passing harness explicitly extracts the
unchanged tested function bodies, removes FastAPI import/routing scaffolding,
uses real Starlette Request/responses/routes with JSON serialization of the
actual snapshot result, and executes the pinned dependency-free clock-domain
function body. Tokenizer absence is the existing intentional CPU-fixture
fallback, not tokenizer qualification. This scope does **not** qualify the
full FastAPI application import/lifespan, Python3.12/native execution or
remote runtime integration; those gates remain unmet.

Validation uses the R8/R9 CPython3.14/provisioned HTTPX command recorded above.
Only the three owned files change; ordinary local commit with Copilot trailer
preserves the receipt. No live protocol/source modification, GPU/SSH/remote
request, DB mutation, push or merge.

## R11: one evolving batch-progress candidate; native fit withheld

**Independent bounded result:** `evolving_batch_progress` is one executable
simultaneous, composition-dependent transition prototype. Later admitted
requests affect progress of existing/earlier-born requests; cap enters only
through admission/population. A source-bound fit was actually attempted on
three fixed already-used Train1/2/3 artifacts. Its declared closed-work mask
has **zero eligible intervals**, so prefill/decode rates remain **None**, not
invented coefficients or zero service. No native forecast or MPC qualification
follows. No other model's R11 conclusions were read.

### Minimal x,u,w,f,h and prototype boundary

x assumes one opaque actor per original Gateway owner (split-child ownership
is unsupported), with immutable original Gateway charges, reported
prefill headroom `max(prompt-computed,0)`, native output count/maximum,
current KV fraction and explicit unknown waiting/unmapped-work flags.
Native computed progress, native output, delivered tokens and EOS remain
distinct. u is a declared **applied** reservation budget16/32 sequence on the
existing .5s grid, not concurrency or a future ACK oracle. w is one common,
cap-independent ordered future-offer/payload scenario plus uniforms keyed by
request/step/phase; examples are hypothetical, not realized future inputs.

For each step, admissions use current whole-owner stock plus original charge;
no existing charge is evicted or re-admitted. Count phase composition before
any actor update, then update all actors simultaneously:

```text
D_k = max(1, 2*n_reported_prefill + n_reported_decode) * (1 + KV_cut)
mu_i,k = r_phase(i) * .5 / D_k
increment_i,k = floor(mu_i,k) + 1{U_request,step,phase < fractional(mu_i,k)}
```

The prefill weight2 is one explicit hypothesis, not a fitted GPU token budget.
KV_cut is a constant-cut proxy: future KV evolution is explicitly unfit.
Prefill increments reduce reported headroom; a phase completed within a step
enters decode only next step. Decode increments advance modeled native output
within reported headroom. Decode computed-token/tail execution is not thereby
predicted or equated with output. Actors at zero output headroom are retained;
that is not an EOS observation. Native/lifecycle exits, API good outcomes and
Gateway release are all **None/unfit**. Charges remain held over this bounded
prototype horizon, not released on modeled output or HTTP first residence.
That convention is conservative about recorded stock, not a calibrated
performance/risk bound.

h remains the R9/R10 receipt/sample observation contract. This function takes
only closed hypothetical actor/state schemas: terminal/EOS/header fields,
unknown original charges, reused IDs, unsupported budgets or unknown
waiting/unmapped population refuse. `batch_progress_input_refusal` explicitly
withholds initialization from current online inputs: pre-outcome client/Gateway
binding is preserved, but engine-owner lineage, latent work, future charge/
arrival/ACK law and lifecycle/risk transition are unqualified. No fictitious
NativeID join or callback receipt is generated to initialize the prototype.

### Fixed-CRN interference and same-mask comparators

The runnable test starts with one decode actor, admits an early decode birth
at step0, and offers a prefill-heavy charge17 birth at step1. With the same
seed, rates and offers, all16 rejects the later birth and all32 admits it.
Before that later admission, actor states are identical. Subsequently the
evolving denominator slows **both** the initial actor and the earlier birth.
The frozen-composition ablation leaves their marks/progress equal between
plans despite that admission difference. Uniforms for existing IDs are not
shifted by inserting a new actor. Replays and actor-order permutation are
deterministic.

A separate one-move/multistep test shares the exact original-cohort ID mask,
noise, parameters, offered law and 1/3/5s cuts. One-move holds32; multistep
uses32,32,16,16,32,32,16,16,32,32. A later charge2 offer admits in the one-move
case but rejects while the multistep cap is16; previously admitted stock18
is not evicted. Existing-cohort progress changes only through that population
difference. A no-new-admissions negative control gives identical transitions
under16/32 even with existing charge17. These are model/falsification
witnesses, **not native OneMove/MPC results**. No search or weak controller
baseline is substituted for the frozen experimental comparisons.

### Actual used-Train fitting attempt and exact blocker

`fit_batch_progress_artifacts` accepts exactly p4096/m128 arm0 event artifacts
for181001..181003, verifies declared bytes and calls the actual pinned parent
NativeState parser. It uses only native-frame observations; future native
counter increments are offline training **labels**, never forecast inputs.
Engine IDs are compared exactly within their native namespace, without a
client/Gateway suffix join. Features are the prior sampled/received native
phase/count/KV state; the later sample must occur after the prior receipt.

The unchanged mask requires nonempty repeated native inventory endpoints,
no waiting/pending/unrepresented frontend work, a non-overlapping gap<=.5s,
unchanged prompt/maximum and supported phase/counter transitions. Repeated
endpoint inventory does not prove no transient births/deaths between samples.
The tentative phase rate estimator is total reported increment divided by
sum(dt/D); interval/request counts are correlated observations, not independent
trials or GPU-exclusive durations. Lifecycle/exit labels are not fitted.

| Used artifact | Empty inventory | Inventory changed | Same inventory but unknown work | Eligible |
|---|---:|---:|---:|---:|
|181001 p4096/m128 arm0|50|431|396|0|
|181002 p4096/m128 arm0|32|452|387|0|
|181003 p4096/m128 arm0|46|428|407|0|

Both exposures and increments are zero **because the mask rejects**, not
because native service is zero. No coefficient is supplied. I did not relax
pending work into known-zero workload, drop the unknowns, or retune the mask
after this negative to manufacture a fit. The closed-observed-population
candidate is therefore currently unusable on this scoped factual fit set.
Missing exact engine-owner lineage and prospective offered charge/arrival/
ACK inputs independently block a factual cap-plan rollout. This is the
concrete conservative-prototype fallback, not an invented native result.
Train4..9 outcomes were not rescored; no claim extends these three-artifact,
single-cell/arm receipts into those development blocks.

```text
3170f5eb991a8a69311870f5d809fe9b05d1e03f1735403d6af9001438f99789  nv3-181001-p4096-m128-arm0.events.jsonl
fbe1f49dcea63775d0f94fd09dd2fac4752d99ce585437a6b20776f7a8434324  nv3-181002-p4096-m128-arm0.events.jsonl
9b0fd7aa47ba6b7a93340ade8e6c315d2f752d6a7ce3aa0f1a6c3af0afaca0dd  nv3-181003-p4096-m128-arm0.events.jsonl
```

The initial fit command encountered cwd package shadowing (local mpc_lab lacks
native_state); explicitly putting MayorRoot first resolved the import and
produced the real source-bound negative above. No alternate parser, dependency
installation, native-data fabrication or ABI workaround was used.

### Preregistration BEFORE fresh181012/181013 exposure

This seal is a **prediction/feasibility** proposal, not an authorization to
inspect fresh outcomes or a replacement SLO/endpoint benchmark:

| Item | Frozen specification / refusal |
|---|---|
| Split/source | Fit scope exactly used181001..181003 p4096/m128 arm0; other used4..9 are development only, not fresh. No fit/tune/score on10/11/12/13 or Cal/Val/Final. Fresh12/13 must be byte/source/clock/run sealed by Mayor before any exposure, and complete paired blocks; no request/bin pseudoreplication. |
| Eligibility first | Current candidate has no fitted rates/qualified online initialization, hence **refuses factual prediction before label access**. No fresh performance score is allowed while this gate fails. A latent-work/lineage/lifecycle or mask repair is a different source/spec seal, not silently this candidate. |
| Diagnostic target if independently qualified | Primary reported-native output increment RATE over1s per original visible engine ID, averaged within origin then equal complete block weights; fixed secondary3/5s and one .5s transition. No API first/terminal/EOS conversion. The earlier full-offered G5/SLO/physical-natural proposal remains separate and unavailable from this prototype. |
| Origin/mask | Same pre-assignment receipt prefix, native age/source/context and exact original engine ID cohort for every model/plan. Input uses receipts<=cut only. Predict future arrivals only from the frozen common exogenous law, never realized offers. Planned paths need a separately qualified ACK/compliance law; otherwise only applied-path hypothetical diagnostics. |
| Missing target | Native disappearance, overhang/counter reset, new IDs and incomplete inventories are censored/unavailable labels, not zero progress or successful EOS. Publish all pre-cut eligible origins and label/prediction availability. Complete-label comparisons are explicitly conditional; if less than80% of eligible origins qualify for either predictions or primary labels, no primary improvement claim. |
| Baselines | Same-source/mask frozen-composition ablation with identical phase-rate coefficients/noise and receipt-qualified per-ID last-progress-slope carry-forward, headroom-limited. Require comparison to **both**, not only a weaker no-interference fixture. Frozen v5/strong prior G5 comparisons remain unchanged and cannot be scored against this progress-only output. |
| One/multistep | Same kernel, .5s step, 1/3/5s targets, origin cohort, common law/noise, masks, cost/ACK/SLO contract; only admissible action sequence differs. Report signed block differences, coverage and refusals, not same-state effects from diverged factual arms. |
| Margin/falsification | At least.10 reported-native output tokens/s reduction in primary block-weighted MAE against **each** baseline, positive separately in both fresh blocks; secondary horizons and phase/cell exclusions disclosed. This is a distinct progress-diagnostic margin, not reinterpretation of the earlier.10 good/s practical margin. Failure, zero eligibility, missing-source transfer, cap dependence without population change, ID/cost/count violation or unavailable common law retains the negative. |
| Statistical/authority | Two fresh blocks give no statistical guarantee, calibrated bands or optimized-policy support. Source hashes do not establish independent blocks. This candidate has no joint/lifecycle/risk model and all active/native/MPC permits stay false, regardless of a possible point-prediction result. |

Fresh12/13 remain unopened. No scores for10/11/12/13, no peer R11 conclusion
exchange, no horizon/weight/SLO retuning and no physical EOS demand are hidden
in this preregistration. It makes the current candidate's refusal falsifiable
without rescuing it after seeing fresh labels.

### R11 exact source/test receipt

```text
a9cfb8590fd37bf4ba0cf59c8de8d3fc925e4b5e77265e6b720478d5c2b330ad  native_experiment_audit.py
ef04ed35c4e0161a7e5ef30774a78ff47f4667f9fa866aa244635a310185f051  test_native_experiment_audit.py
```

**71 scoped CPU methods passed, no skips**, including six new transition/
comparison/source-fit/refusal methods and all existing receipt/lineage
contracts. The source-bound three-artifact fit negative was separately
executed and reproduced. Whitespace passed. Environment remains the R10
CPython3.14/provisioned HTTPX setup; full FastAPI/native/Python3.12 gates remain
unqualified. Only the three owned files change; ordinary local Copilot-trailer
commit preserves the artifact. No live native/GPU/SSH request, new paid
resource, DB mutation, push, merge or source/runtime hot patch.

## R11 follow-up: separately versioned native OUTPUT-counter observations

**The closed-work fit above remains empty and unchanged.** Normal asynchronous
pending batches are not zero unknown GPU work. The new
`output_counter_stayer_diagnostic` is a source-bound, partial-observation
diagnostic, not a relaxed fit of the earlier closed-population kernel.
It does not fit that kernel's rates, lifecycle, joint hazard or cap-plan
response. No full Good, exclusive service, physical EOS or controller permit
follows from its point predictions.

### Observation response and fixed comparison contract

Schema is `native-v3-output-counter-stayer-observation-v2`. Fit is exactly
already-used Train181001..181003, development exactly already-used4..9,
**p4096/m128 arm0 only**. Each raw file must match its supplied immutable
manifest SHA; parsing uses the actual pinned parent NativeState source
`835df8ebaa58c773074e65cedba4627b468d14b560233a7655bf9cd2240b83d6`
and raw observer
`29fc1ebd875ccc1a53b9584fd0f3b002c518e3653c9b4238877b67b7ec13802e`.
Frame run/clock/Gateway identity are bound within the artifact. Wrong source,
clock or identity refuses the artifact rather than bridging namespaces.
Byte/source binding still does not authenticate execution or completeness.
No client terminal rows, terminal headers, API finish reasons or aliases are
used. Native engine IDs remain opaque and unjoined to Gateway ownership.

For each qualified native receipt cut `c` and current native ID `i`, the
observation target is its reported OUTPUT-counter increment at the last
qualified received frame `<=c+h`, with native sample age at that target
`<=.5s`. Fixed `h=.5,1,3,5s`; .5 is a transition diagnostic, not a changed
SLO or primary control horizon. An ID must occur in **every sampled inventory**
between origin and target with unchanged prompt/maximum metadata and no
output-counter regression. This is observed-stayer selection, not proof of
uninterrupted physical residence. Disappearance, even temporary followed by
the same ID's return, is censored; absent frames, changed metadata, reset,
overhang, stale target and end-of-record are explicit unavailable statuses.
No missing request is filled from future terminal rows or assumed EOS.
Native IDs newly visible at the target are label context, not necessarily
post-cut offered births: accepted-but-native-invisible work can appear later.

Pre-cut features are reported phase (`computed<prompt`, decode or output
headroom zero), `min(running//8,4)`, waiting-positive, pending-positive,
reported KV quartile and prefill headroom bins `{0,<=256,<=1024,>1024}`.
These are noisy reported-observation covariates, not a complete physical
batch state. Waiting token work, transient inventory, pending ownership,
native-invisible work and actual original Gateway charge remain unknown.
Neither offered estimates nor the16/32 reservation control enter a GPU-rate
equation. Counts/KV do not become scheduler-token budgets or GPU-seconds.

For each fixed horizon/key, fit the mean nonnegative increment on fit-only
observed stayers; back off to phase then horizon-global mean. Full/phase
cells require20 correlated labels; global fallback requires any label.
This threshold is an estimation rule, **not20 independent experiments**.
Predictions are headroom-limited. No horizon/weight/coverage search occurs.
The tables have40 entries,12084 pooled labels across horizons, fit-table SHA
`6e21039353acc634fb076fb43ae392c49fc12448c6913e471c20b27854546fe4`.
Fit support by horizon is7627/4440/17/**0**. Five-second forecast is therefore
unavailable *before* development labels are considered.

The receipt-safe past-rate comparator carries the ID's output-counter slope
from its longest continuously observed prefix within the previous1s, using
only receipts `<=c`, forward for `h`, headroom-limited. It stops at missing/
changed IDs or observation gaps; no prior interval means explicitly disclosed
fallback to the same fitted mean, not zero invented service. A second
phase-only fit baseline uses the same fit labels and development mask.
Both errors divide increments by the prescribed horizon, giving **reported
native output tokens/s**, not a GPU clock rate. First past-available forecast
witnesses include cut/ID/features/rate/prediction but no future label fields.
Changing later native output/phase/inventory in tests changes labels/errors
without changing those witnesses or fit tables.

### Actually executed used-data diagnostic

All nine selected manifests and raw bytes matched; parent parser refusals
were empty. Fit labels:4032/4196/3856, respectively. Fit censor totals were
disappeared10062/10262/9858 and record-end166/166/170. Requests/origins/horizons
are correlated repetitions, not new independent samples.

The following errors equally weight the six *used development artifacts*.
They are descriptive conditional scores, not paired intervention effects,
fresh validation or inferential confidence intervals:

| h seconds | Comparable / all current-ID origins | Model MAE | Past-rate MAE | Phase-only MAE |
|---|---:|---:|---:|---:|
|.5|15433/21672 (71.21%)|12.581504|22.844901|20.081955|
|1|9076/21672 (41.88%)|9.845093|21.170396|12.648923|
|3|58/21672 (.268%)|1.278271|9.933298|1.385095|
|5|0/21672|unavailable|unavailable|unavailable|

| Used block | 1s comparable | Model | Past-rate | Phase-only |
|---|---:|---:|---:|---:|
|181004|1580|9.578622|21.162457|12.297409|
|181005|1504|10.072118|20.832115|13.213759|
|181006|1525|9.636441|21.116715|12.411419|
|181007|1667|9.404715|20.989198|12.050839|
|181008|1427|10.144314|21.609672|13.714742|
|181009|1373|10.234349|21.312217|12.205369|

At1s,12373 origins disappear and223 hit the record end.1534 scored origins
have no prior slope and use the disclosed equal-model fallback. On the7542
strict past-rate-available origins, pooled model/past errors are9.639451/
23.279762; thus the descriptive difference is not manufactured by fallback.
Reported phase changes account for1924 comparable origins;8463 have new
native inventory IDs at the target. On the latter, pooled model/past errors
are9.320614/19.714607; on the613 without new IDs they are16.807934/41.132343.
These are **future-label strata only**, never model inputs. They cannot show
that births cause an observed progress difference, and do not identify
latent admission times or a batch-interference coefficient.

At3s all58 predictions back off;25 also lack prior slope. Tiny survivor
support makes the low conditional error misleading as a full-origin score.
At5s20754 origins disappear,918 hit record end, and every forecast also
lacks fit support. The previous80% availability gate fails even at1s.
**No primary improvement claim or fresh12/13 scoring is admissible.**
No hazard calibration, transfer-band repair, paired causal effect or
optimized-policy residual coverage is established by these observations.
The earlier physical-natural endpoint/SLO/whole-offered/practical-margin
proposal and original R11 preregistration are preserved, not rebound to
this easier conditional target.

Minimal usable next interface is therefore a receipt-cut reported-counter
observation response with explicit unknown work/censor/support fields,
alongside the still-unfitted evolving physical prototype. A conditional
mean table is not itself an evolving causal hazard transition. Evidence that
its factual short-step prediction differs from past-rate does **not** qualify
the prototype's synthetic composition denominator. A genuine fitted joint
kernel needs admission/composition transitions, native progress/lifecycle
observations and conditional intervention support separately.

### Controlled ignore-EOS anchor / interference pilot contract

Mayor's proposed pilot need not demand unobservable physical EOS or
nonexistent per-step kernel clocks. Minimal reported-counter interference
evidence needs source/run/domain/sequence-stamped receipts; a prospective,
publicly known ignore-EOS/maximum-output configuration for an already
accepted probe; exact native ID creation/producer lineage before its scoring
cut; native prompt/computed/output/max and running/waiting/pending/KV
observations with both sampling and receive clocks; and actual admission/
applied-ACK receipts for subsequently assigned competitors. Gateway UUID
acceptance alone still cannot join an opaque native ID. The new producer
observation required is an explicit creation/lineage binding, not a suffix,
future terminal header or source hash asserted as runtime authentication.

Randomize later competition conditional on **pre-assignment** receipt
history, keep the probe admission fixed and the future offered payload law
common/exogenous, and record actual ACK/admission delay rather than treating
a planned cap as immediate execution. Subsequent batch composition must
update existing probe/earlier-birth transitions, as in the retained fixed-CRN
synthetic witness. Sampled disappearance/reappearance, counter reset,
unknown waiting work and observer loss remain censored or unknown. This can
falsify a *reported-counter* interference model without labeling HTTP
first-residence as exclusive serial GPU service. To claim physical service
instead would require additional independently matched executed-forward/
scheduled-token evidence; the current observer does not supply it, and
GPU elapsed durations are not an absolute shared host/GPU clock.

No pilot, GPU process, SSH, new10/11/12/13 or Cal/Val/Final access was performed.
Future source/spec seals must precede fresh exposure. All source-auth,
global-complete, physical-EOS, joint-dynamics and active-MPC flags remain false.

### Reproduction and exact receipt

Use the actual parent package first on PYTHONPATH and the supplied pure-Python
HTTPX site-packages described in R10. CPython3.14 remains the available
interpreter; full FastAPI/native-ABI and unavailable supplied3.12 interpreter
qualifications are unchanged. One final analysis command omitted the
site-packages path and failed `ModuleNotFoundError: httpx`; restoring that
already-provisioned path produced the result below. No installation, shim,
dependency skip or synthetic substitute occurred.

Call `output_counter_stayer_diagnostic(fit, development)` with dictionaries
mapping the exact nine basenames to `(raw_bytes, manifest_sha256)`. Manifest
locations are under the same Mayor session `files/`:
`pr33-native-v3-first-three-complete-train-blocks-frozen` for1..3,
`pr33-native-v3-recovery-first-two-train-blocks-frozen` for4..5,
`pr33-native-v3-recovery-train-six-seven-frozen` for6..7 and
`pr33-native-v3-recovery-train-eight-nine-frozen` for8..9, each
`verified-artifact-sha256.jsonl`. Canonical returned JSON uses
`sort_keys=True,separators=(',',':'),allow_nan=False`; result SHA:
`550372c04326c72701d7882d7d81e93771b03c36e03c6949edee47f817b11e45`.

```text
88252c367d5880e3f55ae87bf40620c97579f6707e891351db580148b690500b  nv3-181004-p4096-m128-arm0.events.jsonl
0e8311b17badf30155397c353831755c0f4b7c64ea990e426521f7e510e131e2  nv3-181005-p4096-m128-arm0.events.jsonl
3917554c1f14f85bf47c679b2bac3008af11bd9666bbebb1e9a74c1eca2bc529  nv3-181006-p4096-m128-arm0.events.jsonl
71a9b6bee24f0041b8e2ab4390fde1ff9bb224233fea32ef31a985bbbc117fba  nv3-181007-p4096-m128-arm0.events.jsonl
d231cf4df390b94e6f70d9f4046bba3fcac03ee3e133d151d062c9e9aa7baf6f  nv3-181008-p4096-m128-arm0.events.jsonl
ebae00a740a86d82fea926bd2d1a746812809ceadc7866b5fb14177a48db7bb6  nv3-181009-p4096-m128-arm0.events.jsonl
7f305e54ec321cdced698064898b8e008d6f46d16e0add103c47c6302c5f75da  native_experiment_audit.py
7666c86c518a3da06545128e4cdd451c96485f64610bcf06e89a0f71ca19875a  test_native_experiment_audit.py
```

**75 scoped CPU methods passed, no skips**, including four new counter/
leakage/censor/source methods and unchanged real capture/lineage contracts.
The exact nine-artifact fit/development diagnostic was independently run
as above. Whitespace passed. This bounded follow-up changes only the three
owned files and is preserved by an ordinary local Copilot-trailer commit.

## R12 independent adversarial review and controlled-cohort receipt audit

**Disposition:** no R11 design currently identifies a qualified full-origin
causal cap-plan response or optimized-policy uncertainty. Sol's original
closed-work fit stays **zero**; the separately versioned output-stayer target
stays conditional, low-availability and without5s fit. No R11 raw outcomes were
rescored in R12. No fresh12/13, Cal/Val/Final, GPU, SSH or runtime change occurred.

### Frozen evidence and all-four review

Read the frozen R11 source/report designs under the Mayor session's
`files/pr33-native-v3-round11-frozen`. Independently checked **all12** source/
test/report files against `manifest.json`; manifest SHA:
`236435fd1d93e89dd267ad035f744d7f2824e728983363c9ef1767f1e41797a8`.
Mayor's archive digest
`dcb06813b0b9f5b771075113cc532ad77701c062cd66d92e3fc00ee189daf148`
is retained as the supplied archive receipt, not an independently rehashed
archive. Mayor's323 tests/177 subtests are likewise the supplied combined
receipt; this worker executes its own scoped tests below.

| Design | Mathematics/state and identification assessment |
|---|---|
| Opus v8 (`aa927973...12c7`) | Evolving empirical `(phase,TTFT,good)` transitions recompute a population batch key, and cap enters admission rather than a GPU-rate formula. This is a useful structural interference pathway. H/P/Q lumping, coarse output/phase bins and unused raw `computed_tokens` lose progress/unknown-work distinctions. Independent per-ID draws conditional on a shared batch are not a fitted joint scheduler-shock law. Held one-step log loss is observational prediction information, not a causal bandwidth coefficient. The frozen report's G5 negative (aware roughly7.1..7.9 vs v7 roughly4.1..4.4; bands roughly.51..54 for nominal.8) remains a negative, not rescued by beating blind. |
| Astra (`a64b58d9...c564`) | Event-split fluid conserves work-equivalent resource and holds original charge until explicit release. Cap-only-through-admission is coherent, but a constant aggregate capacity with equal sharing is a structural assumption: decode-only fit, zero prefill support and disastrous transfer against last-rate do not identify mixed-batch allocation. Its separate residual-ridge stayer predictor is explicitly a different observational target:1s availability13.06%, one3s row, no5s rows. Current prefixes cannot initialize latent EOS/work, unknown-owner work, KV evolution or a full-G joint law. |
| Gemini corrected (`ade3dfce...90ca`) | Corrected exact-ID endpoint matching, censored disappearance, continuous progress and honest frozen-state naming are meaningful repairs. However OLS `dt/advance` on *positive-advance surviving* rows fits conditional inverse rate, not mean service or randomized bandwidth. The negative decode gamma, surrogate KV during rollout, unknown-KV zero fallback, horizon-frozen composition, and work-completion-to-active-cost removal do not identify a physical/lifecycle kernel. A latent common-law output draw is an assumption, not observed physical EOS. The mock controlled cohort uses4 arbitrary-cost anchors/2048-token bursts and invented **mock** NativeIDs; it is not the specified9-anchor real pilot. Its disclosed−58 is CPU plant arithmetic only. |
| Sol frozen (`7f305e54...75da`) | Closed-population transition has a falsifiable shared-composition denominator, immutable charges and explicit unknown-work refusal, but **no fitted rates**. V2 mean tables predict reported output conditional on continuous observed staying; fit support7627/4440/17/0 across.5/1/3/5s and1s development availability41.88% cannot become a lifecycle or full-origin service law. Binned population and progress can carry factual information without identifying intervention effects. Source hashes do not identify independent samples, true ingress closure or uncertainty under optimized plans. |

In particular, Opus `_native` (112..142) and Astra `_counter_records`
(2364..2457) use a regex-extracted UUID component to form Gateway joins.
A syntactically exact regex and matching payload do not independently prove
engine creation lineage. Their corresponding cost/missing-owner covariates
remain subject to that producer contract. This is distinct from a purely
opaque-NativeID aggregate counter target. No R12 receipt audit adopts those
joins, and no per-GatewayUUID/native identity claim is made.

#### Executable Opus within-step stock counterexample

The test runs the **unchanged SHA-pinned** `r11_simulate` (3084..3137), with
fixed uniforms, sourced costs and9 initial D1 anchors. An identical empirical
grid record makes every original anchor GONE at.5s; a common burst arrives
at.4s. Frozen step-start stock rejects it under16.

Two physical event chronologies have the same grid endpoint record: release
all anchors at.01s, or at.49s. The former admits that burst; the latter rejects
it. The executable witness returns coarse rejection1 versus feasible
early/late outcomes0/1. Thus release ordering **can** explain extra rejections,
but the grid records alone do not establish that it caused the observed
negative. Moving every release to the early endpoint would be an unjustified
optimistic repair. Need a joint within-step release/admission ordering law,
fit to source-stamped release brackets/events and offered send times, with
uncertain ordering retained; new source/spec seal before testing. This is
not a hardware intervention, a release-endpoint retune or new development score.

#### Executable Gemini coefficient/selection counterexamples

The tests execute the exact pinned `compute_service_rates` and
`fit_batch_aware_hazard_model_on_train13` function bodies, not a substitute
GPU model. With reported fitted gamma_d=−.011, more decode actors at fixed
prefill/KV **increase** the predicted per-ID rate. That sign is not itself
physically impossible: real batching can improve efficiency. It contradicts
an automatic reading as causally identified decode bandwidth contention.
The denominator floor.1 also does not create support or uncertainty.

A two-type selection witness makes every type slow under competition
(100→50 and10→5), yet the observed survivor mean increases10→27.5 because
the fast actor completed before the low-load observation. Conditioning on
survival/positive advance/phase can reverse an association even with uniformly
negative individual effects. OLS's inverse-rate target adds another boundary:
the reciprocal of mean token-time is not mean token rate. Repeated NativeID
observations are not121079 independent interventions.

The exact fitter on an existing directory with **no** matching episode JSON
returns the stored constants while reporting121079 decode samples/30 fitted
episodes. A precomputed artifact can be useful, but that branch needs an
explicit precomputed/no-current-fit receipt and byte-bound fit provenance,
not a fresh-fit implication. Function-body extraction uses a simple output
record container and postponed annotations; it is not full-module/native-ABI
qualification. No Train/fresh outcomes are read by this witness.

### Aggregate controlled-cohort provenance: sufficient condition, absent producer

**Yes, the proposed provenance can suffice for the aggregate reported-counter
estimand without a per-UUID bijection**, provided it is genuinely verified:
an executed initial drain; closed **all native ingress**, including any direct
engine path; exactly9 anchor admissions and no other creations; all9 observed
NativeIDs decode-ready with the equal known payload; and that exact opaque
NativeID set frozen **before** allocation. The permutation of nine identical
anchors is irrelevant to the original-cohort mean. This does not identify
which NativeID belongs to a particular Gateway UUID.

Today's snapshots, source hashes and caller assertions do not prove that
premise. Empty Gateway/running/waiting/pendingBatchQueue is a necessary check,
not proof that asynchronous outstanding work is drained. Native `complete`
is not global ingress completeness, and maximum output256 does not prove
the backend actually received `ignore_eos=True`. Current sources provide no
qualified producer for the controlled-cohort contract.

Minimal new producer evidence is a source/run/clock/sequence-stamped cohort
creation-and-idle/closure contract: an executed drain/fence epoch covering
all Native ingress and active asynchronous lifecycle; the complete admitted/
created cohort journal or a native creation **cohort tag** binding exactly
those9 raw IDs; and prospective accepted/forwarded ignore-EOS/public-payload
configuration. It need not expose prompt text, physical EOS, GPU-exclusive
time, per-kernel clocks or a Gateway UUID suffix. If ingress cannot be fenced,
explicit native creation cohort membership plus recorded foreign work is
required, and the experiment is no longer the claimed no-foreign closed cohort.
Hashes bind artifacts but do not authenticate execution of this producer.

### New strict, source-bound receipt/statistics interface

`controlled_cohort_spec()` seals
`native-v3-controlled-cohort-sol-r12-v1` before any fresh exposure.
`audit_controlled_cohort(raw_bytes, raw_sha256)` verifies the exact raw bytes,
spec hash and current pinned actual **CostSpec, Gateway, NativeState and runtime
source bytes**, plus the explicitly frozen R8 capture source reference.
CostSpec configuration must match the Gateway
snapshot identity cost fingerprint. It computes, rather than uses permit
constants:

```text
actual estimator: max(minimum, intercept + input_per_token*p + output_per_token*m)
one p128/max256 anchor: 1.6893573248
nine original anchors:  15.2042159232
one p4096/max128 burst:  4.0304346624
anchors plus one burst: 19.2346505856 > 16
anchors plus four:      31.3259545728 <= 32
```

Those numbers are the derived current-source arithmetic, **not unconditional
runtime charges or a permit**. Different sourced coefficients are accepted
only if they preserve the specified admission separation; actual admission/
snapshot/release charges must match their immutable originals. No control
change recosts or re-admits a known accepted actor. Explicit cap-driven
eviction is invalid. Missing releases or snapshot/journal races remain
refusals, not inferred zero work.

Prospective public registrations have their **own new closed schema**
`native-v3-controlled-public-payload-v1`: class, prompt estimate, requested
maximum, ignore-EOS declaration and publication before attempt/assignment;
no prompt text/secrets. They are not silently added to old R9 metadata.
Thirteen registrations are planned rows, not thirteen actual sends.
Numbered Gateway journals retain actual attempts, admissions, rejected/
failed/timeout/cancelled/unsent fates and explicit whole-cost release.
Publication/observer receive clocks, journal/run/domain, unique physical
UUIDs and NativeID/run identities are checked. Missing fates stay explicit.
These prospective journal schemas still require actual collector integration;
the interface **never manufactures them from final rows**.

All12 pairs and both assigned arm slots are mandatory, with unique pair/
sampling/episode/request/native identities. Duplicate labels do not prove
independence; a missing slot is invalid, not a reduced denominator. A failed
gate/command/run stays in its assigned slot with wide counter bounds.
Gate and cohort seal must precede assignment strictly; equal-time ordering
without an explicit source sequence cannot certify pre-assignment identity.
No matching future header or surviving subset can repair that gate.

The actual command retains planned/send/apply/ACK clocks, expected CAS
version, operation ID, run/domain/identity,100ms `not_after` and the pending
fence. An apply after TTL is invalid; a later-delivered ACK for an apply
before TTL is allowed and its delay disclosed. Failed/missing ACK keeps the
assignment and pending uncertainty. Admission uses actually applied budget,
not the planned label; no success-only comparison. Actual burst attempts
are compared to the same four p4096/max128 scheduled offsets +.1s; actual
schedule lag is recorded rather than retiming the primary window.

#### Preregistered estimand, censoring and inference boundary

Primary: **mean over the9 original anchors of reported OUTPUT increment**
between the pre-assignment and assignment+1s reporter cuts; contrast32−16,
then equal weights across **12 independent randomized-order episode pairs**.
Initial32, later16/32 and common exogenous four-burst tape are fixed.
Sample/receive times and endpoint age are returned; this is not exactly1s of
GPU execution. Other R11 horizons and all SLO/output semantics are unchanged.
No full Goodput, natural EOS or physical-service endpoint is introduced.

Proposed meaningful slowdown margin:5 reported tokens per original anchor
over the1s window, with at most5% censored anchor/assigned-arm endpoints.
Native age<=.1s, successive receipt gap<=.2s are fixed proposal gates, not
changes to729. They may legitimately cause refusal.

Every original ID contributes a bound. Disappearance/reappearance, missing
or wrong-source frames, stale endpoint, changed metadata or counter reset
cannot become a zero or a forced256 completion. Trusted observed increments
provide lower bounds where possible; remaining source-qualified maximum
headroom gives upper bounds, conditional on the counter contract. Resets/
changed metadata widen the lower bound to zero; an output over256 violates
the proposed bounded-counter model outright. An unprepared assigned arm is
[0,256] per anchor. Pair intervals are `[L32-U16,U32-L16]`; average **all**
pair intervals. No endpoint/ACK-success-only selection is allowed.

The audit returns a deliberately conservative conditional independent-pair
Hoeffding mean interval, using pair range[-256,256], and an exact two-sided
sign-flip calculation only when every assigned pair is point-observed.
Neither is called authenticated causal inference: independent sampling,
randomized order, no carryover and producer completeness must be qualified
separately. Censoring disables the exact point test. There is one prespecified
primary contrast, no cell/horizon/margin search or multiple-policy guarantee.
Twelve pairs are a bounded identification pilot, **not a power guarantee**:
the distribution-free interval can remain extremely wide. A numeric
`margin_and_censor_met` is not significance or an acceptance permit; a
practical-confidence claim additionally needs a qualified upper confidence
bound below−5. All inference/source-auth/global-complete/cohort/physical-EOS/
native-clock/active-MPC flags remain false in this version.

### Executed counterexamples and exact R12 receipt

**R12 hardware/raw controlled receipts: NONE.** The executable input is labeled
`cpu_fixture`, collector source SHA is explicitly `None`, and no actual Native
ID, configuration-forward receipt, independent RNG receipt or physical EOS is
fabricated. Fixture NativeIDs are opaque CPU mock values captured from the
mock gate. The producer interface is a proposal, not an already-qualified hook.

The CPU accounting fixture produces−10 reported tokens/anchor across12 pairs.
That is test data, just as Gemini's−58 is test data. Replacing one assigned
high-budget arm with a failed/no-attempt run preserves all12 units, widens
the mean to **[-12.5,+8.833333]**, and yields censor fraction4.1667%, no point
permutation test and no numeric margin acceptance. Thus a missing arm can
reverse the full-origin contrast despite a small censor fraction and an
apparently strong complete-case result. Late/missing ACKs, reordered opaque
cohort lists, future terminal “stop/256” rows, transient disappear/reappear,
reset, gaps, wrong domains, recosting and duplicated pair identities have
focused executable checks.

Canonical JSON for raw/spec/result receipts:
`json.dumps(...,sort_keys=True,separators=(',',':'),allow_nan=False).encode()`.
The raw fixture is reproducible from
`ControlledCohortTests().receipt()`; pass its bytes/hash to the actual audit.
It has **no randomized-execution provenance** (fixture order is alternating).
The conditional point sign-flip arithmetic.00048828125 therefore is not a
hardware p-value. Its conditional conservative mean interval
[-210.729671,+190.729671] also prevents a practical-confidence claim.

```text
6ec73a11ec6ad0ce11ca3ed1dd60190da77a8c3f0ce2676f1657a01ccc97f990  controlled_cohort_spec canonical JSON
96b721cf3bd455a8ea3e302a01129753c2e6875311fae8ccca614e13a18ae7de  CPU fixture raw receipt JSON
283b3cf8272c065c065ddf3820682c2e424af4c44173cd7d44c6d75043b7749a  CPU audit returned JSON
d282b2f85830f6cd0fa9be224051047bf7b6fd5adfe48607aa54b7d3f0a5df00  native_experiment_audit.py
137e6e7c08bbbd66adc8e11c3ba66f088580ba971ce559b82aab27258f9aedfc  test_native_experiment_audit.py
```

During final validation the parent capture worktree changed to SHA
`f961e75ba54b63f478e5d970c0c4c5aeaed5f2cb5ebb35ba9c450454810de958`.
The existing R8 source seal **correctly refused** it; that failed validation
is retained, not called a passing live-source gate. No pin was relaxed.
The original local Git object `734d459:mpc_lab/http_capture.py` still hashes
exactly to `a8bbafd6...3fb6c`. `_capture_reference_source` verifies those bytes,
and the R8 regression harness executes that **full unchanged historical
module** in memory with its package context, not edited statements or a fake
filesystem `__file__`. The initial in-memory attempt omitted the package
context and raised ImportError; assigning the genuine `mpc_lab` package
context resolved relative imports. No file was copied or modified outside
the three owned paths, and no source/authentication check was bypassed.
R12 explicitly returns
`capture_source_reference=parent-git:734d459:mpc_lab/http_capture.py` and
`live_capture_matches_reference=false`; the changed live source has **no
qualification** here. Other current parent source hashes remained unchanged.

**81 scoped CPU tests passed, zero skips**, including6 new R12 methods and
all prior real capture/lineage/counter regressions. `git diff --check` passes.
The actual parent NativeState/CostSpec implementations are executed in the
receipt checks; the exact Opus source and scoped Gemini function bodies are
executed for the witnesses. No full native/FastAPI/ABI or live collector
qualification is claimed. The existing CPython3.14/provisioned pure-Python
HTTPX environment is unchanged. Only the three owned files are changed;
the final ordinary local commit and committed hashes are the source seal.

## R13: actual tag producers, prospective inputs, and Gateway ledger boundaries

**Implemented a separately versioned conditional lineage adapter and an offline
actual-ledger prefix audit. Neither qualifies trusted ingress, complete cohort
execution, physical EOS, GPU service, a fitted model, or active MPC.** Work is for
`pr-native-v3.4`; only the three Sol files change. No fresh Native outcomes,
12/13 raw outcomes, Calibration/Validation/Final, GPU, SSH or runtime changes were
used. Mayor's statement that 12/13 summaries have been exposed is not fresh
held-out evidence. Supplied facts (1259 offered with one unknown preheader row,
15960 valid seconds, owned compute stopped, billing unverified) are **not
independently verified measurements in this artifact**.

### Source boundary and sealed R12 review

All twelve R12 files were checked against the frozen manifest, SHA256
`da0464904d863e29a324484be3e58d3400af705813884b2d5a94666640599308`.
The changed Parent tree is read-only interface context:

| Producer | Exact SHA256 |
|---|---|
| Gateway | `a4a8229b0f636b64c945881d062c3ee925ef5fccc5ba2e6fc7629657d3575ea7` |
| Capture | `0648738704771f80470849b0c0beb671d0f17c9dbc75e4095cff155b20d04be7` |
| Native observer | `77633dc7652066e45b7680d297d3e36ddb97a3e12222de9f526a76b9a01d66b4` |
| Telemetry | `46d6fb923e558f6435d269dd6fa5cfd5b0d71eb1fd91cbb3aaca8a82385e6370` |
| NativeState | `835df8ebaa58c773074e65cedba4627b468d14b560233a7655bf9cd2240b83d6` |
| Contracts/CostSpec | `f39f6b73b41b1433a220f182679852df5c4332d9022ce903dba9863375236e23` |
| Runtime | `f04c58eb9b5a81e7e1c7a22aaea1cd6b59de88c568ec77d51f1487af4c85b727` |

| R12 proposal | Actionable independent assessment |
|---|---|
| Opus | Release-endpoint sweeps correctly expose stock/within-step ordering sensitivity. Their factual offered tape is an offline disturbance label, not deployable arrivals. Actual complete ledger transitions can replace cost-release intervals; neither release time nor charged stock is GPU work or an identified interference kernel. |
| Astra | Keep prospective cohort seals, original held charges, all-assigned intervals and the explicit failed complete-progress transfer. Endpoint order, async work, source publication and observer receipt remain distinct. A collector/fixture schema and conditional stayer improvement do not qualify physical closure or causal bandwidth. |
| Gemini | The runner executes HTTPX mock transport with supplied cohort/provenance, not a native GPU intervention. Failure paths must retain assigned slots instead of raising away failed arms. Fixed marks lacking interference are a counterexample to that kernel, not a theorem that all fixed-mark factual approximations are invalid. Negative observational gamma_d and survivor associations remain unidentified. Its arithmetic does not guarantee four low-budget rejections: two original anchors can release before a burst, making seven-anchor stock plus one burst fit under16. Actual charge/stock at each attempt and actual ACK timing are required. |
| Sol | R12 was a CPU structural proposal with false producer/causal qualifications. The new tag source changes what is potentially observable, not what old receipts contained. Preserve the closed-work zero fit, conditional 1s output availability9076/21672, and zero5s fit/labels. No old source seal, empty mask or inferential refusal is relaxed to obtain success. |

The original Gateway/capture SHA constants remain unchanged. The original
`OnlineModelInputAdapter` **rejects the changed Gateway** in an executed test.
Old R8 callback regressions still execute the byte-verified unchanged historical
capture. Changed-Gateway registry regressions explicitly use the R13 subclass
with that historical capture version; they do not qualify a new live capture.
The frozen R12 audit may reference byte-verified `734d459:gateway.py` **only for
CPU fixtures**, reporting `live_gateway_matches_reference=false`. Prospective
Native R12 receipts still refuse the changed Gateway. The R13 actual-tag path
requires both new capture and observer pins.

### Runnable prospective adapter and remaining producer contract

`TaggedNativeInputAdapter.register_controlled()` registers a unique planned
request/cohort and typed maximum/ignore-EOS metadata **before task creation**.
Its new closed registration schema records publisher/observer runs, source,
domain, sequence, publication NOW and independent observer receive. Returned
copies cannot modify the registration. Public prompt estimates use the existing
closed schema; no text/secrets, charge invention or retrospective final rows.
Pass **`adapter.observe`** to actual `capture_chat`, then feed contemporaneous
parent frames to **`receive_tagged_native`** and obtain monotone sealed `cut`s.
Callback failure receipts have their own receive clock: live error latches are
not retroactively exposed at older cuts.

The actual Gateway receives a validated benchmark UUID, creates its accepted
mark, and overwrites caller `pr33_gateway_request_id` in **lab chat dict xargs**
before sending upstream. Cohort tag remains caller data. The observer reads
exact opaque NativeIDs, valid32hex tags and actual bool/unknown ignore-EOS from
SamplingParams. No suffix matching or future terminal header is used.
Wrong source/domain, duplicate Gateway tags, changed original metadata and a
second native actor claiming a previously observed Gateway UUID refuse.
Missing tags, absent pre-cut registration/binding/charge and parameter mismatch
remain unjoined. Accepted work stays known accepted and cannot be re-admitted;
waiting work, native-invisible accepted work and async work remain unknown.

A match requires actual pre-cut attempt fields, pre-outcome local registry
binding, original Gateway owner charge and contemporaneous SamplingParams tags.
It is a **conditional producer-lineage match**, not trusted end-to-end identity.
Actual Gateway prompt estimates need not equal native prompt counters. The CPU
example retains native128 versus the different Gateway estimate and its actual
charge rather than recosting the Native row. Offered estimate remains `None`.

The CPU tests execute actual new capture, actual Gateway handler bodies through
Starlette/HTTPX ASGI mock transport, and exact observer function bodies on mocked
SamplingParams. They do **not** execute the native vLLM OpenAI parser/engine.
Operational qualification must establish the real JSON xargs-to-SamplingParams
path, source/run/domain continuity and trusted ingress (including direct-engine
and other-Gateway exclusion). Valid tags and source hashes alone cannot prove
those facts; no cryptographic tag guarantee is claimed.

### Actual ledger and flush falsification

`audit_gateway_ledger_prefix()` consumes byte-bound **actual Telemetry JSONL and
status shapes**, with separately supplied expected run/domain/Identity and
actual CostSpec. It does not add missing source, client schedule, observer receive
or final-watermark fields to producer rows. It validates source files, finite
chronology, complete owner/count/cost stocks, contiguous ledger sequence,
original accepted charge arithmetic, zero-stock boundaries and clean status.
Malformed charges/domain refuse; gaps, incomplete stocks, dropped records and
failed status withhold prefix conditions. Anonymous +1/-1 count with corresponding
whole-cost delta distinguishes admission/release from zero-stock-change
first-content/budget events. Budget changes do not evict held charges.

`mpc_changed` increments for more than admission/release. Ledger increases precede
accepted telemetry; cleanup closes upstream before releasing, then emits terminal
telemetry. Ledger rows have no UUID owner field. No generic adjacency/FIFO rule
is promoted to exact per-UUID release, and no release is physical GPU completion.
Existing source-bound RequestMarks provide original ownership; otherwise keep
identity/timing ambiguous. Native collector events do not automatically contain
the separate Gateway telemetry log.

The executed actual lifespan/CAS/flush test writes two complete CPU requests
with guarded100ms commands, then reads the **actual status sidecar**. It returns
two admissions and two whole-charge releases, plus four zero-stock changes.
Truncating the same actual JSONL after the **first** drained cycle retains a
contiguous empty-to-empty prefix and the original clean closed status. Both
satisfy prefix conditions, but neither proves full-run completeness. Status
contains no final ledger sequence, row count or JSONL digest binding that
detects this suffix loss.

The actual flush test writes one line then raises OSError on the next: the
entire two-record batch is counted dropped, buffer remains empty, and a second
flush cannot recover it. The producer swaps the buffer before append; no fsync
or persisted per-record ACK is provided. Atomic status rename is not a JSONL
tail/byte or power-failure durability certificate. Minimal improvement is a
source-bound final producer watermark/record count and binding to the retained
log, with clean flush/drop accounting and a defined durability scope. A genuine
online ledger observer additionally needs prospective publication/receive
receipts; final-file monotonic timestamps cannot backfill them.

### Controlled-cohort acceptance criteria, unchanged statistical proposal

For the aggregate original-cohort reporter-counter estimand, no independent EOS
receipt or exclusive GPU clock is necessary. Required provenance is a verified
initial scheduler/Gateway drain, trusted no-foreign-ingress interval, exactly9
original accepted anchors and their **exact observed NativeIDs sealed before
assignment**, waiting0/all9 decode, actual ignore-EOS/max/prompt metadata,
complete source/run/domain inventory and original charges. Tags can support
conditional membership; without operational ingress/parser qualification they
do not certify it. Queue length is not all active async work. Unknown residual
work prevents an isolated-mechanism/physical-idle claim; hidden pre-treatment
work may be balanced by genuine post-preparation randomization for an ITT
reporter contrast, but cannot be declared zero.

Keep9 p128/max256 anchors, initial32, later16/32, four common p4096/max128 bursts,
the actual source-derived charge inequalities,1s original-cohort mean OUTPUT
contrast32-minus16, margin5 tokens/anchor, maximum5% censoring and12 independent
randomized-order pairs. Registration is not budget assignment; qualify
assignment/publication/apply/ACK exposure and retain schedule lag,100ms TTL/CAS
and unknown pending operations. Every assigned preparation/command/HTTP failure
stays in the denominator. Missing/reset/disappeared original counters stay
intervals, not256, zero, final-survivor averages or forced Good. Independent
pairs are the statistical unit; source hashes and request count do not create
independent replications. One primary contrast, no horizon/margin/multiplicity
search. Existing conditional statistics remain conditional, not a power,
equivalence or causal/control permit.

### Exact R13 CPU receipt

**86 tests /124 subtests passed, zero skips; `git diff --check` passed.** This
adds5 focused actual-producer methods. The supplied py312 interpreter's missing
base remains a real environment limitation, not a skipped test; CPython3.14 with
the already-provisioned pure-Python HTTPX packages was used, without installs.
No ABI/native/GPU qualification is implied.

```text
50bbb2dbe7862dc805cb116ec6af7fa3a6b675a856065e17bb972bd08702b55d  native_experiment_audit.py
bab70fd84c1b2c79db1c6f804a5b3c72b7e736ecc0efa983d2f1fbba32a0aef9  test_native_experiment_audit.py
54daddf2b2ea8651f8f7a85cb8f94a922f30dfcda2f4b997b38d5758c7c1baa0  execution-specific CPU actual JSONL
90d81d38527878603697e7a80798cb301063ce9768fdc5e12e749e019ade8134  execution-specific CPU actual status
3ba2535f989f3f309416806d89cdbbfe24cea4162cf716baad30f992db64df73  execution-specific truncated CPU JSONL
29c8c7aba2b84a5a5b21be634a69b1aa5fbea6851b22325afddc2d49b55690d9  canonical time-free CPU projection
```

Execution-specific temporary files are cleaned by the tests; their timestamps
and run UUIDs are not reproducible constants or retained Native raw receipts.
The reproducible **offline derived projection** below excludes times/UUIDs, is
not an online packet replay, and hashes with sorted compact JSON:

```json
{"accepted_original_charges":[0.27775466660000003,0.27775466660000003],"evidence":"CPU actual Gateway/Telemetry handlers; time-free offline witness, not GPU data","exact_per_UUID_release":false,"full_prefix":true,"full_run_complete":false,"transitions":[{"cost_delta":0.27775466660000003,"kind":"one_admission_whole_charge","owner_delta":1,"request_id":null},{"cost_delta":0.0,"kind":"no_stock_change_first_content_budget_or_other","owner_delta":0,"request_id":null},{"cost_delta":0.0,"kind":"no_stock_change_first_content_budget_or_other","owner_delta":0,"request_id":null},{"cost_delta":-0.27775466660000003,"kind":"one_release_whole_charge_not_GPU_completion","owner_delta":-1,"request_id":null},{"cost_delta":0.27775466660000003,"kind":"one_admission_whole_charge","owner_delta":1,"request_id":null},{"cost_delta":0.0,"kind":"no_stock_change_first_content_budget_or_other","owner_delta":0,"request_id":null},{"cost_delta":0.0,"kind":"no_stock_change_first_content_budget_or_other","owner_delta":0,"request_id":null},{"cost_delta":-0.27775466660000003,"kind":"one_release_whole_charge_not_GPU_completion","owner_delta":-1,"request_id":null}],"truncated_prefix":true}
```

No new fitted model, native result, physical EOS, active MPC or statistical
authority is promoted. Final ordinary local commit and report SHA are printed
as the local receipt; Mayor retains experiment/runtime/Beads authority.

## R14: independent boundaries, R13 critique, and geometry adjudication

**A genuine final raw Gateway snapshot can witness aggregate ledger coverage
through its sequence; a closed status or log-derived final cannot. Neither
9x256 nor5x512 proves physical survival.** This bounded artifact adds
`audit_gateway_ledger_boundaries` and `controlled_geometry_proposals`, retains
the R13 prefix API unchanged, and executes frozen-peer counterexamples.
Bead: `pr-native-v3.8`. Only the three owned files change; no live Source144
hotpatch, native/GPU/Pod/SSH calls, fresh15/16 or Cal/Val/Final reads.

### Evidence update, not a native control result

Mayor supplied actual Source144 smoke evidence:922 offered,649 complete,
273 rejected,0 other over48s;3346 native sampling rows matched Gateway's
validated client UUID, with actual ignore_eos=false. The supplied aggregate
ledger has1963 rows, numerically `3*649+16` applied ACKs, and two closed
status epochs with zero drops/errors. These facts materially advance the
end-to-end tag evidence beyond my R13 CPU-only execution. They are **Mayor's
actual receipt, not a worker reproduction or freshly opened outcome archive**.
Repeated sampling rows and requests are not independent experimental pairs.
This smoke does not test actual ignore_eos=true, controlled-cohort survival,
physical EOS, causal interference, or MPC performance. Native03 and fresh15/16
remain outside this worker's reads and authority.

### All-four frozen R13 review

All twelve files were byte-verified against R13 manifest SHA256
`2bb51485f6fc6401716c9c2eb86e1b759cd43a9be8844d9e9f775e7c5795df99`.
Source pins: Opus `3ec5b68364a1e7eb17e38ea47a81c5fd0490365bde1b1045e383ff9b09067bd9`;
Astra `0f91fdff72c962709f465a93291a6923f2a2d1217890bd164d048428eadc2325`;
Gemini `21103b14840397bc37de82d00274a61463d53f2d681b5de57ba5fe169bd4aecb`;
Sol `50bbb2dbe7862dc805cb116ec6af7fa3a6b675a856065e17bb972bd08702b55d`.

| R13 design | Independent decision and live-interface consequence |
|---|---|
| Opus stable per-identity CRN | Correctly repairs plan-dependent birth/member stream offsets while retaining the frozen kernel, common exogenous offers and release endpoints. Correct pairing is not causal identification, physical marginal unbiasedness or calibrated optimized-plan coverage. Its iid statement is about Monte Carlo draws relative to the simulator. Preserve the negative/undercoverage facts and separate gates. New source tags cannot retrofit old regex joins; known accepted native-invisible work must never be re-offered under a new cap. Unknown client attempts may require admission scenarios, not invented accepted state. Exact aggregate ledger times do not automatically resolve repeated-cost per-owner release. |
| Astra exact prefix enumeration | Exact32-plan computation and the same scored four Strong-OneMove plans are a sound computational comparison for the frozen surrogate. Byte/arithmetic equality is not native forecast/control validity. Uncertainty, phase/async missingness, live source binding, ACK/pending handling and cooperative-deadline/fallback qualification remain prerequisites. Preserve original stock, both release endpoints and full-origin/coverage refusals; do not select favorable conditional stayer errors or endpoints. |
| Gemini transport/runner | Still virtual `advance_clock`, mock `/native/state`, sequential POSTs and fake `prompt_tokens` with content `"prompt"`; no real guarded actuator/capture/native runtime integration is established. The actual Gateway rejects its command shape with422: schema/identity are absent. Source execution shows ignore_eos=true requests remain decode **past their finite maximum**, so mock survival claims are invalid. Its `gateway_request_id not in client_ids` assertion is false on actual validated benchmark UUIDs: the correct tag equals the validated client UUID, while NativeID remains a separate opaque identifier. Exact pair-wrapper execution loses the failed second arm via exception rather than returning all-assigned bounds. Hardcoded ITT/provenance/censor flags do not repair that. |
| Sol prefix/conditional tag adapter | Retain the honest R13 source/version boundaries, conditional pre-cut matching, original charge/unknown pending state and zero5s fit. Revise only the suffix conclusion: independent raw snapshot boundaries can provide **conditional sequence-interval coverage**, even though current status lacks a final digest/sequence. My old prefix-only return remains unchanged. Operational snapshot provenance, post-final tail, client publication completeness and physical release remain separate; no per-UUID or native permit is promoted. |

### Source-bound boundary witness: useful closure, precise limits

`audit_gateway_ledger_boundaries` accepts the actual byte-bound JSONL/status
plus **separately acquired raw initial/final `/admin/mpc/state` replies** and
their byte hashes. It parses the unmodified parent Snapshot schema and uses
the existing source-pinned parent `identification.reserved_cost_at`, SHA256
`bae3888768be5508f6a5d57a48eddd80abe9e0942f95e7f57bab824707f560f8`.
Current Gateway/capture/Telemetry/NativeState/runtime pins are unchanged from
R13; no Source144 field or clock is invented.

The source helper requires same run/domain/Identity, complete snapshots,
zero trace loss, contiguous sequences from initial+1, chronological effective
times within the boundary window and final sequence/reserved-stock agreement.
The new wrapper additionally retains prefix validation, verifies first-step
count/cost coupling against the independently observed initial stock and final
count/budget/version agreement, and checks final sampling before status closure.
An initial stock may be active; it is not replaced by a fabricated empty ledger
row. The result is explicitly **aggregate coverage of the sequence interval**,
not full-run/all-offered/native or authenticated per-owner closure.

The actual CPU Gateway/lifespan/flush test now obtains initial and final raw
replies by independent ASGI GETs. Its full log passes the interval witness.
The same clean suffix-truncated log that passes R13 prefix checks **fails**
against the genuine final reply with `final_watermark_mismatch`. A missing
boundary withholds coverage. Wrong run/domain/sequence/budget and impossible
first count/cost jumps refuse. Thus an independent query supplies information
that status=closed/drop0 alone lacks.

The adversarial test then rewrites the final reply's sequence/budget/version
from the cropped log: it becomes structurally consistent again. This is **not
independent execution evidence**; authentication/full-run flags remain false.
A query-derived watermark must be retained by a distinct prospective observer
with source/run/domain and acquisition receipts, not reconstructed after outcomes
from the same file. Source hashes authenticate neither acquisition nor execution.
An earlier genuine final query also cannot rule out later events before shutdown.

Optional expected-update counts are supplied separately and checked only for
arithmetic consistency. For the supplied complete smoke,649 admissions +
649 first-content updates +649 releases +16 applied budget updates gives1963.
It is not a universal `3*complete` rule: absent content, accepted failures,
other changes and missing/delayed ACKs require their actual event classes, not
zeros or ACK-success-only selection. Counts copied from the tested file are not
independent witnesses. Combining two run epochs into one sequence or one status
is invalid; audit each epoch and retain all expected epoch/assignment slots.
An equal total can hide compensating loss/duplication; continuity/boundaries
remain necessary. Per-UUID release still needs original ownership and adequate
producer lineage, not FIFO/single-cost guessing. No GPU clock/EOS is demanded
for aggregate lease-stock truth, or inferred from it.

### 9x256 versus5x512: feasibility is not survival

The actual parent CostSpec defaults, fingerprint
`4228f9b98664f8c91b3fe27e7499a0f16dc9ceed48545d3726251bd5951a8aa7`,
give the following **nominal**, not actual admitted, geometry:

| Geometry | Charge/anchor | Stock | Margin for low16 rejection after one anchor releases |
|---|---:|---:|---:|
| 9 p128/max256 |1.6893573248 |15.2042159232 |1.5452932608 |
| 5 p128/max512 |3.0226906496 |15.1134532480 |0.1211972608 |

Burst p4096/max128 charge is4.0304346624. Both stocks fit initial32,
both reject the first low16 burst **while all original leases stay held**,
and both fit four high32 bursts with no foreign stock. Either geometry can
permit a low-budget admission after two original releases;5x512 has a much
smaller margin after one release. The source uses rounded output coefficient
0.0052083333, not a silently substituted exact1/192. Actual Gateway prompt
estimates/charges may differ from native p128 and must replace these nominal
costs before an experimental admission claim.

There is no source-qualified upper decode rate or lower residual lifetime.
Finite remaining tokens and actual ignore_eos=true do not guarantee1s survival:
the maximum, failure, cancellation or missingness can still end observation.
The runnable mathematical witness chooses a **hypothetical**, not fitted/native,
rate `2*maximum`; both maxima can expire within1s from output1. The exact frozen
Gemini mock instead continues beyond max2 with ignore_eos=true, confirming that
its positive survival result is a transport bug, not a hardware certificate.
Neither the90 tok/s constant nor observed short-response distributions prove
a hard maximum rate. ACK receive delay is not application delay: valid apply
must precede100ms not_after, even if its ACK arrives3.5s later.

**Decision: no geometry selected from outcomes.** Keep9x256 as the frozen default
proposal, explicitly without a survival guarantee.5x512 is a separately
versioned exploratory alternative, not a retroactive successful replacement.
It changes batch width/prompt work/termination headroom despite similar cost,
and changes the pair endpoint range from[-256,256] to[-512,512]. With the same
12 independent pairs the conservative bounded-range interval doubles in width;
more max tokens do not automatically improve statistical power. Preserve1s
original-cohort mean reported-output contrast32-minus16, margin5 tokens/anchor,
maximum5% censoring and12 independently randomized-order pairs. A5-anchor
version must explicitly seal the denominator/max/bounds before fresh exposure,
not reinterpret R12's9/max256 receipts. No full Good, physical EOS, statistical
guarantee or equivalence claim.

### Minimal usable live stages, without changing the running experiment

Use the actual capture callback with prospective source/versioned public
metadata registration, independently stamped publication/receive and concurrent
request tasks; awaiting a full sequential POST is not concurrent offered traffic.
Only actual attempt callbacks count as offers; unsent cancellations and missing
publications remain separately accounted. Bind Gateway tags to validated client
UUIDs and exact opaque NativeIDs with epoch/domain/source fencing, no suffix or
future header backfill. Native-visible tags do not cover waiting/transient
births or prove ingress closure. Retain immutable actual Gateway charges,
accepted-but-native-invisible ownership and unknown work; never re-admit
known accepted requests after a cap decrease.

Use the real GuardedActuator schema/identity/CAS/not_after/pending fence, journal
assignment/dispatch/actual apply/ACK receive and all failed/unknown slots. Common
burst schedules and the assignment+1s reporter window must run independently of
waiting for a successful ACK; a late ACK cannot retime offers or the endpoint
after outcomes. Qualify actual SamplingParams ignore_eos=true before calling
anchors forced; smoke false is not that qualification. Seal the exact original
NativeID set/metadata before assignment, observe all original counters with
bounded censor intervals, and retain preparation failures in all-assigned pairs.
No final-survivor or ACK-success-only denominator. Qualify initial scheduler/
Gateway drain and trusted ingress operationally; physical idle/service is a
different claim. All x,u,w inputs require pre-cut receipts; final raw rows and
boundary files are offline truth, not online observation backfill.

### Exact R14 receipt and validation limitation

**90 tests /128 subtests passed, zero skips.** Four new source/geometry methods
plus actual boundary/CAS extensions cover both useful closure and refusal.
Parent's398/196 receipt is supplied, not reproduced here. CPython3.14 and the
already-provisioned pure-Python HTTPX packages remain in use; no installation,
missing-dependency skip or native ABI claim.

One custom receipt-script attempt imported the worktree `mpc_lab` before putting
Parent first on sys.path. It genuinely failed source/import checks, including
missing NativeState and absent historical Git object734d459 in the wrong tree.
That failure is retained; changing only the harness import order to explicit
Parent-first resolved it, with no source-pin relaxation or package installation.
The successful final run also logged an asyncio slow-task warning; all actual
100ms guarded commands and the suite passed. No warning is a GPU measurement.

```text
2c1be46be5a124cb9a6275cd61f389f7eeedb42a6dd6963e6ae3dd74857743ed  native_experiment_audit.py
9969198051673812d691ef5104651b3135599524be842822d7d81b347eb0121b  test_native_experiment_audit.py
016a7a4a1fc9b360cffaaec409882a67f852384d3c11bdacdf6932ee8805e6eb  geometry canonical JSON
29c8c7aba2b84a5a5b21be634a69b1aa5fbea6851b22325afddc2d49b55690d9  unchanged time-free aggregate CPU projection
4e2d1c62d9f54f4c701a594df6e62070718c93a73f14bfb86ae4fee791ef6ba4  execution-specific CPU JSONL
847d839ce004cd8f41c8692ad05220032a7c7436e2595fde6d6330a2cf155c93  execution-specific CPU status
8a4025aa90382dea3c69271a838c15173b9b8fbc3f1c4757d05eecfdc11c8eb6  execution-specific cropped CPU JSONL
f1b0058e27a6fcc9ef3eec79ff4dff0d044410b82b6839ac0f0e89e80eced1af  independently queried CPU initial raw snapshot
ed5a6019cbb07b6dec3d8cd7cdd8179d1c6f5b4de509ca3423d9d17dcfe9d28d  independently queried CPU final raw snapshot
```

Temporary execution files are cleaned; their clock/run-dependent hashes are
receipts, not retained Native raw data or reproducible fixture constants.
The canonical geometry is reproducible from the pinned CostSpec and module.
Full interval=true; crop with actual final=false; log-derived fake final is
structurally consistent but execution-authenticated/full-run=false. No new
fit, fresh prediction score, native result, physical permit or MPC authority.
Report hash and ordinary local commit are printed as the final local receipt.

### R14 urgent follow-up: Source144-only replica bridge seal

**`load_source144_replica(frozen_model, folder)` now loads the exact sealed
Train15/16 source domain without changing the frozen model or scoring forecasts.**
The original frozen R13 loader still correctly refuses Source144. This bridge
registers144 separately; it does not alias729, alter COMMON/SOURCE_BINDINGS,
change gates, fit parameters or manufacture ACKs/holds.

Only the newly authorized frozen Train15/16 folder and public48s smoke archive
were read. Index/source metadata and episode envelopes were inspected for loading;
**no fresh forecast, diagnostic score, model comparison or gate was evaluated**.
Cal17-36/Val37-40 raw files were not opened. Legacy Train1-3 remain on the original
loader; no legacy raw files were opened for this follow-up.

Registration requires actual Source144 commit
`144cef32a9b51c3a74355ff67f5eafdfac6e075f`, core
`ed8a6a537b7b663f44f4d6ed42d9679fe88048b4077c25dd778b6e8cf418a014`,
costcf816/support7e6d, collector78e2, protocolae10 and the exact64589 clock domain.
The full unfitted model Identity, controller version, strict calibrated=false/
mpc_active=false, pinned Qwen snapshot/served model, software and native launch
flags are validated. Scheduler max-num-seqs32 and batched-token limit2048 are
launch settings, **not** the reservation budgets16/32 and not concurrency16.

The bridge requires exactly20 assigned train episode slots: blocks181015/181016,
all five cells, both arms. It pins index and manifest bytes and verifies **all
40 raw/event SHA256s before calling any episode parser**. Missing events, duplicate/
outside-scope manifest entries, changed SHA/bytes, non-Train/missing slots and
wrong source/core/cost/support/model/flags/domain refuse. No raw path outside this
whitelist is accessed. Raw episode bytes are checked again before parsing.
Paired offered tapes must match; all expected client IDs/rows are retained,
with actual model/domain/ignore-EOS flags. Available native frames retain144
Gateway Identity and source/domain/observer/parameter flags; unavailable frames
are not invented or transformed into successful observations.

Only after registration/verification does the bridge call the **unmodified**
frozen `episode_from_replica` and `bind_assignments(document, True, domain)`.
True denotes this exact confirmed-holds collector's capability; actual holds
still require the frozen ACK/version/operation/run/domain/chronology checks.
Every returned episode retains source144 and coreed8. The receipt includes all
raw **and event** digests and explicit fit/forecast/gate/MPC=false fields.

The actual public smoke tar hashes to
`cdcb249b397c9bab2c11a8beeb05dc360eaa9444cc1db872319f824dc4a8eafa`.
Its144 launch/Identity match, but its protocol is
`68df0a92f31e61eb85e7dad39c671b40bced7fae41d694077a13efb2e66afbe8`,
not the sealed Train protocolae10. Its train-labeled180001 smoke episodes are
also not181015/181016. Tests therefore **correctly refuse** it rather than
rename its seed/protocol or present it as a positive Train dataset. The positive
test loads the actual complete frozen20/40 Train pair and confirms the frozen
COMMON/SOURCE_BINDINGS remain byte-value unchanged.

Ledger authority remains prefix-only without an independent full witness.
Source first-content239 changes first_at; terminal cleanup529/finish_request439
releases the lease. Three events for a standard completion are admission,
first-content mark and release: **not three lease changes**. Event digests alone
do not prove suffix closure, per-UUID release, physical EOS/service or MPC merit.
Published Source144/5221ee1 and main5h8+ are not10h completion or a MPC win.

**94 tests /147 subtests passed, zero skips**, including four new Source144
methods and actual public-smoke/complete-Train tests. No package installation,
GPU/SSH/API/runtime change or fresh forecasting. This local commit is the bridge
seal **before any future fresh forecast scoring**; existing preregistration
and independence/censoring/uncertainty/permit requirements remain intact.

```text
f3c2a060c5bb91ef196d4bf66ad6890e5c94d007992fbb74a5580389c52887e6  native_experiment_audit.py
cd657ff3de04644b08c485289b2ab8f8e13c8a1ef33b9cabef5e0c91aa8d1a8d  test_native_experiment_audit.py
a7e088fb410ef29a032b2bcd4e8a0dd3d59bd7b1d33a38b7bc2e8146950ca54b  frozen Train15/16 index
15b36155c6d91ae0b009edb74463db2beafb24703843c5c6a6a3aee109c18a8a  all40 raw/event SHA manifest
3ec5b68364a1e7eb17e38ea47a81c5fd0490365bde1b1045e383ff9b09067bd9  unmodified frozen R13 model/parser
d9975427a459d02b60c58fcedf78897fe673e0ba4f1d084a2303dac939b67e9a  canonical Source144 bridge receipt
```

Ordinary local commit, report hash and committed source/test hashes are printed
as the final source-only receipt. No Beads/runtime or forecast authority changes.

### R15 independent experimental critique: pr-native-v3.10

This is a bounded CPU falsification of the **unchanged** frozen R14 Gemini
`LiveNativeCohortRunner`, not a replacement runner, GPU pilot or new model fit.
`bd show pr-native-v3.10` failed with the known localhost Dolt refusal; the
Mayor-supplied assignment is the scope and this report is the persistent receipt.
No database restart/retry/mutation was performed.

The executed class is extracted without body edits from the frozen source:
`a2adf55bc57e2e6f3f02310cef2c950d066d1caa5cfa0e6f4304252e1551007b`.
Tests supply actual HTTPX AsyncClients/MockTransport with standard Chat SSE,
source-shaped Gateway/Native snapshots and an explicit parent NativeBinding.
They use real parent `capture_chat`, `drain_evidence` and NativeState validation.
The actuator is an explicitly injected failed/unknown-receipt fault, **not**
an execution qualification of GuardedActuator or a permit for its default
automatically approved IdentificationPermit.

**Executable findings**

| Witness | Actual CPU result | Experimental failure |
|---|---|---|
| Explicit real-shaped binding with distinct runs/cost, failed drain, empty gate | 13 POSTs; supplied cost ignored; empty tag `all` true; zero censored and mean0 | `bnd` is unused; failed source/drain does not stop nine anchors or four bursts; empty gate is not a complete assigned cohort |
| Unknown CAS, missing gate OUTPUT, disappeared end cohort | Four full-SSE serial bursts; gate counter defaults1; end after last HTTP+1s, more than1.12s after submission; nine censors but mean0 | Unknown assignment does not stop dispatch; zero imputation is not an ITT point; headroom-based survival flag remains true despite disappearance |
| Failed CAS, gate OUTPUT1, apply OUTPUT8, end OUTPUT8 | Four bursts; reported mean7; apply-to-end bounds[0,0] | It counts pre-assignment progress as evaluation-window progress and continues after failed assignment |
| Independent actual-capture reference | Four common-due **burst** attempts concurrent within30ms; actual first content visible; sample at apply+1s while all four full captures remain pending | HTTP completion need not determine the observation window; terminal receipts arrive afterward |

The serial-delay issue is also **treatment-dependent measurement error**:
rejected low-cap HTTP can finish quickly while admitted high-cap SSE lasts
longer, making the purported same1s arms different windows. The code's `t_apply`
is consumer time after `submit`, not a qualified server `response.applied_at`.
It also takes start counters from the earlier gate, not the apply-time frame.
Neither a fixed90tok/s constant nor early remaining>90 is an independently
verified physical upper rate or finite-max survival proof. `ignore_eos=True`
does not prevent reaching max256/512. No physical EOS observation is demanded
to make this criticism: missing/reset reporter endpoints require censor bounds.

**Correction to the supplied scheduling characterization:** actual parent
`capture_chat` really waits for a future `scheduled_at`; it is not universally
metadata-only. Nevertheless, the frozen runner sequentially awaits each entire
capture at the same overdue schedule. It cannot create four simultaneous actual
attempts or guarantee an apply-relative1s measurement by passing that timestamp.
The positive reference uses no retrospective receipt publication/backdating.

**Minimal receipt checks, not another deployment implementation**

`controlled_dispatch_preflight(binding, initial, gate, ...)` uses the explicit
NativeBinding and strict parent NativeState validation. It refuses wrong
source/domain, unavailable/orphaned state, non-drained initial work, non32 initial
budget, empty/missing/duplicate inventory, nondecode or missing counters, wrong
tags/maxima and absent/mismatched source CostSpec/original charges. Actual
Gateway charge arithmetic comes from the supplied hash-matched cost document,
not nominal fixture constants or caller `prompt_tokens`. Valid receipts can
only report **conditional gate readiness**. They never authorize dispatch.
Pending Native work stays explicitly unknown; separate snapshots are not an
atomic closed-cohort proof. Trusted ingress and source execution remain false.

`controlled_window_bounds(assigned_ids, start, end, ...)` retains the entire
assigned denominator. Missing/disappeared/reset/invalid counters conservatively
retain [0,max] rather than zero. With seven observed10-token increments and two
unknowns at max256, the cohort interval is [70/9,(70+512)/9], not a survivor mean
or point7.78. Failed/unknown/not-dispatched assignments remain represented.
Assignment labels and scalar timing arguments alone cannot source-qualify an
experiment; primary, statistical, causal, Goodput, physical-survival and MPC
permits all remain false. The20ms/30ms assertions are CPU harness timing checks,
**not new native benchmark tolerances or statistical guarantees**.

For a future real pilot, acceptance requires producer-bound run/domain/source/
identity/charge registration, verified initial drain and controlled ingress,
exact immutable pre-assignment Native inventory, no default approved permit,
actual CAS/100ms TTL/pending fencing and applied server-clock receipt. Abort
unsafe dispatch on failed/unknown evidence while preserving every planned arm
and all assigned fates; do not replace them with an ACK-success-only sample.
Launch the four actual bursts under a common prespecified arrival tape,
record actual attempts, obtain qualified start/end observations at the
prespecified apply-relative target independently of HTTP completion, and retain
late/missing/reset intervals. Preserve the existing12 independent randomized
pairs, all-assigned ITT,5-token meaningful margin and censor/statistical gates.
Do not readmit known accepted work or mistake cap16/32 for concurrency.
Nothing here selects9x256 versus5x512 or weakens frozen R14.

**Environment and exact receipt**

The first targeted invocation genuinely failed from cwd package precedence
(`mpc_lab.native_state` missing); Parent-first import fixed that harness issue.
The next genuinely failed because Python3.14 cannot import installed NumPy's
3.12 extension. Mayor's provided py312 executable still returned no-such-file.
No installation, ABI tricks or absent-dependency skips were used. The bounded
tests extract only the unchanged **stdlib `clock_domain` function** from parent
`prefill_lab/live_http.py` into a temporary test import context; no NumPy
algorithm or full prefill module is stubbed/claimed qualified. Frozen runner
path setup is a no-op because Parent is explicitly on the import path.
Injected pending paths remain inside the owned worktree and create no journals.

**100 tests /165 subtests passed, zero skips**, including six new R15 methods
and nonfinite/overflow/boolean/wrong-window clock refusals.
Full owned-suite validation also reproduced the Source14420/40 bridge tests.
AST equality against sealed commit
`598ad1584fc778aa87627ddf22778c92bff6b16d` verifies `_register_source144` and
`load_source144_replica` are unchanged. No fresh forecast/fit/scoring,
Cal/Val/Final raw, GPU/SSH/paid resources, model weights, parent/live changes,
source aliases, push or benchmark authority promotion.

```text
335f6d8a4c088d6a2c20f9568c44d163a3efea3a65642d9f2ce7522f8cc17cad  native_experiment_audit.py
c691cb918be9ef99300d408fb02e0f3b9bb0fabf78d5af3d24764527e19ac225  test_native_experiment_audit.py
6465bcbb112bca0a39ae07716ea96d50375145e6571e55082994529dd9802b0b  canonical CPU witness receipt below
0648738704771f80470849b0c0beb671d0f17c9dbc75e4095cff155b20d04be7  actual parent capture
835df8ebaa58c773074e65cedba4627b468d14b560233a7655bf9cd2240b83d6  actual parent NativeState
e31dbe92eb3a27be554db15405af0a6046a6820096e84540812d3ee88afc59d5  parent actuator import; NOT executed qualification
cbbd1f338e0d078d5c5eacdfbcec725dcfe2ed9b46c1ee1ed68ad2f26de24e1f  parent prefill source; stdlib clock function ONLY
```

Canonical receipt bytes (UTF-8, no trailing newline):

```json
{"binding":{"drain_verified":false,"empty_gate_censored_count":0,"empty_gate_mean":0.0,"empty_gate_tag_all_true":true,"posts":13,"supplied_cost_ignored":true},"origin":{"apply_origin_bounds":[0.0,0.0],"bursts":4,"gate_origin_mean":7.0,"status":"failed"},"timing":{"bursts":4,"censored_count":9,"corrected_mean_bounds":[0.0,256.0],"end_after_last_HTTP_plus_1":true,"full_HTTP_serial":true,"late_relative_to_assignment":true,"missing_gate_counter_default":1,"purported_survival_verified":true,"status":"unknown","zero_imputed_mean":0.0}}
```

Ordinary local commit and all three committed file hashes are delivered to
Mayor with **immediate** nudge. This receipt is CPU experimental critique only.

### R16 common-core independent peer/journal review: pr-native-v3.17

All12 R15 files were verified against the supplied frozen manifest before
review. This round performs no forecast, profile, refit, endpoint selection or
new data evaluation. Source144 and its f3c bridge remain separately sealed;
`_register_source144`/`load_source144_replica` ASTs still equal commit598ad15.
The journal is a **new source epoch**, not an alias for144 or729.

**Peer disposition**

| Peer | Accepted result | Remaining qualification boundary |
|---|---|---|
| Opus R15 | Explicit Native/Gateway tag audits; stale-snapshot pending-stock defect; aggregate ledger release-time/cost multisets distinguish endpoint conventions | Its `_offer_cost` obtains eventual owner/reject charge and its pending audit uses final rows: retrospective labels, not an online callback interface. Same-cost release multisets do not identify per-owner ages. Snapshot deduplication must not hide differing same-sequence copies. Smoke suffix remains unproved; no rescue of H12/H13 or new fit |
| Astra R15 | First-content/non-eviction whole-cost witness and saved-table conditional tail-value identity; separately timed, source-bound descriptive prefixes | Two packet pairs do not establish global coverage, simultaneous state or a real pending queue. Saved-tail gain does not prove a changed first action or deployed policy value; old-core v11 integration remains refused |
| Gemini R15 | Failed initial binding/drain and nonapplied CAS now abort dispatch; bursts are concurrent; sampling is independent of their full HTTP completion | Gate still lacks source/clock/NativeState validation, unique Gateway-tag equality and required positive counters. It uses nonexistent observer `phase`, gate-start counters, client post-submit time and survivor means. Default approved permit and sourced-cost fallback remain inadmissible qualification |
| Sol R15 | Original exact raw6465 negatives remain; conservative all-assigned bounds and conditional preflight are useful refusals | Scalar labels/timestamps are not source-qualified commands; conditional readiness never authorizes dispatch. Its old producer SHA must refuse the changed journal Gateway. No closed-work fit or5s/native permit has appeared |

For saved scores, Astra's identity
`V32-V16 = (q32-q16) + (d32-d16)`, with `d_a=V_a-q_a>=0`,
is the right distinction between conditional tail flexibility and first-action
value. An exact optimizer of32 surrogate plans does not identify their causal
responses or transfer random-policy residual coverage to optimized plans.
Keep horizons1/3/5s, five future1s inputs, common exogenous future offers,
the strong constant/one-move comparator and unchanged SLO/output meanings.
Whole reservation cost is not request count, GPU-seconds or CUDA batch work.

**New executable Gemini R15 findings**

The unchanged frozen gate loop accepts nine unique opaque Native IDs all
claiming **one** client UUID, wrong source/domain, absent waiting/output fields,
and `computed128 < actual prompt4096`: it compares computed to the protocol's
nominal128 instead of each observed request. This is not a validated decode
cohort. Conversely, the actual pinned observer functions, executed against a
CPU scheduler-shaped object, emit prompt/computed/output/max/tags/ignore_eos
but **no `phase` field**. The same frozen gate times out on those actual-shaped
rows even when computed129/prompt128/output1. No new observer was invented.

Exact frozen statements also retain `t_apply=self.clock()` after submission,
not `response.applied_at`. A response with server apply10 and client receive10.2
therefore targets11.2, not11. Start counters still come from the gate. With
two assigned actors and one disappeared, the code returns survivor mean10;
the all-assigned max256 interval is [5,133] and no qualified point remains.
R15 now checks survival at end rather than early headroom, which is an
improvement, but unqualified endpoint membership is not continuous physical
survival, exclusive service time or EOS. The paired wrapper's means must not
promote censored/failed arms into an ITT point or inferential success.

**Separate owner-journal producer qualification**

Reviewed exact commit `a4ec4e386e68f6ea20b68a8557785fc5813c7b16`, Gateway SHA:
`21e3b335450a141e0c9c84d15a5f6c46850f9bb219b296a1f7b9929c6caa81f7`.
Opt-in requires MPC lab, cost_aware admission and both log/status paths.
`mpc_changed` writes v2 `change_kind`, owner UUID and immutable request_cost.
Admission adds whole cost, first-content leaves it held, terminal cleanup
removes it once; control changes budget/version without eviction or stock
release. `running` here is **Gateway owner count**, not Native scheduler running.

Shutdown joins the loop-owned writer, performs final flush, captures final
sequence/remaining owners/arithmetic consistency, then hashes exact file bytes
and atomically renames a status file. Leftover owners make status **failed**
even when `mpc_ledger_complete=True`; the tested clean lifespan can still return
normally, so process exit success alone is insufficient. No fsync or
authentication is provided. A shutdown ingress/in-flight fence and unique
epoch file paths still need qualification: append-existing paths are possible,
and the memory/status/hash observations are not an atomic concurrency fence.

`audit_owner_journal_epoch` is separately versioned, source-pinned **offline**
replay. It requires original independent closed status, exact size/SHA,
drop/error0, v2 identity/run/domain, contiguous1..final sequence, finite ordered
effective/closure clocks, known unique owner admissions, unchanged charges,
first-content without release, valid control versions, whole-cost/count stock
coupling and empty final ownership. It refuses leftover, truncated or
re-sealed-truncated files, unknown owner, altered charge, first-content release,
wrong source/domain and legacy status. It deliberately does not reuse the old
aggregate prefix auditor or its Source144 identity.

Actual new Gateway/lifespan/flush definitions are exercised in the existing
CPU ASGI scaffold. New-source contracts/runtime are loaded only inside a
restored test context so their implementation hash refers to the **new**
worktree; old-core modules are not used to manufacture a new-core identity.
Source-specified costs are computed from its actual CostSpec for two explicit
CPU payloads, not fixed30/7 or native efficacy observations. Their held stock
exceeds16 while owner count is2; lowering32→16 and first content do not evict.
The second owner releases first; the journal resolves that UUID, not FIFO.
This is ownership arithmetic, not a new controlled-cohort geometry.
Direct control-version mutation in this scaffold is **not actual CAS transport
qualification**. Original strict tagged producer binding rejects this Gateway.

A deliberately self-consistent UUID-remapped file plus recomputed status also
passes *conditional replay* while authentication stays false. Hashes bind
bytes, not truthful execution or trusted ingress. More importantly, a future
closed-file seal cannot certify that a row was visible before an earlier model
cut: raw `effective_at<=cut` lacks independent publication/receive clocks.
Current flush cadence may exceed the100ms decision budget. The new function
always leaves `online_cut_available=False`, fsync/authentication/physical EOS/
active MPC false. It verifies owner transitions only: rejected/unsent/offered
traffic completeness is a separate callback receipt obligation.

**Revised future Train41/42 proof/spec, sealed before exposure**

1. Register this new Gateway/core/cost/support/collector/protocol/model/flags/
   run/domain epoch separately with exact source and artifact manifests.
   Old144/729 loaders and old model identity guards must continue to refuse it.
   No hash, endpoint, parameter or prediction-gate alias is permitted.
2. Capture the entire epoch journal and independent final status, start at
   sequence0/empty owners under verified drain and controlled ingress, fence
   final work, require closed/drop0/errors0/remaining0/exact sequence and bytes.
   Preserve source-bound original payload charge marks and actual applied
   CAS/TTL/pending receipts. Journal request_cost alone lacks prompt/max/cost
   provenance sufficient to independently recompute every charged estimate.
3. Separately capture all planned/actual client registrations and callbacks.
   For online inputs qualify source/sequence/completeness/error/heartbeat,
   publication and independent observer receive clocks; use only a contiguous
   actually received prefix at each cut. Accepted-known work is never re-offered
   under another cap. Native-invisible, waiting and pending-batch work stay
   unknown. Retrospective final-row clocks and final journal seals are labels,
   not cut-time receipts.
4. Keep the exact previously sealed model/hypothesis, split/baselines, fixed
   horizons and masks; any ledger-based release replacement is a **new**
   prespecified experiment on41/42, not retrospective endpoint rescue.
   New source admission/release timestamps can identify host lease transitions;
   they cannot fit exclusive GPU service or identify off-policy interference.
   Actual Native stayer counters, censor intervals and complete observed
   origins still need their own source-bound estimand/mask.
5. For the controlled pilot preserve12 independent randomized pairs, all
   assigned ITT/failures, immutable preassignment inventory, genuine server
   apply+1s sampling, common concurrent actual burst attempts, max5% censor
   constraint and meaningful5-token margin. No ACK-success/survivor selection,
   physical survival shortcut, forced-Goodput label or native/MPC permit.
   No41/42 or Cal/Val/Final raw was exposed or scored in this round.

**Receipt:**105 tests /175 subtests passed, zero skips; five new R16 methods.
All old R14/R15 negative witnesses and Source144 bridge tests pass unchanged.
The first owner replay run correctly exposed my wrong assumed count field
`admitted_count`; actual producer uses `running`, and that schema error was
fixed without changing the source or weakening arithmetic. Actual observer
version is a labelled CPU metadata stub; no vLLM/GPU was invoked. No extra
forecast/profile/refit, installation, parent/live modification or push.

```text
6c3ee52c247b02d738baaa0ac93e08b436f00bce3c7657941be1e58fa8321d93  native_experiment_audit.py
e8df2f67437d8e1909d40826c74cebcef0ffdfb1103c5a35b499ded383717813  test_native_experiment_audit.py
fa51dcdb981662acba7ac6259747d188c6cb9e841ec0dde17732b186e80960ea  canonical CPU journal receipt below
```

Canonical UTF-8 receipt, no trailing newline:

```json
{"active_mpc_permit":false,"byte_seal_verified":true,"final_sequence":6,"kinds":["admission","admission","first_content","terminal","terminal"],"non_FIFO_release":true,"online_cut_available":false,"source_execution_authenticated":false}
```

Local commit and all three committed hashes are delivered by Mayor immediate
nudge. No `.beads/` or `.runtime/` cleanup or database mutation.

#### R16 same-task actual-counter/max512 contract follow-up

Mayor's supplied static schema-refusal receipt agrees with the independently
executed R16 observer/gate witness above. The reference producer remains
SHA77633 and has exactly its real eight request fields; **no phase was added**.

One additional CPU actual-source-shaped contract case exercises the unchanged
`controlled_dispatch_preflight` with five max512/True-ignore-EOS anchors and a
bijective cohort/Gateway UUID inventory. It derives the counter phase proxy
from `computed >= each row's ACTUAL prompt_tokens`, positive integer output
strictly below the qualified maximum, and typed actual sampling flag. Source/
identity/run/domain/receipt freshness use the existing strict NativeState
binding; independent pending/ingress/execution/survival qualifications remain
unknown/false. Invalid actual-prompt progress, output0, False EOS flag,
duplicate Gateway tag or mismatched maximum all refuse. This is a counter
phase proxy, **not an observed scheduler phase or exclusive GPU service**.
The earlier exact `observe` execution proves field compatibility; this new
case supplies those fields plus explicitly CPU-labelled merged Gateway/
frontend receipts, not invented physical observations.

The fixture deliberately distinguishes Native prompt256 from Gateway-estimated
prompt512. Each actual quoted original charge is computed from the source
CostSpec and Gateway mark, not from the protocol's nominal p128. Nominal
5*p128/max512 stock plus four nominal bursts fits32; **actual quoted** stock
plus those bursts exceeds32. Thus valid counter/UUID readiness does not prove
the intended action contrast or four high-cap admissions. Token estimator
provenance/actual marks and existing non-eviction must determine the contrast;
filler text/declared `prompt_tokens` cannot certify it. This is hypothetical CPU
arithmetic, not a measured new native geometry or a choice over9x256.

Require this field-derived/source-verified contract before any future pilot,
with the already sealed41/42 journal/callback/CAS/ITT/censor requirements.
No observer changes, freshness relaxation, invented phase, native permit,
new forecast/profile/refit, Cal/Val/Final raw or GPU access.

**106 tests /180 subtests passed, zero skips.** Production module unchanged:

```text
6c3ee52c247b02d738baaa0ac93e08b436f00bce3c7657941be1e58fa8321d93  native_experiment_audit.py
a7fc879f6a463153ca2066740a8835d4ba234052943a9f2afa47c6395bd80a6c  test_native_experiment_audit.py
```

Ordinary local follow-up commit and all three hashes are delivered by immediate
Mayor nudge; earlier R16 source/receipt remains historical, not overwritten.

## R17: written-source, server-clock and all-assigned falsification

**Local CPU seal for pr-native-v3.20; Native remains UNTESTED.** The requested
`bd show` failed with the known sandbox localhost refusal; no retry, database
mutation or connectivity exploration was performed. All twelve R16 frozen-file
SHA digests were independently verified. No new forecast, profile, refit or
future raw data was read.

### Source epochs and bounded interfaces

Historical Source144 and a4ec contracts remain untouched: AST equality against
`719d79a` holds for `_register_source144`, `load_source144_replica` and
`audit_owner_journal_epoch`. The historical owner auditor still binds
`21e3b335450a141e0c9c84d15a5f6c46850f9bb219b296a1f7b9929c6caa81f7`
and explicitly refuses the corrected writer; no hash alias or model change.

The separately bound corrected candidate is commit
`d1bd1e5f6262eda1ee29867689a810a475797c73`, Gateway SHA
`23aef8b8b903eda99ea325fd8ece09d998c174df39f2d1230ed5b9cc37e4ce3a`.
`audit_written_journal_seal` checks its actual bytes/SHA, closed status,
run/domain/identity, contiguous v2 written rows, producer/written/count
agreement, zero unflushed/drop/error and zero remaining-owner status. Its
`sol-written-journal-seal-v1` result qualifies only a conditional offline
**written seal**, not per-UUID ownership replay, online cut availability,
execution authentication, fsync durability or native/controller authority.
It must not be substituted for the old owner-replay auditor.

`audit_server_counter_bracket` is a separately versioned conservative receipt
prototype. It requires an explicit approved matching source/run/domain/identity
permit, actual server apply, matching CAS version, command TTL at most100ms,
budget16/32, permit expiry through target and source-clock frames bracketing
**server apply +1s** with valid receive chronology. All assigned identities
remain in the denominator. Valid monotone reported counters produce interval
differences; disappeared/reset/missing/invalid counters receive the full
`[0, maximum_output_tokens]` censor interval. The maximum is a declared
source-reported finite bound, not inferred physical survival or delivered
goodput. Start counts likewise must be independently source-bound at the
registered start, not recycled gate counters; this prototype does not itself
prove their provenance. It returns no point mean and no statistical/native/MPC
permit. A matching receipt dictionary is a conditional hypothesis, not
authentication or proof that an actual actuator executed it.

### Actual corrected-source CPU witnesses

The existing isolated Gateway scaffold executes the exact new Gateway bodies
with its own contracts/runtime source, actual telemetry writer/lifespan and
temporary JSONL/status files. It restores old package bindings afterwards.
Transport/framework/tokenizer scaffolding remains CPU-only, not an end-to-end
native qualification.

One anchor cleanup injected after the closing writer's awaited flush is
preserved by its second flush: admission/first-content/terminal, producer3,
written3, rows3, unflushed0, statusclosed. First content is still not a release.
An initial unlogged sequence is refused: producer4, finalwritten4, only3 rows,
statusfailed. A second cleanup arriving **after the second flush** yields
producer6, finalwritten4, rows4, unflushed2, remaining owners0 and drop0, yet
statusfailed. This is useful fail-closed behavior, not a promise that two
flushes drain arbitrarily late producers.

NoneMark, disabled writer and already-closing admission refuse without
stock/sequence mutation; both already-closing budget endpoints return503.
However, a distinct actual-body interleaving remains: both budget endpoints
check the writer/closing guard **before `await request.json()`**. If that await
resumes after closing and writer disablement, both can still return200,
increment budget version/producer sequence to1 and leave no buffered row.
The fixture controls that exact await; it does not claim that production
Uvicorn shutdown necessarily permits this interleaving. Source-local guards
alone therefore do not establish closure against in-flight controls. Either
prove/enforce ingress-and-handler draining before writer closure, or serialize
closure and recheck writer/closing under the same mutation lock. No Parent
repair was made and no closed-control permit is granted.

### Repaired Gemini and common-core adjudication

Gemini's exact `5aecb10c2bd2af543a3e0ad19ceec9cac4f5cc77` blob was read from
shared Git objects and pinned against its schema-freeze SHA
`7b6e48e6e163686c33f964260ad3d8c4734bea923892e77c748ac554c187b60d`.
Its actual eight-field/no-PHASE, UUID and counter/prompt repairs are real;
the old R14 phase/drain/sequential-burst criticisms are not repeated as
current faults. Executing the exact remaining statements still reproduces
automatic default approval, consumer apply10.2 rather than server apply10,
target11.2 rather than11, gate-origin survivor mean10 with one censored
assignment, and receipt-relative burst due10.45 rather than the registered
server-relative10.1. A receipt-relative schedule could be a different
preregistered policy, but cannot silently stand in for this server-relative
contrast. A source-bound ACK is not itself a model-risk permit.

Opus correctly separates ownership labels from native EOS/GPU service and
identified the historical journal defects. The corrected written watermark
addresses one defect, not online availability, all ingress races or causal
GPU identification. Astra's offline-versus-online distinction and conditional
horizon-value algebra remain useful; neither final seals nor conditional
value establish native efficacy. Gemini's schema/concurrency improvements
do not repair the remaining clock, auto-permit and survivor estimands.
Sol's wide all-assigned bounds deliberately refuse a survivor point result;
no censor-independence assumption or survival estimator is introduced to
make those bounds narrower.

The positive reference has an explicit matching permit, server apply10,
target11 and samples10.99..11.01. Two assignments, one missing, yield
mean interval **[3,261]**, pointnull and no native/MPC permit. Missing permit,
wrong domain, noncompliance, expired TTL and unbracketed target refuse. This
is bounded reporter arithmetic, not a hardware result or effect estimate.

### Prospective split and falsification contract

This supersedes the earlier R16 journal41/42 suggestion: **H14 remains natural
Source14441/42 with unchanged model/spec; H16 is a distinct prospective
corrected-owner measurement43/44**. Neither raw pair was read here.
H16 requires its own immutable source/run/domain/identity, trusted ingress
conditions, flushed written-row closure, per-UUID original-charge ownership
replay under that new source, and contemporaneous receive/sequence evidence
for every claimed cut. A final journal cannot certify a past online prefix.
Actual ACK/CAS/TTL/pending and apply-to-target brackets must be retained;
counter schema, assignment inventory and source-reported maxima must be
sealed before exposure. Preserve the twelve independent randomized-pair
unit, all-assigned ITT including failed ACK/dispatch/missing outcome, primary
1s reporter-counter contrast, five-token/anchor meaningful margin and5%
censor gate. No ACK-success-only, final-survivor-only or serial HTTP service
estimator; no direct budget-to-GPU-rate or fixed-mark causal claim. Failed
closure, unavailable brackets, excessive censoring or unidentified ingress
refuse rather than becoming zero effect or a permit.

### Complete local receipt

**113 tests /187 subtests passed, zero skips (8.505s)** on the current original
Parent and separately pinned actual new-source scaffold. The provided py312
executable remained unavailable; the documented Python3.14/pure-Python
dependency path was used, without installs, ABI substitutes or skips.
`git diff --check` passed. Historical AST and all12 R16 artifact checks passed.

Canonical complete seven-witness receipt, SHA
`241add32c5aebaef809d8ad5d7d1f84bbc53fe3d27608c6b9e8d797541399ce4`:

```json
{"active_mpc_permit":false,"closing_race":{"mpc_update_budget":{"budget_version":1,"buffered_rows":0,"http_status":200,"producer_sequence":1},"update_budget":{"budget_version":1,"buffered_rows":0,"http_status":200,"producer_sequence":1}},"fsync_durability_verified":false,"gap":{"producer_sequence":4,"status":"failed","written_rows":3,"written_sequence":4},"gem":{"auto_approved":true,"censored_count":1,"consumer_apply":10.2,"gate_origin_mean":10.0,"receipt_relative_burst_due":10.45,"server_apply":10.0,"server_relative_burst_due":10.1,"wrong_target":11.2},"native_permit":false,"positive":{"active_mpc_permit":false,"all_assigned":2,"mean_interval":[3.0,261.0],"native_permit":false,"point_mean":null,"server_target":11.0},"refusals":{"NoneMark":true,"closing":true,"control_http_status":503,"disabled_writer":true,"producer_sequence":0},"second_flush":{"producer_sequence":6,"status":"failed","unflushed":2,"written_rows":4,"written_sequence":4},"source_execution_authenticated":false,"written":{"late_cleanup_preserved":true,"producer_sequence":3,"status":"closed","unflushed":0,"written_rows":3,"written_sequence":3}}
```

```text
75e559c57b95e3588d5a00617e2faaf57c223906e43b0c3aa06c2a8453001ead  native_experiment_audit.py
943980e440e589173531cd5a1da96a876b4463e17f872760c2fd8f78af122dc4  test_native_experiment_audit.py
```

All three file hashes and ordinary local commit are delivered by immediate
Mayor nudge. Only these three owned files changed; existing untracked
`.beads/` and `.runtime/` remain untouched. No GPU/SSH, Parent edits, push,
fresh forecasting or Cal/Val/Final raw exposure; all native/auth/fsync/MPC
qualification remains false.

## R17 same-task serialized-source confirmation

**Two bounded actual-source CPU confirmations only; no product changes.**
The new candidate is commit `104e65a69df73997b977bce2588b655ae714f45d`,
Gateway SHA
`0b1a80ade258d8875ba80a072c4f360bfa5d4a7ac312bd222c0571380b341570`
at the separately named `mpc-native-owner-serialized-journal` worktree.
`R17SerializedSourceTests` pins those bytes and uses the existing isolated
actual-Gateway/telemetry scaffold; no production binding is registered.

Both actual budget handlers now reject the earlier controlled interleaving:
closure is set under `state_lock` during the JSON await, the writer is
disabled, and the resumed handler returns503. Budget, version0, producer
sequence0 and empty buffered rows remain unchanged. This confirms the
post-JSON locked recheck for these bodies; it does not prove production
shutdown reachability, arbitrary ingress draining or blanket lifecycle safety.

The actual append/flush/status path rejects a foreign-run **non-ledger** row:
statusfailed and ledger completenessfalse even with producer0, written0 and
zero ledger rows. The same-run non-ledger control closes with completenesstrue;
both actual byte counts and SHA seals match the written files. This confirms
the all-row run check, not semantic validation or authentication of arbitrary
same-run rows, online cut availability or a general ownership seal.

The product module is byte-identical to `f2ad1fd`. Exact historical Gateway
bytes21e3/a4ec and23aef/d1bd were independently rechecked at their unchanged
paths. The complete suite retains the old23aef body-race positives and all
historical negative tests; neither old binding was patched or aliased.
No additional witness family, forecast, fit, profile or native data exposure.

**H16 remains prospective43/44 and must separately qualify104e source,
ownership/clock/ingress and collection bindings before collection.**
These two confirmations alone do not qualify that binding. H14 remains
natural Source14441/42 with its unchanged model/spec. Blanket seal,
authentication, online, fsync, native and MPC qualification remain false;
no Parent edits, GPU/SSH, push or Cal/Val/Final raw access.

**115 tests /191 subtests passed, zero skips (8.771s)**, including the two
new methods/four new subtests. `git diff --check` passed.
Canonical conditional follow-up receipt SHA
`4c330afefb66ef9e56bd834dc643ac918fdd21243037ee894e26e0d85a725aee`:

```json
{"active_mpc_permit":false,"blanket_seal_qualified":false,"closing":{"mpc_update_budget":{"budget_version":0,"buffered_rows":0,"http_status":503,"producer_sequence":0},"update_budget":{"budget_version":0,"buffered_rows":0,"http_status":503,"producer_sequence":0}},"gateway_source_sha256":"0b1a80ade258d8875ba80a072c4f360bfa5d4a7ac312bd222c0571380b341570","native_permit":false,"nonledger":{"foreign":{"ledger_complete":false,"producer_sequence":0,"status":"failed","written_rows":0,"written_sequence":0},"same_run":{"ledger_complete":true,"producer_sequence":0,"status":"closed","written_rows":0,"written_sequence":0}},"online_cut_available":false,"production_reachability_claim":false,"source_execution_authenticated":false}
```

```text
75e559c57b95e3588d5a00617e2faaf57c223906e43b0c3aa06c2a8453001ead  native_experiment_audit.py
00da4c961dff2c4a5bddf1bc26605627553ed5b015cf3c06c13e00df04f6768c  test_native_experiment_audit.py
```

Ordinary local follow-up seal and all three hashes are delivered by immediate
Mayor nudge. Existing untracked `.beads/` and `.runtime/` are preserved.

## R17 same-task repaired paired-caller witnesses

**Three focused CPU tests only, no actual HTTP or Native activity.**
Exact Gemini commit `c4e70903fae3cf5d9d59710af76a7e5ab749794b` source SHA
`96af1c8d42dc24548759e8cd26da59756cd8c5e3c8e5b6e86acddc8f1b3335c8`
was read from this repository's Git objects. The complete unchanged
`run_live_native_cohort_pipeline` AST executes with a stub Runner returning
explicit arm receipts, a receipt-container stub and an import-scoped permit
constructor stub. No leaf runner, actuator, transport clock integration,
HTTP callback or native pipeline is executed or qualified by these tests.
The leaf's repaired server clock, bracketing and censored-mean refusal are
acknowledged; old5aec numerical witnesses are not relabeled as current faults.

`R17PairedCallerTests` independently reproduces:

1. Censored `anchor_mean_progress=None` and missing-explicit-permit refusal
   receipts cause the paired caller's `.2f` interpretation formatting to
   raise `TypeError`. Both arm calls already occurred, but no paired receipt
   is returned. Without supplied transports, absent explicit permits reach
   the stub asNone; this is a failure to propagate unknown/refusal, not proof
   that this branch dispatches unauthorized real work.
2. No-censor nondegenerate arm bounds A[10,30], B[0,25] have lower-bound
   means10 and0. The caller marks delta−10 as fixed-mark falsification,
   despite the identified contrast **[−30,15]**, which includes zero and
   fails the meaningful negative-margin condition. These are source-shaped
   bracket bounds, not Native measurements.
3. Supplied transports with no explicit operator permits still cause two
   `approved=True` permit-constructor calls. A stub receipt contrast−10
   triggers the caller's falsification flag even while `itt_preserved=False`
   and `all_assigned_fates_retained=False`. Constructor kwargs prove the
   default-approval code path only; the stub does not authenticate or
   authorize an actual transport.

The bounded **test-only** reference uses contrast
`[B.lower − A.upper, B.upper − A.lower]`, never a difference of lower-bound
points. It requires explicit assignment qualification, exact five-ID
inventory/fate coverage, all-assigned retention and at most5% censoring,
then requires identified upper **strictly below−5**. The overlapping example
refuses; a conditional [−11,−9] arithmetic reference passes the margin gate,
while missing assignment qualification, excessive censoring or incomplete
assignment retention refuses. All statistical/native/MPC permits remainfalse.
This is not a new production comparator or a statistical rejection:
the preregistered twelve independent randomized pairs, all-assigned ITT,
appropriate pair-level uncertainty, source/clock validity and meaningful
margin gates are still required for an experimental conclusion.

A caller repair must preserve optional means/unknown fates in a returned
receipt, format unknown values explicitly, avoid automatic operator approval
and report interval contrast with the assignment/censor gates. A negative
lower-bound point difference cannot replace an identified negative upper
bound. No Gemini or Parent edits were made; this pinned historical witness
does not prejudge the caller repair now in progress.

**Focused run:3 tests /2 subtests passed, zero skips (0.135s).** The latest
D41a **115/191** remains historical, not rerun or represented as a combined
zero-failure run. Product module bytes and every pre-existing test AST are
identical toD41a; the conditional0b1 two-guard source evidence remains unchanged.
Mayor's supplied485 required checks include separately executed canonical
Git-cwd evidence and retained main/wrong-repository failures; they are not
this worker's single-run total.

Canonical focused receipt SHA
`2d69037db42b147a97f9c96ba24467efd0756c5278104685448848b0d2a41369`:

```json
{"active_mpc_permit":false,"actual_http":false,"interval":{"caller_falsified":true,"contrast_interval":[-30.0,15.0],"guarded_falsified":false,"identified_reference_interval":[-11.0,-9.0],"point_delta":-10.0},"native_activity":false,"optional":{"censored":{"arms_retained_by_stub":2,"error":"TypeError","guarded_contrast":[-512.0,512.0],"guarded_falsified":false},"missing_permit":{"arms_retained_by_stub":2,"error":"TypeError","guarded_contrast":[-512.0,512.0],"guarded_falsified":false}},"permit":{"all_assigned_retained":false,"automatic_approved_permits":2,"caller_falsified":true,"explicit_permits":0,"guarded_falsified":false,"itt_preserved":false},"source_sha256":"96af1c8d42dc24548759e8cd26da59756cd8c5e3c8e5b6e86acddc8f1b3335c8","statistical_permit":false}
```

```text
75e559c57b95e3588d5a00617e2faaf57c223906e43b0c3aa06c2a8453001ead  native_experiment_audit.py
511fac896820d62cdc95bee9a17d461cdb23a8a8704aac67ff63c0f9d7453c62  test_native_experiment_audit.py
```

`git diff --check` passed. Only owned tests/report changed; no product,
Parent, GPU/SSH, forecast/profile/refit, Cal/Val/Final raw or push. H14
natural Source14441/42 and prospective separately-bound H16owner43/44 remain
unchanged. Exact local seal/three file hashes are delivered Mayor immediately.

## R17 same-task 793 paired eligibility seal

**Exact full paired-function CPU reproduction, one focused method/six cases.**
Gemini commit `79368366908f6525d6cbbf236ce380ca95887b2b` is pinned at module
SHA `44179f8d50e0f5aaead1d9cd77436cb6f90f10686a1992ccbfd3c2d28bd89142`.
The supplied Mayor probe and complete JSON were read; the independent test
executes the complete function AST from this repository's Git object with
stub arm receipts and a receipt container. An import-scoped, deliberately
unusable permit constructor prevents incidental actuator/dependency loading;
explicit CPU permit objects reach the stub arms. No actual permit validation,
leaf runner, HTTP, actuator or Native execution is claimed.

793 genuinely repairs interval contrast and optional formatting. Overlap
[−30,15] no longer falsifies; the one-of-five censored receipt returns a
paired result with point deltanull instead of raising `TypeError`.
Its eligibility check nevertheless accepts four invalid assigned/censor
cases despite identified interval[−11,−9]:

| Case | Caller falsifies | Strict conditional gate |
|---|---|---|
| Complete reference | true | true |
| Missing burst fate; ITTfalse | true | false |
| Missing anchor ID; count still5 | true | false |
| Lost all-assigned retention | true | false |
| One of5 censored:20% | true | false |
| Overlapping interval[−30,15] | false | false |

The new **test-only** guard includes burst offered/fate cardinality as well
as exact five-anchor inventory/fate coverage, retention, consistent censor
flags/count, at most5% censoring, applied assignment and interval upper<−5.
The historical c4e guard did not check burst-fate coverage; the supplied
Mayor probe therefore reported its strict reference astrue for a missing
burst fate. That historical guard/test is not rewritten: the separately
named new guard refuses this case too. An identified negative upper bound
does not erase broken ITT or excessive censoring. The complete reference is
only conditional arithmetic eligibility; twelve independent randomized
pairs, valid provenance and pair-level uncertainty remain required for any
experimental conclusion. Native/statistical/MPC permits remainfalse.

The first standalone attempt failed all six subcases before useful helper
execution because its incidental actuator import could not find `httpx`.
That actual missing-dependency failure is retained, not a Native failure or
a skipped case. The stub-only harness was corrected by isolating the unused
permit import, without installing dependencies or changing the function AST.
**Corrected focused run:1 test /6 subtests passed, zero skips (0.047s).**
These are separate failed and successful attempts, not a single zero-failure
history. Mayor's supplied119 pass is not this worker's run total.

Every prior test AST, including c4e historical failures and the conditional
0b1 guards, and the product module bytes remain identical to`bf28816`.
D41a115/191 and the later c4e3/2 focused run remain historical, not broadly
rerun here. `git diff --check` passed.

No peer-fix identity later than793 was supplied or examined in this follow-up;
no inference is made about unsealed work. The Native03 partial artifact
was **not opened**. The supplied pending-first-POST, fence budget32/version77
and subsequent stale-snapshot observations leave cause unidentified; no TTL
loosening or claimed diagnosis. GPU shutdown/26880s is Mayor-supplied context,
not newly verified worker evidence. No Cal HTTP rows/scores or any Native
raw data, forecast/profile/refit, Parent edits, GPU/SSH or push.
H14natural Source14441/42 and prospective separately-qualified H16owner43/44
remain unchanged.

Canonical complete six-case receipt SHA
`bd7676ff9897eafa1f52e6812547e3474c0f402eafae5d6127b04c2a7923b1b7`:

```json
{"active_mpc_permit":false,"actual_http":false,"cases":[{"all_assigned_retained":true,"caller_falsified":true,"case":"reference","contrast_interval":[-11.0,-9.0],"guarded_falsified":true,"itt_preserved":true},{"all_assigned_retained":true,"caller_falsified":true,"case":"missing_burst_fate","contrast_interval":[-11.0,-9.0],"guarded_falsified":false,"itt_preserved":false},{"all_assigned_retained":true,"caller_falsified":true,"case":"missing_anchor_inventory","contrast_interval":[-11.0,-9.0],"guarded_falsified":false,"itt_preserved":true},{"all_assigned_retained":false,"caller_falsified":true,"case":"lost_assigned_fates","contrast_interval":[-11.0,-9.0],"guarded_falsified":false,"itt_preserved":true},{"all_assigned_retained":true,"caller_falsified":true,"case":"excess_censor","contrast_interval":[-11.0,-9.0],"guarded_falsified":false,"itt_preserved":true},{"all_assigned_retained":true,"caller_falsified":false,"case":"overlap","contrast_interval":[-30.0,15.0],"guarded_falsified":false,"itt_preserved":true}],"native_activity":false,"source_sha256":"44179f8d50e0f5aaead1d9cd77436cb6f90f10686a1992ccbfd3c2d28bd89142","statistical_permit":false}
```

```text
75e559c57b95e3588d5a00617e2faaf57c223906e43b0c3aa06c2a8453001ead  native_experiment_audit.py
41cf0193f45da8b8c7fc38002ff1342114152dec4c88fde8630c538b20045576  test_native_experiment_audit.py
```

Only owned tests/report changed. Exact ordinary local seal/three hashes are
delivered by immediate Mayor nudge; existing untracked state is preserved.

## R17 same-task 5fc final-eligibility conditional audit

**Exact complete paired AST; CPU stub arms only.** All three supplied frozen
files were verified byte-for-byte against commit
`5fc93f15237be0cf57d48f2e7d335ccb3b787271`, with hashes:

```text
d03a587c77e3e276ffce809f783014da8aed4b239b108d0c6237568534d1755c  native_campaign_protocol.py
1a1e9f9e8bddead8c0699770f88b83a60c48540979f9c42969e0fc473e6788bb  test_native_campaign_protocol.py
c40a908234581e98e9e1eefb983c22bad69766933b37dd851a8d41c42de488c7  gemini.md
```

`R17FinalEligibilityTests` executes the complete unchanged new paired function
using the established import-scoped unused permit constructor, explicit CPU
permits, stub Runner and receipt container. No real leaf, HTTP, actuator,
Native, clock/control or statistical qualification is performed.

**All six original cases are repaired:** the complete [−11,−9] reference
passes the conditional margin gate; missing burst fate, missing anchor ID,
lost assigned retention,20% censor and overlap[−30,15] no longer falsify.
The fixes are acknowledged without rewriting the historical793/c4e failures.

Six bounded additional consumer-boundary cases give:

| Case | Caller falsifies | Strict conditional reference |
|---|---|---|
| One retained counter bracket made nonmonotone | true | false |
| Gateway/client tag match explicitlyfalse | true | false |
| Known binding-provenance lineage refusal | false | false |
| Assignment statuspending, notapplied | false | false |
| Reversed arm bounds | false | false |
| Negative arm progress bounds[−10,−9] | true | false |

The counter case changes one before-end counter to−1 while preserving the
declared [10,11] arm interval. The tag case preserves interval[−11,−9] but
returns `gateway_tag_matches_client_verified=False` alongside falsification.
The negative-bound case yields contrast[−31,−29], which is accepted because
the wrapper only checks bound ordering, not nonnegative reporter progress.
The conditional test reference retains the new burst/inventory/censor guard,
then requires matching tags, no lineage refusal, bounds in[0,512], monotone
integer counter brackets and aggregate bounds consistent with fate replay.
It refuses all six invalid cases.

**Scope limitation:** these are deliberately inconsistent or invalid stub
receipts at the consumer boundary, not demonstrated receipts produced by
the real leaf and not production/native reachability claims. A separately
qualified leaf contract might exclude these inputs; that exclusion must be
proved rather than inferred from this wrapper's return flags. Consumer checks
for matching tags, valid nonnegative/finite bounds and counter-to-bound
consistency, or explicit verified leaf invariants covering them, are needed
before calling the combined path qualified. No Parent/Gemini edits were made.
A successful reference remains conditional arithmetic, not physical
fixed-mark falsification, causal identification or a statistical guarantee;
the twelve independent-pair, provenance, all-assigned and uncertainty gates
remain required. No native/statistical/MPC permit.

**Focused run:2 tests /12 subtests passed, zero skips (0.426s).**
Every pre-existing test AST and product module byte remains identical to
`4aa390d`; historical source793/test/raw and c4e evidence are unchanged.
No broad history rerun or combined pass total is claimed. No Native03 or
Cal outcome artifact was opened. No forecast/refit/profile, Parent edits,
actual HTTP, SSH/GPU or push; H14Source14441/42 and separately qualified
prospective H16owner43/44 remain unchanged. `git diff --check` passed.

Canonical complete twelve-case receipt SHA
`dbcb57df17afd878b1aba9e6f8e6c7f0fc7175016035f280ef5ce66de461cc01`:

```json
{"active_mpc_permit":false,"actual_http":false,"commit":"5fc93f15237be0cf57d48f2e7d335ccb3b787271","guard_cases":[{"caller_falsified":true,"case":"counter_mismatch","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":true,"case":"gateway_tag_mismatch","contrast_interval":[-11,-9],"gateway_tag_matches":false,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":false,"case":"lineage_refusal","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":false,"case":"not_applied","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":false,"case":"reversed_bounds","contrast_interval":[-10.0,-10.0],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":true,"case":"negative_bounds","contrast_interval":[-31.0,-29.0],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true}],"native_activity":false,"original_cases":[{"caller_falsified":true,"case":"reference","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":true,"itt_preserved":true},{"caller_falsified":false,"case":"missing_burst_fate","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":false},{"caller_falsified":false,"case":"missing_anchor_inventory","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":false,"case":"lost_assigned_fates","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":false,"case":"excess_censor","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":false,"case":"overlap","contrast_interval":[-30,15],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true}],"source_hashes":{"gemini_md":"c40a908234581e98e9e1eefb983c22bad69766933b37dd851a8d41c42de488c7","native_campaign_protocol_py":"d03a587c77e3e276ffce809f783014da8aed4b239b108d0c6237568534d1755c","test_native_campaign_protocol_py":"1a1e9f9e8bddead8c0699770f88b83a60c48540979f9c42969e0fc473e6788bb"},"statistical_permit":false}
```

```text
75e559c57b95e3588d5a00617e2faaf57c223906e43b0c3aa06c2a8453001ead  native_experiment_audit.py
eebf9cc34e042a28e7fdf2be35794e4e3858b6302993497e2e07646b6e47c820  test_native_experiment_audit.py
```

Only owned tests/report changed. Exact ordinary local commit/three hashes
are delivered Mayor immediately; existing untracked state remains preserved.

## R17 same-task 06ac consumer repair confirmation

**All twelve previously sealed CPU stub-arm cases now agree with the conditional
reference.** Exact commit `06ac63380d525d7c292475a3869714e7b2882737` and all
three frozen files were verified byte-for-byte against these hashes:

```text
579163c611d2717af8b0a52cd961c7f36eb516dbcd1c3ca42d3b4cc977bde962  native_campaign_protocol.py
f322a301e1faf034076207bee7b8c2a0f29509a45086ffcf0f05e4c94ec2b495  test_native_campaign_protocol.py
a0bc9e322599e1dac40212aa92d6914ed2d34099c3ee0ecf94f7dcefe9dfcb95  gemini.md
```

`R17ConsumerRepairTests` reuses the unchanged twelve-case fixture and strict
burst/inventory/censor/tag/counter-replay reference, but separately pins and
executes the complete new paired AST. It does not change the historical
5fc/793/c4e source bindings or expectations. Explicit CPU permits, stub arms,
receipt container and import-scoped unused permit constructor remain the only
harness substitutes; no leaf/HTTP/actuator/native execution.

The complete [−11,−9] reference retains conditional margin eligibility.
Original missing burst fate, missing anchor inventory, lost retention,
20% censor and overlap remain non-falsifying. The three deliberately
inconsistent consumer receipts that still falsified under5fc now return
falsificationfalse: nonmonotone counter inconsistent with declared interval,
explicitly mismatched Gateway tag and negative reporter bounds. Known lineage
refusal, pending/not-applied assignment and reversed bounds also remainfalse.
The returned invalid interval can remain visible for diagnostics; a false
falsification flag is not a fabricated valid outcome or an identified effect.

**Qualified only for this bounded caller matrix.** The earlier inconsistent
stub cases were never proof of real-leaf or hardware reachability; the new
consumer guards now exclude them directly. No remaining failure was found in
these twelve cases, and no broader fuzzing, history rerun or blanket source/
clock/ingress/native/statistical/MPC qualification is implied. A conditional
reference pass still requires the preregistered twelve independent randomized
pairs and valid source/provenance/uncertainty before an experimental conclusion.
Mayor's separate static mode-key baselines4A8/8477 are not this controlled
pilot and were not inspected or scored.

**Focused run:2 tests /12 subtests passed, zero skips (0.468s).**
All prior test AST and product bytes are identical to`acc9e55`; source793
and all earlier failure/pass receipts remain historical and unchanged.
`git diff --check` passed. No Native03/Cal artifacts, actual HTTP, GPU/SSH,
Parent edits, forecast/fit/profile or push. H14Source14441/42 and prospective
separately qualified H16owner43/44 remain unchanged; all native/statistical/
MPC permits remainfalse.

Canonical complete same-matrix receipt SHA
`59dc30cd6b7d874670a830cc7133613e7a22459f9747e47db268c5b448b6f536`:

```json
{"active_mpc_permit":false,"actual_http":false,"commit":"06ac63380d525d7c292475a3869714e7b2882737","guard_cases":[{"caller_falsified":false,"case":"counter_mismatch","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":false,"case":"gateway_tag_mismatch","contrast_interval":[-11,-9],"gateway_tag_matches":false,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":false,"case":"lineage_refusal","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":false,"case":"not_applied","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":false,"case":"reversed_bounds","contrast_interval":[-10.0,-10.0],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":false,"case":"negative_bounds","contrast_interval":[-31.0,-29.0],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true}],"native_activity":false,"original_cases":[{"caller_falsified":true,"case":"reference","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":true,"itt_preserved":true},{"caller_falsified":false,"case":"missing_burst_fate","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":false},{"caller_falsified":false,"case":"missing_anchor_inventory","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":false,"case":"lost_assigned_fates","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":false,"case":"excess_censor","contrast_interval":[-11,-9],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true},{"caller_falsified":false,"case":"overlap","contrast_interval":[-30,15],"gateway_tag_matches":true,"guarded_falsified":false,"itt_preserved":true}],"source_hashes":{"gemini_md":"a0bc9e322599e1dac40212aa92d6914ed2d34099c3ee0ecf94f7dcefe9dfcb95","native_campaign_protocol_py":"579163c611d2717af8b0a52cd961c7f36eb516dbcd1c3ca42d3b4cc977bde962","test_native_campaign_protocol_py":"f322a301e1faf034076207bee7b8c2a0f29509a45086ffcf0f05e4c94ec2b495"},"statistical_permit":false}
```

```text
75e559c57b95e3588d5a00617e2faaf57c223906e43b0c3aa06c2a8453001ead  native_experiment_audit.py
270fa208e7662dab08f485f822bdae9ceaee21dd4a1f62e065ae35caec8ab32f  test_native_experiment_audit.py
```

Only owned tests/report changed. Exact ordinary local seal/three hashes are
delivered Mayor immediately, then local park; existing untracked state remains.
