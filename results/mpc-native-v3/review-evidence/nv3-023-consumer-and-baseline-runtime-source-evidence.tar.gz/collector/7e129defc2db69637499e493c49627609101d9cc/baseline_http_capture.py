"""Mode-keyed classification over unchanged Source144 HTTP capture bytes."""
from contextlib import asynccontextmanager
import hashlib
import json
from pathlib import Path

from mpc_lab.http_capture import capture_chat


SOURCE_CAPTURE_SHA = "0648738704771f80470849b0c0beb671d0f17c9dbc75e4095cff155b20d04be7"


class BufferedErrorResponse:
    def __init__(self, response, body):
        self.status_code = response.status_code
        self.headers = response.headers
        self.body = body

    async def aiter_bytes(self):
        yield self.body


async def capture_baseline_chat(client, url, payload, request_id, scheduled_at, *,
                                policy_mode, record=None, **kwargs):
    if policy_mode not in ("protected", "cost_aware"):
        raise ValueError("registered admission mode required")
    error_body = None

    class Client:
        @asynccontextmanager
        async def stream(self, *args, **options):
            nonlocal error_body
            async with client.stream(*args, **options) as response:
                if response.status_code != 503:
                    yield response
                    return
                body = bytearray()
                async for chunk in response.aiter_bytes():
                    body.extend(chunk)
                    if len(body) > 65536:
                        raise ValueError("error_body_limit")
                error_body = bytes(body)
                yield BufferedErrorResponse(response, error_body)

    def classify(row):
        row["source_capture_status"] = row["status"]
        row["source_capture_sha256"] = SOURCE_CAPTURE_SHA
        row["baseline_classifier_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        row["admission_policy_mode"] = policy_mode
        if error_body is not None:
            row["source_503_body_utf8"] = error_body.decode("utf-8", errors="replace")
            row["source_503_body_sha256"] = hashlib.sha256(error_body).hexdigest()
        if (policy_mode == "protected" and row["status"] == "failed"
                and row["http_status"] == 503 and row["response_request_id"] == request_id
                and error_body is not None):
            try:
                body = json.loads(error_body)
            except (ValueError, UnicodeError):
                body = None
            if (isinstance(body, dict)
                    and set(body) == {"detail", "estimated_request_cost", "estimated_input_tokens",
                                     "estimated_output_tokens", "max_admitted_cost", "budget_version"}
                    and body["detail"] == "request rejected: admission capacity exceeded"
                    and body["estimated_request_cost"] == 0
                    and body["estimated_input_tokens"] == body["estimated_output_tokens"] == 0
                    and body["max_admitted_cost"] is None and body["budget_version"] is None):
                row.update(status="rejected", admission_rejection=True, admission=body)
        if record is not None:
            record(row)
        return row

    captured = []
    result = await capture_chat(Client(), url, payload, request_id, scheduled_at,
                                record=lambda row: captured.append(classify(row)), **kwargs)
    return captured[0] if captured else result
