"""Separate natural fixed-count/fixed-cost experiment; never calibrated MPC."""
import argparse
import asyncio
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import random
import socket
import sys
import time
import uuid


ROOT = Path(__file__).resolve().parents[3]
SERVING_SOURCE = "144cef32a9b51c3a74355ff67f5eafdfac6e075f"
GATEWAY_SHA = "a4a8229b0f636b64c945881d062c3ee925ef5fccc5ba2e6fc7629657d3575ea7"
LEGACY_SHA = "78e2c8b91f6b4a582feb69293adff5aa34d4fbd332dfa93b92735bcd0275a069"
OBSERVER_SHA = "77633dc7652066e45b7680d297d3e36ddb97a3e12222de9f526a76b9a01d66b4"
COST_SHA = "cf8162ea687a697d698f26d0bd663fdb9a2f172dce71add05d267ac3dfb43833"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(ROOT / "experiments/mpc-research/native_observer"))
from collect_identification import CELLS, persist, summary, tape_for


def messages(tokenizer, target, words, topic):
    from collect_interventions import messages as legacy_messages
    return legacy_messages(tokenizer, target, words, topic)


@dataclass(frozen=True)
class Policy:
    name: str
    mode: str
    count: int
    cost: int


POLICIES = (
    Policy("fixed-count16", "protected", 16, 32),
    Policy("fixed-count32", "protected", 32, 32),
    Policy("fixed-cost16", "cost_aware", 32, 16),
    Policy("fixed-cost32", "cost_aware", 32, 32),
)


def protocol_for(cost_spec, *, smoke=False):
    episodes = []
    cells = ("p128-m128", "mixed") if smoke else tuple(CELLS)
    seeds = (180004,) if smoke else (181045, 181046, 181047, 181048)
    duration = 12 if smoke else 120
    for block, seed in enumerate(seeds):
        for cell in cells:
            order = list(POLICIES)
            random.Random(f"baseline-order:181045:{cell}").shuffle(order)
            if block % 2:
                order.reverse()
            for policy in order:
                episodes.append(dict(
                    episode_id=f"nv3-baseline-{seed}-{cell}-{policy.name}",
                    seed_block=seed, split="train", cell=cell,
                    policy=policy.name, duration_s=duration))
    return dict(
        schema="native-v3-fixed-baseline-v1", serving_source_commit=SERVING_SOURCE,
        serving_gateway_sha256=GATEWAY_SHA, legacy_collector_sha256=LEGACY_SHA,
        collector_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        observer_sha256=OBSERVER_SHA, cost_spec=cost_spec, smoke=smoke,
        max_waiting=2, shared_upstream_client=False, forced_ignore_eos=False,
        requested_sample_period_s=.1, max_state_age_s=.5,
        ttft_slo_s=.5, tpot_slo_s=.05,
        terminal_scope="Natural EOS, uncapped; all offered IDs retained.",
        hypotheses="Baseline support only; no MPC or superiority permit.",
        episodes=episodes, planned_offered_window_s=len(episodes)*duration,
    )


def validate_protocol(protocol):
    if type(protocol.get("smoke")) is not bool:
        raise ValueError("explicit experiment partition required")
    if protocol != protocol_for(protocol.get("cost_spec"), smoke=protocol["smoke"]):
        raise ValueError("unregistered or changed baseline protocol")
    from mpc_lab.contracts import CostSpec
    if CostSpec(**protocol["cost_spec"]).fingerprint != COST_SHA:
        raise ValueError("public serving cost specification changed")
    if hashlib.sha256(Path(__file__).with_name("collect_identification.py").read_bytes()).hexdigest() != LEGACY_SHA:
        raise ValueError("historical tape/payload/capture helpers changed")
    if hashlib.sha256((ROOT / "gateway.py").read_bytes()).hexdigest() != GATEWAY_SHA:
        raise ValueError("serving Gateway changed")


def gateway_environment(config, policy, evidence, cost_spec):
    environment = dict(os.environ)
    for key in ("MODEL_NAME", "ADMIN_API_KEY", "COST_INTERCEPT", "INPUT_TOKEN_COST",
                "OUTPUT_TOKEN_COST", "MIN_REQUEST_COST", "DEFAULT_MAX_TOKENS"):
        if key in config:
            environment[key] = str(config[key])
    environment.update(
        HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
        PYTHONPATH=str(ROOT), VLLM_URL="http://127.0.0.1:8000",
        ADMISSION_MODE=policy.mode, MAX_IN_FLIGHT=str(policy.count), MAX_WAITING="2",
        MAX_ADMITTED_COST=str(policy.cost), MPC_LAB_ENABLED="false",
        MPC_OWNER_LEDGER_ENABLED="false", BENCHMARK_REQUEST_IDS="1",
        SHARED_UPSTREAM_CLIENT="0", PREFILL_LAB_RAW_COMPLETIONS="0",
        GATEWAY_DIAGNOSTICS="0", LOOP_LAG_TELEMETRY="0",
        TELEMETRY_JSONL=str(evidence / "gateway-telemetry.jsonl"),
        TELEMETRY_STATUS_JSON=str(evidence / "gateway-telemetry-status.json"))
    for key, field in (
        ("COST_INTERCEPT", "intercept"), ("INPUT_TOKEN_COST", "input_per_token"),
        ("OUTPUT_TOKEN_COST", "output_per_token"), ("MIN_REQUEST_COST", "minimum"),
        ("DEFAULT_MAX_TOKENS", "default_max_tokens"),
    ):
        environment[key] = str(cost_spec[field])
    return environment


def policy_metrics(metrics, policy, cost_spec=None):
    if (metrics.get("admission_mode") != policy.mode
            or metrics.get("max_in_flight") != policy.count
            or metrics.get("max_waiting_capacity") != 2
            or metrics.get("initial_admission_budget") != policy.cost
            or metrics.get("admission_budget") != policy.cost
            or metrics.get("budget_version") != 0
            or metrics.get("shared_upstream_client", False) is not False
            or metrics.get("tokenizer_available") is not True):
        raise ValueError("actual static admission policy differs")
    if cost_spec is not None and any(
        metrics.get(key) != cost_spec[field] for key, field in (
            ("cost_intercept", "intercept"), ("input_token_cost", "input_per_token"),
            ("output_token_cost", "output_per_token"))):
        raise ValueError("actual cost arithmetic differs")


def drained(frame, metrics, now):
    at = metrics.get("state_sampled_at")
    if (type(at) not in (int, float) or not 0 <= now-at <= .5
            or frame.get("complete") is not True
            or any(type(frame.get(k)) is not int or frame[k] < 0
                   for k in ("running", "waiting", "orphaned"))):
        return False
    return (metrics["current_in_flight"] == 0 and metrics["current_waiting"] == 0
            and metrics["current_admitted_cost"] == 0
            and not any(frame[k] for k in ("running", "waiting", "orphaned")))


def payloads_for(tokenizer, seed, cell, tape):
    rng = random.Random(f"payloads:{seed}:{cell}")
    cache, payloads = {}, []
    for _ in tape:
        selected = rng.choice(("p128-m256", "p4096-m128")) if cell == "mixed" else cell
        prompt, maximum, _ = CELLS[selected]
        words = rng.choice((28, 32, 36) if maximum == 128 else (65, 80, 95))
        topic = rng.choice(("the solar system", "ocean currents", "photosynthesis", "volcanoes"))
        key = prompt, maximum, words, topic
        if key not in cache:
            cache[key] = messages(tokenizer, prompt, words, topic)
        payloads.append(dict(
            model="Qwen/Qwen3-4B-Instruct-2507", messages=cache[key],
            temperature=0, max_tokens=maximum))
    return payloads


async def run(args, protocol):
    import httpx
    from transformers import AutoTokenizer
    from mpc_lab.http_capture import capture_chat
    from mpc_lab.runtime import local_clock_domain
    validate_protocol(protocol)
    if not args.source_qualified:
        raise ValueError("separate source/runtime qualification required; flag is attestation only")
    with socket.socket() as sock:
        if sock.connect_ex(("127.0.0.1", 8080)) == 0:
            raise ValueError("foreign or prior Gateway active")
    output = args.output.resolve()
    if not output.is_relative_to(ROOT / "results") or output.exists():
        raise ValueError("fresh results directory required")
    output.mkdir(parents=True)
    config = json.loads(args.config.read_text())
    if f";model={config['MODEL_NAME']};" not in protocol["cost_spec"]["tokenizer_identity"]:
        raise ValueError("actual tokenizer/model binding differs")
    tokenizer = AutoTokenizer.from_pretrained(config["MODEL_NAME"], local_files_only=True)
    domain, engine_run = local_clock_domain(), None
    index = dict(
        schema=protocol["schema"], protocol_sha256=hashlib.sha256(args.protocol.read_bytes()).hexdigest(),
        serving_source_commit=SERVING_SOURCE, collector_sha256=protocol["collector_sha256"],
        started_at_utc=datetime.now(timezone.utc).isoformat(),
        clock_domain=domain, calibrated=False, mpc_active=False,
        episodes=[], gateway_epochs=[], actual_offered_window_s=0)
    persist(output / "index.json", index)
    process = None
    async with httpx.AsyncClient(
        base_url="http://127.0.0.1:8080", timeout=30, trust_env=False,
        limits=httpx.Limits(max_connections=None, max_keepalive_connections=100)) as client, \
        httpx.AsyncClient(base_url="http://127.0.0.1:8000", timeout=5, trust_env=False,
                         headers={"x-observer-key": config["ADMIN_API_KEY"]}) as native:
        async def sample(policy, gateway_run):
            nonlocal engine_run
            response = await client.get("/metrics")
            response.raise_for_status()
            metrics = response.json()
            policy_metrics(metrics, policy, protocol["cost_spec"])
            if metrics["telemetry_run_id"] != gateway_run:
                raise ValueError("Gateway epoch changed")
            response = await native.get("/pr33-native/state")
            response.raise_for_status()
            frame = response.json()
            engine_run = engine_run or frame["run_id"]
            now = time.monotonic()
            if (frame["clock_domain"] != domain or frame["run_id"] != engine_run
                    or frame["observer_sha256"] != OBSERVER_SHA
                    or not 0 <= now-frame["sampled_at"] <= .5
                    or not 0 <= frame["frontend_sampled_at"]-frame["sampled_at"] <= .05):
                raise ValueError("native source/clock/freshness changed")
            return dict(native=frame, metrics=metrics, received_at=now)

        async def drain(policy, gateway_run):
            end, checks = time.monotonic()+30, []
            while time.monotonic() < end:
                row = await sample(policy, gateway_run)
                checks = checks+[row] if drained(row["native"], row["metrics"], row["received_at"]) else []
                if len(checks) == 2:
                    return checks
                await asyncio.sleep(.05)
            raise ValueError("physical/Gateway drain not established")

        async def stop_gateway():
            if process is not None and process.returncode is None:
                process.terminate()
                try:
                    await asyncio.wait_for(process.wait(), 15)
                except TimeoutError:
                    process.kill()
                    await process.wait()

        try:
            for spec in protocol["episodes"]:
                policy = next(p for p in POLICIES if p.name == spec["policy"])
                evidence = output / f"gateway-epoch-{len(index['gateway_epochs'])+1:04d}"
                evidence.mkdir()
                with (evidence / "process.log").open("x") as log:
                    process = await asyncio.create_subprocess_exec(
                        sys.executable, "-m", "uvicorn", "gateway:app", "--host", "127.0.0.1",
                        "--port", "8080", "--workers", "1", cwd=ROOT,
                        env=gateway_environment(config, policy, evidence, protocol["cost_spec"]),
                        stdout=log, stderr=asyncio.subprocess.STDOUT)
                index["gateway_epochs"].append(dict(
                    pid=process.pid, evidence=evidence.name, policy=policy.name))
                persist(output / "index.json", index)
                for attempt in range(90):
                    if process.returncode is not None:
                        raise ValueError("owned Gateway exited")
                    try:
                        response = await client.get("/metrics")
                        response.raise_for_status()
                        metrics = response.json()
                        policy_metrics(metrics, policy, protocol["cost_spec"])
                        gateway_run = metrics["telemetry_run_id"]
                        break
                    except httpx.HTTPError:
                        if attempt == 89:
                            raise
                        await asyncio.sleep(1)
                episode = dict(spec, rows=[], samples=[], gateway_run_id=gateway_run)
                episode["initial_drain"] = await drain(policy, gateway_run)
                tape = tape_for(spec["seed_block"], spec["cell"], spec["duration_s"])
                payloads = payloads_for(tokenizer, spec["seed_block"], spec["cell"], tape)
                ids = [uuid.uuid4().hex for _ in tape]
                episode.update(start=time.monotonic()+.5, offered_tape=tape, expected_ids=ids)
                path = output / (spec["episode_id"]+".json")
                persist(path, episode)
                stop = asyncio.Event()
                tasks = []
                with path.with_suffix(".events.jsonl").open("x") as events:
                    last_sync = time.monotonic()
                    def event(kind, value):
                        nonlocal last_sync
                        events.write(json.dumps(dict(kind=kind, value=value), allow_nan=False)+"\n")
                        if time.monotonic()-last_sync >= 1:
                            events.flush()
                            os.fsync(events.fileno())
                            last_sync = time.monotonic()
                    def record(row):
                        episode["rows"].append(row)
                        event("http_outcome", row)
                    async def observe():
                        while not stop.is_set():
                            row = await sample(policy, gateway_run)
                            episode["samples"].append(row)
                            event("state", row)
                            await asyncio.sleep(.1)
                    async def offers():
                        await asyncio.gather(*(capture_chat(
                            client, "/v1/chat/completions", payload, rid, episode["start"]+at,
                            enabled=True, timeout_s=30, record=record)
                            for rid, at, payload in zip(ids, tape, payloads)))
                        await asyncio.sleep(max(0, episode["start"]+spec["duration_s"]-time.monotonic()))
                    tasks = [asyncio.create_task(observe()), asyncio.create_task(offers())]
                    try:
                        done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
                        for task in done:
                            task.result()
                        stop.set()
                        episode["final_drain"] = await drain(policy, gateway_run)
                        if (len(episode["rows"]) != len(ids)
                                or {r["request_id"] for r in episode["rows"]} != set(ids)):
                            raise ValueError("all-offered identity/completeness failed")
                        episode["summary"] = summary(episode["rows"], episode["start"], spec["duration_s"])
                        if episode["summary"]["other"]:
                            raise ValueError("failed HTTP retained; no valid baseline acquisition claim")
                        episode["completed_at"] = time.monotonic()
                        index["episodes"].append(dict(
                            episode_id=spec["episode_id"], artifact=path.name, split="train"))
                        index["actual_offered_window_s"] += spec["duration_s"]
                        print(json.dumps(dict(episode=spec["episode_id"],
                                              valid_seconds=index["actual_offered_window_s"])), flush=True)
                    finally:
                        stop.set()
                        for task in tasks:
                            task.cancel()
                        await asyncio.gather(*tasks, return_exceptions=True)
                        events.flush()
                        os.fsync(events.fileno())
                        persist(path, episode)
                        persist(output / "index.json", index)
                await stop_gateway()
            index["completed"] = True
        except BaseException as exc:
            index["error"] = type(exc).__name__+": "+str(exc)
            raise
        finally:
            await stop_gateway()
            index["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
            persist(output / "index.json", index)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare", action="store_true")
    mode.add_argument("--execute", action="store_true")
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--cost-spec", type=Path)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--config", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--source-qualified", action="store_true")
    args = parser.parse_args()
    if args.prepare:
        if args.cost_spec is None:
            parser.error("--prepare requires public cost specification")
        protocol = protocol_for(json.loads(args.cost_spec.read_text()), smoke=args.smoke)
        validate_protocol(protocol)
        with args.protocol.open("x") as stream:
            json.dump(protocol, stream, indent=2, allow_nan=False)
    else:
        if args.config is None or args.output is None:
            parser.error("--execute requires config and output")
        asyncio.run(run(args, json.loads(args.protocol.read_text())))


if __name__ == "__main__":
    main()
