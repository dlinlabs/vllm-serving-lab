from copy import deepcopy
import importlib.util
from pathlib import Path
import sys
from unittest.mock import patch

import pytest


PATH = Path(__file__).with_name("count_baseline.py")
SPEC = importlib.util.spec_from_file_location("count_baseline", PATH)
module = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = module
SPEC.loader.exec_module(module)


def cost():
    return dict(intercept=.259, input_per_token=.000758, output_per_token=.0052083333,
                minimum=.1, default_max_tokens=128,
                tokenizer_identity="gateway-token-estimate-v1;Qwen3-4B-2507;"
                "model=/root/.cache/huggingface/hub/models--Qwen--Qwen3-4B-Instruct-2507/"
                "snapshots/cdbee75f17c01a7cc42f958dc650907174af0554;"
                "available=True;fallback=chars4-chat-v1")


def test_policies_share_natural_tapes_and_reverse_order_without_relabeling():
    protocol = module.protocol_for(cost())
    module.validate_protocol(protocol)
    assert len(protocol["episodes"]) == 80
    assert protocol["planned_offered_window_s"] == 9600
    for cell in module.CELLS:
        rows = [r for r in protocol["episodes"] if r["cell"] == cell]
        for lo in (0, 8):
            assert [r["policy"] for r in rows[lo:lo+4]] == [r["policy"] for r in rows[lo+4:lo+8]][::-1]
        assert {r["seed_block"] for r in rows} == {181045, 181046, 181047, 181048}
        assert all(r["split"] == "train" for r in rows)
        tape = module.tape_for(181045, cell, 120)
        with patch.object(module, "messages", side_effect=lambda tokenizer, p, w, t: (p, w, t)):
            payloads = [module.payloads_for(object(), 181045, cell, tape) for _ in rows[:4]]
        assert all(p == payloads[0] for p in payloads)
        assert all("ignore_eos" not in p for p in payloads[0])


@pytest.mark.parametrize("mutation", ["waiting", "source", "seed", "slo"])
def test_changed_protocol_refuses_before_execution(mutation):
    protocol = module.protocol_for(cost())
    if mutation == "waiting":
        protocol["max_waiting"] = 3
    elif mutation == "source":
        protocol["serving_source_commit"] = "0"*40
    elif mutation == "seed":
        protocol["episodes"][0]["seed_block"] = 181024
    else:
        protocol["ttft_slo_s"] = 1.
    with pytest.raises(ValueError, match="changed baseline"):
        module.validate_protocol(protocol)


def test_explicit_launcher_does_not_inherit_cost_or_owner_mode(tmp_path):
    with patch.dict(module.os.environ, {"ADMISSION_MODE": "cost_aware", "MAX_IN_FLIGHT": "4",
                                       "MPC_OWNER_LEDGER_ENABLED": "true"}):
        count_env = module.gateway_environment({}, module.POLICIES[0], tmp_path, cost())
        cost_env = module.gateway_environment({}, module.POLICIES[2], tmp_path, cost())
    assert count_env["ADMISSION_MODE"] == "protected"
    assert count_env["MAX_IN_FLIGHT"] == "16"
    assert cost_env["ADMISSION_MODE"] == "cost_aware"
    assert cost_env["MAX_ADMITTED_COST"] == "16"
    assert count_env["MPC_OWNER_LEDGER_ENABLED"] == cost_env["MPC_OWNER_LEDGER_ENABLED"] == "false"
    assert count_env["MAX_WAITING"] == cost_env["MAX_WAITING"] == "2"


def test_policy_and_drain_refuse_wrong_capacity_active_waiter_and_stale_stock():
    metrics = dict(admission_mode="protected", max_in_flight=16, max_waiting_capacity=2,
                   initial_admission_budget=32, admission_budget=32, budget_version=0,
                   tokenizer_available=True, current_in_flight=0, current_waiting=0,
                   current_admitted_cost=0, state_sampled_at=10.)
    frame = dict(complete=True, running=0, waiting=0, orphaned=0)
    module.policy_metrics(metrics, module.POLICIES[0])
    assert module.drained(frame, metrics, 10.1)
    changed = deepcopy(metrics)
    changed["current_waiting"] = 1
    assert not module.drained(frame, changed, 10.1)
    assert not module.drained(frame, metrics, 11.)
    changed["max_in_flight"] = 32
    with pytest.raises(ValueError, match="static admission"):
        module.policy_metrics(changed, module.POLICIES[0])
    with pytest.raises(ValueError, match="cost arithmetic"):
        module.policy_metrics(metrics, module.POLICIES[0], cost())


@pytest.mark.parametrize("count", [16, 32])
def test_actual_gateway_enforces_count_with_two_waiters_and_ignores_cost(monkeypatch, tmp_path, count):
    import asyncio
    asyncio.run(actual_gateway_count(monkeypatch, tmp_path, count))


async def actual_gateway_count(monkeypatch, tmp_path, count):
    import asyncio
    from types import SimpleNamespace
    policy = next(p for p in module.POLICIES if p.mode == "protected" and p.count == count)
    for key, value in module.gateway_environment({}, policy, tmp_path, cost()).items():
        monkeypatch.setenv(key, value)
    monkeypatch.setitem(sys.modules, "transformers", SimpleNamespace(
        AutoTokenizer=SimpleNamespace(from_pretrained=lambda *a, **k: object())))
    spec = importlib.util.spec_from_file_location("actual_fixed_gateway", module.ROOT / "gateway.py")
    gateway = importlib.util.module_from_spec(spec)
    monkeypatch.setitem(sys.modules, spec.name, gateway)
    spec.loader.exec_module(gateway)
    tasks = [asyncio.create_task(gateway.begin_request(100000., False))
             for _ in range(count+4)]
    try:
        for _ in range(3):
            await asyncio.sleep(0)
        assert gateway.state["current_in_flight"] == count
        assert gateway.state["current_waiting"] == 2
        assert gateway.state["rejected_requests"] == 2
        assert sum(t.done() and t.result().accepted for t in tasks) == count
        for task in tasks:
            if not task.done():
                task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        for _ in range(count):
            await gateway.finish_request(100000.)
        metrics = await gateway.snapshot_metrics()
        module.policy_metrics(metrics, policy)
        assert metrics["current_in_flight"] == metrics["current_waiting"] == 0
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
