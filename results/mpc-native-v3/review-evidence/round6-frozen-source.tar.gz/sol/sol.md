# Sol NV3 independent round 1: identifiable outcomes before predictive control

## Status and evidence boundary

Independent proposal and bounded offline audit, not a new synthetic benchmark,
native model fit, ten-hour receipt, qualification pass, or MPC win. No NV3 peer
proposal was read. Scope is this report and its sibling
`native_experiment_audit.py` / `test_native_experiment_audit.py` only.
No Gateway, observer, core, configuration, remote, or GPU change.
Mayor owns Beads, SSH, execution, and paid-resource decisions.

Read campaign at base `10f2fb0`, native-v2
`decision-and-next-native-protocol.zh-TW.md`, my previous
`round3/sol-revision.md`, actual
`../native-identification-and-model-falsification.zh-TW.md`,
`prefill_lab/contracts.py`, and the native-v2 collector.
The serial HTTP-service interpretation remains falsified: the old empty-start
90s arm delivered 2449 natural completions against that model's upper bound
2004. That does not falsify predictive control or all queueing models.
The old commit-progress model did not beat persistence consistently and used
realized sampling gaps, not fixed future horizons.

Mayor's shared new observation is treated as reported native evidence, not
reproduced locally: exact joined UUID, prompt4096/output32/natural EOS; 34
physical steps, two prefill and 32 decode; contiguous executed end4128 versus
delivered input minimum4127. The final placeholder was1, its host forward
wrapper started before EOS and output commit followed EOS, with a matched
executed CUDA forward. The v2 audit is still FALSE. No local raw capture for
this new observation was supplied; the executable test reproduces the
accounting case with explicitly artificial timestamps, not native timing.

Authorized deployment is the sole user Pod RTX4090/24564MiB/driver595.91.07,
vLLM0.30.0, Torch2.13.0, Transformers5.22.1 and restored pinned Qwen4B.
These shared environment facts are not a loaded-revision or performance
attestation. Final heldout160021-160024 is not read, fitted, or evaluated.

## 1. Observable batch state and transition

Use a receipt-cut history, not a claimed fully observed GPU Markov state.
At origin k retain:

| Component | Available state and provenance | Unresolved part |
|---|---|---|
| Admission | Exact UUID/original-cost ledger; pending/applied cap version; command fence; receipt timestamp | Accepted but unmatched native work stays explicitly unknown |
| Queue | Prompt tokens and recipe, admission age, waiting/admitted-not-first bins | Scheduler order not inferred from HTTP residence |
| Decode | Joined physical request, delivered output so far, context/progress bins, most recent batch participation | Residual output/EOS and pending physical work remain latent |
| Batch history | Last received prefill query-token/chunk-size distribution, decoder/context distribution, placeholder count if observable | Post-drain execution spans are labels, not live features |
| Capture health | Source/epoch/clock, dropped/pending/overflow flags, receipt age/width | Missing values are not zero workload |
| Environment | Receipt-qualified runtime identity and available temperature/clock timeline | Old/partial NVML is not complete environmental control |

Costs16/32 are whole-request reservation budgets, NOT concurrency, scheduler
token limits, or KV bytes. Exact transitions retain old costs on cap reduction:

```
R_next = R + sum(actual admitted original costs) - sum(actual released original costs)
admit only when R + original_cost <= actually_applied_cap
```

No extra overshoot allowance and no forced eviction when `R > reduced_cap`.
Engine EOS, HTTP terminal, output commit, and ledger release remain separate
events. Use native host timestamps only within their qualified domain; join
client/native clocks by exact identity and receipt brackets, not subtraction.

Predict the distribution of cost release, first-content deadline passage,
natural complete-good count, physical progress, and tail incidence jointly
conditioned on this history and a supported assigned cap program. A bounded
stratified/regularized direct response model is the first candidate; a
batch-aware semi-Markov extension is warranted only if phase/history ablation
improves block-held-out forecasts. This report does not implement or fit either.
Latent EOS/tail uncertainty is retained rather than assigning every output
token a deterministic exclusive-service coefficient.

## 2. Useful, physical, and tail-work accounting

Keep the v2 `audit_capture` untouched, including its equality failure. A new
versioned descriptive ledger can reconcile without retrospectively passing it:

* **Delivered-useful input minimum**: `prompt + delivered_output - 1` under the
  declared no-cache/no-speculation protocol. This is a token-position minimum,
  not measured GPU demand or exclusive service duration.
* **Physical input work**: contiguous, exact matched scheduler/worker input
  positions/counts with resolved executed CUDA forward evidence. Preserve
  all34 steps and their identity; do not delete the final step.
* **Undelivered tail input**: physical positions beyond that minimum, with
  request/step evidence that no delivered output came from that work. A
  placeholder alone is insufficient. Label unexplained excess as failed,
  not generic "async tolerance."

The bounded `work_accounting` diagnostic supports only the shared
one-placeholder extra-input case: exact single extra position, matched
execution, native host clock, forward wrapper start before EOS, commit at/after
EOS, and independently determined no delivered output from that step.
It outputs4127/4128/1 and `old_final_progress_equal=False` for the structural
fixture, with qualification explicitly false. Extra/gapped/replayed/unmatched
work fails closed. Those timestamps do NOT place GPU execution on the host
clock: GPUelapsed is a relative current-stream span, not an absolute clock,
other-stream coverage, or complete sampling/transport service.

Mayor's future adapter must retain raw scheduler and worker rows, verify
actual_tokens/counts/positions, EOS/output mapping, step digest and worker/run
identity before normalization. Caller-provided booleans are attestations, not
independently verified native joins. OFF captures without step evidence can
qualify outcomes but cannot qualify this physical ledger.

Falsification experiments, not relaxed acceptance:

1. Repeat natural EOS with different actual output lengths, prompt lengths
   and observed batch compositions. Predict zero/one tail incidence before
   seeing labels; distinguish useful decode steps from physical decode steps.
2. Include mixed prefill/decode and pending-async cases. Test whether excess
   is always the last one-placeholder input or sometimes an earlier/multi-step
   phenomenon; the latter invalidates this bounded reconciliation contract.
3. Stop/abort/length-finish controls remain separate cohorts. Their drain work
   must not be mislabeled as natural EOS or dropped from costs.
4. Independently verify no repeated/gapped positions, no mismatched actual
   worker counts, and executed versus merely scheduled extra work. Deep-trace
   confirmation in a separate diagnostic epoch may qualify execution scope,
   but does not establish unprofiled timing or observer equivalence.

## 3. Response, uncertainty, and full-offered outcomes

Freeze every offered logical ID, physical HTTP-attempt UUID, prompt recipe
SHA, prompt/output limits, scheduled origin and window before execution.
Each physical attempt occurs once globally; identical logical trace IDs across
paired arms are intentional. Do not reoffer after ambiguous BEGIN/POST.
Retain a terminal/censor row for every offer; missing/extra/duplicate rows fail
the audit rather than improving a conditional denominator.

Natural complete-good requires positive integer output, exact successful Chat
UUID, complete non-error stream, finite ordered same-client-clock chronology,
matching prompt/limits, stop reason plus independent native EOS evidence,
scheduled-origin TTFT<=0.5s and request-mean
`(terminal-first)/(output-1)<=0.05s`; one token has TPOT0.
Last chunk is NOT substituted for terminal. Token-gap/P99 claims are absent.
Length-finished outputs are labeled truncated and count0 for this frozen
natural-complete primary outcome; report their complete response counts
separately rather than discarding them. Reject/error/cancel/client timeout
count0. Timeout is a resolved HTTP failure, not proof the engine drained:
physical-work and release labels may remain censored.

Right-censoring yields lower/upper good-count bounds, not assumed success or
imputed native completion. A first token already past TTFT has upper0.
Otherwise conservative upper1 is retained. Report late drain completions in
the original offered cohort; dividing cohort good by its offered window is
not a steady-state capacity claim.

Joint predictive uncertainty should use whole held-out block trajectories,
not independent token/request residuals. Fit on Train; choose features on
grouped Train folds; calibrate on disjoint Calibration blocks; select policy
and continuation only on Development. Report empirical coverage and miss
rates with the block count, not certified chance constraints.

## 4. One-step, multi-step, action ranking, and OOD evaluation

Log forecasts at fixed origins before labels exist, with source hash, model
hash, feature receipt cut, plan, and prediction publication time. Do not input
realized future sampling gaps, final output lengths, post-drain spans, future
offered tapes, or outcomes of paired counterfactual arms.

Primary predictive endpoint: then-live cumulative original-cost release at
1/3/5s, normalized by positive origin reservation and averaged per independent
block. Zero-reservation origins are a separate stratum. Secondary: natural-good
count errors, deadline Brier/reliability, physical/tail incidence, joint
trajectory coverage and ranking of actually supported plans. Predicting token
progress well does not establish release accuracy or control goodput.

Compare ledger/history-only, persistence, hold-current empirical response and
batch-history extension under identical origins and labels. Publish one-step
and free-running multi-step errors separately; do not feed actual intermediate
states to a purported multi-step rollout. Assess calibration before maximizing
over plans, because ranking/selection can exploit model error.

OOD: withheld prompt/output combinations, unseen mixture/order, burst and
recovery, accepted-unmatched work, altered observer source/epoch and available
thermal/clock shifts. Bounds must come from qualified Train/Calibration support,
not invented KV thresholds. Abstain on missing identity, stale/unknown work,
unseen history/action support, unresolved labels or capture overflow.
Reject fitting if supported binding states are too few; state aliasing is a
measurable limitation, not a reason to invent latent features.

## 5. Strong One-move versus MPC, causal support, safe deployment

Only after model qualification, compare Fixed16, development-selected
best-supported-fixed, development-selected reactive, strong One-move, and MPC.
One-move and MPC share 5s forecast window, same uncertainty trajectories,
future-arrival LAW (not realized tape), constraints, tail scoring, control
frequency, and development-frozen continuation. One-move frees its first move;
MPC may free two/three future moves only where sequence support exists.
Both apply just their first move and replan at the same rate. No deliberately
poor Fixed16 continuation or short-window straw baseline.

First run randomized open-loop LL/LH/HL/HH cap16/32 sequences from verified
drained starts, paired common offered tapes within fresh independent workload
blocks, randomized arm order with washout/drain and exact application fences.
Include literal-disabled/enabled-OFF/LIGHT ablations in separate service
epochs and same-action repeats. Repeats estimate within-block EOS/observer
variation, NOT independent seeds. Actual batch composition is a mediator:
randomized nominal bursts do not make a batch-duration causal coefficient.
Sequence ITT effects do not license rolling same-state counterfactuals after
states have diverged; unsupported policy plans remain masked.

Before closed-loop outcomes: freeze configuration hashes, metric, contrasts,
minimum useful effect, independent-block sampling and randomization, handling
of censoring, multiplicity and precision plan from Development variance.
The paired module estimates equal-block right-minus-left natural-good/window,
block-resampled approximate percentile95% CI and exact two-sided block
sign-flip p for a sharp no-effect null under the stated exchangeability design.
This exact enumeration specifically requires independent fair pair-order
coins and no carryover/order-by-policy effect after qualified washout. A
balanced/constrained randomization has a different assignment space and must
not be passed to this routine as independent flips.
It rejects cloned block/seed/randomization unit, repeated logical tapes,
physical UUID reuse, mismatched paired tapes/windows/SLOs, changed frozen
comparison configuration and unrandomized declarations. It withholds CI/p
whenever any offered outcome is censored.

These are guards against obvious pseudoreplication, NOT proof of physical
independence, random assignment, or truthful provenance. Mayor must verify raw
receipts and actual independent block generation. Equal synthetic effects can
produce a degenerate bootstrap interval; it is not a variance or significance
guarantee. Four independent pairs have minimum two-sided exact p0.125, not
0.05. No "superior", "equivalent", or "MPC impossible" classifier exists.
The exact sign-flip routine intentionally caps at16 blocks; a larger frozen
final protocol needs a separately reviewed inference implementation, not
splitting into batches or silently treating approximate p as exact.
Do not take this exploratory pairwise p as multiplicity-adjusted evidence for
winning against all baselines.

Report offered/accept/reject/failure/natural/truncated/censored counts, SLO
quantiles, tail work, action binding incidence, affected offered mass, ranking
errors, full observation-to-solve-to-persist-to-POST-to-fence cost, deadline
fallback, oscillation and recovery. Small first-action disagreement is not a
bound on benefit without affected mass and outcome consequences.

No deployment authority from this module. Candidate first runs shadow-only,
then a separately permitted bounded trial with rollback to the best
development-supported fixed/reactive policy. Keep existing expiry, memory,
timeout, observation completeness and source fences. Unknown work or OOD
invokes qualified fallback; lowering cap does not evict old reservations.
Uncalibrated KV/joint risk is not declared hard-safe. Mayor alone runs GPU/API
work and manages paid time; no claimed ten-hour elapsed experiment or quote.

## Local source/test receipt

Owned directory: `experiments/mpc-research/native-v3/`.
Exact implementation/test SHA256:

```
6abb94a4fbc1f3e238cd2d4687e996829304afe669b38efba14f2ca29074a554  native_experiment_audit.py
da6705c687e8d4fa8aa3df072e751f6c141d1f300e4d9eb5f374b51c289ee96e  test_native_experiment_audit.py
```

Executed local command:

```
python3 -m unittest discover -s experiments/mpc-research/native-v3 \
  -p test_native_experiment_audit.py -v
```

Result: **15 tests passed**, CPython3.14.4; outcome, clone/leakage,
randomization, exact four-block p floor, censored inference, and physical
tail counterexamples. These are standard-library CPU unit tests, not native
measurements. `python` was absent and `python3 -m pytest` reported missing
pytest, so the existing unittest-compatible tests were run with the built-in
runner without installing or changing dependencies.

Full Linux CPU acceptance was not executed: it requires CPython3.12, a clean
checkout and local port checks; this assigned offline scope forbids socket
exploration and includes pre-existing untracked `.beads/` / `.runtime/`.
No full-suite, lint-tool, GPU, deployment or statistical qualification claim.
Those pre-existing paths remain untouched. Only the three owned files are
staged for a local commit with the Copilot trailer, retained for Mayor review.
Mayor can retrieve its exact commit from this branch's HEAD and independently
check the recorded implementation/test hashes. Bead status is not mutated:
Mayor retains in_progress for peer review.

Persistence receipt: the environment automatically checkpointed the owned
source/tests/report before the explicit commit attempt; that attempt found
nothing staged. Verified checkpoint
`c8ef4ce06a36d381882ecf68799913855923bcde` contains the exact source/test hashes
above and matches the worktree. This receipt update is committed separately
with the required Copilot trailer; existing automatic commits are not amended.

## Round 2: frozen-peer review and owned surgical corrections

### Evidence update and review boundary

Read all three frozen reports, complete implementations and focused tests,
not just their passing receipts. Reviewed R1 commits:
Opus `17f62c71aadd8fdcea8d017498ce34fdb13e08cc`,
Astra `a51404649e5fcec8338720371abc3d842ebd5b7b`,
Gemini `4c53d40ed7a8300a0d5eb8c1b0b5ab590d503e15`.
The replay helper verifies all six source/test SHA256s before importing them;
it never patches or writes peer files. Findings refer to those frozen bytes,
not a peer's later repair. No new experiment or peer agreement is invented.

Mayor now reports actual qualification at `2587d2b`:16 executed arms,
40 HTTP complete,40 natural EOS, all16 v3 audits valid,8 old v2 audits FALSE
retained,20 explicit tail tokens. Accept this as **reported capture/HTTP/drain
qualification**, superseding the R1 "not yet qualified" status at that time.
I did not rerun it or inspect the separate Mayor accounting implementation.
It is NOT prediction, MPC, observer-overhead, absolute GPU-clock, exclusive
service, independent efficacy, or ten-hour qualification.

In the tables, `Opus`, `Astra`, `Gemini` source abbreviations mean respectively
`native_release_model.py`, `native_response_planner.py`,
`native_campaign_protocol.py` in their frozen artifacts. Replay output contains
15 named counterexample groups; bool-output and post chronology are two
distinct cases grouped in one result.

### Opus: useful response candidate, incomplete qualification

| Source | Finding / reproduced witness | Disposition |
|---|---|---|
| `Opus:72`, `_native` | Adding foreign native clock and run IDs to every otherwise valid frame still produces origins. Gateway identity is checked; native clock/epoch/source is not. | Reject the report's same-run/same-clock qualification claim for this parser. Require actual native provenance before feature availability or any cross-domain arithmetic. |
| `Opus:169`, `ledger_releases` | Change a release effective time to -100 while the mark remains live at origin0: dataset truth is still `(1,1)` released by1s. Sequence conservation does not enforce event-time chronology or release-after-admit. `_marks:49` also does not require positive prompt count or first-after-admit. | A negative/retroactive release is not exact ground truth. Preserve the failure; require monotonic effective times and consistent snapshot/event brackets. |
| `Opus:93`, `_planned_budget` | Plans L-at0/H-at.5/L-at1 and H-at0/L-at.5/L-at1 have identical averaged cap features at1/3/5s:24,18.6667,17.6. | Order-dependent responses cannot be distinguished by these plan features. This is a representational alias, not proof that their native outcomes differ. Keep assigned sequence/order features or abstain if a native contrast separates them. |
| `Opus:320-331`, support envelope | Two-short and two-long homogeneous Train origins admit an unobserved short+long mixture with `ood_reasons=[]`. Marginal ranges and a set of individual shapes are not joint mixture/history/sequence support. | Reject "never extrapolate outside Train support" as a general guarantee. Report the actual envelope and test joint-support failures separately. |
| `Opus:460`, calibration | With the same two Calibration blocks, repeat origins of the positive-residual block20 times: lower band changes from-.5 to+.5. No independent block was added. | It pools origin residuals, not block residuals. This is not block-balanced calibration or a split-conformal guarantee. Freeze cadence/weighting and use block trajectory scores for a block-level claim. |
| `Opus:523`, tail accounting | The peer's baseline fixture returns `tail_accounted=True` without CUDA resolution, placeholder, clock or output-commit/discard evidence. Duplicate worker keys are also collapsed into a dict. | Counts/positions and schedule-before-finish are necessary but do not prove the asserted executed/discarded tail mechanism. Do not promote this thin accounting flag into raw native qualification. |

Accept the Train-only fit and reserved-final seed guard, equal-block evaluation,
whole-origin-cost bounds, exact cost-tie ambiguity rather than invented UUID
release assignment, and explicit absence of native/MPC acceptance. The stable
sigmoid is preferable to naïve exponentiation. However, the Newton fitter has
no reported convergence/conditioning certificate; model predictions still
need finite/convergence diagnostics on actual Train data. Fitting pooled
origin/mark rows is not independent-block fitting simply because final scores
are aggregated by block.

Per-horizon mean release forecasts are not a joint stochastic transition
kernel. Three-offset cummax is useful monotonicity, not calibrated whole-cost
trajectory scenarios. A time-average cap coefficient is not a causal slope,
especially after differently assigned histories diverge. Passing individual
shape/range checks does not qualify new rolling MPC sequences.

### Astra: strongest interface boundaries, still not an adapter or model

| Source | Finding / review | Disposition |
|---|---|---|
| `Astra:212`, state validator | A known decode mark with `native_running=0` still gives `status="shadow"` under the peer's stub, with `active_permit=False`. There is no consistency check between native counts and marked native stages. | Reproducible adapter-validation gap, not an active-actuation exploit. An atomically joined physical prefix must reconcile stages/counts; if timestamps make the relationship uncertain, retain unknown work and abstain. |
| `Astra:248,276` | IDs bind supplied objects and aggregate counts, not loaded source/revision, received history, raw natural-EOS outcomes, support, or calibrated uncertainty. | Accept the explicit external-artifact boundary. Nonempty receipt IDs are not independently verified attestations; the future adapter/model owner must audit them. |
| `Astra:326` | Six calls and checks before/after callbacks do not preempt a hung callback. Planner elapsed excludes upstream observation/features and downstream persist/POST/fence. The report explicitly says so. | Accept this limitation; do not claim a native100ms/full-path runtime guarantee. Deadline origin, watchdog and last-moment epoch/version recheck remain deployment prerequisites. |

Accept exact whole-cost admission/release, preserving reservations on a cap
drop, shared immutable evaluation/scenario pairing, original-ID release sets,
tail-versus-model-error separation, missing-plan abstention, strong common
continuation and always-inactive permit. No new synthetic plant is hidden
behind the planner. Bounds are reporting envelopes, not proven risk limits.

Important mathematical boundary: the one-prefix and two-prefix families start
the same reactive continuation at different times and are not automatically
nested. Even with exact forecasts, open-loop two-move value is not a theorem
about gain when both algorithms replan every second. Keeping One-move for the
same first action is reasonable; empirical closed-loop gain still requires
randomized full algorithms. The planner's actual model/support/OOD behavior
is delegated to `predict`, not implemented by its string IDs. I do not claim
this interface already predicts or enforces native KV safety.

### Gemini: reject the implemented superiority/campaign claims

| Source | Finding / reproduced witness | Disposition |
|---|---|---|
| `Gemini:120`, work accounting | It converts exclusive forward end4128 into4129 physical positions, and `P+O-1` into `P+O` "useful" work. End100 clips missing useful work to tail0 while returning the same placeholder-cause string. | Off-by-one and missing-work concealment. A scalar endpoint/default constant cannot validate contiguous worker steps or a CUDA/EOS mechanism. Correct shared count is4127 minimum/4128 physical/1 tail. |
| `Gemini:172`, clock semantics | `active_concurrent_requests=2` alone sets serial-model-falsified. Two simultaneous HTTP offers can queue behind valid serial .1s service intervals `[0,.1]`, `[.1,.2]`; residence .1/.2 includes waiting. | Retain the actual old drained-start capacity falsification, not this generic concurrency test. Aggregate elapsed cannot establish GPU/host order or exclusive per-request demand. |
| `Gemini:232`, outcome validator | Both boolean output and a POST at100 after first10.1/terminal10.12 are scored good. `stop` alone does not audit a complete exact-UUID native-EOS response. | Zero and NaN fixes are insufficient: strict integer type, POST chronology, full stream/UUID/EOS joins and explicit full-offered censoring remain necessary. |
| `Gemini:488`, ledger | Admit the same cost8 record twice, release once: reserved8 with zero live marks. Mutable records can also change the cost subsequently subtracted. | Fails UUID uniqueness/original-cost conservation. Do not mask negative/corrupt releases with `max(0,...)`; retain immutable admission costs and fail on duplicate/reuse. |
| `Gemini:319,344`, evaluator | Four distinct-ID aggregates with offered1 but10–25 good completions, `min_blocks=4`, one Monte Carlo draw return `CONFIRMED_SUPERIOR`, p0. Exact four-pair floor is.125. | Aggregate counts are not validated against raw offers. Monte Carlo p0 is not an exact p or defensible superiority receipt. Default6 is not power, and configurable minima are not independent sampling proof. |
| `Gemini:344`, statistical claims | Zero variance is called artificial replication; no CI or Holm implementation exists in the complete source. Mean>=margin plus a zero-effect p does not establish a statistically supported minimum practical effect. | Equal independently generated differences can be genuine. Identify blocks/physical provenance rather than rejecting all equal outcomes. Freeze contrasts/multiplicity and distinguish null0 from a useful-effect margin. |
| `Gemini:640,653`, comparators | "MPC" returns the same cap32 for horizon1 or5; both horizon and One-move continuation parameters are unused in decisions. Functions contain backlog heuristics, no forecast/sequence objective. | Reject these labels as implementations of strong One-move/MPC. Merely returning16/32 does not test predictive control or a fair common continuation. |
| `Gemini:737`, duration | With offered duration0 and maximum drain120, all320 schedules are empty but hours_requirement_satisfied=True at10.6667h. Default offered time is only8h; the remaining2.6667h is maximum drain. | Planning capacity is not actual informative duration. This output cannot satisfy the user's actual>=10h requirement or account for execution, setup, idle, failures or real drain. |

Further source-based limits: the purported immutable protocol is a mutable
dict with a stored hash, no later verification/freeze enforcement. Episode
tape keys are not emitted frozen arrival/prompt contents or physical UUIDs.
Mixed/burst/shift descriptions/rates do not become executable mixture/arrival
laws in the generated episodes. The same `unseen_ood_mix`2048/384 shape is
included in Train and Final; that alone is not withheld-shape OOD. No actual
state-support validator or OOD abstention precedes the heuristic decisions.
Calling Fixed16 "safe" without current epoch/expiry/unknown-tail/recovery
evidence is unsupported; lowering cap never evicts old costs. Unsupported24
in a best-fixed example needs fresh action qualification, not promotion from
the16/32 grid. Nominal6req/s is not measured120% native capacity.
These flaws do not imply that predictive control is impossible.

### Owned Sol corrections and limits retained

The replay also confirmed two defects in my frozen R1:

1. Four positive effects scaled to1e-15 give p1 instead of.125 because of the
   absolute1e-12 comparison tolerance. Round2 enumerates sign swaps using exact
   `Fraction(count_difference)/Fraction(recorded_window)` sums; effect/CI
   reporting remains floating point. This preserves ties and scale invariance
   for the declared input numbers, without making independence a theorem.
2. Interpolating between -1e308/+1e308 overflows their difference: frozen R1
   emits `[inf,inf]`. Round2 uses convex weighted interpolation; the adversarial
   test selects both endpoints and now requires finite intervals.

Also require an explicit common partition before paired analysis, reject the
reserved old final seeds before reading outcomes, reject oversized nonfinite
integer timestamps as ValueError, and require per-request host forward starts
not to regress or begin at/after natural EOS. The last rule is a conservative
host-order consistency gate, NOT a GPU execution-before-EOS assertion.
No other path, old audit, peer source, controller or native collector changed.

Remaining limitations are intentional and explicit: declared independence,
pair randomization/config hashes and `native_eos_verified` do not authenticate
raw events by themselves. Missing rows fail; censoring withholds inference;
bootstrap95% is approximate and can degenerate for genuine equal effects.
The exact null concerns zero effect under independent fair label/order swaps
and qualified no-carryover, not equivalence, power, useful-margin proof or
joint superiority against five baselines. Larger/constrained assignment
spaces need a separately frozen analysis. This module has no actuation permit.

### Unresolved disagreements and discriminating native experiments

| Question | Discriminating experiment / required outcome |
|---|---|
| Does one-placeholder accounting explain all qualified natural cases? | Keep all raw steps/EOS/commit lineage in short/long/mixed repeats and cancel/length controls. Test extra0/1/multiple positions, post-EOS launches and duplicate/gapped/unresolved workers. A generic+1 allowance is not an explanation. |
| Does cap order matter beyond its1/3/5s average? | Randomize the equal-average LH/HL first-second pair with identical origin/tape and common continuation. Publish release/good forecasts before outcomes. If responses separate by order, average-only plan features are falsified; if not, report precision, not universal equivalence. |
| Can marginal feature boxes qualify mixtures? | Train on homogeneous short/long, withhold mixtures and burst/recovery histories. Log support flags and block-held-out release/count/ranking errors plus abstention coverage. This tests the demonstrated accepted-unseen-mixture alias. |
| Are calibration bands stable under cadence/blocks? | On the same sealed data, change offline origin sampling cadence without adding blocks; compare origin-pooled and whole-block trajectory calibration, then evaluate fresh independent Calibration/Development blocks. No extra GPU time is needed for the resampling diagnostic. |
| Are count/stage/tail observations complete at the decision cut? | Join Gateway/native snapshots by exact IDs and recorded receipt brackets; replay delayed observation, accepted-not-visible, cap-drop and reservation-empty-but-pending-forward cases. Count/stage conflicts must become unknown/abstain, not fabricated fully observed state. |
| Does extra planning improve actual closed-loop outcomes? | After model/continuation support, randomize complete strong One-move/MPC algorithms at the same cadence, law, horizon/tail, offered cohort and full-path runtime cost. Report binding mass, policy disagreement consequences and independent block effects, not the stub's open-loop scores. |
| Has informative native experimentation actually reached10h? | Maintain actual start/end/clock/epoch/source-linked intervention and executed-drain receipts, union overlapping intervals on the sole GPU and retain invalid arms. Separate actual experiment duration, GPU span labels, setup, idle and billing time. Planned schedules/max drain alone are never added as executed time. |

Mayor alone executes these interventions. Current16-arm capture qualification
does not answer these model, observer, causal, precision, duration or deployment
questions. No physical decomposition or elaborate predictor is accepted by
consensus, and no peer's passing unit suite supplies missing native evidence.

### Round2 source/test receipt

Final owned implementation/test SHA256s:

```
44423a5d76782da9d9118ddacbdb94e82d6963b70a65dfdf95d4e82d5487251d  native_experiment_audit.py
336d298fdc766618e126ce19c952ee1ccb3057f061041a575d07d6e53aeb6bf6  test_native_experiment_audit.py
```

Executed `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover
-s experiments/mpc-research/native-v3 -p test_native_experiment_audit.py -v`:
**19 tests passed**, no skips. Separately, all15 named peer witness groups and
all six frozen source/test digests verified successfully:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=experiments/mpc-research/native-v3 \
python3 -c 'import json,sys; from test_native_experiment_audit import peer_counterexamples; print(json.dumps(peer_counterexamples(sys.argv[1]), sort_keys=True, indent=2, allow_nan=False))' \
  /path/to/pr33-native-v3-round1-frozen
```

Executed against Mayor's supplied frozen directory. Portable unit tests do not
require that external archive; the pinned-peer replay deliberately does.
The two numerical regression cases were separately run against frozen Sol R1
and produced p1 / `[inf,inf]`, so they are not tests that only restate the fix.
All reproduction is CPU contract evidence, not new native performance.
Local commit only; Mayor retains in_progress for peer review.

## Round 3: actual comparison binding and individual peer responses

### Frozen evidence and corrected native facts

Read all other R2 reports and their actual source/tests. Reviewed commits:
Opus `fb7e517904bc001802010271972954198a8532f2`,
Astra `d0ad27503f1b7a59bffaadebcffcafa0ceff7715`,
Gemini `c04cd0ab1265fc97930d63e8692a30a3504bf0e8`.
The new `round3_counterexamples` verifies eight frozen R2 source/test digests,
including my own R2, before executing thirteen named CPU witnesses. These are
reproducible contract findings, not a consensus or native performance result.

Mayor's correction is decisive: of the forty qualifier requests, only twenty
LIGHT requests have physical GPU-work labels, and all twenty have one overhang.
The twenty OFF requests have **no physical tail measurement**, not zero tail.
Thus twenty tail tokens divided by forty HTTP completions is neither a tail
probability of0.5 nor evidence of stochastic zero/one variation. The sixteen
arms/forty HTTP/natural EOS qualification at native source `2587d2b` establishes
capture/HTTP/drain, not a universal one-token mechanism or MPC benefit.
The old v2 failures remain preserved; GPU elapsed is not an absolute timestamp
or an exclusive service duration.

Additional Mayor-reported execution facts, not independently rerun here:
controlled `87` smoke922 offered/648 EOS/274 rejected/48s; managed `6c`
smoke922 offered/650 EOS/272 rejected/48s, two Gateway epochs, cleanup verified.
The long `6c` driver is running;400x120 offered windows/48000 planned seconds
do not establish ten actual experimental hours. Native source is `2587`,
collector/Gateway `6c`, core unchanged. The operation cache is **in memory**,
rollover occurs every two episodes/one paired cell, and the1024 ceiling is
unchanged without relaxation or eviction. Gateway run ID changes at rollover;
the same Pod boot/time namespace retains the same ClockDomain.

First-Train diagnostics reported by Mayor:765 strict receipt-joined frames;
3034/13280 mark observations are accepted-but-not-native-visible even after
canonical ID normalization. This is a mark-observation count, not an origin
abstention rate, independent sample size, or forecast error. Full joint data
availability does not imply all physical work is visible. The established
`state_sample.join_observations` and `native_prediction.native_running` use
exact fullmatch of native `chatcmpl-<32hex>-<8hex>` IDs and their Gateway32hex
canonical identity; naive equality and substring matching are invalid adapters.
Online availability uses receipt stamps, not retrospective event knowledge.
Gateway `scheduled_at=None` cannot serve as my HTTP offered-origin timestamp.

Individual-episode inspection was limited to the first Train181001 artifact's
identity/schema and byte digest, without fitting, joining or requalifying its765 frames:
`nv3-181001-p128-m128-arm0.json`,
SHA256 `d633b4e402e453238b0d612b3b64c198d61fe572eb9c3b171cbb76a616187c23`.
No Calibration/Validation/Final outcome was read or tuned against in R3;
Train181001..181016 is the authorized diagnostic range and old
Final160021..160024 remains unused.

### Additional first-Train descriptive evidence, without metric retuning

Read Mayor's `first-train-block-descriptive-diagnostics.json`, source
`6c11fe7e683439f379f0dfdbd21b05f5873b2c90`, SHA256
`0f072b7f2d0feb64e21bae78b943b6ad1845e8cd85e12bf6b2585b3fa92156e9`.
The five cells each describe two120s episodes in one seedblock181001:

| Cell | Offered / natural EOS / reject / reported good | TTFT p50 / p95 (s) | E2E p95 (s) | Maximum observed KV |
|---|---|---|---|---|
| p128/m128 | 7850 / 5346 / 2504 / 5015 | .232 / .519 | 1.249 | .064 |
| p128/m256 | 2588 / 1840 / 748 / 1839 | .126 / .219 | 1.563 | .046 |
| p4096/m128 | 1850 / 584 / 1266 / 213 | .607 / 1.097 | 2.829 | .371 |
| p4096/m256 | 648 / 344 / 304 / 222 | .423 / .776 | 3.241 | .322 |
| mixed | 1146 / 826 / 320 / 675 | .331 / .684 | 2.605 | .372 |

These are correlated assigned-sequence descriptions, not five independent
seedblocks, per-arm causal effects, Fixed-cap results or a native MPC result.
The supplied good counts are reported diagnostics, not a rerun of this auditor's
raw-wire/source/config/EOS checks. TPOT in the artifact is a request-level
mean, not a physical decode-step distribution. Neither native capacity nor a
120% capacity anchor is inferred from the prespecified offered-rate references.
TTFT SLO.5s and TPOT SLO.05s remain unchanged despite these quantiles.

Cap16 observations still carry prior reservations>16 in112/795 short
p128/m128 observations and363/909 prefill-heavy p4096/m128 observations
(about14%/40%). These time-correlated descriptions support the actual
non-eviction/transient-reservation-memory observation, not independent
Bernoulli probabilities or the effect of Fixed16. Observed KV maximum.372
does not qualify full-pressure/preemption/OOM behavior or a hard safety bound.
The ten displayed episodes imply1200 offered seconds; the artifact separately
records a snapshot-level1560 completed actual offered-window seconds without
allocating the extra360 to its displayed first-block cells. Keep those scopes
separate and verify raw interval/epoch coverage before duration qualification.
Neither quantity is ten hours, and neither is GPU-exclusive demand or paid time.

The current one-second move interval is a hypothesis, not a proven control
timescale. These1-3s residence descriptions suggest earlier reservations may
persist across successive decisions. Falsify that hypothesis with
receipt-cut/action-conditioned release responses at1/2/3s and the same
continuation, recording whether a second move can alter still-live offered
work and whether lag/uncertainty erases ranking separation. Do not automatically
increase horizon or modify the running protocol from pooled E2E quantiles.

For a future adapter, prospectively select receipt-stamped cuts before the
next assignment/planned action and verify the prefix against actual applied
ACK/version fences. Preserve CAS delay, actual applied prefix and published
full assigned sequence; do not backdate a delayed action or select a favorable
cut retrospectively. Every input receipt must be<=cut; later releases/EOS and
physical tail labels remain separate outcomes. Gateway marks contain accepted
traffic with `scheduled_at=None`, not the full offered client history: online
arrival-law and offered-origin SLO features need an explicit client-receipt
adapter and availability audit, not an offline oracle.

A future randomized action can have sequential causal support conditional on
pre-assignment history when assignment probabilities, positivity, no
anticipation and actual execution are qualified. Post-action batch composition
is a mediator and cannot be treated as the same pre-treatment state across
different earlier prefixes. For a full preassigned sequence, conditional suffix
support must follow its actual randomization design; average-cap aliases do
not preserve order. None of this descriptive evidence supplies calibration,
conditional support, a causal coefficient or a controller win.

### Astra: accept S1/S2/S3 and repair the actual defects

| Counterexample on frozen Sol R2 | Owned R3 repair and regression |
|---|---|
| S1: offer10, no first content through11, otherwise complete client prefix, retains good upper1. Opus raises the same issue. | Censored absence tightens upper to0 only with `client_prefix_complete=True` and cutoff strictly beyond the scheduled-origin TTFT deadline. Missing/incomplete prefixes retain1; equality at the inclusive deadline retains1. The row remains censored and CI/p remain withheld, including when aggregate bounds collapse. Client timeout already scores0 but does not prove native drain. |
| S2: both arms of block2 change actual TTFT from.5 to.05 behind the same opaque hash; effects `[1,0]` are pooled. | Require substantive configuration and side-specific policy SHA256s; recompute the semantic comparison digest from each actual pair and match the one globally frozen digest. Tests reject changed TTFT, TPOT, window, native source, Torch version or policy, an arbitrary shared hash, and independently re-frozen per-block settings. |
| S3: six identical tapes with renamed logical IDs/UUIDs/seeds/block IDs produce exact p.03125. | Retain identity-sensitive within-pair tape matching, but add a label-free ordered semantic digest for cross-block replay rejection. It binds offset, prompt recipe hash, prompt count and output limit, normalizes numeric offset representations, preserves tied-offer ordering, and rejects out-of-order offers. Relabeled copies now fail before inference. |

The replay calls the immutable Sol R2 implementation, rather than a simplified
replacement. It drops only the two newly required API keywords when preparing
old-schema arguments; the substantive witnesses remain different actual SLOs,
identical semantic tapes, and observed late absence, not API TypeErrors.

`configuration` now requires the pinned40hex model revision; deployment,
boot, GPU UUID, driver, vLLM, Torch, Transformers and dtype identifiers;
native/Gateway/core/cost-model/scheduler SHA256s; and observer mode.
Additional stable settings are also hashed and must match. Process run IDs
belong in episode provenance, not the stable comparison configuration.
This policy comparator intentionally cannot pool changing observer/source/boot
regimes. An observer-overhead contrast needs a separately frozen protocol that
explicitly designates observer mode as treatment, not hidden configuration
differences passed through this API.
`comparison_digest` additionally binds left/right policy hashes, actual
window and both SLOs, the natural-complete endpoint and equal-fresh-block
weighting. It binds declarations, not truth: source-bound receipts and
pre-outcome freeze timing still require external verification.
The bootstrap draw count/seed, assignment space, contrasts, multiplicity and
minimum practical effect must be frozen separately in the analysis protocol;
this digest is not a complete experiment preregistration.

Astra R2's clock-domain/availability/freshness checks are real improvements
over R1. However, a decode mark with zero native-running count still reaches
`shadow` under the frozen stub; `active_permit` remains false. The state adapter
must reconcile the received physical prefix or mark the disagreement unknown.
Cooperative callback checks are not a hard watchdog, and planner elapsed does
not include observation/features/persist/POST/fence. The response model,
joint uncertainty, support and deployment receipts remain external interfaces.
The repaired Sol audit supplies none of those missing native qualifications.

### Opus: accepted censor criticism, retained provenance/support boundaries

Accept S1 conditionally as above. A no-first complete observation beyond TTFT
proves natural-good is impossible; an incomplete SSE prefix does not.
This is endpoint-bound tightening, not a native EOS/drain assertion.

R2 improves missing-history representation and requires tail commit at/after
finish. Both are useful. The new replay still obtains origins with explicitly
foreign native clock/run fields, accepts a retroactive release time-100 as
truth `(1,1)`, and aliases order-distinct LH/HL plans at all three average-cap
horizons. These are thin-adapter/representation limitations, not proof that
the real native LH/HL outcomes differ. Use the established receipt join and
exact canonical IDs before presenting a physical qualification; validate
ledger chronology before using releases as training truth.

Marginal shape/range envelopes still do not prove joint mixture, history,
sequence or unknown-work support. Horizon-specific censor exclusion can
change the cohort and make a reported train release fraction decrease with
horizon; it is not a coherent joint trajectory probability without an explicit
common cohort/selection model. Origin-pooled calibration is not block-balanced
or a whole-block coverage guarantee. Missing-native and missing-history flags
may support a useful partial-observation predictor, but only demonstrated
Train-conditioned support and later sealed block evaluation can justify that
use; the3034/13280 visibility diagnostic alone cannot qualify or falsify it.

Tail count/positions and commit brackets remain insufficient to authenticate
the discarded-placeholder mechanism without matched raw scheduler/worker/CUDA
and output lineage. My own booleans are also attestations: the bounded
diagnostic does not independently authenticate a native trace.

### Gemini: distinguish deliberate limits from numerical/factual defects

The exact routine's2..16-block bound is a documented fail-closed boundary, not
permission to split thirty-two blocks into pseudo-experiments. A new
preregistered Monte Carlo protocol can be legitimate, but must explicitly
declare approximate inference, assignment space, draw count, seed, resolution
and Monte Carlo uncertainty. It must not silently replace exact enumeration.
The frozen R2 Gemini exact branch still reports p1 for four positive1e-15
effects; the scale-invariant correct exact p is.125. My R2 rational comparison
and its regression remain unchanged.

The independently rounded timestamp example is real:
`1700000000.123 + .1` differs from literal `1700000000.223` by
`2.384185791015625e-7` seconds. The new replay uses the actual current auditor:
the source-computed scheduled stamp passes, the independently rounded literal
fails. I retain that explicit source-copied planned-origin contract, not a
claim that independent floating arithmetic is identical. A future raw adapter
needs a declared exact tick/source stamp representation or reviewed bounded
absolute quantization rule; broad relative tolerance at epoch-sized values
would mask materially wrong schedules. This interoperability limitation is
not silently fixed by weakening chronology.

Four additional actual-source witnesses: empty qualification records still
produce the hardcoded stochastic-tail claim; the default epoch contains four
episodes rather than the actual two; NaN "realized" duration is classified
`Qualified`; and its scaled exact-p defect persists. The first is refuted by
twenty LIGHT/all-one-overhang versus twenty OFF/unmeasured, not by another
model's opinion. Planned duration or an unattested scalar cannot establish
actual>=10h, and a nonfinite scalar cannot even pass numerical validation.
R2's SQLite/new-ClockDomain narrative is also contradicted by actual runtime
facts stated above. None of these diagnostics constitutes a GPU experiment.

The original full-offered/boolean/POST-chronology/ledger/count-conservation and
heuristic-controller concerns remain. Helpers that restate simplified
Sol/Astra logic do not demonstrate how the frozen implementations behave.
A minimum practical effect is a different null from zero; point mean>=margin
plus a zero-null p is not margin-supported superiority. No manufactured
agreement against all t/asymptotic methods, universal tail law, or impossibility
of MPC is endorsed.

### RETAINED DISAGREEMENTS and discriminating experiments

**Fresh-workload versus fixed-tape estimand.** Independently randomized
executions of one genuinely fixed tape can be legitimate stochastic replications
for a conditional fixed-workload effect. They are not fresh-workload blocks;
this module deliberately rejects semantic repeats for its declared estimand.
Unique hashes cannot prove independence: the actual block generator,
randomization and no-carryover evidence remain externally verified.
Fresh independent discrete workload draws can also coincide; duplicate
rejection is not proof of dependence. This routine rejects the whole comparison,
not selected blocks. Any uniqueness-screened workload law must be preregistered
as a distinct target from unrestricted IID workloads, never selected after
seeing outcomes or disguised by relabeling.

**Known-bad censor versus terminal completion.** A separately preregistered
analysis might permit inference when the binary endpoint is identified despite
an unresolved native lifecycle. This conservative routine still withholds
point inference on every censored full-offered row; it never imputes success.

**Tail mechanism and partial observation.** The bounded useful/physical/tail
ledger accepts zero excess or the explicitly evidenced one-placeholder case,
not arbitrary+1 relaxation or a universal stochastic distribution. Keep old
audit failures and test other excess/launch/commit patterns. Partial state can
be predictively useful, but missing physical work must stay represented and
must not turn receipt availability into full observability.

**Prediction versus causal closed-loop value.** Conditional release forecasts,
open-loop plan ranking and same-first-action scores do not establish gain over
strong One-move when both algorithms replan. Freeze identical continuation,
outcome definition, robust joint support and full-path deadline accounting;
then Mayor can run randomized full-policy comparisons with washed-out paired
cells. No active permit, hard KV safety or native solver-overhead bound is
granted by any current CPU contract.

Discriminating native work remains Mayor-owned: order-matched LH/HL contrasts
with pre-outcome forecasts; joint-mixture/history/missing-visible support
ablations using exact receipt cuts; raw tail-lineage checks on measured LIGHT
and appropriately instrumented controls; block/cadence sensitivity of release
calibration; watchdog and late persist/POST/fence failure injection; and actual
source/clock-linked informative-duration receipts. These are proposed tests,
not R3 execution receipts or permission to fit held-out partitions now.

The exact null remains zero effect under independent fair pair-order swaps
and qualified absence of carryover/order-by-policy effects. The bootstrap
percentile95% interval is approximate, may degenerate legitimately, and has
no guaranteed coverage/power. Nonsignificance is not equivalence; pairwise p
is not multiplicity-adjusted superiority or minimum-useful-effect support.
`independent_sampling_verified=False` and `native_performance_accepted=False`
remain unconditional. No native prediction/MPC, observer-overhead, deployment
or ten-hour claim is introduced.

### Round3 exact source/test and replay receipt

Final owned implementation/test SHA256s:

```
40feecfc7b2c5f2b3954f1a997cac570f2a19dc6b78845350ff74f589bd363ad  native_experiment_audit.py
1e95d2c898c9bc526ff5f4362de02a2299ed0f034cb7f48cf398d5dd83d2291a  test_native_experiment_audit.py
```

Executed the existing standard-library focused runner:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s experiments/mpc-research/native-v3 -p test_native_experiment_audit.py -v
```

**26 tests passed**, no skips. The historical R1 helper still verifies six
digests and fifteen named witness groups. R3 replay verified eight R2 digests
and all thirteen named witnesses, including three substantive old-Sol failures
and the current implementation's explicit thirty-two-block refusal:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=experiments/mpc-research/native-v3 \
python3 -c 'import json,sys; from test_native_experiment_audit import round3_counterexamples; print(json.dumps(round3_counterexamples(sys.argv[1]), sort_keys=True, indent=2, allow_nan=False))' \
  /path/to/pr33-native-v3-round2-frozen
```

The executable helper pins exact frozen source/tests and requires the supplied
external archive; portable unit tests do not. No native data fixture or invented
native result was added. Whitespace checks passed; full CPU acceptance/native
quality gates were not run for the previously recorded scope/environment reasons.
Only the three owned paths changed across the R3 local history. The environment
checkpointed initial R3 source/tests at `6e28a83`; this report and final replay
receipt are committed locally with the Copilot trailer, without amending it.
Mayor retains Beads/in_progress and peer-review management; no push/merge or
database mutation is part of this deliverable.

## Bounded follow-on: real Train6c schema and frozen methodology proposal

### Deliverable and evidence boundary

R3 commit `475eb855dada59cb40d8c96d09368befcedadc92` remains historical/frozen.
Added one portable standard-library capability adapter,
`train_schema_audit(episode_bytes, expected_sha256=..., cut_at=..., horizon_s=1)`,
and seven focused regression methods. It verifies exact artifact bytes, refuses
non-Train/out-of-range seeds, and separates `observations`, `offline_labels`
and `authority`. No fit, benchmark, controller, protocol change or fabricated
source field is supplied. The bounded short-step target is1s by default,
at most3s; this is an audit interface, not an empirically selected optimal horizon.

Only Train181001 p128/m128 arms0/1 and their read-only event/verification
receipts were examined for this follow-on. Sources:

```
d633b4e402e453238b0d612b3b64c198d61fe572eb9c3b171cbb76a616187c23  nv3-181001-p128-m128-arm0.json
467887df4445c5f20aea1376d40ce07b59671c6326a3c8e88b04bd18008a1a7f  nv3-181001-p128-m128-arm1.json
```

Both digests match the supplied artifact verification ledger. The6c Git object
is unavailable locally; older `collect_interventions.py` was read for schema
context, not falsely presented as byte verification of6c. Frame clock/run,
observer hash, Gateway identity and CostSpec consistency are checked, but
producer authenticity remains external. A dataset/source hash is not a proof
of genuine randomness, independence, pre-outcome publication or calibration.

### What the schema supports, and what it does not

| Distinction | Concrete adapter/evidence result |
|---|---|
| Received observations versus future labels | Only native frames with recorded native receipt<=cut enter observations; Gateway receipt, clock, epoch, sample skew and current freshness are checked. Earlier event/sample time cannot admit a late receipt. Final client rows and later frames enter only `offline_labels`. Mutating a later client first time to before cut, later native output and an unreceived ACK leaves observations unchanged. |
| Live admitted stock versus all-offered past/rate | At arm0 cut `start+.9`:15 live Gateway marks,14 native-visible, one accepted-not-visible; offline planned offers by cut17. Fifteen live marks are neither all-offered arrivals nor cumulative admissions. The schema contains the final all-offered ID/offset/row cohort, but does not establish an online model consumer's receipt of in-progress client offers/first-content history. `all_offered_client_history=None`; no first time or scheduling origin is backfilled into Gateway marks from future rows. |
| API stop versus independent physical EOS | Arm0 reports3925 outcomes:2681 complete/stop,1244 rejected. Arm1 reports2665 complete/stop,1260 rejected. No independent per-request physical EOS receipt accompanies these Train rows. A stop label or injected boolean never establishes EOS/CUDA/output lineage; `independent_physical_eos_receipts=None`, not measured zero. |
| Disappearance versus a physical finish time | A complete same-epoch Gateway mark lost between snapshots yields an open-left/closed-right sampled disappearance interval, conditional on those snapshot attestations and no ID reuse. If it straddles `cut+horizon`, whole-request release bounds are `[0,1]`, not fractional interpolation or a natural-EOS timestamp. Missing endpoint coverage stays interval-censored; corrupt future snapshots withhold labels without rewriting valid pre-cut observations. |
| Original cost versus net stock change | Every UUID retains its original charge, charged shape and admission/ingress stamps. CostSpec is checked, but original charges are never replaced by costs of delivered tokens. Two equal-cost old requests followed by one surviving old request plus one new equal-cost request have unchanged total stock and one complete old-cohort release. The regression produces12 released cost, not zero or a fractional six. |
| Cap drop versus eviction | A synthetic, explicitly non-native schema witness preserves original reservation24 when the observed cap is16. The cap governs further admission; it does not erase prior costs or cancel requests. Real Train non-eviction facts remain those recorded in R3, not this fixture's values. |
| Actual prefix versus nominal/average cap | Receipt-qualified command/ACK pairs must match clock/run/identity, operation, budget, CAS version and expiry. Actual application/receipt times are retained. A received newer ACK conflicting with the sampled state is flagged, not silently reconciled into fabricated state. The full declared assigned sequence remains separate offline metadata until its model-consumer publication is qualified. |
| Same offered tape versus same-state causal effect | The two real arms share offered-offset digest `dc602d910983ecb8d76d37f8b1d69563d7003e89fde31a910ffd79f94dabcb26`, but their assigned prefixes and observed stocks diverge, as shown below. Offset equality does not authenticate common prompt payloads or a same-state contrast. |

At identical relative receipt cuts, the actual partial states differ:

| Arm / relative cut | Assigned first three caps | Observed current cap | Original reserved cost | Live / native-visible / accepted-not-visible |
|---|---|---|---|---|
| 0 / .9s | 32,16,16 | 32 | 15.340359936 | 15 / 14 / 1 |
| 1 / .9s | 16,32,32 | 16 | 12.2722879488 | 12 / 10 / 2 |
| 0 / 2.9s | 32,16,16 | 16 | 8.1815252992 | 8 / 8 / 0 |
| 1 / 2.9s | 16,32,32 | 32 | 20.453813248000003 | 20 / 20 / 0 |

The first planned1s applications occurred with actual planned-to-apply lags
.04942819394636899s / .033400297979824245s. Those are observed planned-origin
lags, not exclusive CAS/POST processing times; command POST-send latency is
not manufactured from GET or expiry stamps. Actual prefix and full assigned
sequence must be preserved rather than averaged into a cap coefficient.
These manually chosen descriptive cuts supply no forecast or causal fit.

At arm0 `start+.9`, the sampled cohort anchor is996887.719384979; by the
target996888.776386528, all its original15.340359936 charged cost has disappeared
in complete later snapshots. This is sampled-Gateway-cohort ownership evidence,
not physical EOS, useful GPU demand or release exactly after the decision:
the anchor precedes the decision receipt, and some releases may occur in that
skew interval. Unknown transient admissions/releases between snapshots and
accepted-but-not-native-visible work remain unobserved. Individual intervals
must not be sampled independently to invent a joint transition distribution.

The real arm0 event envelope has24 GPU samples,765 native frames,3925
`http_outcome` records and119 action records. Native frames/actions carry their
specific receipts; `http_outcome` is an eventual outcome row, without a separate
model-consumer publication receipt for its earlier scheduled/send/first events.
The client driver may internally know its offered plan, but the current
export does not prove that an online policy consumed that history at a cut.
Source timestamps alone must not become a retrospective online oracle.

### Joint short-step model and honest comparison eligibility

**Supported as a partial, unqualified modeling dataset:** received marked-cost
stocks, whole-cost cohort disappearance intervals, explicit accepted-not-visible
work, reported native running/waiting/pending/KV and per-visible-request
prompt/output/computed progress. `computed_tokens` is reported scheduler
progress, not authenticated contiguous executed CUDA positions or exclusive
GPU demand. Retain physical visibility, receipt skew and pending-ACK uncertainty
as state uncertainty rather than zero-filling missing work.

**Not supplied:** a fully observed physical stock-flow kernel, exact per-request
native EOS, coherent joint scenarios, support/calibration, independent blocks,
same-state counterfactuals, complete online all-offered history, exact prompt
payload hashes, or all stable run/policy freeze fields required by my strict
comparator. The adapter does not derive prompt SHA256 from a cell label, physical
EOS from `stop`, configuration from unrelated identity hashes, or client
scheduling from `Gateway.scheduled_at=None`.

The all-offered rows can be reconciled offline against exact recorded physical
UUIDs and source-copied planned origins, retaining reject/fail/cancel/censor
labels. That is not full wire/source/EOS qualification:
`client_wire_outcomes_qualified=False` and `native_comparison_accepted=False`.
The new adapter does not loosen `audit_arm` or feed counterfeit required fields
into it. Reported API stops remain descriptive, not the frozen physical-natural
primary endpoint. No existing40-request qualification UUID is presumed to
authenticate these thousands of different Train requests.

A model conditioned on receipt-qualified pre-assignment history can support
sequential randomized-action contrasts under verified assignment probabilities,
positivity, nonanticipation and execution. State after different earlier
prefixes is a mediator; these paired arm states are not one common pre-treatment
state. Current randomized sequence identification is not implementation of
strong One-move/MPC policies. Whole-policy effects require the corresponding
qualified full-policy randomization and offered cohort, not paired snapshot
differences. All authority flags remain false; identifiers/hashes are provenance
metadata, not memorization features or independent sampling units.

### Frozen primary/statistical proposal before Final

This local commit freezes the following **proposal**, without changing the
running identification protocol or claiming a complete executable Final
preregistration. No Calibration/Validation/Final outcome was opened or used.

| Item | Frozen proposal |
|---|---|
| Primary endpoint | Right-minus-left physical-natural complete-good per prespecified offered-window second: positive integer output, complete exact-UUID HTTP response, independently joined physical EOS, scheduled-origin TTFT<=.5s and terminal-based request-mean TPOT<=.05s. One-token TPOT=0. Reject/fail/cancel/timeout/length-finish contribute0; missing rows fail; unresolved censor/EOS/source qualification withholds confirmatory inference. Do not redefine it to fit6c's absent EOS fields. |
| Primary contrast | MPC minus strong One-move, sharing the same qualified model, joint uncertainty, common continuation, constraints, offered law, window and native runtime. Neither existing Train arm is relabeled as one of these policies. |
| Sampling unit/statistic | One independent seedblock contains both policy arms across all five cells. Compute each cell's paired good/window difference, then equal-weight the five cells, then equal-weight independent seedblocks. Origins, requests, steps, cells and repeated arms are not independent replicates. Never split one seedblock or forge a single concatenated scheduled origin to satisfy the flat audit API. |
| Planned sample size | Eight prospectively selected independent complete blocks per contrast, not eight surviving blocks chosen from a larger outcome pool. Actual seed IDs and immutable experiment/assignment manifest must be bound by Mayor before Final execution. Missing/invalid planned blocks withhold the comparison; no optional stopping, dropping, outcome-selected extensions or retrospective manifest. If the existing Final plan differs, this proposal cannot silently reshape it. |
| Minimum practical effect | Delta=.10 physical-natural good/s on the equal-cell standardized endpoint, fixed here independently of fitting these Train outcomes. This is a design threshold, not observed gain, a capacity anchor or a guaranteed detectable effect. |
| Multiplicity | Predeclared family of three contrasts: MPC versus strong One-move, Train-selected best qualified Fixed16/32, and Train-selected best qualified reactive policy. Holm family-wise alpha.05 for valid zero-effect tests; cross-contrast independence is not presumed. Baseline identities/settings/selection rule must be sealed before Final, not chosen as weak controls or selected from Final winners. |
| Inference boundary | Exact block sign-flip zero-null inference is usable only after its actual assignment space, fair block label swaps and qualified no-carryover/order effects are verified. Eight pairs' minimum two-sided exact p is1/128; this is not power. Approximate block percentile bootstrap remains exploratory, not guaranteed coverage. |
| Practical-effect claim | Zero-null rejection plus point mean>=Delta is insufficient. A qualified practical-superiority claim additionally needs a valid simultaneous lower-effect bound aboveDelta or a separately preregistered valid margin-null analysis. Neither is currently implemented/qualified here. Do not silently shift sign-flips byDelta and claim exact inference for a composite mean null. |

Only the endpoint, unit, weights, threshold and contrast/multiplicity proposal
are frozen here. Missing native capture authority, baseline/model artifacts,
prospective cut/sequence publication, source-bound manifest and verified
independent sampling are real prerequisites, not filled by an opaque hash.
The existing `paired_effect` accepts flat single-window paired arms; it does
not yet audit this five-cell native seedblock aggregation or its assignment
space. Any complete Final analysis protocol must resolve those prerequisites
before Final outcomes are generated/viewed, without retrofitting current data.
No native win, equivalence, calibration, sample-size power, full-pressure
safety, solver overhead or ten-hour claim follows from this proposal.

### Exact local adapter/regression receipt

```
4fc5fd5e81ba495e67c96aadc7f0d531874b6262e32edd6d0f5a18f3df33db34  native_experiment_audit.py
e2e7945f3bc641d698519d5bbfa5856b8fc250234f53a79914c83e700e6ae046  test_native_experiment_audit.py
```

Executed the existing standard-library runner:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s experiments/mpc-research/native-v3 -p test_native_experiment_audit.py -q
```

**33 tests passed**, including seven new schema regression methods; no skips.
Preserved R1/R3 pinned replays still pass15/13 named witnesses and6/8 byte
checks. The real two-arm probes above executed through the portable adapter
against ledger-verified bytes; neither granted native comparison authority.
The environment automatically checkpointed part of the work at `d8a64d2`;
the final report/receipt is committed locally with the Copilot trailer, without
amending the frozen R3 history. Only the three owned paths change, with no
push/merge, database mutation, GPU process or live protocol alteration.
Full project/native gates were not run for the previously recorded scope
restrictions; focused contracts and whitespace checks are the local receipt.

## R5: standalone online all-offered publication/receipt interface

### Small API and publication contract

Implemented `OfferedReceiptHistory` with construction, `receive(publication)`
and `cut(cut_at)`. It has no network, GPU, model, dependency installation or
active-control path. The observer captures its own `received_at` with an
injected/default monotonic clock; producer-supplied receive stamps and final
HTTP rows are rejected. Producer and observer must declare the same verified
ClockDomain: no clock-offset inference or GPU-elapsed conversion is supported.

The versioned producer envelope is:

```
schema: native-v3-offered-publication-v1
publisher_run_id: exact hex32 client publisher epoch
clock_domain: producer host monotonic ClockDomain
publication_seq: contiguous positive integer, starting at1
request_id: exact hex32 offered UUID
kind: offered | sent | first | terminal
event_at: actual client callback event stamp
published_at: actual producer publication stamp
```

`offered` additionally supplies the original `scheduled_at`, `original_cost`
and `cost_spec_sha256`. `terminal` additionally supplies a client lifecycle
status: complete/rejected/cancelled/failed/timeout. Unknown cost/provenance is
explicit `None`, not zero, a fixture default or an estimate backfilled from
delivered output/Gateway rejection data. Known cost must be positive/finite
with its source CostSpec digest. Known and unknown original values remain
immutable; a later admission charge is separate evidence, not permission to
rewrite the original offered declaration. An offered cost is not an admitted
reservation, GPU seconds or KV bytes.

Each unique publication is identified by publisher epoch/sequence; each
offered UUID may be registered only once in that epoch, including after
terminal closure. Publications are FIFO/loss-detecting: gaps, duplicates,
foreign epochs/domains, nonfinite/boolean times/costs, publication before
event, publication after observer receive and clock regressions fail closed.
Per-request send/first/terminal event order is checked. `sent` means client
attempt initiation, not successful wire transmission, Gateway admission or
native execution. First requires a preceding send; cancellation/failure/
timeout/rejection may close an unsent intent. Empty complete responses can
still be recorded as lifecycle completions; no positive-output/SLO/EOS
benchmark authority is inferred.

`receive` returns a copied receipt with the observer run/domain and the
observer-generated receive stamp. Original producer objects, returned
receipts and returned cut records cannot mutate stored cost/history.
There is no API that turns present final rows into publications or manufactures
callbacks that were not executed.

### Cut semantics and deterministic evidence

`cut_at` cannot exceed the observer clock or regress after a sealed cut.
Only receipts available by the cut participate. Presubmitted future intents
are excluded from the due-offer history until their original scheduled time.
When a first/terminal event happened before a cut but its publication reached
the observer later, it does not retroactively fill that cut.

Cuts carry a receipt sequence watermark and immutable copies. Repeating the
same time returns the same sealed prefix, including when a subsequent callback
shares that clock tick; a strictly later cut can include it. Thus a timestamp
tie cannot change a previously published decision prefix. The watermark is
transport provenance, not a predictor feature or proof that all producer
events through wall-clock time were received.

All due registered offers remain in the history: rejected, cancelled,
unsent, delayed and completed. Counts distinguish known sends, late sends,
pending requests, terminal statuses and unknown original costs; there is no
accepted-only filtering or terminal-triggered deletion. Global publisher
completeness remains unverified: an unseen/in-flight publication or missing
prospective registration is not evidence that no offer existed.

Seven new CPU regression methods demonstrate deterministic callback-driven
replay, separate publication/receive stamps, late-send and unsent cancellation
inclusion, delayed first/terminal noninterference, future-intent exclusion,
equal-tick prefix sealing, original-cost/copy immutability, malformed
sequence/clock/lifecycle rejection, final-row refusal and explicit unknown
cost preservation. The deterministic stream contains three due offers, two
send attempts, one late send, one completion, one rejection and one unsent
cancellation, retaining original declared costs2/3/5. These are explicitly
synthetic interface inputs, not native measurements or performance constants.

### Exact Mayor source context and integration still required

After the exact path was clarified, read the requested Mayor collector and
its optional synchronous capture hook, without editing either. Read-only
source hashes at inspection:

```
069a58b6c2e15081acaaf70c73a9465fdb64da694d47fbc5b20f35c2560d7422  Mayor native-v3/collect_identification.py
a8bbafd6a84f8a1581a2f0e0d0fe11a086c542e392a45c1466fa9071df93fb6c  Mayor mpc_lab/http_capture.py
```

`collect_identification.py:350-364` creates/persists IDs and the offered tape,
then records eventual `http_outcome` rows. Its `capture_chat` call at391-393
passes `record=record`, **not** the optional HTTP `observe` hook.
Its existing `async def observe()` is the native-frame sampler, not a
synchronous HTTP callback and must not be reused as one.

The inspected `http_capture.py` calls optional synchronous `observe(kind,
receipt)` with a copied receipt containing `published_at` and ClockDomain:
`offered` after assigning the client attempt `sent_at` and before entering
`client.stream`; `first_content` when actual SSE content first becomes
available; `terminal` in `finally`, including timeout/rejection/cancellation.
An unsent cancellation has `sent_at=None`. Callback errors latch
`observation_error` without changing the offered HTTP traffic, and awaitable
callbacks are rejected. This is source-level interface context, not a claim
that these callbacks were attached/executed on the native continuation.

A future authorized integration must:

1. Prospectively publish unique offer-intent registrations before task
   queueing/validation/cancellation, using actual publication clocks and
   source-bound cost metadata or explicit unknowns. Persisting a manifest
   alone is not a model-consumer receipt. Do not create a retrospective
   offered receipt when an unregistered terminal arrives.
2. Add a separate synchronous normalizer/publisher with a serialized
   per-client-epoch sequence. Map the capture hook's `offered` attempt event
   to this interface's `sent`, `first_content` to `first`, and `terminal` to
   `terminal`, preserving actual hook event/publication times. A standalone
   offer-intent registration remains necessary for unsent requests.
3. Attach that callback explicitly to `capture_chat(observe=...)`, deliver
   through an ordered channel, and capture the policy observer's own receipt
   clock at consumption. The current collector call site does not do this.
4. Preserve callback failure/gap evidence and withhold completeness/model
   authority; do not swallow bad measurement into a purported complete
   history. A terminal callback containing an old first timestamp cannot
   recreate the missing first publication or its earlier receive stamp.

This integration is deliberately **not implemented in the collector or live
capture module**. No fake cost, send, first, terminal or publication receipt
was added to existing files/data. R5's receipt interface is standalone, not a
native qualification. Source declarations and syntactically valid callback
packets are not source authentication, complete transport or physical EOS.
`publisher_complete_through_cut`, `callback_source_authenticated`,
`independent_native_eos_verified` and `active_mpc_permit` remain false.

The byte-bound Train capability audit remains unchanged and continues to
withhold absent online/physical authority. The physical-natural endpoint and
statistical design remain **proposals**, not binding benchmark rules or
reinterpretations of current identification labels. The inspected collector
itself describes open-loop identification, correlated cells/arms and no MPC
acceptance. Mayor reports native729 unchanged and continuation02 actually
running/replicated; this task did not execute or independently requalify it.
No Calibration/Validation/Final outcome was opened or fitted in R5.

### R5 exact local source/test receipt

```
b476424aa892ceeaef63f6a67c7e28e45923090cb53db8aeec2f4acbcc1ef10a  native_experiment_audit.py
10a1315117b774eca7531c76067205e9332fc14c1114ecd145b748b6914872ba  test_native_experiment_audit.py
```

Executed the existing standard-library runner with
`PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover
-s experiments/mpc-research/native-v3 -p test_native_experiment_audit.py -q`:
**40 tests passed**, no skips, including seven new receipt methods and all
preserved Train/endpoint/block/work tests. Frozen R1/R3 replays still verify
six/eight digests and pass fifteen/thirteen witnesses. Whitespace checks
passed. No new third-party dependency, native hook execution, active permit
or full/native quality-gate claim. The environment checkpointed source/tests
automatically; this report and exact receipt are committed locally with the
Copilot trailer. Only the three owned paths change; no push/merge, Beads
mutation, GPU process or live protocol change. Mayor retains in_progress/
peer-review management.

## R6 independent architecture: partially observed hybrid marked-batch dynamics

This proposal was written without inspecting another model's R6 conclusions.
I choose a **hybrid marked-event belief kernel**, not exclusive serial
HTTP-first-residence service or a cap-to-GPU-rate regression. The family is
structurally useful but **not point-identified, fitted, calibrated or authorized**
by this round. The runnable deliverable is a source-bound endpoint-attribution
counterexample/diagnostic, not a synthetic performance benchmark or an executable
native dynamical simulator. R5's receipt interface and byte-bound Train audit
remain unchanged.

### Minimal x, u, w, f, h

The directly observable state `x_obs(t)` contains only receipts available at the
cut: Gateway whole-cost owners, prompt/max marks, received/admitted/first times,
current reservation stock and cap/version; exact joined native request IDs and
raw `(computed_tokens, output_tokens, prompt_tokens, maximum_output_tokens)`;
native running/waiting/pending/KV reports, visibility masks and snapshot ages;
and received command/application ACK fences. A published-prefix action history
and R5 all-offered client history are required inputs when actually available.
Present raw final rows do **not** supply those online client receipts.

Use separate latent components `z(t)`, not invented zeros: accepted-but-unseen
ingress/native membership, waiting identities, useful/cache-resident progress,
scheduled versus executed work, possible replay/preemption, physical EOS and
unfinished tail, client delivery/terminal state, and missed inter-snapshot
birth/death pairs. The prediction state is `(x_obs, b_t(z))`, a belief over coherent
marked states. This is not a claim that the observed vector alone is Markov or
that its latent posterior is identified. Native counts with unknown identity and
marked-not-visible work must remain explicit constraints/unknown mass.

`u(t)` is the **actually applied whole-request reservation budget 16 or 32**.
Planned changes and actual CAS/ACK delay are separate events, not instantaneous
control. Each offer has immutable charge `c_i`, Gateway/native prompt marks,
output limit, payload identity, intended-offer time and lifecycle identity.
An unqualified future charge is unknown. A hypothetical scenario charge obtained
from a fixed CostSpec/payload is a prediction, never a fabricated original-cost
callback receipt.

`w` is a COMMON, cap-exogenous offered point process with joint payload marks,
client/ingress timing disturbances and common primitive model randomness. The
future payload/output-limit law does not change to help a candidate cap. EOS
continuation uncertainty is conditional on payload/native prefix and actual
batch state, not a direct budget effect or an asserted independent coin flip.
Common random numbers must preserve that joint dependence. Fitting the birth
law from admitted marks alone would introduce cap-dependent selection; future
final rows are labels, never pre-cut arrivals. Neither intended offer nor client
attempt receipt is proof of native ingress. The current unexecuted R5 callback
integration leaves online all-offered input authority withheld.

The event kernel `f` operates on one marked population with separate Gateway,
native and HTTP lifecycle coordinates. Admission/rejection follows the actual
reservation gate, with no eviction on a cap decrease:

```text
admit i only if reservation_stock + c_i <= applied_u
delta admitted_count = admitted_births - releases
delta reservation_stock = sum(original c_i for admissions)
                        - sum(original c_i for releases)
```

Every release belongs to one exact owner; no fractional releases, duplicate
terminal rewards or independently sampled count/cost flows. A released Gateway
owner need not imply independently verified native EOS or drained physical work.
Conversely, API completion is not the exclusive native service interval.
Unseen between-snapshot flows cannot be recovered from a net stock change.

After admission, ingress/queue events expose native jobs. A common joint
batch-allocation/transition kernel uses actual admitted native composition,
prompt/decode progress, payload/prefix, waiting work, cache residency/KV and
shared resource noise. It **does not receive cap as a service-rate coefficient**.
For a native forward step, nonnegative integer token allocations must respect
the pinned scheduler's physical configuration, which is not the cost budget.
Prefill and decode compete in that same allocation and batch shape:

```text
sum_i allocated_native_tokens_i <= K_scheduler(configuration)
executed_inputs = useful_prefill + useful_decode + tail + replay
```

The second line is a mutually exclusive accounting partition, not extra
independent work generators. Tail is classified relative to useful delivery/
finish lineage and can be unknown online. Replay/preemption cannot be assumed
absent merely because these Train examples do not qualify high KV pressure.
Batch progression/time depends jointly on the allocation/mix and readiness.
There is no sum of per-request HTTP durations equated to GPU service and no
conversion of GPU elapsed into an absolute/exclusive host-clock interval.
`K_scheduler`, progression/time parameters and observation-delay parameters
are **not estimated or numerically invented here**.

EOS/length events, possible pending tail and client delivery/terminal events
complete the same trajectory. Output limit is an upper bound, not realized
natural EOS. Native output counters, client completion usage/content receipts
and executed inputs remain distinct. A pre-finish placeholder may execute
without another useful output. The LIGHT qualifier's 20 measured one-overhang
requests do not identify a random tail law; the other 20 OFF requests are
unmeasured, not measured zero. The old v2 failure is retained.

The observation map `h` emits exact reported token fields, visible masks,
Gateway reservations and client receipt prefixes, with their own source and
sampling/receive clocks. Raw computed-token reports are genuine covariates,
but are **not silently declared executed CUDA counts**. Absent physical EOS
receipts remain absent. Observation loss/delay is part of `h`, not zero service.
A practical future implementation could initially fit receipt-to-receipt
joint reported-progress transitions without claiming physical execution
identification. Physical-natural endpoint qualification still needs its
independent native source.

**Exclusion falsifier:** with common arrivals/payloads/primitive noise, identical
actual admission and native-state paths, and nonbinding 16/32 gates, the service
sample path must be identical. A predictor changing service solely because the
budget label changed violates this family. Budget effects through admission,
batch mix, queue/cache history and later releases remain legitimate. Different
post-action arms are not a matched pre-treatment state or a same-state causal
effect.

### Focused runnable counterexample: incumbent information versus birth error

Added `future_api_good_partition(bytes, expected_sha256=..., cut_at=...)`.
It uses the existing Train181001..181016 byte/receipt audit, preserves the raw
five request fields at the same last received frame (including tied receipt
ordering), and reports **offline labels** for fixed horizons **1/3/5 seconds**.
It does not fit anything or expose future rows as observations.

For each horizon, the API-stop/SLO candidate count partitions exactly into:

```text
G_api = G_visible_snapshot_cohort + G_marked_native_unknown
      + G_past_offered_outside_snapshot + G_post_cut_intended_birth
```

Past offers outside the sampled Gateway cohort may involve transient/gap/
ingress histories; they are not relabeled native-visible incumbents or
post-cut exogenous births. Marked-but-unseen members are their own group,
not zero work. Birth classification uses intended scheduled origin, not
cap-selected admission or retrospective native visibility. This partition
alone does not identify wire ingress or a physical service mechanism.

Candidate labels retain the existing scheduled-origin TTFT <= .5s,
terminal-based request-mean TPOT <= .05s, positive integer completion usage,
one-token TPOT=0, complete exact-ID/HTTP200/SSE and API `stop` conditions.
Length/truncated, rejected/failed/cancelled/timeout contribute no candidate;
all offered IDs/statuses remain reconciled. Missing/duplicate, unresolved
censored or invalid successful rows withhold the point partition. Source
hashes authenticate neither a callback nor an independent physical EOS:
`physical_natural_good` is always **None**, and performance/online-history/
source-authentication/active-permit flags stay false. This API candidate
diagnostic is **not** promoted into the primary physical-natural metric or
a binding reinterpretation of the collector's benchmark rules.

The reproducible two-world witness keeps the same pre-cut progress state and
the exact same incumbent completion. One world has no future offer; the other
adds one later exogenous birth after the incumbent's terminal. The diagnostic
changes total future candidates from one to two while incumbent attribution
remains one. Thus even perfect incumbent prediction leaves the birth-error
term:

```text
total prediction error = incumbent error + unseen-past error + birth error
```

This is an accounting counterexample over hypothetical feasible histories,
not native timing/capacity measurements. Within each world the offered law is
common to candidate caps; changing worlds illustrates arrival-model error,
not cap-induced arrivals. It proves no predictive value for progress by itself.
A separate same-arrival/same-progress continuation changes EOS-at-limit or
terminal TPOT and therefore incumbent candidates. Arrival knowledge alone
does not determine that continuation; the delayed terminal does not identify
exclusive GPU service. Spoofing an EOS Boolean still supplies no physical
receipt. Additional regressions retain unseen-past/marked-unknown groups,
withhold bad future labels without rewriting observations, and align tied
receive-time progress with the original Train audit.

### Actual raw Train check, descriptive only

Independently byte-verified exactly three p4096/m128 arm0 JSONs against the
provided frozen ledger, using one preselected `start + 40s` cut, not a cut/horizon
search. The directory is
`pr33-native-v3-first-three-complete-train-blocks-frozen` in Mayor's supplied
session files. No other outcome partition was opened. These are three
descriptive cuts, **not Train1/2 fitting, fresh Train3 evaluation, causal policy
effects or calibrated coverage**; Train181003 was already used development.

| Train seed | Applied budget / reserved cost | Marked / native visible | G_api at 1/3/5s | 5s visible / marked-unknown / unseen-past / post-cut birth |
|---|---|---|---|---|
| 181001 | 16 / 16.1217386496 | 4 / 4 | 0 / 2 / 2 | 1 / 0 / 0 / 1 |
| 181002 | 32 / 24.1826079744 | 6 / 4 | 1 / 5 / 6 | 4 / 0 / 0 / 2 |
| 181003 | 32 / 28.2130426368 | 7 / 5 | 1 / 2 / 3 | 2 / 0 / 0 / 1 |

Train181002 actually reports a `(computed=4090, output=0, prompt=4096,
max=128)` member alongside decode prefixes. Train181003 reports
`(2039,0,4096,128)` alongside `(4150,54,4096,128)`. These raw observables exist:
older transforms omitting them are not evidence of raw unavailability.
Their executed/useful-work interpretation remains separately unqualified.
The two unseen marks in each latter cut are retained unknown current state;
zero *realized candidate completions* for their group is not zero latent work.
The first cut's reserved cost exceeds its current budget without deletion,
consistent with non-eviction/history rather than concurrency=16.

These selected-cut candidate fractions are not a reproduction/rebuttal of
Mayor's earlier source407a1b46 G5 target/aggregate, its reported post-cut-born
share or its under-covering bands. Better whole-target error with better
arrival inputs would not by itself qualify a service/progress model. No
prediction superiority, native capacity/120% anchor, high-pressure/preemption
qualification, 10-hour actual-duration completion or MPC win is inferred.

Exact input byte receipts:

```text
74da77e6bc936d887da0605085695021827851d38736faf62d512e611579a584  nv3-181001-p4096-m128-arm0.json
3d4f681e0ef0a2e6b45d90bba38c59c945ff6cd918767dbf5dfec5bc1bbf04d7  nv3-181002-p4096-m128-arm0.json
0fadab534bd331afb08090bfde1b2d1a6b8599db77483ec5c7f672553c709215  nv3-181003-p4096-m128-arm0.json
```

Reproduce by reading the frozen ledger, passing each exact JSON byte string
and its ledger digest to `future_api_good_partition`, with
`cut_at=json.loads(raw)["start"] + 40`. The returned observations include raw
progress; `future_api_good` is the separate future-label partition. No final
row publication/send receipt backfill or live collector modification is needed
or performed. R5 native callback integration remains unexecuted.

### Evaluation, support, uncertainty and deployment boundaries

Before any control authority, distinguish three diagnostics at fixed 1/3/5s:
receipt-aligned same-ID native progress/visibility and whole-owner lifecycle;
incumbent versus unseen-past versus future-birth endpoints; and total all-offered
outcomes. Compare inclusion/ablation of progress with the **same exogenous
arrival/payload law**, not a future-arrival oracle secretly supplying service
skill. Joint scenarios must conserve counts/costs and carry tail/replay/visibility
uncertainty. EOS or release marginals sampled independently of that trajectory
can produce impossible stock-flow/outcome combinations. No calibrated bands
or finite-sample guarantees are claimed here.

Future strongOneMove must use the same kernel, admissible single-change
timings/hold, horizons, replanning cadence, SLOs, cost/ACK/observer overhead
and uncertainty as MPC. It may search its qualified one-change possibilities,
not be weakened to a naive immediate-step baseline. MPC's added sequence
choices require native-supported transitions and uncertainty, not arbitrary
average-cap aliases. Native prefix progress information is available, but
its predictive gain and usable horizon must be demonstrated rather than
assumed from the 1--3s response descriptions.

Sequential causal support conditions future randomized actions on **pre**
assignment receipt history, with actual ACK delay and published-prefix/full
assignment sequence retained. Conditioning on a later batch state instead
would remove/change the admission mediation. Current arm divergence does not
qualify same-state effects. OOD includes unseen payload/length mixtures, stale
or missing receipt prefixes, transient/unknown native membership, replay or
KV pressure outside observed support, and unsupported rapid switching.
Out-of-support models withhold authority; native fixed/reactive fallback must
be independently qualified, not improvised from this report.

The earlier frozen physical-natural/statistical **proposal** stays unchanged:
primary MPC-minus-strongOne effect, equal-five-cell then independent complete
seed-block weighting; proposed eight blocks; practical margin .10 good/s;
Holm .05 family across strongOne, best qualified Fixed and best reactive.
Source hashes are custody, **not statistical independence**. Actual independent
sampling/randomization, final manifest, comparison policies, missing/censor
handling and a valid margin/simultaneous-bound method still need sealing before
any Final. A zero-null sign flip plus mean above margin is not a practical-effect
claim. Existing exact 2..16-block refusal and source/configuration/tape guards
are not relaxed. No Calibration/Validation/Final fitting or old reserved
160021..160024 access occurred. This is an independent proposal, not consensus.

### R6 exact local source/test receipt

```text
79226047437dcf35f9d6bfcc54382ec6c05c7d31866313d1b4f012c3143746d6  native_experiment_audit.py
10ec86d4a94996debc9839fb8b63a19a7de597119b508fe047cd58213132bc61  test_native_experiment_audit.py
```

The existing standard-library unittest command passed **45 methods**, no skips,
including five new R6 methods and all preserved receipt/Train/endpoint/block/work
contracts. Frozen R1/R3 replays also passed six/eight pinned digests and
fifteen/thirteen witnesses. Whitespace checks passed. No third-party dependency, native simulator
qualification, model fit, active permit or full/native quality-gate claim.
Only the three owned paths change, committed locally with the Copilot trailer.
No GPU process, push/merge, DB mutation or live protocol change. Mayor retains
in_progress and independent-freeze/peer-exchange management.
