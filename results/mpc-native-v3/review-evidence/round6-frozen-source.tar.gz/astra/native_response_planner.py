"""Bounded, shadow-only native response planning; no plant or actuator implementation."""

from dataclasses import dataclass, replace
from fractions import Fraction
from itertools import product
from math import isclose, isfinite
from typing import Callable, Protocol


CAPS = (16, 32)
OFFSETS = (1.0, 3.0, 5.0)
MAX_REQUESTS = 256
MAX_SCENARIOS = 128


@dataclass(frozen=True)
class Identity:
    """Receipt-bound deployment and process incarnations, not a clock epoch.

    The adapter's epoch must change on Gateway/native run changes even when
    the Pod boot/time namespace and therefore clock_domain remain unchanged.
    """

    deployment: str
    epoch: str
    clock_domain: str
    cost_model: str


@dataclass(frozen=True)
class RequestState:
    """Stage/progress describe the same native prefix as State's counts.

    Awaiting requires an identified native waiting request, not merely a Gateway
    mark without first content. Accepted-but-not-visible work is unknown.
    """

    request_id: str
    original_cost: float
    prompt_tokens: int
    max_output_tokens: int
    observed_output_tokens: int
    stage: str
    age_s: float


@dataclass(frozen=True)
class State:
    state_id: str
    identity: Identity
    origin: float
    sampled_at: float
    received_at: float
    sample_width_s: float
    applied_cap: int
    cap_version: int
    pending_command: bool
    reserved_cost: float
    requests: tuple[RequestState, ...]
    native_waiting: int
    native_running: int
    pending_batches: int
    kv_usage: float
    history_id: str


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    probability: float
    future_offers: int


@dataclass(frozen=True)
class Evaluation:
    """IDs refer to frozen external artifacts, not attestations verified here.

    Good means natural complete, TTFT <= .5s from scheduled offer, and
    (terminal - first content)/(output tokens - 1) <= .05s; one token has TPOT=0.
    All failures/rejections score zero. Old outstanding offers need not be admitted.
    """

    model_id: str
    support_id: str
    future_law_id: str
    uncertainty_id: str
    cohort_id: str
    continuation_id: str
    continuation_development_receipt: str
    tail_rule_id: str
    tail_s: float
    origin_offered_ids: tuple[str, ...]
    scenarios: tuple[Scenario, ...]
    horizon_s: float = 5.0
    slot_s: float = 1.0


@dataclass(frozen=True)
class Timing:
    clock_domain: str
    deadline_at: float
    dispatch_reserve_s: float
    max_age_s: float
    max_sample_width_s: float


@dataclass(frozen=True)
class Plan:
    prefix: tuple[int, ...]
    continuation_id: str


@dataclass(frozen=True)
class Outcome:
    scenario_id: str
    settled_good: int
    unresolved: int
    expected_tail_good: float
    released_origin_ids: tuple[tuple[str, ...], tuple[str, ...], tuple[str, ...]]


@dataclass(frozen=True)
class Prediction:
    state_id: str
    plan: Plan
    evaluation: Evaluation
    outcomes: tuple[Outcome, ...]
    error_below: float
    error_above: float


class ResponseModel(Protocol):
    def predict(
        self, state: State, plan: Plan, evaluation: Evaluation, deadline_at: float
    ) -> Prediction | None:
        """Return None outside joint state/sequence/continuation support."""
        ...


@dataclass(frozen=True)
class Score:
    plan: Plan
    mean_good: float
    lower_good: float
    upper_good: float
    tail_lower: float
    tail_upper: float
    released_origin_cost: tuple[float, ...]


@dataclass(frozen=True)
class Selection:
    best: Score
    first_action_resolved: bool


@dataclass(frozen=True)
class Decision:
    status: str
    reason: str
    shadow_cap: int | None = None
    one_move: Selection | None = None
    two_move: Selection | None = None
    scores: tuple[Score, ...] = ()
    gain_interval: tuple[float, float] | None = None
    elapsed_s: float | None = None

    @property
    def active_permit(self) -> bool:
        return False


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _number(value: float, minimum: float = 0.0) -> bool:
    return type(value) in (float, int) and isfinite(value) and value >= minimum


def _integer(value: int, minimum: int = 0) -> bool:
    return type(value) is int and value >= minimum


def _name(value: str) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _cap(value: int) -> bool:
    return type(value) is int and value in CAPS


def transition_costs(
    live: tuple[tuple[str, float], ...],
    events: tuple[tuple[str, str, float, int], ...],
) -> tuple[tuple[str, float], ...]:
    """Replay ordered (admit/release, id, original cost, actually applied cap)."""
    _require(len(live) <= MAX_REQUESTS and len(events) <= 1024, "ledger size")
    costs = {}
    seen = set()
    for request_id, cost in live:
        _require(_name(request_id) and request_id not in seen, "duplicate live ID")
        _require(_number(cost) and cost > 0, "original cost")
        costs[request_id] = cost
        seen.add(request_id)
    _require(sum(costs.values()) <= max(CAPS), "initial reservation bound")
    for kind, request_id, cost, cap in events:
        _require(_name(request_id) and _number(cost) and cost > 0, "event cost/ID")
        _require(_cap(cap), "unsupported applied cap")
        if kind == "admit":
            _require(request_id not in seen, "reused admission ID")
            _require(sum(costs.values()) + cost <= cap, "projected cost exceeds cap")
            _require(len(costs) < MAX_REQUESTS, "ledger size")
            costs[request_id] = cost
            seen.add(request_id)
        elif kind == "release":
            _require(request_id in costs and costs[request_id] == cost, "release mismatch")
            del costs[request_id]
        else:
            raise ValueError("unknown ledger event")
    return tuple(costs.items())


def _validate_state(state: State, identity: Identity, timing: Timing, now: float) -> None:
    _require(state.identity == identity, "deployment/epoch/cost identity")
    _require(all(_name(x) for x in (
        identity.deployment, identity.epoch, identity.clock_domain, identity.cost_model,
        state.state_id, state.history_id,
    )), "missing identity/history")
    _require(identity.clock_domain == timing.clock_domain, "clock domain")
    _require(all(_number(x) for x in (
        state.origin, state.sampled_at, state.received_at, state.sample_width_s,
        state.reserved_cost, state.kv_usage,
    )), "invalid state numbers")
    _require(state.sampled_at <= state.received_at <= state.origin <= now, "availability")
    _require(now - state.sampled_at <= timing.max_age_s, "stale state")
    _require(state.sample_width_s <= timing.max_sample_width_s, "sample skew")
    _require(_cap(state.applied_cap) and _integer(state.cap_version), "cap/version")
    _require(state.pending_command is False, "pending command")
    _require(all(_integer(x) for x in (
        state.native_waiting, state.native_running, state.pending_batches,
    )) and state.kv_usage <= 1, "batch observation")
    _require(type(state.requests) is tuple and len(state.requests) <= MAX_REQUESTS,
             "mutable/oversized requests")
    ledger = tuple((r.request_id, r.original_cost) for r in state.requests)
    transition_costs(ledger, ())
    _require(isclose(sum(c for _, c in ledger), state.reserved_cost,
                     rel_tol=0, abs_tol=1e-9), "reservation conservation")
    for request in state.requests:
        _require(_integer(request.prompt_tokens, 1)
                 and _integer(request.max_output_tokens, 1)
                 and _integer(request.observed_output_tokens)
                 and request.observed_output_tokens <= request.max_output_tokens,
                 "token observation")
        _require(request.stage in ("awaiting", "prefill", "decode", "release_pending"),
                 "unknown native work")
        _require(_number(request.age_s), "request age")
        if request.stage in ("awaiting", "prefill"):
            _require(request.observed_output_tokens == 0, "stage/progress mismatch")
        elif request.stage == "decode":
            _require(request.observed_output_tokens > 0, "stage/progress mismatch")
    _require(state.native_running == sum(
        r.stage in ("prefill", "decode") for r in state.requests
    ), "native running/stage mismatch")
    _require(state.native_waiting == sum(
        r.stage == "awaiting" for r in state.requests
    ), "native waiting/stage mismatch")


def _validate_evaluation(state: State, evaluation: Evaluation) -> None:
    _require(all(_name(x) for x in (
        evaluation.model_id, evaluation.support_id, evaluation.future_law_id,
        evaluation.uncertainty_id, evaluation.cohort_id, evaluation.continuation_id,
        evaluation.continuation_development_receipt, evaluation.tail_rule_id,
    )), "missing model/evaluation receipt")
    _require(_number(evaluation.horizon_s) and _number(evaluation.slot_s)
             and evaluation.horizon_s == 5.0 and evaluation.slot_s == 1.0,
             "fixed five-second evaluation/two one-second moves")
    _require(_number(evaluation.tail_s), "tail duration")
    ids = evaluation.origin_offered_ids
    _require(type(ids) is tuple and len(ids) <= MAX_REQUESTS
             and all(_name(x) for x in ids) and len(set(ids)) == len(ids),
             "origin cohort")
    _require({r.request_id for r in state.requests}.issubset(ids), "missing live cohort")
    _require(type(evaluation.scenarios) is tuple
             and 1 <= len(evaluation.scenarios) <= MAX_SCENARIOS, "scenario bound")
    ids = set()
    for scenario in evaluation.scenarios:
        _require(_name(scenario.scenario_id) and scenario.scenario_id not in ids,
                 "scenario identity")
        ids.add(scenario.scenario_id)
        _require(_number(scenario.probability) and scenario.probability > 0
                 and _integer(scenario.future_offers), "future law")
    _require(isclose(sum(s.probability for s in evaluation.scenarios), 1.0,
                     rel_tol=0, abs_tol=1e-12), "scenario probabilities")


def _score(state: State, plan: Plan, evaluation: Evaluation, prediction: Prediction) -> Score:
    _require(prediction.state_id == state.state_id and prediction.plan == plan
             and prediction.evaluation == evaluation, "prediction binding")
    _require(type(prediction.outcomes) is tuple
             and len(prediction.outcomes) == len(evaluation.scenarios), "outcome count")
    _require(_number(prediction.error_below) and _number(prediction.error_above),
             "model uncertainty")
    mean = lower = upper = offered = 0.0
    release = [0.0] * len(OFFSETS)
    original_costs = {r.request_id: r.original_cost for r in state.requests}
    for scenario, outcome in zip(evaluation.scenarios, prediction.outcomes):
        _require(outcome.scenario_id == scenario.scenario_id, "joint scenario pairing")
        cohort_size = len(evaluation.origin_offered_ids) + scenario.future_offers
        _require(_integer(outcome.settled_good) and _integer(outcome.unresolved)
                 and outcome.settled_good + outcome.unresolved <= cohort_size,
                 "all-offered accounting")
        _require(_number(outcome.expected_tail_good)
                 and outcome.expected_tail_good <= outcome.unresolved, "tail expectation")
        trajectory = outcome.released_origin_ids
        _require(type(trajectory) is tuple and len(trajectory) == len(OFFSETS)
                 and all(type(ids) is tuple and len(ids) <= len(original_costs)
                         for ids in trajectory), "release trajectory")
        previous_ids = set()
        for i, ids in enumerate(trajectory):
            _require(all(_name(x) for x in ids) and len(set(ids)) == len(ids),
                     "duplicate/invalid release ID")
            current_ids = set(ids)
            _require(previous_ids <= current_ids <= original_costs.keys(),
                     "origin-cost conservation")
            release[i] += scenario.probability * sum(original_costs[x] for x in ids)
            previous_ids = current_ids
        p = scenario.probability
        lower += p * outcome.settled_good
        upper += p * (outcome.settled_good + outcome.unresolved)
        mean += p * (outcome.settled_good + outcome.expected_tail_good)
        offered += p * cohort_size
    return Score(plan, mean, max(0.0, lower - prediction.error_below),
                 min(offered, upper + prediction.error_above), lower, upper, tuple(release))


def _select(scores: tuple[Score, ...], applied_cap: int) -> Selection:
    best = max(scores, key=lambda score: (
        score.mean_good, score.plan.prefix[0] == applied_cap,
        tuple(-cap for cap in score.plan.prefix),
    ))
    other_upper = max(score.upper_good for score in scores
                      if score.plan.prefix[0] != best.plan.prefix[0])
    return Selection(best, best.lower_good > other_upper)


def plan_response(
    state: State,
    evaluation: Evaluation,
    model: ResponseModel,
    *,
    expected_identity: Identity,
    timing: Timing,
    clock: Callable[[], float],
    current_inputs: Callable[[], tuple[State, Evaluation]] | None = None,
) -> Decision:
    """Compare two One-move and four two-move plans, or issue no recommendation.

    Model and input-fence callbacks must cooperate with the deadline. Neither
    can be preempted here. The publisher must atomically return its latest
    receipt-cut State/Evaluation; any update invalidates this planning pass.
    This read is not an actuator CAS or proof of artifact authenticity.

    Agreement on the best first action deliberately retains One-move's
    resolution gate, even if only two-move resolves it. This conservative policy
    is not optimality, a claim of equivalent behavior, or a closed-loop theorem.
    """
    previous = None
    started = None

    def checked_clock() -> float:
        nonlocal previous
        now = clock()
        _require(_number(now) and (previous is None or now >= previous), "clock regression")
        previous = now
        _require(now < timing.deadline_at - timing.dispatch_reserve_s, "deadline")
        return now

    def check_inputs() -> None:
        if current_inputs is None:
            raise ValueError("missing input fence")
        latest = current_inputs()
        _require(type(latest) is tuple and len(latest) == 2
                 and latest == (state, evaluation), "planning inputs changed")

    try:
        _require(_number(timing.deadline_at)
                 and all(_number(x) for x in (
                     timing.dispatch_reserve_s, timing.max_age_s, timing.max_sample_width_s,
                 )), "invalid timing")
        started = checked_clock()
        _validate_state(state, expected_identity, timing, started)
        _validate_evaluation(state, evaluation)
        check_inputs()
        plans = tuple(Plan(prefix, evaluation.continuation_id)
                      for length in (1, 2) for prefix in product(CAPS, repeat=length))
        scores = []
        for plan in plans:
            now = checked_clock()
            _validate_state(state, expected_identity, timing, now)
            now = checked_clock()
            _require(now - state.sampled_at <= timing.max_age_s, "stale state")
            prediction = model.predict(
                state, plan, evaluation, timing.deadline_at - timing.dispatch_reserve_s
            )
            checked_clock()
            _require(prediction is not None, "unsupported state/plan/continuation")
            scores.append(_score(state, plan, evaluation, prediction))
        one = _select(tuple(scores[:2]), state.applied_cap)
        two = _select(tuple(scores[2:]), state.applied_cap)
        gain = (two.best.lower_good - one.best.upper_good,
                two.best.upper_good - one.best.lower_good)
        chosen = one
        reason = "strong One-move retained"
        same_first = two.best.plan.prefix[0] == one.best.plan.prefix[0]
        if not same_first:
            if gain[0] > 0 and two.first_action_resolved:
                chosen, reason = two, "two-move shadow advantage"
            else:
                reason = "two-move advantage unresolved; retain strong One-move"
        finished = checked_clock()
        _validate_state(state, expected_identity, timing, finished)
        check_inputs()
        finished = checked_clock()
        _require(finished - state.sampled_at <= timing.max_age_s, "stale state")
        if not chosen.first_action_resolved:
            fallback_reason = ("same first action; strong One-move unresolved"
                               if same_first and two.first_action_resolved
                               else "first-action uncertainty")
            return Decision("fallback", fallback_reason, one_move=one,
                            two_move=two, scores=tuple(scores), gain_interval=gain,
                            elapsed_s=finished - started)
        return Decision("shadow", reason, chosen.best.plan.prefix[0], one, two,
                        tuple(scores), gain, finished - started)
    except Exception as error:
        elapsed = None if started is None or previous is None else previous - started
        return Decision("fallback", f"{type(error).__name__}: {error}", elapsed_s=elapsed)


@dataclass(frozen=True)
class FlowRequest:
    """Client outcome marks in seconds relative to the receipt-cut origin."""

    request_id: str
    original_cost: float
    offered_at: float
    prompt_tokens: int
    max_output_tokens: int
    output_tokens: int = 0
    first_at: float | None = None
    terminal_at: float | None = None
    natural_eos: bool = False
    rejected: bool = False


@dataclass(frozen=True)
class FlowView:
    at_s: float
    requested_cap: int
    applied_cap: int
    live: tuple[tuple[str, float], ...]
    native: tuple[int | None, int | None, int | None, float | None]
    native_received_at: float
    requests: tuple[FlowRequest, ...]


@dataclass(frozen=True)
class FlowState:
    requests: tuple[FlowRequest, ...]
    history: tuple[FlowView, ...]
    memory: tuple[float, ...]


@dataclass(frozen=True)
class FlowEvent:
    at_s: float
    kind: str
    request_id: str = ""
    output_tokens: int = 0
    natural_eos: bool = False
    cap: int | None = None


@dataclass(frozen=True)
class FlowStep:
    events: tuple[FlowEvent, ...]
    memory: tuple[float, ...]
    native: tuple[int | None, int | None, int | None, float | None]
    native_received_at: float


@dataclass(frozen=True)
class JointPath:
    scenario_id: str
    seed: FlowState
    offers: tuple[FlowRequest, ...]
    innovations: tuple[tuple[float, ...], ...]


class JointKernel(Protocol):
    def step(
        self, state: FlowState, requested_cap: int, offers: tuple[FlowRequest, ...],
        innovation: tuple[float, ...], end_s: float, deadline_at: float,
    ) -> FlowStep | None:
        """One joint short-step law, not independent per-request hazards."""
        ...


def _signed_number(value: float) -> bool:
    return type(value) in (float, int) and isfinite(value)


def _vector(values: tuple[float, ...]) -> bool:
    return (type(values) is tuple and len(values) <= 32
            and all(_signed_number(x) for x in values))


def _flow_request(request: FlowRequest, now: float) -> None:
    _require(_name(request.request_id) and _number(request.original_cost)
             and request.original_cost > 0 and _signed_number(request.offered_at)
             and request.offered_at <= now, "flow offer")
    _require(_integer(request.prompt_tokens, 1)
             and _integer(request.max_output_tokens, 1)
             and _integer(request.output_tokens)
             and request.output_tokens <= request.max_output_tokens, "flow tokens")
    _require(type(request.natural_eos) is bool and type(request.rejected) is bool,
             "flow status")
    _require((request.first_at is None) == (request.output_tokens == 0),
             "flow first/output")
    if request.first_at is not None:
        _require(_signed_number(request.first_at)
                 and request.offered_at <= request.first_at <= now, "flow first time")
    if request.terminal_at is not None:
        _require(_signed_number(request.terminal_at)
                 and request.offered_at <= request.terminal_at <= now
                 and (request.first_at is None or request.first_at <= request.terminal_at),
                 "flow terminal time")
    _require(not request.natural_eos or (
        request.terminal_at is not None and request.output_tokens > 0
        and not request.rejected), "flow EOS")
    _require(not request.rejected or (
        request.output_tokens == 0 and request.terminal_at is None
        and not request.natural_eos), "flow rejection")


def _native_view(native: tuple, received_at: float, now: float) -> None:
    _require(type(native) is tuple and len(native) == 4
             and all(x is None or _integer(x) for x in native[:3])
             and (native[3] is None or (_number(native[3]) and native[3] <= 1)),
             "flow native observation")
    _require(_signed_number(received_at) and received_at <= now, "flow receipt cut")


def _good(request: FlowRequest) -> bool:
    return (request.natural_eos and not request.rejected
            and request.first_at - request.offered_at <= .5
            and (request.output_tokens == 1
                 or (request.terminal_at - request.first_at)
                 / (request.output_tokens - 1) <= .05))


def _advance_flow(
    state: FlowState, requested_cap: int, offers: tuple[FlowRequest, ...],
    step: FlowStep, end_s: float,
) -> FlowState:
    previous = state.history[-1]
    _require(type(step.events) is tuple and len(step.events) <= 1024
             and _vector(step.memory), "flow step bound")
    _native_view(step.native, step.native_received_at, end_s)
    _require(step.native_received_at >= previous.native_received_at,
             "flow receipt regression")
    times = tuple(event.at_s for event in step.events)
    _require(all(_number(t) and previous.at_s < t <= end_s for t in times)
             and tuple(sorted(times)) == times, "flow event chronology")
    _require(not set(times).intersection(r.offered_at for r in offers),
             "unresolved offer/event tie")
    records = {r.request_id: r for r in state.requests}
    live = previous.live
    applied = previous.applied_cap
    ordered = [(r.offered_at, r) for r in offers] + [(e.at_s, e) for e in step.events]
    for _, item in sorted(ordered, key=lambda pair: pair[0]):
        if isinstance(item, FlowRequest):
            _require(item.request_id not in records, "reused flow offer")
            admitted = (sum(Fraction(cost) for _, cost in live)
                        + Fraction(item.original_cost) <= applied)
            _require(admitted == (sum(cost for _, cost in live)
                                  + item.original_cost <= applied),
                     "flow cost arithmetic ambiguous")
            if admitted:
                live = transition_costs(
                    live, (("admit", item.request_id, item.original_cost, applied),))
            records[item.request_id] = replace(item, rejected=not admitted)
            continue
        _require(_integer(item.output_tokens) and type(item.natural_eos) is bool,
                 "flow event mark")
        if item.kind == "apply":
            _require(item.request_id == "" and _cap(item.cap)
                     and item.cap == requested_cap and item.output_tokens == 0
                     and item.natural_eos is False, "flow command application")
            applied = item.cap
            continue
        _require(item.cap is None and item.request_id in dict(live), "flow live event")
        request = records[item.request_id]
        if item.kind == "progress":
            _require(request.terminal_at is None and item.natural_eos is False
                     and request.output_tokens < item.output_tokens
                     <= request.max_output_tokens, "flow progress")
            request = replace(request, output_tokens=item.output_tokens,
                              first_at=(item.at_s if request.first_at is None
                                        else request.first_at))
        elif item.kind == "terminal":
            _require(request.terminal_at is None and item.output_tokens == 0,
                     "duplicate/invalid flow terminal")
            request = replace(request, terminal_at=item.at_s, natural_eos=item.natural_eos)
        elif item.kind == "release":
            _require(request.terminal_at is not None and item.output_tokens == 0
                     and item.natural_eos is False, "flow release before terminal")
            live = transition_costs(
                live, (("release", item.request_id, request.original_cost, applied),))
        else:
            raise ValueError("unknown flow event")
        _flow_request(request, end_s)
        records[item.request_id] = request
    view = FlowView(end_s, requested_cap, applied, live, step.native,
                    step.native_received_at, tuple(records.values()))
    return FlowState(tuple(records.values()), state.history + (view,), step.memory)


@dataclass(frozen=True)
class ShortStepResponse:
    """Opt-in free-running composition; supplied laws/widths are not qualified.

    Fixed .25s integration, at most160 steps,256 total offers and128 joint paths.
    No default kernel, seed adapter, fitted coefficients or native authority.
    """

    state: State
    evaluation: Evaluation
    paths: tuple[JointPath, ...]
    kernel: JointKernel
    continuation: Callable[[tuple[FlowView, ...], float], int]
    clock: Callable[[], float]
    error_below: float
    error_above: float

    def predict(
        self, state: State, plan: Plan, evaluation: Evaluation, deadline_at: float,
    ) -> Prediction | None:
        previous_clock = None

        def check_clock():
            nonlocal previous_clock
            now = self.clock()
            _require(_number(now) and _number(deadline_at) and now < deadline_at
                     and (previous_clock is None or now >= previous_clock),
                     "flow deadline/clock")
            previous_clock = now

        check_clock()
        _require(state == self.state and evaluation == self.evaluation, "flow binding")
        _validate_evaluation(state, evaluation)
        _require(type(plan.prefix) is tuple and 1 <= len(plan.prefix) <= 2
                 and all(_cap(cap) for cap in plan.prefix)
                 and plan.continuation_id == evaluation.continuation_id, "flow plan")
        _require(_number(self.error_below) and _number(self.error_above),
                 "flow model uncertainty")
        step_count = (evaluation.horizon_s + evaluation.tail_s) * 4
        _require(_number(step_count) and step_count <= 160
                 and step_count == int(step_count), "flow time bound")
        _require(type(self.paths) is tuple and len(self.paths) == len(evaluation.scenarios),
                 "flow joint paths")
        outcomes = []
        origin_live = tuple((r.request_id, r.original_cost) for r in state.requests)
        for path, scenario in zip(self.paths, evaluation.scenarios):
            check_clock()
            flow = path.seed
            _require(path.scenario_id == scenario.scenario_id
                     and type(flow.requests) is tuple
                     and tuple(r.request_id for r in flow.requests)
                     == evaluation.origin_offered_ids, "flow origin cohort")
            _require(type(flow.history) is tuple and len(flow.history) == 1
                     and _vector(flow.memory), "flow seed")
            _require(flow.requests == self.paths[0].seed.requests
                     and flow.history == self.paths[0].seed.history,
                     "flow observed seed mismatch")
            initial = flow.history[0]
            _require(initial == FlowView(
                0.0, state.applied_cap, state.applied_cap, origin_live,
                (state.native_running, state.native_waiting, state.pending_batches,
                 state.kv_usage), state.received_at - state.origin, flow.requests),
                     "flow seed observation")
            for request in flow.requests:
                _flow_request(request, 0.0)
                if request.request_id not in dict(origin_live):
                    _require(request.rejected or request.terminal_at is not None,
                             "unobserved origin admission")
            records = {r.request_id: r for r in flow.requests}
            for old in state.requests:
                r = records[old.request_id]
                _require(not r.rejected and r.original_cost == old.original_cost
                         and r.prompt_tokens == old.prompt_tokens
                         and r.max_output_tokens == old.max_output_tokens
                         and r.output_tokens == old.observed_output_tokens
                         and (r.terminal_at is not None) == (old.stage == "release_pending"),
                         "flow origin reconciliation")
            _require(type(path.offers) is tuple
                     and len(path.offers) + len(flow.requests) <= MAX_REQUESTS
                     and type(path.innovations) is tuple
                     and len(path.innovations) == int(step_count)
                     and all(_vector(w) for w in path.innovations), "flow path bound")
            offered_ids = set(records)
            last_offer = 0.0
            for offer in path.offers:
                _flow_request(offer, step_count / 4)
                _require(offer.request_id not in offered_ids
                         and last_offer <= offer.offered_at
                         and offer.output_tokens == 0 and offer.terminal_at is None
                         and not offer.rejected and not offer.natural_eos, "flow future offer")
                offered_ids.add(offer.request_id)
                last_offer = offer.offered_at
            _require(sum(r.offered_at < 5 for r in path.offers) == scenario.future_offers,
                     "flow future-law count")
            releases = []
            at_horizon = None
            cap = None
            for index, innovation in enumerate(path.innovations):
                check_clock()
                if index % 4 == 0:
                    slot = index // 4
                    cap = (plan.prefix[slot] if slot < len(plan.prefix)
                           else self.continuation(flow.history, deadline_at))
                    check_clock()
                    _require(_cap(cap), "flow continuation")
                start, end = index / 4, (index + 1) / 4
                offers = tuple(r for r in path.offers if (
                    start < r.offered_at <= end or index == 0 and r.offered_at == 0))
                step = self.kernel.step(flow, cap, offers, innovation, end, deadline_at)
                check_clock()
                if step is None:
                    return None
                flow = _advance_flow(flow, cap, offers, step, end)
                if end in OFFSETS:
                    live_ids = dict(flow.history[-1].live)
                    releases.append(tuple(rid for rid, _ in origin_live if rid not in live_ids))
                if end == 5:
                    at_horizon = flow
            cohort = set(evaluation.origin_offered_ids) | {
                r.request_id for r in path.offers if r.offered_at < 5}
            horizon_records = [r for r in at_horizon.requests if r.request_id in cohort]
            unresolved_ids = {r.request_id for r in horizon_records
                              if r.terminal_at is None and not r.rejected}
            final_records = {r.request_id: r for r in flow.requests}
            if any(final_records[rid].terminal_at is None for rid in unresolved_ids):
                return None
            outcomes.append(Outcome(
                scenario.scenario_id, sum(_good(r) for r in horizon_records),
                len(unresolved_ids), sum(_good(final_records[rid]) for rid in unresolved_ids),
                tuple(releases)))
        check_clock()
        return Prediction(state.state_id, plan, evaluation, tuple(outcomes),
                          self.error_below, self.error_above)


def nested_family_diagnostic(decision: Decision, applied_cap: int) -> Selection:
    """Score-only union of One/two policies; never change the default decision."""
    expected = tuple(prefix for length in (1, 2) for prefix in product(CAPS, repeat=length))
    _require(_cap(applied_cap) and tuple(s.plan.prefix for s in decision.scores) == expected
             and len({s.plan.continuation_id for s in decision.scores}) == 1,
             "complete common-contract scores required")
    return _select(decision.scores, applied_cap)


@dataclass(frozen=True)
class BatchProgress:
    """Latent non-speculative forward state, NOT a raw native-frame adapter.

    Native commits are atomic in this restricted transition. Delivered tokens,
    ledger release and physical overhang remain separate events/stocks.
    """

    request_id: str
    prompt_tokens: int
    max_output_tokens: int
    prompt_done: int
    native_tokens: int
    decode_done: int
    eos_at: int | None
    finish_reason: str | None = None
    queued_overhang: int = 0
    executed_overhang: int = 0


def _batch_progress_valid(request: BatchProgress) -> None:
    _require(_name(request.request_id)
             and _integer(request.prompt_tokens, 1)
             and _integer(request.max_output_tokens, 1)
             and all(_integer(v) for v in (
                 request.prompt_done, request.native_tokens, request.decode_done,
                 request.queued_overhang, request.executed_overhang,
             )), "batch progress fields")
    _require(request.prompt_done <= request.prompt_tokens
             and request.native_tokens <= request.max_output_tokens
             and (request.eos_at is None or (
                 _integer(request.eos_at, 1)
                 and request.native_tokens <= request.eos_at <= request.max_output_tokens)),
             "batch progress bounds")
    _require((request.prompt_done == request.prompt_tokens) == (request.native_tokens > 0)
             and request.decode_done == max(0, request.native_tokens - 1),
             "atomic non-speculative prefix required")
    reason = ("stop" if request.eos_at is not None and request.native_tokens == request.eos_at
              else "length" if request.native_tokens == request.max_output_tokens else None)
    _require(request.finish_reason == reason, "batch EOS/length distinction")


def advance_joint_forward(
    requests: tuple[BatchProgress, ...],
    allocation: tuple[tuple[str, int, int, int], ...],
) -> tuple[BatchProgress, ...]:
    """Apply one supplied joint forward: (id, prefill positions, decode, overhang).

    No cap, cost, clock, learned service rate or scheduler policy is an input.
    The producer must qualify joint allocation feasibility and completion time.
    """
    _require(type(requests) is tuple and len(requests) <= MAX_REQUESTS
             and type(allocation) is tuple and len(allocation) <= len(requests),
             "joint forward bound")
    current = {}
    for request in requests:
        _batch_progress_valid(request)
        _require(request.request_id not in current, "duplicate batch ID")
        current[request.request_id] = request
    seen = set()
    for item in allocation:
        _require(type(item) is tuple and len(item) == 4, "joint forward allocation")
        rid, prefill, decode, overhang = item
        _require(rid in current and rid not in seen, "joint forward identity")
        seen.add(rid)
        _require(all(_integer(v) for v in (prefill, decode, overhang))
                 and decode <= 1 and overhang <= 1
                 and sum(v > 0 for v in (prefill, decode, overhang)) <= 1,
                 "one request contribution per forward")
        request = current[rid]
        if overhang:
            _require(request.finish_reason is not None and request.queued_overhang > 0,
                     "overhang requires preexisting queued work")
            request = replace(request, queued_overhang=request.queued_overhang - 1,
                              executed_overhang=request.executed_overhang + 1)
        elif prefill or decode:
            _require(request.finish_reason is None, "productive work after finish")
            if prefill:
                _require(request.native_tokens == 0
                         and prefill <= request.prompt_tokens - request.prompt_done,
                         "prefill allocation exceeds residual")
                done = request.prompt_done + prefill
                request = replace(request, prompt_done=done,
                                  native_tokens=int(done == request.prompt_tokens))
            else:
                _require(request.native_tokens > 0, "decode before prefill")
                request = replace(request, decode_done=request.decode_done + 1,
                                  native_tokens=request.native_tokens + 1)
            reason = ("stop" if request.native_tokens == request.eos_at
                      else "length" if request.native_tokens == request.max_output_tokens
                      else None)
            request = replace(request, finish_reason=reason)
        _batch_progress_valid(request)
        current[rid] = request
    return tuple(current.values())
