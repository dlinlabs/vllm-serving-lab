"""Contract witnesses only; the stub below is not a native fitted response model."""

from dataclasses import replace
import copy
import hashlib
import importlib.util
import os
from pathlib import Path
import random
import sys
import unittest
from unittest.mock import patch

import native_response_planner as planner
from native_response_planner import (
    Decision, Evaluation, Identity, Outcome, Prediction, RequestState, Scenario,
    State, Timing, plan_response, transition_costs,
)


IDENTITY = Identity("test-deployment", "test-epoch", "test-clock", "test-cost")


def state():
    return State(
        "test-state", IDENTITY, 10.0, 9.9, 9.95, .01, 16, 4, False, 8.0,
        (RequestState("old", 8.0, 4096, 128, 2, "decode", .2),),
        0, 1, 0, .1, "test-received-history",
    )


def evaluation():
    return Evaluation(
        "test-model", "test-support", "test-future-law", "test-uncertainty",
        "test-cohort", "development-selected-reactive", "test-development-receipt",
        "test-tail-rule", 30.0, ("old",), (Scenario("joint-test-draw", 1.0, 9),),
    )


class StubModel:
    def __init__(self):
        self.calls = []
        self.values = {(16,): 4, (32,): 2, (16, 16): 3,
                       (16, 32): 4, (32, 16): 8, (32, 32): 5}
        self.transform = lambda prediction: prediction

    def predict(self, state, plan, evaluation, deadline_at):
        self.calls.append((state, plan, evaluation, deadline_at))
        outcome = Outcome(evaluation.scenarios[0].scenario_id,
                          self.values[plan.prefix], 0, 0.0, ((), ("old",), ("old",)))
        return self.transform(Prediction(state.state_id, plan, evaluation,
                                         (outcome,), 0.0, 0.0))


def agreement_model():
    """Gemini's R2 numeric witness through the real injected-response interface."""
    model = StubModel()
    bands = {
        (16,): (9, 5, 2.5), (32,): (8, 5, 2.5),
        (16, 16): (10, 2, 1), (16, 32): (15, 5, 2.5),
        (32, 16): (5, 2, 1), (32, 32): (6, 2, 1),
    }

    def prediction(p):
        good, unresolved, expected_tail = bands[p.plan.prefix]
        return replace(p, outcomes=(Outcome(
            "joint-test-draw", good, unresolved, expected_tail, ((), ("old",), ("old",)),
        ),))

    model.transform = prediction
    law = replace(evaluation(), scenarios=(Scenario("joint-test-draw", 1.0, 19),))
    return model, law


class PlannerTests(unittest.TestCase):
    def run_plan(self, model=None, **kwargs):
        snapshot = kwargs.pop("state", state())
        law = kwargs.pop("evaluation", evaluation())
        return plan_response(
            snapshot, law, model or StubModel(),
            expected_identity=kwargs.pop("expected_identity", IDENTITY),
            timing=kwargs.pop("timing", Timing("test-clock", 10.1, .02, .5, .05)),
            clock=kwargs.pop("clock", lambda: 10.0),
            current_inputs=kwargs.pop("current_inputs", lambda: (snapshot, law)), **kwargs,
        )

    def test_complete_bounded_search_uses_identical_contract_and_strong_continuation(self):
        model = StubModel()
        result = self.run_plan(model)
        self.assertEqual(result.status, "shadow")
        self.assertEqual(result.shadow_cap, 32)
        self.assertEqual(result.one_move.best.plan.prefix, (16,))
        self.assertEqual(result.two_move.best.plan.prefix, (32, 16))
        self.assertEqual(result.gain_interval, (4.0, 4.0))
        self.assertEqual([call[1].prefix for call in model.calls],
                         [(16,), (32,), (16, 16), (16, 32), (32, 16), (32, 32)])
        self.assertTrue(all(call[2] is model.calls[0][2] for call in model.calls))
        self.assertTrue(all(call[1].continuation_id == evaluation().continuation_id
                            and call[3] == 10.08 for call in model.calls))
        self.assertFalse(result.active_permit)

    def test_no_default_model_or_permit_even_with_declared_receipts(self):
        self.assertEqual(self.run_plan(object()).status, "fallback")
        self.assertFalse(Decision("shadow", "not evidence", 32).active_permit)

    def test_same_first_action_retains_one_move_even_with_larger_open_loop_score(self):
        model = StubModel()
        model.values[(16, 32)] = 9
        result = self.run_plan(model)
        self.assertEqual(result.shadow_cap, 16)
        self.assertEqual(result.reason, "strong One-move retained")

    def test_uncertainty_overlap_does_not_authorize_point_estimate_winner(self):
        model = StubModel()
        model.transform = lambda p: replace(p, error_below=5, error_above=5)
        result = self.run_plan(model)
        self.assertEqual(result.status, "fallback")
        self.assertIsNone(result.shadow_cap)
        self.assertEqual(result.two_move.best.mean_good, 8)

    def test_tail_expectation_not_settled_count_ranks_but_bounds_prevent_false_certainty(self):
        model = StubModel()

        def tail(p):
            if p.plan.prefix == (32,):
                return replace(p, outcomes=(Outcome("joint-test-draw", 1, 8, 8,
                                                    ((), ("old",), ("old",))),))
            return p

        model.transform = tail
        result = self.run_plan(model)
        self.assertEqual(result.one_move.best.plan.prefix, (32,))
        self.assertEqual(result.one_move.best.mean_good, 9)
        self.assertEqual((result.one_move.best.tail_lower, result.one_move.best.tail_upper),
                         (1, 9))
        self.assertEqual(result.status, "fallback")

    def test_missing_one_move_continuation_support_aborts_not_weakens_baseline(self):
        model = StubModel()
        model.transform = lambda p: None if len(p.plan.prefix) == 1 else p
        result = self.run_plan(model)
        self.assertEqual(result.status, "fallback")
        self.assertIn("unsupported", result.reason)
        self.assertEqual(len(model.calls), 1)

    def test_unknown_or_missing_last_candidate_aborts_partial_optimization(self):
        model = StubModel()
        model.transform = lambda p: None if p.plan.prefix == (32, 32) else p
        result = self.run_plan(model)
        self.assertIsNone(result.shadow_cap)
        self.assertEqual(result.scores, ())
        self.assertEqual(len(model.calls), 6)

    def test_state_fences_fail_before_model(self):
        changes = (
            {"identity": replace(IDENTITY, epoch="other")},
            {"identity": replace(IDENTITY, cost_model="other")},
            {"sampled_at": 9.0}, {"received_at": 10.01}, {"origin": float("nan")},
            {"sample_width_s": .06}, {"reserved_cost": 4.0}, {"pending_command": True},
            {"applied_cap": 24}, {"kv_usage": float("inf")}, {"cap_version": True},
            {"requests": (replace(state().requests[0], stage="unknown"),)},
            {"requests": (replace(state().requests[0], original_cost=-1),)},
            {"requests": (state().requests[0], state().requests[0])},
        )
        for change in changes:
            with self.subTest(change=change):
                model = StubModel()
                self.assertEqual(self.run_plan(model, state=replace(state(), **change)).status,
                                 "fallback")
                self.assertEqual(model.calls, [])

    def test_clock_domain_invalid_deadline_and_regression(self):
        for timing in (Timing("other", 10.1, .02, .5, .05),
                       Timing("test-clock", float("nan"), .02, .5, .05),
                       Timing("test-clock", 10.02, .02, .5, .05)):
            self.assertEqual(self.run_plan(timing=timing).status, "fallback")
        ticks = iter((10.0, 9.99))
        self.assertIn("clock regression", self.run_plan(clock=lambda: next(ticks)).reason)

    def test_deadline_includes_callback_and_reserves_dispatch_time(self):
        ticks = iter((10.0, 10.0, 10.0, 10.081))
        model = StubModel()
        result = self.run_plan(model, clock=lambda: next(ticks))
        self.assertEqual(result.status, "fallback")
        self.assertIn("deadline", result.reason)
        self.assertEqual(len(model.calls), 1)
        self.assertGreater(result.elapsed_s, .08)

    def test_state_that_expires_during_evaluation_aborts(self):
        ticks = iter((10.0, 10.0, 10.0, 10.01, 10.02))
        result = self.run_plan(clock=lambda: next(ticks),
                               timing=Timing("test-clock", 10.1, .02, .11, .05))
        self.assertIn("stale", result.reason)

    def test_prediction_contract_pairing_accounting_and_release_validation(self):
        transformations = (
            lambda p: replace(p, state_id="future-state"),
            lambda p: replace(p, evaluation=replace(p.evaluation, horizon_s=1)),
            lambda p: replace(p, plan=replace(p.plan, continuation_id="weak-fixed16")),
            lambda p: replace(p, error_above=float("nan")),
            lambda p: replace(p, outcomes=p.outcomes * 2),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0], scenario_id="other"),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0], settled_good=11),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0], settled_good=True),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0], expected_tail_good=1),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0],
                                                   released_origin_ids=(("old",), (), ("old",))),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0],
                                                   released_origin_ids=((), (), ("new",))),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0],
                                                   released_origin_ids=((), (), ("old", "old"))),)),
        )
        for transform in transformations:
            with self.subTest(transform=transform):
                model = StubModel()
                model.transform = transform
                self.assertEqual(self.run_plan(model).status, "fallback")

    def test_joint_weighting_and_tail_model_uncertainty_remain_distinct(self):
        model = StubModel()
        law = replace(evaluation(), scenarios=(Scenario("a", .25, 9), Scenario("b", .75, 3)))

        def joint(p):
            return replace(p, outcomes=(
                Outcome("a", 6, 2, 1, ((), ("old",), ("old",))),
                Outcome("b", 1, 1, .5, ((), (), ("old",))),
            ), error_below=.2, error_above=.4)

        model.transform = joint
        score = self.run_plan(model, evaluation=law).scores[0]
        self.assertEqual(score.mean_good, 2.875)
        self.assertEqual((score.tail_lower, score.tail_upper), (2.25, 3.5))
        self.assertEqual((score.lower_good, score.upper_good), (2.05, 3.9))
        self.assertEqual(score.released_origin_cost, (0, 2, 8))

    def test_invalid_or_unbounded_evaluation_is_rejected_without_predicting(self):
        for change in (
            {"horizon_s": 1.0}, {"slot_s": 2.0}, {"slot_s": True},
            {"tail_s": float("nan")},
            {"continuation_development_receipt": ""},
            {"origin_offered_ids": ()}, {"origin_offered_ids": ("old", "old")},
            {"scenarios": ()}, {"scenarios": evaluation().scenarios * 129},
            {"scenarios": (Scenario("x", .9, 3),)},
            {"scenarios": (Scenario("x", 1, -1),)},
            {"scenarios": (Scenario("x", .5, 1), Scenario("x", .5, 1))},
        ):
            model = StubModel()
            self.assertEqual(self.run_plan(model, evaluation=replace(evaluation(), **change)).status,
                             "fallback")
            self.assertEqual(model.calls, [])

    def test_unadmitted_old_offers_stay_in_cohort_without_fake_reserved_work(self):
        model = StubModel()
        model.values = {prefix: 11 for prefix in model.values}
        result = self.run_plan(
            model, evaluation=replace(evaluation(), origin_offered_ids=("old", "not-admitted"))
        )
        self.assertEqual(len(result.scores), 6)
        self.assertEqual(result.scores[0].mean_good, 11)
        self.assertEqual(result.scores[0].released_origin_cost[-1], 8)

    def test_model_exception_is_no_command_not_fixed16_actuation(self):
        model = StubModel()

        def fail(_):
            raise RuntimeError("model unavailable")

        model.transform = fail
        result = self.run_plan(model)
        self.assertIn("model unavailable", result.reason)
        self.assertIsNone(result.shadow_cap)

    def test_validation_time_cannot_start_late_model_or_return_late_recommendation(self):
        for slow_call, expected_calls in ((2, 0), (8, 6)):
            with self.subTest(slow_call=slow_call):
                now, calls = [10.0], [0]
                validate = planner._validate_state
                model = StubModel()

                def slow_validation(*args):
                    validate(*args)
                    calls[0] += 1
                    if calls[0] == slow_call:
                        now[0] += .09

                with patch.object(planner, "_validate_state", slow_validation):
                    result = self.run_plan(model, clock=lambda: now[0])
                self.assertEqual(result.status, "fallback")
                self.assertIn("deadline", result.reason)
                self.assertIsNone(result.shadow_cap)
                self.assertEqual(len(model.calls), expected_calls)

    def test_final_validation_time_is_included_in_state_freshness(self):
        now, calls = [10.0], [0]
        validate = planner._validate_state

        def slow_validation(*args):
            validate(*args)
            calls[0] += 1
            if calls[0] == 8:
                now[0] += .02

        with patch.object(planner, "_validate_state", slow_validation):
            result = self.run_plan(clock=lambda: now[0],
                                   timing=Timing("test-clock", 10.1, .02, .11, .05))
        self.assertEqual(result.status, "fallback")
        self.assertIn("stale", result.reason)

    def test_native_counts_and_stage_progress_must_reconcile_before_prediction(self):
        changes = (
            {"native_running": 0}, {"native_running": 2}, {"native_waiting": 1},
            {"requests": (replace(state().requests[0], observed_output_tokens=0),)},
            {"requests": (replace(state().requests[0], stage="prefill"),)},
            {"requests": (replace(state().requests[0], stage="awaiting"),),
             "native_running": 0, "native_waiting": 1},
            {"requests": (replace(state().requests[0], stage="release_pending"),)},
            {"requests": (), "reserved_cost": 0},
        )
        for change in changes:
            with self.subTest(change=change):
                model = StubModel()
                result = self.run_plan(model, state=replace(state(), **change))
                self.assertEqual(result.status, "fallback")
                self.assertIn("mismatch", result.reason)
                self.assertEqual(model.calls, [])

    def test_known_prefill_waiting_and_release_pending_do_not_evict_cost(self):
        for stage, output, running, waiting in (
            ("prefill", 0, 1, 0), ("awaiting", 0, 0, 1), ("release_pending", 2, 0, 0),
        ):
            with self.subTest(stage=stage):
                snapshot = replace(
                    state(), requests=(replace(state().requests[0], stage=stage,
                                               observed_output_tokens=output),),
                    native_running=running, native_waiting=waiting, pending_batches=1,
                )
                result = self.run_plan(state=snapshot)
                self.assertEqual(result.status, "shadow")
                self.assertEqual(snapshot.reserved_cost, 8)
                self.assertFalse(result.active_permit)

    def test_same_first_resolved_two_move_deliberately_does_not_override_unresolved_one(self):
        for applied_cap in (16, 32):
            with self.subTest(applied_cap=applied_cap):
                model, law = agreement_model()
                result = self.run_plan(model, evaluation=law,
                                       state=replace(state(), applied_cap=applied_cap))
                self.assertEqual(result.one_move.best.plan.prefix, (16,))
                self.assertEqual(result.two_move.best.plan.prefix, (16, 32))
                self.assertFalse(result.one_move.first_action_resolved)
                self.assertTrue(result.two_move.first_action_resolved)
                self.assertEqual(result.gain_interval[0], 1)
                self.assertEqual(result.status, "fallback")
                self.assertEqual(result.reason, "same first action; strong One-move unresolved")
                self.assertIsNone(result.shadow_cap)

    def test_different_first_resolved_two_move_can_override_unresolved_one(self):
        model, law = agreement_model()
        original = model.transform

        def transform(p):
            if len(p.plan.prefix) == 1:
                return original(p)
            lookup = (48 - p.plan.prefix[0], p.plan.prefix[1])
            swapped = original(replace(p, plan=replace(p.plan, prefix=lookup)))
            return replace(swapped, plan=p.plan)

        model.transform = transform
        result = self.run_plan(model, evaluation=law)
        self.assertFalse(result.one_move.first_action_resolved)
        self.assertTrue(result.two_move.first_action_resolved)
        self.assertEqual(result.shadow_cap, 32)
        self.assertEqual(result.reason, "two-move shadow advantage")

    def test_changed_input_bundle_at_entry_stops_before_model(self):
        model = StubModel()
        changed = replace(state(), pending_command=True)
        result = self.run_plan(model, current_inputs=lambda: (changed, evaluation()))
        self.assertEqual(result.status, "fallback")
        self.assertIn("planning inputs changed", result.reason)
        self.assertEqual(model.calls, [])

    def test_last_input_fence_detects_epoch_version_history_and_model_changes(self):
        changes = (
            (replace(state(), identity=replace(IDENTITY, epoch="next-gateway-run")), evaluation()),
            (replace(state(), cap_version=5), evaluation()),
            (replace(state(), history_id="new-received-prefix"), evaluation()),
            (replace(state(), received_at=9.96), evaluation()),
            (state(), replace(evaluation(), model_id="new-model")),
            (state(), replace(evaluation(), uncertainty_id="new-uncertainty")),
        )
        for changed in changes:
            with self.subTest(changed=changed):
                model = StubModel()
                latest = [(state(), evaluation())]

                def advance(p):
                    latest[0] = changed
                    return p

                model.transform = advance
                result = self.run_plan(model, current_inputs=lambda: latest[0])
                self.assertEqual(result.status, "fallback")
                self.assertIn("planning inputs changed", result.reason)
                self.assertIsNone(result.shadow_cap)
                self.assertFalse(result.active_permit)

    def test_input_fence_time_is_included_in_deadline_and_freshness(self):
        for delay, age_limit, reason in ((.09, .5, "deadline"), (.02, .11, "stale")):
            with self.subTest(reason=reason):
                now, calls = [10.0], [0]

                def current():
                    calls[0] += 1
                    if calls[0] == 2:
                        now[0] += delay
                    return state(), evaluation()

                result = self.run_plan(current_inputs=current, clock=lambda: now[0],
                                       timing=Timing("test-clock", 10.1, .02, age_limit, .05))
                self.assertEqual(result.status, "fallback")
                self.assertIn(reason, result.reason)

    def test_missing_malformed_or_failed_input_fence_is_not_authority(self):
        def failed():
            raise RuntimeError("publisher unavailable")

        for callback in (None, lambda: (state(),), lambda: [state(), evaluation()], failed):
            result = self.run_plan(current_inputs=callback)
            self.assertEqual(result.status, "fallback")
            self.assertFalse(result.active_permit)
        model = StubModel()
        result = plan_response(
            state(), evaluation(), model, expected_identity=IDENTITY,
            timing=Timing("test-clock", 10.1, .02, .5, .05), clock=lambda: 10,
        )
        self.assertIn("missing input fence", result.reason)
        self.assertEqual(model.calls, [])


class LedgerTests(unittest.TestCase):
    def test_cap_drop_preserves_reservations_and_releases_original_whole_cost(self):
        self.assertEqual(transition_costs((("a", 20), ("b", 12)),
                                         (("release", "b", 12, 16),)), (("a", 20),))
        self.assertEqual(transition_costs((("a", 20), ("b", 12)),
                                         (("release", "a", 20, 16),
                                          ("admit", "c", 4, 16))), (("b", 12), ("c", 4)))

    def test_cap_is_cost_not_count_and_events_are_ordered(self):
        with self.assertRaisesRegex(ValueError, "exceeds cap"):
            transition_costs((("a", 12),), (("admit", "b", 8, 16),))
        with self.assertRaisesRegex(ValueError, "exceeds cap"):
            transition_costs((("a", 16),), (("admit", "b", 8, 16),
                                           ("release", "a", 16, 16)))
        self.assertEqual(transition_costs((("a", 16),), (("release", "a", 16, 16),
                                                        ("admit", "b", 8, 16))),
                         (("b", 8),))

    def test_duplicate_release_recost_and_reused_id_rejected(self):
        for events in (
            (("release", "a", 7, 16),),
            (("release", "a", 8, 16), ("release", "a", 8, 16)),
            (("release", "a", 8, 16), ("admit", "a", 8, 16)),
        ):
            with self.assertRaises(ValueError):
                transition_costs((("a", 8),), events)

    def test_lowered_cap_state_not_rejected_as_overshoot(self):
        snapshot = replace(state(), reserved_cost=24,
                           requests=(replace(state().requests[0], original_cost=24),))
        model = StubModel()
        result = plan_response(snapshot, evaluation(), model, expected_identity=IDENTITY,
                               timing=Timing("test-clock", 10.1, .02, .5, .05),
                               clock=lambda: 10.0, current_inputs=lambda: (snapshot, evaluation()))
        self.assertEqual(result.status, "shadow")


def flow_model(kernel, *, snapshot=None, law=None, offers=(), memory=(), clock=None):
    snapshot = snapshot or state()
    law = law or replace(evaluation(), tail_s=1, scenarios=(Scenario("joint-test-draw", 1, 0),))
    records = tuple(planner.FlowRequest(
        r.request_id, r.original_cost, -.1, r.prompt_tokens, r.max_output_tokens,
        r.observed_output_tokens, -.01 if r.observed_output_tokens else None,
    ) for r in snapshot.requests)
    seed = planner.FlowState(records, (planner.FlowView(
        0, snapshot.applied_cap, snapshot.applied_cap,
        tuple((r.request_id, r.original_cost) for r in snapshot.requests),
        (snapshot.native_running, snapshot.native_waiting, snapshot.pending_batches,
         snapshot.kv_usage), snapshot.received_at - snapshot.origin,
        records,
    ),), memory)
    paths = tuple(planner.JointPath(
        s.scenario_id, seed, offers, ((),) * int((5 + law.tail_s) * 4),
    ) for s in law.scenarios)
    return planner.ShortStepResponse(
        snapshot, law, paths, kernel, lambda history, deadline: 16,
        clock or (lambda: 10), 0, 0,
    )


class EventKernel:
    """Ordered contract fixture, not a calibrated native transition law."""

    def __init__(self, events=()):
        self.events = events
        self.calls = []

    def step(self, state, cap, offers, innovation, end, deadline):
        self.calls.append((state, cap, offers, innovation, end, deadline))
        start = state.history[-1].at_s
        events = tuple(e for e in self.events if start < e.at_s <= end)
        if state.history[-1].applied_cap != cap:
            events = (planner.FlowEvent(start + .001, "apply", cap=cap),) + events
            events = tuple(sorted(events, key=lambda event: event.at_s))
        return planner.FlowStep(events, ((state.memory[0] if state.memory else 0) + 1,),
                                (None, None, 1, None), end)


class ShortStepTests(unittest.TestCase):
    def predict(self, model, prefix=(16,)):
        return model.predict(model.state, planner.Plan(prefix, model.evaluation.continuation_id),
                             model.evaluation, 10.08)

    def test_terminal_requires_accumulated_transition_state_not_origin_reset(self):
        class AccumulatingKernel:
            def step(self, x, cap, offers, innovation, end, deadline):
                accumulated = (x.memory[0] if x.memory else 0) + 1
                start = x.history[-1].at_s
                events = (() if accumulated != 4 else (
                    planner.FlowEvent(start + .01, "progress", "old", output_tokens=64),
                    planner.FlowEvent(start + .02, "terminal", "old", natural_eos=True),
                    planner.FlowEvent(start + .03, "release", "old"),
                ))
                return planner.FlowStep(events, (accumulated,), (None, None, 1, None), end)

        model = flow_model(AccumulatingKernel())
        prediction = self.predict(model)
        self.assertEqual(prediction.outcomes, (
            Outcome("joint-test-draw", 1, 0, 0, (("old",), ("old",), ("old",))),))

    def test_free_running_state_feeds_all_six_planner_predictions(self):
        kernel = EventKernel((planner.FlowEvent(.02, "terminal", "old", natural_eos=True),
                              planner.FlowEvent(.03, "release", "old")))
        model = flow_model(kernel)
        decision = PlannerTests().run_plan(model, state=model.state, evaluation=model.evaluation)
        self.assertEqual(len(decision.scores), 6)
        self.assertEqual([s.mean_good for s in decision.scores], [1] * 6)
        self.assertTrue(all(s.released_origin_cost == (8, 8, 8) for s in decision.scores))
        self.assertEqual(len(kernel.calls), 6 * 24)
        for offset in range(0, len(kernel.calls), 24):
            trajectory = kernel.calls[offset:offset + 24]
            self.assertEqual([len(c[0].history) for c in trajectory], list(range(1, 25)))
            self.assertEqual(trajectory[1][0].memory, (1,))
            self.assertEqual(trajectory[-1][0].memory, (23,))
            self.assertEqual(trajectory[1][0].history[-1].live, ())
            self.assertEqual(trajectory[1][0].requests[0].terminal_at, .02)
            self.assertTrue(all(c[3] is model.paths[0].innovations[i]
                                for i, c in enumerate(trajectory)))
        self.assertFalse(decision.active_permit)

    def test_non_eviction_applied_not_requested_cap_and_ordered_admission(self):
        snapshot = replace(state(), applied_cap=32, reserved_cost=24,
                           requests=(replace(state().requests[0], original_cost=24),))
        model = flow_model(EventKernel(), snapshot=snapshot)
        offers = (planner.FlowRequest("before-ack", 8, .01, 128, 128),
                  planner.FlowRequest("after-ack", 8, .03, 128, 128),
                  planner.FlowRequest("after-release", 16, .08, 128, 128))
        step = planner.FlowStep((
            planner.FlowEvent(.02, "apply", cap=16),
            planner.FlowEvent(.04, "terminal", "old", natural_eos=True),
            planner.FlowEvent(.05, "release", "old"),
            planner.FlowEvent(.06, "terminal", "before-ack"),
            planner.FlowEvent(.07, "release", "before-ack"),
        ), (), (0, 0, 1, .1), .25)
        result = planner._advance_flow(model.paths[0].seed, 16, offers, step, .25)
        records = {r.request_id: r for r in result.requests}
        self.assertFalse(records["before-ack"].rejected)
        self.assertTrue(records["after-ack"].rejected)
        self.assertFalse(records["after-release"].rejected)
        self.assertEqual(result.history[-1].live, (("after-release", 16),))
        dropped = planner._advance_flow(
            model.paths[0].seed, 16, (), replace(step, events=step.events[:1]), .25)
        self.assertEqual(dropped.history[-1].live, (("old", 24),))

    def test_joint_law_not_marginal_release_cdf_determines_admission_and_good(self):
        class CorrelatedKernel:
            def step(self, x, cap, offers, innovation, end, deadline):
                start = x.history[-1].at_s
                events = []
                for rid, fast in zip(("a", "b"), x.memory):
                    terminal = .1 if fast else 2.1
                    events.extend((planner.FlowEvent(terminal, "terminal", rid, natural_eos=True),
                                   planner.FlowEvent(terminal + .01, "release", rid)))
                if all(x.memory):
                    events.extend((planner.FlowEvent(.16, "progress", "new", output_tokens=10),
                                   planner.FlowEvent(.2, "terminal", "new", natural_eos=True),
                                   planner.FlowEvent(.21, "release", "new")))
                events = tuple(sorted((e for e in events if start < e.at_s <= end),
                                      key=lambda e: e.at_s))
                return planner.FlowStep(events, x.memory, (None, None, None, None), end)

        snapshot = replace(state(), reserved_cost=16, native_running=2, requests=tuple(
            replace(state().requests[0], request_id=rid, observed_output_tokens=10)
            for rid in ("a", "b")))
        law = replace(evaluation(), tail_s=0, origin_offered_ids=("a", "b"),
                      scenarios=(Scenario("left", .5, 1), Scenario("right", .5, 1)))
        base = flow_model(CorrelatedKernel(), snapshot=snapshot, law=law,
                          offers=(planner.FlowRequest("new", 16, .15, 128, 128),))

        def coupled(memories):
            return replace(base, paths=tuple(
                replace(p, seed=replace(p.seed, memory=m)) for p, m in zip(base.paths, memories)))

        together = self.predict(coupled(((1, 1), (0, 0))))
        apart = self.predict(coupled(((1, 0), (0, 1))))
        self.assertEqual([o.settled_good for o in together.outcomes], [3, 0])
        self.assertEqual([o.settled_good for o in apart.outcomes], [1, 1])
        for rid in ("a", "b"):
            for index in range(3):
                marginal = lambda p: sum(s.probability * (rid in o.released_origin_ids[index])
                                         for s, o in zip(law.scenarios, p.outcomes))
                self.assertEqual(marginal(together), marginal(apart))
        scores = [planner._score(snapshot, p.plan, law, p) for p in (together, apart)]
        self.assertEqual(scores[0].released_origin_cost, scores[1].released_origin_cost)
        self.assertEqual([s.mean_good for s in scores], [1.5, 1])

    def test_joint_tail_outcome_does_not_claim_physical_drain(self):
        kernel = EventKernel((planner.FlowEvent(5.05, "progress", "old", output_tokens=128),
                              planner.FlowEvent(5.1, "terminal", "old", natural_eos=True),
                              planner.FlowEvent(5.11, "release", "old")))
        model = flow_model(kernel, offers=(planner.FlowRequest("interference", 8, 5, 128, 128),))
        prediction = self.predict(model)
        self.assertEqual(prediction.outcomes, (
            Outcome("joint-test-draw", 0, 1, 1, ((), (), ())),))
        self.assertEqual(kernel.calls[-1][0].history[-1].live, (("interference", 8),))
        self.assertEqual(kernel.calls[-1][0].history[-1].native[2], 1)

    def test_unsettled_tail_or_unsupported_step_aborts_without_zero_imputation(self):
        model = flow_model(EventKernel())
        self.assertIsNone(self.predict(model))
        decision = PlannerTests().run_plan(model, state=model.state, evaluation=model.evaluation)
        self.assertEqual(decision.scores, ())
        self.assertIsNone(decision.shadow_cap)
        with patch.object(EventKernel, "step", return_value=None):
            self.assertIsNone(self.predict(model))

    def test_continuation_sees_published_history_not_latent_or_future_draws(self):
        model = flow_model(EventKernel((planner.FlowEvent(.02, "terminal", "old"),
                                       planner.FlowEvent(.03, "release", "old"))), memory=(999,))
        seen = []

        def continuation(history, deadline):
            seen.append(history)
            self.assertTrue(all(isinstance(view, planner.FlowView) for view in history))
            self.assertTrue(all(view.native_received_at <= view.at_s for view in history))
            self.assertEqual(history[-1].native, (None, None, 1, None))
            self.assertFalse(hasattr(history[-1], "memory"))
            return 16

        self.assertIsNotNone(self.predict(replace(model, continuation=continuation)))
        self.assertEqual([h[-1].at_s for h in seen], [1, 2, 3, 4, 5])
        seen.clear()
        self.assertIsNotNone(self.predict(replace(model, continuation=continuation), (16, 32)))
        self.assertEqual([h[-1].at_s for h in seen], [2, 3, 4, 5])

    def test_bad_path_binding_bounds_and_origin_availability_fail_before_kernel(self):
        kernel = EventKernel()
        base = flow_model(kernel)
        seed, path = base.paths[0].seed, base.paths[0]
        cases = (
            replace(base, paths=(replace(path, scenario_id="alien"),)),
            replace(base, paths=(replace(path, innovations=()),)),
            replace(base, paths=(replace(path, seed=replace(
                seed, requests=(replace(seed.requests[0], first_at=None),))),)),
            replace(base, paths=(replace(path, offers=(
                planner.FlowRequest("new", 8, -.01, 128, 128),)),)),
            replace(base, paths=(replace(path, offers=(
                planner.FlowRequest("new", 8, .1, 128, 128),)),)),
            replace(base, evaluation=replace(base.evaluation, tail_s=40)),
            replace(base, error_below=float("nan")),
        )
        for model in cases:
            with self.subTest(model=model), self.assertRaises(ValueError):
                self.predict(model)
        with self.assertRaisesRegex(ValueError, "binding"):
            base.predict(replace(base.state, history_id="new"), planner.Plan(
                (16,), base.evaluation.continuation_id), base.evaluation, 10.08)
        self.assertEqual(kernel.calls, [])

    def test_step_rejects_bad_chronology_visibility_and_impossible_lifecycle(self):
        base = flow_model(EventKernel())
        seed = base.paths[0].seed
        good = planner.FlowStep((), (), (None, None, 1, None), .25)
        cases = (
            replace(good, events=(planner.FlowEvent(.1, "release", "old"),)),
            replace(good, events=(planner.FlowEvent(.1, "progress", "old", output_tokens=1),)),
            replace(good, events=(planner.FlowEvent(.1, "terminal", "alien"),)),
            replace(good, events=(planner.FlowEvent(.1, "apply", cap=32),)),
            replace(good, events=(planner.FlowEvent(.3, "terminal", "old"),)),
            replace(good, events=(planner.FlowEvent(.1, "terminal", "old"),
                                  planner.FlowEvent(.11, "terminal", "old"))),
            replace(good, events=(planner.FlowEvent(.1, "terminal", "old"),
                                  planner.FlowEvent(.11, "progress", "old", output_tokens=3))),
            replace(good, native_received_at=.3),
            replace(good, native=(True, None, 1, .1)),
        )
        for step in cases:
            with self.subTest(step=step), self.assertRaises(ValueError):
                planner._advance_flow(seed, 16, (), step, .25)
        with self.assertRaisesRegex(ValueError, "tie"):
            planner._advance_flow(seed, 16, (planner.FlowRequest("new", 8, .1, 128, 128),),
                                  replace(good, events=(
                                      planner.FlowEvent(.1, "terminal", "old"),)), .25)

    def test_joint_paths_cannot_change_the_observed_past(self):
        law = replace(evaluation(), tail_s=1, scenarios=(
            Scenario("left", .5, 0), Scenario("right", .5, 0)))
        model = flow_model(EventKernel((
            planner.FlowEvent(.02, "terminal", "old", natural_eos=True),
            planner.FlowEvent(.03, "release", "old"),
        )), law=law)
        path = model.paths[1]
        records = (replace(path.seed.requests[0], first_at=-.02),)
        altered = replace(path, seed=replace(
            path.seed, requests=records,
            history=(replace(path.seed.history[0], requests=records),)))
        with self.assertRaisesRegex(ValueError, "observed seed mismatch"):
            self.predict(replace(model, paths=(model.paths[0], altered)))

    def test_float_boundary_disagreement_is_unsupported_not_new_admission_rule(self):
        base = flow_model(EventKernel())
        seed = base.paths[0].seed
        seed = replace(seed, requests=(replace(seed.requests[0], original_cost=15.9),),
                       history=(replace(seed.history[0], live=(("old", 15.9),)),))
        with self.assertRaisesRegex(ValueError, "arithmetic ambiguous"):
            planner._advance_flow(seed, 16, (planner.FlowRequest("new", .1, .1, 128, 128),),
                                  planner.FlowStep((), (), (None, None, None, None), .25), .25)

    def test_callback_latency_is_rejected_without_claiming_preemption(self):
        now = [10.]
        kernel = EventKernel()
        model = flow_model(kernel, clock=lambda: now[0])

        def late(*args):
            now[0] = 10.09
            return planner.FlowStep((), (), (None, None, None, None), .25)

        with patch.object(kernel, "step", side_effect=late):
            with self.assertRaisesRegex(ValueError, "deadline"):
                self.predict(model)
        now[0] = 10

        def late_continuation(history, deadline):
            now[0] = 10.09
            return 16

        with self.assertRaisesRegex(ValueError, "deadline"):
            self.predict(replace(model, continuation=late_continuation))
        self.assertEqual(len(kernel.calls), 4)

    def test_nested_union_has_information_without_changing_same_first_default(self):
        stub, law = agreement_model()
        decision = PlannerTests().run_plan(stub, evaluation=law)
        nested = planner.nested_family_diagnostic(decision, 16)
        self.assertEqual(nested.best.plan.prefix, (16, 32))
        self.assertTrue(nested.first_action_resolved)
        self.assertEqual(decision.status, "fallback")
        self.assertIsNone(decision.shadow_cap)
        self.assertFalse(decision.active_permit)
        stub = StubModel()
        stub.values[(16,)] = 9
        decision = PlannerTests().run_plan(stub)
        self.assertEqual(planner.nested_family_diagnostic(decision, 16).best.plan.prefix, (16,))
        with self.assertRaisesRegex(ValueError, "complete"):
            planner.nested_family_diagnostic(Decision("fallback", "no scores"), 16)


FROZEN_SOURCES = {
    "opus": ("opus/experiments/mpc-research/native-v3/native_release_model.py",
             "86f45ab851a446b4a903c8e5f0991acb198ecc4fc5d9d0d9bd0d05e38e77411b"),
    "gemini": ("gemini/native_campaign_protocol.py",
               "087c68868f48f6bac9d1ac829c9dc3cb8b749f1c40b87f6d5364bb2d2f4bad79"),
    "sol": ("sol/experiments/mpc-research/native-v3/native_experiment_audit.py",
            "6abb94a4fbc1f3e238cd2d4687e996829304afe669b38efba14f2ca29074a554"),
    "astra": ("astra/experiments/mpc-research/native-v3/native_response_planner.py",
              "e19db180e1fb06c6c34ff21e9b76131e85749edc7f403d4aa65acf366b7a3326"),
}

ROUND_TWO_SOURCES = {
    name: (f"{name}/experiments/mpc-research/native-v3/{filename}", digest)
    for name, filename, digest in (
        ("opus", "native_release_model.py",
         "6e277d09c2ccfded2bb11e31164f97515c4bbdcc838f3df3f5a917864b297270"),
        ("gemini", "native_campaign_protocol.py",
         "de51b0af0fd1d02db3c960162a82693df3620751944373c2e697b913c55ca38e"),
        ("sol", "native_experiment_audit.py",
         "44423a5d76782da9d9118ddacbdb94e82d6963b70a65dfdf95d4e82d5487251d"),
        ("astra", "native_response_planner.py",
         "61fed73aa44057dbfd15b4f337e67caffa29695d9aa80052b20f94e0e3e00b23"),
    )
}


def load_frozen(name, round_number=1):
    sources = FROZEN_SOURCES if round_number == 1 else ROUND_TWO_SOURCES
    relative, expected = sources[name]
    path = Path(os.environ[f"NV3_R{round_number}_FREEZE"]) / relative
    source = path.read_bytes()
    if hashlib.sha256(source).hexdigest() != expected:
        raise ValueError(f"{name} R{round_number} source hash differs")
    spec = importlib.util.spec_from_file_location(f"nv3_r{round_number}_{name}", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    # Compile the verified bytes, not a second read or a potentially stale pyc.
    exec(compile(source, str(path), "exec"), module.__dict__)
    return module


def opus_episode():
    rid = "1" * 32
    mark = dict(request_id=rid, cost=1.0, prompt_tokens=128, max_tokens=8,
                admitted_at=0.0, first_at=None)
    return dict(
        episode_id="witness", seed_block=170001, partition="train",
        run_id="run", clock_domain="host",
        observations=[
            dict(gateway=dict(run_id="run", clock_domain="host", complete=True,
                              sequence=1, sampled_at=0.25, budget=16, requests=[mark]),
                 received_at=.255, native_received_at=.27,
                 native=dict(schema="pr33-native-read-only-v1", complete=True,
                             sampled_at=.26, running=1, waiting=0,
                             clock_domain="host", run_id="run",
                             requests=[dict(request_id=f"chatcmpl-{rid}-1234abcd",
                                            output_tokens=0)])),
            dict(gateway=dict(run_id="run", clock_domain="host", complete=True,
                              sequence=2, sampled_at=2.0, budget=16, requests=[]),
                 received_at=2.01, native=None),
        ],
        ledger=[dict(event="mpc_ledger", sequence=2, run_id="run", clock_domain="host",
                     complete=True, effective_at=.5, reserved_cost=0)],
    )


def sol_blocks(n=2):
    blocks = []
    for i in range(n):
        arms = {}
        for side in ("left", "right"):
            rid = hashlib.sha256(f"{i}-{side}".encode()).hexdigest()[:32]
            offer = dict(request_id=rid, logical_id=f"offer-{i}", offset_s=0,
                         prompt_tokens=128, max_tokens=4,
                         prompt_sha256=hashlib.sha256(f"prompt-{i}".encode()).hexdigest())
            row = dict(request_id=rid, response_request_id=rid, clock_domain="client",
                       requested_max_tokens=4, scheduled_at=10, sent_at=10.01,
                       first_content_at=10.1, last_content_at=10.11, terminal_at=10.12,
                       status="complete", stream_done=True, stream_error=False,
                       http_status=200, finish_reason="stop", native_eos_verified=True,
                       usage=dict(prompt_tokens=128, completion_tokens=2))
            if side == "left":
                row.update(status="rejected", http_status=503, first_content_at=None,
                           last_content_at=None, admission_rejection=True, usage=None)
            arms[side] = dict(offers=[offer], rows=[row], origin=10, window_s=1,
                              clock_domain="client")
        blocks.append(dict(seed=170010 + i, block_id=f"b{i}", randomization_unit=f"u{i}",
                           independent_sampling=True, pair_order_randomized=True,
                           pair_order="left-first",
                           randomization_scheme="independent-fair-pair-order",
                           frozen_comparison_sha256="a" * 64, **arms))
    return blocks


@unittest.skipUnless(os.environ.get("NV3_R1_FREEZE"), "set NV3_R1_FREEZE for pinned R1 review")
class FrozenRoundOneWitnesses(unittest.TestCase):
    """Expected failures of frozen contracts, not native data or fixed-peer tests."""

    @classmethod
    def setUpClass(cls):
        cls.opus, cls.gemini, cls.sol, cls.astra = (
            load_frozen(name) for name in ("opus", "gemini", "sol", "astra")
        )

    def test_opus_cross_clock_and_epoch_native_frame_is_accepted(self):
        episode = opus_episode()
        baseline = self.opus.build_origins(episode)[0]
        episode["observations"][0]["native"].update(clock_domain="other-clock", run_id="old-run")
        self.assertEqual(self.opus.build_origins(episode)[0], baseline)

    def test_opus_release_before_last_live_snapshot_is_accepted_as_exact_truth(self):
        episode = opus_episode()
        episode["ledger"][0]["effective_at"] = .2
        row = self.opus.build_dataset([episode])[0]
        self.assertLess(.2, row["sampled_at"])
        self.assertEqual(row["truth"][1.0], (1.0, 1.0))

    def test_opus_different_cap_sequences_have_identical_predictor_features(self):
        episode = opus_episode()
        t0 = .27
        episode["cap_plan"] = [(t0, 16), (t0 + 1, 16), (t0 + 2, 32), (t0 + 3, 16)]
        left = self.opus.build_origins(episode)[0][0]
        episode["cap_plan"] = [(t0, 16), (t0 + 1, 32), (t0 + 2, 16), (t0 + 3, 16)]
        right = self.opus.build_origins(episode)[0][0]
        for h in self.opus.HORIZONS:
            for a, b in zip(self.opus.mark_features(left, "1" * 32, h),
                            self.opus.mark_features(right, "1" * 32, h)):
                self.assertAlmostEqual(a, b)

    def test_opus_same_block_repetition_shrinks_claimed_block_calibration(self):
        zero = dict(partition="calibration", seed_block=170002, reserved=1,
                    truth={h: (0, 0) for h in self.opus.HORIZONS})
        one = dict(partition="calibration", seed_block=170003, reserved=1,
                   truth={h: (1, 1) for h in self.opus.HORIZONS})
        fixed_prediction = ({"batch_aware": {h: 0 for h in self.opus.HORIZONS}}, [])
        with patch.object(self.opus, "predict", return_value=fixed_prediction):
            before = self.opus.calibrate({}, [zero, one])
            repeated = self.opus.calibrate({}, [zero] * 100 + [one])
        self.assertEqual(before["blocks"], repeated["blocks"])
        self.assertEqual(before["bands"][1.0]["upper"], 1)
        self.assertEqual(repeated["bands"][1.0]["upper"], 0)

    def test_opus_tail_is_explained_without_placeholder_or_cuda_completion_evidence(self):
        steps = [dict(step_id=f"s{i}", start=i / 100, end=.02 + i / 100,
                      work=[dict(request_id="r", position=i, tokens=1)]) for i in range(2)]
        workers = [dict(step_id=f"s{i}", executed_positions={"r": i},
                        executed_counts={"r": 1}) for i in range(2)]
        result = self.opus.forward_work_accounting(
            dict(input_tokens=1, output_tokens=1, finish_reason="stop", finished=.1),
            steps, workers, request_id="r",
        )
        self.assertTrue(result["tail_accounted"])
        self.assertFalse(result["legacy_strict_audit_valid"])

    def test_opus_ood_envelope_does_not_cover_used_age_and_history_features(self):
        origin = self.opus.build_origins(opus_episode())[0][0]
        support = self.opus.support_envelope([origin])
        shifted = copy.deepcopy(origin)
        shifted["cohort"]["1" * 32]["admitted_at"] = -1000
        shifted["history_rate"] = 1e6
        self.assertEqual(self.opus.ood_reasons(shifted, support), [])
        self.assertNotEqual(self.opus.mark_features(origin, "1" * 32, 1),
                            self.opus.mark_features(shifted, "1" * 32, 1))

    def test_opus_horizon_specific_censor_exclusion_makes_cumulative_baseline_decrease(self):
        partial = opus_episode()
        early = partial["observations"][0]
        early["gateway"]["requests"][0]["cost"] = 9
        pending = dict(early["gateway"]["requests"][0], request_id="2" * 32, cost=1)
        early["gateway"]["requests"].append(pending)
        early["native"]["requests"].append(
            dict(request_id=f"chatcmpl-{'2' * 32}-1234abcd", output_tokens=0)
        )
        early["native"]["running"] = 2
        partial["ledger"][0]["reserved_cost"] = 1
        partial["observations"][1]["gateway"]["requests"] = [pending]
        slow = opus_episode()
        slow.update(episode_id="slow", seed_block=170002, ledger=[])
        slow["observations"][0]["gateway"]["requests"][0]["cost"] = 10
        slow["observations"][1].update(received_at=6.01)
        slow["observations"][1]["gateway"].update(
            sequence=1, sampled_at=6,
            requests=copy.deepcopy(slow["observations"][0]["gateway"]["requests"]),
        )
        rows = self.opus.build_dataset([partial, slow])
        self.assertEqual(rows[0]["truth"], {1.0: (9.0, 9.0), 3.0: (9.0, 10.0),
                                            5.0: (9.0, 10.0)})
        params = self.opus.fit(rows)
        pred, reasons = self.opus.predict(params, rows[0])
        self.assertEqual(reasons, [])
        self.assertEqual(pred["train_fraction"], {1.0: 4.5, 3.0: 0.0, 5.0: 0.0})

    def test_gemini_accounting_adds_a_position_and_concurrency_does_not_falsify_serial(self):
        accounting = self.gemini.compute_work_accounting()
        self.assertEqual(accounting.physical_executed_positions, 4129)
        self.assertEqual(accounting.useful_total_tokens, 4128)
        # Two simultaneous offers on a serial server: demand .4 each, terminal .4/.8.
        result = self.gemini.verify_gpu_elapsed_clock_semantics(.8, .4, 2)
        self.assertTrue(result["serial_service_model_falsified"])

    def test_gemini_zero_offered_duration_satisfies_ten_hour_flag(self):
        protocol = self.gemini.build_native_campaign_protocol(
            offers_duration_s=0, max_drain_duration_s=120
        )
        self.assertTrue(protocol["duration_summary"]["hours_requirement_satisfied"])
        self.assertEqual(sum(e["offers_duration_s"] for e in protocol["episodes"]), 0)
        self.assertTrue(all(not e["actuator_schedule"] for e in protocol["episodes"]))
        self.assertIn("unseen_ood_mix", {e["family"] for e in protocol["episodes"]
                                       if e["split"] == "train"})

    def test_gemini_impossible_good_counts_can_confirm_superiority(self):
        m = self.gemini
        blocks = [m.IndependentSeedBlockOutcome(
            block_id=f"impossible-{i}", seed=170100 + i, workload_family="fixture",
            split="train", duration_s=1, control_decisions=1, offered_requests=1,
            policy_a_good_completions=0, policy_a_rejections=0, policy_a_solver_overruns=0,
            policy_b_good_completions=10 + i, policy_b_rejections=0, policy_b_solver_overruns=0,
        ) for i in range(6)]
        result = m.SuperiorityEvaluator().evaluate(blocks)
        self.assertEqual(result["verdict"], "CONFIRMED_SUPERIOR")
        self.assertTrue(result["statistically_significant"])

    def test_gemini_duplicate_admission_leaves_ghost_reservation(self):
        m = self.gemini
        snapshot = m.ObservableBatchState(32)
        record = m.MarkedReservationRecord("same", 8, 0, 128, 8)
        self.assertTrue(snapshot.admit(record))
        self.assertTrue(snapshot.admit(record))
        snapshot.release("same", 1)
        self.assertEqual(snapshot.active_reservations, {})
        self.assertEqual(snapshot.reserved_cost, 8)

    def test_gemini_boolean_output_and_post_after_terminal_are_scored_good(self):
        m = self.gemini
        outcome = m.RequestOutcome("r", 128, True, 0, 3, .1, .2, 0, "stop", True)
        self.assertTrue(m.validate_request_outcome(outcome)["is_good"])

    def test_sol_no_first_token_after_ttft_deadline_retains_impossible_upper(self):
        arm = sol_blocks()[0]["right"]
        arm["rows"][0].update(status="censored", first_content_at=None, last_content_at=None,
                              terminal_at=None, observed_until=11, stream_done=False, usage=None)
        result = self.sol.audit_arm(**arm)
        self.assertEqual((result["good_lower"], result["good_upper"]), (0, 1))

    def test_sol_same_frozen_comparison_allows_different_slo_between_blocks(self):
        blocks = sol_blocks()
        for side in ("left", "right"):
            blocks[1][side]["ttft_s"] = .05
        result = self.sol.paired_effect(blocks, bootstrap_samples=20)
        self.assertEqual(result["block_effects_good_per_s"], [1, 0])
        self.assertEqual(result["effect_good_per_s"], .5)

    def test_sol_logical_id_renaming_evades_repeated_tape_guard(self):
        blocks = sol_blocks(6)
        for block in blocks:
            for side in ("left", "right"):
                block[side]["offers"][0]["prompt_sha256"] = "b" * 64
        result = self.sol.paired_effect(blocks, bootstrap_samples=20)
        self.assertEqual(result["exact_two_sided_signflip_p"], .03125)
        self.assertFalse(result["independent_sampling_verified"])
        self.assertFalse(result["native_performance_accepted"])

    def test_astra_r1_can_return_shadow_after_final_validation_crosses_deadline(self):
        now, calls = [10.0], [0]
        validate = self.astra._validate_state

        def slow_validation(*args):
            validate(*args)
            calls[0] += 1
            if calls[0] == 8:
                now[0] += .09

        with patch.object(self.astra, "_validate_state", slow_validation):
            result = self.astra.plan_response(
                state(), evaluation(), StubModel(), expected_identity=IDENTITY,
                timing=Timing("test-clock", 10.1, .02, .5, .05), clock=lambda: now[0],
            )
        self.assertEqual(result.status, "shadow")
        self.assertEqual(result.elapsed_s, 0)
        self.assertGreater(now[0], 10.08)
        self.assertFalse(result.active_permit)


@unittest.skipUnless(os.environ.get("NV3_R2_FREEZE"), "set NV3_R2_FREEZE for pinned R2 review")
class FrozenRoundTwoResponses(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.opus, cls.gemini, cls.sol, cls.astra = (
            load_frozen(name, 2) for name in ("opus", "gemini", "sol", "astra")
        )

    def test_sol_count_stage_counterexample_against_actual_astra_r2(self):
        result = self.astra.plan_response(
            replace(state(), native_running=0), evaluation(), StubModel(),
            expected_identity=IDENTITY, timing=Timing("test-clock", 10.1, .02, .5, .05),
            clock=lambda: 10,
        )
        self.assertEqual(result.status, "shadow")
        self.assertFalse(result.active_permit)

    def test_opus_r2_commit_fence_is_stronger_but_not_full_tail_provenance(self):
        steps = [dict(step_id=f"s{i}", start=i / 100, end=.02,
                      work=[dict(request_id="r", position=i, tokens=1)]) for i in range(2)]
        workers = [dict(step_id=f"s{i}", executed_positions={"r": i},
                        executed_counts={"r": 1}) for i in range(2)]
        request = dict(input_tokens=1, output_tokens=1, finish_reason="stop", finished=.1)
        before = self.opus.forward_work_accounting(request, steps, workers, request_id="r")
        self.assertIn("tail_commit_before_finish", before["problems"])
        steps[-1]["end"] = .2
        after = self.opus.forward_work_accounting(request, steps, workers, request_id="r")
        self.assertTrue(after["tail_accounted"])
        self.assertFalse(after["legacy_strict_audit_valid"])

    def test_gemini_same_first_case_reproduces_on_actual_astra_not_only_copied_logic(self):
        model, law = agreement_model()
        result = self.astra.plan_response(
            state(), law, model, expected_identity=IDENTITY,
            timing=Timing("test-clock", 10.1, .02, .5, .05), clock=lambda: 10,
        )
        self.assertFalse(result.one_move.first_action_resolved)
        self.assertTrue(result.two_move.first_action_resolved)
        self.assertEqual(result.gain_interval[0], 1)
        self.assertIsNone(result.shadow_cap)
        peer = self.gemini.demonstrate_astra_selection_defect()
        self.assertEqual(peer["astra_unfixed_status"], result.status)

    def test_astra_r2_does_not_notice_new_gateway_run_in_same_clock_domain(self):
        latest = [state()]
        model = StubModel()

        def advance(p):
            latest[0] = replace(state(), identity=replace(IDENTITY, epoch="new-gateway-run"))
            return p

        model.transform = advance
        result = self.astra.plan_response(
            state(), evaluation(), model, expected_identity=IDENTITY,
            timing=Timing("test-clock", 10.1, .02, .5, .05), clock=lambda: 10,
        )
        self.assertEqual(latest[0].identity.clock_domain, IDENTITY.clock_domain)
        self.assertNotEqual(latest[0].identity.epoch, IDENTITY.epoch)
        self.assertEqual(result.status, "shadow")

    def test_gemini_tail_claim_ignores_records_and_missing_physical_measurement(self):
        measured = [dict(observer="light", tail_tokens=1) for _ in range(20)]
        off = [dict(observer="off", tail_tokens=None) for _ in range(20)]
        reported = self.gemini.audit_native_qualification_tail_distribution(measured + off)
        contradictory = self.gemini.audit_native_qualification_tail_distribution(
            [dict(observer="light", tail_tokens=0)]
        )
        self.assertEqual(reported, contradictory)
        self.assertTrue(reported["tail_is_stochastic"])
        self.assertEqual(reported["mean_tail_tokens_per_request"], .5)

    def test_gemini_actual_duration_checker_qualifies_nonfinite_duration(self):
        for duration in (float("nan"), float("inf")):
            record = self.gemini.ExperimentDurationAccounting(
                400, 120, 48000, duration, 0, 0, 0,
            )
            self.assertTrue(record.validate_actual_10h_milestone()[0])

    def test_gemini_r2_exact_signflip_still_changes_with_units_but_sol_is_repaired(self):
        normal = self.gemini.robust_paired_permutation_test([1.0] * 4)
        scaled = self.gemini.robust_paired_permutation_test([1e-15] * 4)
        self.assertEqual(normal["p_value"], .125)
        self.assertEqual(scaled["p_value"], 1)
        cases = sol_blocks(4)
        for case in cases:
            case["partition"] = "train"
            for side in ("left", "right"):
                case[side]["window_s"] = 10 ** 15
        self.assertEqual(self.sol.paired_effect(cases, bootstrap_samples=20)
                         ["exact_two_sided_signflip_p"], .125)


class MeanFamilyTests(unittest.TestCase):
    class Scorer:
        source_sha = planner.R9_V5_SHA
        kernel_id = "unit-kernels"
        clock_domain = "test-clock"
        cost_hash = "test-cost"
        costs = {("test", 128): 1.}

        def __init__(self, favored=None, unsupported=None, clock=None):
            self.favored, self.unsupported, self.clock = favored, unsupported, clock
            self.draw_calls, self.draw_ids, self.plans = 0, [], []

        def support_reasons(self, step):
            return []

        def draw(self, cut, key, scenario):
            self.draw_calls += 1
            return dict(arrivals=[(.1 * i, 128, .1) for i in range(1, 5)],
                        live_u=[.5], pending_u=[])

        def score(self, cut, plan, draw):
            if self.clock is not None:
                self.clock[0] += .2
            if plan == self.unsupported:
                raise ValueError("kernel_unsupported")
            self.draw_ids.append(id(draw))
            self.plans.append(plan)
            return dict(good_1=0., good_3=1., good_5=3. if plan == self.favored else 2.,
                        offers_1=4., offers_3=4., offers_5=4.)

    def request(self):
        step = dict(t0=10., cell="test", gateway=dict(budget=32, reserved=1.),
                    cohort={"old"}, outstanding=0)
        cut = dict(t0=10., cell="test", law=1., live=[("old", 1., None, [("key",)])],
                   pending=[], mix=[(128, 1)])
        return planner.MeanPlanRequest(
            "unit-cut", Identity(planner.R8_CORE, "epoch", "test-clock", "test-cost"),
            "native-epoch", 9.8, 9.9, "unit-key", step, cut, (("old", 1.),))

    def run_solver(self, scorer, request=None):
        return planner.optimize_v5_mean(request or self.request(), scorer, enabled=True,
                                         deadline_at=101., now=lambda: 100.)

    def test_exact_nested_families_shared_draws_and_first_action_difference(self):
        scorer = self.Scorer(favored=(16, 32, 16, 32, 16))
        request = self.request()
        before = copy.deepcopy(request.cut)
        result = self.run_solver(scorer, request)
        self.assertEqual(result["status"], "experimental_candidate")
        self.assertEqual(result["completed_plans"], 32)
        self.assertEqual(scorer.draw_calls, 32)
        self.assertEqual(len(scorer.draw_ids), 32 * 32)
        self.assertEqual(scorer.draw_ids, scorer.draw_ids[:32] * 32)
        self.assertEqual(set(scorer.plans), set(planner.R9_ALL_PLANS))
        self.assertEqual(result["one_move"]["plan"], (32,) * 5)
        self.assertEqual(result["mpc"]["plan"], scorer.favored)
        self.assertEqual(result["implied_gain"], 1.)
        self.assertTrue(result["first_action_differs"])
        self.assertEqual(request.cut, before)
        self.assertFalse(result["active_permit"])
        self.assertFalse(result["risk_coverage_certified"])

    def test_ties_keep_incumbent_then_minimize_variation_without_utility_penalty(self):
        result = self.run_solver(self.Scorer())
        self.assertEqual(result["mpc"]["plan"], (32,) * 5)
        self.assertEqual(result["implied_gain"], 0.)
        self.assertFalse(result["first_action_differs"])
        favored = (32, 16, 32, 16, 32)
        result = self.run_solver(self.Scorer(favored=favored))
        self.assertEqual(result["mpc"]["plan"], favored)
        self.assertEqual(result["implied_gain"], 1.)
        self.assertFalse(result["first_action_differs"])

    def test_no_partial_family_recommendation_when_a_full_plan_is_unsupported(self):
        result = self.run_solver(self.Scorer(unsupported=(16, 16, 16, 32, 16)))
        self.assertEqual(result["status"], "unsupported")
        self.assertTrue(result["pair_family_support"]["one_complete"])
        self.assertFalse(result["pair_family_support"]["mpc_complete"])
        self.assertIsNone(result["candidate_first_action"])
        self.assertIsNone(result["implied_gain"])

    def test_late_callback_is_deadline_not_a_partial_winner(self):
        clock = [100.]
        scorer = self.Scorer(clock=clock)
        result = planner.optimize_v5_mean(self.request(), scorer, enabled=True,
                                          deadline_at=100.1, now=lambda: clock[0])
        self.assertEqual(result["status"], "deadline")
        self.assertEqual(result["completed_plans"], 0)
        self.assertIsNone(result["candidate_first_action"])
        self.assertGreater(result["wall_s"], .1)

    def test_deadline_is_checked_after_final_family_selection(self):
        clock, scorer = [100.], self.Scorer()
        original_tie = planner._mean_plan_tie

        def late_tie(plan, incumbent):
            if len(scorer.plans) == 1024:
                clock[0] = 100.2
            return original_tie(plan, incumbent)

        with patch.object(planner, "_mean_plan_tie", side_effect=late_tie):
            result = planner.optimize_v5_mean(self.request(), scorer, enabled=True,
                                              deadline_at=100.1, now=lambda: clock[0])
        self.assertEqual(result["status"], "deadline")
        self.assertEqual(result["reason"], "final return deadline")
        self.assertTrue(result["pair_family_support"]["mpc_complete"])
        self.assertIsNone(result["candidate_first_action"])
        self.assertGreater(result["wall_s"], .1)

    def test_inactive_source_clock_and_original_cost_guards(self):
        scorer, request = self.Scorer(), self.request()
        result = planner.optimize_v5_mean(request, scorer, now=lambda: 100.)
        self.assertEqual(result["status"], "inactive")
        self.assertEqual(scorer.draw_calls, 0)
        for bad in (replace(request, received_at=11.),
                    replace(request, sampled_at=9.),
                    replace(request, original_costs=(("old", 2.),)),
                    replace(request, identity=replace(request.identity, clock_domain="other"))):
            with self.subTest(bad=bad):
                result = self.run_solver(scorer, bad)
                self.assertEqual(result["status"], "unsupported")
                self.assertIsNone(result["candidate_first_action"])
        scorer.source_sha = "unbound"
        self.assertEqual(self.run_solver(scorer)["status"], "unsupported")

    def test_mutation_and_cap_dependent_offers_cannot_authorize_a_result(self):
        class Mutating(self.Scorer):
            def score(self, cut, plan, draw):
                draw["arrivals"] = []

        class InvalidOffers(self.Scorer):
            def score(self, cut, plan, draw):
                result = super().score(cut, plan, draw)
                result["offers_5"] = 3.
                return result

        self.assertEqual(self.run_solver(Mutating())["status"], "unsupported")
        self.assertEqual(self.run_solver(InvalidOffers())["status"], "unsupported")

    def test_existing_stock_above_lowered_cap_is_retained_not_evicted(self):
        request = self.request()
        request = replace(request,
                          step={**request.step, "gateway": dict(budget=16, reserved=24.)},
                          cut={**request.cut, "live": [("old", 24., None, [("key",)])]},
                          original_costs=(("old", 24.),))
        result = self.run_solver(self.Scorer(), request)
        self.assertEqual(result["status"], "experimental_candidate")
        self.assertEqual(request.cut["live"][0][1], 24.)
        self.assertEqual(result["mpc"]["plan"], (16,) * 5)


@unittest.skipUnless(os.environ.get("NV3_V5_SOURCE"), "set NV3_V5_SOURCE for exact frozen v5 checks")
class ExactPrefixTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.module = planner._r9_loader(os.environ["NV3_V5_SOURCE"])

    def scorers(self, *, trace=False):
        records = [(2., .8, .8), (.5, .2, .2), (3., 2.5, 2.5), (1.5, None, 1.4)] * 8
        kernels = dict(cohort={("key",): records},
                       birth={("test", 128): records,
                              **{("test", 128, i): list(reversed(records)) if i % 2 else records
                                 for i in range(5)}})
        costs = {("test", 128): 1.}
        base = planner.FrozenV5MeanScorer(self.module, kernels, costs, {})
        fast = planner.FrozenV5PrefixScorer(self.module, kernels, costs, {}, trace=trace)
        return base, fast

    def test_exact_all_plans_and_shared_draws_with_prefix_reuse(self):
        base, fast = self.scorers()
        request = MeanFamilyTests().request()
        cut = planner._immutable({**request.cut, "law": 12.,
                                  "pending": [("pending", 1., 128, .7)]})
        draws = [planner._immutable(base.draw(cut, "unit-shared", i)) for i in range(32)]
        for plan in planner.R9_ALL_PLANS:
            for draw in draws:
                self.assertEqual(fast.score(cut, plan, draw), base.score(cut, plan, draw))
        self.assertEqual(fast.prefix_evaluations, 32 * (2 + 4 + 8 + 16 + 32))
        before = fast.prefix_evaluations
        fast.score(cut, (32,) * 5, draws[0])
        self.assertEqual(fast.prefix_evaluations, before)

    def test_boundary_order_cost_overshoot_and_pending_conditioning_unchanged(self):
        base, fast = self.scorers(trace=True)
        cut = planner._immutable(dict(
            t0=10., cell="test", law=1., mix=[(128, 1)],
            live=[("old", 24., None, [("key",)])], pending=[("pending", 1., 128, .7)]))
        draw = planner._immutable(dict(
            live_u=[0.], pending_u=[.3],
            arrivals=[(t, 128, .2) for t in (0., .5, 1., 1. + 2e-9, 2., 3., 4., 5.)]))
        for plan in planner.R9_ALL_PLANS:
            self.assertEqual(fast.score(cut, plan, draw), base.score(cut, plan, draw))
        path = fast.path_evidence(cut, (16, 32, 16, 32, 16), draw)
        self.assertFalse(path["events"][0]["admitted"])
        self.assertEqual(path["events"][0]["reserved"], 24.)
        boundary = {r["t"]: r for r in path["events"] if r["kind"] == "offer"}
        self.assertEqual(boundary[1.]["cap"], 16)
        self.assertEqual(boundary[1. + 2e-9]["cap"], 32)
        # The acceleration retains, rather than silently repairs, cyclic scanning.
        table = {("probe",): [(2, None, 2), (3, None, 3), (.5, None, .5), (.5, None, .5)]}
        self.assertEqual([self.module.kernel_draw(table, [("probe",)], u, 1)[0][-1]
                          for u in (.125, .375, .625, .875)], [2, 3, 2, 2])

    def test_cache_scope_is_cut_and_draw_objects_not_reused_origin_key(self):
        base, fast = self.scorers()
        request = MeanFamilyTests().request()
        for rate in (2., 4., 0.):
            cut = planner._immutable({**request.cut, "law": rate})
            draw = planner._immutable(base.draw(cut, "same-key", 0))
            self.assertEqual(fast.score(cut, (32,) * 5, draw), base.score(cut, (32,) * 5, draw))
            self.assertEqual(fast.prefix_evaluations, 5)
        with self.assertRaisesRegex(ValueError, "immutable"):
            fast.score(dict(cut), (32,) * 5, draw)

    def test_solver_freeze_copies_nested_data_behind_mapping_proxy(self):
        base, fast = self.scorers()
        owned = MeanFamilyTests().request().cut
        cut = planner._immutable(planner.MappingProxyType(owned))
        draw_data = base.draw(cut, "proxy-key", 0)
        draw = planner._immutable(planner.MappingProxyType(draw_data))
        expected = base.score(cut, (32,) * 5, draw)
        self.assertEqual(fast.score(cut, (32,) * 5, draw), expected)
        owned["live"].clear()
        draw_data["arrivals"].clear()
        self.assertEqual(len(cut["live"]), 1)
        self.assertEqual(base.score(cut, (32,) * 5, draw), expected)
        self.assertEqual(fast.score(cut, (32,) * 5, draw), expected)

    def test_unsupported_kernel_does_not_invent_zero_or_reuse_failed_prefix(self):
        kernels = dict(cohort={("key",): [(10., None, 10.)]}, birth={})
        costs = {("test", 128): 1.}
        base = planner.FrozenV5MeanScorer(self.module, kernels, costs, {})
        fast = planner.FrozenV5PrefixScorer(self.module, kernels, costs, {})
        cut = planner._immutable(dict(t0=0., cell="test", law=0., mix=[],
                                      live=[("old", 24., None, [("key",)])], pending=[]))
        draw = planner._immutable(dict(arrivals=[(.1, 128, .2)], live_u=[.5], pending_u=[]))
        self.assertEqual(base.score(cut, (16,) * 5, draw), fast.score(cut, (16,) * 5, draw))
        for scorer in (base, fast, fast):
            with self.assertRaisesRegex(ValueError, "kernel_unsupported"):
                scorer.score(cut, (32,) * 5, draw)
        self.assertEqual(base.score(cut, (16,) * 5, draw), fast.score(cut, (16,) * 5, draw))

    def test_same_optimizer_predictions_ties_and_guards(self):
        base, fast = self.scorers()
        request = MeanFamilyTests().request()
        request = replace(request, identity=replace(
            request.identity, clock_domain=base.clock_domain, cost_model=base.cost_hash))
        results = []
        for scorer in (base, fast):
            scorer.support_reasons = lambda _: []
            results.append(planner.optimize_v5_mean(
                request, scorer, enabled=True, deadline_at=100.1, now=lambda: 100.))
        for result in results:
            self.assertEqual(result["status"], "experimental_candidate")
            self.assertFalse(result["active_permit"])
        self.assertEqual(planner._r10_ranking(results[0]), planner._r10_ranking(results[1]))
        self.assertEqual([(r["plan"], r["mean_good"]) for r in results[0]["scores"]],
                         [(r["plan"], r["mean_good"]) for r in results[1]["scores"]])
        for scorer in (base, fast):
            self.assertEqual(planner.optimize_v5_mean(request, scorer)["status"], "inactive")
            self.assertEqual(planner.optimize_v5_mean(
                request, scorer, enabled=True, deadline_at=100., now=lambda: 100.)["status"],
                "deadline")

    def test_measurement_rejects_unqualified_python_and_censored_ranking(self):
        with patch.object(sys, "version_info", (3, 14, 4)):
            with self.assertRaisesRegex(ValueError, "qualified PY312"):
                planner.run_r10("unused", "unused", "unused")
        self.assertIsNone(planner._r10_ranking(
            dict(scores=[], pair_family_support=dict(mpc_complete=False))))

    def test_admission_load_path_can_move_good_across_horizon_without_more_eventual_good(self):
        # Hypothetical kernel witness, not a fit or native outcome.
        early = [(3., None, 2.8)] * 10
        kernels = dict(
            cohort={("key",): [(3., None, 3.)]},
            birth={("test", 128): early + [(2.5, 2., 2.)] * 10,
                   ("test", 128, 1): early + [(2.5, 2., 2.)] * 10,
                   ("test", 128, 2): early + [(4.5, 4., 4.)] * 10})
        costs = {("test", 128): 1.}
        base = planner.FrozenV5MeanScorer(self.module, kernels, costs, {})
        fast = planner.FrozenV5PrefixScorer(self.module, kernels, costs, {}, trace=True)
        cut = planner._immutable(dict(
            t0=0., cell="test", law=0., mix=[],
            live=[(f"old{i}", 2., None, [("key",)]) for i in range(8)], pending=[]))
        draw = planner._immutable(dict(
            live_u=[.5] * 8, pending_u=[],
            arrivals=[(1.1 + i * .01, 128, .1) for i in range(8)] + [(2.1, 128, .9)]))
        one, full = (32,) * 5, (32, 16, 32, 32, 32)
        for plan in (one, full):
            self.assertEqual(base.score(cut, plan, draw), fast.score(cut, plan, draw))
        self.assertEqual(base.score(cut, one, draw)["good_5"], 0.)
        self.assertEqual(base.score(cut, full, draw)["good_5"], 1.)
        left, right = (fast.path_evidence(cut, p, draw) for p in (one, full))
        self.assertEqual((left["events"][-1]["cap"], right["events"][-1]["cap"]), (32, 32))
        self.assertEqual((left["events"][-1]["load"], right["events"][-1]["load"]), (16, 8))
        self.assertEqual((left["good_after_5"], right["good_after_5"]), (1, 0))
        self.assertEqual((left["total_drawn_good"], right["total_drawn_good"]), (1, 1))


class CoupledWorkTests(unittest.TestCase):
    def capacity(self):
        return planner.WorkCapacity(1200., 12., 32, .4)

    def test_fixed_common_offer_changes_existing_work_only_through_admission(self):
        initial = planner.WorkBatch(0., (planner.WorkOwner("old", 16., 0., 6.),), kv_usage=.1)
        rng = random.Random(181001)
        offer = planner.WorkOwner("same-offer", 8., float(rng.randrange(1000, 1300)), 4.)
        low, low_admitted = planner.admit_work(initial, offer, 16)
        high, high_admitted = planner.admit_work(initial, offer, 32)
        self.assertFalse(low_admitted)
        self.assertTrue(high_admitted)
        left, left_events = planner.advance_work(low, .5, self.capacity())
        right, right_events = planner.advance_work(high, .5, self.capacity())
        self.assertEqual(left.owners[0].decode_left, 0.)
        self.assertEqual(right.owners[0].decode_left, 3.)
        self.assertIn(("old", "work_done", .5), left_events)
        self.assertNotIn(("old", "work_done", .5), right_events)
        self.assertEqual((left.reserved, right.reserved), (16., 24.))
        # A nonbinding cap cannot enter service through another path.
        empty = planner.WorkBatch(0., ())
        a, _ = planner.admit_work(empty, offer, 16)
        b, _ = planner.admit_work(empty, offer, 32)
        self.assertEqual(planner.advance_work(a, .5, self.capacity()),
                         planner.advance_work(b, .5, self.capacity()))

    def test_phase_crossing_and_early_finish_reallocate_without_lost_time(self):
        initial = planner.WorkBatch(0., (planner.WorkOwner("a", 1., 120., 1.2),
                                         planner.WorkOwner("b", 1., 0., 12.)))
        final, events = planner.advance_work(initial, .5, self.capacity())
        self.assertEqual(final.owners[0].prefill_left, 0)
        self.assertEqual(final.owners[0].decode_left, 0)
        self.assertAlmostEqual(final.owners[1].decode_left, 8.4)
        self.assertIn(("a", "prefill_done", .2), events)
        self.assertIn(("a", "work_done", .4), events)
        spent = 120 / 1200 + (1.2 + 12 - final.owners[1].decode_left) / 12
        self.assertAlmostEqual(spent, .5)

    def test_free_running_split_steps_match_one_step_and_idle_work_retains_cost(self):
        initial = planner.WorkBatch(0., (planner.WorkOwner("a", 3., 120., 1.2),))
        whole, events = planner.advance_work(initial, .5, self.capacity())
        half, a = planner.advance_work(initial, .25, self.capacity())
        split, b = planner.advance_work(half, .25, self.capacity())
        self.assertEqual(whole, split)
        self.assertEqual(events, a + b)
        self.assertEqual(whole.reserved, 3.)
        released = planner.release_work(whole, "a")
        self.assertEqual(released.reserved, 0.)
        with self.assertRaises(ValueError):
            planner.release_work(released, "a")
        with self.assertRaises(ValueError):
            planner.admit_work(released, initial.owners[0], 32)

    def test_cost_drop_does_not_evict_or_release_unfinished_owner(self):
        initial = planner.WorkBatch(0., (planner.WorkOwner("old", 24., 0., 12.),))
        state, admitted = planner.admit_work(initial, planner.WorkOwner("new", 1., 1., 1.), 16)
        self.assertFalse(admitted)
        self.assertEqual(state, initial)
        evolved, _ = planner.advance_work(state, .5, self.capacity())
        self.assertEqual(evolved.reserved, 24.)
        self.assertEqual(evolved.owners[0].decode_left, 6.)
        with self.assertRaises(ValueError):
            planner.release_work(evolved, "old")

    def test_missing_work_waiting_kv_and_batch_support_are_not_zero_imputed(self):
        state = planner.WorkBatch(0., (planner.WorkOwner("old", 1., 0., 6.),))
        for bad in (replace(state, unknown_costs=(("unknown", 2.),)),
                    replace(state, waiting=1), replace(state, kv_usage=.5)):
            with self.subTest(bad=bad), self.assertRaisesRegex(ValueError, "unresolved"):
                planner.advance_work(bad, .5, self.capacity())
        with self.assertRaisesRegex(ValueError, "batch-size"):
            planner.advance_work(replace(state, owners=(
                planner.WorkOwner("a", 1., 0., 6.), planner.WorkOwner("b", 1., 0., 6.))),
                .5, replace(self.capacity(), max_active=1))
        with self.assertRaises(ValueError):
            planner.advance_work(state, 1., self.capacity())


class StayerOutputTests(unittest.TestCase):
    def prefix(self, i=0):
        return planner.OutputCounterPrefix(
            20 + i, 128, 30. + i, 31. + i, 2 + i % 4, i % 2, 1, .2, .1, .25)

    def fit(self):
        from dataclasses import asdict
        return planner.StayerOutputModel.fit([
            dict(block=181001 + i % 3, horizon=.5, prefix=asdict(self.prefix(i)),
                 rate=self.prefix(i).past_rate + 5.) for i in range(24)])

    def test_portable_counter_prediction_keeps_bounds_and_is_not_full_good(self):
        model = self.fit()
        copied = planner.StayerOutputModel(planner.json.loads(planner.json.dumps(model.artifact)))
        for horizon in (.5, 1., 3., 5.):
            prediction = model.predict(self.prefix(), horizon)
            self.assertEqual(prediction, copied.predict(self.prefix(), horizon))
            self.assertAlmostEqual(prediction["delta_output"], min(108., 35. * horizon))
            self.assertFalse(prediction["active_permit"])
            self.assertTrue(prediction["conditional_on_native_stayer"])

    def test_training_scope_and_counter_prefix_are_fenced(self):
        from dataclasses import asdict
        records = [dict(block=181004, horizon=.5, prefix=asdict(self.prefix()), rate=30.)] * 20
        with self.assertRaisesRegex(ValueError, "partition"):
            planner.StayerOutputModel.fit(records)
        model = self.fit()
        for bad in (replace(self.prefix(), output=129), replace(self.prefix(), past_rate=-1.),
                    replace(self.prefix(), running=0), replace(self.prefix(), kv=float("nan"))):
            with self.assertRaises(ValueError):
                model.predict(bad, .5)

    def episode(self):
        import re
        from types import SimpleNamespace
        rid = "a" * 32
        module = SimpleNamespace(
            NATIVE_ID=re.compile(r"chatcmpl-([a-f0-9]{32})-[a-f0-9]{8}"),
            _marks=lambda gateway, episode: gateway["requests"],
            _native=lambda *args: None, _budget_provenance=lambda *args: None)
        observations = []
        for i in range(21):
            t = i / 4.
            request = dict(request_id=f"chatcmpl-{rid}-12345678", prompt_tokens=10,
                           computed_tokens=11 + i * 5, output_tokens=1 + i * 5,
                           maximum_output_tokens=128)
            observations.append(dict(
                gateway=dict(requests={rid: dict(cost=1., prompt_tokens=10)}),
                received_at=t + .005, native_received_at=t + .01,
                native=dict(sampled_at=t, requests=[request], running=1, waiting=0,
                            pending_batches=1, kv_cache_usage=.1)))
        return dict(episode_id="unit", seed_block=181001, observations=observations,
                    start=0., duration_s=5., actions=[]), module

    def test_future_disappearance_censors_instead_of_zero_or_reappearance(self):
        episode, module = self.episode()
        rows, _ = planner._counter_records(episode, module, (.5,))
        self.assertTrue(any(r["origin_index"] == 4 for r in rows))
        episode["observations"][6]["native"]["requests"] = []
        episode["observations"][6]["native"]["running"] = 0
        after, masks = planner._counter_records(episode, module, (.5,))
        self.assertFalse(any(r["origin_index"] == 4 for r in after))
        self.assertGreater(masks["target_0.5:native_id_disappeared"], 0)

    def test_future_reported_output_changes_labels_not_prefix_features(self):
        episode, module = self.episode()
        rows, _ = planner._counter_records(episode, module, (.5,))
        before = next(r for r in rows if r["origin_index"] == 4)
        for obs in episode["observations"][5:]:
            obs["native"]["requests"][0]["output_tokens"] += 5
            obs["native"]["requests"][0]["computed_tokens"] += 5
        rows, _ = planner._counter_records(episode, module, (.5,))
        after = next(r for r in rows if r["origin_index"] == 4)
        self.assertEqual(before["prefix"], after["prefix"])
        self.assertEqual(after["delta"], before["delta"] + 5)


@unittest.skipUnless(os.environ.get("NV3_R11_FREEZE"), "set NV3_R11_FREEZE for source-pinned audit")
class FrozenR12AuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.opus = planner._r12_load(
            Path(os.environ["NV3_R11_FREEZE"]) / "opus/native_release_model.py",
            "test_r12_opus", planner.R12_OPUS_SHA)

    def fixture(self, costs, entry=("H", "ok", 0)):
        table = {("D1", "ok"): [("GONE", "end", 0)],
                 ("H", "ok"): [("H", "ok", 0)], ("Z", "ok"): [("GONE", "end", 0)]}
        table.update({("entry", "unit", c): [entry] for c in costs})
        return (dict(cell="unit", table=table, prompt_k={("unit", c): .128 for c in costs}),
                {("unit", c): value for c, value in costs.items()})

    def test_same_sampled_release_changes_local_admission_not_source_forecast(self):
        model, costs = self.fixture({0: 16., 1: 8.})
        result = planner.audit_v8_order(
            self.opus, [("D1", "ok", 0)], [16] * 10, [(.1, 1, .5)],
            [[.5] * 10 for _ in range(2)], model, costs)
        event = result["steps"][0]["offers"][0]
        self.assertFalse(event["source_admitted"])
        self.assertTrue(event["release_first_admitted"])
        self.assertTrue(event["isolated_release_opportunity"])
        self.assertEqual(result["source_result"]["rejected_1"], 1.)
        self.assertEqual(result["steps"][0]["end_stock"], 0.)
        self.assertIsNone(result["counterfactual_good_forecast"])
        self.assertFalse(result["native_timing_identified"])

    def test_release_first_is_not_monotone_in_heterogeneous_admission_counts(self):
        model, costs = self.fixture({0: 8., 1: 16., 2: 4.})
        result = planner.audit_v8_order(
            self.opus, [("D1", "ok", 0)], [16] * 10,
            [(.1, 1, .5), (.2, 2, .5), (.3, 2, .5)],
            [[.5] * 10 for _ in range(4)], model, costs)
        events = result["steps"][0]["offers"]
        self.assertEqual([e["source_admitted"] for e in events], [False, True, True])
        self.assertEqual([e["release_first_admitted"] for e in events], [True, False, False])
        self.assertEqual(result["steps"][0]["admitted_cost"], 8.)
        self.assertTrue(all(abs(s["balance_residual"]) < 1e-12 for s in result["steps"]))

    def test_within_step_birth_release_is_accounted_but_not_silently_reordered(self):
        model, costs = self.fixture({1: 16., 2: 4.}, entry=("Z", "ok", 0))
        result = planner.audit_v8_order(
            self.opus, [], [16] * 10, [(.1, 1, .5), (.2, 2, .5)],
            [[.5] * 10 for _ in range(2)], model, costs)
        first = result["steps"][0]
        self.assertEqual(first["birth_released_cost"], 16.)
        self.assertEqual(first["end_stock"], 0.)
        self.assertFalse(first["offers"][1]["release_first_admitted"])
        self.assertEqual(first["balance_residual"], 0.)

    def test_known_stayer_does_not_cover_unknown_cost_or_future_owner(self):
        from types import SimpleNamespace
        module = SimpleNamespace(
            _marks=lambda gateway, episode: gateway["marks"],
            _native=lambda native, *args: native["ids"], _budget_provenance=lambda *args: None)
        old = {"old": {"cost": 8.}, "unknown": {"cost": 8.}}
        observations = [
            dict(gateway=dict(marks=old), received_at=.005, native_received_at=.01,
                 native=dict(sampled_at=0., ids={"old": 1})),
            dict(gateway=dict(marks={**old, "new": {"cost": 4.}}), received_at=.605,
                 native_received_at=.61, native=dict(sampled_at=.6, ids={"old": 2}))]
        episode = dict(episode_id="unit", seed_block=181004, observations=observations,
                       start=0., duration_s=5., actions=[])
        rows = {"181004": [dict(episode="unit", origin_index=0, horizon=.5, request_id="old")]}
        result = planner._r12_cost_coverage([episode], rows, module)
        first = result["blocks"]["181004"][0]
        self.assertEqual(first["native_invisible_cost"], 8.)
        self.assertEqual(first["unrepresented_original_cost"], 8.)
        self.assertEqual(first["target_new_owner_cost_label"], 4.)
        self.assertFalse(first["all_original_owners_counter_covered"])
        self.assertFalse(result["full_gateway_cost_forecast_available"])


@unittest.skipUnless(os.environ.get("NV3_R12_FREEZE"), "set NV3_R12_FREEZE for exact v9 tests")
class FrozenR13BinaryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.m = planner._r12_load(
            Path(os.environ["NV3_R12_FREEZE"]) / "opus/native_release_model.py",
            "test_r13_opus", planner.R13_V9_SHA)

    def world(self, scorer_type=planner.FrozenV9BinaryScorer):
        m = self.m
        costs = {("unit", 128): 5.75, ("unit", 256): 2.5}
        table = {("D1", "ok"): [("D1", "ok", 0), ("Z", "ok", 1), ("GONE", "end", 1)],
                 ("H", "ok"): [("D1", "ok", 0), ("H", "ok", 0)],
                 ("Q", "ok"): [("D1", "ok", 0)], ("Z", "ok"): [("GONE", "end", 0)]}
        table.update({("entry", "unit", c): [("H", "ok", 0), ("GONE", "end", 1)] for c in (128, 256)})
        model = dict(table=table, prompt_k={("unit", 128): 4.096, ("unit", 256): .128})
        step = dict(t0=10., cell="unit", cohort={"a", "b", "c"}, outstanding=0,
                    gateway=dict(budget=32, reserved=17.25, headroom=14.75, live=3, hist_offers=4))
        support = dict(ranges={}, bins={m._support_key(step): m.SUPPORT_MIN})
        scorer = scorer_type(
            m, model, costs, {(): tuple(sorted([0., .25, .5] * 20))}, support)
        cut = dict(t0=10., cell="unit", law=2., mix=[(128, 1), (256, 1)],
                   live=[(rid, 5.75, status, ()) for rid, status in (
                       ("a", None), ("b", "ttft_impossible"), ("c", None))],
                   pending=[("new", 5.75, 128, .2), ("seen", 2.5, 256, .1)])
        starts = {16: (("D1", "ok", 128),) * 3 + (("Z", "ok", 256),),
                  32: (("D1", "ok", 128),) * 3 + (("Q", "ok", 128), ("Z", "ok", 256))}
        request = planner.MeanPlanRequest(
            "unit-v9", Identity(planner.R8_CORE, "epoch", m.COMMON_BINDING["clock_domain"],
                               m.COMMON_BINDING["cost_hash"]), "native", 9.8, 9.9, "unit-v9",
            step, cut, tuple((rid, 5.75) for rid in ("a", "b", "c")))
        return request, starts, scorer

    def test_exact_all_plans_scenarios_nested_family_and_prefix_work_count(self):
        request, starts, scorer = self.world()
        original = copy.deepcopy((request, starts))
        ref = planner.optimize_v9_binary(request, starts, scorer, method="reference", enabled=True)
        fast = planner.optimize_v9_binary(request, starts, scorer, enabled=True)
        self.assertEqual(ref["status"], "offline_candidate", ref["reason"])
        self.assertEqual(fast["status"], "offline_candidate", fast["reason"])
        self.assertEqual(ref["outputs"], fast["outputs"])
        self.assertEqual(ref["scores"], fast["scores"])
        self.assertEqual(ref["one_move"], fast["one_move"])
        self.assertEqual(ref["mpc"], fast["mpc"])
        self.assertEqual(ref["completed_half_steps"], 32 * 32 * 10)
        self.assertEqual(fast["completed_half_steps"], 32 * 62 * 2)
        self.assertEqual(fast["cached_prefixes"], 32 * 62)
        self.assertEqual(set(r["plan"] for r in fast["scores"][:4]), set(planner.R9_ONE_MOVE))
        self.assertGreaterEqual(fast["implied_gain"], 0.)
        self.assertEqual((request, starts), original)
        self.assertFalse(fast["active_permit"])

    def test_original_response_streams_are_preserved_not_silently_repaired(self):
        request, starts, scorer = self.world()
        for cap in planner.CAPS:
            plan = (cap,) * 5
            actual = self.m.r12_response(starts[cap], (cap,) * 10, request.cut, request.key,
                                        dict(scorer.model, cell="unit"), scorer.costs, scorer.offsets)
            runs = [scorer.reference(starts[cap], plan, scorer.tape(request.cut, request.key, i, starts),
                                     "unit") for i in range(32)]
            for name in planner.R13_METRICS:
                self.assertEqual(actual[name]["mean"], planner.math.fsum(r[name] for r in runs) / 32)
        tape = scorer.tape(request.cut, request.key, 0, starts)
        self.assertNotEqual(tape[1][len(starts[16])][0], tape[1][len(starts[32])][0])

    def test_release_tie_no_eviction_and_cache_reuse_under_reversed_plan_order(self):
        request, _, scorer = self.world()
        start = (("D1", "ok", 128),) * 3
        tape = (((.25, 256, .5),), ((.5,) * 10,) * 4, ((.5,) * 10,) * 4)
        cache, outputs = {}, {}
        for plan in planner.R9_ALL_PLANS:
            result, _ = scorer.prefix(start, plan, tape, "unit", cache, lambda: None)
            self.assertEqual(result, scorer.reference(start, plan, tape, "unit"))
            outputs[plan] = result
        for plan in reversed(planner.R9_ALL_PLANS):
            result, steps = scorer.prefix(start, plan, tape, "unit", cache, lambda: None)
            self.assertEqual(result, outputs[plan])
            self.assertEqual(steps, 0)
        # All three owners exceed cap16 initially; no eviction precedes their sampled release.
        state = (tuple(("D1", "ok", 128, i) for i in range(3)), 0, (), (), (), 0.)
        late_tape = (((.1, 256, .5),), tape[1], ((.99,) * 10,) * 4)
        after = scorer.advance(state, 16, late_tape, "unit", 3)
        self.assertEqual(after[3], (.1,))

    def test_deadlines_inactive_clock_and_original_cost_guards(self):
        request, starts, scorer = self.world()
        self.assertEqual(planner.optimize_v9_binary(request, starts, scorer)["status"], "inactive")
        for method in ("reference", "prefix"):
            result = planner.optimize_v9_binary(
                request, starts, scorer, enabled=True, method=method, deadline_at=0., now=lambda: 0.)
            self.assertEqual(result["status"], "deadline")
            self.assertIsNone(result["candidate_first_action"])
        bad = replace(request, original_costs=(("a", 1.), ("b", 5.75), ("c", 5.75)))
        self.assertEqual(planner.optimize_v9_binary(bad, starts, scorer, enabled=True)["status"], "unsupported")
        missing = dict(starts)
        missing[16] = starts[16][1:]
        self.assertEqual(planner.optimize_v9_binary(request, missing, scorer, enabled=True)["status"],
                         "unsupported")
        times = iter((1., .9, .9))
        result = planner.optimize_v9_binary(request, starts, scorer, enabled=True, now=lambda: next(times))
        self.assertEqual(result["status"], "unsupported")

    def test_late_callback_cannot_produce_a_candidate_and_missing_kernel_is_explicit(self):
        request, starts, scorer = self.world()
        clock = [0.]
        original = scorer.advance

        def late(*args):
            result = original(*args)
            clock[0] = .2
            return result
        with patch.object(scorer, "advance", late):
            result = planner.optimize_v9_binary(request, starts, scorer, enabled=True,
                                                 deadline_at=.1, now=lambda: clock[0])
        self.assertEqual(result["status"], "deadline")
        self.assertIsNone(result["candidate_first_action"])
        self.assertEqual(result["wall_s"], .2)
        scorer.model = planner._immutable(dict(table={}, prompt_k={("unit", 128): 4.096,
                                                                  ("unit", 256): .128}))
        result = planner.optimize_v9_binary(request, starts, scorer, enabled=True)
        self.assertEqual(result["status"], "unsupported")
        self.assertIn("r11_unsupported", result["reason"])


@unittest.skipUnless(os.environ.get("NV3_R13_FREEZE"), "set NV3_R13_FREEZE for stable v10 tests")
class FrozenR14StableTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.m = planner._r12_load(
            Path(os.environ["NV3_R13_FREEZE"]) / "opus/native_release_model.py",
            "test_r14_opus", planner.R14_V10_SHA)

    def world(self):
        request, starts, scorer = FrozenR13BinaryTests.world(self, planner.FrozenV10BinaryScorer)
        ids = {16: ("rid:a", "rid:b", "rid:c", "rid:seen"),
               32: ("rid:a", "rid:b", "rid:c", "rid:new", "rid:seen")}
        return request, starts, ids, scorer

    def test_exact_all_plans_against_frozen_v10_runs_and_strong_family(self):
        request, starts, ids, scorer = self.world()
        ref = planner.optimize_v10_binary(request, starts, ids, scorer, method="reference", enabled=True)
        fast = planner.optimize_v10_binary(request, starts, ids, scorer, enabled=True)
        self.assertEqual(ref["status"], "offline_candidate", ref["reason"])
        self.assertEqual(fast["status"], "offline_candidate", fast["reason"])
        self.assertEqual(ref["outputs"], fast["outputs"])
        self.assertEqual(ref["scores"], fast["scores"])
        self.assertEqual(fast["completed_half_steps"], 3968)
        self.assertEqual(ref["completed_half_steps"], 10240)
        self.assertEqual(fast["one_move"], ref["one_move"])
        self.assertEqual(fast["mpc"], ref["mpc"])
        self.assertGreaterEqual(fast["implied_gain"], 0.)
        for score, actual in zip(ref["scores"], ref["outputs"]):
            plan = score["plan"]
            expected = self.m.r13_runs(
                starts[plan[0]], ids[plan[0]], tuple(c for c in plan for _ in range(2)),
                request.cut, request.key, dict(scorer.model, cell="unit"), scorer.costs,
                offsets=scorer.offsets)
            self.assertEqual(actual, tuple(tuple(r[k] for k in planner.R13_METRICS) for r in expected))
        self.assertFalse(fast["active_permit"])

    def test_identity_streams_survive_q_insertion_and_rejected_arrival_gaps(self):
        request, starts, ids, scorer = self.world()
        tape = scorer.tape(request.cut, request.key, 0, starts, ids)
        a, b = (scorer.plan_tape(tape, cap) for cap in planner.CAPS)
        self.assertIs(a[0], b[0])
        for kind in (1, 2):
            for ident in set(ids[16]) & set(ids[32]):
                self.assertEqual(a[kind][ids[16].index(ident)], b[kind][ids[32].index(ident)])
            for i in range(len(a[0])):
                self.assertEqual(a[kind].identity(len(ids[16]) + i), f"arrival:{i}")
                self.assertEqual(a[kind][len(ids[16]) + i], b[kind][len(ids[32]) + i])
        self.assertNotEqual(a[1][0], a[2][0])
        other_scenario = scorer.tape(request.cut, request.key, 1, starts, ids)
        other_cut = scorer.tape(request.cut, request.key + "-other", 0, starts, ids)
        fresh = scorer.tape(request.cut, request.key, 0, starts, ids)
        self.assertNotEqual(a[1][0], other_scenario[16][1][0])
        self.assertNotEqual(a[1][0], other_cut[16][1][0])
        self.assertIsNot(a[1].cache, fresh[16][1].cache)
        self.assertEqual(a[1][0], fresh[16][1][0])

    def test_identity_refusals_source_separation_and_deadline(self):
        request, starts, ids, scorer = self.world()
        for invalid in (None, {16: ids[16], 32: ids[32][:-1]},
                        {16: ("rid:a",) * 4, 32: ids[32]},
                        {16: ids[16][:-1] + ("arrival:0",), 32: ids[32]}):
            result = planner.optimize_v10_binary(request, starts, invalid, scorer, enabled=True)
            self.assertEqual(result["status"], "unsupported")
            self.assertIsNone(result["candidate_first_action"])
        self.assertEqual(planner.optimize_v9_binary(request, starts, scorer, enabled=True)["status"],
                         "unsupported")
        self.assertEqual(planner.optimize_v10_binary(request, starts, ids, scorer)["status"], "inactive")
        result = planner.optimize_v10_binary(request, starts, ids, scorer, enabled=True,
                                             deadline_at=0., now=lambda: 0.)
        self.assertEqual(result["status"], "deadline")
        self.assertIsNone(result["candidate_first_action"])


class R15ActionValueTests(unittest.TestCase):
    def scores(self):
        return [dict(plan=p, mean_good=[0., 0., 8. if p[0] == 16 else 7.])
                for p in planner.R9_ALL_PLANS]

    def test_tail_gain_changes_first_action_only_when_conditional_ranking_changes(self):
        scores = self.scores()
        for row in scores:
            if row["plan"] == (32, 16, 32, 16, 32):
                row["mean_good"][2] = 9.
        result = planner.r15_action_value(scores, 16)
        self.assertEqual(result["one_margin_32_minus_16"], -1.)
        self.assertEqual(result["full_margin_32_minus_16"], 1.)
        self.assertEqual(result["conditional"][32]["tail_bonus"], 2.)
        self.assertTrue(result["first_action_differs"])
        self.assertEqual(result["one_plan"][0], 16)
        self.assertEqual(result["full_plan"][0], 32)
        for row in scores:
            if row["plan"] == (16, 32, 16, 32, 16):
                row["mean_good"][2] = 10.
        result = planner.r15_action_value(scores, 16)
        self.assertGreater(result["implied_gain"], 0.)
        self.assertFalse(result["first_action_differs"])

    def test_ties_preserve_incumbent_and_incomplete_tables_are_not_ties(self):
        scores = self.scores()
        for row in scores:
            row["mean_good"] = [0., 0., 0.]
        result = planner.r15_action_value(scores, 32)
        self.assertEqual(result["one_plan"], (32,) * 5)
        self.assertEqual(result["full_plan"], (32,) * 5)
        for invalid in (scores[:-1], scores[:-1] + scores[:1]):
            with self.assertRaises(ValueError):
                planner.r15_action_value(invalid, 32)
        scores[0]["mean_good"] = [0., 1., 0.]
        with self.assertRaises(ValueError):
            planner.r15_action_value(scores, 32)


@unittest.skipUnless(os.environ.get("NV3_SOURCE144_REPO"), "set NV3_SOURCE144_REPO for source witness")
class R15GatewayWitnessTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import subprocess
        cls.source = subprocess.check_output([
            "git", "-C", os.environ["NV3_SOURCE144_REPO"], "show",
            "144cef32a9b51c3a74355ff67f5eafdfac6e075f:gateway.py"])

    def test_actual_source_holds_cost_after_first_content_and_non_eviction(self):
        result = planner.r15_gateway_witness(self.source)
        self.assertEqual(result["after_downshift_and_first_content"],
                         dict(owners=4, cost=20., first_at=10.))
        self.assertFalse(result["over_budget_accepted"])
        self.assertEqual(result["after_terminal_release_cost"], 15.)
        self.assertTrue(result["after_release_accepted"])
        self.assertEqual(result["final_cost"], 16.)
        self.assertEqual(result["final_owner_cost_sum"], 16.)
        self.assertEqual(result["final_owners"], 4)
        self.assertFalse(result["native_execution"])
        self.assertFalse(result["active_permit"])

    def test_modified_gateway_cannot_claim_exact_source(self):
        with self.assertRaisesRegex(ValueError, "Source144"):
            planner.r15_gateway_witness(self.source + b"\n")


class FittedFullPlanTests(unittest.TestCase):
    def prefix(self, caps=(16, 16, 16, 16, 16), reserved=8., rate=4.):
        state = dict.fromkeys(planner.R8_STATE, 0.)
        state.update(reserved=reserved, live=4., budget=16., headroom=16. - reserved,
                     unstarted=2., hist_released_cost=4., running=4.,
                     prefill_remaining_k=2., native_unknown_frac=.25)
        return planner.FullPlanInput(
            10., 9.9, tuple(state[n] for n in planner.R8_STATE), rate, 1.,
            tuple((float(j), cap) for j, cap in enumerate(caps)),
            "unit-cell", "unit-source", "unit-collector")

    def fit(self):
        records = []
        for i in range(32):
            x = self.prefix(tuple(32 if i & (1 << j) else 16 for j in range(5)),
                            reserved=float(8 + i % 8), rate=float(2 + i % 4))
            records.append((181001, x, (1. + i % 2, 4. + i % 3, 8. + i % 4)))
        return planner.FittedFullPlanResponse.fit(records)

    def test_fitted_serialization_causal_mask_and_shared_law(self):
        fitted = self.fit()
        copied = planner.FittedFullPlanResponse(planner.json.loads(
            planner.json.dumps(fitted.artifact)))
        x = self.prefix()
        late = replace(x, timed_plan=((0., 16), (1., 16), (2., 16), (3., 32), (4., 32)))
        for h in (1., 3.):
            self.assertEqual(planner.full_plan_features(x, h),
                             planner.full_plan_features(late, h))
        p, q = fitted.predict(x), copied.predict(late)
        self.assertEqual(p["good"][:2], q["good"][:2])
        self.assertEqual(p["expected_offers"], q["expected_offers"])
        self.assertEqual(p, copied.predict(x))
        self.assertNotEqual(p["expected_offers"],
                            copied.predict(replace(x, arrival_rate=5.))["expected_offers"])
        self.assertFalse(p["active_permit"])

    def test_nonbinding_headroom_has_no_future_cap_effect(self):
        x = self.prefix(reserved=0., rate=1.)
        high = replace(x, timed_plan=tuple((float(j), 32) for j in range(5)))
        for h in planner.OFFSETS:
            self.assertEqual(planner.full_plan_features(x, h),
                             planner.full_plan_features(high, h))
        self.assertEqual(self.fit().predict(x)["good"], self.fit().predict(high)["good"])
        crowded = self.prefix(reserved=15., rate=4.)
        self.assertNotEqual(planner.full_plan_features(crowded, 5.),
                            planner.full_plan_features(
                                replace(crowded, timed_plan=high.timed_plan), 5.))

    def test_cumulative_projection_does_not_change_early_horizons(self):
        fitted = self.fit()
        for model, intercept in zip(fitted.artifact["models"], (3., -2., 1.)):
            model["beta"] = [intercept] + [0.] * len(model["mean"])
        self.assertEqual(fitted.predict(self.prefix())["good"], [3., 3., 3.])

    def test_partition_source_timing_and_transport_masks(self):
        x = self.prefix()
        with self.assertRaisesRegex(ValueError, "Train-only"):
            planner.FittedFullPlanResponse.fit([(181004, x, (1., 2., 3.))])
        with self.assertRaisesRegex(ValueError, "Train-only"):
            planner.FittedFullPlanResponse.fit([(181001, x, (2., 1., 3.))])
        with self.assertRaisesRegex(ValueError, "prefix"):
            planner.full_plan_features(replace(x, received_at=11.), 1.)
        with self.assertRaisesRegex(ValueError, "timed"):
            planner.full_plan_features(replace(x, timed_plan=((.5, 16),) * 5), 1.)
        fitted = self.fit()
        with self.assertRaisesRegex(ValueError, "source"):
            fitted.predict(replace(x, source_id="changed-core"))
        p = fitted.predict(replace(x, collector_id="new-hold-collector", arrival_rate=100.))
        self.assertIn("collector_ACK_hold_transport_unqualified", p["warnings"])
        self.assertIn("range:arrival_rate", p["support_reasons"])
        self.assertIn("controller_client_history_receipts_unverified", p["warnings"])

    def test_future_outcome_cannot_backdate_prefix_history_or_payload_law(self):
        x = self.prefix()
        s = dict(t0=10., gateway=dict(zip(planner.R8_STATE[:13], x.state[:13])),
                 native=dict(zip(planner.R8_STATE[13:-1], x.state[13:-1])),
                 plan=[16.] * 11)
        row = dict(sent_at=9., requested_max_tokens=128, scheduled_at=9.,
                   terminal_at=11., first_content_at=None, admission_rejection=True)
        e = dict(cell="p128-m128", client_rows=[row])
        obs = dict(native_received_at=9.9, native=dict(requests=[]),
                   gateway=dict(cost_spec=dict(minimum=.1, intercept=.2,
                                               input_per_token=.001, output_per_token=.01)))
        receipt = dict(source_id="unit-source", collector="unit-collector")
        _, before = planner._r8_prefix(e, s, receipt, obs)
        row["admission_rejection"] = False
        row["first_content_at"] = 10.5
        _, after = planner._r8_prefix(e, s, receipt, obs)
        self.assertEqual(before, after)
        row["terminal_at"] = 9.8
        row["first_content_at"] = 9.6
        _, published = planner._r8_prefix(e, s, receipt, obs)
        self.assertNotEqual(before.state, published.state)
        self.assertEqual(before.arrival_rate, published.arrival_rate)

    def test_confirmed_hold_preserves_original_ack_lineage(self):
        index = dict(clock_domain="clock", model_identity={})
        command = dict(run_id="gateway", clock_domain="clock", identity={},
                       operation_id="op", budget=16, expected_version=0, not_after=.1)
        ack = dict(run_id="gateway", clock_domain="clock", operation_id="op",
                   budget=16, budget_version=1, applied_at=0.)
        hold = dict(at_s=1, budget=16, budget_version=1, run_id="gateway",
                    clock_domain="clock", status="confirmed_hold", confirmed_at=1.03,
                    reference_operation_id="op", state_observation=dict(
                        run_id="gateway", clock_domain="clock", budget_version=1,
                        get_started_at=1., sampled_at=1.01, get_received_at=1.02))
        document = dict(start=0., gateway_run_id="gateway",
                        schedule=[dict(at_s=0, budget=16), dict(at_s=1, budget=16)],
                        preassignment=[dict(received_at=.05, reply=dict(
                            status="applied", acknowledgment=ack, command=command))],
                        actions=[], held_assignments=[hold])
        receipt = planner._r8_execution(document, index)
        self.assertEqual(receipt["applied_operations"], 1)
        self.assertEqual(receipt["confirmed_holds"][0][-1], 1.03)
        self.assertTrue(receipt["holds_are_not_new_CAS"])
        hold["budget_version"] = 2
        with self.assertRaisesRegex(ValueError, "hold lineage"):
            planner._r8_execution(document, index)


class FullPlanIdentificationWitness(unittest.TestCase):
    def test_randomized_slot_coverage_does_not_identify_unsupported_full_plans(self):
        offers = (planner.FlowRequest("a", 16, .1, 128, 256),
                  planner.FlowRequest("b", 8, 1.1, 128, 256),
                  planner.FlowRequest("c", 8, 2.1, 128, 256))
        observed_plans = ((16, 32, 16, 32, 16), (32, 16, 32, 16, 32))
        for slot in range(5):
            self.assertEqual({plan[slot] for plan in observed_plans}, {16, 32})
        low, high = (16,) * 5, (32,) * 5
        self.assertNotIn(low, observed_plans)
        self.assertNotIn(high, observed_plans)

        def replay(plan, burst_completion):
            flow = planner.FlowState((), (
                planner.FlowView(0, 16, 16, (), (0, 0, 0, 0.), 0, ()),
            ), ())
            applications = {slot + .01: cap for slot, cap in enumerate(plan)}
            first = {.2: "a", 1.2: "b", 2.2: "c"}
            terminal = {"a": 4., "b": 3.25, "c": 4.25}
            times = sorted(set(applications) | set(first) | {o.offered_at for o in offers}
                           | {1., 3., 5., 3.25, 4., 4.25, 4.5, 6.})
            good, offered, admitted = [], [], []
            burst_seen = False
            for now in times:
                cap = plan[min(int(now), 4)]
                incoming = tuple(o for o in offers if o.offered_at == now)
                events = []
                if now in applications:
                    events.append(planner.FlowEvent(now, "apply", cap=applications[now]))
                live = dict(flow.history[-1].live)
                if now in first and first[now] in live:
                    events.append(planner.FlowEvent(
                        now, "progress", first[now], output_tokens=1))
                for rid in live:
                    if terminal[rid] == now:
                        events.extend((
                            planner.FlowEvent(now, "progress", rid, output_tokens=128),
                            planner.FlowEvent(now, "terminal", rid, natural_eos=True),
                            planner.FlowEvent(now, "release", rid),
                        ))
                flow = planner._advance_flow(
                    flow, cap, incoming,
                    planner.FlowStep(tuple(events), (), (None, None, None, None), now), now,
                )
                offered.extend(incoming)
                admitted.extend(o.request_id for o in incoming
                                if o.request_id in dict(flow.history[-1].live))
                # The two unfit service worlds differ only in an unobserved admitted batch.
                if not burst_seen and {"b", "c"} <= dict(flow.history[-1].live).keys():
                    terminal = {rid: burst_completion for rid in live.keys() | {"c"}}
                    burst_seen = True
                if now in (1, 3, 5):
                    good.append(sum(planner._good(r) for r in flow.requests))
            return tuple(good), tuple(offered), tuple(admitted), flow.history

        for plan in observed_plans:
            fast, slow = replay(plan, 4.5), replay(plan, 6.)
            self.assertEqual(fast, slow)
            self.assertEqual(fast[0], (0, 0, 2))
            self.assertEqual(fast[1], offers)
        low_fast, low_slow = replay(low, 4.5), replay(low, 6.)
        high_fast, high_slow = replay(high, 4.5), replay(high, 6.)
        self.assertEqual(low_fast, low_slow)
        self.assertEqual(low_fast[0], (0, 0, 1))
        self.assertEqual(high_fast[0], (0, 0, 3))
        self.assertEqual(high_slow[0], (0, 0, 0))
        self.assertEqual(high_fast[1:3], high_slow[1:3])
        self.assertEqual(high_fast[1], offers)
        self.assertEqual(high_fast[2], ("a", "b", "c"))
        self.assertGreater(high_fast[0][-1], low_fast[0][-1])
        self.assertLess(high_slow[0][-1], low_slow[0][-1])
        # A point band at2 covers the complete randomized support, but neither high-cap world.
        self.assertTrue(all(replay(plan, 4.5)[0][-1] == 2 for plan in observed_plans))
        self.assertTrue(all(result[0][-1] != 2 for result in (high_fast, high_slow)))


class ProgressArchitectureWitness(unittest.TestCase):
    def test_native_counter_prefix_does_not_authorize_invented_commit_or_tail(self):
        incomplete = planner.BatchProgress("p", 8, 2, 8, 0, 0, 1)
        with self.assertRaisesRegex(ValueError, "atomic"):
            planner.advance_joint_forward((incomplete,), ())
        prefill = replace(incomplete, prompt_done=7)
        with self.assertRaisesRegex(ValueError, "decode before prefill"):
            planner.advance_joint_forward((prefill,), (("p", 0, 1, 0),))
        with self.assertRaisesRegex(ValueError, "exceeds residual"):
            planner.advance_joint_forward((prefill,), (("p", 2, 0, 0),))
        finished, = planner.advance_joint_forward((prefill,), (("p", 1, 0, 0),))
        with self.assertRaisesRegex(ValueError, "preexisting queued"):
            planner.advance_joint_forward((finished,), (("p", 0, 0, 1),))
        with self.assertRaisesRegex(ValueError, "after finish"):
            planner.advance_joint_forward((finished,), (("p", 0, 1, 0),))

    def test_output_limit_is_not_natural_eos(self):
        request = planner.BatchProgress("p", 8, 1, 7, 0, 0, None)
        length, = planner.advance_joint_forward((request,), (("p", 1, 0, 0),))
        natural, = planner.advance_joint_forward(
            (replace(request, eos_at=1),), (("p", 1, 0, 0),))
        self.assertEqual((length.native_tokens, natural.native_tokens), (1, 1))
        self.assertEqual((length.finish_reason, natural.finish_reason), ("length", "stop"))

    def test_identical_oracle_arrivals_do_not_identify_good_without_batch_progress(self):
        future = planner.FlowRequest("new", 4, .1, 1, 2)

        def replay(prompt_done, cap):
            snapshot = replace(
                state(), applied_cap=cap, reserved_cost=12, native_running=2,
                requests=(RequestState("a", 8, 128, 2, 0, "prefill", .1),
                          RequestState("b", 4, 128, 12, 10, "decode", .1)),
            )
            law = replace(evaluation(), origin_offered_ids=("a", "b"),
                          scenarios=(Scenario("joint-test-draw", 1, 1),))
            seed = flow_model(EventKernel(), snapshot=snapshot, law=law,
                              offers=(future,)).paths[0].seed
            flow = planner._advance_flow(
                seed, cap, (future,), planner.FlowStep((), (), (None, None, 1, None), .125),
                .125,
            )
            self.assertFalse(flow.requests[-1].rejected)
            batch = (
                planner.BatchProgress("a", 128, 2, prompt_done, 0, 0, 1),
                planner.BatchProgress("b", 128, 12, 128, 10, 9, 11, queued_overhang=1),
                planner.BatchProgress("new", 1, 2, 0, 0, 0, 1),
            )
            goods, unresolved, service_trace = [], [], []
            release_before_overhang = False
            for tick in range(1, 21):
                # Six position opportunities is a countermodel fixture, not a native rate.
                remaining, allocation = 6, []
                for r in batch:
                    if r.finish_reason is not None and r.queued_overhang and remaining:
                        allocation.append((r.request_id, 0, 0, 1))
                        remaining -= 1
                for r in batch:
                    if r.finish_reason is None and r.native_tokens and remaining:
                        allocation.append((r.request_id, 0, 1, 0))
                        remaining -= 1
                for r in batch:
                    if r.finish_reason is None and not r.native_tokens and remaining:
                        count = min(remaining, r.prompt_tokens - r.prompt_done)
                        allocation.append((r.request_id, count, 0, 0))
                        remaining -= count
                updated = planner.advance_joint_forward(batch, tuple(allocation))
                now, events = tick / 4, []
                for before, after in zip(batch, updated):
                    if after.native_tokens > before.native_tokens:
                        events.append(planner.FlowEvent(
                            now, "progress", after.request_id, output_tokens=after.native_tokens))
                    if before.finish_reason is None and after.finish_reason is not None:
                        events.extend((
                            planner.FlowEvent(now, "terminal", after.request_id,
                                              natural_eos=after.finish_reason == "stop"),
                            planner.FlowEvent(now, "release", after.request_id),
                        ))
                # Explicit zero client-publication lag in this witness only.
                flow = planner._advance_flow(
                    flow, cap, (), planner.FlowStep(
                        tuple(events), (), (None, None, sum(r.queued_overhang for r in updated),
                                            None), now), now,
                )
                if tick == 1:
                    self.assertNotIn("b", dict(flow.history[-1].live))
                    self.assertEqual(updated[1].queued_overhang, 1)
                    release_before_overhang = True
                    self.assertIn(("b", 0, 1, 0), allocation)
                    self.assertTrue(any(row[1] > 0 for row in allocation))
                if tick == 2:
                    self.assertEqual(updated[1].native_tokens, 11)
                    self.assertEqual(updated[1].executed_overhang, 1)
                    self.assertEqual(updated[1].queued_overhang, 0)
                    self.assertFalse(any(event.request_id == "b" for event in events))
                service_trace.append((tuple(allocation), updated))
                batch = updated
                if now in (1, 3, 5):
                    goods.append(sum(planner._good(r) for r in flow.requests))
                    unresolved.append(sum(r.terminal_at is None and not r.rejected
                                          for r in flow.requests))
            return (tuple(goods), tuple(unresolved),
                    planner._good(flow.requests[-1]), tuple(service_trace),
                    release_before_overhang)

        near16, early16 = replay(124, 16), replay(0, 16)
        near32, early32 = replay(124, 32), replay(0, 32)
        self.assertEqual(near16, near32)
        self.assertEqual(early16, early32)
        self.assertEqual(near16[:3], ((3, 3, 3), (0, 0, 0), True))
        self.assertEqual(early16[:3], ((1, 1, 1), (2, 2, 2), False))
        self.assertEqual(near16[3][0][0], (("b", 0, 1, 0), ("a", 4, 0, 0), ("new", 1, 0, 0)))
        self.assertEqual(early16[3][0][0], (("b", 0, 1, 0), ("a", 5, 0, 0)))
        self.assertTrue(near16[-1] and early16[-1])


@unittest.skipUnless(os.environ.get("NV3_R4_FREEZE"), "explicit R4 archive not supplied")
class FrozenRoundFourOpusChecks(unittest.TestCase):
    """Four bounded checks of actual frozen R4 code, not native efficacy tests."""

    @classmethod
    def setUpClass(cls):
        root = Path(os.environ["NV3_R4_FREEZE"]) / "opus/experiments/mpc-research/native-v3"
        hashes = {
            "opus.md": "47a994c1d5541f24642e508c127e0950663170da52ffb785fa4e295d92823b27",
            "native_release_model.py":
                "670edf6627a53eae14ea80a47a88ffb4e0795254b606d90d3d58c3e13edfc2c8",
            "test_native_release_model.py":
                "8376e6b9d90843fec8a8d270ea6d41a1eec22f681048e2a0e2d53c5a60108eae",
        }
        sources = {}
        for filename, digest in hashes.items():
            sources[filename] = (root / filename).read_bytes()
            if hashlib.sha256(sources[filename]).hexdigest() != digest:
                raise ValueError(f"Opus R4 {filename} hash differs")

        def load(filename, name):
            path = root / filename
            spec = importlib.util.spec_from_file_location(name, path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[name] = module
            exec(compile(sources[filename], str(path), "exec"), module.__dict__)
            return module

        cls.opus = load("native_release_model.py", "nv3_r4_opus")
        with patch.dict(sys.modules, {"native_release_model": cls.opus}), \
                patch.object(sys, "path", list(sys.path)):
            cls.fixture = load("test_native_release_model.py", "nv3_r4_opus_fixture")

    def episode(self):
        return self.fixture.joint_episode([(1, 8, 128, 128, 0, .1, 3)])

    def at(self, episode, cut=.5):
        return next(s for s in self.opus.joint_steps(episode)[0] if s["t0"] == cut)

    def model(self, values):
        m = self.opus
        size = len(m.GATEWAY_FEATURES)
        return dict(mean=[0.] * size, scale=[1.] * size,
                    betas={target: [values.get(target, 0.)] + [0.] * size
                           for target in m.TARGETS})

    def rollout(self, model, step):
        m = self.opus
        residuals = [[dict.fromkeys(m.TARGETS, 0.) for _ in range(m.ROLLOUT_STEPS)]]
        return m._rollout(model, step, residuals, random.Random(7), 1)

    def test_candidate_budget_changes_offered_flow_with_identical_history_and_draws(self):
        m = self.opus
        left = self.at(self.episode())
        right = copy.deepcopy(left)
        left["plan"] = [16.] * (m.ROLLOUT_STEPS + 1)
        right["plan"] = [16.] + [32.] * m.ROLLOUT_STEPS
        model = self.model({})
        model["betas"]["offers"][1 + m.GATEWAY_FEATURES.index("next_plan_budget")] = 1.
        self.assertEqual(left["gateway"], right["gateway"])
        self.assertEqual(left["hist_steps"], right["hist_steps"])
        self.assertEqual([p[0]["offers"] for p in self.rollout(model, left)],
                         [16.] * m.SCENARIOS)
        self.assertEqual([p[0]["offers"] for p in self.rollout(model, right)],
                         [32.] * m.SCENARIOS)

    def test_clipping_and_residual_rollout_do_not_enforce_joint_flow_feasibility(self):
        m = self.opus
        step = self.at(self.episode())
        raw = dict.fromkeys(m.TARGETS, 0.)
        raw.update(released_cost=4., released_n=0., born_cost=40., born_n=0.,
                   offers=1., admitted=0., rejected=2., good=3.)
        clipped = m._clip(raw, reserved=8., live=1.)
        self.assertEqual(clipped, raw)
        self.assertEqual((clipped["released_n"], clipped["released_cost"]), (0, 4))
        self.assertEqual((clipped["born_n"], clipped["born_cost"]), (0, 40))
        paths = self.rollout(self.model(raw), step)
        self.assertTrue(all(p[0]["reserved"] == 44 for p in paths))
        self.assertTrue(all(p[0]["offers"] == 1 and p[0]["rejected"] == 2
                            and p[0]["good"] == 3 for p in paths))

    def test_endpoint_flow_omits_transient_identity_and_cannot_recover_its_cost(self):
        m, fixture = self.opus, self.fixture
        long = (1, 8, 128, 128, 0, .1, 3)
        a = fixture.joint_episode([long, (2, 4, 128, 128, .6, .61, .65)])
        b = fixture.joint_episode([long, (2, 1, 128, 128, .6, .61, .65)])
        left, right = self.at(a), self.at(b)
        self.assertEqual(left, right)
        self.assertEqual(left["labels"]["offers"], 1)
        self.assertEqual(left["labels"]["admitted"], 1)
        self.assertEqual(left["labels"]["good"], 1)
        self.assertEqual([left["labels"][key] for key in m.TARGETS[:4]], [0, 0, 0, 0])
        self.assertEqual(self.at(a, 1)["gateway"]["reserved"], 8)
        self.assertNotIn(fixture._uuid(2), left["cohort"] | self.at(a, 1)["cohort"])
        self.assertNotEqual(a["ledger"], b["ledger"])
        self.assertEqual(m.joint_steps(a)[1], m.joint_steps(b)[1])

    def test_future_rejection_classification_changes_preterminal_history_features(self):
        fixture = self.fixture
        rejected = fixture.joint_episode([(1, 8, 128, 128, 0, .1, 3)], rejected=[(2, .3)])
        rejected["client_rows"][1]["terminal_at"] = 1.5
        completed = copy.deepcopy(rejected)
        completed["client_rows"][1].update(
            admission_rejection=False, status="complete", finish_reason="stop",
            first_content_at=1.4, usage=dict(completion_tokens=50),
        )

        def received_prefix(episode):
            return [(r["request_id"], r["scheduled_at"], r["sent_at"],
                     r["first_content_at"] if r["first_content_at"] is not None
                     and r["first_content_at"] <= 1 else None,
                     r["terminal_at"] if r["terminal_at"] <= 1 else None)
                    for r in episode["client_rows"]]

        self.assertEqual(received_prefix(rejected), received_prefix(completed))
        self.assertEqual(rejected["observations"], completed["observations"])
        before, after = self.at(rejected, 1), self.at(completed, 1)
        self.assertEqual((before["gateway"]["hist_offers"], after["gateway"]["hist_offers"]),
                         (2, 2))
        self.assertEqual((before["gateway"]["hist_rejected"], after["gateway"]["hist_rejected"]),
                         (0, 0))
        self.assertEqual((before["gateway"]["hist_ttft_miss"], after["gateway"]["hist_ttft_miss"]),
                         (0, 1))
        self.assertEqual((sum(h["admitted"] for h in before["hist_steps"]),
                          sum(h["admitted"] for h in after["hist_steps"])), (1, 2))


if __name__ == "__main__":
    unittest.main()
