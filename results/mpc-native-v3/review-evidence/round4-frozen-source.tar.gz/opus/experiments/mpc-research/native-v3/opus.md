# NV3 Opus 獨立提案（Round 1）：history-conditioned 原始成本釋放模型

狀態：**獨立初稿，未讀 peer NV3 提案**。沒有新的 native／MPC 結果；
本文件與程式只定義可在實際 Gateway marks／ledger 與 native frames 上執行的
模型、ground truth 與否證測試。單元 fixtures 只驗證會計與因果性，
不是 native 性能、校準或統計保證。

## 1. 共同 ground truth：useful／physical／tail work（不放寬舊 audit）

Strict HTTP 基線（exact UUID、4096 prompt／32 output／natural EOS）：
34 steps＝2 prefill＋32 decode；worker 連續 forward positions 結束於 4128，
delivered-token 最小值 `P+O−1=4127`。舊 v2 `audit_capture` 的
`progress == input+output−1` 因此**仍為 FALSE，原樣保留**。

明確會計（`forward_work_accounting`）：

| 量 | 定義 | 基線值 |
|---|---|---:|
| useful positions | `P+O−1`（最後 sampled token 不需再 forward） | 4127 |
| physical positions | 實際連續 executed positions 終點 | 4128 |
| tail positions | physical − useful | 1 |
| useful steps | 結束 ≤ useful 邊界的 steps（2 prefill＋31 decode） | 33 |
| tail steps | 起點 ≥ useful 邊界的 steps | 1 |

`tail_accounted=True` 只在全部成立時：natural EOS；positions 無 gap／repeat／split；
每個 step 與 worker `executed_positions/executed_counts` 相符；tail ≤1 token；
tail step 是單 token decode 且 **schedule start < engine finish**（pre-finish placeholder）。
否證（各有測試）：tail step 在 finish 後才排程、tail>1（unexplained work）、
tail<0（missing useful work）、position gap、跨越 useful 邊界、worker 未匹配。
GPU elapsed 只是 per-step current-stream label，不是絕對 GPU／host clock
或獨占 service duration；本模組不把它相加成 service time。

對 release 模型的含義：reservation release 不早於 EOS output commit，
tail forward 是 release 之前可能的物理延遲來源；它作為誤差解釋 label，
不是預測輸入。

## 2. 可觀測狀態與 transition

Origin `t0`＝joined observation 的 native client receipt；要求同 run／clock domain、
`gateway.sampled_at ≤ received_at ≤ t0`、age ≤0.5s、native ID
`chatcmpl-<uuid>-<8hex>` 精確 join（未 join／重複即拒絕）。
Cohort＝origin snapshot 中所有 live marks（原始 cost、prompt、max、admitted、first）。

每 mark 特徵（全部 ≤t0 可得）：cost、prompt_k、max/100、started、age、
native_unknown、output progress、remaining cap、decode batch D、
prefill backlog k-tokens（native output=0 ＋ Gateway 已收但 native 未見）、
waiting、cohort cost R、**計畫中**的 cap（frozen `cap_plan` 時間平均，
非 realized）、trailing 2s realized release rate（只用先前已收到的 snapshot pairs）。
有測試證明修改未來 observations 不改變 origin 特徵。

Exact transition 部分沿用 Gateway 守恆：每個 `mpc_ledger` frame 是單一事件，
delta<0 即一次 release（原始 cost、effective_at）。

## 3. Response：累計釋放原始 cost 的 ground truth（含不確定）

Target：origin cohort 在 `(sampled_at, t0+h]` 已釋放的原始 cost，h∈{1,3,5}s；
包含 observation lag 內已發生的 release。

1. Ledger 必須 sequence 連續、complete、同 run/clock；每個 snapshot 的 mark cost 和
   必須等於該 sequence 的 ledger reserved（否則拒絕）。
2. 每個 cohort mark 的消失區間＝最後出現與下一個 snapshot 的 sequence 區間。
3. 同區間同 cost 的 ledger release 事件為候選；若 `n_g` 事件、`m_g` cohort marks：
   cohort 已釋放數 ∈ `[max(0, r−(n_g−m_g)), min(r, m_g)]`（r＝≤τ 的事件數）。
   Cost 相同且有非 cohort release 時輸出**區間**而非猜測；`n_g<m_g` 拒絕。
4. 超過最後 snapshot 而仍未消失的 marks 是 censored 上界。

Per-mark label：唯一可識別時才給 0/1；否則 None，排除於 fit 並計數報告
（選擇偏差限制已承認）。

## 4. 比較的模型（全部只用 Train fit；無發明的 service 參數）

| 模型 | 形式 | 參數來源 |
|---|---|---|
| train_fraction | `R·p̄_h` | Train 精確 truth 的平均釋放比例 |
| fluid_history | `min(R, μ·h)`，μ＝trailing realized rate，缺少時用 Train 平均 cost/s | 歷史＋Train |
| batch_aware | `Σ cost_i·p_i(h)`，per-horizon L2 logistic，h 間 cummax 單調 | Train per-mark labels |

L2=1.0（標準化特徵）、α=0.1、history 2s 均**預先宣告、不調參**。
`fit` 拒絕任何非 Train row；seed block 只能屬於一個 partition；
final held-out **160021–160024 一律拒絕**（未使用）。

## 5. 評估：one／multi／OOD、block calibration

- 主要指標：`mean_h |pred(h)−actual(h)| / R_origin`，episode→block→平均；
  truth 為區間時報 lower/upper error；`R_origin=0` 另計不納入。
- One-step（1s）與 multi-step（3／5s）同一 origin 同時發布，不用 realized future gaps。
- OOD：Train 支援域（R、D、prefill_k、waiting、cap、planned cap、cohort size、
  `(prompt,max)` work shapes）外**整個 origin abstain**，所有模型配對相同樣本；
  abstention 原因逐項計數。
- Calibration：只用 Calibration blocks 的 split residual quantiles 形成 band，
  Development 報 per-block 覆蓋（lower＝所有可行 truth 皆覆蓋、upper＝某個可行 truth 覆蓋）。
  Blocks 間 exchangeability 未證，**不是 coverage 保證**。

## 6. Strong One-move vs MPC、因果支援與安全部署（本模組之外的條件）

- 本模型輸出 `P(release | H_t0, planned cap)`；cap 依賴性只有在 randomized
  cap-sequence episodes（Gate B LL/LH/HL/HH）支援下才可解讀為 action response；
  觀察資料上的 cap 係數不是因果斜率。
- Strong One-move 與 MPC 必須使用同一模型、同一 abstention 與同一 continuation
  （由 Development 在 hold／fixed／reactive 中選定）；只有 multi-step forecast
  在 Development 優於 train_fraction／fluid_history 時，multi-move 才有資訊價值。
- 部署：任何 OOD abstain 或 truth/ledger 驗證失敗 → 回到 development-chosen
  best-supported-fixed；cap 16/32 是 cost cap 而非 concurrency；無 KV hard-safety 宣稱。

## 7. 否證條件（預先宣告）

1. batch_aware 在 Development blocks 上未低於兩個 baseline 的 upper error →
   batch 特徵沒有超過 fluid 的預測價值，不得用於 MPC。
2. 3／5s 誤差相對 1s 未改善 baseline 差距 → 不支持 multi-step 規劃。
3. Development 覆蓋顯著低於 1−α 或 block 間差異大 → band 不可作 risk 約束。
4. 需要 abstain 的 origin 比例高 → 支援域不足，需要更多 randomized Train。
5. tail_accounted 對任何 natural-EOS request 為 False → release 延遲解釋失敗。

## 8. Receipt

- 檔案：`native_release_model.py`
  sha256 `86f45ab851a446b4a903c8e5f0991acb198ecc4fc5d9d0d9bd0d05e38e77411b`；
  `test_native_release_model.py`
  sha256 `1f38d3cb88d9c89d9acf2296b94278f02ed4f73a7e3e98caf5f7f045f902bed3`。
- 測試：`cd experiments/mpc-research/native-v3 && python3 test_native_release_model.py`
  → `9 passed`（Python 3.14.4，stdlib only；pytest 亦可收集 `test_*`）。
  Sandbox 阻擋 pip，故未安裝 numpy／pytest。
- 沒有 SSH／GPU／API、push、merge、`gt done`；沒有讀 peer NV3 提案；
  沒有 native 數據、fixture 常數或統計保證被宣稱為結果。
- 資料 adapter：raw NV3 capture → episode schema（見模組 docstring）待 Gate A／B
  原始資料存在後依實際欄位實作；目前不猜測 capture 欄位。

## Round 2：交叉審查（peer 原始碼，非僅 test pass）

所有反例皆在 `test_native_release_model.py` 中，以 sha256 鎖定 Mayor 凍結的 R1 bytes 後 importlib 載入（`NV3_PEER_ROOT` 可覆寫；檔案不在則 SKIP，不偽造）。重現：`cd experiments/mpc-research/native-v3 && python3 test_native_release_model.py`。

### Gemini（`native_campaign_protocol.py`）— 不可採用為 campaign 協定
| # | 發現 | 反例 test |
|---|---|---|
| G1 | ≥10h 由「計畫 90s offer + 30s max-drain」×320 得出；違反「planned/max-drain 不計入 actual」 | `..._counts_planned_drain_...` |
| G2 | `compute_work_accounting`：end=4100 時 tail=0（27 個缺失位置被 `max(0,·)` 隱藏）；end=4200 時 tail=73 仍寫死「placeholder 1」原因；physical=end+1=4129 與 useful=4128 的單位不同 | `..._hides_missing_and_invents_tail_cause` |
| G3 | concurrency>1 即宣告 serial 被證偽：屬斷言而非資料 | （code review） |
| G4 | 偽重複保護只檢查標籤：同一 block 換 id/seed 複製 6 次 → `CONFIRMED_SUPERIOR` | `..._one_block_relabelled_six_times` |
| G6 | NAE 對空 origin 與缺 horizon 回傳 0 誤差（白送完美分數） | `..._score_as_zero_error` |
| G8 | StrongOneMove 不讀 continuation：c 與 48−c 決策完全相同；「MPC」為寫死閾值啟發式 → 弱基準 | `..._one_move_ignores_its_continuation` |
| G9 | `unseen_ood_mix` 有 10 個 Train blocks（非 OOD）；`mixed_short_long` 僅單一 prompt 2048，與宣稱 80/20 不符；到達率與「120% capacity」為虛構 | 同 G1 test |

### Sol（`native_experiment_audit.py`）— 整體嚴謹，tail 規則較我嚴格，已採納
- 採納：tail 步驟要求輸出 commit 不早於 finish（Sol：`begin < eos <= commit`）。我的 R1 只檢查 `start < finished`。**修正**：`forward_work_accounting` 新增 `tail_commit_before_finish` 證偽；falsifier test 已補。
- 反例 S1：censored 列在 `observed_until − sent_at = 30s` 無 first content，TTFT≤0.5s 已不可能，但 `good_upper` 仍為 1。這是保守的上界，不會產生錯誤宣稱，但會放寬界限而減損辨識力（`test_peer_sol_censored_upper_bound_...`）。
- 次要：`scheduled == origin+offset_s` 用精確浮點相等；`pair_order` 宣告未用；exact sign-flip 上限 16 blocks。皆不影響正確性。

### Astra（`native_response_planner.py`）— 介面嚴謹，無模型
- R1 懷疑：fresh `sum(costs)+c<=cap` 與 gateway 遞增 float 累計不一致。以 gateway CostSpec 形式、cap 16/32、20000 條隨機 admit/release 軌跡檢查，**未重現分歧**；撤回此疑慮，不宣稱缺陷。
- `stage="unknown"` 一律 fallback：過往 joined 樣本約 18%（1865/10367）屬 gateway 已 admit、native 未見，致多數決策為 `shadow_cap=None`。誤差容許度 error_below/above 為呼叫端純量，未經校準。one/two-move 計畫族不巢套。
- **自身修正（受此審查啟發）**：R1 以 `history_rate=-1.0` 哨兵值編碼「無歷史」，會被 logistic 當作真實速率外插。改為 `history_rate=0` + 顯式 `history_missing` 指示特徵。

### 未解決分歧
1. 未知 native 工作：Astra 棄權；我把它當特徵（`native_unknown`）。需資料決定（見實驗 E1）。
2. Tail 嚴格度：Sol 要求 `delivered_output_from_step=False` 的明確證據；我要求 commit≥finish 加 forward 匹配，未要求該欄位。若 native capture 有該欄位，應以 Sol 版本為準。
3. Gemini 的計畫時數與啟發式控制器：我認為不可作為 ≥10h 或 MPC 優越性的依據。
4. 16-arm 資格（40 HTTP、natural EOS 40、16 個 v3 audit valid、8 個 v2 FALSE 保留、20 個明確 tail token）只驗證 capture/HTTP/drain，**不**驗證預測、MPC 或 overhead；本報告無任何 native 預測結果。

### 鑑別性 native 實驗（Development blocks，不動 160021–160024）
- E1：在同一批 Train/Dev 原點上比較 `native_unknown` 特徵與 Astra 式棄權。量測棄權率與 1/3/5s release NAE 及覆蓋率。
- E2：實際 ledger 的 tied-cost 模糊率（區間寬度/上界）。若超過在看資料前預先登錄的門檻，則 per-mark 標籤選擇偏差不可忽略，需改為區間似然。
- E3：tail 發生率對輸出長度與 batch mix 的分佈（以 20 個 tail token 為種子 → 擴展 arms），並以 Sol 與本版 tail 規則交叉判定，任何不一致即為反例。
- E4：LL/LH/HL/HH 隨機化 cap 序列，檢驗 planned-cap 係數是否具因果意義（非僅相關）。
- E5：fluid vs batch_aware 在 Dev 的 block 校準與 OOD 棄權後誤差。batch_aware 未勝出即採 fluid。

### Round 2 receipt
- `native_release_model.py` sha256 `6e277d09c2ccfded2bb11e31164f97515c4bbdcc838f3df3f5a917864b297270`
- `test_native_release_model.py` sha256 `fd120e927353d4eec18c88b48711d68168a9bf3aa034138206b2b789b4ca1379`
- `python3 test_native_release_model.py` → `15 passed, 0 skipped`（Python 3.14.4，stdlib only）
- 本地 commit，bead 保持 in_progress；未執行 gt done／push。

## Round 3：逐一回應 peer 反例、修復、train-only 實際資料診斷

範圍：只改本人三個檔案。R3 只讀取 Train blocks 181001..181016，Calibration/Validation/Final 一律不讀、不 fit、不調參；舊 Final 160021–160024 仍保留不用。本節**沒有** forecast、causal 或 MPC 結果，也沒有 statistical guarantee。

### 逐一回應（針對我 R1/R2 的具體反例）

| 反例（提出者） | 判定 | R3 修復 | 回歸測試 |
|---|---|---|---|
| O1 native run/clock/observer 未檢查（Astra） | 接受 | `_native` 要求 `run_id==native_run_id`、clock_domain、observer_sha256，以及 sampled≤frontend≤received、frontend 寬度 ≤0.05s、age ≤0.5s、running==len(requests)、kv∈[0,1]、`chatcmpl-<32hex>-<8hex>` fullmatch、prompt/maximum_output 與 Gateway mark 一致。這些 predicate 鏡像 `state_sample.join_observations`。不合格的 frame 不算觀測，會計數為 `rejected_native_frames`，不致命 | `test_r3_o1_*` |
| O2 retroactive/負向 ledger release 被當成精確真值（Astra eff .2 vs snapshot .25；Sol eff −100） | 接受 | 新增 `ledger_chronology`（effective_at 不遞減）與 `ledger_snapshot_chronology`（eff[s]≤sampled≤eff[s+1]） | `test_r3_o2_*` |
| O3 `_planned_budget` 平均造成順序 alias（Astra [16,16,32,16]/[16,32,16,16]；Sol 0.5s 切換） | 接受 | 改用無損 slot 編碼：(到下一 slot 邊界時間、t0 預算、ceil(h) 個邊界後的預算)。Astra 的兩個計畫特徵不同。Sol 的 0.5s 計畫不在宣告的 SLOT_S=1s 網格上，直接 raise `cap_plan_off_slot_grid`（宣告範圍，不假裝能編碼） | `test_r3_o3_*` |
| O4 calibrate 合併各原點（Astra [0]*100+[1] 使上帶 1→0；Sol 下帶 −.5→+.5） | 接受 | (a) 原點改在固定決策網格上，取 t0 前最新的 joined 觀測，所以重複觀測或 cadence 改變不會改變權重。(b) `_unique` 依 (block, episode, t0) 去重。(c) 每個 block 各自取 α/2、1−α/2 殘差分位數（用區間真值上下界），帶寬取跨 block 包絡 | `test_r3_o4_*`（兩個） |
| O5 OOD 只看邊際盒、漏掉 age/history、混合 short+long 可通過 | 接受 | 所有使用的特徵都有 range（含 age_s、history_rate、plan 編碼），另加 joint gate：`joint_work_mix`（Train 中出現過的 shape 組合）、`joint_plan_sequence`、leave-one-episode-out NN 半徑（`joint_nn_distance`；少於 2 個 episode 時為 `joint_nn_unavailable`） | `test_r3_o5_*` |
| O6 `tail_accounted` 沒有 placeholder/CUDA/commit 證據；重複 worker key 被合併 | 部分接受 | 新增 `duplicate_worker_step` 問題。`tail_mechanism_evidenced` 需要 `tail_evidence`：placeholder_tokens==1、cuda_completed、delivered_output_from_step False、output_commit_at≥finished。`native_qualification_authority` 恆為 False。保留結構性 `tail_accounted`，但它只代表結構一致 | `test_r3_o6_*` |
| O7 依 horizon 只選精確標籤，使 train_fraction 非單調（{1:4.5,3:0,5:0}） | 接受 | 不再丟棄任何原點或標籤。baseline 用真值上下界平均（另報 `fraction_bounds`、`fluid_rate_bounds`）。logistic 對區間截尾標籤用 0.5 中點（慣例，**非 MLE**），`sensitivity=True` 另以 0/1 補值 fit 出界 | `test_r3_o7_*` |
| logistic 無收斂證明（Astra/Gemini） | 接受 | `fit_logistic` 回報 converged/iterations/last_step/gradient_inf_per_weight/max_abs_beta，未收斂時 `predict` 以 `fit_not_converged` 棄權。單一類別的 horizon 以 `degenerate=True` 常數表示，不偽稱為 fitted model | `test_r3_unconverged_*` |
| 區間標籤選擇偏差（Gemini §10.1） | 接受（部分） | 同 O7。中點仍是慣例；在實際 Train 上報告 0/1 補值敏感度（見下） | 同上 |

### Ledger 不存在時的真值：snapshot brackets
實際 replica **沒有** `mpc_ledger`。snapshot sequence 有間隙，也有 3 個重複，所以真值不能假裝為 ledger 精確值。改用 `snapshot_brackets`：每個 mark 取（最後 live、首次 absent）。h 的下界是「absent≤T」的 cost，上界是「last_live<T」的 cost。mark 消失後若重新出現，raise `mark_reappeared`。測試：`test_r3_snapshot_bracket_truth_without_ledger`。

### Portable 實際 native-frame adapter（只讀）
`load_replica(dir)` 先驗證 `verified-artifact-sha256.jsonl` 中每個 artifact 的 sha256，只載入 split=train 且 seed_block∈181001..181016 的 episode；160021–24 或非 Train 一律 raise。`episode_from_replica` 的 Gateway identity/clock 取自 index；native run/observer 由 frames 取得並要求一致，這只是內部一致性，**不是**獨立 receipt。Join 鏡像 reference 規則，ID 用 exact fullmatch，不用子字串。回歸測試 `test_r3_actual_replica_adapter_reproduces_reference_join_counts` 先比對 artifact hash，再重現 Mayor 的事實：p128-m128-arm0 有 765 個 joined frame，13280 個 mark 中 3034 個 accepted-not-native-visible，0 個 rejected。我也另外用 reference `state_sample.join_observations` 對 181001 其他 episode 交叉核對，計數相同。

### 實際 replica Train-only 診斷（**不是** forecast/causal/MPC 結果）
指令：`python3 native_release_model.py --replica-train-diagnostics <replica>`，約 14 秒。replica 仍在寫入，這是當下快照：22 個 verified artifact，載入 11 個 Train episode。
- clock_domain：`linux-monotonic:64589d75-…:time:[4026534406]`
- collector：6c11fe7e683439f379f0dfdbd21b05f5873b2c90
- native source：2587d2b822dcd3812353ce2ac3369b7192fa7ba7
- native run：58777b3950ff44d88c077e1101096cc8（單一）
- Gateway run_id 每格兩個 episode 共用一個（9950f2…、5101fc…、d06dbf…、e87fd1…、27a40b…、5fcca6…）。這與「每 2 episode rollover、ClockDomain 不變」一致。

| episode | artifact sha256 前 16 | grid 點 | stale | joined frames | rejected |
|---|---|---|---|---|---|
| 181001-mixed-arm0 | c3b5edcc63bb8feb | 120 | 0 | 912 | 0 |
| 181001-mixed-arm1 | fd483ce77832dd52 | 120 | 0 | 903 | 0 |
| 181001-p128-m128-arm0 | d633b4e402e45323 | 121 | 0 | 765 | 0 |
| 181001-p128-m128-arm1 | 467887df4445c5f2 | 121 | 1 | 761 | 0 |
| 181001-p128-m256-arm0 | f99c6470c478a36e | 122 | 0 | 935 | 0 |
| 181001-p128-m256-arm1 | 7ad41e1f0faf34ef | 121 | 0 | 933 | 0 |
| 181001-p4096-m128-arm0 | 74da77e6bc936d88 | 121 | 0 | 878 | 0 |
| 181001-p4096-m128-arm1 | fd61c5abf017d575 | 122 | 0 | 898 | 0 |
| 181001-p4096-m256-arm0 | f7722058627612b4 | 121 | 0 | 945 | 0 |
| 181001-p4096-m256-arm1 | a62d86171cf18028 | 122 | 0 | 961 | 0 |
| 181002-p128-m128-arm1 | 8beef76b13d94f71 | 121 | 0 | 765 | 1 (`native_unjoined_or_ambiguous`) |

- 1331 個原點、12095 個 origin-mark，其中 2087 個 not-native-visible。這是 Train 中真實存在的「未知 native 工作」比例，不能宣稱為全部可見。
- 真值寬度：h=1 有 971 個精確、330 個區間原點，平均寬度占 R 的 0.052，507 個截尾 mark 標籤；h=3 為 1286/15/0.0028/20；h=5 為 1292/9/0.0018/13。結論：~150ms snapshot cadence 對 h=1 不可忽略，對 3/5s 很小。
- Logistic（in-sample，只看收斂與敏感度，**不報任何誤差**）：
  - h=1：10047 released / 1541 unreleased，三種補值皆收斂（8–9 次 Newton），平均標籤敏感度 0.042，最大 0.40。
  - h=3：12065 / 10，皆收斂，但 |β|max 達 16.6（ambiguous_as_1），實質接近分離，資訊量極少。
  - h=5：0 個 unreleased。中點與 as_1 都是 degenerate 常數，只有 as_0 有 fit。**5s 在目前 Train 上不可識別。** 這是誠實結果，不是模型能力。
- 以 R3 之前的程式碼跑會直接 raise `degenerate_train_labels`。R3 改為每個 horizon 各自標記 degenerate；只有三個 horizon 全部 degenerate 才 raise。

### 對 Mayor 實際事實的立場
- 16-arm qualifier 中，只有 20 個 LIGHT request 有 physical GPU work 標籤，而且 20 個都有 1 個 overhang。20 個 OFF request **沒有** tail 測量。所以 20/40 **不是** 0.5 的 tail 機率，也不是 0/1 隨機變異的證據。本模組的 tail 欄位不是 native authority。
- GPU elapsed 不是絕對時鐘，也不是 exclusive service 時間。
- Long 6c driver 規劃 400×120s=48000s，**尚未** 10 小時。planned、drain、setup、idle 都不算實際實驗時數。
- Gateway operation cache 在記憶體中、每 2 episode rollover；1024 上限未放寬。本模組不依賴它。

### RETAINED DISAGREEMENTS（不是投票、不是共識）
1. **未知 native 工作**：Astra 選擇棄權，我把它當特徵（`native_unknown`）。實際 Train 中有 17% origin-mark 不可見，全部棄權會丟掉大量狀態。這要由 Development 上的 E1 決定，目前沒有證據支持任一方。
2. **Marginal ≠ joint**：本模組是單一 marginal 累計 release 預測（`joint_response_kernel=False`），**不可**被當作 Astra 的 good/unreleased/tail 聯合 kernel。我不同意把它拿去餵 joint-feasibility 判定。
3. **中點標籤**是慣例，不是區間似然 MLE。我保留它，並報告 0/1 補值敏感度（h=1 最大 0.40）；若 E2 顯示偏差超過預先登錄的門檻，應改為區間似然。
4. **NN 半徑支援門**是資料定義的棄權包絡，不是 exchangeability 或 coverage 證明。它是 O(n²) stdlib 實作，無法直接擴展到整個 10h campaign，需要分塊或子抽樣（屆時另行宣告）。
5. **Tail 嚴格度**：我保留結構性 `tail_accounted`，Sol/Astra 只承認 mechanism evidence。兩者都不給 qualification authority；在 capture 提供 `tail_evidence` 欄位前，`tail_mechanism_evidenced` 在實際資料上恆為 False。
6. **Sol 的 0.5s 計畫**：我選擇 raise，而不是推廣編碼，因為實際 protocol 的 `schedule.at_s` 是整數秒。若未來 protocol 改變，SLOT_S 需重新宣告，不能沿用。
7. **Calibration**：跨 block 包絡偏保守，而且沒有 coverage 保證。Astra 要求的 conformal 保證在 block 數不足時無法成立，我不宣稱。
8. **MAE gate** 是研究 gate，不等於 MPC 價值；Gemini 的時數與控制器缺陷（R2 已記錄）維持不變。
9. **h=5 Train 不可識別**：我不會用 Calibration/Validation 補救。這需要更高負載或更長 release 的 Train cell（E6）。

### 鑑別性 native 實驗（新增；E1–E5 見 Round 2）
- **E6**：在 Train 中加入讓 5s 內仍有未釋放 mark 的 cell（長輸出或高 cap），使 h=5 可識別；在看資料前預先登錄最少 unreleased 數。
- **E7**：snapshot cadence 減半與加倍的成對 episode。若 grid 原點與 bracket 真值設計正確，h=3/5 的訓練統計量應只隨真值寬度變化。
- **E8**：在 capture 中加入 `tail_evidence`（placeholder、CUDA 完成、commit 時間），對 OFF 與 LIGHT 都測量 tail。只有這樣才能估計 tail 發生率；目前不可估。

### Round 3 receipt
- `native_release_model.py` sha256 `62cc1fa0263885ee751e6c51c0c09b95d887930d120c0366b6db8cc9376a3b48`
- `test_native_release_model.py` sha256 `097fd4798cffae8303b5e1a9ac66446a36d6ffa45d4cde1fe99295167adcd832`
- `python3 test_native_release_model.py` → `26 passed, 0 skipped`（Python 3.14.4，stdlib only；replica 測試在 replica 不存在時 SKIP）
- 本地 commit，bead 保持 in_progress；未執行 gt done/push/network/DB。

## Round 3b：Mayor 補充 Train 證據後的因果 cut／provenance 修正（仍屬 R3，有界）

Mayor 補充的 181001 描述性資料（`first-train-block-descriptive-diagnostics.json`）：
- E2E P95：p128/m128 1.249s、p128/m256 1.563s、p4096/m128 2.829s、p4096/m256 3.241s、mixed 2.605s。
- TTFT P95：0.22–1.10s。
- KV 最高 0.372，不構成滿載或 preemption 資格。
- cap16 觀測中，prior cost >16 的比例：short 約 14%，prefill-heavy 約 40%。

這些是相關的序列描述，**不是** Fixed/MPC 結果或因果成對差異。offered rate 是預先指定的參考值，不是量測到的容量。我未修改執行中的 protocol，也未讀取或擬合任何 Calibration/Validation/Final 資料。

### 新發現：計畫 slot 時間 ≠ 實際 apply 時間
replica 的 `actions` 中有實際 CAS ACK。
- 1785 個計畫動作全部 applied，其中 12 個曾重試。
- `applied_at − 計畫 slot` 的 p50 為 0.037s，p95 為 0.157s，最大 **2.399s**（181001-p128-m128-arm1 at_s=43，前兩次 pending）。

R3 原本的 `cap_plan` 特徵假設「計畫時間即生效」。在實際資料上，這對尾端延遲不成立。

### 修正（只動本人檔案）
1. **快照預算 provenance**：每個 joined snapshot 的 (budget, budget_version) 必須等於它 sampled_at 當下已生效的 ACK（pre-assignment 加上各次動作），否則拒收並計為 `gateway_budget_provenance`。在實際 Train 上，15 個 episode 都是 **0 拒收**：這是實際驗證，不是假設。
2. **Cut 必須在下一個動作的 ACK 之前**：origin 使用的所有 receipt（Gateway 與 native）必須早於任何計畫在 t0 或之後的動作的 `applied_at`，否則 raise `cut_after_action_ack`。實際 Train 上沒有觸發。因此 batch 狀態輸入都是 pre-treatment，不會把動作後的狀態當成同一 pre-treatment 狀態。
3. **未確認動作的 abstention**：若某指令計畫在 t0 前、但 t0 前尚未收到 applied ACK，origin 會以 `outstanding_action_at_cut` 棄權。這在線上可知（指令已送出、ACK 未回），不用 retrospective oracle。實際 Train 有 3 個這樣的 grid 點。
4. **保留的資訊**：actual CAS delay 只出現在診斷 `cas_apply_delay_s`，標明為 cut 之後的結果，**永遠不是輸入**。計畫特徵仍是完整的指派序列（無損 slot 編碼，不會 average-alias），條件於 pre-assignment 歷史。觀測到的實際生效預算是另一個特徵（`budget`）。模型不假設 reserved ≤ budget；cap16 下 prior cost >16 的實際觀測在 support range 內被當作真實狀態。
5. **線上可得性**：輸入只有 Gateway accepted marks（scheduled_at=None）與 native frame，**不使用** client 的 offered/rejected 歷史或 SLO 觀測。標籤來自其後的 snapshot brackets，與輸入分離。若要加入 arrival/SLO 特徵，需要另寫顯式的線上 adapter（本模組未提供）。

### Horizon／控制時間尺度：由實際 1–3s response 判定，不自動加長
15 個 Train episode（181001 完整 10 個加 181002 的 5 個；replica 仍在寫入，30 個 verified artifact）。另外 3 個 artifact 的 sha256 前 16 碼：181002-p128-m128-arm0 1c06c42fa5372c23、p128-m256-arm0 2ecd8a652e470eed、p128-m256-arm1 36f2ea533f261b41、p4096-m128-arm0 3d4f681e0ef0a2e6，其餘同上表。
- 1814 個 origin、17120 個 origin-mark，其中 2890 個 not-native-visible。
- h=1：14318 released / **2051 unreleased** / 751 截尾。
- h=3：17083 / **11** / 26。
- h=5：17102 / **0** / 18。h=5 的中點版與 as_1 版都是 degenerate 常數。

這與 E2E P95 ≤3.24s 一致：在目前的 protocol 下，live cohort 幾乎都在 3s 內釋放，所以 h=3/5 是近乎平凡的目標，資訊集中在 ≤1s（約等於 1s 控制 slot）。**我不在 R3 修改宣告的 HORIZONS**，因為依 Train 結果改 horizon 屬於事後調整。我提出一個可否證的預登錄修正，供 R4 決定：horizons {0.5, 1, 2}s，控制 slot 維持 1s。
- 否證條件：若在預先宣告的 Train 新 block 上 h=2 的 unreleased 比例 <1%，則 2s 也是平凡目標，應改以 sub-second 釋放動態作為 MPC 的主要 response。
- 若 ≥10% 的 grid 點出現 outstanding 動作，則 1s slot 對 CAS 延遲而言太短。

### 新增 RETAINED DISAGREEMENTS／限制
10. outstanding 動作的 origin 我選擇棄權，而不是把 CAS 延遲建模為 response 的一部分。其他 peer 若把延遲當作隨機 response 的一部分，需要明確說明條件於哪些 receipt。
11. 181002 目前只有部分 episode。混入部分 block 只適用於 Train 描述，不得作為 block-level 評估。

### Round 3b receipt
- `native_release_model.py` sha256 `98edb2df3b0bc9f5f4c8e9bedc0df5c4e08070f65408d32f63666004dc55ade3`
- `test_native_release_model.py` sha256 `ffd2b8f6ad3f713ef98538f12caed4a3e99a23a69e90208f1540593c96789a72`
- `python3 test_native_release_model.py` → `28 passed, 0 skipped`（新增 `test_r3b_*` 2 個）
- `--replica-train-diagnostics` 約 21s；本地 commit，bead 保持 in_progress；未執行 gt done/push/network/DB。

---

## Round 4 — short-step joint serving transition candidate (`nv3-opus-joint-transition-v1`)

Scope: one bounded candidate, no weight search, Train only. The R3/R3b marginal
original-ID release model is unchanged and remains a **diagnostic**; it is *not*
renamed or advertised as a joint kernel (`marginal_release_model_is_joint=False`).
The live 400-episode/source-6c protocol was not touched; no GPU process was run.

### R4.1 State, stock-flow equations, observability

Step Δ=0.5 s on a fixed cut grid t_k = start + kΔ (receipt-stamped cuts reused from
R3 `build_origins`, so all R3 clock/source/epoch/provenance/outstanding-action
fences apply unchanged).

Observable at cut t_k (receipts ≤ t_k only):
- Gateway stock: reserved original cost R_k, live count n_k, budget b_k (ACK in
  force, provenance-checked), headroom b_k−R_k, unstarted share, live prompt/max mix.
- Assigned plan b_{k..k+10} (pre-assignment; the actual CAS delay stays a label/fence,
  never a feature).
- Native frame joined by exact canonical UUID (running, waiting, KV, decode batch,
  prefill tokens, unknown-native fraction). Native partial visibility is kept as a
  feature; no stage/EOS clock is manufactured.
- Client all-offered receipt history over the last 4 steps (2 s): offers, rejected,
  good, TTFT misses, released and born cost. This is an explicit **observer input**.
  Gateway marks alone only see accepted traffic, so an online deployment needs this
  client receipt adapter. Future arrivals are never read from the tape.

Flows over (t_k, t_k+Δ] are **labels**, not features:
- D_k / N^D_k: original cost/count released (in snapshot k, absent in k+1).
- B_k / N^B_k: cost/count born.
- O_k = A_k + J_k: offers by send receipt, split into admitted and rejected (the
  503 receipt).
- G_k: natural-EOS good terminals, with TTFT = first − scheduled ≤ 0.5 and
  TPOT = (terminal−first)/(n−1) ≤ 0.05. This reproduces `summary.natural_cohort_good`
  exactly.
- M^TTFT_k: counted at the deadline scheduled+0.5 when first is absent or late, so it
  is knowable at that time.
- M^TPOT_k: counted at the natural terminal.

Stock update: R_{k+1} = R_k − D_k + B_k and n_{k+1} = n_k − N^D_k + N^B_k. The
identity is exact on the snapshot ID sets. It is not itself falsifying; the
falsifiable parts are these fences:
- `client_row_identity_or_clock`: the clock must match, the ID must be 32hex, and
  sent ≥ scheduled.
- `client_rows_incomplete`: rows must equal expected_ids.
- `snapshot_client_inconsistent`: each mark needs a non-rejected row with sent ≤ the
  snapshot sample.
- `mark_reappeared`.

Latent: native scheduler internals, the remaining tokens of unknown-native work, and
the future exogenous arrival process.

### R4.2 Model, support, scenarios

- **Per-target ridge** (closed form, standardized, λ=1e-3 declared, not searched).
  - `gateway_ridge`: Gateway and history features.
  - `batch_ridge`: adds the native batch features.
  - Outputs are clipped physically: ≥ 0, D ≤ R, N^D ≤ n.
- **Support/OOD** is bounded at O(n) per fit, replacing the O(n²) nearest-neighbour
  gate for this candidate. It combines:
  - per-feature Train ranges;
  - a coarse joint bin (cell, budget, headroom//4, live//8, offers//10) that needs
    ≥ 3 Train occurrences;
  - abstention on an outstanding action at the cut.

  Abstentions are counted, not dropped silently.
- **Free-running rollout** (10 steps = 5 s; reported at 1/3/5 s) uses the gateway
  model only, because the native state is latent after the cut and is not forecast.
  - Stocks follow the equation above, the budget follows the assigned plan, and the
    history window rolls over predicted flows.
  - 20 scenarios each add one contiguous Train residual run, which keeps serial and
    cross-target batch correlation.
  - Status: **unqualified**. The bootstrap is not state-conditional, and there is no
    coverage or MPC-risk claim.
- **Cross-fit**: leave-one-seed-block-out on Train only. Non-train partitions raise
  `joint_requires_train_only`; fewer than 2 blocks raise `crossfit_needs_two_blocks`.
- **Baselines**:
  - `train_mean`;
  - `persistence` (previous step's flows);
  - `history_mean` (mean of the last 4 steps) — the strong exogenous baseline;
  - for reserved, `hold` (R_k held constant), plus the above.

### R4.3 Actual Train result

Data: the read-only replica at 40 verified artifacts, which is 20 episodes from Train
blocks 181001 and 181002 (5 cells × 2 arms). No Calibration, Validation, Final or
160021–24 data was read. These are two folds, not an uncertainty estimate; paired arms
within a block are correlated.

Each fold held out one block:

| Held-out block | Train steps | Residual runs | One-step scored | Abstained (joint_bin / outstanding) | Rollout origins |
|---|---|---|---|---|---|
| 181001 | 2389 | 15 | 2196 | 194 (184 / 11) | 538 |
| 181002 | 2385 | 16 | 2175 | 220 (203 / 10) | 528 |

**Cohort-vs-future decomposition of good terminals in (t, t+h]**, over all steps:

| Horizon | From cut cohort | From later births | Later share |
|---|---|---|---|
| 1 s | 6521 | 1572 | 19% |
| 3 s | 7508 | 16172 | 68% |
| 5 s | 7388 | 31404 | 81% |

Original-cohort release therefore cannot be the Goodput kernel beyond about 1 s.
5 s release degeneracy does not make 5 s state/Goodput forecasting moot: births
dominate it.

**One-step MAE per 0.5 s**, held-out block 181001 (block 181002 within ±0.2):

| Target | batch_ridge | gateway_ridge | history_mean | persistence | train_mean |
|---|---|---|---|---|---|
| released_cost | 2.72 | 2.86 | 4.32 | 5.05 | 4.51 |
| born_cost | 2.92 | 2.95 | 3.89 | 4.81 | 4.14 |
| good | 1.12 | 1.17 | 1.72 | 2.19 | 3.39 |
| rejected | 1.66 | 1.67 | 1.89 | 2.07 | 2.34 |
| offers | 1.89 | 1.88 | 1.92 | 2.43 | 4.54 |
| ttft_miss | 0.40 | 0.49 | 0.58 | 0.56 | 0.59 |
| tpot_miss | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |

TPOT misses are essentially absent in this Train data, so TPOT risk is
**unidentified**, not shown to be safe. Native batch features help modestly, and only
on released_cost and ttft_miss.

**Free-running MAE**, joint median vs the strongest baseline. Each cell gives
fold 181001 / fold 181002.

| Target | 1 s | 3 s | 5 s |
|---|---|---|---|
| good (vs history_mean) | 1.80 vs 2.72 / 1.65 vs 2.62 | 5.29 vs 5.59 / 5.55 vs 5.70 | **9.84 vs 8.47 / 10.37 vs 8.67 (loses)** |
| offers (vs history_mean) | 3.06 vs 2.78 / 3.26 vs 3.10 (loses) | 7.58 vs 6.14 / 8.30 vs 7.19 (loses) | 13.11 vs 9.80 / 14.47 vs 10.88 (loses) |
| rejected (vs history_mean) | 3.08 vs 3.39 / 3.28 vs 3.61 | 7.42 vs 6.91 / 7.20 vs 6.91 (loses) | 11.82 vs 10.83 / 12.00 vs 10.58 (loses) |
| ttft_miss (vs best of history_mean/train_mean) | 0.91 vs 1.08 / 0.91 vs 0.99 | 2.07 vs 2.41 / 2.33 vs 2.36 | 3.13 vs 3.63 / 3.54 vs 3.66 |
| reserved (vs hold) | 5.52 vs 8.00 / 5.11 vs 7.16 | 5.36 vs 7.65 / 5.62 vs 8.09 | 5.51 vs 7.97 / 5.60 vs 7.96 |

For reserved, train_mean is about equal to hold.

**Scenario 10–90% band inclusion** falls with horizon: 0.65–0.84 at 1 s and
0.42–0.75 at 5 s (5 s TTFT: 0.42 and 0.51). The bands are under-dispersed, which is
consistent with the unqualified status.

### R4.4 Honest conclusion

- **Where the candidate is useful.** It is a usable *short-step state* model.
  - It beats every baseline one step ahead on all non-degenerate targets.
  - Free-running, it beats hold/train_mean on reserved stock at 1–5 s.
  - It modestly beats the baselines on TTFT-miss counts at 1–5 s.
- **Where it fails.** Free-running, it **loses to history_mean on the exogenous
  flows**: offers at all horizons, rejected at 3–5 s, and good at 5 s. Compounding
  rollout error on the arrival process is the failure. Offers are a pre-assigned
  protocol rate, so predicting them identifies the cell, not capacity.
- **Falsifiable next step** (not done here): a hybrid that feeds the observed
  history_mean of offers as an exogenous input into the stock dynamics, instead of
  rolling its own arrival prediction. That is the only stated change, with no
  search, and it must be tested on a fresh Train block before any Calibration use.
- **Not claimed:** no MPC result, calibration, coverage, statistical guarantee,
  capacity or absolute GPU-time claim. TPOT risk is unidentified on this data.
- **Data sufficiency.** The data is sufficient for one-step and 1 s joint state. It
  is insufficient to qualify 5 s exogenous-flow scenarios.

### R4.5 Retained disagreements and limits

12. **Scenario conditioning.** The residual-bootstrap scenarios are batch-correlated
    but not state-conditional. Astra-style joint response kernels need a
    state-conditional generator; this candidate stays unqualified.
13. **Support gate.** The bounded joint-bin support replaces the R3 O(n²)
    nearest-neighbour gate only for this candidate; R3 keeps its gate. Bin edges are
    declared, not tuned, but are still a modelling choice.
14. **Observer adapter.** The client all-offered history adapter is required. A
    Gateway-only deployment cannot compute the offers, rejected or TTFT-deadline
    history features.
15. **Fold structure.** Two folds over paired arms is not uncertainty
    quantification. Uncertainty should be judged with ≥ 4 Train blocks later.

### R4.6 Receipt

- Run: `python3 native_release_model.py --replica-joint-crossfit <replica>` takes
  about 6 s.
- Tests: `python3 test_native_release_model.py` gives 34 passed, 0 skipped, including
  6 new R4 tests:
  - Stock identity and receipt labels.
  - A marginal≠kernel counterexample: identical R3 `mark_features`, but different
    offered/rejected history and future births give different future good.
  - Client fencing and snapshot consistency.
  - No future leakage into features or rollout.
  - Train-only, block-grouped, unqualified cross-fit.
  - An actual-replica stock-identity check for 181001 p128-m128 arm0
    (2540 good = summary).
- Source sha256 values are recorded in the commit message.
