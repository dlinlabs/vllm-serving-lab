"""Bounded exact-source caller probe; all arm observations are CPU stubs."""
import ast
import asyncio
import __future__
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "pr33-native-v3-round17-gemini-paired-frozen/native_campaign_protocol.py"
EXPECTED_SHA = "44179f8d50e0f5aaead1d9cd77436cb6f90f10686a1992ccbfd3c2d28bd89142"


async def main():
    raw = SOURCE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED_SHA
    historical = BASE / "pr33-native-v3-round17-sol-paired-frozen/test_native_experiment_audit.py"
    spec = importlib.util.spec_from_file_location("historical_sol_probe", historical)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    factory = module.R17PairedCallerTests()
    node = next(n for n in ast.parse(raw).body
                if isinstance(n, ast.AsyncFunctionDef)
                and n.name == "run_live_native_cohort_pipeline")
    results = []
    for case in ("reference", "missing_burst_fate", "missing_anchor_inventory",
                 "lost_assigned_fates", "excess_censor", "overlap"):
        a = factory.arm(20., (20., 21.))
        b = factory.arm(10., (10., 11.))
        for arm in (a, b):
            arm.anchor_count = 5
            arm.actuator_submission = {"status": "applied"}
            arm.survivor_mean_discarded = False
            arm.burst_cost_per_request = .25
        if case == "missing_burst_fate":
            b.burst_fates.pop()
        elif case == "missing_anchor_inventory":
            b.preassigned_engine_ids = b.preassigned_engine_ids[:-1]
        elif case == "lost_assigned_fates":
            b.all_assigned_fates_retained = False
        elif case == "excess_censor":
            b.censored_count = 1
            b.anchor_fates["cpu-anchor-0"]["censored"] = True
            b.survivor_mean_discarded = True
            b.anchor_mean_progress = None
        elif case == "overlap":
            a.itt_mean_lower, a.itt_mean_upper = 10., 30.
            b.itt_mean_lower, b.itt_mean_upper = 0., 25.

        async def run_arm(name, budget, **kwargs):
            return a if name == "arm_a" else b

        namespace = {
            "LiveNativeCohortRunner": lambda **kwargs: SimpleNamespace(run_arm=run_arm),
            "LiveNativeCohortPairedReceipt": lambda **kwargs: SimpleNamespace(**kwargs),
        }
        exec(compile(ast.Module(body=[node], type_ignores=[]), "sealed:7936836:paired",
                     "exec", flags=__future__.annotations.compiler_flag), namespace)
        protocol = SimpleNamespace(
            initial_budget=32., post_gate_assigned_budget_arm_a=16.,
            post_gate_assigned_budget_arm_b=32., burst_request_count=4,
            hypothesis="CPU stub only", geometry_name="five assigned anchors")
        result = await namespace["run_live_native_cohort_pipeline"](
            protocol=protocol, client=object(),
            permit_arm_a=SimpleNamespace(approved=True),
            permit_arm_b=SimpleNamespace(approved=True))
        assert result.fixed_mark_runner_invariance_falsified == (case != "overlap")
        results.append({
            "case": case, "interval": result.itt_delta_interval,
            "caller_falsified": result.fixed_mark_runner_invariance_falsified,
            "itt_preserved": result.itt_preserved,
            "all_assigned_retained": result.all_assigned_fates_retained,
            "strict_inventory_censor_reference": factory.guard(
                a, b, assignment_qualified=True)["conditional_margin_falsified"],
        })
    print(json.dumps({
        "source_sha256": EXPECTED_SHA, "cases": results,
        "scope": "exact paired function; stub arms only; no HTTP or native execution",
        "native_permit": False, "statistical_permit": False,
    }, sort_keys=True))


if __name__ == "__main__":
    asyncio.run(main())
