"""NV3 (Opus) history-conditioned cumulative original-cost release model.

Offline, stdlib-only research module. It grants no actuation authority, runs no
GPU/HTTP work and contains no service constants: every fitted quantity comes from
Train episodes that a caller assembles from actual Gateway marks and native frames.
Passing unit fixtures are not native results or statistical guarantees.

Episode schema (one actuated cap episode, all times in one monotonic clock domain):
  episode_id, seed_block, partition in {train, calibration, development},
  clock_domain, run_id (Gateway epoch), native_run_id, observer_sha256,
  identity (optional Gateway model identity; checked when present),
  observations: [{gateway: /admin/mpc/state document, received_at,
                  native: pr33-native-read-only-v1 frame or None, native_received_at}]
  ledger: contiguous mpc_ledger frames, or None -> snapshot-bracket truth
  cap_plan: optional [[assigned_from, budget], ...] frozen before the episode, on the
            SLOT_S grid; origin_grid_start / origin_grid_s: optional decision grid.
  actions: optional actual CAS receipts [{planned_at (None for pre-assignment), budget,
           budget_version, applied_at, ack_received_at}]. When present every joined
           snapshot's (budget, budget_version) must match the ACK in force at its
           sampled_at, origins must be cut before the next planned action's ACK, and an
           origin with a command sent but no ACK received by t0 abstains.
Origins are decision times on a fixed grid (not observation cadence). An origin uses
the latest joined observation received at or before the grid time. The forecast target
is the cost of that observation's live marks released in (gateway.sampled_at, t0+h].
This is a marginal cumulative-release forecast, not a joint good/unreleased/tail kernel.
"""
import bisect
from collections import Counter, defaultdict
import hashlib
import heapq
import json
import math
from pathlib import Path
import random
import re
import statistics
import sys

HORIZONS = (1.0, 3.0, 5.0)
PARTITIONS = ("train", "calibration", "development")
FINAL_HELDOUT = frozenset(range(160021, 160025))
NATIVE_ID = re.compile(r"chatcmpl-([0-9a-f]{32})-[0-9a-f]{8}")   # native_prediction.NATIVE_ID
MAX_AGE_S = 0.5                 # state_sample.join_observations max_age_s
FRONTEND_WIDTH_S = 0.05         # state_sample.join_observations frontend bracket
HISTORY_S = 2.0
MIN_HISTORY_SPAN_S = 0.5
SLOT_S = 1.0                    # actual protocol cap slots are integer at_s seconds
ORIGIN_GRID_S = 1.0             # predeclared decision cadence
L2 = 1.0          # predeclared on standardized features; never tuned
ALPHA = 0.1       # predeclared calibration miscoverage (descriptive band, no guarantee)
NEWTON_MAX, NEWTON_TOL = 50, 1e-8
EPS = 1e-9
BASE_FEATURES = ("cost", "prompt_k", "max_h", "started", "age_s", "native_unknown",
                 "progress", "remaining_h", "decode_batch", "prefill_k", "waiting",
                 "cohort_cost", "budget", "history_rate", "history_missing")


def plan_slots(horizon):
    return math.ceil(horizon / SLOT_S - EPS)


def feature_names(horizon):
    return BASE_FEATURES + ("plan_phase",) + tuple(
        f"plan_b{k}" for k in range(plan_slots(horizon) + 1))


def _finite(value):
    return type(value) in (int, float) and math.isfinite(value)


# ----------------------------------------------------------------------------
# Observation validation (mirrors state_sample.join_observations) and causal features
# ----------------------------------------------------------------------------

def _marks(document, episode):
    if (not isinstance(document, dict) or document.get("run_id") != episode["run_id"]
            or document.get("clock_domain") != episode["clock_domain"]
            or (episode.get("identity") is not None
                and document.get("identity") != episode["identity"])
            or document.get("complete") is not True
            or type(document.get("sequence")) is not int
            or not _finite(document.get("sampled_at"))
            or not _finite(document.get("budget")) or document["budget"] <= 0):
        raise ValueError("gateway_identity_or_clock")
    spec = document.get("cost_spec")
    marks = {}
    for mark in document["requests"]:
        rid = mark.get("request_id")
        received = mark.get("received_at")
        if (not isinstance(rid, str) or rid in marks or not _finite(mark.get("cost"))
                or mark["cost"] <= 0 or type(mark.get("prompt_tokens")) is not int
                or mark["prompt_tokens"] <= 0
                or type(mark.get("max_tokens")) is not int or mark["max_tokens"] <= 0
                or not _finite(mark.get("admitted_at"))
                or mark["admitted_at"] > document["sampled_at"]
                or (received is not None and not (_finite(received)
                                                   and received <= mark["admitted_at"]))
                or (mark.get("first_at") is not None and not (
                    _finite(mark["first_at"])
                    and mark["admitted_at"] <= mark["first_at"] <= document["sampled_at"]))):
            raise ValueError("gateway_mark")
        if spec is not None:
            estimate = max(spec["minimum"], spec["intercept"]
                           + spec["input_per_token"] * mark["prompt_tokens"]
                           + spec["output_per_token"] * mark["max_tokens"])
            if not math.isclose(mark["cost"], estimate, rel_tol=1e-12):
                raise ValueError("gateway_cost_spec_mismatch")
        marks[rid] = mark
    return marks


def _native(frame, marks, episode, gateway_received_at, native_received_at):
    if (not isinstance(frame, dict) or frame.get("schema") != "pr33-native-read-only-v1"
            or frame.get("complete") is not True
            or frame.get("run_id") != episode.get("native_run_id")
            or frame.get("clock_domain") != episode["clock_domain"]
            or frame.get("observer_sha256") != episode.get("observer_sha256")):
        raise ValueError("native_source_or_clock")
    times = (frame.get("sampled_at"), frame.get("frontend_sampled_at"), native_received_at)
    if (not all(_finite(v) for v in times) or not gateway_received_at <= native_received_at
            or not frame["sampled_at"] <= frame["frontend_sampled_at"] <= native_received_at
            or frame["frontend_sampled_at"] - frame["sampled_at"] > FRONTEND_WIDTH_S
            or not 0 <= native_received_at - frame["sampled_at"] <= MAX_AGE_S):
        raise ValueError("native_frame_time")
    usage = frame.get("kv_cache_usage")
    if (any(type(frame.get(k)) is not int or frame[k] < 0
            for k in ("running", "waiting", "pending_batches"))
            or frame["running"] != len(frame.get("requests", ()))
            or not (_finite(usage) and 0 <= usage <= 1)):
        raise ValueError("native_counts")
    joined = {}
    for request in frame["requests"]:
        match = NATIVE_ID.fullmatch(request.get("request_id", ""))
        if not match or match[1] not in marks or match[1] in joined:
            raise ValueError("native_unjoined_or_ambiguous")
        out, mark = request.get("output_tokens"), marks[match[1]]
        if (type(out) is not int or not 0 <= out <= mark["max_tokens"]
                or type(request.get("prompt_tokens")) is not int or request["prompt_tokens"] < 0
                or request.get("maximum_output_tokens") != mark["max_tokens"]):
            raise ValueError("native_work")
        joined[match[1]] = out
    return joined


def _cap_plan(episode):
    plan = episode.get("cap_plan")
    if not plan:
        return None
    points = sorted((float(at), b) for at, b in plan)
    first = points[0][0]
    for at, budget in points:
        slots = (at - first) / SLOT_S
        if abs(slots - round(slots)) > 1e-6 or not (_finite(budget) and budget > 0):
            raise ValueError("cap_plan_off_slot_grid")
    return points


def plan_features(points, t0, horizon, fallback):
    """Lossless slot encoding of the frozen plan on (t0, t0+h]: time to the next slot
    boundary, the budget active at t0, then the budget after each of ceil(h) boundaries."""
    slots = plan_slots(horizon)
    if points is None:
        return (SLOT_S,) + (float(fallback),) * (slots + 1)

    def active(t):
        value = fallback
        for at, budget in points:
            if at <= t + EPS:
                value = budget
        return float(value)
    first = points[0][0]
    boundary = first + SLOT_S * (math.floor((t0 - first) / SLOT_S + EPS) + 1)
    return (boundary - t0, active(t0)) + tuple(active(boundary + k * SLOT_S)
                                               for k in range(slots))


def _budget_provenance(gateway, actions):
    """The snapshot budget must be the one applied by the ACK in force at sampled_at."""
    applied = sorted((a for a in actions if _finite(a.get("applied_at"))),
                     key=lambda a: a["applied_at"])
    current = [a for a in applied if a["applied_at"] <= gateway["sampled_at"] + EPS]
    if (not current or current[-1].get("budget_version") != gateway.get("budget_version")
            or current[-1]["budget"] != gateway["budget"]):
        raise ValueError("gateway_budget_provenance")


def _outstanding(actions, t0):
    """Online-knowable: commands planned before t0 whose applied ACK was not received."""
    return sum(1 for a in actions if a.get("planned_at") is not None
               and a["planned_at"] < t0 - EPS and not a["ack_received_at"] <= t0 + EPS)


def build_origins(episode):
    """Fixed-grid causal origins. Features use only observations received <= t0."""
    if episode.get("partition") not in PARTITIONS:
        raise ValueError("unknown_partition")
    if episode.get("seed_block") in FINAL_HELDOUT:
        raise ValueError("final_heldout_reserved")
    observations = sorted(episode["observations"],
                          key=lambda o: (o["gateway"]["sequence"], o["received_at"]))
    parsed = [(_marks(o["gateway"], episode), o) for o in observations]
    for (_, a), (_, b) in zip(parsed, parsed[1:]):
        if (a["gateway"]["sampled_at"] > b["gateway"]["sampled_at"]
                or a["received_at"] > b["received_at"]):
            raise ValueError("observation_order")
    joined_at, rejected = [], defaultdict(int)
    for index, (marks, obs) in enumerate(parsed):
        if obs.get("native") is None:
            continue
        if not obs["gateway"]["sampled_at"] <= obs["received_at"] <= obs["native_received_at"]:
            raise ValueError("observation_stale_or_noncausal")
        try:
            joined = _native(obs["native"], marks, episode, obs["received_at"],
                             obs["native_received_at"])
            if episode.get("actions") is not None:
                _budget_provenance(obs["gateway"], episode["actions"])
        except ValueError as error:
            # A frame failing the strict join is not an observation (online: fallback).
            rejected[str(error)] += 1
            continue
        joined_at.append((obs["native_received_at"], index, joined))
    actions = episode.get("actions")
    stats = dict(grid_points=0, stale_grid_points=0, no_observation_grid_points=0,
                 outstanding_action_grid_points=0,
                 joined_frames=len(joined_at), rejected_native_frames=dict(rejected),
                 joined_frame_marks=sum(len(parsed[i][0]) for _, i, _ in joined_at),
                 joined_frame_marks_not_native_visible=sum(
                     sum(r not in j for r in parsed[i][0]) for _, i, j in joined_at))
    if not joined_at:
        return [], parsed, stats
    plan = _cap_plan(episode)
    step = episode.get("origin_grid_s", ORIGIN_GRID_S)
    start = episode.get("origin_grid_start", min(j[0] for j in joined_at))
    last = max(j[0] for j in joined_at)
    origins = []
    for k in range(int(math.floor((last - start) / step + EPS)) + 1):
        t0 = start + k * step
        stats["grid_points"] += 1
        seen = [j for j in joined_at if j[0] <= t0 + EPS]
        if not seen:
            stats["no_observation_grid_points"] += 1
            continue
        _, index, joined = max(seen, key=lambda j: (j[0], j[1]))
        marks, obs = parsed[index]
        gateway = obs["gateway"]
        if t0 - gateway["sampled_at"] > MAX_AGE_S:
            stats["stale_grid_points"] += 1
            continue
        outstanding = 0
        if actions is not None:
            used = max(obs["received_at"], obs["native_received_at"])
            for a in actions:
                # Inputs must precede the ACK of any action planned at/after the cut.
                if (a.get("planned_at") is not None and a["planned_at"] >= t0 - EPS
                        and _finite(a.get("applied_at")) and not used < a["applied_at"]):
                    raise ValueError("cut_after_action_ack")
            outstanding = _outstanding(actions, t0)
            stats["outstanding_action_grid_points"] += outstanding > 0
        decode = sum(1 for out in joined.values() if out > 0)
        prefill_k = sum(marks[r]["prompt_tokens"] for r, out in joined.items() if out == 0)
        prefill_k += sum(m["prompt_tokens"] for r, m in marks.items() if r not in joined)
        # Trailing realized release from snapshot pairs received <= t0 only.
        released, span = 0.0, 0.0
        for (m_a, o_a), (m_b, o_b) in zip(parsed, parsed[1:]):
            if o_b["received_at"] > t0 + EPS:
                break
            if o_a["gateway"]["sampled_at"] >= gateway["sampled_at"] - HISTORY_S:
                released += sum(m["cost"] for r, m in m_a.items() if r not in m_b)
                span += o_b["gateway"]["sampled_at"] - o_a["gateway"]["sampled_at"]
        history = released / span if span >= MIN_HISTORY_SPAN_S else None
        cohort_cost = math.fsum(m["cost"] for m in marks.values())
        origins.append(dict(
            episode_id=episode["episode_id"], seed_block=episode["seed_block"],
            partition=episode["partition"], t0=t0, grid_index=k, index=index,
            sampled_at=gateway["sampled_at"], cohort=marks, joined=joined,
            reserved=cohort_cost, budget=gateway["budget"], decode_batch=decode,
            prefill_k=prefill_k / 1000, waiting=obs["native"]["waiting"],
            history_rate=history, outstanding_actions=outstanding,
            plan={h: plan_features(plan, t0, h, gateway["budget"]) for h in HORIZONS}))
    return origins, parsed, stats


def mark_features(origin, rid, horizon):
    mark = origin["cohort"][rid]
    out = origin["joined"].get(rid)
    unknown = out is None
    out = 0 if unknown else out
    return (mark["cost"], mark["prompt_tokens"] / 1000, mark["max_tokens"] / 100,
            float(mark.get("first_at") is not None), origin["sampled_at"] - mark["admitted_at"],
            float(unknown), out / mark["max_tokens"], (mark["max_tokens"] - out) / 100,
            float(origin["decode_batch"]), origin["prefill_k"], float(origin["waiting"]),
            origin["reserved"], origin["budget"],
            origin["history_rate"] if origin["history_rate"] is not None else 0.0,
            float(origin["history_rate"] is None)) + tuple(origin["plan"][horizon])


# ----------------------------------------------------------------------------
# Ground truth: contiguous ledger (exact/tied bounds) or snapshot brackets
# ----------------------------------------------------------------------------

def ledger_releases(episode, parsed):
    frames = sorted(episode["ledger"], key=lambda f: f["sequence"])
    first = parsed[0][1]["gateway"]
    sequence, reserved = first["sequence"], math.fsum(m["cost"] for m in parsed[0][0].values())
    at_sequence = {sequence: reserved}
    effective = {}
    releases, previous_at = [], -math.inf
    for frame in frames:
        if frame["sequence"] <= first["sequence"]:
            continue
        if (frame.get("event") != "mpc_ledger" or frame.get("run_id") != episode["run_id"]
                or frame.get("clock_domain") != episode["clock_domain"]
                or frame.get("complete") is not True or frame["sequence"] != sequence + 1
                or not _finite(frame.get("effective_at")) or not _finite(frame.get("reserved_cost"))):
            raise ValueError("ledger_identity_or_gap")
        if frame["effective_at"] < previous_at:
            raise ValueError("ledger_chronology")
        previous_at = frame["effective_at"]
        delta = frame["reserved_cost"] - reserved
        if delta < -EPS:
            releases.append((frame["sequence"], frame["effective_at"], -delta))
        sequence, reserved = frame["sequence"], frame["reserved_cost"]
        at_sequence[sequence] = reserved
        effective[sequence] = frame["effective_at"]
    for marks, obs in parsed:
        seq, sampled = obs["gateway"]["sequence"], obs["gateway"]["sampled_at"]
        value = at_sequence.get(seq)
        if value is None or not math.isclose(value, math.fsum(m["cost"] for m in marks.values()),
                                             abs_tol=1e-9):
            raise ValueError("snapshot_ledger_mismatch")
        # A snapshot at sequence s was read after event s and before event s+1.
        if effective.get(seq, -math.inf) > sampled + EPS or \
                effective.get(seq + 1, math.inf) < sampled - EPS:
            raise ValueError("ledger_snapshot_chronology")
    return releases, parsed[-1][1]["gateway"]["sampled_at"]


def release_groups(origin, parsed, releases):
    """Group cohort marks by (disappearance interval, cost) with candidate ledger events."""
    start = origin["index"]
    pending = set(origin["cohort"])
    groups, unresolved = defaultdict(list), []
    for (_, a), (m_b, b) in zip(parsed[start:], parsed[start + 1:]):
        gone = [rid for rid in pending if rid not in m_b]
        for rid in gone:
            groups[(a["gateway"]["sequence"], b["gateway"]["sequence"],
                    origin["cohort"][rid]["cost"])].append(rid)
        pending -= set(gone)
    for rid in pending:
        unresolved.append(rid)
    out = []
    for (lo, hi, cost), members in groups.items():
        events = sorted(t for seq, t, c in releases
                        if lo < seq <= hi and math.isclose(c, cost, rel_tol=1e-9, abs_tol=1e-12))
        if len(events) < len(members):
            raise ValueError("ledger_release_identity")
        out.append(dict(cost=cost, members=members, events=events))
    return out, unresolved


def cumulative_truth(origin, groups, unresolved, coverage_end, horizon):
    target = origin["t0"] + horizon
    lo = hi = 0.0
    for g in groups:
        done = sum(t <= target for t in g["events"])
        extra = len(g["events"]) - len(g["members"])
        lo += g["cost"] * max(0, done - extra)
        hi += g["cost"] * min(done, len(g["members"]))
    if target > coverage_end:
        hi += sum(origin["cohort"][rid]["cost"] for rid in unresolved)
    return lo, hi


def mark_label(rid, groups, unresolved, coverage_end, target):
    for g in groups:
        if rid in g["members"]:
            if len(g["events"]) == 1 or target >= g["events"][-1]:
                return int(target >= g["events"][-1])
            return 0 if target < g["events"][0] else None
    return 0 if target <= coverage_end else None


def snapshot_brackets(origin, parsed):
    """Release of each cohort mark lies in (last live sampled_at, first absent sampled_at]."""
    last = {rid: origin["sampled_at"] for rid in origin["cohort"]}
    absent = {}
    horizon_end = origin["t0"] + max(HORIZONS)
    for marks, obs in parsed[origin["index"] + 1:]:
        sampled = obs["gateway"]["sampled_at"]
        for rid in origin["cohort"]:
            if rid in marks:
                if rid in absent:
                    raise ValueError("mark_reappeared")
                last[rid] = sampled
            elif rid not in absent:
                absent[rid] = sampled
        if sampled >= horizon_end and len(absent) == len(origin["cohort"]):
            break
        if sampled >= horizon_end and all(last[r] >= horizon_end for r in origin["cohort"]
                                          if r not in absent):
            break
    return {rid: (last[rid], absent.get(rid, math.inf)) for rid in origin["cohort"]}


def bracket_truth(origin, brackets, horizon):
    target = origin["t0"] + horizon
    lo = math.fsum(origin["cohort"][r]["cost"] for r, (_, a) in brackets.items() if a <= target)
    hi = math.fsum(origin["cohort"][r]["cost"] for r, (l, _) in brackets.items() if l < target)
    return lo, hi


def bracket_label(bracket, target):
    live, absent = bracket
    return 1 if absent <= target else 0 if target <= live else None


def build_dataset(episodes, stats=None):
    rows, seen = [], {}
    stats = {} if stats is None else stats
    for episode in episodes:
        block, part = episode.get("seed_block"), episode.get("partition")
        if seen.setdefault(block, part) != part:
            raise ValueError("seed_block_partition_leakage")
        origins, parsed, origin_stats = build_origins(episode)
        stats[episode["episode_id"]] = origin_stats
        if episode.get("ledger") is not None:
            releases, coverage_end = ledger_releases(episode, parsed)
        for origin in origins:
            if episode.get("ledger") is not None:
                groups, unresolved = release_groups(origin, parsed, releases)
                origin["truth_source"] = "ledger"
                origin["truth"] = {h: cumulative_truth(origin, groups, unresolved, coverage_end, h)
                                   for h in HORIZONS}
                origin["labels"] = {(rid, h): mark_label(rid, groups, unresolved, coverage_end,
                                                         origin["t0"] + h)
                                    for rid in origin["cohort"] for h in HORIZONS}
            else:
                brackets = snapshot_brackets(origin, parsed)
                origin["truth_source"] = "snapshot_bracket"
                origin["truth"] = {h: bracket_truth(origin, brackets, h) for h in HORIZONS}
                origin["labels"] = {(rid, h): bracket_label(brackets[rid], origin["t0"] + h)
                                    for rid in origin["cohort"] for h in HORIZONS}
            rows.append(origin)
    return rows


# ----------------------------------------------------------------------------
# Train-only fitting
# ----------------------------------------------------------------------------

def _solve(matrix, vector):
    n = len(vector)
    a = [row[:] + [vector[i]] for i, row in enumerate(matrix)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(a[r][col]))
        if abs(a[pivot][col]) < 1e-15:
            raise ValueError("singular_system")
        a[col], a[pivot] = a[pivot], a[col]
        for r in range(n):
            if r != col and a[r][col]:
                f = a[r][col] / a[col][col]
                a[r] = [x - f * y for x, y in zip(a[r], a[col])]
    return [a[i][n] / a[i][i] for i in range(n)]


def _sigmoid(z):
    return 1 / (1 + math.exp(-z)) if z >= 0 else math.exp(z) / (1 + math.exp(z))


def fit_logistic(xs, ys, weights, iterations=NEWTON_MAX):
    """L2 logistic (quasi-)likelihood, y in [0,1], unpenalized intercept, Newton.

    Returns convergence diagnostics; callers must not use an unconverged fit."""
    k = len(xs[0])
    mean = [statistics.fmean(x[j] for x in xs) for j in range(k)]
    scale = [statistics.pstdev([x[j] for x in xs]) or 1.0 for j in range(k)]
    zs = [[1.0] + [(x[j] - mean[j]) / scale[j] for j in range(k)] for x in xs]
    beta = [0.0] * (k + 1)
    total = math.fsum(weights)
    converged, used, step_size, grad_norm = False, 0, math.inf, math.inf
    for used in range(1, iterations + 1):
        grad = [0.0] * (k + 1)
        hess = [[0.0] * (k + 1) for _ in range(k + 1)]
        for z, y, w in zip(zs, ys, weights):
            p = _sigmoid(sum(b * v for b, v in zip(beta, z)))
            g, h = w * (y - p), w * p * (1 - p)
            for i in range(k + 1):
                grad[i] += g * z[i]
                for j in range(i, k + 1):
                    hess[i][j] += h * z[i] * z[j]
        for i in range(k + 1):
            for j in range(i):
                hess[i][j] = hess[j][i]
            if i:
                grad[i] -= L2 * total / len(ys) * beta[i]
                hess[i][i] += L2 * total / len(ys)
        hess[0][0] += 1e-9
        grad_norm = max(abs(g) for g in grad) / total
        step = _solve(hess, grad)
        beta = [b + s for b, s in zip(beta, step)]
        step_size = max(abs(s) for s in step)
        if step_size < NEWTON_TOL:
            converged = True
            break
    return dict(beta=beta, mean=mean, scale=scale, converged=converged, iterations=used,
                last_step=step_size, gradient_inf_per_weight=grad_norm,
                max_abs_beta=max(abs(b) for b in beta))


def _fit_or_constant(xs, ys, ws):
    """A horizon whose determinate labels have one class has no identifiable covariate
    effect; it is reported as a degenerate weighted constant, never as a fitted model."""
    if len({y for y in ys if y in (0, 1)}) < 2:
        value = math.fsum(w * y for y, w in zip(ys, ws)) / math.fsum(ws)
        return dict(constant=value, degenerate=True, converged=True, iterations=0,
                    last_step=0.0, gradient_inf_per_weight=0.0, max_abs_beta=0.0)
    return dict(fit_logistic(xs, ys, ws), degenerate=False)


def _logit_predict(model, x):
    if model.get("degenerate"):
        return model["constant"]
    z = [1.0] + [(v - m) / s for v, m, s in zip(x, model["mean"], model["scale"])]
    return _sigmoid(sum(b * v for b, v in zip(model["beta"], z)))


def origin_vector(origin):
    marks = origin["cohort"].values()
    unknown = math.fsum(m["cost"] for r, m in origin["cohort"].items() if r not in origin["joined"])
    progress = [origin["joined"][r] / m["max_tokens"] for r, m in origin["cohort"].items()
                if r in origin["joined"]]
    return (origin["reserved"], float(origin["decode_batch"]), origin["prefill_k"],
            float(origin["waiting"]), origin["budget"],
            origin["history_rate"] if origin["history_rate"] is not None else 0.0,
            float(origin["history_rate"] is None), float(len(origin["cohort"])),
            unknown / origin["reserved"] if origin["reserved"] else 0.0,
            statistics.fmean(progress) if progress else 0.0,
            float(sum(1 for m in marks if m.get("first_at") is None))) \
        + tuple(origin["plan"][max(HORIZONS)])


def _nn(vector, others, scale):
    return min((math.sqrt(sum(((a - b) / s) ** 2 for a, b, s in zip(vector, o, scale)))
                for o in others), default=math.inf)


def support_envelope(train):
    """Data-defined support: every used feature's range, observed joint work mixes and
    plan sequences, and a leave-one-episode-out nearest-neighbour radius. It is an
    abstention envelope, not a certificate of exchangeability or coverage."""
    env = dict(ranges={}, work_mixes=sorted({tuple(sorted({(m["prompt_tokens"], m["max_tokens"])
                                                            for m in o["cohort"].values()}))
                                             for o in train}),
               plan_patterns={h: sorted({tuple(o["plan"][h][1:]) for o in train})
                              for h in HORIZONS})
    for h in HORIZONS:
        rows = [mark_features(o, rid, h) for o in train for rid in o["cohort"]]
        env["ranges"][h] = [(min(c), max(c)) for c in zip(*rows)] if rows else None
    vectors = [(o["episode_id"], origin_vector(o)) for o in train]
    scale = [statistics.pstdev([v[j] for _, v in vectors]) or 1.0
             for j in range(len(vectors[0][1]))]
    radius = None
    if len({e for e, _ in vectors}) >= 2:
        radius = max(_nn(v, [w for f, w in vectors if f != e], scale) for e, v in vectors)
    env["nn"] = dict(vectors=[v for _, v in vectors], scale=scale, radius=radius,
                     rule="max leave-one-episode-out NN distance over Train origins")
    return env


def ood_reasons(origin, env):
    reasons = set()
    for h in HORIZONS:
        names, ranges = feature_names(h), env["ranges"][h]
        for rid in origin["cohort"]:
            for name, value, (lo, hi) in zip(names, mark_features(origin, rid, h), ranges):
                if not lo - EPS <= value <= hi + EPS:
                    reasons.add("range_" + name)
        if tuple(origin["plan"][h][1:]) not in {tuple(p) for p in env["plan_patterns"][h]}:
            reasons.add("joint_plan_sequence")
    mix = tuple(sorted({(m["prompt_tokens"], m["max_tokens"]) for m in origin["cohort"].values()}))
    if mix not in {tuple(tuple(s) for s in w) for w in env["work_mixes"]}:
        reasons.add("joint_work_mix")
    nn = env["nn"]
    if nn["radius"] is None:
        reasons.add("joint_nn_unavailable")
    elif _nn(origin_vector(origin), nn["vectors"], nn["scale"]) > nn["radius"] + EPS:
        reasons.add("joint_nn_distance")
    return sorted(reasons)


def _labelled(train, h, ambiguous_as):
    xs, ys, ws, ambiguous = [], [], [], 0
    for o in train:
        for rid in o["cohort"]:
            y = o["labels"][(rid, h)]
            if y is None:
                ambiguous += 1
                y = ambiguous_as
            xs.append(mark_features(o, rid, h))
            ys.append(y)
            ws.append(1 / len(o["cohort"]))
    return xs, ys, ws, ambiguous


def fit(train, sensitivity=False):
    """Every parameter uses Train origins only; calibration/development are refused.
    No origin or mark is dropped for interval truth: baselines use mean truth bounds and
    the logistic uses the midpoint 0.5 for interval-censored mark labels (a convention,
    not an MLE). With sensitivity=True the 0/1 imputation bounds are also fitted."""
    if not train or any(o["partition"] != "train" for o in train):
        raise ValueError("fit_requires_train_only")
    positive = [o for o in train if o["reserved"] > 0]
    if not positive:
        raise ValueError("no_train_origins")
    fraction, fraction_bounds, lo_sum, hi_sum, h_sum = {}, {}, 0.0, 0.0, 0.0
    for h in HORIZONS:
        lo = statistics.fmean(o["truth"][h][0] / o["reserved"] for o in positive)
        hi = statistics.fmean(o["truth"][h][1] / o["reserved"] for o in positive)
        fraction_bounds[h], fraction[h] = (lo, hi), (lo + hi) / 2
        lo_sum += math.fsum(o["truth"][h][0] for o in positive)
        hi_sum += math.fsum(o["truth"][h][1] for o in positive)
        h_sum += h * len(positive)
    logits, label_counts, bounds = {}, {}, {}
    for h in HORIZONS:
        xs, ys, ws, ambiguous = _labelled(train, h, 0.5)
        logits[h] = _fit_or_constant(xs, ys, ws)
        label_counts[h] = dict(marks=len(ys), interval_censored_midpoint=ambiguous,
                               released=sum(y == 1 for y in ys), unreleased=sum(y == 0 for y in ys))
        if sensitivity:
            bounds[h] = tuple(_fit_or_constant(*_labelled(train, h, a)[:3]) for a in (0.0, 1.0))
    if all(m["degenerate"] for m in logits.values()):
        raise ValueError("degenerate_train_labels")
    return dict(fraction=fraction, fraction_bounds=fraction_bounds,
                fluid_rate=(lo_sum + hi_sum) / 2 / h_sum,
                fluid_rate_bounds=(lo_sum / h_sum, hi_sum / h_sum), logistic=logits,
                label_bounds=bounds, support=support_envelope(train), label_counts=label_counts,
                fit_weighting="origin-equal mark weights; not block-balanced",
                train_blocks=sorted({o["seed_block"] for o in train}))


def _batch_aware(models, origin):
    out, previous = {}, {rid: 0.0 for rid in origin["cohort"]}
    for h in HORIZONS:
        total = 0.0
        for rid, mark in origin["cohort"].items():
            p = max(previous[rid], _logit_predict(models[h], mark_features(origin, rid, h)))
            previous[rid] = p
            total += mark["cost"] * p
        out[h] = total
    return out


def predict(params, origin):
    """None when outside the Train support envelope or when any fit did not converge."""
    reasons = ood_reasons(origin, params["support"])
    if origin.get("outstanding_actions"):
        reasons.append("outstanding_action_at_cut")
    if any(not params["logistic"][h]["converged"] for h in HORIZONS):
        reasons.append("fit_not_converged")
    if reasons:
        return None, reasons
    r = origin["reserved"]
    rate = origin["history_rate"] if origin["history_rate"] is not None else params["fluid_rate"]
    out = dict(train_fraction={h: r * params["fraction"][h] for h in HORIZONS},
               fluid_history={h: min(r, rate * h) for h in HORIZONS},
               batch_aware=_batch_aware(params["logistic"], origin))
    return out, []


# ----------------------------------------------------------------------------
# Block-level evaluation, calibration and OOD accounting
# ----------------------------------------------------------------------------

def _unique(rows):
    """One row per (block, episode, origin time): duplicated origins carry no new block."""
    out = {}
    for o in rows:
        out.setdefault((o.get("seed_block"), o.get("episode_id"), o.get("t0")), o)
    return list(out.values())


def _interval_error(pred, lo, hi):
    best = 0.0 if lo <= pred <= hi else min(abs(pred - lo), abs(pred - hi))
    return best, max(abs(pred - lo), abs(pred - hi))


def score(params, rows):
    """Equal-weight mean over h of |pred-actual|/R_origin, grid origin -> episode -> block."""
    per_block = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    counts = defaultdict(int)
    for o in _unique(rows):
        if o["reserved"] <= 0:
            counts["zero_reserved_origins"] += 1
            continue
        pred, reasons = predict(params, o)
        if pred is None:
            counts["ood_abstained"] += 1
            for reason in reasons:
                counts["ood_" + reason] += 1
            continue
        counts["scored_origins"] += 1
        for model, values in pred.items():
            errs = [_interval_error(values[h], *o["truth"][h]) for h in HORIZONS]
            per_block[model][o["seed_block"]][o["episode_id"]].append(
                (statistics.fmean(e[0] for e in errs) / o["reserved"],
                 statistics.fmean(e[1] for e in errs) / o["reserved"]))
    result = {}
    for model, blocks in per_block.items():
        block_scores = {}
        for block, episodes in blocks.items():
            means = [(statistics.fmean(v[0] for v in e), statistics.fmean(v[1] for v in e))
                     for e in episodes.values()]
            block_scores[block] = dict(lower=statistics.fmean(m[0] for m in means),
                                       upper=statistics.fmean(m[1] for m in means))
        result[model] = dict(blocks=block_scores,
                             lower=statistics.fmean(b["lower"] for b in block_scores.values()),
                             upper=statistics.fmean(b["upper"] for b in block_scores.values()))
    return dict(models=result, counts=dict(counts))


def _quantile(values, q):
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, math.ceil(q * (len(ordered) + 1)) - 1))
    return ordered[index]


def calibrate(params, rows, model="batch_aware"):
    """Block-level descriptive band from Calibration blocks only.

    Each block contributes its own within-block residual quantiles on the fixed origin
    grid, using interval truth bounds (no exact-only selection); the band is the envelope
    across blocks. Duplicated origins and the number of origins in a block cannot move
    another block's contribution. No coverage guarantee is claimed."""
    if any(o["partition"] != "calibration" for o in rows):
        raise ValueError("calibration_requires_calibration_only")
    per_block = defaultdict(lambda: defaultdict(lambda: ([], [])))
    for o in _unique(rows):
        pred, _ = predict(params, o) if o["reserved"] > 0 else (None, None)
        if pred is None:
            continue
        for h in HORIZONS:
            lo, hi = o["truth"][h]
            cell = per_block[o["seed_block"]][h]
            cell[0].append((lo - pred[model][h]) / o["reserved"])
            cell[1].append((hi - pred[model][h]) / o["reserved"])
    if not per_block:
        raise ValueError("no_calibration_residuals")
    bands = {}
    for h in HORIZONS:
        blocks = {b: (_quantile(c[h][0], ALPHA / 2), _quantile(c[h][1], 1 - ALPHA / 2))
                  for b, c in per_block.items() if c[h][0]}
        bands[h] = dict(lower=min(v[0] for v in blocks.values()),
                        upper=max(v[1] for v in blocks.values()), blocks=len(blocks))
    return dict(model=model, alpha=ALPHA, bands=bands, blocks=sorted(per_block),
                statistical_guarantee=False)


def coverage(params, calibration, rows):
    per_block = defaultdict(lambda: [0, 0, 0])
    for o in _unique(rows):
        if o["reserved"] <= 0:
            continue
        pred, _ = predict(params, o)
        if pred is None:
            continue
        for h in HORIZONS:
            band = calibration["bands"][h]
            lo = pred[calibration["model"]][h] + band["lower"] * o["reserved"]
            hi = pred[calibration["model"]][h] + band["upper"] * o["reserved"]
            t_lo, t_hi = o["truth"][h]
            cell = per_block[o["seed_block"]]
            cell[2] += 1
            cell[0] += lo - EPS <= t_lo and t_hi <= hi + EPS     # covered for every feasible truth
            cell[1] += t_hi >= lo - EPS and t_lo <= hi + EPS      # covered for some feasible truth
    return {block: dict(lower=c[0] / c[2], upper=c[1] / c[2], n=c[2]) for block, c in per_block.items()}


def evaluate(episodes):
    stats = {}
    rows = build_dataset(episodes, stats)
    split = {p: [o for o in rows if o["partition"] == p] for p in PARTITIONS}
    params = fit(split["train"])
    result = dict(schema="nv3-opus-release-model-v3", horizons=list(HORIZONS),
                  train_blocks=params["train_blocks"], fluid_rate_cost_per_s=params["fluid_rate"],
                  label_counts={str(h): v for h, v in params["label_counts"].items()},
                  convergence={str(h): {k: v for k, v in m.items()
                                        if k not in ("beta", "mean", "scale")}
                               for h, m in params["logistic"].items()},
                  origin_grid=stats,
                  scores={p: score(params, split[p]) for p in PARTITIONS if split[p]},
                  native_performance_accepted=False, statistical_guarantee=False,
                  mpc_accepted=False, joint_response_kernel=False)
    if split["calibration"]:
        cal = calibrate(params, split["calibration"])
        result["calibration"] = dict(cal, bands={str(h): v for h, v in cal["bands"].items()})
        if split["development"]:
            result["development_coverage"] = coverage(params, cal, split["development"])
    return result


# ----------------------------------------------------------------------------
# Useful / physical / tail forward-work accounting (does not relax the v2 audit)
# ----------------------------------------------------------------------------

def forward_work_accounting(request, steps, worker_rows, *, request_id, max_tail_tokens=1):
    """Partition one natural-EOS request's executed positions.

    useful = prompt + delivered_output - 1 (the last sampled token is never fed back);
    physical = contiguous executed positions; tail = physical - useful. The legacy strict
    audit (physical == useful) is reported unchanged. A tail is only *accounted* when it is
    a single contiguous decode position scheduled before the engine finish, whose matched
    output commit (step end) is at/after that finish, and matched to an executed worker
    forward. That is structural parity only: tail_mechanism_evidenced additionally needs
    request["tail_evidence"] with placeholder_tokens == 1, cuda_completed, an explicit
    delivered_output_from_step False and output_commit_at >= finished. Neither flag is
    native qualification authority. GPU spans are not absolute clocks or exclusive service.
    """
    prompt, output = request["input_tokens"], request["output_tokens"]
    finished = request.get("finished")
    problems = []
    if request.get("finish_reason") != "stop" or type(output) is not int or output <= 0:
        problems.append("not_natural_eos_output")
    workers = {}
    for row in worker_rows:
        if row["step_id"] in workers:
            problems.append("duplicate_worker_step")
        workers[row["step_id"]] = row
    progress, useful_steps, tail_steps = 0, 0, []
    useful = prompt + output - 1
    for step in sorted(steps, key=lambda s: s["start"]):
        mine = [w for w in step["work"] if w["request_id"] == request_id]
        if not mine:
            continue
        if len(mine) != 1 or mine[0]["position"] != progress or mine[0]["tokens"] <= 0:
            problems.append("position_gap_repeat_or_split")
            continue
        work = mine[0]
        worker = workers.get(step["step_id"])
        if (worker is None or (worker.get("executed_positions") or {}).get(request_id) != work["position"]
                or (worker.get("executed_counts") or {}).get(request_id) != work["tokens"]):
            problems.append("unmatched_worker_forward")
        if work["position"] + work["tokens"] <= useful:
            useful_steps += 1
        elif work["position"] >= useful:
            tail_steps.append((step, work, worker))
        else:
            problems.append("step_straddles_useful_boundary")
        progress = work["position"] + work["tokens"]
    tail = progress - useful
    if tail < 0:
        problems.append("missing_useful_work")
    if tail > max_tail_tokens:
        problems.append("unexplained_tail_work")
    tail_ok = True
    for step, work, worker in tail_steps:
        if not _finite(finished):
            problems.append("finish_time_unavailable")
            tail_ok = False
        elif not step["start"] < finished:
            problems.append("tail_scheduled_after_finish")
            tail_ok = False
        elif not (_finite(step.get("end")) and step["end"] >= finished):
            problems.append("tail_commit_before_finish")
            tail_ok = False
        if work["tokens"] != 1 or worker is None:
            tail_ok = False
    accounted = not problems and 0 <= tail <= max_tail_tokens and tail_ok
    evidence = request.get("tail_evidence") or {}
    mechanism = (accounted and tail == 1 and evidence.get("placeholder_tokens") == 1
                 and evidence.get("cuda_completed") is True
                 and evidence.get("delivered_output_from_step") is False
                 and _finite(evidence.get("output_commit_at")) and _finite(finished)
                 and evidence["output_commit_at"] >= finished)
    return dict(useful_positions=useful, physical_positions=progress, tail_positions=tail,
                useful_steps=useful_steps, tail_steps=len(tail_steps),
                legacy_strict_audit_valid=progress == useful and not problems,
                tail_accounted=accounted, tail_mechanism_evidenced=mechanism,
                native_qualification_authority=False,
                problems=sorted(set(problems)),
                scope="Executed positions per request; GPU forward spans are per-step labels, "
                      "not absolute clocks or exclusive service durations.")


# ----------------------------------------------------------------------------
# Portable adapter for actual native-v3 identification artifacts (read-only)
# ----------------------------------------------------------------------------

REPLICA_SPLITS = {"train": "train"}        # R3: Train only; other splits are not loaded
TRAIN_BLOCKS = frozenset(range(181001, 181017))
NATIVE_EXTRA = ("gateway_snapshot", "gateway_received_at", "received_at", "available")


def episode_from_replica(document, index):
    """Map one native-v3 episode artifact to this module's episode schema.

    Gateway identity/clock come from the index receipt; the native run/observer are taken
    from the episode's frames and must be uniform (internal consistency, not an
    independent receipt). The ledger is not captured, so truth uses snapshot brackets."""
    if document.get("split") not in REPLICA_SPLITS:
        raise ValueError("replica_split_not_allowed")
    if document["seed_block"] in FINAL_HELDOUT or document["seed_block"] not in TRAIN_BLOCKS:
        raise ValueError("replica_seed_block_not_train")
    frames = [f for f in document["native_frames"] if f.get("available") is True]
    sources = {(f.get("run_id"), f.get("observer_sha256")) for f in frames}
    if len(sources) != 1:
        raise ValueError("native_source_not_uniform")
    (native_run, observer), = sources
    return dict(
        episode_id=document["episode_id"], seed_block=document["seed_block"],
        partition=REPLICA_SPLITS[document["split"]], clock_domain=index["clock_domain"],
        run_id=document["gateway_run_id"], native_run_id=native_run, observer_sha256=observer,
        identity=index["model_identity"], ledger=None, origin_grid_start=document["start"],
        cap_plan=[(document["start"] + s["at_s"], s["budget"]) for s in document["schedule"]],
        actions=_replica_actions(document), start=document["start"],
        duration_s=document["duration_s"], cell=document["cell"],
        client_rows=document["rows"], expected_ids=document["expected_ids"],
        observations=[dict(gateway=f["gateway_snapshot"], received_at=f["gateway_received_at"],
                           native={k: v for k, v in f.items() if k not in NATIVE_EXTRA},
                           native_received_at=f["received_at"]) for f in frames],
        unavailable_frames=len(document["native_frames"]) - len(frames))


def _replica_actions(document):
    """Actual CAS receipts: pre-assignment plus every planned action's final attempt."""
    out = []
    for planned, attempts in ([(None, document["preassignment"])]
                              + [(document["start"] + a["at_s"], a["attempts"])
                                 for a in document["actions"]]):
        last = attempts[-1]
        ack = last["reply"].get("acknowledgment") or {}
        applied = last["reply"].get("status") == "applied"
        out.append(dict(planned_at=planned, budget=ack.get("budget"),
                        budget_version=ack.get("budget_version"),
                        applied_at=ack.get("applied_at") if applied else None,
                        ack_received_at=last["received_at"] if applied else math.inf,
                        attempts=len(attempts)))
    return out


# R8: explicit collector-source registry. Different collectors are never aliased: each
# binds its own index file, collector/protocol hashes, controller and native source, and
# whether confirmed holds replace repeated-budget commands. All share one cost/core binding.
COMMON_BINDING = dict(
    schema="native-v3-state-response-id-v1",
    implementation_hash="b4f234020105f69f608da45dba7317a8bb632ecd84aeb0e310362740e5fa083a",
    cost_hash="cf8162ea687a697d698f26d0bd663fdb9a2f172dce71add05d267ac3dfb43833",
    support_hash="7e6d49ca4a15ab8630fed9a7fa150eb3ab8f2e1a7b0d9585cc8a6c48f666498d",
    clock_domain="linux-monotonic:64589d75-974d-436e-80e4-fc734d7195d8:time:[4026534406]")
SOURCE_BINDINGS = {
    "6c11fe7e683439f379f0dfdbd21b05f5873b2c90": dict(
        index="latest-index.json",
        collector_sha256="a2ec60abeee5ae736abd6b125585cba2d12ab3046527cf6cc2b445aa60b9d609",
        protocol_sha256="7ca36af13ad065bc7edf0f381b7517ee30c915ec400541e01ff7054369452662",
        controller_version="prespecified-cap-sequence-v1",
        native_source="2587d2b822dcd3812353ce2ac3369b7192fa7ba7", holds=False),
    "729b144a0c5885d702a6a49c655f61c62513ed30": dict(
        index="index.json",
        collector_sha256="069a58b6c2e15081acaaf70c73a9465fdb64da694d47fbc5b20f35c2560d7422",
        protocol_sha256="8b072a3c6f0d287196a9bbb07fce9e9095a1d63ef8bb7a2a56ad71c31d8281fc",
        controller_version="prespecified-cap-sequence-v2-confirmed-holds",
        native_source="729b144a0c5885d702a6a49c655f61c62513ed30", holds=True)}


def bind_source(root):
    """Return (source_commit, index) only for an exactly registered collector binding."""
    found = [(c, b) for c, b in SOURCE_BINDINGS.items() if (root / b["index"]).exists()]
    if len(found) != 1:
        raise ValueError("replica_index_ambiguous_or_missing")
    commit, binding = found[0]
    index = json.loads((root / binding["index"]).read_text())
    identity = index.get("model_identity") or {}
    if (index.get("source_commit") != commit
            or index.get("schema") != COMMON_BINDING["schema"]
            or index.get("implementation_hash") != COMMON_BINDING["implementation_hash"]
            or identity.get("implementation_hash") != COMMON_BINDING["implementation_hash"]
            or identity.get("cost_hash") != COMMON_BINDING["cost_hash"]
            or identity.get("support_hash") != COMMON_BINDING["support_hash"]
            or index.get("clock_domain") != COMMON_BINDING["clock_domain"]
            or any(index.get(k) != binding[k] for k in
                   ("collector_sha256", "protocol_sha256", "controller_version"))
            or index["gpu_environment"]["native_launch"].get("source_commit")
            != binding["native_source"]):
        raise ValueError("replica_source_binding")
    return commit, index


def bind_assignments(document, holds_allowed, clock_domain):
    """Each slot 1..last is covered exactly once by an applied command whose ACK budget is
    the planned budget, or (holds collectors only) by a confirmed hold bound to the ACK in
    force at its confirmation (same budget/version/operation, same run/clock). Returns the
    hold evidence; a hold is an observed no-change, never a manufactured ACK."""
    schedule = {s["at_s"]: s["budget"] for s in document["schedule"]}
    acks = []
    for at_s, attempts in [(0, document["preassignment"])] + \
            [(a["at_s"], a["attempts"]) for a in document["actions"]]:
        reply = attempts[-1]["reply"]
        ack = reply.get("acknowledgment") or {}
        if (reply.get("status") != "applied" or ack.get("budget") != schedule.get(at_s)
                or ack.get("run_id") != document["gateway_run_id"]
                or ack.get("clock_domain") != clock_domain):
            raise ValueError("replica_action_not_applied_as_planned")
        acks.append(ack)
    holds = document.get("held_assignments") or []
    if holds and not holds_allowed:
        raise ValueError("replica_holds_not_in_binding")
    covered = sorted([a["at_s"] for a in document["actions"]] + [h["at_s"] for h in holds])
    if covered != sorted(s for s in schedule if s > 0):
        raise ValueError("replica_assignment_coverage")
    lags = []
    for h in holds:
        prior = [a for a in acks if a["applied_at"] <= h["confirmed_at"]]
        last = max(prior, key=lambda a: a["applied_at"]) if prior else {}
        obs = h.get("state_observation") or {}
        if (h.get("status") != "confirmed_hold" or h["budget"] != schedule[h["at_s"]]
                or schedule.get(h["at_s"] - 1) != h["budget"]
                or last.get("budget") != h["budget"]
                or last.get("budget_version") != h["budget_version"]
                or last.get("operation_id") != h["reference_operation_id"]
                or h.get("run_id") != document["gateway_run_id"]
                or h.get("clock_domain") != clock_domain
                or obs.get("run_id") != h["run_id"] or obs.get("clock_domain") != clock_domain
                or obs.get("budget_version") != h["budget_version"]
                or not obs["get_started_at"] <= obs["sampled_at"] <= obs["get_received_at"]
                <= h["confirmed_at"]):
            raise ValueError("replica_hold_not_bound_to_ack")
        lags.append(h["confirmed_at"] - (document["start"] + h["at_s"]))
    return dict(holds=len(holds), commands=len(document["actions"]),
                hold_confirm_lag_s=sorted(lags))


def load_replica(directory):
    """Verify every listed artifact's sha256 before use; load allowed-split episodes."""
    root = Path(directory)
    source, index = bind_source(root)
    listed = [json.loads(line) for line in (root / "verified-artifact-sha256.jsonl").read_text()
              .splitlines() if line.strip()]
    for row in listed:
        if hashlib.sha256((root / row["artifact"]).read_bytes()).hexdigest() != row["sha256"]:
            raise ValueError("replica_artifact_hash:" + row["artifact"])
    names = sorted(r["artifact"] for r in listed
                   if r["artifact"].endswith(".json") and r["artifact"].startswith("nv3-"))
    episodes, skipped = [], []
    for name in names:
        document = json.loads((root / name).read_text())
        if document.get("split") not in REPLICA_SPLITS:
            skipped.append(name)
            continue
        episode = episode_from_replica(document, index)
        # Kept off the receipt so that earlier rounds' outputs stay byte-identical.
        episode["source_commit"] = source
        episode["assignment_evidence"] = bind_assignments(
            document, SOURCE_BINDINGS[source]["holds"], index["clock_domain"])
        episodes.append(episode)
    receipt = dict(collector_source_commit=index.get("source_commit"),
                   native_source_commit=index["gpu_environment"]["native_launch"]["source_commit"],
                   clock_domain=index["clock_domain"], verified_artifacts=len(listed),
                   loaded=[e["episode_id"] for e in episodes], skipped_splits=skipped,
                   gateway_runs={e["episode_id"]: e["run_id"] for e in episodes},
                   native_runs=sorted({e["native_run_id"] for e in episodes}),
                   artifact_sha256={r["artifact"]: r["sha256"] for r in listed
                                    if r["artifact"] in names})
    return episodes, receipt


def train_diagnostics(episodes, receipt=None):
    """Train-only descriptive diagnostics; not forecast, calibration or causal results."""
    if any(e["partition"] != "train" for e in episodes):
        raise ValueError("diagnostics_train_only")
    stats = {}
    rows = build_dataset(episodes, stats)
    marks = [(o, rid) for o in rows for rid in o["cohort"]]
    out = dict(schema="nv3-opus-train-diagnostics-v1", receipt=receipt, origin_grid=stats,
               origins=len(rows), origin_marks=len(marks),
               origin_marks_not_native_visible=sum(r not in o["joined"] for o, r in marks),
               forecast_result=False, causal_result=False, mpc_result=False)
    delays = sorted(a["applied_at"] - a["planned_at"] for e in episodes
                    for a in e.get("actions") or () if a["planned_at"] is not None
                    and _finite(a["applied_at"]))
    out["cas_apply_delay_s"] = dict(
        n=len(delays), p50=_quantile(delays, 0.5), p95=_quantile(delays, 0.95),
        max=delays[-1], not_applied=sum(1 for e in episodes for a in e.get("actions") or ()
                                        if not _finite(a["applied_at"])),
        retried=sum(1 for e in episodes for a in e.get("actions") or () if a["attempts"] > 1),
        scope="applied_at - planned slot time; an outcome after the cut, never an input") \
        if delays else None
    out["truth"] = {}
    for h in HORIZONS:
        width = [o["truth"][h][1] - o["truth"][h][0] for o in rows if o["reserved"] > 0]
        share = [w / o["reserved"] for w, o in zip(width, [o for o in rows if o["reserved"] > 0])]
        ambiguous = sum(o["labels"][(rid, h)] is None for o, rid in marks)
        out["truth"][str(h)] = dict(
            exact_origins=sum(w <= EPS for w in width), interval_origins=sum(w > EPS for w in width),
            mean_width_share=statistics.fmean(share) if share else None,
            interval_censored_mark_labels=ambiguous)
    params = fit(rows, sensitivity=True)
    out["fit"] = {}
    for h in HORIZONS:
        low, high = params["label_bounds"][h]
        gaps = [abs(_logit_predict(high, mark_features(o, rid, h))
                    - _logit_predict(low, mark_features(o, rid, h))) for o, rid in marks]
        out["fit"][str(h)] = dict(
            label_counts=params["label_counts"][h],
            convergence={name: {k: v for k, v in model.items()
                                if k not in ("beta", "mean", "scale")}
                         for name, model in (("midpoint", params["logistic"][h]),
                                             ("ambiguous_as_0", low), ("ambiguous_as_1", high))},
            in_sample_label_sensitivity_mean_abs_probability=statistics.fmean(gaps),
            in_sample_label_sensitivity_max_abs_probability=max(gaps))
    out["fit_scope"] = "Train in-sample diagnostics only; no prediction error is reported"
    return out


# ============================================================================
# Short-step JOINT serving transition candidate (nv3-opus-joint-transition-v1).
# The R3 marginal original-cohort release model above is kept unchanged as a
# diagnostic; it is NOT this joint transition.
# ============================================================================

JOINT_VERSION = "nv3-opus-joint-transition-v1"
STEP_S = 0.5                 # declared: TTFT SLO scale; median CAS 0.037s; snapshots ~0.15s
HISTORY_STEPS = 4            # 2s receipt history; E2E P95 1.25-3.24s in Train block 181001
TTFT_SLO_S, TPOT_SLO_S = 0.5, 0.05
ROLLOUT_STEPS, ROLLOUT_EVERY, ROLLOUT_REPORT = 10, 4, (2, 6, 10)
SCENARIOS, SCENARIO_SEED, BAND = 20, 20261031, (0.1, 0.9)
RIDGE_L2 = 1e-3              # predeclared on standardized features; never searched
SUPPORT_MIN = 3
CLIENT_KINDS = ("offers", "admitted", "rejected", "good", "ttft_miss", "tpot_miss")
TARGETS = ("released_cost", "born_cost", "released_n", "born_n") + CLIENT_KINDS
HIST = ("offers", "rejected", "good", "ttft_miss", "released_cost", "born_cost")
GATEWAY_FEATURES = ("reserved", "live", "budget", "headroom", "next_plan_budget", "unstarted",
                    "live_prompt_k", "live_max_h") + tuple("hist_" + h for h in HIST)
NATIVE_FEATURES = ("running", "waiting", "kv", "decode_batch", "prefill_k", "native_unknown_frac")
ROLLOUT_SUMS = ("offers", "rejected", "good", "ttft_miss")
REQUEST_ID = re.compile(r"[0-9a-f]{32}")


def _client_events(episode):
    """Fence client rows (same clock, exact IDs, complete offered set) and turn them
    into receipt-time event lists. TTFT miss is knowable at scheduled+SLO when no first
    content has been received; TPOT miss only at the natural terminal receipt."""
    rows, seen = episode["client_rows"], {}
    events = {k: [] for k in CLIENT_KINDS}
    for r in rows:
        rid = r.get("request_id")
        if (r.get("clock_domain") != episode["clock_domain"] or not isinstance(rid, str)
                or not REQUEST_ID.fullmatch(rid) or rid in seen
                or not _finite(r.get("scheduled_at")) or not _finite(r.get("sent_at"))
                or r["sent_at"] < r["scheduled_at"] - EPS):
            raise ValueError("client_row_identity_or_clock")
        rejected = r.get("admission_rejection") is True
        first, terminal = r.get("first_content_at"), r.get("terminal_at")
        if rejected and (r.get("status") != "rejected" or not _finite(terminal)):
            raise ValueError("client_row_rejection")
        seen[rid] = dict(rejected=rejected, sent=r["sent_at"], good_at=None,
                         scheduled=r["scheduled_at"], first=first, terminal=terminal)
        events["offers"].append(r["sent_at"])
        if rejected:
            events["rejected"].append(terminal)
            continue
        events["admitted"].append(r["sent_at"])
        deadline = r["scheduled_at"] + TTFT_SLO_S
        if first is None or first > deadline:
            events["ttft_miss"].append(deadline)
        if r.get("status") == "complete" and r.get("finish_reason") == "stop":
            n = (r.get("usage") or {}).get("completion_tokens")
            if (type(n) is not int or n < 1 or not _finite(first) or not _finite(terminal)
                    or not r["sent_at"] <= first <= terminal):
                raise ValueError("client_row_terminal")
            tpot = (terminal - first) / (n - 1) if n > 1 else 0.0
            if first - r["scheduled_at"] <= TTFT_SLO_S:
                events["good" if tpot <= TPOT_SLO_S else "tpot_miss"].append(terminal)
                if tpot <= TPOT_SLO_S:
                    seen[rid]["good_at"] = terminal
    if episode.get("expected_ids") is not None and set(seen) != set(episode["expected_ids"]):
        raise ValueError("client_rows_incomplete")
    return {k: sorted(v) for k, v in events.items()}, seen


def _count(times, a, b):
    return bisect.bisect_right(times, b + EPS) - bisect.bisect_right(times, a + EPS)


def _plan_at(points, t, fallback):
    value = fallback
    for at, budget in points or ():
        if at <= t + EPS:
            value = budget
    return float(value)


def joint_steps(episode, with_rows=False):
    """One record per short step (t_k, t_k+STEP_S] on a fixed grid from the episode start.

    Stock-flow (exact on the cut snapshots' original IDs):
      R_{k+1} = R_k - released_cost_k + born_cost_k,  n_{k+1} = n_k - released_n_k + born_n_k
    Client flows by receipt time: offers_k = admitted_k + rejected-by-send_k; natural
    terminals split into good / TTFT-ok-TPOT-miss; TTFT misses at their deadline.
    Features use only receipts <= t_k; labels are the factual flows in the step."""
    events, rows = _client_events(episode)
    start = episode["start"]
    end = start + episode["duration_s"]
    grid = dict(episode, origin_grid_s=STEP_S, origin_grid_start=start)
    origins, parsed, _ = build_origins(grid)
    plan = _cap_plan(grid)
    cut = {o["grid_index"]: o for o in origins}
    flows, ever_released = {}, set()
    for k in sorted(cut):
        if k + 1 not in cut:
            continue
        a, b = cut[k], cut[k + 1]
        released = [r for r in a["cohort"] if r not in b["cohort"]]
        born = [r for r in b["cohort"] if r not in a["cohort"]]
        for rid, limit in [(r, a["sampled_at"]) for r in released] + \
                          [(r, b["sampled_at"]) for r in born]:
            row = rows.get(rid)
            if row is None or row["rejected"] or row["sent"] > limit + EPS:
                raise ValueError("snapshot_client_inconsistent")
        if any(r in ever_released for r in born):
            raise ValueError("mark_reappeared")
        ever_released.update(released)
        flows[k] = dict(released_cost=math.fsum(a["cohort"][r]["cost"] for r in released),
                        born_cost=math.fsum(b["cohort"][r]["cost"] for r in born),
                        released_n=float(len(released)), born_n=float(len(born)))
    steps = []
    for k, o in sorted(cut.items()):
        t0 = o["t0"]
        marks = list(o["cohort"].values())
        native = parsed[o["index"]][1]["native"]
        hist_from = t0 - HISTORY_STEPS * STEP_S
        prior = [flows[j] for j in range(k - HISTORY_STEPS, k) if j in flows]
        hist_steps = [dict({c: float(_count(events[c], t0 - (i + 1) * STEP_S, t0 - i * STEP_S))
                            for c in CLIENT_KINDS},
                           **{f: flows.get(k - 1 - i, {}).get(f, 0.0) for f in TARGETS[:4]})
                      for i in reversed(range(HISTORY_STEPS))]
        gateway = dict(
            reserved=o["reserved"], live=float(len(marks)), budget=float(o["budget"]),
            headroom=o["budget"] - o["reserved"],
            next_plan_budget=_plan_at(plan, t0 + STEP_S, o["budget"]),
            unstarted=float(sum(m.get("first_at") is None for m in marks)),
            live_prompt_k=statistics.fmean(m["prompt_tokens"] for m in marks) / 1000 if marks else 0.0,
            live_max_h=statistics.fmean(m["max_tokens"] for m in marks) / 100 if marks else 0.0,
            **{"hist_" + h: float(_count(events[h], hist_from, t0)) for h in HIST[:4]},
            hist_released_cost=math.fsum(f["released_cost"] for f in prior),
            hist_born_cost=math.fsum(f["born_cost"] for f in prior))
        unknown = math.fsum(m["cost"] for r, m in o["cohort"].items() if r not in o["joined"])
        native_x = dict(running=float(native["running"]), waiting=float(native["waiting"]),
                        kv=float(native["kv_cache_usage"]), decode_batch=float(o["decode_batch"]),
                        prefill_k=o["prefill_k"],
                        native_unknown_frac=unknown / o["reserved"] if o["reserved"] else 0.0)
        labels = None
        if k in flows and t0 + STEP_S <= end + EPS:
            labels = dict(flows[k], **{c: float(_count(events[c], t0, t0 + STEP_S))
                                       for c in CLIENT_KINDS})
        steps.append(dict(episode_id=episode["episode_id"], seed_block=episode["seed_block"],
                          partition=episode["partition"], cell=episode.get("cell"), k=k, t0=t0,
                          outstanding=o["outstanding_actions"], cohort=set(o["cohort"]),
                          joined=o["joined"],
                          hist_steps=hist_steps,
                          gateway=gateway, native=native_x, labels=labels,
                          plan=[_plan_at(plan, t0 + j * STEP_S, o["budget"])
                                for j in range(ROLLOUT_STEPS + 1)]))
    by_k = {s["k"]: s for s in steps}
    for s in steps:
        previous = by_k.get(s["k"] - 1)
        s["previous_labels"] = previous["labels"] if previous else None
    good = sorted((r["good_at"], rid) for rid, r in rows.items() if r["good_at"] is not None)
    if with_rows:
        return steps, good, rows
    return steps, good


def _vector(step, names_native):
    x = [step["gateway"][n] for n in GATEWAY_FEATURES]
    if names_native:
        x += [step["native"][n] for n in NATIVE_FEATURES]
    return x


def fit_ridge(xs, ys, targets=TARGETS):
    """Closed-form ridge per target on standardized features (unpenalized intercept)."""
    k, n = len(xs[0]), len(xs)
    mean = [statistics.fmean(x[j] for x in xs) for j in range(k)]
    scale = [statistics.pstdev([x[j] for x in xs]) or 1.0 for j in range(k)]
    zs = [[1.0] + [(x[j] - mean[j]) / scale[j] for j in range(k)] for x in xs]
    gram = [[math.fsum(z[i] * z[j] for z in zs) / n for j in range(k + 1)] for i in range(k + 1)]
    for i in range(1, k + 1):
        gram[i][i] += RIDGE_L2
    gram[0][0] += 1e-12
    betas = {}
    for t in targets:
        rhs = [math.fsum(z[i] * y[t] for z, y in zip(zs, ys)) / n for i in range(k + 1)]
        betas[t] = _solve([row[:] for row in gram], rhs)
    return dict(mean=mean, scale=scale, betas=betas)


def _clip(y, reserved, live):
    out = {t: max(0.0, v) for t, v in y.items()}
    out["released_cost"] = min(out["released_cost"], reserved)
    out["released_n"] = min(out["released_n"], live)
    return out


def ridge_predict(model, x):
    z = [1.0] + [(v - m) / s for v, m, s in zip(x, model["mean"], model["scale"])]
    return {t: math.fsum(b * v for b, v in zip(beta, z)) for t, beta in model["betas"].items()}


def _support_key(step):
    g = step["gateway"]
    return (step["cell"], g["budget"], math.floor(g["headroom"] / 4), min(int(g["live"]) // 8, 8),
            min(int(g["hist_offers"]) // 10, 10))


def joint_support(train):
    """Bounded O(n) support: per-feature ranges plus a coarse joint bin count."""
    ranges = {}
    for name in GATEWAY_FEATURES:
        values = [s["gateway"][name] for s in train]
        ranges[name] = (min(values), max(values))
    for name in NATIVE_FEATURES:
        values = [s["native"][name] for s in train]
        ranges["native_" + name] = (min(values), max(values))
    bins = defaultdict(int)
    for s in train:
        bins[_support_key(s)] += 1
    return dict(ranges=ranges, bins=bins)


def joint_ood(step, support):
    reasons = []
    for name, (lo, hi) in support["ranges"].items():
        value = step["native"][name[7:]] if name.startswith("native_") else step["gateway"][name]
        if not lo - EPS <= value <= hi + EPS:
            reasons.append("range_" + name)
    if support["bins"].get(_support_key(step), 0) < SUPPORT_MIN:
        reasons.append("joint_bin")
    if step["outstanding"]:
        reasons.append("outstanding_action_at_cut")
    return reasons


def _usable(step):
    return step["labels"] is not None and not step["outstanding"]


def _rollout(model, step, residual_runs, rng, horizon, arrivals=None):
    """Free-running gateway-propagable rollout; native features are latent after the cut
    and are not manufactured. Each scenario adds one contiguous Train residual run
    (cross-target and serial correlation kept). Unqualified as MPC risk.

    arrivals=None is v1 (offers recursively predicted from state/plan). Otherwise it is
    a callable (run, offset) -> offered path fixed BEFORE any state/plan propagation
    (v2 exogenous common law, or an explicitly labelled oracle disturbance); the model
    then takes the interval offers as its last input."""
    paths = []
    for _ in range(SCENARIOS):
        run = residual_runs[rng.randrange(len(residual_runs))]
        offset = rng.randrange(len(run) - horizon + 1)
        offered = None if arrivals is None else arrivals(run, offset)
        g = dict(step["gateway"])
        window = list(step["hist_steps"])
        unstarted_share = g["unstarted"] / g["live"] if g["live"] else 0.0
        sums, path = dict.fromkeys(ROLLOUT_SUMS, 0.0), []
        for j in range(horizon):
            if j:
                g["budget"] = step["plan"][j]
            g["next_plan_budget"] = step["plan"][j + 1]
            g["headroom"] = g["budget"] - g["reserved"]
            g["unstarted"] = unstarted_share * g["live"]
            for h in HIST:
                g["hist_" + h] = math.fsum(w[h] for w in window[-HISTORY_STEPS:])
            x = [g[n] for n in GATEWAY_FEATURES] + ([] if offered is None else [offered[j]])
            mean = ridge_predict(model, x)
            y = {t: mean[t] + run[offset + j][t] for t in TARGETS}
            if offered is not None:
                y["offers"] = offered[j]
            y = _clip(y, g["reserved"], g["live"])
            g["reserved"] = max(0.0, g["reserved"] - y["released_cost"] + y["born_cost"])
            g["live"] = max(0.0, g["live"] - y["released_n"] + y["born_n"])
            window.append({h: y[h] for h in HIST})
            for key in ROLLOUT_SUMS:
                sums[key] += y[key]
            path.append(dict(sums, reserved=g["reserved"]))
        paths.append(path)
    return paths


def _history_mean(step):
    return {t: statistics.fmean(h[t] for h in step["hist_steps"]) for t in TARGETS}


def _persistence_path(step, horizon, y):
    g, out, sums = dict(step["gateway"]), [], dict.fromkeys(ROLLOUT_SUMS, 0.0)
    for _ in range(horizon):
        g["reserved"] = max(0.0, g["reserved"] - y["released_cost"] + y["born_cost"])
        for key in ROLLOUT_SUMS:
            sums[key] += y[key]
        out.append(dict(sums, reserved=g["reserved"]))
    return out


def _actual_path(steps_by_k, step, horizon):
    sums, out = dict.fromkeys(ROLLOUT_SUMS, 0.0), []
    for j in range(horizon):
        s = steps_by_k.get(step["k"] + j)
        nxt = steps_by_k.get(step["k"] + j + 1)
        if s is None or s["labels"] is None or nxt is None:
            return None
        for key in ROLLOUT_SUMS:
            sums[key] += s["labels"][key]
        out.append(dict(sums, reserved=nxt["gateway"]["reserved"]))
    return out


def _block_mean(per_episode):
    return statistics.fmean(statistics.fmean(v) for v in per_episode.values()) \
        if per_episode else None


def joint_crossfit(episodes, receipt=None, exogenous=False, holdouts=None):
    """Leave-one-seed-block-out cross-fit on Train episodes only (descriptive).

    exogenous=True adds the v2 candidate side by side on the same origins/abstentions;
    v1 outputs and their random stream are unchanged. holdouts restricts which blocks
    are held out (e.g. a fresh Development/Train block fit on all other blocks)."""
    if any(e["partition"] != "train" for e in episodes):
        raise ValueError("joint_requires_train_only")
    data = {e["episode_id"]: (e, *joint_steps(e)) for e in episodes}
    blocks = sorted({e["seed_block"] for e in episodes})
    if len(blocks) < 2:
        raise ValueError("crossfit_needs_two_blocks")
    out = dict(schema=JOINT_VERSION, receipt=receipt, step_s=STEP_S, history_steps=HISTORY_STEPS,
               targets=list(TARGETS), folds={}, train_only=True, calibration_result=False,
               mpc_result=False, statistical_guarantee=False,
               scenario_status="unqualified: contiguous Train residual bootstrap, not state-"
                               "conditional; no coverage or MPC-risk claim",
               marginal_release_model_is_joint=False)
    out["cohort_vs_future_good"] = _cohort_decomposition(data)
    if exogenous:
        out.update(EXO_CONTRACT)
    for held in (blocks if holdouts is None else holdouts):
        train = [s for e, steps, _ in data.values() if e["seed_block"] != held
                 for s in steps if _usable(s)]
        test_eps = [(e, steps) for e, steps, _ in data.values() if e["seed_block"] == held]
        if any(s["seed_block"] == held for s in train):
            raise ValueError("crossfit_leakage")
        models = {name: fit_ridge([_vector(s, native) for s in train],
                                  [s["labels"] for s in train])
                  for name, native in (("gateway_ridge", False), ("batch_ridge", True))}
        means = {t: statistics.fmean(s["labels"][t] for s in train) for t in TARGETS}
        support = joint_support(train)
        runs = []
        for e, steps, _ in data.values():
            if e["seed_block"] == held:
                continue
            run = []
            for s in steps:
                if _usable(s):
                    pred = ridge_predict(models["gateway_ridge"], _vector(s, False))
                    run.append({t: s["labels"][t] - pred[t] for t in TARGETS})
                elif len(run) >= ROLLOUT_STEPS:
                    runs.append(run)
                    run = []
                else:
                    run = []
            if len(run) >= ROLLOUT_STEPS:
                runs.append(run)
        rng = random.Random(SCENARIO_SEED + held)
        if exogenous:
            exo_model = fit_ridge([_exo_vector(s, s["labels"]["offers"]) for s in train],
                                  [s["labels"] for s in train])
            exo_runs = _exo_residual_runs(exo_model, data, held)
            exo_rng = random.Random(SCENARIO_SEED + held)
            oracle_one = defaultdict(lambda: defaultdict(list))
            oracle_free = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
        one = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
        free = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
        band = defaultdict(lambda: defaultdict(list))
        counts = defaultdict(int)
        for e, steps in test_eps:
            by_k = {s["k"]: s for s in steps}
            for s in steps:
                if s["labels"] is None:
                    continue
                reasons = joint_ood(s, support)
                if reasons:
                    counts["one_step_abstained"] += 1
                    for r in reasons:
                        counts["ood_" + r] += 1
                    continue
                if s["previous_labels"] is None:
                    counts["one_step_no_persistence"] += 1
                    continue
                counts["one_step_scored"] += 1
                preds = dict(train_mean=means, persistence=s["previous_labels"],
                             history_mean=_history_mean(s),
                             **{n: _clip(ridge_predict(m, _vector(s, n == "batch_ridge")),
                                         s["gateway"]["reserved"], s["gateway"]["live"])
                                for n, m in models.items()})
                if exogenous:
                    preds["exo_ridge"] = _exo_one_step(exo_model, s, arrival_law(s))
                    oracle = _exo_one_step(exo_model, s, s["labels"]["offers"])
                    for t in TARGETS:
                        oracle_one[t][e["episode_id"]].append(abs(oracle[t] - s["labels"][t]))
                for name, pred in preds.items():
                    for t in TARGETS:
                        one[name][t][e["episode_id"]].append(abs(pred[t] - s["labels"][t]))
                if s["k"] % ROLLOUT_EVERY or s["previous_labels"] is None:
                    continue
                actual = _actual_path(by_k, s, ROLLOUT_STEPS)
                if actual is None or not runs:
                    counts["rollout_unavailable"] += 1
                    continue
                counts["rollout_origins"] += 1
                paths = _rollout(models["gateway_ridge"], s, runs, rng, ROLLOUT_STEPS)
                exo_paths = oracle_paths = None
                if exogenous:
                    law = arrival_law(s)
                    exo_paths = _rollout(exo_model, s, exo_runs, exo_rng, ROLLOUT_STEPS,
                                         arrivals=lambda r, o: [max(0.0, law + r[o + j]["offers"])
                                                                for j in range(ROLLOUT_STEPS)])
                    realized = [by_k[s["k"] + j]["labels"]["offers"] for j in range(ROLLOUT_STEPS)]
                    oracle_paths = _rollout(exo_model, s, exo_runs, random.Random(s["k"]),
                                            ROLLOUT_STEPS, arrivals=lambda r, o: realized)
                fixed = {name: _persistence_path(s, ROLLOUT_STEPS, y) for name, y in
                         (("persistence", s["previous_labels"]), ("history_mean", _history_mean(s)),
                          ("train_mean", means))}
                for h in ROLLOUT_REPORT:
                    for key in ROLLOUT_SUMS + ("reserved",):
                        values = sorted(p[h - 1][key] for p in paths)
                        median = _quantile(values, 0.5)
                        truth = actual[h - 1][key]
                        free[f"{h * STEP_S:g}s"][key + "|joint_median"][e["episode_id"]].append(
                            abs(median - truth))
                        if key == "reserved":
                            free[f"{h * STEP_S:g}s"]["reserved|hold"][e["episode_id"]].append(
                                abs(s["gateway"]["reserved"] - truth))
                        for name, path in fixed.items():
                            free[f"{h * STEP_S:g}s"][key + "|" + name][e["episode_id"]].append(
                                abs(path[h - 1][key] - truth))
                        lo, hi = _quantile(values, BAND[0]), _quantile(values, BAND[1])
                        band[f"{h * STEP_S:g}s"][key].append(lo - EPS <= truth <= hi + EPS)
                        if exogenous:
                            hs = f"{h * STEP_S:g}s"
                            ev = sorted(p[h - 1][key] for p in exo_paths)
                            free[hs][key + "|exo_median"][e["episode_id"]].append(
                                abs(_quantile(ev, 0.5) - truth))
                            band[hs][key + "|exo"].append(
                                _quantile(ev, BAND[0]) - EPS <= truth <= _quantile(ev, BAND[1]) + EPS)
                            ov = sorted(p[h - 1][key] for p in oracle_paths)
                            oracle_free[hs][key][e["episode_id"]].append(
                                abs(_quantile(ov, 0.5) - truth))
        out["folds"][str(held)] = dict(
            train_blocks=[b for b in blocks if b != held], train_steps=len(train),
            residual_runs=len(runs), counts=dict(counts),
            one_step_mae={n: {t: _block_mean(v) for t, v in per.items()} for n, per in one.items()},
            free_running_mae={h: {k: _block_mean(v) for k, v in per.items()}
                              for h, per in free.items()},
            scenario_band_inclusion={h: {k: statistics.fmean(v) for k, v in per.items()}
                                     for h, per in band.items()})
        if exogenous:
            out["folds"][str(held)].update(
                exo_residual_runs=len(exo_runs),
                oracle_disturbance_diagnostic=dict(
                    status=ORACLE_STATUS,
                    one_step_mae={t: _block_mean(v) for t, v in oracle_one.items()},
                    free_running_mae={h: {k: _block_mean(v) for k, v in per.items()}
                                      for h, per in oracle_free.items()}))
    return out


EXO_VERSION = "nv3-opus-exogenous-arrival-v2"
ORACLE_STATUS = ("ORACLE DISTURBANCE: realized future interval offers fed as input; "
                 "not a forecast, not admissible for comparison or deployment")
EXO_CONTRACT = dict(
    exogenous_schema=EXO_VERSION,
    arrival_contract=("future offered flow is a common law of pre-cut all-offered receipts "
                      "(mean of last HISTORY_STEPS steps), independent of the candidate "
                      "plan/cap and of post-cut state; conditional f is fit on realized "
                      "interval offers as a disturbance input, which forecasts never see"),
    exo_scenario_status=("unqualified: arrival residual and conditional residuals drawn "
                         "jointly from one contiguous Train run; not state-conditional"))


def arrival_law(step):
    """Common exogenous offered-flow law per 0.5s step from genuinely pre-cut all-offered
    receipts. Deliberately takes only the receipt history: no plan, cap or state."""
    return statistics.fmean(h["offers"] for h in step["hist_steps"])


def _exo_vector(step, offers):
    return _vector(step, False) + [float(offers)]


def _exo_one_step(model, step, offers):
    y = ridge_predict(model, _exo_vector(step, offers))
    y["offers"] = float(offers)
    return _clip(y, step["gateway"]["reserved"], step["gateway"]["live"])


def _exo_residual_runs(model, data, held):
    """Contiguous Train runs of (offers - arrival law, label - f(x, realized offers))."""
    runs = []
    for e, steps, _ in data.values():
        if e["seed_block"] == held:
            continue
        run = []
        for s in steps:
            if _usable(s):
                pred = ridge_predict(model, _exo_vector(s, s["labels"]["offers"]))
                res = {t: s["labels"][t] - pred[t] for t in TARGETS}
                res["offers"] = s["labels"]["offers"] - arrival_law(s)
                run.append(res)
            elif len(run) >= ROLLOUT_STEPS:
                runs.append(run)
                run = []
            else:
                run = []
        if len(run) >= ROLLOUT_STEPS:
            runs.append(run)
    return runs


DEVELOPMENT_CELLS = 5
DEVELOPMENT_ARMS = 2


def exogenous_report(episodes, receipt=None, train_blocks=(181001, 181002),
                     development_block=181003):
    """R5: v2 vs v1 cross-fit on the declared Train blocks, plus a fresh-block diagnostic
    fit on those blocks only if the fresh block is complete (cells x arms)."""
    train = [e for e in episodes if e["seed_block"] in train_blocks]
    out = dict(cross_fit=joint_crossfit(train, receipt, exogenous=True))
    fresh = [e for e in episodes if e["seed_block"] == development_block]
    if len(fresh) != DEVELOPMENT_CELLS * DEVELOPMENT_ARMS or \
            len({(e["cell"], e["episode_id"]) for e in fresh}) != len(fresh) or \
            len({e["cell"] for e in fresh}) != DEVELOPMENT_CELLS:
        out["development"] = dict(block=development_block, status="not_run: incomplete",
                                  episodes=sorted(e["episode_id"] for e in fresh))
    else:
        out["development"] = joint_crossfit(train + fresh, receipt, exogenous=True,
                                            holdouts=[development_block])
        out["development"]["status"] = "fresh Train/Development diagnostic, fit on train_blocks only"
    return out


def _cohort_decomposition(data):
    """Good terminals in (t, t+h] from the cut's original IDs vs requests not yet live."""
    out = {}
    for h in (1.0, 3.0, 5.0):
        cohort = future = 0
        for e, steps, good_ids in data.values():
            times = [t for t, _ in good_ids]
            end = e["start"] + e["duration_s"]
            for s in steps:
                if s["k"] % ROLLOUT_EVERY or s["t0"] + h > end + EPS:
                    continue
                lo = bisect.bisect_right(times, s["t0"] + EPS)
                hi = bisect.bisect_right(times, s["t0"] + h + EPS)
                for _, rid in good_ids[lo:hi]:
                    if rid in s["cohort"]:
                        cohort += 1
                    else:
                        future += 1
        out[f"{h:g}s"] = dict(from_cut_cohort=cohort, from_later_births=future,
                              later_share=future / (cohort + future) if cohort + future else None)
    return out


# ---------------------------------------------------------------------------
# R6: ID-level progress hybrid (nv3-opus-progress-hybrid-v3) and the diagnostic that
# separates missing progress/service state (live cohort) from future-birth error.
# ---------------------------------------------------------------------------

PROGRESS_VERSION = "nv3-opus-progress-hybrid-v3"
PROGRESS_HORIZONS = (1.0, 3.0, 5.0)
OUTPUT_EDGES = (1, 16, 64, 128)  # declared native output_tokens progress bins
RUNNING_BIN, RUNNING_CAP = 8, 4  # native running // 8, capped (batch competition)
HAZARD_MIN = 20                  # declared back-off threshold, not searched
DETERMINISTIC = ("client_terminal", "ttft_impossible")


def id_progress_state(step, rid, row):
    """Pre-cut state of one live original ID from receipts <= t0 only.

    Returns a deterministic status when good in the future is impossible (exact
    lifecycle/SLO logic), else a list of hazard keys from fine to coarse. Native
    progress is only the joined output_tokens; prefill progress (computed_tokens) and
    the ~17-23% accepted-not-native-visible IDs are explicit 'unknown' states."""
    t0 = step["t0"]
    if row["terminal"] is not None and row["terminal"] <= t0 + EPS:
        return "client_terminal"
    first = row["first"] if row["first"] is not None and row["first"] <= t0 + EPS else None
    if (first is None and t0 - row["scheduled"] > TTFT_SLO_S + EPS) or \
            (first is not None and first - row["scheduled"] > TTFT_SLO_S + EPS):
        return "ttft_impossible"
    visible = rid in step["joined"]
    out = bisect.bisect_right(OUTPUT_EDGES, step["joined"][rid]) if visible else -1
    run = min(int(step["native"]["running"]) // RUNNING_BIN, RUNNING_CAP)
    batch = (run, step["native"]["waiting"] > 0)
    phase = first is not None
    cell = step["cell"]
    return [(cell, visible, phase, out, batch), (cell, visible, phase, out),
            (cell, visible, phase), ()]


def _horizon_good(step, good_times, good_ids, h):
    lo = bisect.bisect_right(good_times, step["t0"] + EPS)
    hi = bisect.bisect_right(good_times, step["t0"] + h + EPS)
    ids = {rid for _, rid in good_ids[lo:hi]}
    cohort = sum(1 for rid in ids if rid in step["cohort"])
    return ids, cohort, len(ids) - cohort


def fit_progress_hazard(records):
    """records: (h, keys or status, became_good). Empirical frequency table per key."""
    table, violations = defaultdict(lambda: [0, 0]), 0
    for h, keys, good in records:
        if isinstance(keys, str):
            violations += good
            continue
        for key in keys:
            cell = table[(h,) + key]
            cell[0] += 1
            cell[1] += good
    if violations:
        raise ValueError("deterministic_state_became_good")
    return dict(table)


def progress_probability(table, h, keys):
    if isinstance(keys, str):
        return 0.0, keys
    for level, key in enumerate(keys):
        n, g = table.get((h,) + key, (0, 0))
        if n >= HAZARD_MIN or (level == len(keys) - 1 and n):
            return g / n, f"level{level}"
    raise ValueError("progress_hazard_unsupported")


def _progress_rows(entries):
    """Per usable step: horizon labels split into live-cohort and later-birth good."""
    out = []
    for e, steps, good_ids, rows in entries:
        times = [t for t, _ in good_ids]
        end = e["start"] + e["duration_s"]
        for s in steps:
            if not _usable(s):
                continue
            labels = {}
            for h in PROGRESS_HORIZONS:
                if s["t0"] + h > end + EPS:
                    break
                labels[h] = _horizon_good(s, times, good_ids, h)
            out.append((e, s, rows, labels))
    return out


def progress_diagnostic(episodes, receipt=None, train_blocks=(181001, 181002),
                        development_block=181003):
    """Fit on train_blocks only; descriptive on the (already used) development block."""
    if any(e["partition"] != "train" for e in episodes):
        raise ValueError("progress_requires_train_only")
    fresh = [e for e in episodes if e["seed_block"] == development_block]
    if len(fresh) != DEVELOPMENT_CELLS * DEVELOPMENT_ARMS or \
            len({e["cell"] for e in fresh}) != DEVELOPMENT_CELLS:
        raise ValueError("development_block_incomplete")
    train_eps = [e for e in episodes if e["seed_block"] in train_blocks]
    if {e["seed_block"] for e in train_eps} != set(train_blocks):
        raise ValueError("train_blocks_missing")
    train_entries = [(e, *joint_steps(e, with_rows=True)) for e in train_eps]
    train = _progress_rows(train_entries)
    train_k = {e["episode_id"]: {s["k"]: s for s in steps} for e, steps, _, _ in train_entries}
    dev_entries = [(e, *joint_steps(e, with_rows=True)) for e in fresh]
    dev = _progress_rows(dev_entries)

    records = [(h, id_progress_state(s, rid, rows[rid]), int(rid in labels[h][0]))
               for _, s, rows, labels in train for h in labels for rid in s["cohort"]]
    table = fit_progress_hazard(records)
    names = [f"{part}_{h:g}" for h in PROGRESS_HORIZONS for part in ("cohort", "birth")]
    full = [(s, labels) for _, s, _, labels in train if len(labels) == len(PROGRESS_HORIZONS)]
    ys = [{f"{p}_{h:g}": float(labels[h][1 if p == "cohort" else 2])
           for h in PROGRESS_HORIZONS for p in ("cohort", "birth")} for _, labels in full]
    aggregate = fit_ridge([_vector(s, False) for s, _ in full], ys, names)
    birth = fit_ridge([_exo_vector(s, arrival_law(s)) for s, _ in full], ys, names)
    support = joint_support([s for _, s, _, _ in train])
    # ORACLE diagnostic only: birth model conditioned on the REALIZED mean offered rate
    # over (t0, t0+h]; fit and evaluated with realized arrivals, never a forecast.
    oracle_birth = {}
    for h in PROGRESS_HORIZONS:
        n = int(round(h / STEP_S))
        xs, ys_h = [], []
        for e, s, _, labels in train:
            path = _actual_path(train_k[e["episode_id"]], s, ROLLOUT_STEPS)
            if path is None or h not in labels:
                continue
            xs.append(_exo_vector(s, path[n - 1]["offers"] / n))
            ys_h.append({"birth": float(labels[h][2])})
        oracle_birth[h] = fit_ridge(xs, ys_h, ("birth",))

    err = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    counts = defaultdict(int)
    by_episode = {e["episode_id"]: {s["k"]: s for s in steps} for e, steps, _, _ in dev_entries}
    for e, s, rows, labels in dev:
        # same origin rule as the R4/R5 rollout origins
        if (s["k"] % ROLLOUT_EVERY or s["previous_labels"] is None or joint_ood(s, support)
                or len(labels) != len(PROGRESS_HORIZONS)):
            continue
        actual = _actual_path(by_episode[e["episode_id"]], s, ROLLOUT_STEPS)
        if actual is None:
            counts["actual_path_unavailable"] += 1
            continue
        for h in PROGRESS_HORIZONS:
            if len(labels[h][0]) != actual[int(round(h / STEP_S)) - 1]["good"]:
                raise ValueError("good_id_count_mismatch")
        counts["origins"] += 1
        agg = ridge_predict(aggregate, _vector(s, False))
        bir = ridge_predict(birth, _exo_vector(s, arrival_law(s)))
        hist_rate = statistics.fmean(x["good"] for x in s["hist_steps"])
        for h in PROGRESS_HORIZONS:
            ids, cohort, born = labels[h]
            hs = f"{h:g}s"
            terms = []
            for rid in s["cohort"]:
                p, level = progress_probability(table, h, id_progress_state(s, rid, rows[rid]))
                terms.append(p)
                counts[f"{hs}_ids_{level}"] += 1
            prog = math.fsum(terms)  # exact, so independent of set/hash iteration order
            live_possible = sum(not isinstance(id_progress_state(s, r, rows[r]), str)
                                for r in s["cohort"])
            if not 0 <= prog <= live_possible + EPS:
                raise ValueError("progress_cohort_exceeds_possible")
            if cohort > live_possible:
                raise ValueError("cohort_good_exceeds_possible")
            a_c = max(0.0, min(agg[f"cohort_{h:g}"], float(len(s["cohort"]))))
            b_b = max(0.0, bir[f"birth_{h:g}"])
            total = cohort + born
            preds = dict(history_mean=hist_rate * h / STEP_S, aggregate_hybrid=a_c + b_b,
                         progress_hybrid=prog + b_b)
            n = int(round(h / STEP_S))
            b_o = max(0.0, ridge_predict(oracle_birth[h],
                                         _exo_vector(s, actual[n - 1]["offers"] / n))["birth"])
            diag = dict(oracle_birth_aggregate=a_c + born, oracle_birth_progress=prog + born,
                        oracle_cohort=cohort + b_b, oracle_arrivals_progress=prog + b_o)
            err[hs]["ORACLE_part|birth_given_realized_arrivals"][e["episode_id"]].append(
                (b_o - born, born))
            parts = dict(cohort_aggregate=(a_c, cohort), cohort_progress=(prog, cohort),
                         birth_reduced_form=(b_b, born))
            for name, value in preds.items():
                err[hs]["total|" + name][e["episode_id"]].append((value - total, total))
            for name, value in diag.items():
                err[hs]["ORACLE|" + name][e["episode_id"]].append((value - total, total))
            for name, (value, truth) in parts.items():
                err[hs]["part|" + name][e["episode_id"]].append((value - truth, truth))
    summary = {hs: {name: dict(mae=_block_mean({k: [abs(d) for d, _ in v] for k, v in per.items()}),
                               bias=_block_mean({k: [d for d, _ in v] for k, v in per.items()}),
                               mean_truth=_block_mean({k: [t for _, t in v]
                                                       for k, v in per.items()}))
                    for name, per in by.items()} for hs, by in err.items()}
    return dict(schema=PROGRESS_VERSION, receipt=receipt, train_blocks=list(train_blocks),
                development_block=development_block,
                development_status="already-used Train development block; descriptive only",
                train_steps=len(train), hazard_cells=len(table), counts=dict(counts),
                summary=summary,
                oracle_status=("ORACLE rows feed realized future cohort or birth good; "
                               "decomposition diagnostics only, not forecasts"),
                birth_model_status=("reduced-form ridge on pre-cut Gateway state + common "
                                    "exogenous arrival law; mixes admission and service, so it "
                                    "is NOT an admissible GPU service law"),
                calibration_result=False, mpc_result=False, statistical_guarantee=False)


# ---------------------------------------------------------------------------
# R7: paired common-tape test of a direct full-plan response F_N(x, U, w)
# ---------------------------------------------------------------------------

PLAN_VERSION = "nv3-opus-plan-response-v4"
PLAN_VARIANTS = ("blind", "r6_next", "masked_plan", "full_plan")
PLAN_TARGETS = ("good", "rejected", "offers")
PLAN_SLOT_S = 1.0


def plan_inputs(step, h, variant):
    """Pre-cut state + common arrival law + an explicit PLANNED budget encoding.

    `blind` keeps only the in-force budget/headroom observed at the cut; `r6_next` adds the
    single next-step planned budget (R6 reduced form); `full_plan` adds the exact planned
    budget on each 0.5s sub-step of (t0, t0+5]; `masked_plan` keeps only sub-steps inside
    (t0, t0+h]. Planned schedule = intention-to-treat; actual ACK timing is not an input."""
    x = _exo_vector(step, arrival_law(step))
    if variant == "r6_next":
        return x
    del x[GATEWAY_FEATURES.index("next_plan_budget")]
    if variant == "blind":
        return x
    n = ROLLOUT_STEPS if variant == "full_plan" else int(round(h / STEP_S))
    return x + [float(u) for u in step["plan"][:n]]


def _schedule_design(episodes):
    """Randomization/compliance facts of the actual planned schedules and CAS receipts."""
    patterns, repeats, slots, lags, retries, failed = Counter(), 0, 0, [], 0, 0
    for e in episodes:
        budgets = [b for _, b in e["cap_plan"]]
        steps = [round(b - a, 6) for (a, _), (b, _) in zip(e["cap_plan"], e["cap_plan"][1:])]
        if any(abs(d - PLAN_SLOT_S) > 1e-6 for d in steps):
            raise ValueError("schedule_slot_not_1s")
        slots += len(budgets) - 1
        repeats += sum(a == b for a, b in zip(budgets, budgets[1:]))
        for i in range(len(budgets) - 4):
            patterns[tuple(budgets[i:i + 5])] += 1
        for a in e["actions"]:
            if a["planned_at"] is None:
                continue
            retries += a["attempts"] > 1
            if a["applied_at"] is None:
                failed += 1
            else:
                lags.append(a["ack_received_at"] - a["planned_at"])
    lags.sort()
    q = (lambda p: lags[min(len(lags) - 1, int(p * len(lags)))]) if lags else (lambda p: None)
    return dict(slot_s=PLAN_SLOT_S, repeat_probability=repeats / slots if slots else None,
                five_slot_patterns=len(patterns),
                five_slot_min_windows=min(patterns.values()) if patterns else 0,
                constant16_windows=patterns[(16,) * 5], constant32_windows=patterns[(32,) * 5],
                ack_lag_s=dict(n=len(lags), p50=q(0.5), p99=q(0.99),
                               max=lags[-1] if lags else None),
                retried_actions=retries, unapplied_actions=failed)


def plan_response_diagnostic(episodes, receipt=None, train_blocks=(181001, 181002),
                             development_block=181003):
    """Fit on Train blocks only; paired-arm description on the already-used block.

    Paired arms share the offered tape and run complementary randomized 1s schedules, so
    the realized paired difference Y_A - Y_B removes the common arrival draw. A plan
    response that is useful for ranking must predict that difference from each arm's own
    pre-cut state and its planned future budgets. Offers are a placebo target: a valid
    exogenous law must predict ~zero paired offer difference from the plan."""
    if any(e["partition"] != "train" for e in episodes):
        raise ValueError("plan_requires_train_only")
    fresh = [e for e in episodes if e["seed_block"] == development_block]
    if len(fresh) != DEVELOPMENT_CELLS * DEVELOPMENT_ARMS or \
            len({e["cell"] for e in fresh}) != DEVELOPMENT_CELLS:
        raise ValueError("development_block_incomplete")
    train_eps = [e for e in episodes if e["seed_block"] in train_blocks]
    if {e["seed_block"] for e in train_eps} != set(train_blocks):
        raise ValueError("train_blocks_missing")
    for (blk, cell), arms in _pairs(fresh).items():
        if len(arms) != 2:
            raise ValueError("development_pair_incomplete")
        a, b = ([u for _, u in e["cap_plan"]] for e in arms)
        if len(a) != len(b) or a == b:
            raise ValueError("development_pair_not_randomized_contrast")

    train_entries = [(e, *joint_steps(e, with_rows=True)) for e in train_eps]
    train = _progress_rows(train_entries)
    train_k = {e["episode_id"]: {s["k"]: s for s in steps} for e, steps, _, _ in train_entries}
    records = [(h, id_progress_state(s, rid, rows[rid]), int(rid in labels[h][0]))
               for _, s, rows, labels in train for h in labels for rid in s["cohort"]]
    table = fit_progress_hazard(records)
    support = joint_support([s for _, s, _, _ in train])

    def target_rows(entries_k, rows_):
        out = []
        for e, s, _, labels in rows_:
            if len(labels) != len(PROGRESS_HORIZONS):
                continue
            path = _actual_path(entries_k[e["episode_id"]], s, ROLLOUT_STEPS)
            if path is None:
                continue
            y = {}
            for h in PROGRESS_HORIZONS:
                cum = path[int(round(h / STEP_S)) - 1]
                if len(labels[h][0]) != cum["good"]:
                    raise ValueError("good_id_count_mismatch")
                y.update({f"good_{h:g}": float(labels[h][2]),
                          f"total_good_{h:g}": float(len(labels[h][0])),
                          f"rejected_{h:g}": cum["rejected"], f"offers_{h:g}": cum["offers"]})
            out.append((e, s, y))
        return out

    fit_rows = target_rows(train_k, train)
    models = {(v, h): fit_ridge([plan_inputs(s, h, v) for _, s, _ in fit_rows],
                                [y for _, _, y in fit_rows],
                                [f"{t}_{h:g}" for t in PLAN_TARGETS])
              for v in PLAN_VARIANTS for h in PROGRESS_HORIZONS}

    dev_entries = [(e, *joint_steps(e, with_rows=True)) for e in fresh]
    dev_k = {e["episode_id"]: {s["k"]: s for s in steps} for e, steps, _, _ in dev_entries}
    dev_rows = {e["episode_id"]: rows for e, _, _, rows in dev_entries}
    dev = [(e, s, y) for e, s, y in target_rows(dev_k, _progress_rows(dev_entries))
           if not (s["k"] % ROLLOUT_EVERY or s["previous_labels"] is None
                   or joint_ood(s, support))]
    forecasts, counts = {}, Counter()
    for e, s, y in dev:
        rows = dev_rows[e["episode_id"]]
        counts["origins"] += 1
        counts["planned_ne_inforce_at_cut"] += s["plan"][0] != s["gateway"]["budget"]
        f = {}
        for h in PROGRESS_HORIZONS:
            cohort = math.fsum(progress_probability(table, h, id_progress_state(s, r, rows[r]))[0]
                               for r in s["cohort"])
            for v in PLAN_VARIANTS:
                p = ridge_predict(models[(v, h)], plan_inputs(s, h, v))
                f[(v, "good", h)] = cohort + max(0.0, p[f"good_{h:g}"])
                for t in ("rejected", "offers"):
                    f[(v, t, h)] = max(0.0, p[f"{t}_{h:g}"])
        forecasts[(e["episode_id"], s["k"])] = (e, s, y, f)

    def truth(y, t, h):
        return y[f"total_good_{h:g}"] if t == "good" else y[f"{t}_{h:g}"]

    level = defaultdict(lambda: defaultdict(list))
    for (eid, _), (e, s, y, f) in forecasts.items():
        for (v, t, h), value in f.items():
            level[f"{h:g}s|{t}|{v}"][eid].append(abs(value - truth(y, t, h)))
    paired = defaultdict(lambda: defaultdict(list))
    for (blk, cell), arms in _pairs(fresh).items():
        a, b = (x["episode_id"] for x in arms)
        for (eid, k), (_, sa, ya, fa) in forecasts.items():
            if eid != a or (b, k) not in forecasts:
                continue
            _, sb, yb, fb = forecasts[(b, k)]
            counts["pairs"] += 1
            key = f"{blk}|{cell}"
            for h in PROGRESS_HORIZONS:
                for t in PLAN_TARGETS:
                    d_true = truth(ya, t, h) - truth(yb, t, h)
                    paired[f"{h:g}s|{t}|zero_predictor"][key].append(abs(d_true))
                    for v in PLAN_VARIANTS:
                        d_hat = fa[(v, t, h)] - fb[(v, t, h)]
                        paired[f"{h:g}s|{t}|{v}"][key].append(abs(d_hat - d_true))
                        paired[f"{h:g}s|{t}|{v}|abs_predicted"][key].append(abs(d_hat))
                        if abs(d_true) >= 1.0:
                            paired[f"{h:g}s|{t}|{v}|sign_agree"][key].append(
                                float(d_hat * d_true > 0))
    return dict(
        schema=PLAN_VERSION, receipt=receipt, train_blocks=list(train_blocks),
        development_block=development_block,
        development_status="already-used Train development block; descriptive only",
        design=dict(train=_schedule_design(train_eps), development=_schedule_design(fresh)),
        train_rows=len(fit_rows), counts=dict(counts),
        level_mae={k: _block_mean(v) for k, v in sorted(level.items())},
        paired_difference={k: _block_mean(v) for k, v in sorted(paired.items())},
        estimand=("ITT of the PLANNED randomized budget sequence over (t0,t0+5] given the "
                  "pre-cut receipt state, under the random-schedule state distribution"),
        status=("reduced-form total effect through admission/state; not a GPU service law, "
                "not calibrated, no off-policy coverage for optimized policies"),
        calibration_result=False, mpc_result=False, statistical_guarantee=False)


def _pairs(episodes):
    out = defaultdict(list)
    for e in sorted(episodes, key=lambda x: x["episode_id"]):
        out[(e["seed_block"], e["cell"])].append(e)
    return out


# ---------------------------------------------------------------------------
# R8: fitted admission-mediated birth / marked-progress scenario response (R7.7)
# ---------------------------------------------------------------------------

ADMISSION_VERSION = "nv3-opus-admission-birth-v5"
REPAIRED_ADMISSION_VERSION = "nv3-opus-admission-birth-v7-eligible-draw"
SIM_SCENARIOS = 32                       # declared once; fractional means are reported
SIM_SEED = "nv3-opus-r8-common-law"
SIM_BAND = (0.1, 0.9)
PENDING_WINDOW_S = 30.0                  # bounded pre-cut scan; longer requests raise
SIM_TARGETS = ("good", "rejected", "offers")
SIM_HORIZONS = PROGRESS_HORIZONS
LOAD_BIN, LOAD_CAP = RUNNING_BIN, RUNNING_CAP   # reused R6 declared bins, not searched
R8_TRAIN_BLOCKS = (181001, 181002, 181003)
R8_EVAL_BLOCKS = (181004, 181005)


def payload_class(row):
    """Client-known payload class: the requested max_tokens within a cell."""
    return int(row["requested_max_tokens"])


def payload_costs(episodes):
    """Exact original whole-owner cost per (cell, payload class) from Gateway marks and
    rejected-row admission estimates; any second value for one class raises."""
    costs = {}

    def put(key, value):
        if key in costs and abs(costs[key] - value) > 1e-9:
            raise ValueError("payload_cost_not_unique")
        costs.setdefault(key, float(value))
    for e in episodes:
        by_id = {r["request_id"]: r for r in e["client_rows"]}
        for r in e["client_rows"]:
            if r.get("admission_rejection") is True:
                put((e["cell"], payload_class(r)), r["admission"]["estimated_request_cost"])
        for o in e["observations"]:
            for mark in o["gateway"].get("requests") or ():
                row = by_id.get(mark["request_id"])
                if row is None or mark["max_tokens"] != row["requested_max_tokens"]:
                    raise ValueError("mark_row_payload_mismatch")
                put((e["cell"], payload_class(row)), mark["cost"])
    return costs


def _load_bin(n):
    return min(int(n) // LOAD_BIN, LOAD_CAP)


def _cohort_keys(step, rid, row):
    state = id_progress_state(step, rid, row)
    if isinstance(state, str):
        return state, [("status", state, step["cell"]), ("status", state)]
    return None, [("live",) + k for k in state]


def release_intervals(episode, rows):
    """Interval-censored Gateway owner release per admitted ID from snapshots only.

    Release of an owner is NOT its client HTTP terminal receipt. An ID last present in the
    snapshot sampled at L is released in (L, U] with U the next snapshot's sampled_at. An
    admitted ID never present in any snapshot was admitted before its client terminal T,
    so it was released before the first snapshot sampled >= T: interval (sent, U]. The
    upper bound U (conservative for the reservation stock) is the declared convention;
    IDs without a later snapshot are returned as None (explicitly unidentified)."""
    snaps = sorted((o["gateway"]["sampled_at"],
                    {m["request_id"] for m in o["gateway"].get("requests") or ()})
                   for o in episode["observations"])
    times = [t for t, _ in snaps]
    last = {}
    for t, present in snaps:
        for rid in present:
            last[rid] = t
    out = {}
    for rid, row in rows.items():
        if row["rejected"]:
            continue
        if rid in last:
            lower, i = last[rid], bisect.bisect_right(times, last[rid])
        else:
            lower, i = row["sent"], bisect.bisect_left(times, row["terminal"])
        out[rid] = (lower, times[i]) if i < len(times) else None
    return out


RELEASE_ENDPOINTS = ("upper", "lower")


def fit_admission_kernels(entries, endpoint="upper"):
    """Empirical marked kernels from Train only.

    Records are (Gateway release upper bound, client good | None, client terminal), all
    relative to t0 (cohort) or to send (birth); release is interval-censored owner
    disappearance (release_intervals), never the HTTP terminal.
    cohort: per live-ID R6 progress key (client_terminal/ttft_impossible as status keys).
    birth:  per (cell, payload, load bin at send), load = admitted IDs still Gateway-owned
    (release endpoint > send) at send: the only cap->state->service path.
    endpoint selects which end of the censoring interval (lower, upper] is used as the
    release time; v5 is 'upper'. Neither end is the true release time."""
    if endpoint not in RELEASE_ENDPOINTS:
        raise ValueError("release_endpoint")
    end = 1 if endpoint == "upper" else 0
    cohort, birth, lags = defaultdict(list), defaultdict(list), dict(
        upper_minus_terminal=[], lower_minus_terminal=[], never_snapshotted=0,
        admitted=0, unidentified=0)
    for e, steps, _, rows in sorted(entries, key=lambda x: x[0]["episode_id"]):
        release = release_intervals(e, rows)
        for rid, iv in sorted(release.items()):
            lags["admitted"] += 1
            if iv is None:
                lags["unidentified"] += 1
                continue
            lags["upper_minus_terminal"].append(iv[1] - rows[rid]["terminal"])
            lags["lower_minus_terminal"].append(iv[0] - rows[rid]["terminal"])
            lags["never_snapshotted"] += iv[0] == rows[rid]["sent"]
        for s in steps:
            if not _usable(s):
                continue
            for rid in sorted(s["cohort"]):
                row = rows[rid]
                status, keys = _cohort_keys(s, rid, row)
                good = rows[rid]["good_at"]
                if status is not None and good is not None and good > s["t0"] + EPS:
                    raise ValueError("deterministic_state_became_good")
                if release.get(rid) is None:
                    continue
                record = (release[rid][end] - s["t0"],
                          None if good is None or good <= s["t0"] + EPS else good - s["t0"],
                          row["terminal"] - s["t0"])
                for key in keys:
                    cohort[key].append(record)
        admitted = sorted((r["sent"], rid) for rid, r in rows.items()
                          if not r["rejected"] and release.get(rid) is not None)
        sents = [t for t, _ in admitted]
        ends = sorted(release[rid][end] for _, rid in admitted)
        raw = {r["request_id"]: r for r in e["client_rows"]}
        for sent, rid in admitted:
            row = rows[rid]
            n = bisect.bisect_left(sents, sent) - bisect.bisect_right(ends, sent)
            record = (release[rid][end] - sent,
                      None if row["good_at"] is None else row["good_at"] - sent,
                      row["terminal"] - sent)
            if max(record[0], record[2]) > PENDING_WINDOW_S:
                raise ValueError("request_longer_than_pending_window")
            cls = payload_class(raw[rid])
            for key in ((e["cell"], cls, _load_bin(n)), (e["cell"], cls)):
                birth[key].append(record)
    for name in ("upper_minus_terminal", "lower_minus_terminal"):
        v = sorted(lags[name])
        lags[name] = dict(n=len(v), p01=_quantile(v, 0.01), p50=_quantile(v, 0.5),
                          p99=_quantile(v, 0.99), min=v[0], max=v[-1]) if v else None
    return dict(cohort=dict(cohort), birth=dict(birth), release_lag=lags)


def kernel_draw(table, keys, u, min_alive=None):
    """Back-off draw: first key with >= HAZARD_MIN records (or the coarsest non-empty).
    min_alive conditions a pending ID on what IS known at the cut, no client terminal
    receipt by then: the first record at or after the uniform position whose client
    terminal offset (last field) exceeds min_alive, cyclically."""
    for level, key in enumerate(keys):
        records = table.get(key) or ()
        if len(records) >= HAZARD_MIN or (level == len(keys) - 1 and records):
            start = int(u * len(records))
            for i in range(len(records)):
                rec = records[(start + i) % len(records)]
                if min_alive is None or rec[-1] > min_alive + EPS:
                    return rec, level
            break
    raise ValueError("kernel_unsupported")


DRAW_RULES = ("v5_cyclic", "eligible_uniform")


def kernel_draw_eligible(table, keys, u, min_alive=None):
    """R10 repair of kernel_draw. Same back-off: the level is chosen on its TOTAL record
    count (>= HAZARD_MIN, or the coarsest non-empty), exactly as v5. Within that level the
    eligible survivors (client terminal offset > min_alive + EPS) are filtered FIRST and
    one is drawn uniformly, so each eligible record has probability 1/len(eligible). v5
    instead walked cyclically from int(u*n) to the next survivor, which over-weights
    survivors that follow runs of ineligible records. No eligible survivor at the chosen
    level is explicitly unsupported (no fall-through to a coarser level, as in v5).
    min_alive=None reproduces v5 exactly."""
    for level, key in enumerate(keys):
        records = table.get(key) or ()
        if len(records) >= HAZARD_MIN or (level == len(keys) - 1 and records):
            eligible = records if min_alive is None else [
                rec for rec in records if rec[-1] > min_alive + EPS]
            if not eligible:
                raise ValueError("kernel_no_eligible_survivor")
            return eligible[min(int(u * len(eligible)), len(eligible) - 1)], level
    raise ValueError("kernel_unsupported")


def _drawer(draw_rule):
    if draw_rule == "v5_cyclic":
        return kernel_draw
    if draw_rule == "eligible_uniform":
        return kernel_draw_eligible
    raise ValueError("draw_rule")


def admission_cut_state(step, rows, raw_rows, costs, sent_index):
    """Online cut state from receipts <= t0 only: live ledger IDs with exact costs and
    progress keys, pending sent-but-unresolved IDs (incl. not-yet-snapshot), the pre-cut
    all-offered payload mix and the common arrival law. No plan, cap or future input."""
    t0, cell = step["t0"], step["cell"]
    live = []
    for rid in sorted(step["cohort"]):
        status, keys = _cohort_keys(step, rid, rows[rid])
        cost = costs[(cell, payload_class(raw_rows[rid]))]
        live.append((rid, cost, status, keys))
    sents, ids, by_class = sent_index
    hi = bisect.bisect_right(sents, t0 + EPS)
    lo = bisect.bisect_left(sents, t0 - PENDING_WINDOW_S)
    pending = []
    for i in range(lo, hi):
        rid = ids[i]
        row = rows[rid]
        if rid in step["cohort"] or (row["terminal"] is not None and row["terminal"] <= t0 + EPS):
            continue
        pending.append((rid, costs[(cell, payload_class(raw_rows[rid]))],
                        payload_class(raw_rows[rid]), t0 - row["sent"]))
    mix = [(c, bisect.bisect_right(times, t0 + EPS)) for c, times in sorted(by_class.items())]
    return dict(t0=t0, cell=cell, law=arrival_law(step), live=live, pending=pending,
                mix=[(c, n) for c, n in mix if n])


def draw_common_law(cut, key, scenario):
    """One common future offered draw per (origin key, scenario): Poisson arrivals at the
    pre-cut law rate and payloads from the pre-cut all-offered mix. The uniform stream is
    keyed by (block, cell, k, scenario), so paired arms and every candidate plan share it."""
    digest = hashlib.sha256(f"{SIM_SEED}|{key}|{scenario}".encode()).hexdigest()
    rng = random.Random(int(digest[:16], 16))
    rate = cut["law"] / STEP_S
    total = sum(w for _, w in cut["mix"])
    arrivals, t = [], 0.0
    while True:
        t += rng.expovariate(1.0) / rate if rate > 0 else math.inf
        if t > ROLLOUT_STEPS * STEP_S:
            break
        pick, acc = rng.random() * total, 0
        cls = cut["mix"][-1][0]
        for c, w in cut["mix"]:
            acc += w
            if pick < acc:
                cls = c
                break
        arrivals.append((t, cls, rng.random()))
    return dict(arrivals=arrivals, live_u=[rng.random() for _ in cut["live"]],
                pending_u=[rng.random() for _ in cut["pending"]])


def simulate_plan(cut, plan, draw, kernels, costs, load_aware=True, draw_rule="v5_cyclic",
                  trace=None):
    """Exact ledger scenario for one PLANNED 0.5s budget path (plan[j] on (j/2, (j+1)/2]).

    Admission: R(a) + c <= u(a) at the offer instant, with every release at or before a
    applied first; non-eviction, immutable whole-owner cost, each ID released once. GPU
    service enters ONLY through the birth kernel's load bin at admission (cap -> admitted
    set -> load -> service), never through the budget value itself.
    Pending sent-not-owned IDs have a LATENT Gateway status at the cut (not yet admitted,
    owned since the snapshot, rejected or finished with the client uninformed); they are
    NOT added to the stock, but re-offered at the cut through the same admission test and
    conditioned only on 'no client terminal by t0'. This is a declared approximation.
    Release times are Gateway-disappearance UPPER bounds, so reservation is conservative."""
    draw_fn = _drawer(draw_rule)
    heap, good, rejected, offers = [], [], [], []
    for (rid, cost, status, keys), u in zip(cut["live"], draw["live_u"]):
        # client_terminal IDs stay Gateway-owned until their drawn release (no exact zero)
        (rel, g, _), _ = draw_fn(kernels["cohort"], keys, u)
        heapq.heappush(heap, (rel, rid, cost))
        if trace is not None:
            trace[rid] = dict(release=rel, good=g, admitted_at=None)
        if g is not None:
            good.append(g)
    events = [(0.0, "pending", rid, cls, cost, age, u) for (rid, cost, cls, age), u
              in zip(cut["pending"], draw["pending_u"])]
    events += [(t, "offer", f"new{i}", cls, costs[(cut["cell"], cls)], 0.0, u)
               for i, (t, cls, u) in enumerate(draw["arrivals"])]
    released, max_reserved = 0, 0.0
    for a, kind, rid, cls, cost, age, u in events:
        while heap and heap[0][0] <= a + EPS:
            heapq.heappop(heap)
            released += 1
        if kind == "offer":
            offers.append(a)
        j = min(max(int(math.ceil(a / STEP_S - EPS)) - 1, 0), ROLLOUT_STEPS - 1)
        reserved = math.fsum(c for _, _, c in heap)
        if reserved + cost > plan[j] + EPS:
            rejected.append(a)
            continue
        keys = [(cut["cell"], cls, _load_bin(len(heap))), (cut["cell"], cls)]
        if not load_aware:
            keys = keys[1:]
        (dur, g, _), _ = draw_fn(kernels["birth"], keys, u,
                                 min_alive=age if kind == "pending" else None)
        heapq.heappush(heap, (a - age + dur, rid, cost))
        if trace is not None:
            trace[rid] = dict(release=a - age + dur, good=None if g is None else a - age + g,
                              admitted_at=a)
        max_reserved = max(max_reserved, reserved + cost)
        if g is not None and a - age + g > 0:
            good.append(a - age + g)
    out = {}
    for h in SIM_HORIZONS:
        out[f"good_{h:g}"] = float(sum(0 < g <= h + EPS for g in good))
        out[f"rejected_{h:g}"] = float(sum(r <= h + EPS for r in rejected))
        out[f"offers_{h:g}"] = float(sum(o <= h + EPS for o in offers))
    out["max_reserved_after_admission"] = max_reserved
    return out


def admission_birth_response(cut, plan, key, kernels, costs, scenarios=SIM_SCENARIOS,
                             load_aware=True, draw_rule="v5_cyclic"):
    """Portable interface: scenario means/bands of G/R/O over 1/3/5s for one planned path.
    The same common-law draws are used for every plan evaluated at this origin key."""
    if len(plan) != ROLLOUT_STEPS:
        raise ValueError("plan_length")
    runs = [simulate_plan(cut, plan, draw_common_law(cut, key, i), kernels, costs, load_aware,
                          draw_rule) for i in range(scenarios)]
    out = {}
    for name in runs[0]:
        values = sorted(r[name] for r in runs)
        out[name] = dict(mean=math.fsum(values) / len(values),
                         lo=values[int(SIM_BAND[0] * (len(values) - 1))],
                         hi=values[int(math.ceil(SIM_BAND[1] * (len(values) - 1)))])
    return out


def _r8_entries(episodes):
    out = []
    for e in sorted(episodes, key=lambda x: x["episode_id"]):
        steps, good, rows = joint_steps(e, with_rows=True)
        out.append((e, steps, good, rows))
    return out


def _mean_truth(selected):
    """Per-episode mean over ALL selected origins, then mean over episodes (the same
    aggregation as the MAE). R9 fix: v5 kept only the last origin per episode."""
    names = sorted({n for r in selected.values() for n in r["truth"]})
    out = {}
    for n in names:
        per = defaultdict(list)
        for (eid, _), r in sorted(selected.items()):
            per[eid].append(r["truth"][n])
        out[n] = _block_mean(per)
    return out


def admission_birth_diagnostic(train_episodes, eval_episodes, receipts=None,
                               train_blocks=R8_TRAIN_BLOCKS, eval_blocks=R8_EVAL_BLOCKS,
                               release_endpoint="upper"):
    return _admission_birth(train_episodes, eval_episodes, receipts, train_blocks,
                            eval_blocks, release_endpoint)[0]


def _admission_birth(train_episodes, eval_episodes, receipts, train_blocks, eval_blocks,
                     release_endpoint, draw_rule="v5_cyclic"):
    """Fit on complete Train blocks only; describe the held complete Train blocks.

    Pre-registered: horizons 1/3/5s, R6/R7 comparators refit on the same Train blocks,
    SIM_SCENARIOS, seeds, LOAD bins, HAZARD_MIN, origin rule k%4==0 + previous labels +
    Train-support not OOD + no outstanding action + full 5s labels. Primary: total G5 MAE.
    Secondary: paired-arm factual differences (different arm states, not action effects)."""
    for e in list(train_episodes) + list(eval_episodes):
        if e["partition"] != "train":
            raise ValueError("admission_requires_train_only")
    if set(train_blocks) & set(eval_blocks):
        raise ValueError("train_eval_overlap")
    train_eps = [e for e in train_episodes if e["seed_block"] in train_blocks]
    eval_eps = [e for e in eval_episodes if e["seed_block"] in eval_blocks]
    for blocks, eps in ((train_blocks, train_eps), (eval_blocks, eval_eps)):
        for b in blocks:
            got = [e for e in eps if e["seed_block"] == b]
            if len(got) != DEVELOPMENT_CELLS * DEVELOPMENT_ARMS or \
                    len({e["cell"] for e in got}) != DEVELOPMENT_CELLS:
                raise ValueError("block_incomplete")
    for (blk, cell), arms in _pairs(eval_eps).items():
        a, b = ([u for _, u in e["cap_plan"]] for e in arms)
        if len(arms) != 2 or a == b:
            raise ValueError("eval_pair_not_randomized_contrast")

    train_entries = _r8_entries(train_eps)
    costs = payload_costs(train_eps)
    if any(abs(costs.get(k, math.inf) - v) > 1e-9 for k, v in payload_costs(eval_eps).items()):
        raise ValueError("eval_payload_cost_not_bound_to_train")
    kernels = fit_admission_kernels(train_entries, release_endpoint)
    train = _progress_rows(train_entries)
    train_k = {e["episode_id"]: {s["k"]: s for s in steps} for e, steps, _, _ in train_entries}
    records = [(h, id_progress_state(s, rid, rows[rid]), int(rid in labels[h][0]))
               for _, s, rows, labels in train for h in labels for rid in s["cohort"]]
    table = fit_progress_hazard(records)
    support = joint_support([s for _, s, _, _ in train])
    names = [f"{part}_{h:g}" for h in SIM_HORIZONS for part in ("cohort", "birth")]
    full = [(e, s, labels) for e, s, _, labels in train if len(labels) == len(SIM_HORIZONS)]
    ys = [{f"{p}_{h:g}": float(labels[h][1 if p == "cohort" else 2])
           for h in SIM_HORIZONS for p in ("cohort", "birth")} for _, _, labels in full]
    aggregate = fit_ridge([_vector(s, False) for _, s, _ in full], ys, names)
    birth = fit_ridge([_exo_vector(s, arrival_law(s)) for _, s, _ in full], ys, names)
    plan_rows, plan_ys = [], []
    for e, s, labels in full:
        path = _actual_path(train_k[e["episode_id"]], s, ROLLOUT_STEPS)
        if path is None:
            continue
        y = {}
        for h in SIM_HORIZONS:
            cum = path[int(round(h / STEP_S)) - 1]
            y.update({f"good_{h:g}": float(labels[h][2]), f"rejected_{h:g}": cum["rejected"],
                      f"offers_{h:g}": cum["offers"]})
        plan_rows.append(s)
        plan_ys.append(y)
    full_plan = {h: fit_ridge([plan_inputs(s, h, "full_plan") for s in plan_rows], plan_ys,
                              [f"{t}_{h:g}" for t in SIM_TARGETS]) for h in SIM_HORIZONS}

    counts = Counter()
    forecasts = {}
    eval_entries = _r8_entries(eval_eps)
    for e, steps, good_ids, rows in eval_entries:
        by_k = {s["k"]: s for s in steps}
        raw = {r["request_id"]: r for r in e["client_rows"]}
        order = sorted((r["sent"], rid) for rid, r in rows.items())
        by_class = defaultdict(list)
        for t, rid in order:
            by_class[payload_class(raw[rid])].append(t)
        sent_index = ([t for t, _ in order], [rid for _, rid in order], dict(by_class))
        labelled = {s["k"]: labels for _, s, _, labels in _progress_rows([(e, steps, good_ids,
                                                                           rows)])}
        for s in steps:
            counts["grid_steps"] += 1
            if s["k"] % ROLLOUT_EVERY:
                continue
            counts["grid_origins"] += 1
            reason = None
            if s["previous_labels"] is None or s["k"] not in labelled:
                reason = "no_previous_or_current_labels"
            elif len(labelled[s["k"]]) != len(SIM_HORIZONS):
                reason = "horizon_beyond_episode"
            elif joint_ood(s, support):
                reason = "ood:" + ",".join(joint_ood(s, support))
            elif _actual_path(by_k, s, ROLLOUT_STEPS) is None:
                reason = "actual_path_unavailable"
            if reason is not None:
                counts["excluded|" + reason] += 1
                continue
            labels = labelled[s["k"]]
            actual = _actual_path(by_k, s, ROLLOUT_STEPS)
            try:
                cut = admission_cut_state(s, rows, raw, costs, sent_index)
                key = f"{e['seed_block']}|{e['cell']}|{s['k']}"
                plan = s["plan"][:ROLLOUT_STEPS]
                sim = admission_birth_response(cut, plan, key, kernels, costs,
                                               draw_rule=draw_rule)
                sim_flat = admission_birth_response(cut, plan, key, kernels, costs,
                                                    load_aware=False, draw_rule=draw_rule)
                # attribution ablation: drop sent-but-unresolved pre-cut IDs (arrival
                # uniforms are drawn first, so the common offered stream is unchanged)
                sim_np = admission_birth_response(dict(cut, pending=[]), plan, key, kernels,
                                                  costs, draw_rule=draw_rule)
                const = {u: admission_birth_response(cut, [float(u)] * ROLLOUT_STEPS, key,
                                                     kernels, costs, draw_rule=draw_rule)
                         for u in (16, 32)}
            except (KeyError, ValueError) as error:
                counts["excluded|unidentified:" + str(error)] += 1
                continue
            counts["origins"] += 1
            counts["pending_ids"] += len(cut["pending"])
            counts["live_ids"] += len(cut["live"])
            counts["live_ids_not_native_visible"] += sum(r not in s["joined"]
                                                         for r, *_ in cut["live"])
            counts["planned_ne_inforce_at_cut"] += s["plan"][0] != s["gateway"]["budget"]
            truth, f = {}, {}
            hist = {t: statistics.fmean(x[t] for x in s["hist_steps"]) for t in SIM_TARGETS}
            agg = ridge_predict(aggregate, _vector(s, False))
            bir = ridge_predict(birth, _exo_vector(s, arrival_law(s)))
            for h in SIM_HORIZONS:
                n = int(round(h / STEP_S))
                ids, cohort_good, born = labels[h]
                if len(ids) != actual[n - 1]["good"]:
                    raise ValueError("good_id_count_mismatch")
                truth.update({f"good_{h:g}": float(len(ids)),
                              f"rejected_{h:g}": actual[n - 1]["rejected"],
                              f"offers_{h:g}": actual[n - 1]["offers"]})
                prog = math.fsum(progress_probability(table, h, id_progress_state(
                    s, r, rows[r]))[0] for r in s["cohort"])
                a_c = max(0.0, min(agg[f"cohort_{h:g}"], float(len(s["cohort"]))))
                b_b = max(0.0, bir[f"birth_{h:g}"])
                p = ridge_predict(full_plan[h], plan_inputs(s, h, "full_plan"))
                for t in SIM_TARGETS:
                    name = f"{t}_{h:g}"
                    f[("history_mean", name)] = hist[t] * n
                    f[("r7_full_plan", name)] = (prog if t == "good" else 0.0) + max(0.0, p[name])
                    f[("r8_admission_birth", name)] = sim[name]["mean"]
                    f[("r8_no_load_bin", name)] = sim_flat[name]["mean"]
                    f[("r8_no_pending", name)] = sim_np[name]["mean"]
                f[("aggregate_hybrid", f"good_{h:g}")] = a_c + b_b
                f[("r6_progress_hybrid", f"good_{h:g}")] = prog + b_b
                truth[f"cohort_{h:g}"] = float(cohort_good)
                truth[f"later_{h:g}"] = float(born)
            band = {name: (sim[name]["lo"], sim[name]["hi"]) for name in truth if name in sim}
            implied = {f"good_{h:g}": const[32][f"good_{h:g}"]["mean"]
                       - const[16][f"good_{h:g}"]["mean"] for h in SIM_HORIZONS}
            implied.update({f"rejected_{h:g}": const[32][f"rejected_{h:g}"]["mean"]
                            - const[16][f"rejected_{h:g}"]["mean"] for h in SIM_HORIZONS})
            forecasts[(e["episode_id"], s["k"])] = dict(
                episode=e, truth=truth, f=f, band=band, implied=implied,
                max_reserved=sim["max_reserved_after_admission"]["mean"],
                plan_max=max(s["plan"][:ROLLOUT_STEPS]), reserved0=s["gateway"]["reserved"])

    def summarize(selected):
        level, bias, cover = (defaultdict(lambda: defaultdict(list)) for _ in range(3))
        for (eid, _), r in selected.items():
            for (pred, name), value in r["f"].items():
                level[f"{name}|{pred}"][eid].append(abs(value - r["truth"][name]))
                bias[f"{name}|{pred}"][eid].append(value - r["truth"][name])
            for name, (lo, hi) in r["band"].items():
                cover[name][eid].append(float(lo - EPS <= r["truth"][name] <= hi + EPS))
        return dict(mae={k: _block_mean(v) for k, v in sorted(level.items())},
                    bias={k: _block_mean(v) for k, v in sorted(bias.items())},
                    mean_truth=_mean_truth(selected),
                    band_coverage_nominal_0_8={k: _block_mean(v) for k, v in sorted(cover.items())},
                    origins=len(selected))

    def paired(selected, eps):
        out = defaultdict(lambda: defaultdict(list))
        n = 0
        for (blk, cell), arms in _pairs(eps).items():
            a, b = (x["episode_id"] for x in arms)
            for (eid, k), ra in selected.items():
                if eid != a or (b, k) not in selected:
                    continue
                rb = selected[(b, k)]
                n += 1
                key = f"{blk}|{cell}"
                for name in [f"{t}_{h:g}" for h in SIM_HORIZONS for t in SIM_TARGETS]:
                    d_true = ra["truth"][name] - rb["truth"][name]
                    out[f"{name}|zero_predictor"][key].append(abs(d_true))
                    for pred in ("history_mean", "r7_full_plan", "r8_admission_birth",
                                 "r8_no_load_bin", "r8_no_pending", "aggregate_hybrid",
                                 "r6_progress_hybrid"):
                        if (pred, name) not in ra["f"]:
                            continue
                        d_hat = ra["f"][(pred, name)] - rb["f"][(pred, name)]
                        out[f"{name}|{pred}"][key].append(abs(d_hat - d_true))
                        if abs(d_true) >= 1.0:
                            out[f"{name}|{pred}|sign_agree"][key].append(
                                float(d_hat * d_true > 0))
        return dict(pairs=n, mae={k: _block_mean(v) for k, v in sorted(out.items())})

    per_block = {}
    for blk in eval_blocks:
        sel = {k: v for k, v in forecasts.items() if v["episode"]["seed_block"] == blk}
        eps = [e for e in eval_eps if e["seed_block"] == blk]
        per_block[str(blk)] = dict(level=summarize(sel), paired=paired(sel, eps),
                                   per_cell={cell: summarize({k: v for k, v in sel.items()
                                                              if v["episode"]["cell"] == cell})
                                             ["mae"] for cell in sorted({e["cell"] for e in eps})})
    implied = defaultdict(lambda: defaultdict(list))
    for (eid, _), r in forecasts.items():
        for name, v in r["implied"].items():
            implied[f"{r['episode']['cell']}|{name}"][eid].append(v)
    birth_levels = Counter(len(k) for k in kernels["birth"])
    out = dict(
        schema=ADMISSION_VERSION, receipts=receipts, train_blocks=list(train_blocks),
        eval_blocks=list(eval_blocks),
        eval_status=("complete Train DEVELOPMENT blocks from a different collector source "
                     "(confirmed holds); not unseen Final, not Calibration/Validation"),
        source_binding={e["episode_id"]: e.get("source_commit") for e in
                        sorted(train_eps + eval_eps, key=lambda x: x["episode_id"])},
        assignment_evidence={
            "train_holds": sum(e["assignment_evidence"]["holds"] for e in train_eps
                               if "assignment_evidence" in e),
            "eval_holds": sum(e["assignment_evidence"]["holds"] for e in eval_eps
                              if "assignment_evidence" in e),
            "eval_commands": sum(e["assignment_evidence"]["commands"] for e in eval_eps
                                 if "assignment_evidence" in e)},
        frozen=dict(scenarios=SIM_SCENARIOS, seed=SIM_SEED, band=list(SIM_BAND),
                    horizons=list(SIM_HORIZONS), step_s=STEP_S, load_bin=LOAD_BIN,
                    load_cap=LOAD_CAP, hazard_min=HAZARD_MIN, ridge_l2=RIDGE_L2,
                    pending_window_s=PENDING_WINDOW_S, origin_every=ROLLOUT_EVERY),
        payload_costs={f"{c}|{p}": v for (c, p), v in sorted(costs.items())},
        release_lag_train=kernels["release_lag"],
        kernel_support=dict(cohort_keys=len(kernels["cohort"]),
                            birth_keys=len(kernels["birth"]),
                            birth_records=sum(len(v) for k, v in kernels["birth"].items()
                                              if len(k) == 2),
                            birth_key_levels=dict(birth_levels)),
        train_design=_schedule_design(train_eps), eval_design=_schedule_design(eval_eps),
        counts=dict(sorted(counts.items())), per_block=per_block,
        pooled=dict(level=summarize(forecasts), paired=paired(forecasts, eval_eps)),
        model_implied_const32_minus_const16={k: _block_mean(v)
                                             for k, v in sorted(implied.items())},
        status=("fitted Train-only scenario response; planned-budget ITT, ACK timing not "
                "modelled; owner release = interval-censored Gateway disappearance, UPPER "
                "bound used (release-vs-terminal lag reported, true release time unknown "
                "within the snapshot interval); pending latent-status IDs re-offered at the "
                "cut, never added to stock; load bin = Gateway-owned admitted IDs, not "
                "native running; scenario bands are model draws, not calibrated intervals"),
        implied_effect_status=("model-implied contrast under the fitted kernels at observed "
                               "states; NOT a measured action effect"),
        calibration_result=False, mpc_result=False, statistical_guarantee=False)
    if release_endpoint != "upper":
        out["release_endpoint"] = release_endpoint
    if draw_rule != "v5_cyclic":
        out["schema"] = REPAIRED_ADMISSION_VERSION
        out["kernel_draw_rule"] = draw_rule
    return out, forecasts


# ---------------------------------------------------------------------------
# R9: pre-registered release LOWER/UPPER endpoint sensitivity of the frozen v5 response
# ---------------------------------------------------------------------------

SENSITIVITY_VERSION = "nv3-opus-release-endpoint-sensitivity-v6"
R9_EVAL_BLOCKS = (181008, 181009)
R8_PREDICTORS = ("r8_admission_birth", "r8_no_load_bin", "r8_no_pending")
REJECTED_BIAS_EXPLAINED = 1.5   # declared: half the R8 pooled +3.0 rejected_5 bias


def release_endpoint_sensitivity(train_episodes, eval_episodes, receipts=None,
                                 train_blocks=R8_TRAIN_BLOCKS, eval_blocks=R9_EVAL_BLOCKS):
    """Run the UNCHANGED v5 response twice, Gateway release at the lower and at the upper
    end of each owner's censoring interval. Same Train fit blocks, origins, common-law
    draws, scenarios and comparators; only the kernels' release field differs. Goodput is
    not monotone in release time (earlier release admits more, which can slow service),
    so the two runs are SENSITIVITY values, never outcome bounds; no endpoint is chosen
    and they are never averaged."""
    runs, frames = {}, {}
    for endpoint in RELEASE_ENDPOINTS:
        runs[endpoint], frames[endpoint] = _admission_birth(
            train_episodes, eval_episodes, receipts, train_blocks, eval_blocks, endpoint)
    up, lo = frames["upper"], frames["lower"]
    if set(up) != set(lo):
        raise ValueError("endpoint_origin_sets_differ")
    for key in up:
        if up[key]["truth"] != lo[key]["truth"] or any(
                up[key]["f"][k] != lo[key]["f"][k] for k in up[key]["f"]
                if k[0] not in R8_PREDICTORS):
            raise ValueError("endpoint_changed_non_release_quantity")

    def contrast(keys):
        per = defaultdict(lambda: defaultdict(list))
        for key in sorted(keys):
            eid = key[0]
            for (pred, name), value in up[key]["f"].items():
                if pred not in R8_PREDICTORS:
                    continue
                low = lo[key]["f"][(pred, name)]
                truth = up[key]["truth"][name]
                per[f"{name}|{pred}|upper_minus_lower"][eid].append(value - low)
                per[f"{name}|{pred}|truth_between_endpoint_means"][eid].append(
                    float(min(value, low) - EPS <= truth <= max(value, low) + EPS))
        return {k: _block_mean(v) for k, v in sorted(per.items())}

    def criteria(level_up, level_lo):
        out = {}
        for pred in R8_PREDICTORS:
            bu, bl = (lv["bias"][f"rejected_5|{pred}"] for lv in (level_up, level_lo))
            out[pred] = dict(
                rejected_5_bias=dict(upper=bu, lower=bl),
                good_5_mae=dict(upper=level_up["mae"][f"good_5|{pred}"],
                                lower=level_lo["mae"][f"good_5|{pred}"]),
                good_5_bias=dict(upper=level_up["bias"][f"good_5|{pred}"],
                                 lower=level_lo["bias"][f"good_5|{pred}"]),
                release_endpoint_explains_rejected_bias=abs(bl) < REJECTED_BIAS_EXPLAINED,
                rejected_bias_sign_changes_between_endpoints=bu * bl < 0)
        return out

    per_block = {}
    for blk in eval_blocks:
        keys = [k for k, v in up.items() if v["episode"]["seed_block"] == blk]
        per_block[str(blk)] = dict(
            origins=len(keys), contrast=contrast(keys),
            criteria=criteria(runs["upper"]["per_block"][str(blk)]["level"],
                              runs["lower"]["per_block"][str(blk)]["level"]))
    return dict(
        schema=SENSITIVITY_VERSION, base_schema=ADMISSION_VERSION, receipts=receipts,
        train_blocks=list(train_blocks), eval_blocks=list(eval_blocks),
        rejected_bias_explained_threshold=REJECTED_BIAS_EXPLAINED,
        runs=runs, per_block=per_block,
        pooled=dict(origins=len(up), contrast=contrast(list(up)),
                    criteria=criteria(runs["upper"]["pooled"]["level"],
                                      runs["lower"]["pooled"]["level"])),
        status=("sensitivity of the frozen v5 response to the interval-censored Gateway "
                "release convention; endpoints are not outcome bounds (non-monotone "
                "Goodput), no endpoint selected, no averaging; Train development only"),
        calibration_result=False, mpc_result=False, statistical_guarantee=False)



# ---------------------------------------------------------------------------
# R10: eligible-set kernel draw repair, old v6 vs repaired, both release conventions
# ---------------------------------------------------------------------------

ELIGIBLE_DRAW_VERSION = "nv3-opus-eligible-draw-comparison-v7"
R10_EVAL_BLOCKS = (181010, 181011)
R10_TARGETS = ("good_1", "good_3", "good_5", "rejected_1", "rejected_3", "rejected_5")


def eligible_draw_comparison(train_episodes, eval_episodes, receipts=None,
                             train_blocks=R8_TRAIN_BLOCKS, eval_blocks=R10_EVAL_BLOCKS):
    """Pre-registered R10: the frozen v5/v6 response (cyclic survivor draw) and the repaired
    eligible-uniform draw, each under BOTH release endpoints. Same Train 1-3 fit, seeds,
    scenarios, horizons, origin masks, targets and comparators. Only pending IDs (the
    only min_alive draws) can differ, so r8_no_pending and every non-R8 predictor must be
    bit-identical; any other difference raises. The repair is adopted on correctness
    grounds, not on these scores; v6 stays reported beside it."""
    runs, deltas = {}, {}
    for endpoint in RELEASE_ENDPOINTS:
        old, old_f = _admission_birth(train_episodes, eval_episodes, receipts, train_blocks,
                                      eval_blocks, endpoint, "v5_cyclic")
        new, new_f = _admission_birth(train_episodes, eval_episodes, receipts, train_blocks,
                                      eval_blocks, endpoint, "eligible_uniform")
        if set(old_f) != set(new_f):
            raise ValueError("draw_rule_origin_sets_differ")
        changed = defaultdict(lambda: defaultdict(list))
        for key in sorted(old_f):
            a, b = old_f[key], new_f[key]
            if a["truth"] != b["truth"] or set(a["f"]) != set(b["f"]):
                raise ValueError("draw_rule_changed_truth")
            for k, v in a["f"].items():
                if k[0] not in ("r8_admission_birth", "r8_no_load_bin") and b["f"][k] != v:
                    raise ValueError("draw_rule_changed_non_pending_quantity")
                if k[0] in ("r8_admission_birth", "r8_no_load_bin"):
                    changed[f"{k[1]}|{k[0]}|abs_repaired_minus_v6"][key[0]].append(
                        abs(b["f"][k] - v))
                    changed[f"{k[1]}|{k[0]}|prediction_changed"][key[0]].append(
                        float(b["f"][k] != v))
        runs[endpoint] = dict(v6=old, repaired=new)

        def table(scope_old, scope_new):
            lo, ln = scope_old["level"], scope_new["level"]
            out = {}
            for pred in ("r8_admission_birth", "r8_no_load_bin"):
                for t in R10_TARGETS:
                    out[f"{t}|{pred}"] = dict(
                        mae=dict(v6=lo["mae"][f"{t}|{pred}"], repaired=ln["mae"][f"{t}|{pred}"]),
                        bias=dict(v6=lo["bias"][f"{t}|{pred}"],
                                  repaired=ln["bias"][f"{t}|{pred}"]))
            out["band_coverage_nominal_0_8"] = dict(v6=lo["band_coverage_nominal_0_8"],
                                                    repaired=ln["band_coverage_nominal_0_8"])
            out["paired_good_5_mae"] = dict(
                v6=scope_old["paired"]["mae"]["good_5|r8_admission_birth"],
                repaired=scope_new["paired"]["mae"]["good_5|r8_admission_birth"])
            return out

        deltas[endpoint] = dict(
            pooled=table(old["pooled"], new["pooled"]),
            per_block={b: table(old["per_block"][b], new["per_block"][b])
                       for b in sorted(old["per_block"])},
            per_origin_change={k: _block_mean(v) for k, v in sorted(changed.items())})
    return dict(
        schema=ELIGIBLE_DRAW_VERSION, base_schema=ADMISSION_VERSION,
        repaired_schema=REPAIRED_ADMISSION_VERSION, receipts=receipts,
        train_blocks=list(train_blocks), eval_blocks=list(eval_blocks),
        release_endpoints=list(RELEASE_ENDPOINTS), comparison=deltas, runs=runs,
        status=("v6 cyclic survivor draw vs repaired eligible-uniform draw; correctness repair "
                "adopted independent of score; both release endpoints reported, none chosen; "
                "Train development only"),
        calibration_result=False, mpc_result=False, statistical_guarantee=False)


def interference_witness(draw_rule="v5_cyclic"):
    """Executable fixed-CRN witness of the frozen simulate_plan's interference structure.

    One live owner L and one birth A (offered at 0.2s) share every uniform across two plans
    that differ ONLY after 0.5s: 'open' admits six later fillers B, 'shut' rejects them.
    A third plan 'pre' admits eight fillers BEFORE A, moving A's load bin. Synthetic kernels:
    this is a structural property of the code, not a data result."""
    cut = dict(t0=0.0, cell="w", law=0.0, mix=[("A", 1), ("B", 1)],
               live=[("L", 1.0, None, [("live",)])], pending=[])
    kernels = dict(
        cohort={("live",): [(2.0, 1.5, 1.6)]},
        birth={("w", "A"): [(3.0, 1.0, 1.0)], ("w", "A", 0): [(3.0, 1.0, 1.0)] * HAZARD_MIN,
               ("w", "A", 1): [(4.0, 2.5, 2.5)] * HAZARD_MIN,
               ("w", "B"): [(4.5, None, 4.5)]})
    costs = {("w", "A"): 1.0, ("w", "B"): 1.0}
    late = [(0.2, "A", 0.0)] + [(0.6 + 0.1 * i, "B", 0.0) for i in range(6)]
    early = [(0.01 * (i + 1), "B", 0.0) for i in range(8)] + [(0.2, "A", 0.0)]
    plans = {"open": [32.0] * ROLLOUT_STEPS,
             "shut": [32.0] + [2.0] * (ROLLOUT_STEPS - 1)}
    out = {}
    for name, plan in plans.items():
        trace = {}
        res = simulate_plan(cut, plan, dict(arrivals=late, live_u=[0.0], pending_u=[]),
                            kernels, costs, draw_rule=draw_rule, trace=trace)
        out[name] = dict(admitted_after_0_5s=sum(v["admitted_at"] is not None and
                                                 v["admitted_at"] > STEP_S
                                                 for v in trace.values()),
                         live_L=trace["L"], birth_A=trace["new0"], good_5=res["good_5"])
    trace = {}
    simulate_plan(cut, plans["open"], dict(arrivals=early, live_u=[0.0], pending_u=[]),
                  kernels, costs, draw_rule=draw_rule, trace=trace)
    out["pre"] = dict(birth_A=trace["new8"])
    out["future_admissions_change_live_cohort_mark"] = out["open"]["live_L"] != \
        out["shut"]["live_L"]
    out["later_admissions_change_birth_mark"] = out["open"]["birth_A"] != \
        out["shut"]["birth_A"]
    out["pre_admission_load_changes_birth_mark"] = out["pre"]["birth_A"] != \
        out["open"]["birth_A"]
    out["status"] = ("structural witness of the frozen simulator under common random "
                     "numbers; synthetic kernels; not native evidence")
    return out


POST_ADMISSION_WINDOW_S = 0.5   # declared, equals the 0.5s control step; not searched


def post_admission_load_descriptive(episodes, blocks=R8_TRAIN_BLOCKS):
    """Train-only descriptive check of what v5 cannot represent: after conditioning on the
    v5 birth key (cell, payload, load bin at send), is an admitted request's remaining
    client duration associated with how many further requests were admitted in the next
    0.5s? Only requests still unterminated at send+0.5s enter (common survival condition).
    Load here is client-side admitted-and-unterminated, not native running. Observational:
    later admissions co-vary with the cap schedule and arrival bursts, so this is NOT a
    causal interference estimate; it only tells whether the fixed-mark kernel leaves
    structured residual."""
    entries = _r8_entries([e for e in episodes if e["seed_block"] in blocks
                           and e["partition"] == "train"])
    per_key = defaultdict(list)
    for e, _, _, rows in entries:
        raw = {r["request_id"]: r for r in e["client_rows"]}
        adm = sorted((r["sent"], r["terminal"], rid) for rid, r in rows.items()
                     if not r["rejected"] and r["terminal"] is not None)
        sents = [a[0] for a in adm]
        ends = sorted(a[1] for a in adm)
        for sent, term, rid in adm:
            if term <= sent + POST_ADMISSION_WINDOW_S + EPS:
                continue
            n = bisect.bisect_left(sents, sent) - bisect.bisect_right(ends, sent)
            inc = bisect.bisect_right(sents, sent + POST_ADMISSION_WINDOW_S) - \
                bisect.bisect_right(sents, sent)
            key = (e["cell"], payload_class(raw[rid]), _load_bin(n))
            per_key[key].append((inc, term - sent - POST_ADMISSION_WINDOW_S, e["episode_id"]))
    out, hi_all, lo_all = {}, [], []
    for key, rec in sorted(per_key.items()):
        if len(rec) < HAZARD_MIN:
            continue
        med = statistics.median(r[0] for r in rec)
        mean = statistics.fmean(r[1] for r in rec)
        hi = [r[1] - mean for r in rec if r[0] > med]
        lo = [r[1] - mean for r in rec if r[0] <= med]
        if not hi or not lo:
            continue
        hi_all += hi
        lo_all += lo
        out["|".join(map(str, key))] = dict(
            n=len(rec), median_later_admissions=med,
            remaining_s_high_minus_low=statistics.fmean(hi) - statistics.fmean(lo))
    return dict(schema="nv3-opus-post-admission-load-descriptive-v1",
                train_blocks=list(blocks), window_s=POST_ADMISSION_WINDOW_S, per_key=out,
                pooled=dict(n_high=len(hi_all), n_low=len(lo_all),
                            remaining_s_high_minus_low=(statistics.fmean(hi_all) -
                                                        statistics.fmean(lo_all))
                            if hi_all and lo_all else None),
                status=("observational Train-only within-key residual association; not a "
                        "causal interference effect, not native GPU time"),
                calibration_result=False, statistical_guarantee=False)


# ---------------------------------------------------------------------------
# R11: batch-aware evolving per-ID progress transition (shared-core candidate)
# ---------------------------------------------------------------------------

BATCH_VERSION = "nv3-opus-batch-progress-v8"
PREFILL_EDGES_K = (1.0, 4.0, 8.0, 16.0)   # declared a priori: ~8 short / 1 / 2 / 4 long prompts
R11_EVAL_BLOCKS = (181012, 181013)
R11_SEED = "nv3-opus-r11-transition"
COST_PHASES = frozenset(("H", "P", "D1", "D2", "D3", "D4", "T", "Q"))
RUN_PHASES = frozenset(("P", "D1", "D2", "D3", "D4"))
WORK_PHASES = frozenset(("H", "P", "Q"))
R11_COMPARATORS = ("r8_admission_birth", "r8_no_load_bin", "r7_full_plan",
                   "r6_progress_hybrid", "aggregate_hybrid", "history_mean")


def ttft_state(row, t):
    """'ok' / 'dead' / 'open' from client receipts <= t only (scheduled + TTFT SLO)."""
    first = row["first"] if row["first"] is not None and row["first"] <= t + EPS else None
    if first is not None:
        return "ok" if first - row["scheduled"] <= TTFT_SLO_S + EPS else "dead"
    return "dead" if t - row["scheduled"] > TTFT_SLO_S + EPS else "open"


def r11_phase(step, rid, row, z, unseen):
    """Observable phase at a grid cut. Owned (Gateway mark): T (client terminal seen,
    cost still held), P (native running, output 0), D1..D4 (native output bin), H (owned
    but NOT native running: native waiting, not yet visible or finished-unreleased are
    indistinguishable). Unowned: Z (seen owned at an earlier cut, released, no client
    terminal yet), Q (admitted, never yet in a grid snapshot). None: gone."""
    t0 = step["t0"]
    term = row["terminal"] is not None and row["terminal"] <= t0 + EPS
    if rid in step["cohort"]:
        if term:
            return "T"
        if rid not in step["joined"]:
            return "H"
        out = step["joined"][rid]
        return "P" if out == 0 else "D%d" % bisect.bisect_right(OUTPUT_EDGES, out)
    if term:
        return None
    if rid in z:
        return "Z"
    if rid in unseen:
        return "Q"
    return None


def r11_batch(members, prompt_k):
    """Batch state from the CURRENT population only: (native running bin, prefill-work bin).
    members: iterable of (phase, cell, cls)."""
    run, work = 0, 0.0
    for phase, cell, cls in members:
        if phase in RUN_PHASES:
            run += 1
        if phase in WORK_PHASES:
            work += prompt_k[(cell, cls)]
    return min(run // RUNNING_BIN, RUNNING_CAP), bisect.bisect_right(PREFILL_EDGES_K, work)


def _r11_keys(cell, cls, phase, ttft, batch, aware=True):
    keys = [(cell, cls, phase, ttft) + tuple(batch), (cell, cls, phase, ttft), (phase, ttft)]
    return keys if aware else keys[1:]


def _r11_entry_keys(cell, cls, half, batch, aware=True):
    keys = [("entry", cell, cls, half) + tuple(batch), ("entry", cell, cls, half),
            ("entry", cell, cls)]
    return keys if aware else keys[1:]


def _r11_walk(steps, rows):
    """Grid-cut population sets with bounded incremental updates (no full-run rescans):
    z = released-but-not-terminal, unseen = admitted-never-snapshotted (label-informed,
    used ONLY for Train transition records), seen = IDs in any earlier/current cut."""
    admitted = sorted((r["sent"], rid) for rid, r in rows.items() if not r["rejected"])
    seen, z, unseen, prev, ptr, out = set(), set(), set(), set(), 0, []
    for s in sorted(steps, key=lambda x: x["k"]):
        t0 = s["t0"]
        while ptr < len(admitted) and admitted[ptr][0] <= t0 + EPS:
            unseen.add(admitted[ptr][1])
            ptr += 1
        z |= prev - s["cohort"]
        seen |= s["cohort"]
        unseen -= s["cohort"]
        done = lambda r: rows[r]["terminal"] is not None and rows[r]["terminal"] <= t0 + EPS
        z = {r for r in z if not done(r)}
        unseen = {r for r in unseen if not done(r)}
        out.append((s, frozenset(seen), frozenset(z), frozenset(unseen)))
        prev = s["cohort"]
    return out


def _r11_next(rid, row, t0, nxt, z1, u1):
    """Factual one-step label: (phase', ttft', good_event) at the next grid cut."""
    t1 = nxt["t0"]
    if row["terminal"] is not None and t0 + EPS < row["terminal"] <= t1 + EPS:
        good = int(row["good_at"] is not None)
        return ("T" if rid in nxt["cohort"] else "GONE", "end", good)
    phase = r11_phase(nxt, rid, row, z1, u1)
    if phase is None:
        return ("GONE", "end", 0)
    return (phase, ttft_state(row, t1), 0)


def r11_transition_records(cell, steps, rows, cls_of, prompt_k):
    """Train-only factual transitions between CONSECUTIVE grid cuts k -> k+1.
    Yields (kind, keys_aware, record) with kind 'trans' (population at k) or 'entry'
    (admitted with send in (t_k, t_k+1])."""
    walk = _r11_walk(steps, rows)
    by_k = {w[0]["k"]: w for w in walk}
    admitted = sorted((r["sent"], rid) for rid, r in rows.items() if not r["rejected"])
    sents = [t for t, _ in admitted]
    for s, _, z, unseen in walk:
        if s["k"] + 1 not in by_k:
            continue
        nxt, _, z1, u1 = by_k[s["k"] + 1]
        t0 = s["t0"]
        pop = []
        for rid in sorted(set(s["cohort"]) | z | unseen):
            phase = r11_phase(s, rid, rows[rid], z, unseen)
            if phase is not None:
                pop.append((rid, phase))
        batch = r11_batch(((ph, cell, cls_of[r]) for r, ph in pop), prompt_k)
        for rid, phase in pop:
            row = rows[rid]
            ttft = "end" if phase == "T" else ttft_state(row, t0)
            yield "trans", _r11_keys(cell, cls_of[rid], phase, ttft, batch), \
                _r11_next(rid, row, t0, nxt, z1, u1)
        lo, hi = bisect.bisect_right(sents, t0 + EPS), bisect.bisect_right(sents, nxt["t0"] + EPS)
        for sent, rid in admitted[lo:hi]:
            half = int(sent - t0 > STEP_S / 2 + EPS)
            yield "entry", _r11_entry_keys(cell, cls_of[rid], half, batch), \
                _r11_next(rid, rows[rid], t0, nxt, z1, u1)


def fit_batch_progress(entries):
    """Empirical batch-conditioned transition and entry tables from Train only."""
    prompt_k = {}
    for e, _, _, _ in entries:
        for o in e["observations"]:
            for m in o["gateway"].get("requests") or ():
                key = (e["cell"], int(m["max_tokens"]))
                v = m["prompt_tokens"] / 1000
                if prompt_k.setdefault(key, v) != v:
                    raise ValueError("prompt_not_unique_per_payload")
    table, categories = defaultdict(list), set()
    for e, steps, _, rows in entries:
        cls_of = {r["request_id"]: payload_class(r) for r in e["client_rows"]}
        for _, keys, rec in r11_transition_records(e["cell"], steps, rows, cls_of, prompt_k):
            categories.add(rec)
            for key in keys:
                table[key].append(rec)
    return dict(table=dict(table), prompt_k=prompt_k, categories=sorted(categories))


def _r11_resolve(table, keys):
    for level, key in enumerate(keys):
        records = table.get(key) or ()
        if len(records) >= HAZARD_MIN or (level == len(keys) - 1 and records):
            return records, level
    raise ValueError("r11_unsupported")


def r11_simulate(start, plan, arrivals, uniforms, model, costs, aware=True, trace=None,
                 ledger=None):
    """One exact-ledger scenario. start: list of (phase, ttft, cls) at the cut (latent
    pending already re-offered and admitted as Q by the caller's ledger). Every step:
    batch from the CURRENT population -> each member's next state drawn from its
    batch-conditioned record set; offers in (j/2,(j+1)/2] pass R + c <= u_j with R the
    cost-held stock at the step start plus earlier admissions in the step; admitted
    births draw an entry record. Releases occur at step ends (grid-censored, upper end).
    The plan enters ONLY through admission; arrivals and uniforms are plan-free."""
    cell, table, prompt_k = model["cell"], model["table"], model["prompt_k"]
    pop = [[ph, tt, cls, i] for i, (ph, tt, cls) in enumerate(start)]
    good_steps, rejected, offers = [0] * ROLLOUT_STEPS, [], []
    n0, ai, max_reserved = len(start), 0, 0.0
    for j in range(ROLLOUT_STEPS):
        batch = r11_batch(((m[0], cell, m[2]) for m in pop), prompt_k)
        reserved = math.fsum(costs[(cell, m[2])] for m in pop if m[0] in COST_PHASES)
        births = []
        while ai < len(arrivals) and arrivals[ai][0] <= (j + 1) * STEP_S + EPS:
            a, cls = arrivals[ai][0], arrivals[ai][1]
            offers.append(a)
            c = costs[(cell, cls)]
            if reserved + c > plan[j] + EPS:
                rejected.append(a)
            else:
                reserved += c
                max_reserved = max(max_reserved, reserved)
                births.append((cls, int(a - j * STEP_S > STEP_S / 2 + EPS), n0 + ai))
            ai += 1
        if ledger is not None:
            ledger.append(dict(stock=math.fsum(costs[(cell, m[2])] for m in pop
                                               if m[0] in COST_PHASES),
                               admitted=len(births),
                               rejected=sum(j * STEP_S < r <= (j + 1) * STEP_S + EPS
                                            for r in rejected)))
        nxt = []
        for ph, tt, cls, idx in pop:
            records, _ = _r11_resolve(table, _r11_keys(cell, cls, ph, tt, batch, aware))
            rec = records[min(int(uniforms[idx][j] * len(records)), len(records) - 1)]
            good_steps[j] += rec[2]
            if trace is not None:
                trace.setdefault(idx, []).append(rec[0])
            if rec[0] != "GONE":
                nxt.append([rec[0], rec[1], cls, idx])
        for cls, half, idx in births:
            records, _ = _r11_resolve(table, _r11_entry_keys(cell, cls, half, batch, aware))
            rec = records[min(int(uniforms[idx][j] * len(records)), len(records) - 1)]
            good_steps[j] += rec[2]
            if trace is not None:
                trace.setdefault(idx, []).append(rec[0])
            if rec[0] != "GONE":
                nxt.append([rec[0], rec[1], cls, idx])
        pop = nxt
    out = {}
    for h in SIM_HORIZONS:
        n = int(round(h / STEP_S))
        out[f"good_{h:g}"] = float(sum(good_steps[:n]))
        out[f"rejected_{h:g}"] = float(sum(r <= h + EPS for r in rejected))
        out[f"offers_{h:g}"] = float(sum(o <= h + EPS for o in offers))
    out["max_reserved_after_admission"] = max_reserved
    return out


def r11_cut_start(step, rows, cls_of, seen, cut, plan, costs):
    """Online start state from receipts <= t0 only: live owners by observable phase,
    pending IDs split into Z (seen owned at an earlier grid cut, no terminal: released)
    and latent (never seen), latent ones re-offered against plan[0] in send order through
    the exact ledger, never added to the stock unconditionally."""
    cell, start = step["cell"], []
    for rid, _, _, _ in cut["live"]:
        ph = r11_phase(step, rid, rows[rid], frozenset(), frozenset())
        start.append((ph, "end" if ph == "T" else ttft_state(rows[rid], step["t0"]),
                      cls_of[rid]))
    reserved = math.fsum(costs[(cell, c)] for p, _, c in start if p in COST_PHASES)
    for rid, cost, cls, _ in cut["pending"]:
        if rid in seen:
            start.append(("Z", ttft_state(rows[rid], step["t0"]), cls))
        elif reserved + cost <= plan[0] + EPS:
            reserved += cost
            start.append(("Q", ttft_state(rows[rid], step["t0"]), cls))
    return start


def r11_response(start, plan, cut, key, model, costs, aware=True, scenarios=SIM_SCENARIOS):
    """Portable interface: scenario mean/10-90 band of G/R/O over 1/3/5s for one planned
    path. The common law draw (draw_common_law, shared with v5/v7) and the per-ID step
    uniforms are keyed by (origin, scenario) only, so every plan sees the same tape."""
    runs = []
    for i in range(scenarios):
        law = draw_common_law(cut, key, i)
        digest = hashlib.sha256(f"{R11_SEED}|{key}|{i}".encode()).hexdigest()
        rng = random.Random(int(digest[:16], 16))
        uniforms = [[rng.random() for _ in range(ROLLOUT_STEPS)]
                    for _ in range(len(start) + len(law["arrivals"]))]
        runs.append(r11_simulate(start, plan, law["arrivals"], uniforms, model, costs, aware))
    out = {}
    for name in runs[0]:
        values = sorted(r[name] for r in runs)
        out[name] = dict(mean=math.fsum(values) / len(values),
                         lo=values[int(SIM_BAND[0] * (len(values) - 1))],
                         hi=values[int(math.ceil(SIM_BAND[1] * (len(values) - 1)))])
    return out


def _r11_logloss(table, keys, rec, k_categories):
    records, level = _r11_resolve(table, keys)
    n = sum(1 for r in records if r == rec)
    return -math.log((n + 0.5) / (len(records) + 0.5 * k_categories)), level


def batch_progress_diagnostic(train_episodes, eval_episodes, receipts=None,
                              train_blocks=R8_TRAIN_BLOCKS, eval_blocks=R11_EVAL_BLOCKS,
                              extension=None):
    """Fit R11 on complete Train blocks; describe complete held blocks on the SAME origin
    mask as the v7 (eligible-draw, upper) comparator run, minus R11-unsupported origins,
    which are removed from every predictor. One-step: held per-ID next-state log loss,
    batch-aware vs batch-blind keys. Multi-step: free-running 1/3/5s G/R/O."""
    base, forecasts = _admission_birth(train_episodes, eval_episodes, receipts, train_blocks,
                                       eval_blocks, "upper", "eligible_uniform")
    train_entries = _r8_entries([e for e in train_episodes if e["seed_block"] in train_blocks])
    costs = payload_costs([e for e, _, _, _ in train_entries])
    fit = fit_batch_progress(train_entries)
    if extension is not None:
        extension = extension(train_episodes, eval_episodes, receipts, train_blocks,
                              eval_blocks, train_entries, costs)
    k_cat = len(fit["categories"]) + 1
    counts, onestep = Counter(), defaultdict(lambda: defaultdict(list))
    r11 = {}
    eval_entries = _r8_entries([e for e in eval_episodes if e["seed_block"] in eval_blocks])
    for e, steps, _, rows in eval_entries:
        eid, cell = e["episode_id"], e["cell"]
        raw = {r["request_id"]: r for r in e["client_rows"]}
        cls_of = {rid: payload_class(r) for rid, r in raw.items()}
        if any((cell, c) not in fit["prompt_k"] for c in set(cls_of.values())):
            raise ValueError("eval_payload_not_in_train")
        for kind, keys, rec in r11_transition_records(cell, steps, rows, cls_of,
                                                      fit["prompt_k"]):
            try:
                aware, level = _r11_logloss(fit["table"], keys, rec, k_cat)
                blind, _ = _r11_logloss(fit["table"], keys[1:], rec, k_cat)
            except ValueError:
                counts[f"onestep_unsupported|{kind}"] += 1
                continue
            onestep[f"{kind}|aware"][eid].append(aware)
            onestep[f"{kind}|blind"][eid].append(blind)
            onestep[f"{kind}|aware_minus_blind"][eid].append(aware - blind)
            onestep[f"{kind}|batch_key_level0"][eid].append(float(level == 0))
        order = sorted((r["sent"], rid) for rid, r in rows.items())
        by_class = defaultdict(list)
        for t, rid in order:
            by_class[payload_class(raw[rid])].append(t)
        sent_index = ([t for t, _ in order], [rid for _, rid in order], dict(by_class))
        model = dict(fit, cell=cell)
        for s, seen, _, _ in _r11_walk(steps, rows):
            if (eid, s["k"]) not in forecasts:
                continue
            cut = admission_cut_state(s, rows, raw, costs, sent_index)
            plan = s["plan"][:ROLLOUT_STEPS]
            key = f"{e['seed_block']}|{cell}|{s['k']}"
            prior_seen = seen - s["cohort"]
            try:
                start = r11_cut_start(s, rows, cls_of, prior_seen, cut, plan, costs)
                sim = r11_response(start, plan, cut, key, model, costs, True)
                flat = r11_response(start, plan, cut, key, model, costs, False)
                extra = ({} if extension is None else
                         extension["respond"](start, plan, cut, key, model, costs,
                                              **({"context": dict(step=s, rows=rows,
                                                                  cls_of=cls_of,
                                                                  seen=prior_seen)}
                                                 if extension.get("context") else {})))
            except ValueError as error:
                counts["excluded|r11:" + str(error)] += 1
                continue
            counts["origins"] += 1
            counts["start_Z"] += sum(p == "Z" for p, _, _ in start)
            counts["start_Q"] += sum(p == "Q" for p, _, _ in start)
            counts["start_H"] += sum(p == "H" for p, _, _ in start)
            r11[(eid, s["k"])] = (sim, flat, extra)
    selected = {k: v for k, v in forecasts.items() if k in r11}
    counts["v7_origins"] = len(forecasts)
    names = [f"{t}_{h:g}" for h in SIM_HORIZONS for t in SIM_TARGETS]

    def summary(keys):
        mae, bias, cover = (defaultdict(lambda: defaultdict(list)) for _ in range(3))
        for key in keys:
            r, (sim, flat, extra) = selected[key], r11[key]
            eid = key[0]
            for name in names:
                truth = r["truth"][name]
                preds = {"r11_batch_progress": sim[name]["mean"],
                         "r11_batch_blind": flat[name]["mean"]}
                preds.update({p: r["f"][(p, name)] for p in R11_COMPARATORS
                              if (p, name) in r["f"]})
                preds.update({p: v[name]["mean"] for p, v in extra.items()})
                if extension is not None:
                    preds.update(extension["comparators"](key, name))
                for p, v in extra.items():
                    cover[f"{name}|{p}"][eid].append(float(v[name]["lo"] - EPS <= truth
                                                           <= v[name]["hi"] + EPS))
                for p, v in preds.items():
                    mae[f"{name}|{p}"][eid].append(abs(v - truth))
                    bias[f"{name}|{p}"][eid].append(v - truth)
                cover[name][eid].append(float(sim[name]["lo"] - EPS <= truth
                                              <= sim[name]["hi"] + EPS))
        return dict(origins=len(keys),
                    mae={k: _block_mean(v) for k, v in sorted(mae.items())},
                    bias={k: _block_mean(v) for k, v in sorted(bias.items())},
                    r11_band_coverage_nominal_0_8={k: _block_mean(v)
                                                   for k, v in sorted(cover.items())},
                    mean_truth=_mean_truth({k: selected[k] for k in keys}))

    def paired(keys):
        keys = set(keys)
        out, n = defaultdict(lambda: defaultdict(list)), 0
        eps = [e for e, _, _, _ in eval_entries]
        for (blk, cell), arms in _pairs(eps).items():
            a, b = (x["episode_id"] for x in arms)
            for (eid, k) in sorted(keys):
                if eid != a or (b, k) not in keys:
                    continue
                n += 1
                ra, rb = selected[(a, k)], selected[(b, k)]
                d = ra["truth"]["good_5"] - rb["truth"]["good_5"]
                out["zero_predictor"][f"{blk}|{cell}"].append(abs(d))
                out["r11_batch_progress"][f"{blk}|{cell}"].append(abs(
                    r11[(a, k)][0]["good_5"]["mean"] - r11[(b, k)][0]["good_5"]["mean"] - d))
                out["r8_admission_birth"][f"{blk}|{cell}"].append(abs(
                    ra["f"][("r8_admission_birth", "good_5")]
                    - rb["f"][("r8_admission_birth", "good_5")] - d))
                for p in r11[(a, k)][2]:
                    out[p][f"{blk}|{cell}"].append(abs(r11[(a, k)][2][p]["good_5"]["mean"]
                                                       - r11[(b, k)][2][p]["good_5"]["mean"]
                                                       - d))
        return dict(pairs=n, good_5_mae={k: _block_mean(v) for k, v in sorted(out.items())})

    per_block = {}
    for blk in eval_blocks:
        keys = [k for k, v in selected.items() if v["episode"]["seed_block"] == blk]
        eids = {k[0] for k in keys}
        per_block[str(blk)] = dict(
            multistep=summary(keys), paired=paired(keys),
            onestep={k: _block_mean({e: v[e] for e in v if e in eids})
                     for k, v in sorted(onestep.items())})
    table_levels = Counter(len(k) for k in fit["table"])
    if extension is not None:
        counts.update(extension["counts"])
    return dict(
        **({} if extension is None else dict(extension=extension["describe"])),
        schema=BATCH_VERSION if extension is None else extension["schema"], receipts=receipts, train_blocks=list(train_blocks),
        eval_blocks=list(eval_blocks), comparator_schema=REPAIRED_ADMISSION_VERSION,
        comparator_release_endpoint="upper",
        frozen=dict(step_s=STEP_S, horizons=list(SIM_HORIZONS), scenarios=SIM_SCENARIOS,
                    band=list(SIM_BAND), seed=R11_SEED, law_seed=SIM_SEED,
                    running_bin=RUNNING_BIN, running_cap=RUNNING_CAP,
                    prefill_edges_k=list(PREFILL_EDGES_K), output_edges=list(OUTPUT_EDGES),
                    hazard_min=HAZARD_MIN, logloss_pseudocount=0.5,
                    categories=len(fit["categories"])),
        table_keys=dict(sorted((str(k), v) for k, v in table_levels.items())),
        prompt_k={f"{c}|{p}": v for (c, p), v in sorted(fit["prompt_k"].items())},
        counts=dict(sorted(counts.items())), per_block=per_block,
        pooled=dict(multistep=summary(list(selected)), paired=paired(list(selected)),
                    onestep={k: _block_mean(v) for k, v in sorted(onestep.items())}),
        status=("Train-only batch-aware per-ID transition; releases grid-censored at step "
                "ends; H lumps native waiting/not-visible/finished-unreleased; Q latent "
                "pending re-offered; EOS/length uncertainty only through empirical phase "
                "transitions; bands are model draws, not calibrated intervals"),
        calibration_result=False, mpc_result=False, statistical_guarantee=False,
        native_permit=False)


def r11_interference_witness():
    """Fixed-CRN executable witness: one live decode owner L (D1); plan 'open' admits 9
    births in step 0, 'shut' admits none. Synthetic tables: D1 always -> D2; a D2 owner
    finishes (good) when the running bin is 0 but stays in D2 when it is >= 1. Same
    uniforms and arrivals under both plans; only the admitted population differs."""
    cell, cls = "w", 128
    prompt_k = {(cell, cls): 0.128}
    finish, stay, step = ("GONE", "end", 1), ("D2", "ok", 0), ("D2", "ok", 0)
    table = {}
    for run_bin in range(RUNNING_CAP + 1):
        for pb in range(len(PREFILL_EDGES_K) + 1):
            table[(cell, cls, "D1", "ok", run_bin, pb)] = [step] * HAZARD_MIN
            table[(cell, cls, "D2", "ok", run_bin, pb)] = \
                [finish if run_bin == 0 else stay] * HAZARD_MIN
            for half in (0, 1):
                table[("entry", cell, cls, half, run_bin, pb)] = [("D1", "ok", 0)] * HAZARD_MIN
    table[(cell, cls, "D1", "ok")] = [step] * HAZARD_MIN
    table[(cell, cls, "D2", "ok")] = [finish, stay] * (HAZARD_MIN // 2)
    table[("entry", cell, cls, 0)] = [("D1", "ok", 0)] * HAZARD_MIN
    table[("entry", cell, cls, 1)] = table[("entry", cell, cls, 0)]
    model = dict(cell=cell, table=table, prompt_k=prompt_k)
    costs = {(cell, cls): 1.0}
    start = [("D1", "ok", cls)]
    arrivals = [(0.05 * (i + 1), cls, 0.0) for i in range(9)]
    uniforms = [[0.02] * ROLLOUT_STEPS for _ in range(1 + len(arrivals))]
    out = {}
    for aware in (True, False):
        for name, plan in (("open", [32.0] * ROLLOUT_STEPS), ("shut", [1.0] * ROLLOUT_STEPS)):
            trace = {}
            res = r11_simulate(start, plan, arrivals, uniforms, model, costs, aware, trace)
            out[f"{'aware' if aware else 'blind'}|{name}"] = dict(
                live_L_path=trace[0], good_1=res["good_1"], rejected_1=res["rejected_1"])
    out["aware_future_admissions_change_live_cohort"] = (
        out["aware|open"]["live_L_path"] != out["aware|shut"]["live_L_path"])
    out["blind_future_admissions_change_live_cohort"] = (
        out["blind|open"]["live_L_path"] != out["blind|shut"]["live_L_path"])
    out["status"] = "structural witness of r11_simulate; synthetic tables; not native evidence"
    return out


# ---------------------------------------------------------------------------
# R12: falsifying stock-flow witnesses for the v8 G5/rejection bias
# ---------------------------------------------------------------------------

STOCK_FLOW_VERSION = "nv3-opus-stock-flow-witness-r12"


def _stock_sweep(admitted, queries, endpoint):
    """Exact Gateway cost stock at query times from interval-censored releases.
    admitted: [(rid, sent, cost, (lo, hi) | None)]; an owner is in the stock on
    [sent, release) with release its lower or upper snapshot endpoint (None: kept).
    Releases at or before a query apply first; admissions strictly before it count.
    O((n + q) log(n + q)); returns {query_key: stock}."""
    ev = []
    for rid, sent, cost, iv in admitted:
        ev.append((sent, 1, cost))
        if iv is not None:
            ev.append((iv[0] if endpoint == "lower" else iv[1], 0, -cost))
    for key, t in queries:
        ev.append((t, 0.5, key))
    ev.sort(key=lambda x: (x[0], x[1]))
    stock, out = [], {}
    for t, kind, v in ev:
        if kind == 0.5:
            out[v] = math.fsum(stock)
        else:
            stock.append(v)
    return out


def admission_replay(episode, steps, rows, costs):
    """F2 open-loop admission classifier on the FACTUAL offered tape (oracle-disturbance
    label diagnostic, never a forecast). Each actual offer a in grid step (t_k, t_k+0.5]
    with the step's planned budget u_k is classified under:
      grid_<e>:  R(t_k) + cost of ACTUAL admissions in (t_k, a) + c > u_k   (v8 rule)
      event_<e>: R(a-) + c > u_k  (releases <= a applied; actual admissions before a)
    for both release endpoints e. Returns per-grid-step predicted and actual counts."""
    cell = episode["cell"]
    raw = {r["request_id"]: r for r in episode["client_rows"]}
    cost_of = {rid: costs[(cell, payload_class(raw[rid]))] for rid in rows}
    ivs = release_intervals(episode, rows)
    admitted = [(rid, rows[rid]["sent"], cost_of[rid], ivs.get(rid))
                for rid in rows if not rows[rid]["rejected"]]
    grid = sorted(steps, key=lambda x: x["k"])
    sents = sorted((r["sent"], rid) for rid, r in rows.items())
    times = [t for t, _ in sents]
    out, queries, offers = {}, [], []
    for s in grid:
        t0 = s["t0"]
        lo = bisect.bisect_right(times, t0 + EPS)
        hi = bisect.bisect_right(times, t0 + STEP_S + EPS)
        queries.append((("t0", s["k"]), t0))
        for t, rid in sents[lo:hi]:
            queries.append((("a", rid), t - EPS))
            offers.append((s, t, rid))
    stocks = {e: _stock_sweep(admitted, queries, e) for e in RELEASE_ENDPOINTS}
    for s in grid:
        out[s["k"]] = Counter(offers=0, actual_rejected=0, budget_mismatch_on_reject=0)
    acc = defaultdict(float)
    for s, t, rid in offers:
        k, u, c = s["k"], s["plan"][0], cost_of[rid]
        row = out[k]
        row["offers"] += 1
        row["actual_rejected"] += rows[rid]["rejected"]
        adm = raw[rid].get("admission") or {}
        if rows[rid]["rejected"] and adm.get("max_admitted_cost") is not None:
            row["budget_mismatch_on_reject"] += abs(adm["max_admitted_cost"] - u) > EPS
        for e in RELEASE_ENDPOINTS:
            grid_stock = stocks[e][("t0", k)] + acc[(k, e)]
            row[f"grid_{e}"] += grid_stock + c > u + EPS
            row[f"event_{e}"] += stocks[e][("a", rid)] + c > u + EPS
            row[f"freed_before_offer_{e}"] += max(0.0, grid_stock - stocks[e][("a", rid)])
        if not rows[rid]["rejected"]:
            for e in RELEASE_ENDPOINTS:
                acc[(k, e)] += c
    snap = {s["k"]: s["gateway"]["reserved"] - stocks["upper"][("t0", s["k"])] for s in grid}
    return out, snap, sum(v is None for v in ivs.values())


def stock_flow_witness(train_episodes, eval_episodes, receipts=None,
                       train_blocks=R8_TRAIN_BLOCKS, eval_blocks=(181004, 181005)):
    """R12 falsifying diagnostics for v8's G5 bias -6 / rejected_5 bias +9, on the SAME
    origins as the frozen v8 development run (v7 eligible-draw upper mask).
    F2: factual-tape admission replay, grid (step-start stock) vs event-ordered stock,
        summed over each origin's 10 steps, both release endpoints; actual = label.
    F1: v8 free-running per-step simulated stock / admissions / rejections vs the actual
        Gateway snapshot stock and actual counts at the same grid cuts."""
    _, forecasts = _admission_birth(train_episodes, eval_episodes, receipts, train_blocks,
                                    eval_blocks, "upper", "eligible_uniform")
    train_entries = _r8_entries([e for e in train_episodes if e["seed_block"] in train_blocks])
    costs = payload_costs([e for e, _, _, _ in train_entries])
    fit = fit_batch_progress(train_entries)
    f2 = defaultdict(lambda: defaultdict(list))
    f1 = defaultdict(lambda: defaultdict(list))
    counts = Counter()
    for e, steps, _, rows in _r8_entries([x for x in eval_episodes
                                          if x["seed_block"] in eval_blocks]):
        eid, cell, blk = e["episode_id"], e["cell"], str(e["seed_block"])
        replay, snap, unknown = admission_replay(e, steps, rows, costs)
        counts["release_unidentified_ids"] += unknown
        counts["snapshot_minus_upper_stock_abs_gt_0_01"] += sum(abs(v) > 0.01
                                                                for v in snap.values())
        raw = {r["request_id"]: r for r in e["client_rows"]}
        cls_of = {rid: payload_class(r) for rid, r in raw.items()}
        order = sorted((r["sent"], rid) for rid, r in rows.items())
        by_class = defaultdict(list)
        for t, rid in order:
            by_class[cls_of[rid]].append(t)
        sent_index = ([t for t, _ in order], [rid for _, rid in order], dict(by_class))
        by_k = {s["k"]: s for s in steps}
        model = dict(fit, cell=cell)
        for s, seen, _, _ in _r11_walk(steps, rows):
            k = s["k"]
            if (eid, k) not in forecasts:
                continue
            window = [replay.get(k + j) for j in range(ROLLOUT_STEPS)]
            if any(w is None for w in window) or any(k + j not in by_k
                                                     for j in range(ROLLOUT_STEPS)):
                counts["excluded|grid_incomplete"] += 1
                continue
            cut = admission_cut_state(s, rows, raw, costs, sent_index)
            plan = s["plan"][:ROLLOUT_STEPS]
            key = f"{e['seed_block']}|{cell}|{k}"
            try:
                start = r11_cut_start(s, rows, cls_of, seen - s["cohort"], cut, plan, costs)
            except ValueError as error:
                counts["excluded|r11:" + str(error)] += 1
                continue
            counts["origins"] += 1
            act = sum(w["actual_rejected"] for w in window)
            f2[blk]["actual_rejected_5"].append(act)
            f2[blk]["offers_5"].append(sum(w["offers"] for w in window))
            f2[blk]["budget_mismatch_on_reject_5"].append(
                sum(w["budget_mismatch_on_reject"] for w in window))
            for e_ in RELEASE_ENDPOINTS:
                for rule in ("grid", "event"):
                    f2[blk][f"{rule}_{e_}_minus_actual_rejected_5"].append(
                        sum(w[f"{rule}_{e_}"] for w in window) - act)
                f2[blk][f"freed_before_offer_cost_{e_}_5"].append(
                    sum(w[f"freed_before_offer_{e_}"] for w in window))
            per = [defaultdict(list) for _ in range(ROLLOUT_STEPS)]
            for i in range(SIM_SCENARIOS):
                law = draw_common_law(cut, key, i)
                digest = hashlib.sha256(f"{R11_SEED}|{key}|{i}".encode()).hexdigest()
                rng = random.Random(int(digest[:16], 16))
                uniforms = [[rng.random() for _ in range(ROLLOUT_STEPS)]
                            for _ in range(len(start) + len(law["arrivals"]))]
                ledger = []
                r11_simulate(start, plan, law["arrivals"], uniforms, model, costs, True,
                             ledger=ledger)
                for j, row in enumerate(ledger):
                    for name, v in row.items():
                        per[j][name].append(v)
            for j in range(ROLLOUT_STEPS):
                w = window[j]
                actual = dict(stock=by_k[k + j]["gateway"]["reserved"],
                              admitted=w["offers"] - w["actual_rejected"],
                              rejected=w["actual_rejected"])
                for name, v in actual.items():
                    f1[blk][f"{name}|step{j}"].append(statistics.fmean(per[j][name]) - v)
                    f1[blk][f"{name}|step{j}|actual"].append(v)
    mean = lambda d: {k: statistics.fmean(v) for k, v in sorted(d.items())}
    return dict(
        schema=STOCK_FLOW_VERSION, receipts=receipts, train_blocks=list(train_blocks),
        eval_blocks=list(eval_blocks), origin_mask="v7 eligible-draw upper (= frozen v8 dev)",
        counts=dict(sorted(counts.items())),
        f2_factual_tape_admission_replay={b: mean(v) for b, v in sorted(f2.items())},
        f1_v8_simulated_minus_actual_per_step={b: mean(v) for b, v in sorted(f1.items())},
        status=("F2 uses realized offers/admissions/releases as an ORACLE label diagnostic "
                "of the admission rule only; F1 compares v8 scenario means with factual "
                "paths (different states after step 0); neither is a forecast or effect"),
        calibration_result=False, mpc_result=False, statistical_guarantee=False,
        native_permit=False)


WITHIN_STEP_VERSION = "nv3-opus-within-step-release-v9"
R12_SEED = "nv3-opus-r12-release-offset"
R12_EVAL_BLOCKS = (181012, 181013)  # only if sealed before exposure; else next sealed pair


def fit_release_offsets(train_entries, endpoint):
    """Train-only empirical within-step release offsets. A start-of-step owner (present in
    the last Gateway snapshot <= t_j) absent from the last snapshot <= t_{j+1} released in
    step j; its offset is its interval endpoint minus t_j, clipped to [0, STEP_S] (the
    lower endpoint can precede t_j by snapshot staleness; the upper never exceeds the next
    cut's snapshot). Offsets are snapshot-resolution observations, not invented times; the
    true release inside (L, U] is unidentified, hence both endpoints are carried."""
    pools = defaultdict(list)
    for e, steps, _, rows in train_entries:
        cell = e["cell"]
        raw = {r["request_id"]: r for r in e["client_rows"]}
        ivs = release_intervals(e, rows)
        snaps = sorted((o["gateway"]["sampled_at"],
                        frozenset(m["request_id"] for m in o["gateway"].get("requests") or ()))
                       for o in e["observations"])
        times = [t for t, _ in snaps]
        grid = sorted(steps, key=lambda x: x["k"])

        def present(t):
            i = bisect.bisect_right(times, t) - 1
            return snaps[i][1] if i >= 0 else frozenset()
        for a, b in zip(grid, grid[1:]):
            if b["k"] != a["k"] + 1:
                continue
            for rid in present(a["t0"]) - present(b["t0"]):
                if rid not in rows or rows[rid]["rejected"] or ivs.get(rid) is None:
                    continue
                r = ivs[rid][0] if endpoint == "lower" else ivs[rid][1]
                off = min(max(r - a["t0"], 0.0), STEP_S)
                cls = payload_class(raw[rid])
                for key in ((cell, cls), (cell,), ()):
                    pools[key].append(off)
    return {k: sorted(v) for k, v in pools.items()}


def _r12_pool(offsets, cell, cls):
    for key in ((cell, cls), (cell,), ()):
        if len(offsets.get(key, ())) >= HAZARD_MIN:
            return offsets[key]
    raise ValueError("release_offset_unsupported")


def r12_simulate(start, plan, arrivals, uniforms, release_uniforms, model, costs, offsets,
                 trace=None, ledger=None):
    """v8 scenario with ONE change: within-step event-ordered admission. Member records are
    drawn from the step-start batch with the SAME uniforms as v8 (identical transitions
    given the population); a member leaving the cost-held set this step releases its whole
    cost at j*STEP_S + an empirical Train offset (separate CRN stream), so an offer at a
    sees R(a) = holders + members not yet released + births admitted so far. Births hold
    cost through their birth step (conservative; never released early). No HTTP residence,
    no serial GPU time, no budget-driven eviction; arrivals/uniforms are plan-free."""
    cell, table = model["cell"], model["table"]
    pop = [[ph, tt, cls, i] for i, (ph, tt, cls) in enumerate(start)]
    good_steps, rejected, offers = [0] * ROLLOUT_STEPS, [], []
    n0, ai, max_reserved = len(start), 0, 0.0
    for j in range(ROLLOUT_STEPS):
        batch = r11_batch(((m[0], cell, m[2]) for m in pop), prompt_k=model["prompt_k"])
        hold, releases, nxt = [], [], []
        for ph, tt, cls, idx in pop:
            records, _ = _r11_resolve(table, _r11_keys(cell, cls, ph, tt, batch, True))
            rec = records[min(int(uniforms[idx][j] * len(records)), len(records) - 1)]
            good_steps[j] += rec[2]
            if trace is not None:
                trace.setdefault(idx, []).append(rec[0])
            if ph in COST_PHASES:
                c = costs[(cell, cls)]
                if rec[0] in COST_PHASES:
                    hold.append(c)
                else:
                    pool = _r12_pool(offsets, cell, cls)
                    off = pool[min(int(release_uniforms[idx][j] * len(pool)), len(pool) - 1)]
                    releases.append((j * STEP_S + off, c))
            if rec[0] != "GONE":
                nxt.append([rec[0], rec[1], cls, idx])
        releases.sort()
        if ledger is not None:
            ledger.append(dict(stock=math.fsum(hold) + math.fsum(c for _, c in releases),
                               admitted=0, rejected=0))
        held, ri, births = math.fsum(hold), 0, []
        while ai < len(arrivals) and arrivals[ai][0] <= (j + 1) * STEP_S + EPS:
            a, cls = arrivals[ai][0], arrivals[ai][1]
            offers.append(a)
            while ri < len(releases) and releases[ri][0] <= a + EPS:
                ri += 1
            c = costs[(cell, cls)]
            reserved = held + math.fsum(x for _, x in releases[ri:])
            if reserved + c > plan[j] + EPS:
                rejected.append(a)
                if ledger is not None:
                    ledger[-1]["rejected"] += 1
            else:
                held += c
                max_reserved = max(max_reserved, reserved + c)
                births.append((cls, int(a - j * STEP_S > STEP_S / 2 + EPS), n0 + ai))
                if ledger is not None:
                    ledger[-1]["admitted"] += 1
            ai += 1
        for cls, half, idx in births:
            records, _ = _r11_resolve(table, _r11_entry_keys(cell, cls, half, batch, True))
            rec = records[min(int(uniforms[idx][j] * len(records)), len(records) - 1)]
            good_steps[j] += rec[2]
            if trace is not None:
                trace.setdefault(idx, []).append(rec[0])
            if rec[0] != "GONE":
                nxt.append([rec[0], rec[1], cls, idx])
        pop = nxt
    out = {}
    for h in SIM_HORIZONS:
        n = int(round(h / STEP_S))
        out[f"good_{h:g}"] = float(sum(good_steps[:n]))
        out[f"rejected_{h:g}"] = float(sum(r <= h + EPS for r in rejected))
        out[f"offers_{h:g}"] = float(sum(o <= h + EPS for o in offers))
    out["max_reserved_after_admission"] = max_reserved
    return out


def r12_response(start, plan, cut, key, model, costs, offsets, scenarios=SIM_SCENARIOS):
    """Portable v9 interface; same common law draw and v8 per-ID uniforms keyed by
    (origin, scenario), plus a plan-free release-offset stream."""
    runs = []
    for i in range(scenarios):
        law = draw_common_law(cut, key, i)
        digest = hashlib.sha256(f"{R11_SEED}|{key}|{i}".encode()).hexdigest()
        rng = random.Random(int(digest[:16], 16))
        n = len(start) + len(law["arrivals"])
        uniforms = [[rng.random() for _ in range(ROLLOUT_STEPS)] for _ in range(n)]
        digest = hashlib.sha256(f"{R12_SEED}|{key}|{i}".encode()).hexdigest()
        rng = random.Random(int(digest[:16], 16))
        release_uniforms = [[rng.random() for _ in range(ROLLOUT_STEPS)] for _ in range(n)]
        runs.append(r12_simulate(start, plan, law["arrivals"], uniforms, release_uniforms,
                                 model, costs, offsets))
    out = {}
    for name in runs[0]:
        values = sorted(r[name] for r in runs)
        out[name] = dict(mean=math.fsum(values) / len(values),
                         lo=values[int(SIM_BAND[0] * (len(values) - 1))],
                         hi=values[int(math.ceil(SIM_BAND[1] * (len(values) - 1)))])
    return out


def within_step_extension(train_episodes, eval_episodes, receipts, train_blocks,
                          eval_blocks, train_entries, costs):
    """v9 extension of the frozen v8 diagnostic: both release endpoints as separate
    predictors (never averaged/selected), plus the v7 LOWER-endpoint comparator on the
    same origin mask (missing keys counted, never imputed)."""
    offsets = {e: fit_release_offsets(train_entries, e) for e in RELEASE_ENDPOINTS}
    _, lower = _admission_birth(train_episodes, eval_episodes, receipts, train_blocks,
                                eval_blocks, "lower", "eligible_uniform")
    counts = Counter()

    def respond(start, plan, cut, key, model, costs_):
        return {f"v9_within_step_{e}": r12_response(start, plan, cut, key, model, costs_,
                                                    offsets[e])
                for e in RELEASE_ENDPOINTS}

    def comparators(key, name):
        f = lower.get(key)
        if f is None or ("r8_admission_birth", name) not in f["f"]:
            counts[f"v7_lower_missing|{name}"] += 1
            return {}
        return {"r8_admission_birth_lower": f["f"][("r8_admission_birth", name)]}

    def quant(v):
        return [v[int(q * (len(v) - 1))] for q in (0.1, 0.25, 0.5, 0.75, 0.9)]
    describe = {e: {"|".join(map(str, k)) or "all": dict(n=len(v), q10_25_50_75_90=quant(v))
                    for k, v in sorted(offsets[e].items(), key=lambda x: str(x[0]))}
                for e in RELEASE_ENDPOINTS}
    return dict(schema=WITHIN_STEP_VERSION, respond=respond, comparators=comparators,
                counts=counts, describe=dict(release_offsets=describe, seed=R12_SEED))


# ---------------------------------------------------------------------------
# R13: stable per-identity common random numbers (correctness repair)
# ---------------------------------------------------------------------------

STABLE_CRN_VERSION = "nv3-opus-stable-crn-v10"
R13_SEED = "nv3-opus-r13-stable-crn"
R13_EVAL_BLOCKS = (181015, 181016)   # first pair unexposed at this seal; 12/13 are exposed
R13_CONTRAST_PLANS = (16.0, 32.0)    # the two existing budget levels, constant paths


class StableUniforms:
    """Per-identity CRN streams for the frozen v8/v9 simulators, which index uniforms by
    position: idx < len(start_ids) is a cut member (identity 'rid:<request_id>'); idx >=
    len(start_ids) is the (idx - n0)-th draw of the COMMON law tape ('arrival:<i>').
    Each identity's ROLLOUT_STEPS uniforms come from sha256(tag|origin|scenario|identity),
    so they do not depend on how many latent Q owners a plan admitted, on start order, on
    the plan or on any other identity. Lazily materialized and cached."""

    def __init__(self, tag, key, scenario, start_ids):
        self.tag, self.key, self.scenario = tag, key, scenario
        self.ids, self.cache = list(start_ids), {}

    def identity(self, idx):
        n0 = len(self.ids)
        return self.ids[idx] if idx < n0 else f"arrival:{idx - n0}"

    def __getitem__(self, idx):
        ident = self.identity(idx)
        if ident not in self.cache:
            digest = hashlib.sha256(
                f"{self.tag}|{self.key}|{self.scenario}|{ident}".encode()).hexdigest()
            rng = random.Random(int(digest[:16], 16))
            self.cache[ident] = [rng.random() for _ in range(ROLLOUT_STEPS)]
        return self.cache[ident]


def r13_cut_start(step, rows, cls_of, seen, cut, plan, costs):
    """r11_cut_start with stable identities: returns (start, ids), start identical to the
    frozen function's output; ids[i] = 'rid:<request_id>' of start[i]."""
    cell, start, ids = step["cell"], [], []
    for rid, _, _, _ in cut["live"]:
        ph = r11_phase(step, rid, rows[rid], frozenset(), frozenset())
        start.append((ph, "end" if ph == "T" else ttft_state(rows[rid], step["t0"]),
                      cls_of[rid]))
        ids.append(f"rid:{rid}")
    reserved = math.fsum(costs[(cell, c)] for p, _, c in start if p in COST_PHASES)
    for rid, cost, cls, _ in cut["pending"]:
        if rid in seen:
            start.append(("Z", ttft_state(rows[rid], step["t0"]), cls))
            ids.append(f"rid:{rid}")
        elif reserved + cost <= plan[0] + EPS:
            reserved += cost
            start.append(("Q", ttft_state(rows[rid], step["t0"]), cls))
            ids.append(f"rid:{rid}")
    return start, ids


def _r13_band(runs):
    out = {}
    for name in runs[0]:
        values = sorted(r[name] for r in runs)
        out[name] = dict(mean=math.fsum(values) / len(values),
                         lo=values[int(SIM_BAND[0] * (len(values) - 1))],
                         hi=values[int(math.ceil(SIM_BAND[1] * (len(values) - 1)))])
    return out


def r13_runs(start, ids, plan, cut, key, model, costs, aware=True, offsets=None,
             scenarios=SIM_SCENARIOS, stable=True):
    """Per-scenario results. stable=True: v10 identity-keyed member/birth (and release
    offset) streams. stable=False reproduces the frozen v8/v9 positional streams exactly.
    offsets=None: v8 grid-release ledger; else the v9 within-step release ledger."""
    runs = []
    for i in range(scenarios):
        law = draw_common_law(cut, key, i)
        n = len(start) + len(law["arrivals"])
        if stable:
            uniforms = StableUniforms(R13_SEED + "|member", key, i, ids)
            release = StableUniforms(R13_SEED + "|release", key, i, ids)
        else:
            digest = hashlib.sha256(f"{R11_SEED}|{key}|{i}".encode()).hexdigest()
            rng = random.Random(int(digest[:16], 16))
            uniforms = [[rng.random() for _ in range(ROLLOUT_STEPS)] for _ in range(n)]
            digest = hashlib.sha256(f"{R12_SEED}|{key}|{i}".encode()).hexdigest()
            rng = random.Random(int(digest[:16], 16))
            release = [[rng.random() for _ in range(ROLLOUT_STEPS)] for _ in range(n)]
        if offsets is None:
            runs.append(r11_simulate(start, plan, law["arrivals"], uniforms, model, costs,
                                     aware))
        else:
            runs.append(r12_simulate(start, plan, law["arrivals"], uniforms, release, model,
                                     costs, offsets))
    return runs


def stable_crn_extension(train_episodes, eval_episodes, receipts, train_blocks,
                         eval_blocks, train_entries, costs):
    """v10 extension: the frozen v9 extension's predictors/comparators unchanged, plus
    v8 aware/blind and v9 upper/lower re-run with stable identity CRN. Also a pairing
    diagnostic on constant 16 vs 32 plans (v8 kernel, aware): per-origin scenario SD of
    the G5 contrast under positional vs stable streams, and how often the plans' start
    lengths differ (the positional birth-index shift). Contrasts are model Monte Carlo
    pairing diagnostics, never causal plan effects or rankings."""
    v9 = within_step_extension(train_episodes, eval_episodes, receipts, train_blocks,
                               eval_blocks, train_entries, costs)
    offsets = {e: fit_release_offsets(train_entries, e) for e in RELEASE_ENDPOINTS}
    pairing = defaultdict(Counter)

    def respond(start, plan, cut, key, model, costs_, context):
        out = v9["respond"](start, plan, cut, key, model, costs_)
        args = (context["step"], context["rows"], context["cls_of"], context["seen"], cut)
        start2, ids = r13_cut_start(*args, plan, costs_)
        if start2 != start:
            raise ValueError("r13_start_mismatch")
        out["v10_stable_aware"] = _r13_band(r13_runs(start, ids, plan, cut, key, model,
                                                     costs_, True))
        out["v10_stable_blind"] = _r13_band(r13_runs(start, ids, plan, cut, key, model,
                                                     costs_, False))
        for e in RELEASE_ENDPOINTS:
            out[f"v10_within_step_{e}"] = _r13_band(r13_runs(
                start, ids, plan, cut, key, model, costs_, True, offsets[e]))
        blk = key.split("|")[0]
        row = pairing[blk]
        starts = {u: r13_cut_start(*args, [u] * ROLLOUT_STEPS, costs_)
                  for u in R13_CONTRAST_PLANS}
        lo, hi = R13_CONTRAST_PLANS
        row["origins"] += 1
        row["start_length_differs"] += len(starts[lo][0]) != len(starts[hi][0])
        for name, stable in (("positional_v8", False), ("stable_v10", True)):
            g = {u: [r["good_5"] for r in r13_runs(*starts[u], [u] * ROLLOUT_STEPS, cut,
                                                    key, model, costs_, True,
                                                    stable=stable)]
                 for u in R13_CONTRAST_PLANS}
            d = [b - a for a, b in zip(g[lo], g[hi])]
            row[f"{name}|sum_mean_g5_contrast"] += statistics.fmean(d)
            row[f"{name}|sum_sd_g5_contrast"] += statistics.pstdev(d)
            row[f"{name}|scenarios_contrast_nonzero"] += sum(abs(x) > EPS for x in d)
        return out

    describe = dict(v9["describe"], seed=R13_SEED, contrast_plans=list(R13_CONTRAST_PLANS),
                    pairing_sums_by_block=pairing,
                    note=("pairing sums: divide by origins; SIM_SCENARIOS per origin"))
    return dict(schema=STABLE_CRN_VERSION, respond=respond, context=True,
                comparators=v9["comparators"], counts=v9["counts"], describe=describe)


# ---------------------------------------------------------------------------
# R14: birth-hold floor, owner-mark stock bracket and aggregate-ledger ambiguity
# ---------------------------------------------------------------------------

OWNER_AUDIT_VERSION = "nv3-opus-owner-stock-audit-r14"


def _owner_marks(episode):
    """Gateway owner marks from snapshots only: per ID exact Gateway admitted_at, cost
    and first/last snapshot times; per snapshot (sampled_at, budget, {id: cost})."""
    snaps, marks = [], {}
    for o in sorted(episode["observations"], key=lambda x: x["gateway"]["sampled_at"]):
        g = o["gateway"]
        owners = {}
        for mk in g.get("requests") or ():
            owners[mk["request_id"]] = mk["cost"]
            rec = marks.setdefault(mk["request_id"], dict(admitted_at=mk["admitted_at"],
                                                          cost=mk["cost"],
                                                          first=g["sampled_at"]))
            if abs(rec["admitted_at"] - mk["admitted_at"]) > EPS or \
                    abs(rec["cost"] - mk["cost"]) > EPS:
                raise ValueError("owner_mark_not_immutable")
            rec["last"] = g["sampled_at"]
        snaps.append((g["sampled_at"], float(g["budget"]), owners))
    return snaps, marks


def owner_stock_audit(episode, steps, rows, costs):
    """Per-episode R14 audit from receipts and Gateway owner marks only (no model, no
    plan, no future input; realized releases/outcomes are LABELS here).

    Owner hold interval: start = exact Gateway admitted_at if ever snapshotted, else only
    bracketed by (sent, release upper]; release in (L, U] from release_intervals.
    Brackets at an offer time a (the offer itself excluded):
      S_def(a) = cost of owners definitely holding (start < a and L >= a)
      S_pos(a) = cost of owners possibly holding (possible start < a and U > a; U None:
                 unidentified, treated as possibly holding)
    Budget bracket at a = budgets of the last snapshot <= a and the first one >= a.
    Determined outcome: S_pos + c <= min budget (must accept) or S_def + c > max budget
    (must reject); otherwise ambiguous from owner marks. Rejections also carry their
    exact max_admitted_cost. Floor variant: every release moved to max(release, end of
    the owner's birth grid step) - the v8/v9 births-hold-their-birth-step convention.
    Aggregate-ledger attribution: releases grouped by (snapshot interval, cost); a group
    of size g > 1 cannot be attributed to owners from (time, cost) events without UUIDs."""
    cell = episode["cell"]
    raw = {r["request_id"]: r for r in episode["client_rows"]}
    snaps, marks = _owner_marks(episode)
    times = [t for t, _, _ in snaps]
    ivs = release_intervals(episode, rows)
    grid = sorted(s["t0"] for s in steps)
    c = Counter()
    holds = []
    for rid, row in rows.items():
        if row["rejected"]:
            continue
        cost = costs[(cell, payload_class(raw[rid]))]
        mk = marks.get(rid)
        if mk is not None and abs(mk["cost"] - cost) > EPS:
            raise ValueError("owner_cost_mismatch")
        iv = ivs.get(rid)
        start_lo = mk["admitted_at"] if mk else row["sent"]
        start_hi = mk["admitted_at"] if mk else (iv[1] if iv else math.inf)
        k = bisect.bisect_left(grid, row["sent"] - EPS) - 1
        end = grid[k] + STEP_S if 0 <= k < len(grid) else None
        c["admitted"] += 1
        c["never_snapshotted"] += mk is None
        c["never_snapshotted_cost"] += cost * (mk is None)
        c["admitted_cost"] += cost
        if iv is None:
            c["release_unidentified"] += 1
        elif end is None:
            c["birth_step_outside_grid"] += 1
        elif iv[1] <= end + EPS:
            c["birth_release_within_birth_step_definite"] += 1
            c["birth_release_within_birth_step_definite_cost"] += cost
        elif iv[0] >= end - EPS:
            c["birth_hold_past_birth_step_definite"] += 1
        else:
            c["birth_release_vs_step_end_ambiguous"] += 1
        holds.append((rid, cost, start_lo, start_hi, iv, end))
    # offers and brackets (O(n_offers * n_owners) per episode is bounded by the run
    # length; sweep would be faster but this audit runs once per episode)
    for rid, row in sorted(rows.items(), key=lambda x: x[1]["sent"]):
        a = row["sent"]
        if not (grid and grid[0] < a <= grid[-1] + STEP_S + EPS):
            continue
        cost = costs[(cell, payload_class(raw[rid]))]
        rejected = row["rejected"]
        # decision window: exact Gateway admitted_at for accepts; for rejects only
        # (client sent, client 503 terminal receipt] brackets the Gateway decision
        if rejected:
            w_lo, w_hi = a, row["terminal"] if row["terminal"] is not None else a
        elif rid in marks:
            w_lo = w_hi = marks[rid]["admitted_at"]
        else:
            c["offers_accepted_unmarked_skipped"] += 1
            continue
        i = bisect.bisect_right(times, w_lo) - 1
        j = bisect.bisect_left(times, w_hi)
        bud = [b for _, b, _ in snaps[max(i, 0):j + 1]]
        if not bud:
            continue
        s_def = s_pos = s_def_floor = 0.0
        for oid, oc, lo, hi, iv, end in holds:
            if oid == rid:
                continue
            low, up = (iv if iv else (-math.inf, math.inf))
            if hi < w_lo and low >= w_hi:
                s_def += oc
            if lo < w_hi and up > w_lo:
                s_pos += oc
            low_f = max(low, end) if end is not None else low
            if hi < w_lo and low_f >= w_hi:
                s_def_floor += oc
        c["offers"] += 1
        c["offers_rejected"] += rejected
        c["sum_possible_minus_definite_stock"] += s_pos - s_def
        must_accept = s_pos + cost <= min(bud) + EPS
        must_reject = s_def + cost > max(bud) + EPS
        c["offers_determined"] += must_accept or must_reject
        c["violation_rejected_but_must_accept"] += rejected and must_accept
        c["violation_accepted_but_must_reject"] += (not rejected) and must_reject
        if rejected:
            u = (raw[rid].get("admission") or {}).get("max_admitted_cost")
            if u is not None:
                slack = float(u) - (s_pos + cost)
                c["violation_rejected_exact_budget_unexplained"] += slack >= -EPS
                if slack >= -EPS:
                    c["sum_unexplained_reject_slack"] += slack
        floor_reject = s_def_floor + cost > max(bud) + EPS
        c["floor_must_reject"] += floor_reject
        c["floor_contradicted_by_actual_accept"] += (not rejected) and floor_reject \
            and not must_reject
    # aggregate-ledger attribution and net-vs-gross snapshot flow
    groups = Counter()
    for oid, oc, lo, hi, iv, end in holds:
        if iv is not None:
            groups[(iv[1], round(oc, 9))] += 1
    for (_, _), g in groups.items():
        c["releases"] += g
        c["releases_singleton_time_cost_group"] += g * (g == 1)
    for (t_a, _, before), (t_b, _, after) in zip(snaps, snaps[1:]):
        deaths = set(before) - set(after)
        births = set(after) - set(before)
        trans = sum(1 for oid, oc, lo, hi, iv, end in holds
                    if oid not in marks and t_a < lo <= t_b)
        net = math.fsum(after.values()) - math.fsum(before.values())
        c["snapshot_intervals"] += 1
        c["intervals_birth_and_death"] += bool(births or trans) and bool(deaths)
        c["intervals_churn_with_zero_net_cost"] += (bool(births or deaths or trans)
                                                    and abs(net) <= EPS)
    return c


def owner_stock_audit_summary(episodes, costs):
    per_block = defaultdict(Counter)
    for e, steps, _, rows in _r8_entries(episodes):
        per_block[str(e["seed_block"])].update(owner_stock_audit(e, steps, rows, costs))
    out = {}
    for blk, c in sorted(per_block.items()):
        d = dict(sorted(c.items()))
        d["frac_never_snapshotted"] = c["never_snapshotted"] / max(c["admitted"], 1)
        d["frac_birth_release_within_birth_step_definite"] = \
            c["birth_release_within_birth_step_definite"] / max(c["admitted"], 1)
        d["frac_offers_determined"] = c["offers_determined"] / max(c["offers"], 1)
        d["frac_rejects_unexplained_by_owner_marks"] = \
            c["violation_rejected_exact_budget_unexplained"] / max(c["offers_rejected"], 1)
        d["mean_possible_minus_definite_stock"] = \
            c["sum_possible_minus_definite_stock"] / max(c["offers"], 1)
        d["frac_releases_attributable_by_time_cost"] = \
            c["releases_singleton_time_cost_group"] / max(c["releases"], 1)
        out[blk] = d
    return out


# ---------------------------------------------------------------------------
# R14 competitor v11: concurrency-aware Gateway decision-time event births
# ---------------------------------------------------------------------------

EVENT_LAG_VERSION = "nv3-opus-event-decision-lag-v11"
R14_SEED = "nv3-opus-r14-decision-lag"
R14_OWNER_BINS = (0, 4, 8, 16)        # declared a priori owner-count edges, not searched
R14_EVAL_BLOCKS = (181017, 181018)    # 15/16 reserved for the unchanged H11/H12/H13 gates


def _r14_bin(n_owners):
    return bisect.bisect_right(R14_OWNER_BINS, n_owners) - 1


def fit_decision_lags(train_entries):
    """Train-only Gateway decision lag = exact Gateway admitted_at - client sent, for
    accepted owners, keyed by (cell, owner-count bin at sent) with (cell,) and () backoff.
    Owner count = owners in the last Gateway snapshot <= sent (an observable at sent).
    Reject decision instants are not observed (only (sent, 503 terminal]); the accept
    pool is APPLIED to all offers - a declared approximation, reported, not hidden."""
    pools = defaultdict(list)
    for e, _, _, rows in train_entries:
        snaps, marks = _owner_marks(e)
        times = [t for t, _, _ in snaps]
        for rid, r in rows.items():
            mk = marks.get(rid)
            if r["rejected"] or mk is None:
                continue
            i = bisect.bisect_right(times, r["sent"]) - 1
            b = _r14_bin(len(snaps[i][2]) if i >= 0 else 0)
            lag = max(mk["admitted_at"] - r["sent"], 0.0)
            for key in ((e["cell"], b), (e["cell"],), ()):
                pools[key].append(lag)
    return {k: sorted(v) for k, v in pools.items()}


def _r14_pool(lags, cell, b):
    for key in ((cell, b), (cell,), ()):
        if len(lags.get(key, ())) >= HAZARD_MIN:
            return lags[key]
    raise ValueError("decision_lag_unsupported")


def r14_simulate(start, plan, arrivals, uniforms, release_uniforms, lag_uniforms, model,
                 costs, offsets, lags, stats=None):
    """v9 (r12_simulate) with ONE change: each offer is decided at its Gateway decision
    instant d = a + lag (lag drawn from the Train pool of its cell and the step-start
    owner-count bin = cost holders incl. members releasing this step), offers within a
    step are decided in d order against R(d), and d is clipped to the step end (the
    offer keeps its arrival step's plan and birth record; clipping counted). Births still
    hold through the birth step (R14 floor audit: not falsified). Arrivals, lag draws and
    uniforms are plan-free; no HTTP residence, no serial GPU time, no eviction."""
    cell, table = model["cell"], model["table"]
    pop = [[ph, tt, cls, i] for i, (ph, tt, cls) in enumerate(start)]
    good_steps, rejected, offers = [0] * ROLLOUT_STEPS, [], []
    n0, ai, max_reserved = len(start), 0, 0.0
    for j in range(ROLLOUT_STEPS):
        batch = r11_batch(((m[0], cell, m[2]) for m in pop), prompt_k=model["prompt_k"])
        hold, releases, nxt = [], [], []
        for ph, tt, cls, idx in pop:
            records, _ = _r11_resolve(table, _r11_keys(cell, cls, ph, tt, batch, True))
            rec = records[min(int(uniforms[idx][j] * len(records)), len(records) - 1)]
            good_steps[j] += rec[2]
            if ph in COST_PHASES:
                c = costs[(cell, cls)]
                if rec[0] in COST_PHASES:
                    hold.append(c)
                else:
                    pool = _r12_pool(offsets, cell, cls)
                    off = pool[min(int(release_uniforms[idx][j] * len(pool)), len(pool) - 1)]
                    releases.append((j * STEP_S + off, c))
            if rec[0] != "GONE":
                nxt.append([rec[0], rec[1], cls, idx])
        releases.sort()
        lag_pool = _r14_pool(lags, cell, _r14_bin(len(hold) + len(releases)))
        end, step_offers = (j + 1) * STEP_S, []
        while ai < len(arrivals) and arrivals[ai][0] <= end + EPS:
            a, cls = arrivals[ai][0], arrivals[ai][1]
            u = lag_uniforms[n0 + ai][0]
            d = a + lag_pool[min(int(u * len(lag_pool)), len(lag_pool) - 1)]
            if d > end:
                d = end
                if stats is not None:
                    stats["v11_lag_clipped_to_step_end"] += 1
            if stats is not None:
                stats["v11_lag_draws"] += 1
            step_offers.append((d, a, cls, n0 + ai))
            offers.append(a)
            ai += 1
        step_offers.sort()
        held, ri, births = math.fsum(hold), 0, []
        for d, a, cls, idx in step_offers:
            while ri < len(releases) and releases[ri][0] <= d + EPS:
                ri += 1
            c = costs[(cell, cls)]
            reserved = held + math.fsum(x for _, x in releases[ri:])
            if reserved + c > plan[j] + EPS:
                rejected.append(a)
            else:
                held += c
                max_reserved = max(max_reserved, reserved + c)
                births.append((cls, int(a - j * STEP_S > STEP_S / 2 + EPS), idx))
        for cls, half, idx in sorted(births, key=lambda x: x[2]):
            records, _ = _r11_resolve(table, _r11_entry_keys(cell, cls, half, batch, True))
            rec = records[min(int(uniforms[idx][j] * len(records)), len(records) - 1)]
            good_steps[j] += rec[2]
            if rec[0] != "GONE":
                nxt.append([rec[0], rec[1], cls, idx])
        pop = nxt
    out = {}
    for h in SIM_HORIZONS:
        n = int(round(h / STEP_S))
        out[f"good_{h:g}"] = float(sum(good_steps[:n]))
        out[f"rejected_{h:g}"] = float(sum(r <= h + EPS for r in rejected))
        out[f"offers_{h:g}"] = float(sum(o <= h + EPS for o in offers))
    out["max_reserved_after_admission"] = max_reserved
    return out


def r14_runs(start, ids, plan, cut, key, model, costs, offsets, lags,
             scenarios=SIM_SCENARIOS, stats=None):
    """v11 with v10 stable identity CRN: member/release streams are EXACTLY the v10
    streams; the lag stream is a separate identity-keyed stream (arrival:<i>)."""
    runs = []
    for i in range(scenarios):
        law = draw_common_law(cut, key, i)
        runs.append(r14_simulate(
            start, plan, law["arrivals"], StableUniforms(R13_SEED + "|member", key, i, ids),
            StableUniforms(R13_SEED + "|release", key, i, ids),
            StableUniforms(R14_SEED + "|lag", key, i, ids), model, costs, offsets, lags,
            stats=stats))
    return runs


def event_lag_extension(train_episodes, eval_episodes, receipts, train_blocks,
                        eval_blocks, train_entries, costs):
    """v11 extension: v10 stable within-step upper/lower (the direct ablation) and v11
    decision-lag upper/lower on the SAME origins, CRN and law; both endpoints carried,
    never selected or averaged. The frozen base predictors are unchanged; the v7 LOWER
    comparator comes from the frozen v9 extension on the same origin mask."""
    v9 = within_step_extension(train_episodes, eval_episodes, receipts, train_blocks,
                               eval_blocks, train_entries, costs)
    offsets = {e: fit_release_offsets(train_entries, e) for e in RELEASE_ENDPOINTS}
    lags = fit_decision_lags(train_entries)
    counts = v9["counts"]

    def respond(start, plan, cut, key, model, costs_, context):
        args = (context["step"], context["rows"], context["cls_of"], context["seen"], cut)
        start2, ids = r13_cut_start(*args, plan, costs_)
        if start2 != start:
            raise ValueError("r13_start_mismatch")
        out = {}
        for e in RELEASE_ENDPOINTS:
            out[f"v10_within_step_{e}"] = _r13_band(r13_runs(
                start, ids, plan, cut, key, model, costs_, True, offsets[e]))
            out[f"v11_event_lag_{e}"] = _r13_band(r14_runs(
                start, ids, plan, cut, key, model, costs_, offsets[e], lags, stats=counts))
        return out

    def quant(v):
        return [v[int(q * (len(v) - 1))] for q in (0.1, 0.5, 0.9, 0.99)]
    describe = dict(seed=R14_SEED, owner_bins=list(R14_OWNER_BINS),
                    decision_lags={"|".join(map(str, k)) or "all":
                                   dict(n=len(v), q10_50_90_99=quant(v))
                                   for k, v in sorted(lags.items(), key=lambda x: str(x[0]))},
                    note="counts: v11 lag draws over both endpoints and all scenarios")
    return dict(schema=EVENT_LAG_VERSION, respond=respond, context=True,
                comparators=v9["comparators"], counts=counts, describe=describe)


# ---------------------------------------------------------------------------
# R15: measured-state audit on Source144 artifacts (tagged native/Gateway join,
# pending-Q proxy, aggregate-ledger interval resolution). Labels only; no fit.
# ---------------------------------------------------------------------------

SOURCE144_AUDIT_VERSION = "nv3-opus-source144-state-audit-r15"
SOURCE144_COMMIT = "144cef32a9b51c3a74355ff67f5eafdfac6e075f"
LEDGER_COST_TOL = 1e-6        # cost equality on the Gateway's own float costs
LEDGER_JOIN_WINDOW_S = 1e-3   # adjacency diagnostic only; never promoted to ownership


def load_source144(directory, manifest=None):
    """Explicit Source144 loader (the legacy loader correctly refuses this schema).
    Every episode artifact is sha256-checked against verified-artifact-sha256.jsonl or,
    for the public smoke archive, its tar manifest. Refuses another source commit,
    a second clock domain, duplicate/missing offered IDs, or a non-train split."""
    root = Path(directory)
    index = json.loads((root / "index.json").read_text())
    if index.get("source_commit") != SOURCE144_COMMIT:
        raise ValueError("source144_commit_mismatch")
    if manifest is None:
        listed = {r["artifact"]: r["sha256"] for r in map(
            json.loads, (root / "verified-artifact-sha256.jsonl").read_text().splitlines())}
    else:
        listed = {f["path"]: f["sha256"] for f in json.loads(Path(manifest).read_text())["files"]}
    for name, digest in listed.items():
        if hashlib.sha256((root / name).read_bytes()).hexdigest() != digest:
            raise ValueError("source144_artifact_hash:" + name)
    clock, episodes = index["clock_domain"], []
    for item in index["episodes"]:
        name = item["artifact"]
        if name not in listed:
            raise ValueError("source144_unverified:" + name)
        d = json.loads((root / name).read_text())
        if d.get("split") != "train":
            raise ValueError("source144_split:" + name)
        ids = [r["request_id"] for r in d["rows"]]
        if len(set(ids)) != len(ids) or set(ids) != set(d["expected_ids"]) or \
                len(d["offered_tape"]) != len(ids):
            raise ValueError("source144_offered_ids:" + name)
        domains = {r["clock_domain"] for r in d["rows"]}
        for f in d["native_frames"]:
            domains.add(f["clock_domain"])
            if f.get("gateway_snapshot"):
                domains.add(f["gateway_snapshot"]["clock_domain"])
        if domains != {clock}:
            raise ValueError("source144_clock_domain:" + name)
        episodes.append(d)
    receipt = dict(source_commit=index["source_commit"], clock_domain=clock,
                   verified_artifacts=len(listed),
                   episodes=[e["episode_id"] for e in episodes],
                   artifact_sha256={k: v for k, v in sorted(listed.items())
                                    if k.endswith(".json") and k.startswith("nv3-")})
    return episodes, receipt


def _s144_snaps(d):
    """Unique Gateway snapshots of this episode's Gateway run, by sequence, with immutable
    owner marks (admitted_at, cost) checked."""
    seen, snaps, marks = set(), [], {}
    for f in d["native_frames"]:
        g = f.get("gateway_snapshot")
        if not g or g["run_id"] != d["gateway_run_id"] or g["sequence"] in seen:
            continue
        seen.add(g["sequence"])
        owners = {}
        for mk in g.get("requests") or ():
            owners[mk["request_id"]] = mk["cost"]
            rec = marks.setdefault(mk["request_id"], dict(admitted_at=mk["admitted_at"],
                                                          cost=mk["cost"],
                                                          first=g["sampled_at"]))
            if abs(rec["admitted_at"] - mk["admitted_at"]) > EPS or \
                    abs(rec["cost"] - mk["cost"]) > EPS:
                raise ValueError("owner_mark_not_immutable")
        snaps.append((g["sampled_at"], float(g["budget"]), owners))
    snaps.sort(key=lambda s: s[0])
    for t, _, owners in snaps:
        for rid in owners:
            marks[rid]["last"] = t
    times = [t for t, _, _ in snaps]
    for rec in marks.values():
        i = bisect.bisect_right(times, rec["last"])
        rec["next"] = times[i] if i < len(times) else None   # release in (last, next]
    return snaps, marks


def _offer_cost(row, marks):
    """Whole original cost of an offered payload: the Gateway's immutable mark for an
    owner, its reported estimate for a 503 admission rejection, else None."""
    if row["request_id"] in marks:
        return marks[row["request_id"]]["cost"]
    if row.get("admission_rejection"):
        return float(row["admission"]["estimated_request_cost"])
    return None


def s144_owner_native_audit(d):
    """Tagged native/Gateway join and owner lifecycle (explicit gateway_request_id only;
    no regex or adjacency). Per frame: G = Gateway owners in the frame's snapshot, N =
    native requests carrying gateway_request_id. Per owner: admitted_at -> native first/
    last visible -> Gateway release interval (last, next] -> client HTTP terminal."""
    c, rows = Counter(), {r["request_id"]: r for r in d["rows"]}
    snaps, marks = _s144_snaps(d)
    native = defaultdict(list)
    for f in d["native_frames"]:
        g = f.get("gateway_snapshot")
        if not f.get("available") or not g:
            c["frames_unavailable"] += 1
            continue
        c["frames"] += 1
        G = {m["request_id"] for m in g.get("requests") or ()}
        N = set()
        for q in f["requests"]:
            gid = q.get("gateway_request_id")
            if gid is None:
                c["native_untagged"] += 1
                continue
            if gid not in rows:
                c["native_tag_not_offered"] += 1
            N.add(gid)
            native[gid].append(f["sampled_at"])
        c["native_running_plus_waiting_ne_listed"] += \
            (f["running"] + f["waiting"]) != len(f["requests"])
        c["frame_owner_slots"] += len(G)
        c["frame_owner_native_visible"] += len(G & N)
        c["frame_owner_not_native_visible"] += len(G - N)
        for gid in N - G:
            m = marks.get(gid)
            if m is None:
                c["native_not_gateway_owner_never_owner"] += 1
            elif f["sampled_at"] > m["last"]:
                c["native_after_gateway_last_snapshot"] += 1
            else:
                c["native_before_gateway_first_snapshot"] += 1
    lag = defaultdict(list)
    for rid, m in marks.items():
        r = rows.get(rid)
        c["owners"] += 1
        if r is None:
            c["owner_not_offered"] += 1
            continue
        if r.get("admission_rejection"):
            c["owner_rejected_by_http"] += 1
        seen = native.get(rid)
        c["owner_native_visible"] += bool(seen)
        if seen:
            lag["native_first_minus_admitted"].append(min(seen) - m["admitted_at"])
            lag["gateway_last_minus_native_last"].append(m["last"] - max(seen))
        if r.get("first_content_at") is not None:
            c["owner_held_past_first_content"] += m["last"] > r["first_content_at"]
        t = r.get("terminal_at")
        if m["next"] is None or t is None:
            c["owner_release_or_terminal_unobserved"] += 1
            continue
        if t <= m["last"]:
            c["terminal_before_last_owner_snapshot"] += 1     # Gateway held after client end
        elif t <= m["next"]:
            c["terminal_inside_release_interval"] += 1
        else:
            c["terminal_after_release_interval"] += 1
        lag["terminal_minus_last_snapshot"].append(t - m["last"])
        lag["next_snapshot_minus_terminal"].append(m["next"] - t)
    offered = Counter(r["request_id"] for r in d["rows"])
    c["offered_duplicate_ids"] = sum(v > 1 for v in offered.values())
    for rid, r in rows.items():
        if r.get("admission_rejection"):
            c["rejected"] += 1
            c["rejected_later_gateway_owner"] += rid in marks
            c["rejected_later_native_visible"] += rid in native
    return c, lag


def s144_pending_proxy_audit(d):
    """Online pending set at grid cuts t0 = start + 0.5k vs its realized fate (labels).
    Pending = offered with sent_at <= t0, not an owner in the last snapshot <= t0, client
    terminal > t0. Proxy (the frozen r11_cut_start rule): previously-seen owner -> Z (no
    cost); else in sent order Q if snapshot stock + Q so far + cost <= snapshot budget.
    Truth: 'released' (seen; client not yet informed), 'admitted' (Gateway owner later),
    'rejected' (503), 'other'. Costs: Gateway mark / reported 503 estimate (both are the
    deterministic Gateway estimator of the client's own payload)."""
    c, rows = Counter(), sorted(d["rows"], key=lambda r: r["sent_at"])
    snaps, marks = _s144_snaps(d)
    times = [t for t, _, _ in snaps]
    for k in range(int(round(d["duration_s"] / STEP_S))):
        t0 = d["start"] + k * STEP_S
        i = bisect.bisect_right(times, t0) - 1
        if i < 0:
            c["cuts_without_snapshot"] += 1
            continue
        ts, budget, owners = snaps[i]
        c["cuts"] += 1
        stock = math.fsum(owners.values())
        q_cost, true_admit_cost = 0.0, 0.0
        for r in rows:
            if r["sent_at"] > t0:
                break
            rid = r["request_id"]
            if rid in owners or (r["terminal_at"] is not None and r["terminal_at"] <= t0):
                continue
            m = marks.get(rid)
            if m is not None and m["first"] <= ts:
                truth = "released"
            elif m is not None:
                truth = "admitted"
            elif r.get("admission_rejection"):
                truth = "rejected"
            else:
                truth = "other"
            c[f"pending|{truth}"] += 1
            if truth == "admitted":
                c["pending_admitted|admitted_at_le_t0"] += m["admitted_at"] <= t0
                true_admit_cost += m["cost"]
            if truth == "released":
                c["proxy_Z|released"] += 1
                continue
            cost = _offer_cost(r, marks)
            if cost is None:
                c["proxy_cost_unknown"] += 1
                continue
            if stock + q_cost + cost <= budget + EPS:
                q_cost += cost
                c[f"proxy_Q|{truth}"] += 1
            else:
                c[f"proxy_drop|{truth}"] += 1
        c["sum_proxy_Q_cost"] += q_cost
        c["sum_true_pending_admitted_cost"] += true_admit_cost
        c["sum_abs_Q_cost_error"] += abs(q_cost - true_admit_cost)
    return c


def load_gateway_journal(path, status_path=None):
    """Gateway telemetry JSONL for one epoch. Records the producer status (closed,
    dropped, write_errors); a missing suffix is NOT detectable from these fields."""
    events = [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]
    status = json.loads(Path(status_path).read_text()) if status_path else None
    return events, status


def s144_ledger_audit(d, events):
    """Aggregate mpc_ledger (no request_id) vs Gateway snapshots of the same run.
    (a) stock equality at each snapshot instant; (b) interval resolution: in each snapshot
    interval (L, U] the ledger's negative deltas must equal the departed owners' costs as
    a multiset (positive deltas = born owners). Where they do, every release TIME is
    identified per (interval, cost) without ownership; the OWNER is identified only when
    its cost is unique among the interval's departures; (c) whole-cost admission check of
    every per-UUID accept/reject event against ledger stock at that instant; (d) release
    position u = (t - L)/(U - L); (e) adjacency diagnostic (never promoted)."""
    run, mine = d["gateway_run_id"], {r["request_id"] for r in d["rows"]}
    led = sorted((e for e in events if e.get("run_id") == run and e["event"] == "mpc_ledger"),
                 key=lambda e: e["sequence"])
    ev = [e for e in events if e.get("run_id") == run and e.get("request_id") in mine]
    c, lag = Counter(), defaultdict(list)
    if not led:
        c["episodes_without_ledger"] += 1
        return c, lag
    lt = [e["effective_at"] for e in led]

    def stock(t):
        i = bisect.bisect_right(lt, t) - 1
        return led[i]["reserved_cost"] if i >= 0 else 0.0
    deltas = [(b["effective_at"], b["reserved_cost"] - a["reserved_cost"])
              for a, b in zip(led, led[1:])]
    snaps, marks = _s144_snaps(d)
    for t, _, owners in snaps:
        c["snapshots"] += 1
        diff = abs(stock(t) - math.fsum(owners.values()))
        c["snapshot_stock_equal"] += diff <= LEDGER_COST_TOL
        if diff > LEDGER_COST_TOL:
            lag["snapshot_stock_abs_diff"].append(diff)

    st = [t for t, _, _ in snaps]
    for k in range(int(round(d["duration_s"] / STEP_S))):
        # staleness of the online snapshot stock at the frozen 0.5 s grid cuts
        t0 = d["start"] + k * STEP_S
        i = bisect.bisect_right(st, t0) - 1
        if i >= 0:
            c["cuts_with_snapshot"] += 1
            gap = stock(t0) - math.fsum(snaps[i][2].values())
            c["cuts_ledger_stock_ne_snapshot_stock"] += abs(gap) > LEDGER_COST_TOL
            lag["cut_ledger_minus_snapshot_stock"].append(gap)
            lag["cut_minus_snapshot_age_s"].append(t0 - st[i])

    def key(x):
        return round(x / LEDGER_COST_TOL)
    dt = [t for t, _ in deltas]
    for (L, _, a), (U, _, b) in zip(snaps, snaps[1:]):
        lo, hi = bisect.bisect_right(dt, L), bisect.bisect_right(dt, U)
        inside = [x for x in deltas[lo:hi] if abs(x[1]) > LEDGER_COST_TOL]
        dep = Counter(key(a[r]) for r in set(a) - set(b))
        born = Counter(key(b[r]) for r in set(b) - set(a))
        neg = Counter(key(-x) for _, x in inside if x < 0)
        pos = Counter(key(x) for _, x in inside if x > 0)
        c["intervals"] += 1
        c["releases_snapshot"] += sum(dep.values())
        if neg != dep or pos != born:
            c["intervals_ledger_ne_snapshot_multiset"] += 1
            c["releases_in_unmatched_intervals"] += sum(dep.values())
            continue
        c["releases_time_identified"] += sum(dep.values())
        c["releases_owner_identified"] += sum(n == 1 for n in dep.values())
        c["intervals_with_births_and_deaths"] += bool(dep) and bool(born)
        for t, x in inside:
            if x < 0:
                lag["release_u_in_interval"].append((t - L) / (U - L))
                lag["release_minus_L"].append(t - L)
                lag["U_minus_release"].append(U - t)
    for e in ev:
        if e["event"] not in ("accepted", "rejected"):
            continue
        s, cost, b = stock(e["monotonic"]), float(e["request_cost"]), float(e["budget"])
        if e["event"] == "accepted":
            c["decisions_accepted"] += 1
            c["violation_accept_stock_after_gt_budget"] += s > b + LEDGER_COST_TOL
        else:
            c["decisions_rejected"] += 1
            c["violation_reject_but_fits"] += s + cost <= b + LEDGER_COST_TOL
    acost = {e["request_id"]: float(e["request_cost"]) for e in ev if e["event"] == "accepted"}
    rows = {r["request_id"]: r for r in d["rows"]}

    def preceding(t):
        # the ledger delta immediately preceding a per-UUID event (adjacency diagnostic)
        i = bisect.bisect_right(dt, t) - 1
        return deltas[i] if i >= 0 else (None, 0.0)
    for e in ev:
        t = e["monotonic"]
        if e["event"] == "completed":
            c["completed_events"] += 1
            pt, x = preceding(t)
            c["adjacency_preceding_delta_equals_minus_cost"] += \
                pt is not None and t - pt <= LEDGER_JOIN_WINDOW_S and \
                abs(x + acost.get(e["request_id"], math.nan)) <= LEDGER_COST_TOL
            r = rows.get(e["request_id"])
            if r and r.get("terminal_at") is not None:
                lag["client_terminal_minus_gateway_completed"].append(r["terminal_at"] - t)
        elif e["event"] == "first_content":
            c["first_content_events"] += 1
            pt, x = preceding(t)
            c["adjacency_first_content_preceding_delta_zero"] += \
                pt is not None and t - pt <= LEDGER_JOIN_WINDOW_S and abs(x) <= LEDGER_COST_TOL
    return c, lag


def s144_ledger_run_checks(events, clock):
    """Once per Gateway run: sequence contiguity, time order, clock domain, row kinds."""
    out = {}
    for run in sorted({e["run_id"] for e in events if e["event"] == "mpc_ledger"}):
        led = sorted((e for e in events if e.get("run_id") == run and
                      e["event"] == "mpc_ledger"), key=lambda e: e["sequence"])
        pairs = list(zip(led, led[1:]))
        out[run] = dict(
            rows=len(led), first_sequence=led[0]["sequence"], last_sequence=led[-1]["sequence"],
            sequence_gaps=sum(b["sequence"] != a["sequence"] + 1 for a, b in pairs),
            time_nonmonotone=sum(b["effective_at"] < a["effective_at"] for a, b in pairs),
            clock_domain_mismatch=sum(e["clock_domain"] != clock for e in led),
            zero_cost_delta_rows=sum(abs(b["reserved_cost"] - a["reserved_cost"]) <=
                                     LEDGER_COST_TOL for a, b in pairs),
            per_uuid_events=dict(sorted(Counter(e["event"] for e in events
                                                if e.get("run_id") == run and
                                                "request_id" in e).items())),
            budget_updated=sum(e["event"] == "budget_updated" for e in events
                               if e.get("run_id") == run))
    return out


def _q(v, qs=(0.01, 0.1, 0.5, 0.9, 0.99)):
    v = sorted(v)
    return dict(n=len(v), **({f"q{int(q * 100):02d}": v[int(q * (len(v) - 1))] for q in qs}
                              if v else {}))


def source144_state_audit(directory, manifest=None, journals=()):
    """Per-block R15 audit; journals: [(telemetry.jsonl, status.json), ...] (optional)."""
    episodes, receipt = load_source144(directory, manifest)
    events, statuses = [], []
    for path, status in journals:
        ev, st = load_gateway_journal(path, status)
        events.extend(ev)
        statuses.append(dict(st or {}, path=Path(path).name,
                             sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest()))
    blocks = defaultdict(lambda: dict(join=Counter(), pending=Counter(), ledger=Counter(),
                                      lags=defaultdict(list)))
    for d in episodes:
        b = blocks[str(d["seed_block"])]
        jc, jl = s144_owner_native_audit(d)
        b["join"].update(jc)
        b["pending"].update(s144_pending_proxy_audit(d))
        for k, v in jl.items():
            b["lags"][k].extend(v)
        if not events:
            b["ledger"]["episodes_without_journal"] += 1
        else:
            lc, ll = s144_ledger_audit(d, events)
            b["ledger"].update(lc)
            for k, v in ll.items():
                b["lags"][k].extend(v)
    out = {}
    for blk, b in sorted(blocks.items()):
        out[blk] = dict(join=dict(sorted(b["join"].items())),
                        pending=dict(sorted(b["pending"].items())),
                        ledger=dict(sorted(b["ledger"].items())),
                        distributions={k: _q(v) for k, v in sorted(b["lags"].items())})
    return dict(schema=SOURCE144_AUDIT_VERSION, receipt=receipt, journals=statuses,
                ledger_runs=s144_ledger_run_checks(events, receipt["clock_domain"]),
                journal_suffix_completeness="unverifiable: status has no final sequence/"
                                            "count/digest (Sol R13)",
                per_block=out, native_permit=False, mpc_result=None, fitted_parameters=None)


# --- R16: owner-journal verifier, v1 ambiguity witness, cost-vs-count support ------------
OWNER_JOURNAL_VERSION = "nv3-opus-owner-journal-verifier-r16"
# Mayor's opt-in owner journal: branch a4ec4e386e68f6ea20b68a8557785fc5813c7b16 (not Source144)
OWNER_JOURNAL_GATEWAY_SHA256 = "21e3b335450a141e0c9c84d15a5f6c46850f9bb219b296a1f7b9929c6caa81f7"
OWNER_JOURNAL_KINDS = ("admission", "first_content", "terminal", "control")
R16_LONG_COST = 3.0      # any p4096 payload costs >= 0.259 + 0.000758*4096 = 3.364


def verify_owner_journal(path, status_path):
    """Fail-closed replay of an owner-resolved (schema-v2) mpc_ledger epoch. Status fields
    alone are NOT trusted: mpc_sequence advances even while telemetry is disabled, so a
    row lost after the final flush leaves 'complete' in-memory state with a gap/short
    file. Requires: closed status, no drops/write errors, exact bytes+SHA, a single run,
    contiguous sequences 1..final, every admission/first_content/terminal row carrying its
    ID, each ID admitted once / at most one first_content / released once at its own
    whole cost, replayed owner stock == reserved_cost and len == running at every row,
    reserved_cost <= budget after each admission, and no owner left at the end."""
    raw = Path(path).read_bytes()
    st = json.loads(Path(status_path).read_text())
    f = Counter()
    f["status_not_closed"] += st.get("status") != "closed"
    f["status_dropped_or_write_errors"] += bool(st.get("dropped") or st.get("write_errors"))
    f["status_schema_not_v2"] += st.get("mpc_ledger_schema_version") != 2
    f["status_ledger_incomplete"] += st.get("mpc_ledger_complete") is not True
    f["status_remaining_owners"] += st.get("mpc_remaining_requests") != 0
    f["file_bytes_mismatch"] += st.get("telemetry_file_bytes") != len(raw)
    f["file_sha256_mismatch"] += st.get("telemetry_file_sha256") != hashlib.sha256(raw).hexdigest()
    rows = [json.loads(x) for x in raw.splitlines() if x.strip()]
    f["foreign_run_rows"] += sum(r.get("run_id") != st.get("run_id") for r in rows)
    led = [r for r in rows if r.get("event") == "mpc_ledger" and r.get("run_id") == st.get("run_id")]
    f["clock_domains_not_single"] += len({r.get("clock_domain") for r in led}) > 1
    seqs = [r["sequence"] for r in led]
    f["sequence_not_from_one"] += bool(seqs) and seqs[0] != 1
    f["sequence_gap_or_reorder"] += sum(b != a + 1 for a, b in zip(seqs, seqs[1:]))
    f["final_sequence_mismatch"] += (seqs[-1] if seqs else 0) != st.get("mpc_final_sequence")
    f["effective_at_decreasing"] += sum(b["effective_at"] < a["effective_at"]
                                        for a, b in zip(led, led[1:]))
    owners, life, seen, controls = {}, {}, set(), []
    for r in led:
        kind, rid, cost = r.get("change_kind"), r.get("request_id"), r.get("request_cost")
        if r.get("ledger_schema_version") != 2 or kind not in OWNER_JOURNAL_KINDS:
            f["row_not_v2_owner_kind"] += 1
            continue
        if kind == "control":
            f["control_row_with_owner"] += rid is not None
            controls.append(dict(effective_at=r["effective_at"], budget=r["budget"],
                                 budget_version=r["budget_version"], sequence=r["sequence"]))
        elif rid is None or cost is None:
            f["owner_row_without_id_or_cost"] += 1
        elif kind == "admission":
            if rid in seen:
                f["duplicate_admission"] += 1
            else:
                seen.add(rid)
                owners[rid] = float(cost)
                life[rid] = dict(cost=float(cost), admitted=r["effective_at"],
                                 first_content=None, terminal=None, budget=r["budget"])
                f["admission_stock_over_budget"] += r["reserved_cost"] > r["budget"] + LEDGER_COST_TOL
        elif rid not in owners:
            f[f"{kind}_without_live_owner"] += 1
        elif kind == "first_content":
            if life[rid]["first_content"] is not None:
                f["duplicate_first_content"] += 1
            life[rid]["first_content"] = r["effective_at"]
        else:
            f["terminal_cost_ne_admitted_cost"] += abs(float(cost) - owners[rid]) > LEDGER_COST_TOL
            life[rid]["terminal"] = r["effective_at"]
            del owners[rid]
        f["replayed_stock_ne_reserved_cost"] += \
            abs(math.fsum(owners.values()) - r["reserved_cost"]) > LEDGER_COST_TOL
        f["replayed_count_ne_running"] += len(owners) != r.get("running")
        f["row_complete_false"] += r.get("complete") is not True
    f["owners_left_after_replay"] += len(owners)
    failures = {k: v for k, v in sorted(f.items()) if v}
    return dict(schema=OWNER_JOURNAL_VERSION, ok=not failures and bool(led), failures=failures,
                run_id=st.get("run_id"), ledger_rows=len(led), owners=len(life),
                owners_with_first_content=sum(v["first_content"] is not None
                                              for v in life.values()),
                budget_controls=controls, lifetimes=life,
                guarantees=dict(fsync=False, authentication=False, mpc_permit=False))


def v1_aggregate_ambiguity_witness():
    """Two owner histories that schema-v1 (aggregate, no request_id) ledger rows plus Gateway
    snapshots cannot distinguish, but whose per-owner lifetimes differ: A and B (equal cost
    2.0) are both owners at snapshot 0.0 and both gone at snapshot 1.0; releases at 0.4 and
    0.6 swap owners. Ages/lifetimes (and any age hazard) are therefore not identified by v1
    even with 100% interval multiset matching; v2 rows carry the owner and resolve it."""
    def rows(order):
        events = [(-0.2, "A", "admission"), (-0.1, "B", "admission"),
                  (0.4, order[0], "terminal"), (0.6, order[1], "terminal")]
        owners, v1, v2 = {}, [], []
        for seq, (t, rid, kind) in enumerate(events, 1):
            if kind == "admission":
                owners[rid] = 2.0
            else:
                owners.pop(rid)
            agg = dict(event="mpc_ledger", sequence=seq, effective_at=t,
                       reserved_cost=math.fsum(owners.values()), running=len(owners),
                       budget=16.0)
            v1.append(agg)
            v2.append(dict(agg, ledger_schema_version=2, change_kind=kind, request_id=rid,
                           request_cost=2.0))
        life = {rid: next(t for t, r, k in events if r == rid and k == "terminal") -
                next(t for t, r, k in events if r == rid and k == "admission") for rid in "AB"}
        return v1, v2, life
    snapshots = [(0.0, {"A": 2.0, "B": 2.0}), (1.0, {})]
    h1, h2 = rows("AB"), rows("BA")
    return dict(v1_rows_identical=h1[0] == h2[0], snapshots_identical=True,
                snapshots=snapshots, v2_rows_identical=h1[1] == h2[1],
                lifetimes_h1=h1[2], lifetimes_h2=h2[2], v2_h1=h1[1], v2_h2=h2[1])


def r16_count_support(episodes):
    """USED descriptive support for COST budget 16/32 vs COUNT: Gateway snapshots by their
    actual budget -> owner count, long (p4096, cost >= 3) owner count, and whether any
    snapshot reached 16 owners or the long-owner count that a count-16 cap would allow."""
    out = defaultdict(lambda: dict(snapshots=0, owners_hist=Counter(), long_max=0,
                                   stock_max=0.0, ge16_owners=0, ge4_long=0, min_long_cost=None,
                                   owners_max=0, stock_gt_budget=0,
                                   ge16_owners_stock_le_budget=0))
    for d in episodes:
        for t, budget, owners in _s144_snaps(d)[0]:
            b = out[f"{budget:g}"]
            n = len(owners)
            longs = [c for c in owners.values() if c >= R16_LONG_COST]
            b["snapshots"] += 1
            b["owners_hist"][min(n, 20)] += 1          # 20 = ">= 20"
            b["long_max"] = max(b["long_max"], len(longs))
            b["stock_max"] = max(b["stock_max"], math.fsum(owners.values()))
            b["ge16_owners"] += n >= 16
            b["ge4_long"] += len(longs) >= 4
            b["owners_max"] = max(b["owners_max"], n)
            over = math.fsum(owners.values()) > budget + LEDGER_COST_TOL
            b["stock_gt_budget"] += over   # non-eviction carry-over after a budget decrease
            b["ge16_owners_stock_le_budget"] += n >= 16 and not over
            if longs:
                lo = min(longs)
                b["min_long_cost"] = lo if b["min_long_cost"] is None else min(lo, b["min_long_cost"])
    res = {}
    for k, b in sorted(out.items()):
        b = dict(b, owners_hist={str(n): v for n, v in sorted(b["owners_hist"].items())})
        if b["min_long_cost"]:
            b["long_owner_cost_bound"] = int(float(k) // b["min_long_cost"])
        res[k] = b
    return res


def r16_decision_contrast(episodes, events):
    """Exact-ledger single-decision contrast (smoke only): at each actual accept/reject, the
    ledger stock s just before the decision and the whole cost c. Under budget 16 vs 32 the
    SAME decision differs only if 16 < s + c <= 32. Later states differ after any contrast,
    so this is a support count for first-slot action value, not a counterfactual path."""
    c = Counter()
    for d in episodes:
        run, mine = d["gateway_run_id"], {r["request_id"] for r in d["rows"]}
        led = sorted((e for e in events if e.get("run_id") == run and e["event"] == "mpc_ledger"),
                     key=lambda e: e["sequence"])
        lt = [e["effective_at"] for e in led]
        for e in events:
            if e.get("run_id") != run or e.get("request_id") not in mine or \
                    e["event"] not in ("accepted", "rejected"):
                continue
            i = bisect.bisect_right(lt, e["monotonic"]) - 1
            # an accept's own +cost row precedes its per-UUID event: use the stock before it
            if e["event"] == "accepted":
                i -= 1
            s = led[i]["reserved_cost"] if i >= 0 else 0.0
            x = s + float(e["request_cost"])
            zone = "both_accept" if x <= 16 + LEDGER_COST_TOL else \
                "contrast_16_32" if x <= 32 + LEDGER_COST_TOL else "both_reject"
            c[f"{d['cell']}|budget{float(e['budget']):g}|{e['event']}|{zone}"] += 1
            c[f"all|{zone}"] += 1
            c["consistent_with_actual_budget"] += \
                (x <= float(e["budget"]) + LEDGER_COST_TOL) == (e["event"] == "accepted")
            c["decisions"] += 1
    return dict(sorted(c.items()))


def r16_support(used_dir, smoke=None):
    used, used_receipt = load_source144(used_dir)
    out = dict(schema=OWNER_JOURNAL_VERSION, used_receipt=used_receipt,
               used_count_support=r16_count_support(used),
               v1_ambiguity_witness=v1_aggregate_ambiguity_witness(),
               native_permit=False, mpc_result=None, fitted_parameters=None)
    if smoke:
        directory, manifest, journals = smoke
        eps, rec = load_source144(directory, manifest)
        events = [e for j, s in journals for e in load_gateway_journal(j, s)[0]]
        out.update(smoke_receipt=rec, smoke_count_support=r16_count_support(eps),
                   smoke_decision_contrast=r16_decision_contrast(eps, events))
    return out


# --- R17: written-journal source qualification + Source144 count-16 baseline feasibility --
OWNER_WRITTEN_VERSION = "nv3-opus-owner-written-journal-r17"
# Mayor branch mpc-native-owner-written-journal d1bd1e5 (NOT Source144, NOT a4ec4e3)
OWNER_WRITTEN_GATEWAY_SHA256 = "23aef8b8b903eda99ea325fd8ece09d998c174df39f2d1230ed5b9cc37e4ce3a"
OWNER_TELEMETRY_SHA256 = "46d6fb923e558f6435d269dd6fa5cfd5b0d71eb1fd91cbb3aaca8a82385e6370"
OWNER_CONTRACTS_SHA256 = "f39f6b73b41b1433a220f182679852df5c4332d9022ce903dba9863375236e23"
SOURCE144_GATEWAY_SHA256 = "a4a8229b0f636b64c945881d062c3ee925ef5fccc5ba2e6fc7629657d3575ea7"
SOURCE144_LAUNCHER_SHA256 = "cce5f87c37b5d0a6009d68b6311d8e20f61f066630d7039ea46ebd75a0563d59"
SOURCE144_COLLECTOR_SHA256 = "78e2c8b91f6b4a582feb69293adff5aa34d4fbd332dfa93b92735bcd0275a069"
R17_OUTCOMES = ("completed", "failed", "cancelled")


def _sha_required(path, digest, label):
    raw = Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError(label + "_sha256_mismatch")
    return raw.decode()


def _ast_top(tree, name):
    import ast
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) \
                and node.name == name:
            return node
        if isinstance(node, ast.Assign) and any(getattr(t, "id", None) == name
                                                for t in node.targets):
            return node
        if isinstance(node, ast.AnnAssign) and getattr(node.target, "id", None) == name:
            return node
    raise ValueError("ast_node_missing:" + name)


def _ast_exec(nodes, ns, label):
    import ast
    module = ast.Module(body=list(nodes), type_ignores=[])
    ast.fix_missing_locations(module)
    exec(compile(module, label, "exec"), ns)


def _asyncio_proxy(hooks, calls):
    """asyncio with to_thread running the callable inline, then (optionally) an injected
    coroutine standing for work the event loop ran during that real thread await."""
    import asyncio
    import types
    proxy = types.SimpleNamespace(**{n: getattr(asyncio, n) for n in dir(asyncio)
                                     if not n.startswith("__")})

    async def to_thread(fn, *args, **kwargs):
        result = fn(*args, **kwargs)
        calls.append(getattr(fn, "__name__", "?"))
        hook = hooks.pop(0) if hooks else None
        if hook is not None:
            await hook()
        return result
    proxy.to_thread = to_thread
    return proxy


class OwnerJournalHarness:
    """Executes the ACTUAL AST nodes of a pinned Gateway/telemetry source on CPU without
    FastAPI/HTTP: Telemetry class, AdmissionDecision, state/state_lock, mpc_now,
    mpc_changed, mpc_first_content, begin_request, finish_request and the complete
    lifespan `finally` shutdown body (final_drain + status + persist_status seal).
    Transcribed (not executed source): the caller order received -> begin_request ->
    admitted/terminal('rejected') from _proxy_completions, finish_request -> terminal(outcome)
    from cleanup, the budget mutation of update_budget, and lifespan startup's
    enabled/owner_ledger flags; snapshot_metrics is a stub returning {}."""

    def __init__(self, gateway_path, telemetry_path, contracts_path, workdir,
                 gateway_sha256=OWNER_WRITTEN_GATEWAY_SHA256, prefix_rows=()):
        import ast
        import dataclasses
        import importlib.util
        import time
        import types
        import typing
        import uuid
        from collections import deque
        gsrc = _sha_required(gateway_path, gateway_sha256, "gateway")
        tsrc = _sha_required(telemetry_path, OWNER_TELEMETRY_SHA256, "telemetry")
        _sha_required(contracts_path, OWNER_CONTRACTS_SHA256, "contracts")
        spec = importlib.util.spec_from_file_location("nv3_r17_contracts", contracts_path)
        contracts = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = contracts
        bytecode, sys.dont_write_bytecode = sys.dont_write_bytecode, True
        try:
            spec.loader.exec_module(contracts)
        finally:
            sys.modules.pop(spec.name, None)
            sys.dont_write_bytecode = bytecode
        work = Path(workdir)
        work.mkdir(parents=True, exist_ok=True)
        self.log, self.status = work / "gateway-telemetry.jsonl", work / "gateway-status.json"
        with self.log.open("w", encoding="utf-8") as handle:     # lifespan opens with "a"
            for row in prefix_rows:
                handle.write(json.dumps(row) + "\n")
        self.hooks, self.calls = [], []
        aio = _asyncio_proxy(self.hooks, self.calls)
        ns = dict(asyncio=aio, hashlib=hashlib, json=json, math=math, time=time, Path=Path,
                  uuid=uuid, Counter=Counter, defaultdict=defaultdict, deque=deque,
                  asdict=dataclasses.asdict, dataclass=dataclasses.dataclass,
                  replace=dataclasses.replace, Any=typing.Any, Dict=typing.Dict,
                  Optional=typing.Optional, RequestMark=contracts.RequestMark,
                  MPC_LAB_ENABLED=True, MPC_OWNER_LEDGER_ENABLED=True,
                  ADMISSION_MODE="cost_aware", MAX_ADMITTED_COST=32.0, DIAGNOSTICS_SCHEMA=None,
                  TELEMETRY_JSONL=str(self.log), TELEMETRY_STATUS_JSON=str(self.status),
                  mpc_clock_domain="cpu-r17-witness",
                  mpc_identity=contracts.Identity("cpu-witness", "unfitted", "none", "none",
                                                  "none"),
                  stop=None, lag_task=None, task=None, shared_client=None, started=True,
                  app=types.SimpleNamespace(state=types.SimpleNamespace()))
        ttree, gtree = ast.parse(tsrc), ast.parse(gsrc)
        _ast_exec([_ast_top(ttree, "Telemetry")], ns, "telemetry.py")
        _ast_exec([_ast_top(gtree, n) for n in (
            "AdmissionDecision", "state_lock", "state", "mpc_requests", "mpc_sequence",
            "mpc_now", "mpc_changed", "mpc_first_content", "begin_request", "finish_request")],
            ns, "gateway.py")
        life = _ast_top(gtree, "lifespan")
        final = next(n for n in ast.walk(life) if isinstance(n, ast.Try) and n.finalbody)
        shutdown = ast.AsyncFunctionDef(
            name="_r17_shutdown", args=ast.arguments(posonlyargs=[], args=[], kwonlyargs=[],
                                                     kw_defaults=[], defaults=[]),
            body=final.finalbody, decorator_list=[], returns=None, type_params=[])
        _ast_exec([shutdown], ns, "gateway.py:lifespan.finally")

        async def snapshot_metrics():
            return {}
        ns["snapshot_metrics"] = snapshot_metrics
        tel = ns["Telemetry"]()
        tel.owner_ledger_enabled = True
        tel.enabled = True
        ns["telemetry"] = tel
        self.ns, self.shutdown_error = ns, None

    async def offer(self, rid, cost, mark=True):
        ns, tel = self.ns, self.ns["telemetry"]
        tel.received(rid)
        decision = await ns["begin_request"](cost, False, None, mpc_mark=(
            (rid, ns["mpc_now"](), 1, 1) if mark else None))
        if decision.accepted:
            tel.admitted(rid, request_cost=cost, estimated_input_tokens=1, max_output_tokens=1,
                         budget=decision.budget, budget_version=decision.budget_version)
        else:
            tel.terminal(rid, "rejected", budget=decision.budget,
                         budget_version=decision.budget_version, estimated_input_tokens=1,
                         max_output_tokens=1, request_cost=cost)
        return decision.accepted

    async def first(self, rid):
        await self.ns["mpc_first_content"](rid)
        self.ns["telemetry"].first_content(rid)

    async def finish(self, rid, cost, outcome="completed"):
        await self.ns["finish_request"](cost, request_id=rid)
        self.ns["telemetry"].terminal(rid, outcome)

    async def set_budget(self, budget):
        ns = self.ns
        async with ns["state_lock"]:
            ns["state"]["admission_budget"] = budget
            ns["state"]["budget_version"] += 1
            ns["mpc_changed"]()

    async def flush(self):
        await self.ns["telemetry"].flush(str(self.log))

    async def close(self, hooks=()):
        import asyncio
        self.ns["stop"] = asyncio.Event()
        self.hooks[:] = list(hooks)
        try:
            await self.ns["_r17_shutdown"]()
        except Exception as exc:      # the actual body raises on lost telemetry/errors
            self.shutdown_error = type(exc).__name__ + ": " + str(exc)
        return json.loads(self.status.read_text())

    def rows(self):
        return [json.loads(x) for x in self.log.read_text().splitlines() if x.strip()]


def verify_owner_written_journal(path, status_path):
    """Fail-closed OFFLINE replay for the d1bd1e5 written-seal schema only (a4ec4e3 status
    lacks the written/producer/unflushed fields and is refused). Beyond verify_owner_journal:
    the producer and last-written sequences must agree with the written row count and zero
    unflushed rows; EVERY row (not only mpc_ledger) must carry the sealed run_id (append-mode
    mixing of foreign non-ledger rows passes the Gateway's own ledger-only contiguity check);
    every offered ID gets exactly one decision; accepts must be the ledger admissions; each
    budget rejection is replayed in emit order against the ledger stock (R+c > B) and an
    owner-ledger refusal is attributed only through its adjacent 'rejected' row; each
    admitted ID has exactly one client-facing outcome AFTER its ledger terminal. Results are
    retrospective labels: no online cut, fsync, authentication or MPC permit."""
    raw = Path(path).read_bytes()
    st = json.loads(Path(status_path).read_text())
    base = verify_owner_journal(path, status_path)
    f = Counter(base["failures"])
    need = ("mpc_producer_final_sequence", "mpc_final_sequence", "mpc_ledger_rows_written",
            "mpc_unflushed_records")
    f["status_not_written_seal_schema"] += any(k not in st for k in need)
    rows = [json.loads(x) for x in raw.splitlines() if x.strip()]
    run = st.get("run_id")
    led = [r for r in rows if r.get("event") == "mpc_ledger" and r.get("run_id") == run]
    last = led[-1]["sequence"] if led else 0
    f["producer_ne_written_sequence"] += st.get("mpc_producer_final_sequence") != last
    f["rows_written_ne_ledger_rows"] += st.get("mpc_ledger_rows_written") != len(led)
    f["status_unflushed_records"] += st.get("mpc_unflushed_records") != 0
    owners, budget, offered, decided = {}, None, [], {}
    accepted_tel, outcome, released, refusals, margins = set(), Counter(), set(), [], []
    pending_refusal = False
    for r in rows:
        if r.get("run_id") != run:
            continue
        event, rid = r.get("event"), r.get("request_id")
        if pending_refusal and event != "rejected":
            f["refusal_unattributed"] += 1
            pending_refusal = False
        if event == "mpc_ledger" and r.get("ledger_schema_version") == 2:
            kind, cost = r.get("change_kind"), r.get("request_cost")
            before = math.fsum(owners.values())
            if kind == "admission" and rid is not None and cost is not None:
                f["admission_before_plus_cost_over_budget"] += \
                    before + float(cost) > r["budget"] + LEDGER_COST_TOL
                owners[rid] = float(cost)
                decided.setdefault(rid, []).append("accepted")
            elif kind == "terminal" and rid in owners:
                del owners[rid]
                released.add(rid)
            budget = r["budget"]
        elif event == "received":
            offered.append(rid)
        elif event == "accepted":
            accepted_tel.add(rid)
            f["accepted_without_prior_admission_row"] += rid not in owners
        elif event == "mpc_owner_ledger_refused":
            f["refusal_unattributed"] += pending_refusal
            pending_refusal = True
        elif event == "rejected":
            decided.setdefault(rid, []).append("rejected")
            cost, stock = r.get("request_cost"), math.fsum(owners.values())
            if pending_refusal:
                refusals.append(dict(request_id=rid, stock_before=stock, request_cost=cost,
                                     budget=r.get("budget")))
                pending_refusal = False
            else:
                f["reject_budget_ne_ledger_budget"] += budget is not None and \
                    r.get("budget") != budget
                margin = stock + float(cost) - float(r.get("budget"))
                f["budget_reject_within_budget"] += margin <= LEDGER_COST_TOL
                margins.append(margin)
        elif event in R17_OUTCOMES:
            outcome[event] += 1
            f["outcome_before_ledger_terminal"] += rid not in released
            f["duplicate_outcome"] += decided.setdefault(rid, []).count(event) > 0
            decided[rid].append(event)
    f["refusal_unattributed"] += pending_refusal
    f["offered_id_duplicate"] += len(offered) - len(set(offered))
    admitted = {k for k, v in decided.items() if "accepted" in v}
    f["offer_without_single_decision"] += sum(
        sum(x in ("accepted", "rejected") for x in decided.get(k, [])) != 1 for k in offered)
    f["decision_without_offer"] += len(set(decided) - set(offered))
    f["accepted_telemetry_ne_admissions"] += accepted_tel != admitted
    f["admitted_without_single_outcome"] += sum(
        sum(x in R17_OUTCOMES for x in decided[k]) != 1 for k in admitted)
    failures = {k: v for k, v in sorted(f.items()) if v}
    return dict(schema=OWNER_WRITTEN_VERSION, ok=not failures and bool(led), failures=failures,
                run_id=run, ledger_rows=len(led), offered=len(offered),
                accepted=len(admitted), budget_rejections=len(margins),
                owner_ledger_refusals=refusals, outcomes=dict(sorted(outcome.items())),
                min_budget_reject_margin=min(margins) if margins else None,
                lifetimes=base["lifetimes"], budget_controls=base["budget_controls"],
                online_cut_available=False,
                guarantees=dict(fsync=False, authentication=False, mpc_permit=False))


def r17_written_seal_witness(new_root, old_root, workdir):
    """Executes the ACTUAL pinned d1bd1e5 (and, for comparison, a4ec4e3) Gateway/telemetry
    nodes through scripted CPU scenarios; no HTTP, FastAPI, vLLM or GPU."""
    import asyncio
    work = Path(workdir)
    new = [Path(new_root) / n for n in ("gateway.py", "telemetry.py", "mpc_lab/contracts.py")]
    old = [Path(old_root) / n for n in ("gateway.py", "telemetry.py", "mpc_lab/contracts.py")]

    def harness(name, root=new, sha=OWNER_WRITTEN_GATEWAY_SHA256, prefix=()):
        return OwnerJournalHarness(*root, work / name, gateway_sha256=sha, prefix_rows=prefix)

    def outcome(h, status, extra=None):
        out = dict(status=status.get("status"), shutdown_error=h.shutdown_error,
                   status_complete=status.get("mpc_ledger_complete"),
                   status_final_sequence=status.get("mpc_final_sequence"),
                   status_producer_final_sequence=status.get("mpc_producer_final_sequence"),
                   status_unflushed=status.get("mpc_unflushed_records"),
                   file_ledger_rows=sum(r.get("event") == "mpc_ledger" for r in h.rows()),
                   to_thread_calls=list(h.calls))
        v = verify_owner_written_journal(h.log, h.status) if "mpc_unflushed_records" in status \
            else verify_owner_journal(h.log, h.status)
        out.update(verifier=v["schema"], verifier_ok=v["ok"], verifier_failures=v["failures"])
        out.update(extra or {})
        return out

    async def lifecycle(h, finish_a=True):
        await h.set_budget(32.0)
        a = await h.offer("a" * 32, 5.0)
        b = await h.offer("b" * 32, 20.0)
        c = await h.offer("c" * 32, 10.0)       # 25 + 10 > 32: budget rejection
        await h.set_budget(16.0)                 # non-eviction: stock 25 > 16 retained
        await h.first("a" * 32)
        await h.first("b" * 32)
        await h.flush()
        if finish_a:
            await h.finish("a" * 32, 5.0)
        return dict(accepted_a=a, accepted_b=b, accepted_c=c)

    async def run():
        res = {}
        h = harness("clean")
        d = await lifecycle(h)
        await h.finish("b" * 32, 20.0)
        res["clean_new"] = outcome(h, await h.close(), d)
        hb = h
        for label, root, sha in (("late_terminal_first_final_flush_new", new,
                                  OWNER_WRITTEN_GATEWAY_SHA256),
                                 ("late_terminal_first_final_flush_a4ec", old,
                                  OWNER_JOURNAL_GATEWAY_SHA256)):
            h = harness(label, root, sha)
            await lifecycle(h)

            async def late(h=h):
                await h.finish("b" * 32, 20.0)
            res[label] = outcome(h, await h.close([late]))
        # one late row needs no second flush, so the next thread await is persist_status:
        # B's terminal lands after the status capture (B still in flight -> failed)
        h = harness("terminal_after_status_capture_new")
        await lifecycle(h)

        async def late2(h=h):
            await h.finish("b" * 32, 20.0)
        res["terminal_after_status_capture_new"] = outcome(h, await h.close([None, late2]))
        # A ends during flush 1 (forcing flush 2), B ends during flush 2 -> unflushed row
        h = harness("late_terminals_both_final_flushes_new")
        await lifecycle(h, finish_a=False)

        async def late_a(h=h):
            await h.finish("a" * 32, 5.0)

        async def late_b(h=h):
            await h.finish("b" * 32, 20.0)
        res["late_terminals_both_final_flushes_new"] = outcome(h, await h.close([late_a, late_b]))
        foreign = dict(event="snapshot", run_id="f" * 32, timestamp=0.0, monotonic=0.0)
        h = harness("append_foreign_nonledger_row_new", prefix=[foreign])
        await lifecycle(h)
        await h.finish("b" * 32, 20.0)
        res["append_foreign_nonledger_row_new"] = outcome(h, await h.close())
        h = harness("append_foreign_ledger_row_new", prefix=[dict(
            foreign, event="mpc_ledger", sequence=1, ledger_schema_version=2)])
        await lifecycle(h)
        await h.finish("b" * 32, 20.0)
        res["append_foreign_ledger_row_new"] = outcome(h, await h.close())
        h = harness("none_mark_and_closing_refusal_new")
        await h.set_budget(32.0)
        none_mark = await h.offer("d" * 32, 1.0, mark=False)
        h.ns["telemetry"].owner_ledger_closing = True
        closing = await h.offer("e" * 32, 1.0)
        res["none_mark_and_closing_refusal_new"] = outcome(h, await h.close(), dict(
            accepted_none_mark=none_mark, accepted_while_closing=closing,
            refusal_rows=[{k: r.get(k) for k in ("event", "reason", "request_id")}
                          for r in h.rows() if r.get("event") == "mpc_owner_ledger_refused"]))
        tampered = work / "clean-reject-cost-tampered.jsonl"
        rows = hb.rows()
        for r in rows:
            if r.get("event") == "rejected":
                r["request_cost"] = 1.0          # 25 + 1 <= 32 would have been admitted
        tampered.write_text("".join(json.dumps(r) + "\n" for r in rows))
        st = json.loads(hb.status.read_text())
        raw = tampered.read_bytes()
        st.update(telemetry_file_bytes=len(raw),
                  telemetry_file_sha256=hashlib.sha256(raw).hexdigest())
        tampered_status = work / "clean-reject-cost-tampered.status.json"
        tampered_status.write_text(json.dumps(st))
        v = verify_owner_written_journal(tampered, tampered_status)
        res["reseal_tampered_reject_cost"] = dict(verifier_ok=v["ok"],
                                                  verifier_failures=v["failures"])
        return res
    return dict(schema=OWNER_WRITTEN_VERSION, sources=dict(
        new_gateway=OWNER_WRITTEN_GATEWAY_SHA256, old_gateway=OWNER_JOURNAL_GATEWAY_SHA256,
        telemetry=OWNER_TELEMETRY_SHA256, contracts=OWNER_CONTRACTS_SHA256),
        executed=("Telemetry", "AdmissionDecision", "state", "state_lock", "mpc_changed",
                  "mpc_first_content", "begin_request", "finish_request",
                  "lifespan.finally(final_drain,status,persist_status)"),
        transcribed=("caller order of _proxy_completions/cleanup", "update_budget mutation",
                     "lifespan startup flags", "snapshot_metrics stub {}"),
        scenarios=asyncio.run(run()), online_cut_available=False, native_permit=False)


def r17_count16_feasibility(gateway144, launcher144, collector144, new_gateway):
    """Can the ACTUAL Source144 stack run a true unchanged FixedConcurrency16 ('protected',
    request-count semaphore) baseline? Executes the actual 144 mpc_access/begin_request/
    finish_request AST nodes on CPU and reads the actual launcher/collector ASTs; no
    count axis is added to any parent code and no cost spec is renamed to a count."""
    import ast
    import asyncio
    import types
    import typing
    g = _sha_required(gateway144, SOURCE144_GATEWAY_SHA256, "source144_gateway")
    launch = _sha_required(launcher144, SOURCE144_LAUNCHER_SHA256, "source144_launcher")
    coll = _sha_required(collector144, SOURCE144_COLLECTOR_SHA256, "source144_collector")
    newg = _sha_required(new_gateway, OWNER_WRITTEN_GATEWAY_SHA256, "owner_written_gateway")
    gtree, ltree, ctree, ntree = map(ast.parse, (g, launch, coll, newg))
    # launcher: forced gateway environment vs configurable keys; native scheduler limits
    forced, allowed, update_line, allow_line, vllm = {}, (), None, None, []
    for node in ast.walk(ltree):
        if isinstance(node, ast.Call) and getattr(node.func, "attr", None) == "update" \
                and any(k.arg == "ADMISSION_MODE" for k in node.keywords):
            forced = {k.arg: k.value.value for k in node.keywords
                      if isinstance(k.value, ast.Constant)}
            update_line = node.lineno
        if isinstance(node, ast.Assign) and getattr(node.targets[0], "id", None) == "allowed":
            allowed = tuple(e.value for e in node.value.elts)
        if isinstance(node, ast.For) and getattr(node.iter, "id", None) == "allowed":
            allow_line = node.lineno
        if isinstance(node, ast.Assign) and getattr(node.targets[0], "id", None) == "command" \
                and isinstance(node.value, ast.List) and any(
                    isinstance(e, ast.Constant) and e.value == "--max-num-seqs"
                    for e in node.value.elts):
            vllm = [e.value for e in node.value.elts if isinstance(e, ast.Constant)]
    native = {vllm[i]: vllm[i + 1] for i in range(len(vllm) - 1)
              if vllm[i] in ("--max-num-seqs", "--max-num-batched-tokens")}
    launcher = dict(gateway_env_forced=forced, config_allow_list=list(allowed),
                    count_keys_configurable=[k for k in ("ADMISSION_MODE", "MAX_IN_FLIGHT",
                                                         "MAX_WAITING") if k in allowed],
                    forced_update_after_allow_loop=bool(update_line and allow_line
                                                        and update_line > allow_line),
                    native_scheduler=native)
    # collector: required endpoints and action alphabet
    consts = Counter(n.value for n in ast.walk(ctree) if isinstance(n, ast.Constant)
                     and isinstance(n.value, str) and n.value.startswith("/"))
    choices = [c for c in (tuple(getattr(e, "value", None) for e in n.args[0].elts)
                           for n in ast.walk(ctree) if isinstance(n, ast.Call)
                           and getattr(n.func, "attr", None) == "choice" and n.args
                           and isinstance(n.args[0], ast.Tuple))
               if all(isinstance(x, (int, float)) for x in c)]
    collector = dict(endpoint_literals=dict(sorted(consts.items())), action_choices=choices,
                     uses_cas_actuator="GuardedActuator" in coll,
                     count_arm_present="MAX_IN_FLIGHT" in coll or "protected" in coll)
    # gateway: execute actual nodes
    defaults = {}
    for node in gtree.body:
        if isinstance(node, ast.Assign) and getattr(node.targets[0], "id", None) in (
                "MAX_IN_FLIGHT", "MAX_WAITING"):
            call = node.value.args[0]
            defaults[node.targets[0].id] = int(call.args[1].value)

    class _Resp:
        def __init__(self, content, status_code=200, headers=None):
            self.status_code, self.detail = status_code, content.get("detail")

    def namespace(mode, max_in_flight, budget):
        ns = dict(asyncio=asyncio, math=math, os=types.SimpleNamespace(getenv=lambda k, d=None: d),
                  secrets=__import__("secrets"), JSONResponse=_Resp, dataclass=__import__(
                      "dataclasses").dataclass, Optional=typing.Optional, Any=typing.Any,
                  Dict=typing.Dict, ADMISSION_MODE=mode, MAX_IN_FLIGHT=max_in_flight,
                  MAX_WAITING=defaults["MAX_WAITING"], MAX_ADMITTED_COST=budget,
                  MPC_LAB_ENABLED=False, ADMIN_API_KEY="k")
        _ast_exec([_ast_top(gtree, n) for n in (
            "MAX_OUTSTANDING", "AdmissionDecision", "state_lock", "sem", "state",
            "begin_request", "finish_request", "mpc_access")], ns, "source144:gateway.py")
        return ns

    def access(mode):
        ns = namespace(mode, 16, 32.0)
        ns["MPC_LAB_ENABLED"] = True
        req = types.SimpleNamespace(headers={"x-admin-api-key": "k"})
        r = ns["mpc_access"](req)
        return None if r is None else dict(status_code=r.status_code, detail=r.detail)

    async def burst(mode, cap, cost, n=20):
        ns = namespace(mode, cap, float(cap))
        tasks = [asyncio.ensure_future(ns["begin_request"](cost, False)) for _ in range(n)]
        await asyncio.sleep(0)
        await asyncio.sleep(0)
        done = [t.result().accepted for t in tasks if t.done()]
        snap = dict(offers=n, cost_argument=cost, returned_accepted=sum(done),
                    returned_rejected=len(done) - sum(done),
                    blocked_in_gateway_queue=sum(not t.done() for t in tasks),
                    in_flight=ns["state"]["current_in_flight"],
                    waiting=ns["state"]["current_waiting"],
                    accepted_counter=ns["state"]["accepted_requests"])
        if mode == "protected":
            await ns["finish_request"](cost)
            await asyncio.sleep(0)
            await asyncio.sleep(0)
            snap["after_one_finish"] = dict(in_flight=ns["state"]["current_in_flight"],
                                            waiting=ns["state"]["current_waiting"])
        for t in tasks:
            t.cancel()
        return snap

    proxy = _ast_top(gtree, "_proxy_completions")
    tag_if = next(n for n in ast.walk(proxy) if isinstance(n, ast.If) and any(
        isinstance(c, ast.Constant) and c.value == "pr33_gateway_request_id"
        for c in ast.walk(n)) and not isinstance(n.test, ast.Compare))
    tag_names = sorted({n.id for n in ast.walk(tag_if.test) if isinstance(n, ast.Name)})
    tag_active = eval(compile(ast.Expression(tag_if.test), "tag", "eval"), dict(
        MPC_LAB_ENABLED=True, upstream_path="/v1/chat/completions", payload={},
        isinstance=isinstance, dict=dict, ADMISSION_MODE="protected"))
    cost_if = next(n for n in ast.walk(proxy) if isinstance(n, ast.If) and any(
        isinstance(c, ast.Name) and c.id == "estimate_request_cost" for c in ast.walk(n)))
    routes = {}
    for node in gtree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for dec in node.decorator_list:
                if isinstance(dec, ast.Call) and dec.args and isinstance(dec.args[0], ast.Constant):
                    routes[dec.args[0].value] = dict(
                        mpc_access_gate=any(isinstance(c, ast.Name) and c.id == "mpc_access"
                                            for c in ast.walk(node)),
                        admission_mode_gate=any(isinstance(c, ast.Name) and c.id ==
                                                "ADMISSION_MODE" for c in ast.walk(node)))
    owner_guard = next(n for n in ntree.body if isinstance(n, ast.If) and "Owner ledger requires"
                       in ast.unparse(n))
    owner_guard_raises = eval(compile(ast.Expression(owner_guard.test), "guard", "eval"), dict(
        MPC_OWNER_LEDGER_ENABLED=True, MPC_LAB_ENABLED=True, ADMISSION_MODE="protected"))

    async def bursts():
        return dict(protected16_cost1e6=await burst("protected", 16, 1e6),
                    cost_aware16_cost1e6=await burst("cost_aware", 16, 1e6))
    gateway = dict(defaults=defaults, mpc_access=dict(cost_aware=access("cost_aware"),
                                                      protected=access("protected")),
                   executed_bursts=asyncio.run(bursts()),
                   uuid_tag_injection=dict(test_names=tag_names, active_in_protected=tag_active),
                   whole_cost_estimate_gate=ast.unparse(cost_if.test),
                   routes=routes)
    blockers = []
    if forced.get("ADMISSION_MODE") == "cost_aware" and not launcher["count_keys_configurable"]:
        blockers.append("launcher_forces_cost_aware_and_count_keys_not_configurable")
    if (gateway["mpc_access"]["protected"] or {}).get("status_code") == 409 and \
            "/admin/mpc/state" in consts:
        blockers.append("collector_requires_/admin/mpc/state_which_is_409_in_protected")
    if choices and all(set(c) <= {16, 32} for c in choices) and not collector["count_arm_present"]:
        blockers.append("collector_action_alphabet_is_cost_budget_16_32_cas_only")
    if owner_guard_raises:
        blockers.append("owner_written_journal_requires_cost_aware(no_Q1_Q5_for_count_arm)")
    return dict(schema=OWNER_WRITTEN_VERSION, sources=dict(
        gateway144=SOURCE144_GATEWAY_SHA256, launcher144=SOURCE144_LAUNCHER_SHA256,
        collector144=SOURCE144_COLLECTOR_SHA256, owner_written_gateway=OWNER_WRITTEN_GATEWAY_SHA256),
        launcher=launcher, collector=collector, gateway=gateway,
        owner_journal_guard_raises_in_protected=owner_guard_raises,
        runnable_unchanged=not blockers, blockers=blockers,
        gateway_code_path_exists=True, native_permit=False, gpu_ranking=None,
        count_axis_added_to_parent=False)


# --- R18: H16 source/protocol binding (Train 43/44 measurement only) + run verifier ---------
H16_VERSION = "nv3-opus-h16-binding-r18"
H16_PROTOCOL_SHA256 = "ab883c90e85b9ec61967499841ce9de5942f11d916372f1b40824866750608da"
H16_SOURCE_COMMIT = "104e65a69df73997b977bce2588b655ae714f45d"
H16_GATEWAY_SHA256 = "0b1a80ade258d8875ba80a072c4f360bfa5d4a7ac312bd222c0571380b341570"
H16_EXTENSION_COMMIT = "a577de3fa8b11c2954765fad176fdb4047b7d4c5"
H16_EXTENSION_SHA256 = "7bedff0aa2097a30938cb4e19744e86da86c7999cb7bab950ba2d93fe2f1a1ac"
H16_EXTENSION_PATH = "experiments/mpc-research/native-v3/prospective_identification.py"
H16_LEGACY_PATH = "experiments/mpc-research/native-v3/collect_identification.py"
H16_LAUNCHER_PATH = "experiments/mpc-research/native-v2/launch_batch_service.py"
H16_BLOCKS = (181043, 181044)
# contracts.implementation_hash (mpc_lab/*.py + gateway.py + telemetry.py + live_http.py) of
# each exact source tree; Source144 reproduces the USED 15/16 index value ed8a6a53.
H16_IMPLEMENTATION_HASH = "5523315c5c59083834f92ec08245c849711c7f097c1d6a629c66770e41fb3eea"
H16_REFUSED_IMPLEMENTATIONS = {
    "ed8a6a537b7b663f44f4d6ed42d9679fe88048b4077c25dd778b6e8cf418a014": "source144_144cef3",
    "50faabdb9ed551315bbba5d34c5dee502c0cd4a68446b0fbba951a83079c654c": "owner_journal_a4ec4e3",
    "2aa608074a96f321a69fd3546cf2580bf1ae02e90a8a2e8b9fb49878d468a658": "owner_written_d1bd1e5",
}
H16_REFUSED_GATEWAYS = {SOURCE144_GATEWAY_SHA256: "source144_144cef3",
                        OWNER_JOURNAL_GATEWAY_SHA256: "owner_journal_a4ec4e3",
                        OWNER_WRITTEN_GATEWAY_SHA256: "owner_written_d1bd1e5"}
H16_CAPTURE_TIMEOUT_S = 30.0       # legacy collector capture_chat(timeout_s=30)


def source_implementation_hash(root):
    """Stdlib reproduction of mpc_lab.contracts.implementation_hash for a source tree (no
    import of the tree, so no bytecode is written into it)."""
    root = Path(root)
    files = sorted(list((root / "mpc_lab").glob("*.py")) + [
        p for p in (root / "gateway.py", root / "telemetry.py",
                    root / "prefill_lab/live_http.py") if p.is_file()])
    table = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
             for p in files}
    return hashlib.sha256(json.dumps(table, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest(), table


def h16_expected_episodes(blocks, cells):
    """Independent restatement of the a577 factory (action/arm-order RNG keys, 120 slots,
    complementary 48-a arm) used to check the protocol bytes, not to generate them."""
    out = []
    for seed in blocks:
        for cell in cells:
            rng = random.Random(f"action-sequence:{seed}:{cell}")
            actions = [rng.choice((16, 32)) for _ in range(120)]
            order = [0, 1]
            random.Random(f"arm-order:{seed}:{cell}").shuffle(order)
            for arm in order:
                out.append(dict(episode_id=f"nv3-{seed}-{cell}-arm{arm}", seed_block=seed,
                                split="train", cell=cell, duration_s=120, arm=arm,
                                schedule=[dict(at_s=t, budget=48 - a if arm else a)
                                          for t, a in enumerate(actions)]))
    return out


def h16_source_binding(protocol_path, source_root, extension_path):
    """Explicit trusted binding for the H16 43/44 owner MEASUREMENT (Q1-Q5) only. Accepts
    exactly protocol ab883c90, serving tree 104e65a (gateway 0b1a, implementation 5523315c),
    legacy collector 78e2 and extension a577/7bed; refuses Source144/a4ec4e3/d1bd1e5 trees.
    Trust is in these pinned bytes; nothing here authenticates a run, fsyncs, or makes any
    pre-cut/native/MPC claim."""
    import ast
    _sha_required(protocol_path, H16_PROTOCOL_SHA256, "h16_protocol")
    proto = json.loads(Path(protocol_path).read_text())
    root = Path(source_root)
    gw = hashlib.sha256((root / "gateway.py").read_bytes()).hexdigest()
    if gw in H16_REFUSED_GATEWAYS:
        raise ValueError("historical_gateway_refused:" + H16_REFUSED_GATEWAYS[gw])
    _sha_required(root / "gateway.py", H16_GATEWAY_SHA256, "h16_gateway")
    _sha_required(root / "telemetry.py", OWNER_TELEMETRY_SHA256, "h16_telemetry")
    _sha_required(root / "mpc_lab/contracts.py", OWNER_CONTRACTS_SHA256, "h16_contracts")
    legacy = _sha_required(root / H16_LEGACY_PATH, SOURCE144_COLLECTOR_SHA256, "h16_legacy")
    launch = _sha_required(root / H16_LAUNCHER_PATH, SOURCE144_LAUNCHER_SHA256, "h16_launcher")
    ext = _sha_required(extension_path, H16_EXTENSION_SHA256, "h16_extension")
    impl, table = source_implementation_hash(root)
    if impl in H16_REFUSED_IMPLEMENTATIONS:
        raise ValueError("historical_implementation_refused:" + H16_REFUSED_IMPLEMENTATIONS[impl])
    if impl != H16_IMPLEMENTATION_HASH:
        raise ValueError("h16_implementation_hash_mismatch")
    cells = list(ast.literal_eval(_ast_top(ast.parse(legacy), "CELLS").value))
    res = ast.literal_eval(_ast_top(ast.parse(ext), "RESERVATIONS").value)["h16"]
    want = dict(schema="native-v3-state-response-id-v1", source_commit=H16_SOURCE_COMMIT,
                prospective_reservation="h16", reserved_train_blocks=list(H16_BLOCKS),
                serving_gateway_sha256=H16_GATEWAY_SHA256, owner_journal_required=True,
                legacy_collector_sha256=SOURCE144_COLLECTOR_SHA256,
                collection_extension_sha256=H16_EXTENSION_SHA256, gateway_ledger_capture=True,
                gateway_epoch_episode_limit=2, completed_seed_blocks=0, final_test_used=False,
                planned_offered_window_s=2400)
    bad = sorted(k for k, v in want.items() if proto.get(k) != v)
    if res != dict(blocks=H16_BLOCKS, source=H16_SOURCE_COMMIT, gateway=H16_GATEWAY_SHA256,
                   owner_journal=True):
        bad.append("extension_reservation")
    if proto.get("episodes") != h16_expected_episodes(H16_BLOCKS, cells):
        bad.append("episodes_not_factory")
    if bad:
        raise ValueError("h16_protocol_fields:" + ",".join(bad))
    # owner-ledger env path: preflight sets MPC_OWNER_LEDGER_ENABLED in the collector
    # process; the launcher neither allow-lists nor overrides it, so the gateway inherits it
    ltree = ast.parse(launch)
    forced = next(k.value.value for n in ast.walk(ltree) if isinstance(n, ast.Call)
                  for k in n.keywords if k.arg == "ADMISSION_MODE")
    owner_overridden = any(isinstance(n, ast.keyword) and n.arg == "MPC_OWNER_LEDGER_ENABLED"
                           for n in ast.walk(ltree)) or "MPC_OWNER_LEDGER_ENABLED" in launch
    return dict(schema=H16_VERSION, protocol_sha256=H16_PROTOCOL_SHA256,
                source_commit=H16_SOURCE_COMMIT, gateway_sha256=gw,
                implementation_hash=impl, implementation_files=table,
                legacy_collector_sha256=SOURCE144_COLLECTOR_SHA256,
                extension_commit=H16_EXTENSION_COMMIT, extension_sha256=H16_EXTENSION_SHA256,
                extension_in_serving_tree=(root / H16_EXTENSION_PATH).is_file(),
                launcher_sha256=SOURCE144_LAUNCHER_SHA256, launcher_forced_mode=forced,
                owner_env_inherited_unmodified=not owner_overridden,
                episodes=proto["episodes"], epoch_limit=proto["gateway_epoch_episode_limit"],
                refused_implementations=H16_REFUSED_IMPLEMENTATIONS,
                scope="H16 43/44 owner-measurement Q1-Q5 labels only",
                guarantees=dict(authentication=False, fsync=False, online_cut=False,
                                native_claim=False, mpc_permit=False))


def h16_received_watermark(frames, cut):
    """STRICT received watermark: the largest Gateway snapshot `sequence` whose collector
    receipt `gateway_received_at` is strictly before `cut` (same run/clock checked by the
    caller). Journal rows above it are offline labels, never pre-cut state. The snapshot
    sequence is the producer sequence (not a published-file watermark), so W(t) bounds what
    the controller could have SEEN, not what was durably written."""
    seen = [f["gateway_snapshot"]["sequence"] for f in frames
            if f["gateway_received_at"] < cut]
    return max(seen) if seen else 0


def verify_h16_run(binding, run_dir):
    """Offline fail-closed verification of a complete H16 collection directory against an
    h16_source_binding. Q1 written journal per epoch; Q2 snapshot owner-set/stock replay at
    the snapshot sequence; Q3 offered UUID <-> journal decision/outcome and journal terminal
    <= client terminal; Q4 native gateway_request_id admitted earlier and never rejected; Q5
    all-assigned ITT slots (applied ACK / confirmed hold / noncompliant) with control-row
    match. Results are retrospective measurement labels only."""
    run = Path(run_dir)
    f = Counter()
    index = json.loads((run / "index.json").read_text())
    impl = index.get("implementation_hash")
    if impl in H16_REFUSED_IMPLEMENTATIONS:
        f["historical_source_refused:" + H16_REFUSED_IMPLEMENTATIONS[impl]] += 1
    elif impl != binding["implementation_hash"]:
        f["implementation_hash_mismatch"] += 1
    for k, v in (("schema", "native-v3-state-response-id-v1"),
                 ("source_commit", binding["source_commit"]),
                 ("protocol_sha256", binding["protocol_sha256"]),
                 ("collector_sha256", binding["legacy_collector_sha256"]),
                 ("calibrated", False), ("mpc_active", False), ("completed", True)):
        f["index_" + k] += index.get(k) != v
    f["index_error"] += "error" in index
    specs, limit = binding["episodes"], binding["epoch_limit"]
    f["index_episode_order"] += [e.get("episode_id") for e in index.get("episodes", [])] != \
        [e["episode_id"] for e in specs]
    epochs = index.get("gateway_epochs", [])
    f["gateway_epoch_count"] += len(epochs) != -(-len(specs) // limit)
    q = dict(Q1=Counter(), Q2=Counter(), Q3=Counter(), Q4=Counter(), Q5=Counter())
    itt, lags, refusals = Counter(), dict(apply=[], release_to_client=[]), 0
    journals, epoch_run = {}, {}
    for k, ep in enumerate(epochs, 1):
        d = run / ep.get("evidence", "")
        f["epoch_source_commit"] += ep.get("source_commit") != binding["source_commit"]
        launch = json.loads((d / "gateway-launch.json").read_text()) \
            if (d / "gateway-launch.json").is_file() else {}
        f["epoch_launch_source_commit"] += launch.get("source_commit") != binding["source_commit"]
        t, s = d / "gateway-telemetry.jsonl", d / "gateway-telemetry-status.json"
        if not (t.is_file() and s.is_file()):
            q["Q1"]["epoch_journal_missing"] += 1
            continue
        v = verify_owner_written_journal(t, s)
        for name, n in v["failures"].items():
            q["Q1"][name] += n
        refusals += len(v["owner_ledger_refusals"])
        rows = [json.loads(x) for x in t.read_bytes().splitlines() if x.strip()]
        journals[v["run_id"]] = rows
        epoch_run[k] = v["run_id"]
    q["Q1"]["owner_ledger_refusals"] += refusals
    for pos, spec in enumerate(specs):
        path = run / (spec["episode_id"] + ".json")
        if not path.is_file():
            f["episode_missing"] += 1
            continue
        e = json.loads(path.read_text())
        f["episode_spec_changed"] += any(e.get(k) != spec[k] for k in spec)
        rows = journals.get(e.get("gateway_run_id"))
        if rows is None:
            f["episode_run_not_in_epoch_journals"] += 1
            continue
        f["episode_not_in_its_epoch"] += epoch_run.get(pos // limit + 1) != e["gateway_run_id"]
        led = [r for r in rows if r.get("event") == "mpc_ledger"]
        adm = {r["request_id"]: r for r in led if r.get("change_kind") == "admission"}
        term = {r["request_id"]: r for r in led if r.get("change_kind") == "terminal"}
        outcome = {r["request_id"]: r["event"] for r in rows
                   if r.get("event") in R17_OUTCOMES + ("rejected",)}
        # Q2: replay owners to each snapshot's sequence
        for fr in e.get("native_frames", []):
            snap = fr["gateway_snapshot"]
            if snap.get("run_id") != e["gateway_run_id"]:
                q["Q2"]["snapshot_foreign_run"] += 1
                continue
            owners = {}
            for r in led:
                if r["sequence"] > snap["sequence"]:
                    break
                if r.get("change_kind") == "admission":
                    owners[r["request_id"]] = float(r["request_cost"])
                elif r.get("change_kind") == "terminal":
                    owners.pop(r["request_id"], None)
            got = {x["request_id"]: float(x["cost"]) for x in snap.get("requests", [])}
            q["Q2"]["owner_set_mismatch"] += set(got) != set(owners)
            q["Q2"]["stock_mismatch"] += abs(math.fsum(got.values()) - math.fsum(
                owners.values())) > LEDGER_COST_TOL
            # Q4: native-visible gateway IDs were admitted at or before the native sample
            for nr in fr.get("requests", []):
                gid = nr.get("gateway_request_id")
                if gid is None:
                    q["Q4"]["native_request_without_gateway_id"] += 1
                elif gid not in adm or adm[gid]["effective_at"] > fr["sampled_at"]:
                    q["Q4"]["native_visible_without_prior_admission"] += 1
                elif outcome.get(gid) == "rejected":
                    q["Q4"]["native_visible_rejected"] += 1
        # Q3: complete assigned offered cohort
        ids = e.get("expected_ids", [])
        http = {r["request_id"]: r for r in e.get("rows", [])}
        f["offered_cohort_incomplete"] += set(http) != set(ids) or len(ids) != len(set(ids))
        for rid in ids:
            r = http.get(rid)
            if r is None:
                continue
            st = r.get("status")
            if st == "complete":
                q["Q3"]["complete_without_admission"] += rid not in adm
                q["Q3"]["complete_without_completed_outcome"] += outcome.get(rid) != "completed"
                if rid in term:
                    lag = r["terminal_at"] - term[rid]["effective_at"]
                    q["Q3"]["client_terminal_before_journal_release"] += lag < 0
                    lags["release_to_client"].append(lag)
            elif st == "rejected":
                q["Q3"]["rejected_with_admission"] += rid in adm
                q["Q3"]["rejected_without_rejected_row"] += outcome.get(rid) != "rejected"
            else:
                q["Q3"]["other_http_status"] += 1
        # Q5: every assigned slot, ITT
        ctl = {r["budget_version"]: r for r in led if r.get("change_kind") == "control"}
        acks = {0: next((a["reply"]["acknowledgment"] for a in e.get("preassignment", [])
                         if a.get("reply", {}).get("status") == "applied"), None)}
        for a in e.get("actions", []):
            acks[a["at_s"]] = next((x["reply"]["acknowledgment"] for x in a.get("attempts", [])
                                    if x.get("reply", {}).get("status") == "applied"), None)
        holds = {h["at_s"]: h for h in e.get("held_assignments", [])
                 if h.get("status") == "confirmed_hold"}
        for slot in spec["schedule"]:
            at, ack, hold = slot["at_s"], acks.get(slot["at_s"]), holds.get(slot["at_s"])
            if ack is not None and ack.get("budget") == slot["budget"]:
                row = ctl.get(ack.get("budget_version"))
                q["Q5"]["applied_without_control_row"] += row is None or \
                    row.get("budget") != slot["budget"]
                itt["applied"] += 1
                lags["apply"].append(ack["applied_at"] - (e["start"] + at))
            elif hold is not None and hold.get("budget") == slot["budget"]:
                q["Q5"]["hold_without_control_row"] += hold.get("budget_version") not in ctl
                itt["confirmed_hold"] += 1
            else:
                itt["noncompliant"] += 1      # retained in the ITT denominator, not dropped
    for name, c in q.items():
        q[name] = {k: v for k, v in sorted(c.items()) if v}
    failures = {k: v for k, v in sorted(f.items()) if v}
    passed = not failures and not any(q.values())
    return dict(schema=H16_VERSION, ok=passed, result="labels" if passed else "unidentified",
                failures=failures, questions=q, itt_slots=dict(sorted(itt.items())),
                lag_summary={k: dict(n=len(v), min=min(v) if v else None,
                                     max=max(v) if v else None) for k, v in lags.items()},
                guarantees=binding["guarantees"])


def r18_serialized_closing_regression(serialized_root, written_root, workdir):
    """Executes the actual 0b1a (104e65a) and d1bd1e5 nodes: (i) a foreign non-ledger row in
    the append-mode log, (ii) shutdown closing while an /admin/budget body is being received
    (actual update_budget handler, decorators stripped, Request/JSONResponse stubs)."""
    import ast
    import asyncio
    import types
    work = Path(workdir)
    trees = dict(serialized=(serialized_root, H16_GATEWAY_SHA256),
                 written=(written_root, OWNER_WRITTEN_GATEWAY_SHA256))

    class _Resp:
        def __init__(self, content, status_code=200, headers=None):
            self.status_code, self.detail = status_code, content.get("detail")

    def harness(tag, name, prefix=()):
        root, sha = trees[tag]
        h = OwnerJournalHarness(*[Path(root) / n for n in ("gateway.py", "telemetry.py",
                                                          "mpc_lab/contracts.py")],
                                work / f"{tag}-{name}", gateway_sha256=sha, prefix_rows=prefix)
        node = _ast_top(ast.parse(Path(root, "gateway.py").read_text()), "update_budget")
        node.decorator_list = []
        h.ns.update(JSONResponse=_Resp, Request=object, ADMIN_API_KEY="k",
                    secrets=__import__("secrets"))
        _ast_exec([node], h.ns, "gateway.py:update_budget")
        return h

    async def run():
        res = {}
        for tag in trees:
            foreign = dict(event="snapshot", run_id="f" * 32, timestamp=0.0, monotonic=0.0)
            h = harness(tag, "foreign", [foreign])
            await h.set_budget(32.0)
            st = await h.close()
            res[tag + "_foreign_nonledger_row"] = dict(status=st["status"],
                                                       complete=st["mpc_ledger_complete"])
            h = harness(tag, "closing-body")
            await h.set_budget(32.0)
            tel = h.ns["telemetry"]

            async def body(h=h, tel=tel):
                async with h.ns["state_lock"]:    # what the 0b1a shutdown does first
                    tel.owner_ledger_closing = True
                return dict(budget=16)
            req = types.SimpleNamespace(headers={"x-admin-api-key": "k"}, json=body)
            reply = await h.ns["update_budget"](req)
            status = getattr(reply, "status_code", 200)
            st = await h.close()
            led = [r for r in h.rows() if r.get("event") == "mpc_ledger"]
            res[tag + "_closing_during_body"] = dict(
                http_status=status, budget_after=h.ns["state"]["admission_budget"],
                budget_version=h.ns["state"]["budget_version"],
                control_rows_written=sum(r.get("change_kind") == "control" for r in led),
                status=st["status"])
        return res
    return dict(schema=H16_VERSION, sources=dict(serialized=H16_GATEWAY_SHA256,
                                                 written=OWNER_WRITTEN_GATEWAY_SHA256),
                scenarios=asyncio.run(run()))


COUNT_BASELINE_COMMIT = "9ad024e2029b63a992d38199007d54110ad736ac"
COUNT_BASELINE_FILES = {
    "experiments/mpc-research/native-v3/count_baseline.py":
        "d392da072d199a92734b54dccc960de25c72b742ae084b404322f2e30e8dff79",
    "gateway.py": SOURCE144_GATEWAY_SHA256,
    "mpc_lab/http_capture.py":
        "0648738704771f80470849b0c0beb671d0f17c9dbc75e4095cff155b20d04be7",
    "mpc_lab/contracts.py":
        "f39f6b73b41b1433a220f182679852df5c4332d9022ce903dba9863375236e23",
    "experiments/mpc-research/native-v3/collect_identification.py": SOURCE144_COLLECTOR_SHA256,
}
REJECTION_DETAIL = "request rejected: admission capacity exceeded"


def _ast_function(tree, name):
    import ast
    return next(n for n in ast.walk(tree)
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)


def r18_count_baseline_rejection_witness(root):
    """Actual-source witness: protected 503 body vs capture_chat's rejection predicate.

    Everything is AST-extracted from the sealed tree and evaluated with stdlib only; no
    network, no gateway process.  Returns per-mode classification and collector consequence.
    """
    import ast
    root = Path(root)
    for rel, want in COUNT_BASELINE_FILES.items():
        got = hashlib.sha256((root / rel).read_bytes()).hexdigest()
        if got != want:
            raise ValueError("count_baseline_source_mismatch:" + rel)
    gw = ast.parse((root / "gateway.py").read_text())
    cap = ast.parse((root / "mpc_lab/http_capture.py").read_text())
    con = ast.parse((root / "mpc_lab/contracts.py").read_text())
    leg = ast.parse((root / "experiments/mpc-research/native-v3/collect_identification.py")
                    .read_text())
    col = ast.parse((root / "experiments/mpc-research/native-v3/count_baseline.py").read_text())
    ns = dict(math=math)
    exec(compile(ast.Module([_ast_function(con, "finite")], []), "contracts", "exec"), ns)
    exec(compile(ast.Module([_ast_function(leg, "summary")], []), "legacy", "exec"), ns)
    # actual protected and cost_aware rejection returns inside begin_request
    begin = _ast_function(gw, "begin_request")
    returns = {}
    for branch in begin.body:
        if isinstance(branch, ast.If) and isinstance(branch.test, ast.Compare):
            mode = branch.test.comparators[0].value
            returns[mode] = [ast.unparse(r.value) for r in ast.walk(branch)
                             if isinstance(r, ast.Return) and isinstance(r.value, ast.Call)
                             and r.value.args and ast.unparse(r.value.args[0]) == "False"]
    protected = [ast.unparse(r.value) for r in ast.walk(ast.Module(
        [b for b in begin.body if not isinstance(b, ast.If)], [])) if isinstance(r, ast.Return)
        and isinstance(r.value, ast.Call) and r.value.args
        and ast.unparse(r.value.args[0]) == "False"]
    returns["protected"] = protected
    decision_cls = next(n for n in gw.body if isinstance(n, ast.ClassDef)
                        and n.name == "AdmissionDecision")
    exec("from dataclasses import dataclass\nfrom typing import Optional\n"
         + ast.unparse(decision_cls), ns)
    body = next(n.args[0] for n in ast.walk(_ast_function(gw, "_proxy_completions"))
                if isinstance(n, ast.Call) and n.args and isinstance(n.args[0], ast.Dict)
                and any(isinstance(v, ast.Constant) and v.value == REJECTION_DETAIL
                        for v in n.args[0].values))
    predicate = next(n.test for n in ast.walk(_ast_function(cap, "capture_chat"))
                     if isinstance(n, ast.If) and REJECTION_DETAIL in ast.unparse(n.test))
    body_code = compile(ast.Expression(body), "gateway-503", "eval")
    pred_code = compile(ast.Expression(predicate), "capture-503", "eval")
    rid = "0" * 32
    out = {}
    for mode, expr in (("protected", returns["protected"][0]),
                       ("cost_aware", returns["cost_aware"][0])):
        decision = eval(expr, dict(ns, budget=16.0, version=0))
        local = dict(decision=decision, request_cost=0.0 if mode == "protected" else 1.5,
                     estimated_input_tokens=0, estimated_output_tokens=0)
        wire = json.loads(json.dumps(eval(body_code, ns, local)))   # JSONResponse encoding
        rejected = bool(eval(pred_code, ns, dict(rejection=wire, row=dict(
            response_request_id=rid), request_id=rid)))
        status = "rejected" if rejected else "failed"
        summ = ns["summary"]([dict(request_id=rid, status=status)], 0.0, 120)
        out[mode] = dict(begin_request_return=expr, wire_body=wire, capture_status=status,
                         summary_other=summ["other"], summary_rejected=summ["rejected"])
    aborts = any(isinstance(n, ast.If) and ast.unparse(n.test) == "episode['summary']['other']"
                 and isinstance(n.body[0], ast.Raise) for n in ast.walk(col))
    timeout = sorted({k.value.value for n in ast.walk(col) if isinstance(n, ast.Call)
                      and ast.unparse(n.func) == "capture_chat" for k in n.keywords
                      if k.arg == "timeout_s"})
    tag_guard = next(ast.unparse(n.test) for n in ast.walk(_ast_function(gw, "_proxy_completions"))
                     if isinstance(n, ast.If) and "pr33_gateway_request_id" in ast.unparse(n))
    env = next(n for n in ast.walk(_ast_function(col, "gateway_environment"))
               if isinstance(n, ast.Call) and ast.unparse(n.func) == "environment.update")
    env = {k.arg: k.value.value for k in env.keywords if isinstance(k.value, ast.Constant)}
    bound = sorted(n.targets[0].id for n in col.body if isinstance(n, ast.Assign)
                   and isinstance(n.targets[0], ast.Name) and n.targets[0].id.endswith("_SHA"))
    return dict(
        schema="nv3-opus-r18-count-baseline-critique", source_commit=COUNT_BASELINE_COMMIT,
        files=COUNT_BASELINE_FILES, rejection=out,
        collector_aborts_run_on_other=aborts,
        protected_rejection_aborts_run=aborts and out["protected"]["summary_other"] == 1,
        capture_timeout_s=timeout, uuid_tag_guard=tag_guard,
        mpc_lab_enabled_env=env.get("MPC_LAB_ENABLED"),
        native_uuid_join_available=env.get("MPC_LAB_ENABLED") == "true",
        collector_sha_constants=bound,
        unbound_runtime_helpers=["mpc_lab/http_capture.py", "mpc_lab/runtime.py",
                                 "mpc_lab/contracts.py (only CostSpec fingerprint)",
                                 "native observer bytes (self-reported observer_sha256 only)"],
        guarantees=dict(gpu_run=False, baseline_numbers=False, mpc_permit=False))


COUNT_FIX_COMMIT = "8477d0c62bc764b23b058a5d964d5e9d9e0d5d08"
COUNT_FIX_FILES = dict(COUNT_BASELINE_FILES, **{
    "experiments/mpc-research/native-v3/count_baseline.py":
        "55a09eda26d1484eca2588629616726166648742f5730eb93c5fbd962926cb97",
    "experiments/mpc-research/native-v3/baseline_http_capture.py":
        "18d75ce6b0176ea603748b752251fc09c63b2a6cdbba56a9c50ef8d733a1b606",
    "telemetry.py":
        "46d6fb923e558f6435d269dd6fa5cfd5b0d71eb1fd91cbb3aaca8a82385e6370",
})


def r18_count_fix_classifier_witness(root):
    """Run the actual capture_chat + capture_baseline_chat on actual Source144 503 bytes.

    Only the network is replaced: a byte-buffer client returns exactly the Starlette
    JSONResponse encoding of the gateway's own rejection dict.  httpx is stubbed by two
    exception classes; telemetry.has_sse_content is the actual function.
    """
    import ast
    import asyncio
    import contextlib
    import types
    root = Path(root)
    for rel, want in COUNT_FIX_FILES.items():
        if hashlib.sha256((root / rel).read_bytes()).hexdigest() != want:
            raise ValueError("count_fix_source_mismatch:" + rel)
    gw = ast.parse((root / "gateway.py").read_text())
    ns = dict(math=math)
    exec(compile(ast.Module([_ast_function(ast.parse(
        (root / "mpc_lab/contracts.py").read_text()), "finite")], []), "contracts", "exec"), ns)
    decision_cls = next(n for n in gw.body if isinstance(n, ast.ClassDef)
                        and n.name == "AdmissionDecision")
    exec("from dataclasses import dataclass\nfrom typing import Optional\n"
         + ast.unparse(decision_cls), ns)
    body = next(n.args[0] for n in ast.walk(_ast_function(gw, "_proxy_completions"))
                if isinstance(n, ast.Call) and n.args and isinstance(n.args[0], ast.Dict)
                and any(isinstance(v, ast.Constant) and v.value == REJECTION_DETAIL
                        for v in n.args[0].values))
    body = compile(ast.Expression(body), "gateway-503", "eval")

    def wire(decision, cost):
        content = eval(body, ns, dict(decision=decision, request_cost=cost,
                                      estimated_input_tokens=0, estimated_output_tokens=0))
        return json.dumps(content, ensure_ascii=False, allow_nan=False, indent=None,
                          separators=(",", ":")).encode()          # starlette JSONResponse
    AD = ns["AdmissionDecision"]
    bodies = dict(protected=wire(AD(False), 0.0), cost_aware=wire(AD(False, 16.0, 0), 1.5),
                  foreign=json.dumps({"detail": "benchmark ID capacity exceeded"}).encode())
    httpx = types.SimpleNamespace(HTTPError=type("HTTPError", (Exception,), {}),
                                  TimeoutException=type("TimeoutException", (Exception,), {}))
    tel = dict()
    exec(compile(ast.Module([_ast_function(ast.parse((root / "telemetry.py").read_text()),
                                           "has_sse_content")], []), "telemetry", "exec"), tel)
    cap_src = ast.parse((root / "mpc_lab/http_capture.py").read_text())
    cap_src.body = [n for n in cap_src.body if not isinstance(n, (ast.Import, ast.ImportFrom))
                    or ast.unparse(n) in ("import asyncio", "import codecs", "import inspect",
                                          "import json", "import re", "import time",
                                          "from copy import deepcopy")]
    cns = dict(httpx=httpx, has_sse_content=tel["has_sse_content"], finite=ns["finite"],
               validate_snapshot=None, local_clock_domain=lambda: "witness",
               __name__="http_capture")
    exec(compile(cap_src, "http_capture", "exec"), cns)
    base_path = root / "experiments/mpc-research/native-v3/baseline_http_capture.py"
    base_src = ast.parse(base_path.read_text())
    base_src.body = [n for n in base_src.body if not (isinstance(n, ast.ImportFrom)
                                                      and n.module == "mpc_lab.http_capture")]
    bns = dict(capture_chat=cns["capture_chat"], __file__=str(base_path),
               __name__="baseline_http_capture")
    exec(compile(base_src, str(base_path), "exec"), bns)

    class Response:
        def __init__(self, status, headers, chunks):
            self.status_code, self.headers, self.chunks = status, headers, chunks

        async def aiter_bytes(self):
            for c in self.chunks:
                yield c

    class Client:
        def __init__(self, response):
            self.response = response

        @contextlib.asynccontextmanager
        async def stream(self, *a, **k):
            yield self.response

    rid = "ab" * 16
    sse = [b'data: {"choices":[{"index":0,"delta":{"content":"hi"}}]}\n\n',
           b'data: {"choices":[{"index":0,"delta":{"content":"!"},"finish_reason":"stop"}],'
           b'"usage":{"prompt_tokens":3,"completion_tokens":2}}\n\n', b"data: [DONE]\n\n"]
    cases = [("protected_body_protected_mode", "protected", 503, bodies["protected"], rid),
             ("protected_body_cost_mode", "cost_aware", 503, bodies["protected"], rid),
             ("cost_body_cost_mode", "cost_aware", 503, bodies["cost_aware"], rid),
             ("cost_body_protected_mode", "protected", 503, bodies["cost_aware"], rid),
             ("foreign_503_protected_mode", "protected", 503, bodies["foreign"], rid),
             ("protected_body_wrong_x_request_id", "protected", 503, bodies["protected"],
              "cd" * 16),
             ("complete_stream_protected_mode", "protected", 200, None, rid)]
    out = {}
    for name, mode, status, raw, header in cases:
        headers = {"x-request-id": header}
        if status == 200:
            headers["content-type"] = "text/event-stream"
        resp = Response(status, headers, sse if raw is None else [raw[:7], raw[7:]])
        recorded = []
        row = asyncio.run(bns["capture_baseline_chat"](
            Client(resp), "/v1/chat/completions", dict(messages=[], max_tokens=8), rid, 0.0,
            policy_mode=mode, enabled=True, timeout_s=30, record=recorded.append))
        out[name] = dict(status=row["status"], source_capture_status=row["source_capture_status"],
                         recorded_once=len(recorded) == 1 and recorded[0] is row,
                         body_sha256_retained=row.get("source_503_body_sha256") == (
                             hashlib.sha256(raw).hexdigest() if raw else None))
    col = ast.parse((root / "experiments/mpc-research/native-v3/count_baseline.py")
                    .read_text())
    run_src = ast.unparse(_ast_function(col, "run"))
    meta = dict(
        mpc_lab_enabled_env="MPC_LAB_ENABLED='true'" in ast.unparse(
            _ast_function(col, "gateway_environment")),
        verify_epoch_after_stop=run_src.index("await stop_gateway()") < run_src.index(
            "verify_epoch(evidence, episode)"),
        index_append_after_verify=run_src.index("verify_epoch(evidence, episode)") < run_src.index(
            "index['episodes'].append"),
        smoke_requires_count_reject="qualification count rejection witness absent" in run_src,
        timeout_from_protocol="timeout_s=protocol['http_attempt_timeout_s']" in run_src,
        gateway_status_binds_file_sha=False,
        native_join_requires_every_admitted_visible=False)
    return dict(schema="nv3-opus-r18-count-fix-witness", source_commit=COUNT_FIX_COMMIT,
                files=COUNT_FIX_FILES, wire_bodies={k: v.decode() for k, v in bodies.items()},
                cases=out, meta=meta,
                guarantees=dict(gpu_run=False, live_http=False, baseline_numbers=False))


COUNT_DRAIN_COMMIT = "7e129defc2db69637499e493c49627609101d9cc"
COUNT_DRAIN_FILES = dict(COUNT_FIX_FILES, **{
    "experiments/mpc-research/native-v3/count_baseline.py":
        "e79ac42f2dc77e33ddd0f8ff741f6c90b06b6c9ba5eff3ba1d9d04cb336da125",
    "mpc_lab/controller.py": "44d705101820d89677035101110c70f890f94f7d82a5a521ec87d5e09dbf08cc",
})


def r18_count_drain_witness(root):
    """Actual-source check of the 7e129de cost drain contract (stdlib, AST only)."""
    import ast
    root = Path(root)
    for rel, want in COUNT_DRAIN_FILES.items():
        if hashlib.sha256((root / rel).read_bytes()).hexdigest() != want:
            raise ValueError("count_drain_source_mismatch:" + rel)
    gw = ast.parse((root / "gateway.py").read_text())
    col = ast.parse((root / "experiments/mpc-research/native-v3/count_baseline.py").read_text())
    snap = _ast_function(gw, "mpc_snapshot")
    complete = next(n.value for n in ast.walk(snap) if isinstance(n, ast.Assign)
                    and getattr(n.targets[0], "id", None) == "complete")
    complete = compile(ast.Expression(complete), "gateway-complete", "eval")
    ns = dict(math=math)
    exec(compile(ast.Module([_ast_function(col, "drained")], []), "drained", "exec"), ns)
    a, b = 0.259 + 0.000758 * 128 + 0.0052083333 * 256, 0.259 + 0.000758 * 4096 + 0.0052083333 * 128
    residue = ((0.0 + a) + b) - b - a           # admit a, admit b, release b, release a
    scalars = {"residue": residue, "1e-8": 1e-8, "5.0": 5.0}
    out = {}
    for name, scalar in scalars.items():
        ok = eval(complete, ns, dict(marks=(), state=dict(current_in_flight=0,
                                                         current_admitted_cost=scalar)))
        metrics = dict(state_sampled_at=10.0, current_in_flight=0, current_waiting=0,
                       current_admitted_cost=scalar)
        frame = dict(complete=True, running=0, waiting=0, orphaned=0)
        out[name] = dict(
            snapshot_complete=bool(ok),
            cost_drained=ns["drained"](frame, dict(metrics, admission_mode="cost_aware"), 10.1,
                                       dict(drained=bool(ok))),
            count_drained=ns["drained"](frame, dict(metrics, admission_mode="protected"), 10.1))
    sample = ast.unparse(_ast_function(col, "sample"))
    observe = ast.unparse(_ast_function(col, "observe"))
    return dict(schema="nv3-opus-r18-count-drain-witness", source_commit=COUNT_DRAIN_COMMIT,
                files=COUNT_DRAIN_FILES, residue=residue, cases=out,
                cost_episode_polls_admin_state="/admin/mpc/state" in sample
                and "await sample(policy, gateway_run)" in observe,
                count_episode_polls_admin_state=False)


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) in (3, 4) and argv[0] == "--replica-batch-progress":
        train, train_receipt = load_replica(argv[1])
        evaluation, eval_receipt = load_replica(argv[2])
        blocks = tuple(int(b) for b in argv[3].split(",")) if len(argv) == 4 \
            else R11_EVAL_BLOCKS
        print(json.dumps(batch_progress_diagnostic(
            train, evaluation, dict(train=train_receipt, eval=eval_receipt),
            eval_blocks=blocks), indent=2, sort_keys=True))
        return
    if argv[:1] == ["--source144-state-audit"] and (len(argv) == 2 or
                                                    len(argv) >= 3 and len(argv) % 2 == 1):
        manifest = argv[2] if len(argv) > 2 and argv[2] != "-" else None
        pairs = list(zip(argv[3::2], argv[4::2]))
        print(json.dumps(source144_state_audit(argv[1], manifest, pairs), indent=2,
                         sort_keys=True))
        return
    if len(argv) == 3 and argv[0] == "--owner-journal-verify":
        print(json.dumps(verify_owner_journal(argv[1], argv[2]), indent=2, sort_keys=True))
        return
    if len(argv) == 3 and argv[0] == "--owner-written-verify":
        print(json.dumps(verify_owner_written_journal(argv[1], argv[2]), indent=2,
                         sort_keys=True))
        return
    if len(argv) == 8 and argv[0] == "--r17-audit":
        # NEW_ROOT OLD_ROOT WORKDIR GW144 LAUNCHER144 COLLECTOR144 (new gateway = NEW_ROOT)
        import tempfile
        with tempfile.TemporaryDirectory(dir=argv[3]) as tmp:
            witness = r17_written_seal_witness(argv[1], argv[2], tmp)
        out = dict(schema=OWNER_WRITTEN_VERSION, written_seal_witness=witness,
                   count16_feasibility=r17_count16_feasibility(
                       argv[4], argv[5], argv[6], str(Path(argv[1]) / "gateway.py")))
        Path(argv[7]).write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
        print(hashlib.sha256(Path(argv[7]).read_bytes()).hexdigest(), argv[7])
        return
    if len(argv) in (4, 5) and argv[0] == "--h16-binding":
        # PROTOCOL SOURCE_ROOT EXTENSION [RUN_DIR]
        binding = h16_source_binding(argv[1], argv[2], argv[3])
        out = verify_h16_run(binding, argv[4]) if len(argv) == 5 else \
            {k: v for k, v in binding.items() if k != "episodes"}
        print(json.dumps(out, indent=2, sort_keys=True))
        return
    if len(argv) == 3 and argv[0] == "--r18-count-fix-witness":
        # COUNT_BASELINE_ROOT(8477d0c) OUT
        out = r18_count_fix_classifier_witness(argv[1])
        Path(argv[2]).write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
        print(hashlib.sha256(Path(argv[2]).read_bytes()).hexdigest(), argv[2])
        return
    if len(argv) == 3 and argv[0] == "--r18-count-drain-witness":
        out = r18_count_drain_witness(argv[1])
        Path(argv[2]).write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
        print(hashlib.sha256(Path(argv[2]).read_bytes()).hexdigest(), argv[2])
        return
    if len(argv) == 3 and argv[0] == "--r18-count-critique":
        # COUNT_BASELINE_ROOT OUT
        out = r18_count_baseline_rejection_witness(argv[1])
        Path(argv[2]).write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
        print(hashlib.sha256(Path(argv[2]).read_bytes()).hexdigest(), argv[2])
        return
    if len(argv) == 7 and argv[0] == "--r18-audit":
        # PROTOCOL SERIALIZED_ROOT EXTENSION WRITTEN_ROOT WORKDIR OUT
        import tempfile
        binding = h16_source_binding(argv[1], argv[2], argv[3])
        refusals = {}
        for root in (argv[4], str(Path(argv[3]).parents[3])):
            try:
                h16_source_binding(argv[1], root, argv[3])
            except ValueError as exc:
                refusals[hashlib.sha256(Path(root, "gateway.py").read_bytes()).hexdigest()] = \
                    str(exc)
        with tempfile.TemporaryDirectory(dir=argv[5]) as tmp:
            regression = r18_serialized_closing_regression(argv[2], argv[4], tmp)
        out = dict(schema=H16_VERSION,
                   binding={k: v for k, v in binding.items() if k != "episodes"},
                   episodes=len(binding["episodes"]),
                   slots=sum(len(e["schedule"]) for e in binding["episodes"]),
                   historical_tree_refusals=refusals, closing_regression=regression)
        Path(argv[6]).write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
        print(hashlib.sha256(Path(argv[6]).read_bytes()).hexdigest(), argv[6])
        return
    if argv[:1] == ["--r16-support"] and len(argv) in (2, 8):
        smoke = (argv[2], argv[3], list(zip(argv[4::2], argv[5::2]))) if len(argv) == 8 else None
        print(json.dumps(r16_support(argv[1], smoke), indent=2, sort_keys=True))
        return
    if len(argv) == 3 and argv[0] == "--owner-stock-audit":
        train, train_receipt = load_replica(argv[1])
        evaluation, eval_receipt = load_replica(argv[2])
        costs = payload_costs(train)
        print(json.dumps(dict(schema=OWNER_AUDIT_VERSION,
                              receipts=dict(train=train_receipt, eval=eval_receipt),
                              per_block=owner_stock_audit_summary(evaluation, costs)),
                         indent=2, sort_keys=True))
        return
    if len(argv) == 4 and argv[0] == "--replica-event-lag":
        train, train_receipt = load_replica(argv[1])
        evaluation, eval_receipt = load_replica(argv[2])
        print(json.dumps(batch_progress_diagnostic(
            train, evaluation, dict(train=train_receipt, eval=eval_receipt),
            eval_blocks=tuple(int(b) for b in argv[3].split(",")),
            extension=event_lag_extension), indent=2, sort_keys=True))
        return
    if len(argv) == 4 and argv[0] == "--replica-stable-crn":
        train, train_receipt = load_replica(argv[1])
        evaluation, eval_receipt = load_replica(argv[2])
        print(json.dumps(batch_progress_diagnostic(
            train, evaluation, dict(train=train_receipt, eval=eval_receipt),
            eval_blocks=tuple(int(b) for b in argv[3].split(",")),
            extension=stable_crn_extension), indent=2, sort_keys=True))
        return
    if len(argv) == 4 and argv[0] == "--replica-within-step-release":
        train, train_receipt = load_replica(argv[1])
        evaluation, eval_receipt = load_replica(argv[2])
        print(json.dumps(batch_progress_diagnostic(
            train, evaluation, dict(train=train_receipt, eval=eval_receipt),
            eval_blocks=tuple(int(b) for b in argv[3].split(",")),
            extension=within_step_extension), indent=2, sort_keys=True))
        return
    if len(argv) == 4 and argv[0] == "--replica-stock-flow":
        train, train_receipt = load_replica(argv[1])
        evaluation, eval_receipt = load_replica(argv[2])
        print(json.dumps(stock_flow_witness(
            train, evaluation, dict(train=train_receipt, eval=eval_receipt),
            eval_blocks=tuple(int(b) for b in argv[3].split(","))), indent=2, sort_keys=True))
        return
    if len(argv) == 1 and argv[0] == "--r11-interference-witness":
        print(json.dumps(r11_interference_witness(), indent=2, sort_keys=True))
        return
    if len(argv) == 3 and argv[0] == "--replica-eligible-draw":
        train, train_receipt = load_replica(argv[1])
        evaluation, eval_receipt = load_replica(argv[2])
        print(json.dumps(eligible_draw_comparison(
            train, evaluation, dict(train=train_receipt, eval=eval_receipt)),
            indent=2, sort_keys=True))
        return
    if len(argv) == 1 and argv[0] == "--interference-witness":
        print(json.dumps(dict(v5_cyclic=interference_witness("v5_cyclic"),
                              eligible_uniform=interference_witness("eligible_uniform")),
                         indent=2, sort_keys=True))
        return
    if len(argv) == 2 and argv[0] == "--replica-post-admission-load":
        episodes, receipt = load_replica(argv[1])
        print(json.dumps(dict(post_admission_load_descriptive(episodes), receipts=receipt),
                         indent=2, sort_keys=True))
        return
    if len(argv) == 3 and argv[0] == "--replica-release-sensitivity":
        train, train_receipt = load_replica(argv[1])
        evaluation, eval_receipt = load_replica(argv[2])
        print(json.dumps(release_endpoint_sensitivity(
            train, evaluation, dict(train=train_receipt, eval=eval_receipt)),
            indent=2, sort_keys=True))
        return
    if len(argv) == 3 and argv[0] == "--replica-admission-birth":
        train, train_receipt = load_replica(argv[1])
        evaluation, eval_receipt = load_replica(argv[2])
        print(json.dumps(admission_birth_diagnostic(
            train, evaluation, dict(train=train_receipt, eval=eval_receipt)),
            indent=2, sort_keys=True))
        return
    if len(argv) == 2 and argv[0] == "--replica-plan-response":
        episodes, receipt = load_replica(argv[1])
        print(json.dumps(plan_response_diagnostic(episodes, receipt), indent=2, sort_keys=True))
        return
    if len(argv) == 2 and argv[0] == "--replica-progress-diagnostic":
        episodes, receipt = load_replica(argv[1])
        print(json.dumps(progress_diagnostic(episodes, receipt), indent=2, sort_keys=True))
        return
    if len(argv) == 2 and argv[0] == "--replica-exogenous-arrival":
        episodes, receipt = load_replica(argv[1])
        print(json.dumps(exogenous_report(episodes, receipt), indent=2, sort_keys=True))
        return
    if len(argv) == 2 and argv[0] == "--replica-joint-crossfit":
        episodes, receipt = load_replica(argv[1])
        print(json.dumps(joint_crossfit(episodes, receipt), indent=2, sort_keys=True))
        return
    if len(argv) == 2 and argv[0] == "--replica-train-diagnostics":
        episodes, receipt = load_replica(argv[1])
        print(json.dumps(train_diagnostics(episodes, receipt), indent=2, sort_keys=True))
        return
    if len(argv) != 1:
        raise SystemExit("usage: native_release_model.py EPISODES.json | "
                         "--replica-train-diagnostics DIR")
    with open(argv[0], encoding="utf-8") as handle:
        episodes = json.load(handle)
    print(json.dumps(evaluate(episodes), indent=2, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
