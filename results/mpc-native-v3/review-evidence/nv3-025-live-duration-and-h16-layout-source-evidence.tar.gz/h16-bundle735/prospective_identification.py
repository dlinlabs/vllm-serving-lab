"""Separate, opt-in natural Train pairs; the historical collector stays immutable."""
import argparse
import asyncio
import hashlib
import importlib.util
import json
from pathlib import Path
import os
import random


ROOT = Path(__file__).resolve().parents[3]
LEGACY_PATH = Path(__file__).with_name("collect_identification.py")
LEGACY_SHA256 = "78e2c8b91f6b4a582feb69293adff5aa34d4fbd332dfa93b92735bcd0275a069"
RESERVATIONS = {
    "h14": {
        "blocks": (181041, 181042),
        "source": "144cef32a9b51c3a74355ff67f5eafdfac6e075f",
        "gateway": "a4a8229b0f636b64c945881d062c3ee925ef5fccc5ba2e6fc7629657d3575ea7",
        "owner_journal": False,
    },
    "h16": {
        "blocks": (181043, 181044),
        "source": "104e65a69df73997b977bce2588b655ae714f45d",
        "gateway": "0b1a80ade258d8875ba80a072c4f360bfa5d4a7ac312bd222c0571380b341570",
        "owner_journal": True,
    },
}


def legacy_collector():
    if hashlib.sha256(LEGACY_PATH.read_bytes()).hexdigest() != LEGACY_SHA256:
        raise ValueError("historical collector bytes changed")
    spec = importlib.util.spec_from_file_location("prospective_legacy_collector", LEGACY_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def protocol_for(purpose, source, cost_spec):
    if purpose not in RESERVATIONS:
        raise ValueError("unregistered prospective reservation")
    reservation = RESERVATIONS[purpose]
    if source != reservation["source"]:
        raise ValueError("reservation source mismatch")
    legacy = legacy_collector()
    protocol = legacy.protocol_for(source, cost_spec, gateway_ledger=True)
    episodes = []
    for seed in reservation["blocks"]:
        for cell in legacy.CELLS:
            rng = random.Random(f"action-sequence:{seed}:{cell}")
            actions = [rng.choice((16, 32)) for _ in range(120)]
            order = [0, 1]
            random.Random(f"arm-order:{seed}:{cell}").shuffle(order)
            for arm in order:
                episodes.append(dict(
                    episode_id=f"nv3-{seed}-{cell}-arm{arm}", seed_block=seed,
                    split="train", cell=cell, duration_s=120, arm=arm,
                    schedule=[dict(at_s=t, budget=48-a if arm else a)
                              for t, a in enumerate(actions)],
                ))
    protocol.update(
        prospective_reservation=purpose,
        reserved_train_blocks=list(reservation["blocks"]),
        serving_gateway_sha256=reservation["gateway"],
        owner_journal_required=reservation["owner_journal"],
        legacy_collector_sha256=LEGACY_SHA256,
        collection_extension_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        episodes=episodes, planned_offered_window_s=2400,
        minimum_requested_experiment_s=2400,
        scope="Prospective natural-workload pair only; separate source/protocol qualification "
              "required before collection. Not a new ten-hour, physical-EOS or MPC claim.",
    )
    return protocol


def validate_protocol(protocol):
    expected = protocol_for(protocol.get("prospective_reservation"),
                            protocol.get("source_commit"), protocol.get("cost_spec"))
    if protocol != expected:
        raise ValueError("protocol not identical to registered prospective factory")


def execution_preflight(protocol, config, *, backend_free, epoch_qualified):
    validate_protocol(protocol)
    if not backend_free or not epoch_qualified:
        raise ValueError("explicit free-backend and separate epoch-qualification required")
    if hashlib.sha256((ROOT / "gateway.py").read_bytes()).hexdigest() != protocol["serving_gateway_sha256"]:
        raise ValueError("local serving source does not match reserved epoch")
    owner_enabled = str(config.get("MPC_OWNER_LEDGER_ENABLED", "false")).lower() == "true"
    if owner_enabled != protocol["owner_journal_required"]:
        raise ValueError("owner-journal source/measurement mismatch")
    return {"MPC_OWNER_LEDGER_ENABLED": "true" if owner_enabled else "false"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare", action="store_true")
    mode.add_argument("--validate", action="store_true")
    mode.add_argument("--execute", action="store_true")
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--purpose", choices=RESERVATIONS)
    parser.add_argument("--source-commit")
    parser.add_argument("--cost-spec", type=Path)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--vllm-launch", type=Path)
    parser.add_argument("--gateway-plan", type=Path)
    parser.add_argument("--previous-index", type=Path)
    parser.add_argument("--backend-free", action="store_true",
                        help="explicit operator attestation; not an ownership verifier")
    parser.add_argument("--epoch-qualified", action="store_true",
                        help="explicit operator attestation of separate qualification; not proof")
    args = parser.parse_args()
    if args.prepare:
        if args.cost_spec is None:
            parser.error("--prepare requires --cost-spec")
        protocol = protocol_for(args.purpose, args.source_commit,
                                json.loads(args.cost_spec.read_text()))
        with args.protocol.open("x") as stream:
            json.dump(protocol, stream, indent=2, allow_nan=False)
        return
    protocol = json.loads(args.protocol.read_text())
    validate_protocol(protocol)
    if args.execute:
        if any(value is None for value in (args.config, args.output, args.vllm_launch, args.gateway_plan)):
            parser.error("--execute requires config/output/vllm-launch/gateway-plan")
        environment = execution_preflight(protocol, json.loads(args.config.read_text()),
                                          backend_free=args.backend_free,
                                          epoch_qualified=args.epoch_qualified)
        os.environ.update(environment)
        asyncio.run(legacy_collector().run(args, protocol))


if __name__ == "__main__":
    main()
