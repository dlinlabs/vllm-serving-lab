"""Unit and regression tests for native_campaign_protocol.

Validates ground-truth accounting, R3 rejection guards, observable state,
and >=10h campaign protocol generation.
"""

import json
import math
from pathlib import Path
import sys
import unittest

# Ensure module can be imported whether tests are run from native-v3 dir or repo root
sys.path.insert(0, str(Path(__file__).parent.resolve()))

from native_campaign_protocol import (
    WORKLOAD_FAMILIES,
    DeliveredTokensAuditResult,
    ExperimentDurationAccounting,
    Fixed16Controller,
    GatewayEpoch,
    IndependentSeedBlockOutcome,
    MarkedReservationRecord,
    ObservableBatchState,
    RecedingHorizonMPCController,
    RequestOutcome,
    StrongOneMoveController,
    SuperiorityEvaluator,
    WorkAccounting,
    audit_native_qualification_tail_distribution,
    build_native_campaign_protocol,
    canonical_digest,
    compute_normalized_absolute_error,
    compute_work_accounting,
    demonstrate_astra_selection_defect,
    demonstrate_sol_block_ceiling_and_float_defect,
    is_finite_real,
    plan_gateway_epochs,
    robust_paired_permutation_test,
    run_legacy_delivered_tokens_audit,
    validate_request_outcome,
    verify_gpu_elapsed_clock_semantics,
)


class TestGroundTruthAccounting(unittest.TestCase):
    """Test verification of the ground-truth baseline fact and work accounting."""

    def test_legacy_strict_audit_remains_false(self):
        """The strict v2 audit must evaluate to FALSE and not be silently relaxed."""
        audit = run_legacy_delivered_tokens_audit(
            prompt_tokens=4096,
            delivered_tokens=32,
            worker_forward_end_position=4128,
            total_forward_steps=34,
            prefill_steps=2,
            decode_steps=32,
        )
        self.assertIsInstance(audit, DeliveredTokensAuditResult)
        self.assertFalse(audit.strict_v2_match, "Strict audit must be False per ground truth")
        self.assertEqual(audit.delivered_token_minimum_position, 4127)
        self.assertEqual(audit.worker_forward_end_position, 4128)
        self.assertIn("Strict audit FALSE", audit.reason)

    def test_explicit_work_accounting(self):
        """Useful, physical, and tail work must be explicitly decomposed."""
        acct = compute_work_accounting(
            prompt_tokens=4096,
            delivered_tokens=32,
            worker_forward_end_position=4128,
            total_forward_steps=34,
            prefill_steps=2,
            decode_steps=32,
        )
        self.assertIsInstance(acct, WorkAccounting)
        self.assertEqual(acct.useful_prompt_tokens, 4096)
        self.assertEqual(acct.useful_output_tokens, 32)
        self.assertEqual(acct.useful_total_tokens, 4128)
        self.assertEqual(acct.physical_executed_positions, 4129)
        self.assertEqual(acct.tail_work_tokens, 1)
        self.assertEqual(acct.tail_work_steps, 1)
        self.assertIn("pre-finish scheduler placeholder 1", acct.tail_work_cause)
        self.assertAlmostEqual(acct.tail_work_output_ratio, 1.0 / 32.0)

    def test_gpu_elapsed_and_serial_falsification(self):
        """GPU elapsed is not an exclusive single-tenant service duration."""
        res = verify_gpu_elapsed_clock_semantics(
            http_residence_s=1.2,
            gpu_kernel_forward_elapsed_s=0.4,
            active_concurrent_requests=8,
        )
        self.assertFalse(res["kernel_exceeds_residence"])
        self.assertTrue(res["serial_service_model_falsified"])
        self.assertAlmostEqual(res["apparent_serial_demand_s"], 9.6)


class TestOutcomeValidationAndR3Rejection(unittest.TestCase):
    """Test outcome validation rejecting R3 flaws (zero tokens, NaN origin, pseudoreplication)."""

    def test_zero_completion_tokens_rejected(self):
        """0 output tokens must be rejected as invalid and not scored as good."""
        outcome = RequestOutcome(
            request_id="req-zero",
            prompt_tokens=128,
            output_tokens=0,  # Flaw in R3
            scheduled_at=10.0,
            client_post_at=10.05,
            first_content_at=10.2,
            terminal_at=10.25,
            origin_s=10.0,
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertFalse(val["valid"])
        self.assertFalse(val["is_good"])
        self.assertIn("invalid_output_token_count_must_be_positive_integer", val["rejection_reasons"])

    def test_nan_origin_rejected(self):
        """NaN origin timestamp must be rejected as invalid."""
        outcome = RequestOutcome(
            request_id="req-nan",
            prompt_tokens=128,
            output_tokens=16,
            scheduled_at=10.0,
            client_post_at=10.05,
            first_content_at=10.2,
            terminal_at=10.5,
            origin_s=float("nan"),  # Flaw in R3
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertFalse(val["valid"])
        self.assertFalse(val["is_good"])
        self.assertIn("nonfinite_origin_timestamp", val["rejection_reasons"])

    def test_valid_good_outcome(self):
        """A properly formatted request meeting SLOs must be scored good."""
        outcome = RequestOutcome(
            request_id="req-valid",
            prompt_tokens=128,
            output_tokens=32,
            scheduled_at=10.0,
            client_post_at=10.01,
            first_content_at=10.15,  # TTFT = 0.15s <= 0.5s
            terminal_at=10.77,       # TPOT = (10.77 - 10.15) / 31 = 0.02s <= 0.05s
            origin_s=10.0,
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertTrue(val["valid"])
        self.assertTrue(val["is_good"])
        self.assertAlmostEqual(val["ttft_s"], 0.15)
        self.assertAlmostEqual(val["tpot_s"], 0.02)

    def test_evaluator_rejects_pseudoreplication(self):
        """Duplicating the identical block (R3 flaw) must trigger pseudoreplication rejection."""
        evaluator = SuperiorityEvaluator(min_blocks=6)
        single_block = IndependentSeedBlockOutcome(
            block_id="block-dup",
            seed=170001,
            workload_family="short_homogeneous",
            split="development",
            duration_s=10.0,
            control_decisions=10,
            offered_requests=100,
            policy_a_good_completions=10,
            policy_a_rejections=5,
            policy_a_solver_overruns=0,
            policy_b_good_completions=20,
            policy_b_rejections=5,
            policy_b_solver_overruns=0,
        )
        # Duplicate identical block 6 times
        replicated_blocks = [single_block] * 6
        res = evaluator.evaluate(replicated_blocks)
        self.assertEqual(res["verdict"], "REJECTED_PSEUDOREPLICATION")
        self.assertFalse(res["statistically_significant"])

    def test_evaluator_rejects_zero_variance(self):
        """Distinct block IDs with identical paired differences must be rejected for zero variance."""
        evaluator = SuperiorityEvaluator(min_blocks=6)
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"block-{i}",
                seed=170000 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=10,
                offered_requests=100,
                policy_a_good_completions=10,
                policy_a_rejections=5,
                policy_a_solver_overruns=0,
                policy_b_good_completions=20,  # Exact same difference across all
                policy_b_rejections=5,
                policy_b_solver_overruns=0,
            )
            for i in range(6)
        ]
        res = evaluator.evaluate(blocks)
        self.assertEqual(res["verdict"], "REJECTED_ZERO_VARIANCE")
        self.assertFalse(res["statistically_significant"])

    def test_evaluator_confirms_valid_superiority(self):
        """Independent blocks with natural variance and genuine margin can achieve confirmation."""
        evaluator = SuperiorityEvaluator(
            min_blocks=6,
            pre_registered_margin_req_s=0.5,
        )
        # 8 independent blocks with positive mean improvement and natural variance
        good_b = [22, 24, 21, 25, 23, 26, 22, 24]
        good_a = [12, 11, 13, 10, 12, 11, 13, 12]
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"valid-block-{i}",
                seed=170010 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=10,
                offered_requests=100,
                policy_a_good_completions=good_a[i],
                policy_a_rejections=5,
                policy_a_solver_overruns=0,
                policy_b_good_completions=good_b[i],
                policy_b_rejections=5,
                policy_b_solver_overruns=0,
            )
            for i in range(8)
        ]
        res = evaluator.evaluate(blocks)
        self.assertEqual(res["verdict"], "CONFIRMED_SUPERIOR")
        self.assertTrue(res["statistically_significant"])
        self.assertTrue(res["margin_satisfied"])
        self.assertGreater(res["std_goodput_difference"], 0.0)


class TestObservableBatchState(unittest.TestCase):
    """Test observable Gateway state, soft-cap behavior, and conservation."""

    def test_soft_cap_reduction_does_not_evict(self):
        """Lowering applied cap from 32 to 16 must NOT evict existing reservations."""
        state = ObservableBatchState(initial_cap=32.0)
        
        # Admit 3 requests with cost 8.0 each -> total 24.0
        for i in range(3):
            admitted = state.admit(MarkedReservationRecord(
                request_id=f"r-{i}",
                original_cost=8.0,
                admitted_at=10.0 + i,
                prompt_tokens=256,
                max_tokens=128,
            ))
            self.assertTrue(admitted)
            
        self.assertEqual(state.reserved_cost, 24.0)
        
        # Lower cap to 16.0
        state.update_cap(16.0)
        self.assertEqual(state.applied_cap, 16.0)
        # Invariant: existing reservations survive
        self.assertEqual(state.reserved_cost, 24.0)
        self.assertEqual(len(state.active_reservations), 3)
        
        # New admission is throttled because 24.0 + 4.0 > 16.0
        new_admitted = state.admit(MarkedReservationRecord(
            request_id="r-new",
            original_cost=4.0,
            admitted_at=15.0,
            prompt_tokens=128,
            max_tokens=128,
        ))
        self.assertFalse(new_admitted)

    def test_release_and_conservation(self):
        """Releasing terminal reservations strictly decreases reserved cost."""
        state = ObservableBatchState(initial_cap=32.0)
        rec = MarkedReservationRecord(
            request_id="r-term",
            original_cost=6.5,
            admitted_at=10.0,
            prompt_tokens=512,
            max_tokens=128,
        )
        state.admit(rec)
        self.assertEqual(state.reserved_cost, 6.5)
        
        released = state.release("r-term", timestamp_s=12.5)
        self.assertIsNotNone(released)
        self.assertEqual(state.reserved_cost, 0.0)
        self.assertEqual(len(state.history_released), 1)

    def test_normalized_absolute_error_computation(self):
        """NAE across multi-step horizons must be correctly normalized."""
        pred = {1: 4.0, 3: 8.0, 5: 12.0}
        actual = {1: 5.0, 3: 8.0, 5: 10.0}
        origin_r = 16.0
        
        res = compute_normalized_absolute_error(pred, actual, origin_r)
        self.assertFalse(res["empty_origin"])
        # |4-5|/16 = 1/16, |8-8|/16 = 0, |12-10|/16 = 2/16 -> mean = (3/16)/3 = 1/16 = 0.0625
        self.assertAlmostEqual(res["mean_normalized_absolute_error"], 0.0625)


class TestCampaignProtocolBuilder(unittest.TestCase):
    """Test campaign protocol builder properties (duration, workloads, splits, immutability)."""

    def test_protocol_builder_duration_exceeds_10_hours(self):
        """The protocol must schedule >= 10.0 hours of active execution."""
        protocol = build_native_campaign_protocol()
        hours = protocol["duration_summary"]["total_active_hours"]
        self.assertGreaterEqual(hours, 10.0, f"Scheduled hours {hours:.2f}h must be >= 10.0h")
        self.assertTrue(protocol["duration_summary"]["hours_requirement_satisfied"])
        self.assertEqual(protocol["duration_summary"]["total_episodes"], 320)

    def test_eight_workload_families_present(self):
        """All 8 workload families must be declared and populated in the protocol."""
        protocol = build_native_campaign_protocol()
        self.assertEqual(len(protocol["workload_families"]), 8)
        for fam in WORKLOAD_FAMILIES:
            self.assertIn(fam, protocol["workload_families"])

    def test_splits_and_seed_isolation(self):
        """Train, calibration, development, and final splits must be populated with fresh seeds."""
        protocol = build_native_campaign_protocol(base_seed=180001)
        groups = protocol["groups"]
        all_seeds = [g["seed"] for g in groups.values()]
        
        # Verify no duplicate seeds
        self.assertEqual(len(all_seeds), len(set(all_seeds)))
        
        # Verify historical held-out seeds 160021-160024 are NOT used
        for seed in all_seeds:
            self.assertFalse(
                160021 <= seed <= 160024,
                f"Seed {seed} must not overlap with historical final held-out seeds 160021-160024!",
            )

    def test_matched_arms_share_tape(self):
        """Matched arms (0 and 1) must share identical arrival and prompt tape keys."""
        protocol = build_native_campaign_protocol()
        episodes = protocol["episodes"]
        
        # Group episodes by block_id
        by_block = {}
        for ep in episodes:
            by_block.setdefault(ep["block_id"], []).append(ep)
            
        for block_id, eps in by_block.items():
            self.assertEqual(len(eps), 2, f"Block {block_id} must have exactly 2 matched arms")
            arm0, arm1 = sorted(eps, key=lambda x: x["arm"])
            self.assertEqual(arm0["arm"], 0)
            self.assertEqual(arm1["arm"], 1)
            self.assertEqual(arm0["arrival_tape_key"], arm1["arrival_tape_key"])
            self.assertEqual(arm0["prompt_tape_key"], arm1["prompt_tape_key"])

    def test_canonical_digest_immutability(self):
        """Protocol hash must be a deterministic 64-character SHA-256 hex string."""
        p1 = build_native_campaign_protocol()
        p2 = build_native_campaign_protocol()
        self.assertEqual(p1["protocol_hash"], p2["protocol_hash"])
        self.assertEqual(len(p1["protocol_hash"]), 64)

    def test_protocol_json_serialization_roundtrip(self):
        """Protocol must serialize to valid JSON without NaN or Inf and roundtrip exactly."""
        protocol = build_native_campaign_protocol()
        json_str = json.dumps(protocol, allow_nan=False)
        roundtrip = json.loads(json_str)
        self.assertEqual(protocol["protocol_hash"], roundtrip["protocol_hash"])
        self.assertEqual(len(roundtrip["episodes"]), 320)

    def test_overrun_guard_rejection(self):
        """Excessive decision overruns must trigger REJECTED_OVERRUN_GUARD."""
        evaluator = SuperiorityEvaluator(min_blocks=6, max_decision_overrun_rate=0.01)
        good_b = [22, 24, 21, 25, 23, 26]
        good_a = [12, 11, 13, 10, 12, 11]
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"overrun-block-{i}",
                seed=170050 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=100,
                offered_requests=100,
                policy_a_good_completions=good_a[i],
                policy_a_rejections=5,
                policy_a_solver_overruns=0,
                policy_b_good_completions=good_b[i],
                policy_b_rejections=5,
                policy_b_solver_overruns=5,  # 5% overrun rate > 1% threshold
            )
            for i in range(6)
        ]
        res = evaluator.evaluate(blocks)
        self.assertEqual(res["verdict"], "REJECTED_OVERRUN_GUARD")
        self.assertFalse(res["overrun_guard_passed"])

    def test_rejection_guard_rejection(self):
        """Excessive relative rejection increase must trigger REJECTED_REJECTION_GUARD."""
        evaluator = SuperiorityEvaluator(min_blocks=6, max_relative_rejection_increase=0.05)
        good_b = [22, 24, 21, 25, 23, 26]
        good_a = [12, 11, 13, 10, 12, 11]
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"rej-block-{i}",
                seed=170060 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=100,
                offered_requests=100,
                policy_a_good_completions=good_a[i],
                policy_a_rejections=10,
                policy_a_solver_overruns=0,
                policy_b_good_completions=good_b[i],
                policy_b_rejections=15,  # 50% relative increase > 5% threshold
                policy_b_solver_overruns=0,
            )
            for i in range(6)
        ]
        res = evaluator.evaluate(blocks)
        self.assertEqual(res["verdict"], "REJECTED_REJECTION_GUARD")
        self.assertFalse(res["rejection_guard_passed"])

    def test_controllers_produce_valid_budgets(self):
        """All 5 comparators must produce allowed budgets in {16.0, 32.0}."""
        state = ObservableBatchState(initial_cap=16.0)
        controllers = [
            Fixed16Controller(),
            StrongOneMoveController(),
            RecedingHorizonMPCController(),
        ]
        for ctrl in controllers:
            decision = ctrl.decide(state, queue_length=5)
            self.assertIn(decision, (16.0, 32.0))


class TestRound2PeerCounterexamplesAndSurgicalFixes(unittest.TestCase):
    """Round 2 tests: reproducible counterexamples, peer bug demonstrations, and surgical fixes."""

    def test_astra_selection_defect_reproduced_and_fixed(self):
        """Astra's decision tree drops resolved Two-Move actions when One-Move is unresolved."""
        res = demonstrate_astra_selection_defect()
        # Verify Astra unfixed status falls back to uncertainty despite Two-Move being resolved
        self.assertFalse(res["one_resolved"], "One-move should be unresolved")
        self.assertTrue(res["two_resolved"], "Two-move should be resolved")
        self.assertGreater(res["gain_lower"], 0.0, "Two-move has strictly positive lower gain")
        self.assertEqual(res["astra_unfixed_status"], "fallback")
        self.assertEqual(res["astra_unfixed_reason"], "first-action uncertainty")
        self.assertIsNone(res["astra_unfixed_cap"], "Astra sends no command despite resolved action")
        
        # Verify surgical fix resolves to shadow action with cap 16
        self.assertEqual(res["surgical_fixed_status"], "shadow")
        self.assertEqual(res["surgical_fixed_chosen"], "two")
        self.assertEqual(res["surgical_fixed_cap"], 16)

    def test_sol_block_ceiling_and_float_defect_reproduced_and_fixed(self):
        """Sol's paired_effect crashes on N > 16 blocks, and its scheduled float check is brittle."""
        res = demonstrate_sol_block_ceiling_and_float_defect()
        self.assertTrue(res["sol_crashes_on_dev_split_32_blocks"])
        self.assertTrue(res["exact_float_inequality_triggered"])
        self.assertGreater(res["float_difference"], 0.0)

        # Test robust permutation test on small N (exact enumeration)
        effects_small = [0.1, 0.2, 0.15, 0.3, -0.05, 0.25]
        res_exact = robust_paired_permutation_test(effects_small, max_exact_n=16)
        self.assertEqual(res_exact["n_blocks"], 6)
        self.assertTrue(res_exact["method"].startswith("exact_sign_flip"))
        self.assertLess(res_exact["p_value"], 0.1)

        # Test robust permutation test on large N=32 (development split scale) via Monte Carlo
        effects_dev = [0.15 + (0.02 * (i % 5) - 0.04) for i in range(32)]
        res_mc = robust_paired_permutation_test(effects_dev, max_exact_n=16, mc_samples=1000)
        self.assertEqual(res_mc["n_blocks"], 32)
        self.assertTrue(res_mc["method"].startswith("monte_carlo_permutation"))
        self.assertTrue(res_mc["statistically_significant"])

    def test_actual_duration_accounting_falsifies_planned_time(self):
        """Planned time, setup, idle, and drain cannot be counted as completed >=10h science."""
        # Case A: 48,000s planned, but only 18,000s realized active measurement
        acct_partial = ExperimentDurationAccounting(
            planned_windows_count=400,
            window_duration_seconds=120.0,
            planned_active_measurement_seconds=48000.0,
            realized_active_measurement_seconds=18000.0,  # 5 hours
            drain_duration_seconds=6000.0,
            epoch_rollover_duration_seconds=1200.0,
            setup_and_idle_seconds=14400.0,
        )
        passed, reason = acct_partial.validate_actual_10h_milestone()
        self.assertFalse(passed, "Planned 48ks and idle time cannot pass 10h threshold")
        self.assertIn("Falsified", reason)

        # Case B: 36,050s realized active measurement (meets requirement)
        acct_complete = ExperimentDurationAccounting(
            planned_windows_count=320,
            window_duration_seconds=120.0,
            planned_active_measurement_seconds=38400.0,
            realized_active_measurement_seconds=36050.0,  # > 10.0h
            drain_duration_seconds=2400.0,
            epoch_rollover_duration_seconds=600.0,
            setup_and_idle_seconds=1800.0,
        )
        passed_comp, reason_comp = acct_complete.validate_actual_10h_milestone()
        self.assertTrue(passed_comp)
        self.assertIn("Qualified", reason_comp)

    def test_gateway_epoch_rollovers_respect_1024_op_ceiling(self):
        """Gateway epochs must bound operations below 1024 without restarting native engine."""
        protocol = build_native_campaign_protocol()
        episodes = protocol["episodes"]
        epochs = plan_gateway_epochs(episodes, pairs_per_epoch=2, max_ops_per_epoch=1024)
        
        # 320 episodes / 4 episodes per epoch = 80 epochs
        self.assertEqual(len(epochs), 80)
        for ep in epochs:
            self.assertEqual(len(ep.episode_ids), 4)
            self.assertLess(ep.estimated_operations, 1024)
            self.assertTrue(ep.requires_strict_drain_before_rollover)
            self.assertFalse(ep.requires_native_restart)
            self.assertFalse(ep.evict_idempotency_tables)

    def test_qualification_tail_distribution_audit(self):
        """Authoritative qualification receipt 2587d2b proves stochastic tail distribution."""
        audit = audit_native_qualification_tail_distribution()
        self.assertEqual(audit["qualification_commit"], "2587d2b")
        self.assertEqual(audit["total_requests"], 40)
        self.assertEqual(audit["natural_eos_count"], 40)
        self.assertEqual(audit["v3_audits_valid"], 16)
        self.assertEqual(audit["legacy_v2_audits_retained_false"], 8)
        self.assertEqual(audit["total_tail_tokens"], 20)
        self.assertAlmostEqual(audit["mean_tail_tokens_per_request"], 0.5)
        self.assertTrue(audit["tail_is_stochastic"])


if __name__ == "__main__":
    unittest.main()

