# NV3 Opus 獨立提案（Round 1）：history-conditioned 原始成本釋放模型

狀態：**獨立初稿，未讀 peer NV3 提案**。沒有新的 native／MPC 結果；
本文件與程式只定義可在實際 Gateway marks／ledger 與 native frames 上執行的
模型、ground truth 與否證測試。單元 fixtures 只驗證會計與因果性，
不是 native 性能、校準或統計保證。

## 1. 共同 ground truth：useful／physical／tail work（不放寬舊 audit）

Strict HTTP 基線（exact UUID、4096 prompt／32 output／natural EOS）：
34 steps＝2 prefill＋32 decode；worker 連續 forward positions 結束於 4128，
delivered-token 最小值 `P+O−1=4127`。舊 v2 `audit_capture` 的
`progress == input+output−1` 因此**仍為 FALSE，原樣保留**。

明確會計（`forward_work_accounting`）：

| 量 | 定義 | 基線值 |
|---|---|---:|
| useful positions | `P+O−1`（最後 sampled token 不需再 forward） | 4127 |
| physical positions | 實際連續 executed positions 終點 | 4128 |
| tail positions | physical − useful | 1 |
| useful steps | 結束 ≤ useful 邊界的 steps（2 prefill＋31 decode） | 33 |
| tail steps | 起點 ≥ useful 邊界的 steps | 1 |

`tail_accounted=True` 只在全部成立時：natural EOS；positions 無 gap／repeat／split；
每個 step 與 worker `executed_positions/executed_counts` 相符；tail ≤1 token；
tail step 是單 token decode 且 **schedule start < engine finish**（pre-finish placeholder）。
否證（各有測試）：tail step 在 finish 後才排程、tail>1（unexplained work）、
tail<0（missing useful work）、position gap、跨越 useful 邊界、worker 未匹配。
GPU elapsed 只是 per-step current-stream label，不是絕對 GPU／host clock
或獨占 service duration；本模組不把它相加成 service time。

對 release 模型的含義：reservation release 不早於 EOS output commit，
tail forward 是 release 之前可能的物理延遲來源；它作為誤差解釋 label，
不是預測輸入。

## 2. 可觀測狀態與 transition

Origin `t0`＝joined observation 的 native client receipt；要求同 run／clock domain、
`gateway.sampled_at ≤ received_at ≤ t0`、age ≤0.5s、native ID
`chatcmpl-<uuid>-<8hex>` 精確 join（未 join／重複即拒絕）。
Cohort＝origin snapshot 中所有 live marks（原始 cost、prompt、max、admitted、first）。

每 mark 特徵（全部 ≤t0 可得）：cost、prompt_k、max/100、started、age、
native_unknown、output progress、remaining cap、decode batch D、
prefill backlog k-tokens（native output=0 ＋ Gateway 已收但 native 未見）、
waiting、cohort cost R、**計畫中**的 cap（frozen `cap_plan` 時間平均，
非 realized）、trailing 2s realized release rate（只用先前已收到的 snapshot pairs）。
有測試證明修改未來 observations 不改變 origin 特徵。

Exact transition 部分沿用 Gateway 守恆：每個 `mpc_ledger` frame 是單一事件，
delta<0 即一次 release（原始 cost、effective_at）。

## 3. Response：累計釋放原始 cost 的 ground truth（含不確定）

Target：origin cohort 在 `(sampled_at, t0+h]` 已釋放的原始 cost，h∈{1,3,5}s；
包含 observation lag 內已發生的 release。

1. Ledger 必須 sequence 連續、complete、同 run/clock；每個 snapshot 的 mark cost 和
   必須等於該 sequence 的 ledger reserved（否則拒絕）。
2. 每個 cohort mark 的消失區間＝最後出現與下一個 snapshot 的 sequence 區間。
3. 同區間同 cost 的 ledger release 事件為候選；若 `n_g` 事件、`m_g` cohort marks：
   cohort 已釋放數 ∈ `[max(0, r−(n_g−m_g)), min(r, m_g)]`（r＝≤τ 的事件數）。
   Cost 相同且有非 cohort release 時輸出**區間**而非猜測；`n_g<m_g` 拒絕。
4. 超過最後 snapshot 而仍未消失的 marks 是 censored 上界。

Per-mark label：唯一可識別時才給 0/1；否則 None，排除於 fit 並計數報告
（選擇偏差限制已承認）。

## 4. 比較的模型（全部只用 Train fit；無發明的 service 參數）

| 模型 | 形式 | 參數來源 |
|---|---|---|
| train_fraction | `R·p̄_h` | Train 精確 truth 的平均釋放比例 |
| fluid_history | `min(R, μ·h)`，μ＝trailing realized rate，缺少時用 Train 平均 cost/s | 歷史＋Train |
| batch_aware | `Σ cost_i·p_i(h)`，per-horizon L2 logistic，h 間 cummax 單調 | Train per-mark labels |

L2=1.0（標準化特徵）、α=0.1、history 2s 均**預先宣告、不調參**。
`fit` 拒絕任何非 Train row；seed block 只能屬於一個 partition；
final held-out **160021–160024 一律拒絕**（未使用）。

## 5. 評估：one／multi／OOD、block calibration

- 主要指標：`mean_h |pred(h)−actual(h)| / R_origin`，episode→block→平均；
  truth 為區間時報 lower/upper error；`R_origin=0` 另計不納入。
- One-step（1s）與 multi-step（3／5s）同一 origin 同時發布，不用 realized future gaps。
- OOD：Train 支援域（R、D、prefill_k、waiting、cap、planned cap、cohort size、
  `(prompt,max)` work shapes）外**整個 origin abstain**，所有模型配對相同樣本；
  abstention 原因逐項計數。
- Calibration：只用 Calibration blocks 的 split residual quantiles 形成 band，
  Development 報 per-block 覆蓋（lower＝所有可行 truth 皆覆蓋、upper＝某個可行 truth 覆蓋）。
  Blocks 間 exchangeability 未證，**不是 coverage 保證**。

## 6. Strong One-move vs MPC、因果支援與安全部署（本模組之外的條件）

- 本模型輸出 `P(release | H_t0, planned cap)`；cap 依賴性只有在 randomized
  cap-sequence episodes（Gate B LL/LH/HL/HH）支援下才可解讀為 action response；
  觀察資料上的 cap 係數不是因果斜率。
- Strong One-move 與 MPC 必須使用同一模型、同一 abstention 與同一 continuation
  （由 Development 在 hold／fixed／reactive 中選定）；只有 multi-step forecast
  在 Development 優於 train_fraction／fluid_history 時，multi-move 才有資訊價值。
- 部署：任何 OOD abstain 或 truth/ledger 驗證失敗 → 回到 development-chosen
  best-supported-fixed；cap 16/32 是 cost cap 而非 concurrency；無 KV hard-safety 宣稱。

## 7. 否證條件（預先宣告）

1. batch_aware 在 Development blocks 上未低於兩個 baseline 的 upper error →
   batch 特徵沒有超過 fluid 的預測價值，不得用於 MPC。
2. 3／5s 誤差相對 1s 未改善 baseline 差距 → 不支持 multi-step 規劃。
3. Development 覆蓋顯著低於 1−α 或 block 間差異大 → band 不可作 risk 約束。
4. 需要 abstain 的 origin 比例高 → 支援域不足，需要更多 randomized Train。
5. tail_accounted 對任何 natural-EOS request 為 False → release 延遲解釋失敗。

## 8. Receipt

- 檔案：`native_release_model.py`
  sha256 `86f45ab851a446b4a903c8e5f0991acb198ecc4fc5d9d0d9bd0d05e38e77411b`；
  `test_native_release_model.py`
  sha256 `1f38d3cb88d9c89d9acf2296b94278f02ed4f73a7e3e98caf5f7f045f902bed3`。
- 測試：`cd experiments/mpc-research/native-v3 && python3 test_native_release_model.py`
  → `9 passed`（Python 3.14.4，stdlib only；pytest 亦可收集 `test_*`）。
  Sandbox 阻擋 pip，故未安裝 numpy／pytest。
- 沒有 SSH／GPU／API、push、merge、`gt done`；沒有讀 peer NV3 提案；
  沒有 native 數據、fixture 常數或統計保證被宣稱為結果。
- 資料 adapter：raw NV3 capture → episode schema（見模組 docstring）待 Gate A／B
  原始資料存在後依實際欄位實作；目前不猜測 capture 欄位。

## Round 2：交叉審查（peer 原始碼，非僅 test pass）

所有反例皆在 `test_native_release_model.py` 中，以 sha256 鎖定 Mayor 凍結的 R1 bytes 後 importlib 載入（`NV3_PEER_ROOT` 可覆寫；檔案不在則 SKIP，不偽造）。重現：`cd experiments/mpc-research/native-v3 && python3 test_native_release_model.py`。

### Gemini（`native_campaign_protocol.py`）— 不可採用為 campaign 協定
| # | 發現 | 反例 test |
|---|---|---|
| G1 | ≥10h 由「計畫 90s offer + 30s max-drain」×320 得出；違反「planned/max-drain 不計入 actual」 | `..._counts_planned_drain_...` |
| G2 | `compute_work_accounting`：end=4100 時 tail=0（27 個缺失位置被 `max(0,·)` 隱藏）；end=4200 時 tail=73 仍寫死「placeholder 1」原因；physical=end+1=4129 與 useful=4128 的單位不同 | `..._hides_missing_and_invents_tail_cause` |
| G3 | concurrency>1 即宣告 serial 被證偽：屬斷言而非資料 | （code review） |
| G4 | 偽重複保護只檢查標籤：同一 block 換 id/seed 複製 6 次 → `CONFIRMED_SUPERIOR` | `..._one_block_relabelled_six_times` |
| G6 | NAE 對空 origin 與缺 horizon 回傳 0 誤差（白送完美分數） | `..._score_as_zero_error` |
| G8 | StrongOneMove 不讀 continuation：c 與 48−c 決策完全相同；「MPC」為寫死閾值啟發式 → 弱基準 | `..._one_move_ignores_its_continuation` |
| G9 | `unseen_ood_mix` 有 10 個 Train blocks（非 OOD）；`mixed_short_long` 僅單一 prompt 2048，與宣稱 80/20 不符；到達率與「120% capacity」為虛構 | 同 G1 test |

### Sol（`native_experiment_audit.py`）— 整體嚴謹，tail 規則較我嚴格，已採納
- 採納：tail 步驟要求輸出 commit 不早於 finish（Sol：`begin < eos <= commit`）。我的 R1 只檢查 `start < finished`。**修正**：`forward_work_accounting` 新增 `tail_commit_before_finish` 證偽；falsifier test 已補。
- 反例 S1：censored 列在 `observed_until − sent_at = 30s` 無 first content，TTFT≤0.5s 已不可能，但 `good_upper` 仍為 1。這是保守的上界，不會產生錯誤宣稱，但會放寬界限而減損辨識力（`test_peer_sol_censored_upper_bound_...`）。
- 次要：`scheduled == origin+offset_s` 用精確浮點相等；`pair_order` 宣告未用；exact sign-flip 上限 16 blocks。皆不影響正確性。

### Astra（`native_response_planner.py`）— 介面嚴謹，無模型
- R1 懷疑：fresh `sum(costs)+c<=cap` 與 gateway 遞增 float 累計不一致。以 gateway CostSpec 形式、cap 16/32、20000 條隨機 admit/release 軌跡檢查，**未重現分歧**；撤回此疑慮，不宣稱缺陷。
- `stage="unknown"` 一律 fallback：過往 joined 樣本約 18%（1865/10367）屬 gateway 已 admit、native 未見，致多數決策為 `shadow_cap=None`。誤差容許度 error_below/above 為呼叫端純量，未經校準。one/two-move 計畫族不巢套。
- **自身修正（受此審查啟發）**：R1 以 `history_rate=-1.0` 哨兵值編碼「無歷史」，會被 logistic 當作真實速率外插。改為 `history_rate=0` + 顯式 `history_missing` 指示特徵。

### 未解決分歧
1. 未知 native 工作：Astra 棄權；我把它當特徵（`native_unknown`）。需資料決定（見實驗 E1）。
2. Tail 嚴格度：Sol 要求 `delivered_output_from_step=False` 的明確證據；我要求 commit≥finish 加 forward 匹配，未要求該欄位。若 native capture 有該欄位，應以 Sol 版本為準。
3. Gemini 的計畫時數與啟發式控制器：我認為不可作為 ≥10h 或 MPC 優越性的依據。
4. 16-arm 資格（40 HTTP、natural EOS 40、16 個 v3 audit valid、8 個 v2 FALSE 保留、20 個明確 tail token）只驗證 capture/HTTP/drain，**不**驗證預測、MPC 或 overhead；本報告無任何 native 預測結果。

### 鑑別性 native 實驗（Development blocks，不動 160021–160024）
- E1：在同一批 Train/Dev 原點上比較 `native_unknown` 特徵與 Astra 式棄權。量測棄權率與 1/3/5s release NAE 及覆蓋率。
- E2：實際 ledger 的 tied-cost 模糊率（區間寬度/上界）。若超過在看資料前預先登錄的門檻，則 per-mark 標籤選擇偏差不可忽略，需改為區間似然。
- E3：tail 發生率對輸出長度與 batch mix 的分佈（以 20 個 tail token 為種子 → 擴展 arms），並以 Sol 與本版 tail 規則交叉判定，任何不一致即為反例。
- E4：LL/LH/HL/HH 隨機化 cap 序列，檢驗 planned-cap 係數是否具因果意義（非僅相關）。
- E5：fluid vs batch_aware 在 Dev 的 block 校準與 OOD 棄權後誤差。batch_aware 未勝出即採 fluid。

### Round 2 receipt
- `native_release_model.py` sha256 `6e277d09c2ccfded2bb11e31164f97515c4bbdcc838f3df3f5a917864b297270`
- `test_native_release_model.py` sha256 `fd120e927353d4eec18c88b48711d68168a9bf3aa034138206b2b789b4ca1379`
- `python3 test_native_release_model.py` → `15 passed, 0 skipped`（Python 3.14.4，stdlib only）
- 本地 commit，bead 保持 in_progress；未執行 gt done／push。
