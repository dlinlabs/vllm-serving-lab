"""Focused contract tests for native_release_model. Fixtures exercise accounting and
causality only; they are not native measurements or performance evidence."""
import copy
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import native_release_model as m  # noqa: E402

DOMAIN, RUN = "clock-a", "run-a"


def _uuid(i):
    return f"{i:032x}"


def episode(requests, *, block=170001, partition="train", step=0.25, until=None,
            episode_id=None):
    """requests: (index, cost, prompt, max_tokens, admit, first, release)."""
    events = sorted([(r[4], 1, r) for r in requests] + [(r[6], -1, r) for r in requests],
                    key=lambda e: (e[0], -e[1]))
    ledger, live, reserved, seq = [], {}, 0.0, 0
    for at, sign, r in events:
        seq += 1
        if sign > 0:
            live[_uuid(r[0])] = r
            reserved += r[1]
        else:
            live.pop(_uuid(r[0]))
            reserved -= r[1]
        ledger.append(dict(event="mpc_ledger", run_id=RUN, clock_domain=DOMAIN, complete=True,
                           sequence=seq, effective_at=at, reserved_cost=max(reserved, 0.0)))
    end = until if until is not None else max(e[0] for e in events) + 0.5
    observations, t = [], 0.0
    while t <= end + 1e-9:
        seq_t = sum(1 for e in events if e[0] <= t)
        alive = [e[2] for e in events[:seq_t] if e[1] > 0
                 and not any(x[1] < 0 and x[2] is e[2] for x in events[:seq_t])]
        marks = [dict(request_id=_uuid(r[0]), cost=r[1], prompt_tokens=r[2], max_tokens=r[3],
                      received_at=r[4], admitted_at=r[4],
                      first_at=r[5] if r[5] <= t else None, scheduled_at=None) for r in alive]
        native = dict(schema="pr33-native-read-only-v1", complete=True, sampled_at=t + 0.01,
                      running=len(alive), waiting=0,
                      requests=[dict(request_id=f"chatcmpl-{_uuid(r[0])}-0000abcd",
                                     output_tokens=min(r[3], max(0, int((t - r[5]) * 50))))
                                for r in alive])
        observations.append(dict(
            gateway=dict(run_id=RUN, clock_domain=DOMAIN, complete=True, sequence=seq_t,
                         sampled_at=t, budget=16.0, requests=marks),
            received_at=t + 0.005, native=native, native_received_at=t + 0.02))
        t += step
    return dict(episode_id=episode_id or f"ep-{block}-{partition}", seed_block=block,
                partition=partition, clock_domain=DOMAIN, run_id=RUN,
                observations=observations, ledger=ledger)


def random_requests(seed, n=24):
    rng = random.Random(seed)
    out, t = [], 0.0
    for i in range(n):
        t += rng.uniform(0.1, 0.6)
        prompt = rng.choice((128, 4096))
        first = t + (0.05 if prompt == 128 else 0.3)
        out.append((seed * 1000 + i, 1.0 + 0.5 * (prompt == 4096), prompt, 128, t, first,
                    first + rng.uniform(0.5, 6.0)))
    return out


def test_truth_is_exact_for_distinct_costs_and_counts_observation_lag():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.30), (2, 2.0, 128, 128, 0.0, 0.1, 2.6)])
    rows = m.build_dataset([ep])
    origin = rows[0]                       # sampled 0.0, t0 0.02
    assert origin["reserved"] == 3.0
    assert origin["truth"][1.0] == (1.0, 1.0)
    assert origin["truth"][3.0] == (3.0, 3.0)
    late = next(o for o in rows if o["sampled_at"] == 0.25)
    # release at 0.30 happens after sampling but before t0+1 and is counted.
    assert late["truth"][1.0] == (1.0, 1.0)


def test_tied_costs_with_noncohort_release_yield_bounds_not_guesses():
    # Cohort mark 1 and non-cohort mark 3 (same cost) both release between snapshots.
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.05, 1.10), (2, 1.5, 128, 128, 0.0, 0.05, 4.0),
                  (3, 1.0, 128, 128, 1.01, 1.02, 1.05)], step=0.5)
    rows = m.build_dataset([ep])
    origin = next(o for o in rows if o["sampled_at"] == 0.0)
    # target 1.02+ ... t0=0.02 so h=1 target=1.02: neither 1.05 nor 1.10 released yet.
    assert origin["truth"][1.0] == (0.0, 0.0)
    mid = next(o for o in rows if o["sampled_at"] == 0.5 and _uuid(1) in o["cohort"])
    mid["t0"] = 0.5
    groups, unresolved = m.release_groups(mid, *_parsed_and_releases(ep))
    lo, hi = m.cumulative_truth(mid, groups, unresolved, 6.0, 0.57)  # target 1.07
    assert (lo, hi) == (0.0, 1.0)
    assert m.mark_label(_uuid(1), groups, unresolved, 6.0, 1.07) is None
    assert m.mark_label(_uuid(1), groups, unresolved, 6.0, 1.2) == 1


def _parsed_and_releases(ep):
    _, parsed = m.build_origins(ep)
    releases, _ = m.ledger_releases(ep, parsed)
    return parsed, releases


def _raises(fn, text):
    try:
        fn()
    except ValueError as error:
        assert text in str(error), error
    else:
        raise AssertionError("expected ValueError " + text)


def test_ledger_gap_and_snapshot_mismatch_are_rejected():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.6), (2, 2.0, 128, 128, 0.1, 0.2, 1.1)])
    gap = copy.deepcopy(ep)
    del gap["ledger"][2]
    _raises(lambda: m.build_dataset([gap]), "ledger_identity_or_gap")
    bad = copy.deepcopy(ep)
    bad["ledger"][1]["reserved_cost"] = 5.0
    _raises(lambda: m.build_dataset([bad]), "snapshot_ledger_mismatch")


def test_final_heldout_and_partition_leakage_are_refused():
    reqs = [(1, 1.0, 128, 128, 0.0, 0.1, 0.6)]
    _raises(lambda: m.build_dataset([episode(reqs, block=160022)]), "final_heldout_reserved")
    _raises(lambda: m.build_dataset([episode(reqs, block=170001, episode_id="a"),
                                     episode(reqs, block=170001, partition="development",
                                             episode_id="b")]),
            "seed_block_partition_leakage")
    rows = m.build_dataset([episode(reqs, partition="calibration")])
    _raises(lambda: m.fit(rows), "fit_requires_train_only")


def test_unjoined_native_and_stale_observation_are_rejected():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.6)])
    alien = copy.deepcopy(ep)
    alien["observations"][0]["native"]["requests"] = [
        dict(request_id=f"chatcmpl-{_uuid(99)}-0000abcd", output_tokens=0)]
    alien["observations"][0]["native"]["running"] = 1
    _raises(lambda: m.build_dataset([alien]), "native_unjoined_or_ambiguous")
    stale = copy.deepcopy(ep)
    stale["observations"][0]["native_received_at"] = 0.9
    stale["observations"][0]["native"]["sampled_at"] = 0.85
    _raises(lambda: m.build_dataset([stale]), "observation_stale_or_noncausal")


def test_features_do_not_depend_on_future_observations():
    ep = episode(random_requests(3))
    base = m.build_origins(ep)[0][8]
    future = copy.deepcopy(ep)
    for obs in future["observations"][9:]:
        for request in obs["native"]["requests"]:
            request["output_tokens"] = 0
    changed = m.build_origins(future)[0][8]
    for rid in base["cohort"]:
        for h in m.HORIZONS:
            assert m.mark_features(base, rid, h) == m.mark_features(changed, rid, h)


def test_end_to_end_train_only_fit_calibration_and_ood_abstention():
    episodes = [episode(random_requests(s), block=170000 + s, partition=p)
                for s, p in ((1, "train"), (2, "train"), (3, "train"), (4, "calibration"),
                             (5, "development"))]
    unseen = episode([(9001, 1.0, 999, 64, 0.0, 0.1, 3.0)], block=170099,
                     partition="development", episode_id="ood")
    result = m.evaluate(episodes + [unseen])
    assert result["train_blocks"] == [170001, 170002, 170003]
    dev = result["scores"]["development"]
    assert set(dev["models"]) == {"train_fraction", "fluid_history", "batch_aware"}
    assert dev["counts"]["ood_work_shape"] >= 1
    assert set(dev["models"]["batch_aware"]["blocks"]) == {170005}
    assert result["calibration"]["blocks"] == [170004]
    assert set(result["development_coverage"]) == {170005}
    assert not result["native_performance_accepted"] and not result["statistical_guarantee"]
    rows = m.build_dataset(episodes[:3])
    params = m.fit(rows)
    for origin in rows:
        pred, _ = m.predict(params, origin)
        if pred:
            values = [pred["batch_aware"][h] for h in m.HORIZONS]
            assert values == sorted(values) and values[-1] <= origin["reserved"] + 1e-9


def _baseline_4096_32(tail_start_offset=-0.001, extra_tail=0, drop=None):
    rid, steps, rows, t = "r", [], [], 0.0
    work = [(0, 2048), (2048, 2048)] + [(4096 + i, 1) for i in range(32 + extra_tail)]
    for i, (pos, n) in enumerate(work):
        if drop == i:
            continue
        steps.append(dict(step_id=f"s{i}", start=t, end=t + 0.01,
                          work=[dict(request_id=rid, position=pos, tokens=n)]))
        rows.append(dict(step_id=f"s{i}", executed_positions={rid: pos}, executed_counts={rid: n}))
        t += 0.01
    finished = steps[-1]["start"] - tail_start_offset
    request = dict(input_tokens=4096, output_tokens=32, finish_reason="stop", finished=finished)
    return m.forward_work_accounting(request, steps, rows, request_id=rid)


def test_tail_accounting_keeps_legacy_audit_false_and_explains_one_prefinish_position():
    report = _baseline_4096_32()
    assert (report["useful_positions"], report["physical_positions"], report["tail_positions"]) \
        == (4127, 4128, 1)
    assert (report["useful_steps"], report["tail_steps"]) == (33, 1)
    assert report["legacy_strict_audit_valid"] is False
    assert report["tail_accounted"] is True


def test_tail_accounting_falsifiers():
    assert "tail_scheduled_after_finish" in _baseline_4096_32(tail_start_offset=0.001)["problems"]
    assert "unexplained_tail_work" in _baseline_4096_32(extra_tail=1)["problems"]
    assert "position_gap_repeat_or_split" in _baseline_4096_32(drop=5)["problems"]
    assert not _baseline_4096_32(extra_tail=1)["tail_accounted"]
    late_commit = _baseline_4096_32(tail_start_offset=-0.02)   # start < finish, end < finish
    assert "tail_commit_before_finish" in late_commit["problems"]
    assert not late_commit["tail_accounted"]


# ---------------------------------------------------------------------------
# Round 2: reproducible counterexamples against the frozen peer R1 bytes.
# NV3_PEER_ROOT points at Mayor's byte-verified freeze; absent files => skipped.
# ---------------------------------------------------------------------------
import importlib.util  # noqa: E402
import os  # noqa: E402

PEER_ROOT = Path(os.environ.get("NV3_PEER_ROOT", "/home/daniel_lin/.copilot/session-state/"
                 "73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-round1-frozen"))
PEER_FILES = dict(
    gemini=("gemini/native_campaign_protocol.py",
            "087c68868f48f6bac9d1ac829c9dc3cb8b749f1c40b87f6d5364bb2d2f4bad79"),
    sol=("sol/experiments/mpc-research/native-v3/native_experiment_audit.py",
         "6abb94a4fbc1f3e238cd2d4687e996829304afe669b38efba14f2ca29074a554"),
)


class Skip(Exception):
    pass


def _peer(name):
    import hashlib
    rel, sha = PEER_FILES[name]
    path = PEER_ROOT / rel
    if not path.exists():
        raise Skip(f"frozen {name} bytes unavailable")
    assert hashlib.sha256(path.read_bytes()).hexdigest() == sha, "peer bytes are not the R1 freeze"
    spec = importlib.util.spec_from_file_location(f"nv3_peer_{name}", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def test_peer_gemini_work_accounting_hides_missing_and_invents_tail_cause():
    g = _peer("gemini")
    short = g.compute_work_accounting(worker_forward_end_position=4100)
    assert short.tail_work_tokens == 0          # 27 missing useful positions clamped away, no error
    long = g.compute_work_accounting(worker_forward_end_position=4200)
    assert long.tail_work_tokens == 73 and "placeholder 1" in long.tail_work_cause
    base = g.compute_work_accounting()
    assert base.physical_executed_positions == base.useful_total_tokens + 1 == 4129  # off-by-one units


def test_peer_gemini_superiority_accepts_one_block_relabelled_six_times():
    g = _peer("gemini")
    blocks = [g.IndependentSeedBlockOutcome(
        block_id=f"clone-{i}", seed=900 + i, workload_family="x", split="final", duration_s=90.0,
        control_decisions=90, offered_requests=500, policy_a_good_completions=300,
        policy_a_rejections=10, policy_a_solver_overruns=0,
        policy_b_good_completions=360 + (i % 2), policy_b_rejections=10,
        policy_b_solver_overruns=0) for i in range(6)]
    assert g.SuperiorityEvaluator().evaluate(blocks)["verdict"] == "CONFIRMED_SUPERIOR"


def test_peer_gemini_protocol_counts_planned_drain_and_trains_on_its_ood_family():
    g = _peer("gemini")
    protocol = g.build_native_campaign_protocol()
    summary = protocol["duration_summary"]
    assert summary["hours_requirement_satisfied"] is True
    assert summary["total_active_and_drain_seconds"] == summary["total_episodes"] * (90 + 30)
    ood_train = [b for b in protocol["groups"].values()
                 if b["family"] == "unseen_ood_mix" and b["split"] == "train"]
    assert len(ood_train) == 10
    mixed = protocol["groups"][next(k for k, v in protocol["groups"].items()
                                    if v["family"] == "mixed_short_long")]
    assert mixed["prompt_tokens"] == 2048       # declared 80/20 p128/p4096 mix is not represented


def test_peer_gemini_empty_origin_and_missing_horizon_score_as_zero_error():
    g = _peer("gemini")
    empty = g.compute_normalized_absolute_error({}, {}, 0.0)
    assert empty["mean_normalized_absolute_error"] == 0.0
    missing = g.compute_normalized_absolute_error({1: 0.0, 3: 0.0, 5: 0.0}, {}, 10.0)
    assert missing["mean_normalized_absolute_error"] == 0.0   # absent labels become perfect


def test_peer_gemini_one_move_ignores_its_continuation():
    g = _peer("gemini")
    state = g.ObservableBatchState()
    assert all(g.StrongOneMoveController(c).decide(state, q) ==
               g.StrongOneMoveController(48.0 - c).decide(state, q)
               for c in (16.0, 32.0) for q in range(10))


def test_peer_sol_censored_upper_bound_ignores_elapsed_ttft_deadline():
    sol = _peer("sol")
    rid = "a" * 32
    offer = dict(request_id=rid, logical_id="l0", offset_s=0.0, prompt_sha256="b" * 64,
                 prompt_tokens=128, max_tokens=128)
    row = dict(request_id=rid, requested_max_tokens=128, clock_domain="c", scheduled_at=10.0,
               status="censored", sent_at=10.0, first_content_at=None, last_content_at=None,
               terminal_at=None, stream_done=False, observed_until=40.0)
    result = sol.audit_arm([offer], [row], origin=10.0, window_s=5.0, clock_domain="c")
    # No first content after 30s, so TTFT<=0.5s is already impossible; upper should be 0.
    assert result["good_upper"] == 1


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    skipped = 0
    for test in tests:
        try:
            test()
            print("PASS", test.__name__)
        except Skip as reason:
            skipped += 1
            print("SKIP", test.__name__, reason)
    print(f"{len(tests) - skipped} passed, {skipped} skipped")
