"""Adversarial CPU contracts only; fixtures are not native measurements."""

import copy
import hashlib
import unittest

from native_experiment_audit import audit_arm, paired_effect, work_accounting


def uid(value):
    return hashlib.sha256(value.encode()).hexdigest()[:32]


def arm(seed=1, side="left", status="complete", output=2):
    rid = uid(f"{seed}-{side}")
    offer = dict(request_id=rid, logical_id="offer-0", offset_s=0,
                 prompt_tokens=128, max_tokens=4,
                 prompt_sha256=hashlib.sha256(f"prompt-{seed}".encode()).hexdigest())
    row = dict(request_id=rid, response_request_id=rid, clock_domain="client-epoch",
               requested_max_tokens=4,
               scheduled_at=10, sent_at=10.01, first_content_at=10.1,
               last_content_at=10.11, terminal_at=10.12, status=status,
               stream_done=True, stream_error=False, http_status=200,
               finish_reason="stop", native_eos_verified=True,
               usage=dict(prompt_tokens=128, completion_tokens=output))
    if status == "rejected":
        row.update(first_content_at=None, last_content_at=None, http_status=503,
                   admission_rejection=True, stream_done=False,
                   finish_reason=None, usage=None)
    if status == "censored":
        row.update(terminal_at=None, observed_until=10.2, stream_done=False,
                   finish_reason=None, usage=None)
    return dict(offers=[offer], rows=[row], origin=10, window_s=1,
                clock_domain="client-epoch")


def blocks(n=4):
    return [dict(seed=i, block_id=f"block-{i}", randomization_unit=f"unit-{i}",
                 partition="development",
                 independent_sampling=True, pair_order_randomized=True,
                 pair_order="left-first" if i % 2 == 0 else "right-first",
                 randomization_scheme="independent-fair-pair-order",
                 frozen_comparison_sha256=hashlib.sha256(b"test-design").hexdigest(),
                 left=arm(i, "left", "rejected"),
                 right=arm(i, "right")) for i in range(n)]


class OutcomeTests(unittest.TestCase):
    def test_natural_truncated_censored_and_failures_keep_full_offered_denominator(self):
        case = arm()
        natural = audit_arm(**case)
        self.assertEqual((natural["good_lower"], natural["good_upper"]), (1, 1))
        case["rows"][0].update(finish_reason="length")
        case["rows"][0]["usage"]["completion_tokens"] = 4
        truncated = audit_arm(**case)
        self.assertEqual(truncated["outcomes"][0]["label"], "truncated")
        self.assertEqual(truncated["good_upper"], 0)
        censored = audit_arm(**arm(status="censored"))
        self.assertEqual((censored["good_lower"], censored["good_upper"]), (0, 1))
        for status in ("rejected", "failed", "cancelled", "timeout"):
            result = audit_arm(**arm(status=status))
            self.assertEqual(result["offered"], 1)
            self.assertEqual(result["good_upper"], 0)
        cohort = arm()
        cohort["offers"], cohort["rows"] = [], []
        for i, status in enumerate(("complete", "rejected", "failed", "cancelled",
                                    "timeout", "censored")):
            item = arm(i, status=status)
            item["offers"][0]["logical_id"] = f"offer-{i}"
            cohort["offers"].extend(item["offers"])
            cohort["rows"].extend(item["rows"])
        result = audit_arm(**cohort)
        self.assertEqual((result["offered"], result["good_lower"], result["good_upper"]),
                         (6, 1, 2))

    def test_zero_bool_float_and_missing_successful_output_are_invalid(self):
        for output in (0, True, 1.5, None):
            with self.subTest(output=output), self.assertRaises(ValueError):
                audit_arm(**arm(output=output))
        self.assertEqual(audit_arm(**arm(output=1))["outcomes"][0]["request_mean_tpot_s"], 0)

    def test_all_timestamps_are_finite_and_ordered_even_single_token(self):
        mutations = [("scheduled_at", float("nan")), ("sent_at", True),
                     ("first_content_at", float("inf")), ("last_content_at", 9),
                     ("terminal_at", 10.05)]
        for field, value in mutations:
            case = arm(output=1)
            case["rows"][0][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                audit_arm(**case)
        with self.assertRaises(ValueError):
            audit_arm(**{**arm(), "origin": float("nan")})

    def test_slo_uses_scheduled_origin_and_terminal_not_last_chunk(self):
        case = arm()
        case["rows"][0]["terminal_at"] = 10.3
        self.assertEqual(audit_arm(**case)["good_lower"], 0)
        case = arm()
        case["rows"][0].update(sent_at=10.6, first_content_at=10.7,
                               last_content_at=10.71, terminal_at=10.72)
        self.assertEqual(audit_arm(**case)["good_lower"], 0)

    def test_missing_extra_duplicate_clock_identity_and_unverified_eos_fail_closed(self):
        for kind in ("missing", "extra", "duplicate", "clock", "identity", "eos",
                     "stream", "limit"):
            case = arm()
            if kind == "missing":
                case["rows"] = []
            elif kind == "extra":
                case["rows"][0]["request_id"] = uid("not-offered")
            elif kind == "duplicate":
                case["rows"] *= 2
            else:
                field, value = {"clock": ("clock_domain", "worker-epoch"),
                                "identity": ("response_request_id", uid("other")),
                                "eos": ("native_eos_verified", False),
                                "limit": ("requested_max_tokens", 8),
                                "stream": ("stream_done", False)}[kind]
                case["rows"][0][field] = value
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                audit_arm(**case)

    def test_censored_late_first_cannot_become_good_and_invalid_cutoff_fails(self):
        case = arm(status="censored")
        case["rows"][0].update(first_content_at=10.6, last_content_at=10.6,
                               observed_until=10.7)
        self.assertEqual(audit_arm(**case)["good_upper"], 0)
        case["rows"][0]["observed_until"] = 10.5
        with self.assertRaises(ValueError):
            audit_arm(**case)


class BlockTests(unittest.TestCase):
    def test_four_blocks_have_exact_two_sided_floor_not_request_level_significance(self):
        result = paired_effect(blocks(), bootstrap_samples=200)
        self.assertEqual(result["effect_good_per_s"], 1)
        self.assertEqual(result["exact_two_sided_signflip_p"], .125)
        self.assertEqual(result["percentile_bootstrap_ci95"], [1, 1])
        self.assertFalse(result["native_performance_accepted"])
        self.assertFalse(result["independent_sampling_verified"])

    def test_nonsignificance_has_no_equivalence_or_superiority_label(self):
        cases = blocks()
        cases[0]["left"], cases[0]["right"] = cases[0]["right"], cases[0]["left"]
        cases[1]["left"], cases[1]["right"] = cases[1]["right"], cases[1]["left"]
        result = paired_effect(cases, bootstrap_samples=200)
        self.assertEqual(result["effect_good_per_s"], 0)
        self.assertEqual(result["exact_two_sided_signflip_p"], 1)
        self.assertLess(result["percentile_bootstrap_ci95"][0], 0)
        self.assertGreater(result["percentile_bootstrap_ci95"][1], 0)
        self.assertNotIn("equivalent", result)
        self.assertNotIn("superior", result)

    def test_cloned_block_is_rejected_even_after_cosmetic_relabeling(self):
        for kind in ("clone", "seed", "unit", "tape", "physical", "declaration"):
            cases = blocks()
            if kind == "clone":
                cases[1] = copy.deepcopy(cases[0])
            elif kind == "seed":
                cases[1]["seed"] = cases[0]["seed"]
            elif kind == "unit":
                cases[1]["randomization_unit"] = cases[0]["randomization_unit"]
            elif kind == "tape":
                for side in ("left", "right"):
                    cases[1][side]["offers"][0]["prompt_sha256"] = (
                        cases[0][side]["offers"][0]["prompt_sha256"])
            elif kind == "physical":
                cases[1]["right"] = copy.deepcopy(cases[1]["left"])
            else:
                cases[1]["independent_sampling"] = False
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                paired_effect(cases, bootstrap_samples=20)

    def test_pair_requires_identical_tape_window_and_slo(self):
        for field in ("window_s", "ttft_s", "prompt_sha256"):
            cases = blocks()
            if field == "prompt_sha256":
                cases[0]["right"]["offers"][0][field] = "a" * 64
            else:
                cases[0]["right"][field] = 2
            with self.subTest(field=field), self.assertRaises(ValueError):
                paired_effect(cases, bootstrap_samples=20)

    def test_unrandomized_or_changed_policy_design_cannot_get_permutation_p(self):
        for field, value in (("pair_order_randomized", False),
                             ("pair_order", "unknown"),
                             ("randomization_scheme", "balanced-permuted-order"),
                             ("frozen_comparison_sha256", "a" * 64)):
            cases = blocks()
            cases[1][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                paired_effect(cases, bootstrap_samples=20)

    def test_unresolved_outcomes_withhold_ci_and_permutation_not_impute_success(self):
        cases = blocks()
        cases[0]["right"] = arm(0, "right", "censored")
        result = paired_effect(cases)
        self.assertEqual(result["effect_bounds_good_per_s"], [.75, 1])
        self.assertIsNone(result["effect_good_per_s"])
        self.assertIsNone(result["exact_two_sided_signflip_p"])
        self.assertIsNone(result["percentile_bootstrap_ci95"])

    def test_exact_permutation_is_scale_invariant_not_absolute_epsilon_dependent(self):
        for duration in (1, 10 ** 15):
            cases = blocks()
            for case in cases:
                for side in ("left", "right"):
                    case[side]["window_s"] = duration
            self.assertEqual(paired_effect(cases, bootstrap_samples=20)
                             ["exact_two_sided_signflip_p"], .125)

    def test_partitions_and_old_final_seed_cannot_leak_into_block_analysis(self):
        for mutation in ("mixed", "missing", "heldout"):
            cases = blocks()
            if mutation == "mixed":
                cases[1]["partition"] = "train"
            elif mutation == "missing":
                cases[1].pop("partition")
            else:
                cases[1]["seed"] = 160022
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                paired_effect(cases)

    def test_bootstrap_interpolation_remains_finite_at_opposite_large_effects(self):
        cases = blocks(2)
        cases[1]["left"], cases[1]["right"] = cases[1]["right"], cases[1]["left"]
        for case in cases:
            for side in ("left", "right"):
                item = case[side]
                item.update(origin=0, window_s=1e-308)
                for name in ("scheduled_at", "sent_at", "first_content_at",
                             "last_content_at", "terminal_at"):
                    if item["rows"][0][name] is not None:
                        item["rows"][0][name] = 0
        result = paired_effect(cases, bootstrap_samples=2, random_seed=0)
        import math
        self.assertTrue(all(math.isfinite(v) for v in result["percentile_bootstrap_ci95"]))


def physical_steps(prompt=4096, output=32):
    lengths = [2048, prompt - 2048] + [1] * (output - 1)
    position, steps = 0, []
    for i, count in enumerate(lengths):
        steps.append(dict(step_id=f"step-{i}", position=position, tokens=count,
                          executed_position=position, executed_tokens=count,
                          cuda_forward_matched=True, clock_domain="native-host",
                          host_forward_start=1 + i * .01,
                          output_commit_at=1.1 + i * .01))
        position += count
    steps.append(dict(step_id="tail", position=position, tokens=1,
                      executed_position=position, executed_tokens=1,
                      cuda_forward_matched=True, clock_domain="native-host",
                      host_forward_start=1.9, output_commit_at=2.1,
                      pre_finish_placeholder=1, delivered_output_from_step=False))
    return dict(prompt_tokens=prompt, output_tokens=output, steps=steps,
                eos_at=2, clock_domain="native-host")


class WorkTests(unittest.TestCase):
    def test_physical_tail_is_reported_without_turning_old_equality_true(self):
        result = work_accounting(**physical_steps())
        self.assertEqual(result["useful_input_minimum"], 4127)
        self.assertEqual(result["physical_input_tokens"], 4128)
        self.assertEqual(result["undelivered_tail_input_tokens"], 1)
        self.assertFalse(result["old_final_progress_equal"])
        self.assertFalse(result["native_qualification_accepted"])
        case = physical_steps()
        case["steps"].pop()
        self.assertTrue(work_accounting(**case)["old_final_progress_equal"])

    def test_tail_needs_full_join_and_not_placeholder_or_elapsed_time_alone(self):
        for field, value in (("pre_finish_placeholder", 0),
                             ("pre_finish_placeholder", True),
                             ("cuda_forward_matched", False),
                             ("executed_tokens", 2),
                             ("delivered_output_from_step", True),
                             ("host_forward_start", 2.01),
                             ("output_commit_at", 1.99),
                             ("clock_domain", "gpu-relative")):
            case = physical_steps()
            case["steps"][-1][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                work_accounting(**case)

    def test_gaps_duplicate_steps_missing_work_and_more_excess_are_not_relaxed(self):
        for kind in ("gap", "duplicate", "missing", "extra"):
            case = physical_steps()
            if kind == "gap":
                case["steps"][2]["position"] += 1
            elif kind == "duplicate":
                case["steps"][-1]["step_id"] = "step-0"
            elif kind == "missing":
                case["steps"] = case["steps"][:2]
            else:
                case["steps"][-1].update(tokens=2, executed_tokens=2)
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                work_accounting(**case)

    def test_useful_forward_cannot_start_after_eos_or_regress_in_host_order(self):
        for index, start in ((0, 3), (2, 0)):
            case = physical_steps()
            case["steps"][index].update(host_forward_start=start, output_commit_at=4)
            with self.subTest(index=index), self.assertRaises(ValueError):
                work_accounting(**case)


def peer_counterexamples(frozen_root):
    """Replay pinned peer defects read-only; run separately from portable unit tests."""
    import importlib.util
    import sys
    from dataclasses import replace
    from pathlib import Path

    root = Path(frozen_root)
    receipts = {}

    def load(name, relative, expected=None):
        path = root / relative
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if expected is not None and digest != expected:
            raise ValueError(f"Frozen peer source changed: {relative}")
        receipts[relative] = digest
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        return module

    base = "experiments/mpc-research/native-v3/"
    opus = load("native_release_model", "opus/" + base + "native_release_model.py",
                "86f45ab851a446b4a903c8e5f0991acb198ecc4fc5d9d0d9bd0d05e38e77411b")
    ot = load("nv3_opus_r1_tests", "opus/" + base + "test_native_release_model.py",
              "1f38d3cb88d9c89d9acf2296b94278f02ed4f73a7e3e98caf5f7f045f902bed3")
    astra = load("native_response_planner", "astra/" + base + "native_response_planner.py",
                 "e19db180e1fb06c6c34ff21e9b76131e85749edc7f403d4aa65acf366b7a3326")
    at = load("nv3_astra_r1_tests", "astra/" + base + "test_native_response_planner.py",
              "862bc1db7a9baba167f8cf0baa7997c93201cfb7fdce47152e4a6dadaf8e3f08")
    gemini = load("native_campaign_protocol", "gemini/native_campaign_protocol.py",
                  "087c68868f48f6bac9d1ac829c9dc3cb8b749f1c40b87f6d5364bb2d2f4bad79")
    load("nv3_gemini_r1_tests", "gemini/test_native_campaign_protocol.py",
         "a94770f63e58e68e2046b98876831e609d98a6e595ec204402465620f5864d42")
    findings = {}

    ep = ot.episode([(1, 1., 128, 128, 0., .1, .6)])
    foreign = copy.deepcopy(ep)
    for obs in foreign["observations"]:
        obs["native"].update(clock_domain="foreign-clock", run_id="foreign-run")
    findings["opus_foreign_native_identity_accepted"] = bool(opus.build_origins(foreign)[0])
    assert findings["opus_foreign_native_identity_accepted"]
    bad_time = copy.deepcopy(ep)
    bad_time["ledger"][-1]["effective_at"] = -100
    findings["opus_release_before_live_origin_accepted"] = opus.build_dataset([bad_time])[0]["truth"][1.]
    assert findings["opus_release_before_live_origin_accepted"] == (1., 1.)
    plans = ([(0, 16), (.5, 32), (1, 16)], [(0, 32), (.5, 16), (1, 16)])
    averages = [{h: opus._planned_budget({"cap_plan": p}, 0, h, 16)
                 for h in opus.HORIZONS} for p in plans]
    findings["opus_order_distinct_plans_same_all_horizon_features"] = averages
    assert averages[0] == averages[1]
    train_origins = []
    for prompt in (128, 4096):
        train_origins.extend(opus.build_origins(ot.episode([
            (1, 1., prompt, 128, 0., .1, 1.),
            (2, 1., prompt, 128, 0., .1, 1.)]))[0])
    mixed = opus.build_origins(ot.episode([
        (1, 1., 128, 128, 0., .1, 1.),
        (2, 1., 4096, 128, 0., .1, 1.)]))[0][0]
    findings["opus_unseen_mixture_passes_marginal_ood_envelope"] = opus.ood_reasons(
        mixed, opus.support_envelope(train_origins))
    assert findings["opus_unseen_mixture_passes_marginal_ood_envelope"] == []
    findings["opus_tail_accounted_without_cuda_placeholder_commit_clock"] = (
        ot._baseline_4096_32()["tail_accounted"])
    assert findings["opus_tail_accounted_without_cuda_placeholder_commit_clock"]
    previous_predict = opus.predict
    try:
        opus.predict = lambda params, origin: (
            {"batch_aware": {h: .5 for h in opus.HORIZONS}}, [])
        calibration = [dict(partition="calibration", seed_block=i, reserved=1,
                            truth={h: (value, value) for h in opus.HORIZONS})
                       for i, value in ((1, 0), (2, 1))]
        a = opus.calibrate({}, calibration)["bands"][1.]["lower"]
        b = opus.calibrate({}, calibration[:1] + calibration[1:] * 20)["bands"][1.]["lower"]
        findings["opus_same_two_blocks_origin_resampling_changes_band"] = [a, b]
        assert (a, b) == (-.5, .5)
    finally:
        opus.predict = previous_predict

    contradiction = replace(at.state(), native_running=0)
    decision = astra.plan_response(
        contradiction, at.evaluation(), at.StubModel(), expected_identity=at.IDENTITY,
        timing=astra.Timing("test-clock", 10.1, .02, .5, .05), clock=lambda: 10.)
    findings["astra_decode_mark_with_zero_native_running"] = dict(
        status=decision.status, active_permit=decision.active_permit)
    assert decision.status == "shadow" and decision.active_permit is False

    template = gemini.RequestOutcome("r", 128, 2, 10., 10.01, 10.1, 10.12,
                                     10., "stop", True)
    bool_good = gemini.validate_request_outcome(replace(template, output_tokens=True))["is_good"]
    post_good = gemini.validate_request_outcome(replace(template, client_post_at=100.))["is_good"]
    findings["gemini_boolean_output_and_post_after_terminal_good"] = [bool_good, post_good]
    assert bool_good and post_good
    accounting = gemini.compute_work_accounting()
    findings["gemini_exclusive_end_off_by_one"] = accounting.physical_executed_positions
    assert accounting.physical_executed_positions == 4129
    missing = gemini.compute_work_accounting(worker_forward_end_position=100)
    findings["gemini_missing_useful_work_tail_clipped_to_zero"] = missing.tail_work_tokens
    assert missing.tail_work_tokens == 0
    findings["gemini_concurrency_alone_serial_falsification"] = gemini.verify_gpu_elapsed_clock_semantics(
        .2, .1, 2)["serial_service_model_falsified"]
    assert findings["gemini_concurrency_alone_serial_falsification"]
    ledger = gemini.ObservableBatchState()
    record = gemini.MarkedReservationRecord("duplicate", 8., 10., 128, 128)
    assert ledger.admit(record) and ledger.admit(record)
    ledger.release("duplicate", 11.)
    findings["gemini_duplicate_admission_orphan_reservation"] = [
        ledger.reserved_cost, len(ledger.active_reservations)]
    assert findings["gemini_duplicate_admission_orphan_reservation"] == [8., 0]

    aggregate = [gemini.IndependentSeedBlockOutcome(
        f"block-{i}", 180000 + i, "short_homogeneous", "development", 10.,
        10, 1, 10, 0, 0, good, 0, 0) for i, good in enumerate((22, 24, 21, 25))]
    inference = gemini.SuperiorityEvaluator(min_blocks=4).evaluate(aggregate, num_permutations=1)
    findings["gemini_four_impossible_aggregates_one_draw"] = {
        k: inference[k] for k in ("verdict", "two_sided_permutation_p_value")}
    assert inference["verdict"] == "CONFIRMED_SUPERIOR"
    assert inference["two_sided_permutation_p_value"] == 0
    protocol = gemini.build_native_campaign_protocol(offers_duration_s=0, max_drain_duration_s=120)
    findings["gemini_zero_offers_planned_max_drain_satisfies_hours"] = dict(
        summary=protocol["duration_summary"],
        all_schedules_empty=all(not e["actuator_schedule"] for e in protocol["episodes"]))
    assert protocol["duration_summary"]["hours_requirement_satisfied"]
    assert findings["gemini_zero_offers_planned_max_drain_satisfies_hours"]["all_schedules_empty"]
    state = gemini.ObservableBatchState()
    findings["gemini_horizon_and_continuation_parameters_unused"] = [
        gemini.RecedingHorizonMPCController(horizon_steps=h).decide(state, 5) for h in (1, 5)]
    assert findings["gemini_horizon_and_continuation_parameters_unused"] == [32., 32.]
    return dict(scope="Pinned CPU counterexamples; not native performance or safety evidence",
                source_sha256=receipts, counterexamples=findings)

if __name__ == "__main__":
    unittest.main()
