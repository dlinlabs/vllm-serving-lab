"""Offline NV3 outcome/block audit; no actuator or native qualification authority."""

import hashlib
from fractions import Fraction
import itertools
import json
import math
import random
import re
import statistics


def _finite(value, name):
    try:
        valid = type(value) in (int, float) and math.isfinite(value) and value >= 0
    except OverflowError:
        valid = False
    if not valid:
        raise ValueError(f"Invalid finite nonnegative {name}")
    return value


def _integer(value, name, minimum=1):
    if type(value) is not int or value < minimum:
        raise ValueError(f"Invalid integer {name}")
    return value


def _text(value, name):
    if not isinstance(value, str) or not value:
        raise ValueError(f"Missing {name}")
    return value


def _uuid(value):
    if not isinstance(value, str) or not re.fullmatch("[0-9a-f]{32}", value):
        raise ValueError("Physical request UUID must be exact lowercase hex32")
    return value


def _sha(value):
    if not isinstance(value, str) or not re.fullmatch("[0-9a-f]{64}", value):
        raise ValueError("Missing SHA256 provenance")
    return value


def _digest(value):
    return hashlib.sha256(json.dumps(
        value, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode()).hexdigest()


def audit_arm(offers, rows, *, origin, window_s, clock_domain,
              ttft_s=0.5, tpot_s=0.05):
    """Score a fixed offered cohort, including drain; unresolved rows stay intervals.

    Offers add logical_id, offset_s, prompt_sha256 and prompt_tokens to the
    physical request_id/max_tokens manifest. Rows use capture_chat field names;
    natural stops additionally require an independently joined EOS receipt.
    """
    _finite(origin, "origin")
    if _finite(window_s, "window") == 0:
        raise ValueError("Window must be positive")
    _text(clock_domain, "clock domain")
    _finite(ttft_s, "TTFT SLO")
    _finite(tpot_s, "TPOT SLO")
    manifest, logical, tape = {}, set(), []
    for offer in offers:
        rid = _uuid(offer["request_id"])
        lid = _text(offer["logical_id"], "logical ID")
        if rid in manifest or lid in logical:
            raise ValueError("Duplicate offered physical/logical UUID")
        offset = _finite(offer["offset_s"], "offered offset")
        if offset >= window_s:
            raise ValueError("Offer outside frozen window")
        prompt = _integer(offer["prompt_tokens"], "prompt tokens")
        limit = _integer(offer["max_tokens"], "output limit")
        recipe = _sha(offer["prompt_sha256"])
        manifest[rid] = offer
        logical.add(lid)
        tape.append((lid, offset, prompt, limit, recipe))
    if not manifest:
        raise ValueError("Empty offered cohort")
    outcomes, seen = [], set()
    for row in rows:
        rid = _uuid(row["request_id"])
        if rid in seen or rid not in manifest:
            raise ValueError("Duplicate/unoffered physical UUID")
        seen.add(rid)
        offer = manifest[rid]
        if (_integer(row.get("requested_max_tokens"), "captured output limit")
                != offer["max_tokens"]):
            raise ValueError("Captured output limit differs from frozen offer")
        if row.get("clock_domain") != clock_domain:
            raise ValueError("Outcome clock differs")
        scheduled = _finite(row.get("scheduled_at"), "scheduled origin")
        if scheduled != origin + offer["offset_s"]:
            raise ValueError("Row origin differs from frozen offered tape")
        status = row.get("status")
        if status not in ("complete", "rejected", "failed", "cancelled", "timeout", "censored"):
            raise ValueError("Unknown outcome status")
        sent = row.get("sent_at")
        if sent is not None:
            if _finite(sent, "send") < scheduled:
                raise ValueError("Send precedes offer")
        elif status != "censored":
            raise ValueError("Resolved outcome lacks send")
        first, last = row.get("first_content_at"), row.get("last_content_at")
        if (first is None) != (last is None):
            raise ValueError("Partial first/last chronology")
        if first is not None:
            if sent is None or not sent <= _finite(first, "first") <= _finite(last, "last"):
                raise ValueError("Invalid content chronology")
        if status == "censored":
            if row.get("terminal_at") is not None or row.get("stream_done") is not False:
                raise ValueError("Censored row claims termination")
            until = _finite(row.get("observed_until"), "censor cutoff")
            if until < max(scheduled, sent or scheduled, last or scheduled):
                raise ValueError("Censor cutoff precedes observed events")
        else:
            terminal = _finite(row.get("terminal_at"), "terminal")
            if terminal < (last if last is not None else sent):
                raise ValueError("Terminal precedes observed events")
        usage = row.get("usage")
        count = None
        if usage is not None:
            if not isinstance(usage, dict):
                raise ValueError("Malformed usage")
            prompt = _integer(usage.get("prompt_tokens"), "native prompt")
            count = _integer(usage.get("completion_tokens"), "output tokens", 0)
            if prompt != offer["prompt_tokens"] or count > offer["max_tokens"]:
                raise ValueError("Usage differs from offered token constraints")
        lower, upper, label, ttft, tpot = 0, 0, status, None, None
        if status == "complete":
            _integer(count, "successful output tokens")
            if (first is None or row.get("stream_done") is not True
                    or row.get("stream_error") is not False
                    or type(row.get("http_status")) is not int or row["http_status"] != 200
                    or row.get("response_request_id") != rid):
                raise ValueError("Incomplete/mismatched successful Chat")
            reason = row.get("finish_reason")
            if reason == "stop":
                if row.get("native_eos_verified") is not True:
                    raise ValueError("Stop without independent native EOS join")
                label = "natural"
            elif reason == "length":
                if count != offer["max_tokens"]:
                    raise ValueError("Length finish below requested output limit")
                label = "truncated"
            else:
                raise ValueError("Unqualified completion reason")
            ttft = first - scheduled
            tpot = 0.0 if count == 1 else (terminal - first) / (count - 1)
            lower = upper = int(label == "natural" and ttft <= ttft_s and tpot <= tpot_s)
        elif status == "rejected":
            if (row.get("admission_rejection") is not True
                    or row.get("http_status") != 503
                    or row.get("response_request_id") != rid
                    or first is not None or count not in (None, 0)):
                raise ValueError("Unqualified admission rejection")
        elif status == "censored":
            upper = int(first is None or first - scheduled <= ttft_s)
        outcomes.append(dict(request_id=rid, logical_id=offer["logical_id"],
                             label=label, good_lower=lower, good_upper=upper,
                             ttft_s=ttft, request_mean_tpot_s=tpot))
    if seen != set(manifest):
        raise ValueError("Missing full-offered outcome rows; do not drop or fill them")
    return dict(offered=len(manifest), window_s=window_s, outcomes=outcomes,
                good_lower=sum(r["good_lower"] for r in outcomes),
                good_upper=sum(r["good_upper"] for r in outcomes),
                tape_sha256=_digest(sorted(tape)), physical_uuids=sorted(seen),
                slo=dict(ttft_s=ttft_s, tpot_s=tpot_s),
                scope="Natural complete-good per offered cohort, including drain;"
                      " not accepted-only throughput or steady-state capacity")


def paired_effect(blocks, *, bootstrap_samples=4000, random_seed=0):
    """Audit raw paired independent blocks before estimating right-minus-left.

    Each block supplies seed, block_id, randomization_unit, independent_sampling,
    pair_order_randomized, pair_order, randomization_scheme,
    partition, frozen_comparison_sha256 and left/right arguments to audit_arm.
    Design declarations are not verified facts.
    """
    _integer(bootstrap_samples, "bootstrap draws")
    _integer(random_seed, "bootstrap seed", 0)
    if bootstrap_samples > 100000:
        raise ValueError("Bootstrap exceeds offline bounded audit")
    if not 2 <= len(blocks) <= 16:
        raise ValueError("Require 2..16 independent blocks for bounded exact enumeration")
    seeds, ids, units, tapes, physical = set(), set(), set(), set(), set()
    effects, exact_effects, intervals = [], [], []
    unresolved, comparison, partition = False, None, None
    for block in blocks:
        seed = _integer(block["seed"], "workload seed", 0)
        if 160021 <= seed <= 160024:
            raise ValueError("Reserved old final heldout remains unused")
        split = block.get("partition")
        if split not in ("train", "calibration", "development", "final"):
            raise ValueError("Missing/unknown block partition")
        partition = partition or split
        if split != partition:
            raise ValueError("Mixed block partitions; no train/calibration/final pooling")
        bid = _text(block["block_id"], "block ID")
        unit = _text(block["randomization_unit"], "randomization unit")
        if block.get("independent_sampling") is not True:
            raise ValueError("Independent block sampling not declared")
        if (block.get("pair_order_randomized") is not True
                or block.get("pair_order") not in ("left-first", "right-first")
                or block.get("randomization_scheme") != "independent-fair-pair-order"):
            raise ValueError("Exchangeable randomized pair order not declared")
        frozen = _sha(block.get("frozen_comparison_sha256"))
        comparison = comparison or frozen
        if frozen != comparison:
            raise ValueError("Frozen policy/comparison configuration changed")
        if seed in seeds or bid in ids or unit in units:
            raise ValueError("Repeated independent block identity")
        seeds.add(seed)
        ids.add(bid)
        units.add(unit)
        left, right = audit_arm(**block["left"]), audit_arm(**block["right"])
        if (left["tape_sha256"] != right["tape_sha256"]
                or left["window_s"] != right["window_s"] or left["slo"] != right["slo"]):
            raise ValueError("Pair differs in offered tape/window/SLO")
        if left["tape_sha256"] in tapes:
            raise ValueError("Repeated offered tape is not a fresh independent workload block")
        tapes.add(left["tape_sha256"])
        for arm in (left, right):
            uuids = set(arm["physical_uuids"])
            if physical & uuids:
                raise ValueError("Physical UUID reused across arms/blocks")
            physical.update(uuids)
            unresolved |= any(r["label"] == "censored" for r in arm["outcomes"])
        duration = left["window_s"]
        lo = (right["good_lower"] - left["good_upper"]) / duration
        hi = (right["good_upper"] - left["good_lower"]) / duration
        _finite(abs(lo), "block effect lower magnitude")
        _finite(abs(hi), "block effect upper magnitude")
        intervals.append((lo, hi))
        effects.append(lo)
        exact_effects.append(Fraction(right["good_lower"] - left["good_lower"])
                             / Fraction(duration))
    result = dict(blocks=len(blocks), frozen_comparison_sha256=comparison,
                  partition=partition,
                  effect_bounds_good_per_s=[
        statistics.mean(lo for lo, _ in intervals),
        statistics.mean(hi for _, hi in intervals)],
        effect_good_per_s=None, percentile_bootstrap_ci95=None,
        exact_two_sided_signflip_p=None, independent_sampling_verified=False,
        native_performance_accepted=False,
        inference_scope="Equal-weight independent paired blocks; sharp no-effect"
                        " randomization null requires independent fair pair-order swaps"
                        " and no carryover/order-by-policy effect."
                        " Bootstrap percentile interval is approximate, not a guarantee;"
                        " neither non-significance nor this report establishes equivalence.")
    if unresolved:
        result["inference_withheld"] = "Unresolved full-offered outcomes"
        return result
    effect = statistics.mean(effects)
    # Enumerate block label swaps, never request/step/within-block replicates.
    observed_sum = abs(sum(exact_effects))
    extreme = sum(abs(sum(s * d for s, d in zip(signs, exact_effects)))
                  >= observed_sum
                  for signs in itertools.product((-1, 1), repeat=len(effects)))
    rng = random.Random(random_seed)
    draws = sorted(statistics.mean(rng.choices(effects, k=len(effects)))
                   for _ in range(bootstrap_samples))

    def quantile(p):
        index = (len(draws) - 1) * p
        low = math.floor(index)
        high = math.ceil(index)
        weight = index - low
        return (1 - weight) * draws[low] + weight * draws[high]

    result.update(effect_good_per_s=effect,
                  block_effects_good_per_s=effects,
                  percentile_bootstrap_ci95=[quantile(.025), quantile(.975)],
                  exact_two_sided_signflip_p=extreme / (2 ** len(effects)),
                  bootstrap_samples=bootstrap_samples, bootstrap_seed=random_seed)
    return result


def work_accounting(*, prompt_tokens, output_tokens, steps, eos_at, clock_domain):
    """New descriptive useful/physical/tail ledger, NOT a relaxed v2 audit.

    Steps are normalized per-request joined scheduler/worker rows. An adapter
    must supply actual counts/positions and resolved matched CUDA evidence.
    No duration is converted into an absolute GPU/host timestamp.
    """
    prompt = _integer(prompt_tokens, "prompt tokens")
    output = _integer(output_tokens, "delivered output tokens")
    eos = _finite(eos_at, "native EOS")
    _text(clock_domain, "native host clock")
    useful_end = prompt + output - 1
    position, seen, tails, last_begin = 0, set(), [], -1
    for step in steps:
        key = _text(step["step_id"], "step ID")
        if key in seen:
            raise ValueError("Repeated physical step")
        seen.add(key)
        start = _integer(step["position"], "position", 0)
        count = _integer(step["tokens"], "physical input count")
        if start != position:
            raise ValueError("Physical work gap/repeat")
        if (step.get("executed_position") != start
                or type(step.get("executed_position")) is not int
                or step.get("executed_tokens") != count
                or type(step.get("executed_tokens")) is not int
                or step.get("cuda_forward_matched") is not True
                or step.get("clock_domain") != clock_domain):
            raise ValueError("Unmatched scheduler/worker/CUDA work")
        begin = _finite(step.get("host_forward_start"), "host forward start")
        commit = _finite(step.get("output_commit_at"), "host output commit")
        if begin > commit:
            raise ValueError("Forward wrapper begins after output commit")
        if begin < last_begin or begin >= eos:
            raise ValueError("Forward start regresses or begins after natural EOS")
        last_begin = begin
        position = start + count
        if position > useful_end:
            # Only the explicitly qualified one-placeholder natural-EOS case.
            if (start < useful_end or count != 1 or position != useful_end + 1
                    or type(step.get("pre_finish_placeholder")) is not int
                    or step["pre_finish_placeholder"] != 1
                    or not begin < eos <= commit
                    or step.get("delivered_output_from_step") is not False):
                raise ValueError("Unexplained physical excess; retain failed audit")
            tails.append(key)
    if position < useful_end:
        raise ValueError("Physical work below delivered-token minimum")
    return dict(useful_input_minimum=useful_end, physical_input_tokens=position,
                undelivered_tail_input_tokens=position - useful_end,
                tail_step_ids=tails, old_final_progress_equal=position == useful_end,
                native_qualification_accepted=False,
                scope="Contiguous executed input positions; delivered-token minimum"
                      " is not measured exclusive GPU demand. Matched current-stream"
                      " forward evidence is not an absolute clock or whole-service duration.")
