# Sol NV3 independent round 1: identifiable outcomes before predictive control

## Status and evidence boundary

Independent proposal and bounded offline audit, not a new synthetic benchmark,
native model fit, ten-hour receipt, qualification pass, or MPC win. No NV3 peer
proposal was read. Scope is this report and its sibling
`native_experiment_audit.py` / `test_native_experiment_audit.py` only.
No Gateway, observer, core, configuration, remote, or GPU change.
Mayor owns Beads, SSH, execution, and paid-resource decisions.

Read campaign at base `10f2fb0`, native-v2
`decision-and-next-native-protocol.zh-TW.md`, my previous
`round3/sol-revision.md`, actual
`../native-identification-and-model-falsification.zh-TW.md`,
`prefill_lab/contracts.py`, and the native-v2 collector.
The serial HTTP-service interpretation remains falsified: the old empty-start
90s arm delivered 2449 natural completions against that model's upper bound
2004. That does not falsify predictive control or all queueing models.
The old commit-progress model did not beat persistence consistently and used
realized sampling gaps, not fixed future horizons.

Mayor's shared new observation is treated as reported native evidence, not
reproduced locally: exact joined UUID, prompt4096/output32/natural EOS; 34
physical steps, two prefill and 32 decode; contiguous executed end4128 versus
delivered input minimum4127. The final placeholder was1, its host forward
wrapper started before EOS and output commit followed EOS, with a matched
executed CUDA forward. The v2 audit is still FALSE. No local raw capture for
this new observation was supplied; the executable test reproduces the
accounting case with explicitly artificial timestamps, not native timing.

Authorized deployment is the sole user Pod RTX4090/24564MiB/driver595.91.07,
vLLM0.30.0, Torch2.13.0, Transformers5.22.1 and restored pinned Qwen4B.
These shared environment facts are not a loaded-revision or performance
attestation. Final heldout160021-160024 is not read, fitted, or evaluated.

## 1. Observable batch state and transition

Use a receipt-cut history, not a claimed fully observed GPU Markov state.
At origin k retain:

| Component | Available state and provenance | Unresolved part |
|---|---|---|
| Admission | Exact UUID/original-cost ledger; pending/applied cap version; command fence; receipt timestamp | Accepted but unmatched native work stays explicitly unknown |
| Queue | Prompt tokens and recipe, admission age, waiting/admitted-not-first bins | Scheduler order not inferred from HTTP residence |
| Decode | Joined physical request, delivered output so far, context/progress bins, most recent batch participation | Residual output/EOS and pending physical work remain latent |
| Batch history | Last received prefill query-token/chunk-size distribution, decoder/context distribution, placeholder count if observable | Post-drain execution spans are labels, not live features |
| Capture health | Source/epoch/clock, dropped/pending/overflow flags, receipt age/width | Missing values are not zero workload |
| Environment | Receipt-qualified runtime identity and available temperature/clock timeline | Old/partial NVML is not complete environmental control |

Costs16/32 are whole-request reservation budgets, NOT concurrency, scheduler
token limits, or KV bytes. Exact transitions retain old costs on cap reduction:

```
R_next = R + sum(actual admitted original costs) - sum(actual released original costs)
admit only when R + original_cost <= actually_applied_cap
```

No extra overshoot allowance and no forced eviction when `R > reduced_cap`.
Engine EOS, HTTP terminal, output commit, and ledger release remain separate
events. Use native host timestamps only within their qualified domain; join
client/native clocks by exact identity and receipt brackets, not subtraction.

Predict the distribution of cost release, first-content deadline passage,
natural complete-good count, physical progress, and tail incidence jointly
conditioned on this history and a supported assigned cap program. A bounded
stratified/regularized direct response model is the first candidate; a
batch-aware semi-Markov extension is warranted only if phase/history ablation
improves block-held-out forecasts. This report does not implement or fit either.
Latent EOS/tail uncertainty is retained rather than assigning every output
token a deterministic exclusive-service coefficient.

## 2. Useful, physical, and tail-work accounting

Keep the v2 `audit_capture` untouched, including its equality failure. A new
versioned descriptive ledger can reconcile without retrospectively passing it:

* **Delivered-useful input minimum**: `prompt + delivered_output - 1` under the
  declared no-cache/no-speculation protocol. This is a token-position minimum,
  not measured GPU demand or exclusive service duration.
* **Physical input work**: contiguous, exact matched scheduler/worker input
  positions/counts with resolved executed CUDA forward evidence. Preserve
  all34 steps and their identity; do not delete the final step.
* **Undelivered tail input**: physical positions beyond that minimum, with
  request/step evidence that no delivered output came from that work. A
  placeholder alone is insufficient. Label unexplained excess as failed,
  not generic "async tolerance."

The bounded `work_accounting` diagnostic supports only the shared
one-placeholder extra-input case: exact single extra position, matched
execution, native host clock, forward wrapper start before EOS, commit at/after
EOS, and independently determined no delivered output from that step.
It outputs4127/4128/1 and `old_final_progress_equal=False` for the structural
fixture, with qualification explicitly false. Extra/gapped/replayed/unmatched
work fails closed. Those timestamps do NOT place GPU execution on the host
clock: GPUelapsed is a relative current-stream span, not an absolute clock,
other-stream coverage, or complete sampling/transport service.

Mayor's future adapter must retain raw scheduler and worker rows, verify
actual_tokens/counts/positions, EOS/output mapping, step digest and worker/run
identity before normalization. Caller-provided booleans are attestations, not
independently verified native joins. OFF captures without step evidence can
qualify outcomes but cannot qualify this physical ledger.

Falsification experiments, not relaxed acceptance:

1. Repeat natural EOS with different actual output lengths, prompt lengths
   and observed batch compositions. Predict zero/one tail incidence before
   seeing labels; distinguish useful decode steps from physical decode steps.
2. Include mixed prefill/decode and pending-async cases. Test whether excess
   is always the last one-placeholder input or sometimes an earlier/multi-step
   phenomenon; the latter invalidates this bounded reconciliation contract.
3. Stop/abort/length-finish controls remain separate cohorts. Their drain work
   must not be mislabeled as natural EOS or dropped from costs.
4. Independently verify no repeated/gapped positions, no mismatched actual
   worker counts, and executed versus merely scheduled extra work. Deep-trace
   confirmation in a separate diagnostic epoch may qualify execution scope,
   but does not establish unprofiled timing or observer equivalence.

## 3. Response, uncertainty, and full-offered outcomes

Freeze every offered logical ID, physical HTTP-attempt UUID, prompt recipe
SHA, prompt/output limits, scheduled origin and window before execution.
Each physical attempt occurs once globally; identical logical trace IDs across
paired arms are intentional. Do not reoffer after ambiguous BEGIN/POST.
Retain a terminal/censor row for every offer; missing/extra/duplicate rows fail
the audit rather than improving a conditional denominator.

Natural complete-good requires positive integer output, exact successful Chat
UUID, complete non-error stream, finite ordered same-client-clock chronology,
matching prompt/limits, stop reason plus independent native EOS evidence,
scheduled-origin TTFT<=0.5s and request-mean
`(terminal-first)/(output-1)<=0.05s`; one token has TPOT0.
Last chunk is NOT substituted for terminal. Token-gap/P99 claims are absent.
Length-finished outputs are labeled truncated and count0 for this frozen
natural-complete primary outcome; report their complete response counts
separately rather than discarding them. Reject/error/cancel/client timeout
count0. Timeout is a resolved HTTP failure, not proof the engine drained:
physical-work and release labels may remain censored.

Right-censoring yields lower/upper good-count bounds, not assumed success or
imputed native completion. A first token already past TTFT has upper0.
Otherwise conservative upper1 is retained. Report late drain completions in
the original offered cohort; dividing cohort good by its offered window is
not a steady-state capacity claim.

Joint predictive uncertainty should use whole held-out block trajectories,
not independent token/request residuals. Fit on Train; choose features on
grouped Train folds; calibrate on disjoint Calibration blocks; select policy
and continuation only on Development. Report empirical coverage and miss
rates with the block count, not certified chance constraints.

## 4. One-step, multi-step, action ranking, and OOD evaluation

Log forecasts at fixed origins before labels exist, with source hash, model
hash, feature receipt cut, plan, and prediction publication time. Do not input
realized future sampling gaps, final output lengths, post-drain spans, future
offered tapes, or outcomes of paired counterfactual arms.

Primary predictive endpoint: then-live cumulative original-cost release at
1/3/5s, normalized by positive origin reservation and averaged per independent
block. Zero-reservation origins are a separate stratum. Secondary: natural-good
count errors, deadline Brier/reliability, physical/tail incidence, joint
trajectory coverage and ranking of actually supported plans. Predicting token
progress well does not establish release accuracy or control goodput.

Compare ledger/history-only, persistence, hold-current empirical response and
batch-history extension under identical origins and labels. Publish one-step
and free-running multi-step errors separately; do not feed actual intermediate
states to a purported multi-step rollout. Assess calibration before maximizing
over plans, because ranking/selection can exploit model error.

OOD: withheld prompt/output combinations, unseen mixture/order, burst and
recovery, accepted-unmatched work, altered observer source/epoch and available
thermal/clock shifts. Bounds must come from qualified Train/Calibration support,
not invented KV thresholds. Abstain on missing identity, stale/unknown work,
unseen history/action support, unresolved labels or capture overflow.
Reject fitting if supported binding states are too few; state aliasing is a
measurable limitation, not a reason to invent latent features.

## 5. Strong One-move versus MPC, causal support, safe deployment

Only after model qualification, compare Fixed16, development-selected
best-supported-fixed, development-selected reactive, strong One-move, and MPC.
One-move and MPC share 5s forecast window, same uncertainty trajectories,
future-arrival LAW (not realized tape), constraints, tail scoring, control
frequency, and development-frozen continuation. One-move frees its first move;
MPC may free two/three future moves only where sequence support exists.
Both apply just their first move and replan at the same rate. No deliberately
poor Fixed16 continuation or short-window straw baseline.

First run randomized open-loop LL/LH/HL/HH cap16/32 sequences from verified
drained starts, paired common offered tapes within fresh independent workload
blocks, randomized arm order with washout/drain and exact application fences.
Include literal-disabled/enabled-OFF/LIGHT ablations in separate service
epochs and same-action repeats. Repeats estimate within-block EOS/observer
variation, NOT independent seeds. Actual batch composition is a mediator:
randomized nominal bursts do not make a batch-duration causal coefficient.
Sequence ITT effects do not license rolling same-state counterfactuals after
states have diverged; unsupported policy plans remain masked.

Before closed-loop outcomes: freeze configuration hashes, metric, contrasts,
minimum useful effect, independent-block sampling and randomization, handling
of censoring, multiplicity and precision plan from Development variance.
The paired module estimates equal-block right-minus-left natural-good/window,
block-resampled approximate percentile95% CI and exact two-sided block
sign-flip p for a sharp no-effect null under the stated exchangeability design.
This exact enumeration specifically requires independent fair pair-order
coins and no carryover/order-by-policy effect after qualified washout. A
balanced/constrained randomization has a different assignment space and must
not be passed to this routine as independent flips.
It rejects cloned block/seed/randomization unit, repeated logical tapes,
physical UUID reuse, mismatched paired tapes/windows/SLOs, changed frozen
comparison configuration and unrandomized declarations. It withholds CI/p
whenever any offered outcome is censored.

These are guards against obvious pseudoreplication, NOT proof of physical
independence, random assignment, or truthful provenance. Mayor must verify raw
receipts and actual independent block generation. Equal synthetic effects can
produce a degenerate bootstrap interval; it is not a variance or significance
guarantee. Four independent pairs have minimum two-sided exact p0.125, not
0.05. No "superior", "equivalent", or "MPC impossible" classifier exists.
The exact sign-flip routine intentionally caps at16 blocks; a larger frozen
final protocol needs a separately reviewed inference implementation, not
splitting into batches or silently treating approximate p as exact.
Do not take this exploratory pairwise p as multiplicity-adjusted evidence for
winning against all baselines.

Report offered/accept/reject/failure/natural/truncated/censored counts, SLO
quantiles, tail work, action binding incidence, affected offered mass, ranking
errors, full observation-to-solve-to-persist-to-POST-to-fence cost, deadline
fallback, oscillation and recovery. Small first-action disagreement is not a
bound on benefit without affected mass and outcome consequences.

No deployment authority from this module. Candidate first runs shadow-only,
then a separately permitted bounded trial with rollback to the best
development-supported fixed/reactive policy. Keep existing expiry, memory,
timeout, observation completeness and source fences. Unknown work or OOD
invokes qualified fallback; lowering cap does not evict old reservations.
Uncalibrated KV/joint risk is not declared hard-safe. Mayor alone runs GPU/API
work and manages paid time; no claimed ten-hour elapsed experiment or quote.

## Local source/test receipt

Owned directory: `experiments/mpc-research/native-v3/`.
Exact implementation/test SHA256:

```
6abb94a4fbc1f3e238cd2d4687e996829304afe669b38efba14f2ca29074a554  native_experiment_audit.py
da6705c687e8d4fa8aa3df072e751f6c141d1f300e4d9eb5f374b51c289ee96e  test_native_experiment_audit.py
```

Executed local command:

```
python3 -m unittest discover -s experiments/mpc-research/native-v3 \
  -p test_native_experiment_audit.py -v
```

Result: **15 tests passed**, CPython3.14.4; outcome, clone/leakage,
randomization, exact four-block p floor, censored inference, and physical
tail counterexamples. These are standard-library CPU unit tests, not native
measurements. `python` was absent and `python3 -m pytest` reported missing
pytest, so the existing unittest-compatible tests were run with the built-in
runner without installing or changing dependencies.

Full Linux CPU acceptance was not executed: it requires CPython3.12, a clean
checkout and local port checks; this assigned offline scope forbids socket
exploration and includes pre-existing untracked `.beads/` / `.runtime/`.
No full-suite, lint-tool, GPU, deployment or statistical qualification claim.
Those pre-existing paths remain untouched. Only the three owned files are
staged for a local commit with the Copilot trailer, retained for Mayor review.
Mayor can retrieve its exact commit from this branch's HEAD and independently
check the recorded implementation/test hashes. Bead status is not mutated:
Mayor retains in_progress for peer review.

Persistence receipt: the environment automatically checkpointed the owned
source/tests/report before the explicit commit attempt; that attempt found
nothing staged. Verified checkpoint
`c8ef4ce06a36d381882ecf68799913855923bcde` contains the exact source/test hashes
above and matches the worktree. This receipt update is committed separately
with the required Copilot trailer; existing automatic commits are not amended.

## Round 2: frozen-peer review and owned surgical corrections

### Evidence update and review boundary

Read all three frozen reports, complete implementations and focused tests,
not just their passing receipts. Reviewed R1 commits:
Opus `17f62c71aadd8fdcea8d017498ce34fdb13e08cc`,
Astra `a51404649e5fcec8338720371abc3d842ebd5b7b`,
Gemini `4c53d40ed7a8300a0d5eb8c1b0b5ab590d503e15`.
The replay helper verifies all six source/test SHA256s before importing them;
it never patches or writes peer files. Findings refer to those frozen bytes,
not a peer's later repair. No new experiment or peer agreement is invented.

Mayor now reports actual qualification at `2587d2b`:16 executed arms,
40 HTTP complete,40 natural EOS, all16 v3 audits valid,8 old v2 audits FALSE
retained,20 explicit tail tokens. Accept this as **reported capture/HTTP/drain
qualification**, superseding the R1 "not yet qualified" status at that time.
I did not rerun it or inspect the separate Mayor accounting implementation.
It is NOT prediction, MPC, observer-overhead, absolute GPU-clock, exclusive
service, independent efficacy, or ten-hour qualification.

In the tables, `Opus`, `Astra`, `Gemini` source abbreviations mean respectively
`native_release_model.py`, `native_response_planner.py`,
`native_campaign_protocol.py` in their frozen artifacts. Replay output contains
15 named counterexample groups; bool-output and post chronology are two
distinct cases grouped in one result.

### Opus: useful response candidate, incomplete qualification

| Source | Finding / reproduced witness | Disposition |
|---|---|---|
| `Opus:72`, `_native` | Adding foreign native clock and run IDs to every otherwise valid frame still produces origins. Gateway identity is checked; native clock/epoch/source is not. | Reject the report's same-run/same-clock qualification claim for this parser. Require actual native provenance before feature availability or any cross-domain arithmetic. |
| `Opus:169`, `ledger_releases` | Change a release effective time to -100 while the mark remains live at origin0: dataset truth is still `(1,1)` released by1s. Sequence conservation does not enforce event-time chronology or release-after-admit. `_marks:49` also does not require positive prompt count or first-after-admit. | A negative/retroactive release is not exact ground truth. Preserve the failure; require monotonic effective times and consistent snapshot/event brackets. |
| `Opus:93`, `_planned_budget` | Plans L-at0/H-at.5/L-at1 and H-at0/L-at.5/L-at1 have identical averaged cap features at1/3/5s:24,18.6667,17.6. | Order-dependent responses cannot be distinguished by these plan features. This is a representational alias, not proof that their native outcomes differ. Keep assigned sequence/order features or abstain if a native contrast separates them. |
| `Opus:320-331`, support envelope | Two-short and two-long homogeneous Train origins admit an unobserved short+long mixture with `ood_reasons=[]`. Marginal ranges and a set of individual shapes are not joint mixture/history/sequence support. | Reject "never extrapolate outside Train support" as a general guarantee. Report the actual envelope and test joint-support failures separately. |
| `Opus:460`, calibration | With the same two Calibration blocks, repeat origins of the positive-residual block20 times: lower band changes from-.5 to+.5. No independent block was added. | It pools origin residuals, not block residuals. This is not block-balanced calibration or a split-conformal guarantee. Freeze cadence/weighting and use block trajectory scores for a block-level claim. |
| `Opus:523`, tail accounting | The peer's baseline fixture returns `tail_accounted=True` without CUDA resolution, placeholder, clock or output-commit/discard evidence. Duplicate worker keys are also collapsed into a dict. | Counts/positions and schedule-before-finish are necessary but do not prove the asserted executed/discarded tail mechanism. Do not promote this thin accounting flag into raw native qualification. |

Accept the Train-only fit and reserved-final seed guard, equal-block evaluation,
whole-origin-cost bounds, exact cost-tie ambiguity rather than invented UUID
release assignment, and explicit absence of native/MPC acceptance. The stable
sigmoid is preferable to naïve exponentiation. However, the Newton fitter has
no reported convergence/conditioning certificate; model predictions still
need finite/convergence diagnostics on actual Train data. Fitting pooled
origin/mark rows is not independent-block fitting simply because final scores
are aggregated by block.

Per-horizon mean release forecasts are not a joint stochastic transition
kernel. Three-offset cummax is useful monotonicity, not calibrated whole-cost
trajectory scenarios. A time-average cap coefficient is not a causal slope,
especially after differently assigned histories diverge. Passing individual
shape/range checks does not qualify new rolling MPC sequences.

### Astra: strongest interface boundaries, still not an adapter or model

| Source | Finding / review | Disposition |
|---|---|---|
| `Astra:212`, state validator | A known decode mark with `native_running=0` still gives `status="shadow"` under the peer's stub, with `active_permit=False`. There is no consistency check between native counts and marked native stages. | Reproducible adapter-validation gap, not an active-actuation exploit. An atomically joined physical prefix must reconcile stages/counts; if timestamps make the relationship uncertain, retain unknown work and abstain. |
| `Astra:248,276` | IDs bind supplied objects and aggregate counts, not loaded source/revision, received history, raw natural-EOS outcomes, support, or calibrated uncertainty. | Accept the explicit external-artifact boundary. Nonempty receipt IDs are not independently verified attestations; the future adapter/model owner must audit them. |
| `Astra:326` | Six calls and checks before/after callbacks do not preempt a hung callback. Planner elapsed excludes upstream observation/features and downstream persist/POST/fence. The report explicitly says so. | Accept this limitation; do not claim a native100ms/full-path runtime guarantee. Deadline origin, watchdog and last-moment epoch/version recheck remain deployment prerequisites. |

Accept exact whole-cost admission/release, preserving reservations on a cap
drop, shared immutable evaluation/scenario pairing, original-ID release sets,
tail-versus-model-error separation, missing-plan abstention, strong common
continuation and always-inactive permit. No new synthetic plant is hidden
behind the planner. Bounds are reporting envelopes, not proven risk limits.

Important mathematical boundary: the one-prefix and two-prefix families start
the same reactive continuation at different times and are not automatically
nested. Even with exact forecasts, open-loop two-move value is not a theorem
about gain when both algorithms replan every second. Keeping One-move for the
same first action is reasonable; empirical closed-loop gain still requires
randomized full algorithms. The planner's actual model/support/OOD behavior
is delegated to `predict`, not implemented by its string IDs. I do not claim
this interface already predicts or enforces native KV safety.

### Gemini: reject the implemented superiority/campaign claims

| Source | Finding / reproduced witness | Disposition |
|---|---|---|
| `Gemini:120`, work accounting | It converts exclusive forward end4128 into4129 physical positions, and `P+O-1` into `P+O` "useful" work. End100 clips missing useful work to tail0 while returning the same placeholder-cause string. | Off-by-one and missing-work concealment. A scalar endpoint/default constant cannot validate contiguous worker steps or a CUDA/EOS mechanism. Correct shared count is4127 minimum/4128 physical/1 tail. |
| `Gemini:172`, clock semantics | `active_concurrent_requests=2` alone sets serial-model-falsified. Two simultaneous HTTP offers can queue behind valid serial .1s service intervals `[0,.1]`, `[.1,.2]`; residence .1/.2 includes waiting. | Retain the actual old drained-start capacity falsification, not this generic concurrency test. Aggregate elapsed cannot establish GPU/host order or exclusive per-request demand. |
| `Gemini:232`, outcome validator | Both boolean output and a POST at100 after first10.1/terminal10.12 are scored good. `stop` alone does not audit a complete exact-UUID native-EOS response. | Zero and NaN fixes are insufficient: strict integer type, POST chronology, full stream/UUID/EOS joins and explicit full-offered censoring remain necessary. |
| `Gemini:488`, ledger | Admit the same cost8 record twice, release once: reserved8 with zero live marks. Mutable records can also change the cost subsequently subtracted. | Fails UUID uniqueness/original-cost conservation. Do not mask negative/corrupt releases with `max(0,...)`; retain immutable admission costs and fail on duplicate/reuse. |
| `Gemini:319,344`, evaluator | Four distinct-ID aggregates with offered1 but10–25 good completions, `min_blocks=4`, one Monte Carlo draw return `CONFIRMED_SUPERIOR`, p0. Exact four-pair floor is.125. | Aggregate counts are not validated against raw offers. Monte Carlo p0 is not an exact p or defensible superiority receipt. Default6 is not power, and configurable minima are not independent sampling proof. |
| `Gemini:344`, statistical claims | Zero variance is called artificial replication; no CI or Holm implementation exists in the complete source. Mean>=margin plus a zero-effect p does not establish a statistically supported minimum practical effect. | Equal independently generated differences can be genuine. Identify blocks/physical provenance rather than rejecting all equal outcomes. Freeze contrasts/multiplicity and distinguish null0 from a useful-effect margin. |
| `Gemini:640,653`, comparators | "MPC" returns the same cap32 for horizon1 or5; both horizon and One-move continuation parameters are unused in decisions. Functions contain backlog heuristics, no forecast/sequence objective. | Reject these labels as implementations of strong One-move/MPC. Merely returning16/32 does not test predictive control or a fair common continuation. |
| `Gemini:737`, duration | With offered duration0 and maximum drain120, all320 schedules are empty but hours_requirement_satisfied=True at10.6667h. Default offered time is only8h; the remaining2.6667h is maximum drain. | Planning capacity is not actual informative duration. This output cannot satisfy the user's actual>=10h requirement or account for execution, setup, idle, failures or real drain. |

Further source-based limits: the purported immutable protocol is a mutable
dict with a stored hash, no later verification/freeze enforcement. Episode
tape keys are not emitted frozen arrival/prompt contents or physical UUIDs.
Mixed/burst/shift descriptions/rates do not become executable mixture/arrival
laws in the generated episodes. The same `unseen_ood_mix`2048/384 shape is
included in Train and Final; that alone is not withheld-shape OOD. No actual
state-support validator or OOD abstention precedes the heuristic decisions.
Calling Fixed16 "safe" without current epoch/expiry/unknown-tail/recovery
evidence is unsupported; lowering cap never evicts old costs. Unsupported24
in a best-fixed example needs fresh action qualification, not promotion from
the16/32 grid. Nominal6req/s is not measured120% native capacity.
These flaws do not imply that predictive control is impossible.

### Owned Sol corrections and limits retained

The replay also confirmed two defects in my frozen R1:

1. Four positive effects scaled to1e-15 give p1 instead of.125 because of the
   absolute1e-12 comparison tolerance. Round2 enumerates sign swaps using exact
   `Fraction(count_difference)/Fraction(recorded_window)` sums; effect/CI
   reporting remains floating point. This preserves ties and scale invariance
   for the declared input numbers, without making independence a theorem.
2. Interpolating between -1e308/+1e308 overflows their difference: frozen R1
   emits `[inf,inf]`. Round2 uses convex weighted interpolation; the adversarial
   test selects both endpoints and now requires finite intervals.

Also require an explicit common partition before paired analysis, reject the
reserved old final seeds before reading outcomes, reject oversized nonfinite
integer timestamps as ValueError, and require per-request host forward starts
not to regress or begin at/after natural EOS. The last rule is a conservative
host-order consistency gate, NOT a GPU execution-before-EOS assertion.
No other path, old audit, peer source, controller or native collector changed.

Remaining limitations are intentional and explicit: declared independence,
pair randomization/config hashes and `native_eos_verified` do not authenticate
raw events by themselves. Missing rows fail; censoring withholds inference;
bootstrap95% is approximate and can degenerate for genuine equal effects.
The exact null concerns zero effect under independent fair label/order swaps
and qualified no-carryover, not equivalence, power, useful-margin proof or
joint superiority against five baselines. Larger/constrained assignment
spaces need a separately frozen analysis. This module has no actuation permit.

### Unresolved disagreements and discriminating native experiments

| Question | Discriminating experiment / required outcome |
|---|---|
| Does one-placeholder accounting explain all qualified natural cases? | Keep all raw steps/EOS/commit lineage in short/long/mixed repeats and cancel/length controls. Test extra0/1/multiple positions, post-EOS launches and duplicate/gapped/unresolved workers. A generic+1 allowance is not an explanation. |
| Does cap order matter beyond its1/3/5s average? | Randomize the equal-average LH/HL first-second pair with identical origin/tape and common continuation. Publish release/good forecasts before outcomes. If responses separate by order, average-only plan features are falsified; if not, report precision, not universal equivalence. |
| Can marginal feature boxes qualify mixtures? | Train on homogeneous short/long, withhold mixtures and burst/recovery histories. Log support flags and block-held-out release/count/ranking errors plus abstention coverage. This tests the demonstrated accepted-unseen-mixture alias. |
| Are calibration bands stable under cadence/blocks? | On the same sealed data, change offline origin sampling cadence without adding blocks; compare origin-pooled and whole-block trajectory calibration, then evaluate fresh independent Calibration/Development blocks. No extra GPU time is needed for the resampling diagnostic. |
| Are count/stage/tail observations complete at the decision cut? | Join Gateway/native snapshots by exact IDs and recorded receipt brackets; replay delayed observation, accepted-not-visible, cap-drop and reservation-empty-but-pending-forward cases. Count/stage conflicts must become unknown/abstain, not fabricated fully observed state. |
| Does extra planning improve actual closed-loop outcomes? | After model/continuation support, randomize complete strong One-move/MPC algorithms at the same cadence, law, horizon/tail, offered cohort and full-path runtime cost. Report binding mass, policy disagreement consequences and independent block effects, not the stub's open-loop scores. |
| Has informative native experimentation actually reached10h? | Maintain actual start/end/clock/epoch/source-linked intervention and executed-drain receipts, union overlapping intervals on the sole GPU and retain invalid arms. Separate actual experiment duration, GPU span labels, setup, idle and billing time. Planned schedules/max drain alone are never added as executed time. |

Mayor alone executes these interventions. Current16-arm capture qualification
does not answer these model, observer, causal, precision, duration or deployment
questions. No physical decomposition or elaborate predictor is accepted by
consensus, and no peer's passing unit suite supplies missing native evidence.

### Round2 source/test receipt

Final owned implementation/test SHA256s:

```
44423a5d76782da9d9118ddacbdb94e82d6963b70a65dfdf95d4e82d5487251d  native_experiment_audit.py
336d298fdc766618e126ce19c952ee1ccb3057f061041a575d07d6e53aeb6bf6  test_native_experiment_audit.py
```

Executed `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover
-s experiments/mpc-research/native-v3 -p test_native_experiment_audit.py -v`:
**19 tests passed**, no skips. Separately, all15 named peer witness groups and
all six frozen source/test digests verified successfully:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=experiments/mpc-research/native-v3 \
python3 -c 'import json,sys; from test_native_experiment_audit import peer_counterexamples; print(json.dumps(peer_counterexamples(sys.argv[1]), sort_keys=True, indent=2, allow_nan=False))' \
  /path/to/pr33-native-v3-round1-frozen
```

Executed against Mayor's supplied frozen directory. Portable unit tests do not
require that external archive; the pinned-peer replay deliberately does.
The two numerical regression cases were separately run against frozen Sol R1
and produced p1 / `[inf,inf]`, so they are not tests that only restate the fix.
All reproduction is CPU contract evidence, not new native performance.
Local commit only; Mayor retains in_progress for peer review.
