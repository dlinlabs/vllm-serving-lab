"""Adversarial CPU contracts only; fixtures are not native measurements."""

import copy
import hashlib
import itertools
import json
import unittest

from native_experiment_audit import (
    OfferedReceiptHistory, audit_arm, comparison_digest, paired_effect,
    cap_plan_support_audit, future_api_good_partition, train_schema_audit, work_accounting,
)


def uid(value):
    return hashlib.sha256(value.encode()).hexdigest()[:32]


class ReceiptClock:
    def __init__(self):
        self.value = 0.

    def __call__(self):
        return self.value


class CallbackReplay:
    """Deterministic callback publications only; no native-file receipt reconstruction."""

    def __init__(self):
        self.clock = ReceiptClock()
        self.history = OfferedReceiptHistory(
            publisher_run_id=uid("callback-publisher"),
            observer_run_id=uid("callback-observer"), clock_domain="test-clock",
            clock=self.clock)
        self.sequence = 0

    def callback(self, kind, rid, event_at, published_at, received_at, **fields):
        publication = dict(
            schema=OfferedReceiptHistory.SCHEMA, publisher_run_id=uid("callback-publisher"),
            clock_domain="test-clock", publication_seq=self.sequence + 1,
            kind=kind, request_id=rid, event_at=event_at, published_at=published_at,
            **fields)
        self.clock.value = received_at
        receipt = self.history.receive(publication)
        self.sequence += 1
        return receipt

    def offered(self, rid, event, published, received, scheduled, cost):
        return self.callback("offered", rid, event, published, received,
                             scheduled_at=scheduled, original_cost=cost,
                             cost_spec_sha256="a" * 64)

    def cut(self, at, *, now=None):
        if now is not None:
            self.clock.value = now
        return self.history.cut(at)


class OfferedReceiptTests(unittest.TestCase):
    def replay(self):
        replay = CallbackReplay()
        a, b, c = (uid(name) for name in ("callback-a", "callback-b", "callback-c"))
        replay.offered(a, 0., .01, .02, .1, 2.)
        replay.offered(b, .03, .04, .05, .2, 3.)
        replay.offered(c, .06, .07, .08, .3, 5.)
        replay.callback("sent", a, .1, .11, .12)
        replay.callback("terminal", b, .15, .16, .17, status="cancelled")
        replay.callback("sent", c, .5, .51, .52)
        replay.callback("terminal", c, .55, .56, .57, status="rejected")
        replay.callback("first", a, .6, .61, .62)
        replay.callback("terminal", a, .7, .71, .72, status="complete")
        return replay

    def test_callback_replay_is_deterministic_and_keeps_unsent_rejected_and_late_offers(self):
        first, second = self.replay().cut(1., now=1.), self.replay().cut(1., now=1.)
        self.assertEqual(first, second)
        self.assertEqual(first["counts"]["offered"], 3)
        self.assertEqual(first["counts"]["sent"], 2)
        self.assertEqual(first["counts"]["late_sent"], 1)
        self.assertEqual(first["counts"]["pending"], 0)
        self.assertEqual(first["counts"]["terminal"],
                         dict(complete=1, rejected=1, cancelled=1, failed=0, timeout=0))
        self.assertEqual([r["original_cost"] for r in first["requests"]], [2., 3., 5.])
        self.assertIsNone(first["requests"][1]["sent"])
        self.assertEqual(first["requests"][0]["first"]["published_at"], .61)
        self.assertEqual(first["requests"][0]["first"]["received_at"], .62)
        self.assertFalse(first["active_mpc_permit"])
        self.assertFalse(first["independent_native_eos_verified"])

    def test_delayed_first_publication_cannot_backfill_a_cut_or_expose_future_terminal(self):
        replay = CallbackReplay()
        rid = uid("delayed")
        replay.offered(rid, 0., .01, .02, .1, 2.)
        replay.callback("sent", rid, .1, .11, .12)
        sealed = replay.cut(.3, now=.3)
        replay.callback("first", rid, .2, .5, .6)
        self.assertEqual(replay.cut(.3), sealed)
        self.assertIsNone(sealed["requests"][0]["first"])
        replay.callback("terminal", rid, .7, .8, .9, status="complete")
        before_terminal = replay.cut(.65, now=1.)
        self.assertIsNone(before_terminal["requests"][0]["terminal"])
        self.assertEqual(before_terminal["requests"][0]["first"]["event_at"], .2)
        self.assertEqual(before_terminal["requests"][0]["first"]["received_at"], .6)
        self.assertEqual(before_terminal["counts"]["pending"], 1)

    def test_due_offer_filter_and_equal_clock_seals_do_not_leak_later_publications(self):
        replay = CallbackReplay()
        rid = uid("future-intent")
        replay.offered(rid, 0., .01, .02, 1., 2.)
        replay.callback("terminal", rid, .1, .11, .12, status="cancelled")
        early = replay.cut(.5, now=.5)
        self.assertEqual(early["counts"]["offered"], 0)
        due = replay.cut(1., now=1.)
        self.assertEqual(due["counts"]["terminal"]["cancelled"], 1)
        tied = CallbackReplay()
        sealed = tied.cut(1., now=1.)
        tied.offered(uid("same-tick"), .8, .9, 1., 1., 2.)
        self.assertEqual(tied.cut(1.), sealed)
        self.assertEqual(sealed["receipt_watermark"], 0)
        self.assertEqual(tied.cut(1.1, now=1.1)["receipt_watermark"], 1)
        with self.assertRaisesRegex(ValueError, "Future"):
            tied.cut(1.2)
        with self.assertRaisesRegex(ValueError, "regressing"):
            tied.cut(1.)

    def test_publications_and_returned_cuts_cannot_mutate_original_cost_or_history(self):
        replay = CallbackReplay()
        rid = uid("immutable")
        returned = replay.offered(rid, 0., .01, .02, .1, 2.)
        returned["original_cost"] = 999
        snapshot = replay.cut(.2, now=.2)
        snapshot["requests"][0]["original_cost"] = 999
        self.assertEqual(replay.cut(.2)["requests"][0]["original_cost"], 2.)
        with self.assertRaisesRegex(ValueError, "UUID reused"):
            replay.offered(rid, .21, .22, .23, .1, 3.)
        with self.assertRaisesRegex(ValueError, "schema"):
            replay.callback("sent", rid, .21, .22, .23, original_cost=3.)
        replay.callback("sent", rid, .21, .22, .23)
        replay.callback("terminal", rid, .24, .25, .26, status="failed")
        with self.assertRaisesRegex(ValueError, "after terminal"):
            replay.callback("first", rid, .27, .28, .29)
        self.assertEqual(replay.cut(.3, now=.3)["requests"][0]["original_cost"], 2.)

    def test_sequence_identity_clock_and_lifecycle_chronology_fail_closed(self):
        for mutation in ("gap", "publisher", "domain", "future", "cost", "receive_stamp"):
            replay = CallbackReplay()
            publication = dict(
                schema=OfferedReceiptHistory.SCHEMA, publisher_run_id=uid("callback-publisher"),
                clock_domain="test-clock", publication_seq=1, kind="offered",
                request_id=uid("invalid"), event_at=0., published_at=.1,
                scheduled_at=.2, original_cost=2., cost_spec_sha256="a" * 64)
            replay.clock.value = .2
            if mutation == "gap":
                publication["publication_seq"] = 2
            elif mutation == "publisher":
                publication["publisher_run_id"] = uid("foreign")
            elif mutation == "domain":
                publication["clock_domain"] = "foreign-clock"
            elif mutation == "future":
                publication["published_at"] = .3
            elif mutation == "cost":
                publication["original_cost"] = True
            else:
                publication["received_at"] = .15
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                replay.history.receive(publication)
            self.assertEqual(replay.cut(.2)["receipt_watermark"], 0)
        replay = CallbackReplay()
        rid = uid("chronology")
        replay.offered(rid, .1, .11, .12, .2, 2.)
        with self.assertRaisesRegex(ValueError, "precedes send"):
            replay.callback("first", rid, .13, .14, .15)
        with self.assertRaisesRegex(ValueError, "scheduled"):
            replay.callback("sent", rid, .16, .17, .18)
        replay.callback("sent", rid, .2, .21, .22)
        with self.assertRaisesRegex(ValueError, "regressed"):
            replay.callback("terminal", rid, .19, .23, .24, status="timeout")
        replay.clock.value = .1
        with self.assertRaisesRegex(ValueError, "clock regressed"):
            replay.cut(.2)

    def test_final_rows_are_not_receipts_and_terminal_complete_is_not_endpoint_authority(self):
        replay = CallbackReplay()
        with self.assertRaisesRegex(ValueError, "final rows are not receipts"):
            replay.history.receive(arm()["rows"][0])
        rid = uid("empty-complete")
        replay.offered(rid, 0., .01, .02, .1, 2.)
        replay.callback("sent", rid, .1, .11, .12)
        replay.callback("terminal", rid, .2, .21, .22, status="complete")
        result = replay.cut(.3, now=.3)
        self.assertIsNone(result["requests"][0]["first"])
        self.assertEqual(result["counts"]["terminal"]["complete"], 1)
        self.assertFalse(result["publisher_complete_through_cut"])
        self.assertFalse(result["callback_source_authenticated"])
        self.assertFalse(result["independent_native_eos_verified"])

    def test_missing_cost_is_explicit_unknown_not_zero_or_post_outcome_imputation(self):
        replay = CallbackReplay()
        rid = uid("unknown-cost")
        replay.callback("offered", rid, 0., .01, .02, scheduled_at=.1,
                        original_cost=None, cost_spec_sha256=None)
        replay.callback("terminal", rid, .2, .21, .22, status="cancelled")
        result = replay.cut(.3, now=.3)
        self.assertEqual(result["counts"]["offered"], 1)
        self.assertEqual(result["counts"]["unknown_original_cost"], 1)
        self.assertIsNone(result["requests"][0]["original_cost"])
        self.assertIsNone(result["requests"][0]["cost_spec_sha256"])
        with self.assertRaisesRegex(ValueError, "schema"):
            replay.callback("terminal", rid, .31, .32, .33, status="cancelled", original_cost=2.)


def configuration():
    return dict(model_revision="a" * 40, observer_mode="off",
                deployment_id="test-pod", boot_id="test-boot", gpu_uuid="test-gpu",
                driver_version="test-driver", vllm_version="test-vllm",
                torch_version="test-torch", transformers_version="test-transformers",
                dtype="test-dtype",
                **{key: hashlib.sha256(key.encode()).hexdigest()
                   for key in ("native_source_sha256", "gateway_source_sha256",
                               "core_sha256", "cost_model_sha256", "scheduler_config_sha256")})


def arm(seed=1, side="left", status="complete", output=2):
    rid = uid(f"{seed}-{side}")
    offer = dict(request_id=rid, logical_id="offer-0", offset_s=0,
                 prompt_tokens=128, max_tokens=4,
                 prompt_sha256=hashlib.sha256(f"prompt-{seed}".encode()).hexdigest())
    row = dict(request_id=rid, response_request_id=rid, clock_domain="client-epoch",
               requested_max_tokens=4,
               scheduled_at=10, sent_at=10.01, first_content_at=10.1,
               last_content_at=10.11, terminal_at=10.12, status=status,
               stream_done=True, stream_error=False, http_status=200,
               finish_reason="stop", native_eos_verified=True,
               usage=dict(prompt_tokens=128, completion_tokens=output))
    if status == "rejected":
        row.update(first_content_at=None, last_content_at=None, http_status=503,
                   admission_rejection=True, stream_done=False,
                   finish_reason=None, usage=None)
    if status == "censored":
        row.update(terminal_at=None, observed_until=10.2, stream_done=False,
                   finish_reason=None, usage=None, client_prefix_complete=True)
    return dict(offers=[offer], rows=[row], origin=10, window_s=1,
                clock_domain="client-epoch", configuration=configuration(),
                policy_sha256=hashlib.sha256(f"policy-{side}".encode()).hexdigest())


def blocks(n=4):
    return [dict(seed=i, block_id=f"block-{i}", randomization_unit=f"unit-{i}",
                 partition="development",
                 independent_sampling=True, pair_order_randomized=True,
                 pair_order="left-first" if i % 2 == 0 else "right-first",
                 randomization_scheme="independent-fair-pair-order",
                 frozen_comparison_sha256=comparison_digest(
                     configuration=configuration(), window_s=1,
                     left_policy_sha256=arm(side="left")["policy_sha256"],
                     right_policy_sha256=arm(side="right")["policy_sha256"]),
                 left=arm(i, "left", "rejected"),
                 right=arm(i, "right")) for i in range(n)]


def train_episode():
    """Synthetic schema witnesses, not native receipts or experiment measurements."""
    ids = [uid("train-a"), uid("train-b"), uid("train-c")]
    spec = dict(intercept=10.72, input_per_token=.01, output_per_token=0,
                minimum=.1, default_max_tokens=128,
                tokenizer_identity="test-tokenizer", estimator_version="test-estimator")
    identity = dict(model_version="test-model", calibration_version="unqualified",
                    support_hash="a" * 64, implementation_hash="b" * 64,
                    cost_hash=hashlib.sha256(json.dumps(
                        {"formula": "max-min-affine-v1", **spec}, sort_keys=True,
                        separators=(",", ":")).encode()).hexdigest())

    def frame(sampled, members):
        marks = [dict(request_id=rid, cost=12., prompt_tokens=128, max_tokens=128,
                      received_at=.1, admitted_at=.2, first_at=None, scheduled_at=None)
                 for rid in members]
        return dict(schema="pr33-native-read-only-v1", complete=True, available=True,
                    clock_domain="test-clock", run_id=uid("native-run"), observer_sha256="c" * 64,
                    gateway_received_at=sampled + .01, sampled_at=sampled + .02,
                    frontend_sampled_at=sampled + .03, received_at=sampled + .04,
                    gateway_snapshot=dict(schema="mpc-admission-v1", complete=True,
                        clock_domain="test-clock", run_id=uid("gateway-run"),
                        sampled_at=sampled, budget=16, budget_version=2, sequence=int(sampled * 10),
                        identity=copy.deepcopy(identity), cost_spec=copy.deepcopy(spec), requests=marks),
                    requests=[dict(request_id=f"chatcmpl-{members[0]}-1234abcd",
                                   prompt_tokens=128, output_tokens=2, computed_tokens=130,
                                   maximum_output_tokens=128)],
                    running=1, waiting=0, pending_batches=0, kv_cache_usage=.1)

    rows = []
    for i, rid in enumerate(ids[:2]):
        row = arm()["rows"][0]
        row.update(request_id=rid, response_request_id=rid, clock_domain="test-clock",
                   requested_max_tokens=128, scheduled_at=.1 + i * .1, sent_at=.3,
                   first_content_at=2.2, last_content_at=2.3, terminal_at=2.4)
        rows.append(row)
    return dict(episode_id="nv3-181001-test-arm0", seed_block=181001, split="train",
                start=0., duration_s=3., gateway_run_id=uid("gateway-run"),
                expected_ids=ids[:2], offered_tape=[.1, .2], rows=rows,
                native_frames=[frame(.8, ids[:2]), frame(2., [ids[1], ids[2]])],
                preassignment=[], actions=[], schedule=[])


def audit_train(case, **kwargs):
    raw = json.dumps(case, sort_keys=True, allow_nan=False).encode()
    return train_schema_audit(raw, expected_sha256=hashlib.sha256(raw).hexdigest(),
                              cut_at=kwargs.pop("cut_at", 1.), **kwargs)


def train_ack(case, *, received_at, applied_at, operation):
    return dict(received_at=received_at, reply=dict(status="applied",
        command=dict(identity=case["native_frames"][0]["gateway_snapshot"]["identity"],
                     run_id=uid("gateway-run"), clock_domain="test-clock",
                     operation_id=uid(operation), budget=32, expected_version=2,
                     not_after=received_at + .1),
        acknowledgment=dict(status="applied", applied_at=applied_at,
                            budget=32, budget_version=3, operation_id=uid(operation),
                            clock_domain="test-clock", run_id=uid("gateway-run"))))


class TrainSchemaTests(unittest.TestCase):
    def test_bytes_and_train_partition_are_required_without_source_authority(self):
        case = train_episode()
        raw = json.dumps(case).encode()
        with self.assertRaisesRegex(ValueError, "digest mismatch"):
            train_schema_audit(raw, expected_sha256="0" * 64, cut_at=1.)
        for split, seed in (("final", 181001), ("train", 160021), ("train", 181017)):
            bad = copy.deepcopy(case)
            bad.update(split=split, seed_block=seed)
            with self.subTest(split=split, seed=seed), self.assertRaisesRegex(ValueError, "Only Train"):
                audit_train(bad)
        self.assertFalse(any(audit_train(case)["authority"].values()))

    def test_future_client_labels_native_samples_and_unreceived_ack_cannot_enter_features(self):
        case = train_episode()
        original = audit_train(case)
        changed = copy.deepcopy(case)
        changed["rows"][0]["first_content_at"] = .4
        changed["native_frames"][1]["requests"][0]["output_tokens"] = 17
        changed["actions"] = [dict(at_s=.9, attempts=[
            train_ack(changed, received_at=1.1, applied_at=.95, operation="action")])]
        result = audit_train(changed)
        self.assertEqual(original["observations"], result["observations"])
        self.assertNotEqual(original["offline_labels"]["offline_client_first_by_cut"],
                            result["offline_labels"]["offline_client_first_by_cut"])
        self.assertIsNone(result["observations"]["admitted_marks"][0]["first_at"])

    def test_receipt_not_event_time_and_received_ack_fence_define_available_prefix(self):
        case = train_episode()
        original = audit_train(case)["observations"]
        late = case["native_frames"][1]
        late.update(gateway_received_at=.91, sampled_at=.92,
                    frontend_sampled_at=.93, received_at=1.01)
        late["gateway_snapshot"]["sampled_at"] = .9
        late["gateway_snapshot"]["sequence"] = 9
        self.assertEqual(audit_train(case)["observations"], original)
        case["preassignment"] = [train_ack(case, received_at=.96, applied_at=.95, operation="ack")]
        self.assertTrue(audit_train(case)["observations"]["received_ack_conflicts_with_snapshot"])
        case["preassignment"][0]["reply"]["command"]["expected_version"] = 1
        with self.assertRaisesRegex(ValueError, "CAS"):
            audit_train(case)
        with self.assertRaisesRegex(ValueError, "stale"):
            audit_train(train_episode(), cut_at=1.4)

    def test_full_offered_past_is_offline_not_admitted_rate_or_physical_eos(self):
        case = train_episode()
        case["rows"][1].update(status="rejected", finish_reason=None)
        case["expected_ids"].append(uid("rejected-extra"))
        case["offered_tape"].append(.3)
        extra = copy.deepcopy(case["rows"][1])
        extra.update(request_id=uid("rejected-extra"), scheduled_at=.3)
        case["rows"].append(extra)
        case["rows"][0]["native_eos_verified"] = True
        result = audit_train(case)
        self.assertEqual(result["observations"]["admitted_snapshot_count"], 2)
        self.assertEqual(result["offline_labels"]["offline_planned_offers_by_cut"], 3)
        self.assertIsNone(result["observations"]["all_offered_client_history"])
        self.assertIsNone(result["offline_labels"]["independent_physical_eos_receipts"])
        self.assertFalse(result["authority"]["native_comparison_accepted"])
        case["rows"].pop()
        missing = audit_train(case)
        self.assertIn("Missing full-offered", missing["offline_labels"]["client_labels_withheld"])
        self.assertEqual(missing["observations"], result["observations"])

    def test_original_whole_cost_cohort_not_net_stock_and_cap_drop_never_evicts(self):
        result = audit_train(train_episode())
        self.assertEqual(result["observations"]["applied_cap"], 16)
        self.assertEqual(result["observations"]["reserved_cost"], 24)
        self.assertEqual(result["offline_labels"]["released_cost_bounds"], [12., 12.])
        bounds = result["offline_labels"]["cohort_disappearance"]
        self.assertEqual([b["released_count_bounds"] for b in bounds], [[1, 1], [0, 0]])
        self.assertTrue(result["observations"]["accepted_not_native_visible"])
        self.assertFalse(result["authority"]["same_state_causal_effect_qualified"])

    def test_disappearance_is_interval_censored_not_interpolated_release_or_eos(self):
        case = train_episode()
        frame = case["native_frames"][1]
        frame["gateway_snapshot"]["sampled_at"] = 2.1
        frame.update(gateway_received_at=2.11, sampled_at=2.12,
                     frontend_sampled_at=2.13, received_at=2.14)
        labels = audit_train(case)["offline_labels"]
        self.assertEqual(labels["released_cost_bounds"], [0., 12.])
        self.assertEqual(labels["cohort_disappearance"][0]["released_count_bounds"], [0, 1])

    def test_exact_id_cost_and_future_label_errors_fail_without_rewriting_features(self):
        case = train_episode()
        for field, value in (("clock_domain", "foreign"), ("running", True)):
            bad = copy.deepcopy(case)
            bad["native_frames"][0][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                audit_train(bad)
        bad = copy.deepcopy(case)
        bad["native_frames"][0]["requests"][0]["request_id"] += "-extra"
        with self.assertRaisesRegex(ValueError, "UUID"):
            audit_train(bad)
        changed = copy.deepcopy(case)
        mark = changed["native_frames"][1]["gateway_snapshot"]["requests"][0]
        mark.update(prompt_tokens=228, cost=13.)
        result = audit_train(changed)
        self.assertIn("changed original", result["offline_labels"]["disappearance_withheld"])
        self.assertEqual(result["observations"], audit_train(case)["observations"])


class MarkedDynamicsCounterexampleTests(unittest.TestCase):
    def episode(self):
        case = train_episode()
        rid = case["expected_ids"][0]
        case.update(expected_ids=[rid], offered_tape=[.1], rows=case["rows"][:1])
        case["rows"][0].update(sent_at=.11, first_content_at=.2,
                               last_content_at=1.19, terminal_at=1.2,
                               usage=dict(prompt_tokens=128, completion_tokens=24))
        case["rows"][0].pop("native_eos_verified")
        for frame in case["native_frames"]:
            snapshot = frame["gateway_snapshot"]
            if frame["received_at"] < 1.:
                snapshot["requests"] = snapshot["requests"][:1]
                snapshot["requests"][0].update(received_at=.12, admitted_at=.13)
            else:
                snapshot["requests"] = []
                frame.update(requests=[], running=0, kv_cache_usage=0.)
        return case

    def partition(self, case):
        raw = json.dumps(case, sort_keys=True, allow_nan=False).encode()
        return future_api_good_partition(
            raw, expected_sha256=hashlib.sha256(raw).hexdigest(), cut_at=1.)

    def test_perfect_incumbent_labels_do_not_remove_exogenous_birth_error(self):
        baseline = self.episode()
        births = copy.deepcopy(baseline)
        rid = uid("future-exogenous-offer")
        row = copy.deepcopy(births["rows"][0])
        row.update(request_id=rid, response_request_id=rid, scheduled_at=1.4,
                   sent_at=1.41, first_content_at=1.5, last_content_at=1.51,
                   terminal_at=1.52, usage=dict(prompt_tokens=128, completion_tokens=2))
        births["rows"].append(row)
        births["expected_ids"].append(rid)
        births["offered_tape"].append(1.4)
        old, new = self.partition(baseline), self.partition(births)
        self.assertEqual(old["observations"], new["observations"])
        self.assertEqual(new["observations"]["raw_native_progress"][0]["computed_tokens"], 130)
        for horizon in (1, 3, 5):
            a, b = old["future_api_good"][horizon], new["future_api_good"][horizon]
            self.assertEqual(a["cohort_native_visible"], b["cohort_native_visible"])
            self.assertEqual(a["total"], 1)
            self.assertEqual(b["total"], 2)
            self.assertEqual(b["total"] - a["total"], b["post_cut_offered_birth"])
        self.assertIsNone(new["physical_natural_good"])
        self.assertFalse(new["active_mpc_permit"])

    def test_same_arrivals_and_progress_do_not_identify_eos_or_terminal_slo(self):
        natural = self.episode()
        truncated = copy.deepcopy(natural)
        row = truncated["rows"][0]
        row.update(finish_reason="length", last_content_at=5.49, terminal_at=5.5,
                   usage=dict(prompt_tokens=128, completion_tokens=128))
        frame = truncated["native_frames"][1]
        frame.update(gateway_received_at=6.01, sampled_at=6.02,
                     frontend_sampled_at=6.03, received_at=6.04)
        frame["gateway_snapshot"].update(sampled_at=6., sequence=60)
        a, b = self.partition(natural), self.partition(truncated)
        self.assertEqual(natural["offered_tape"], truncated["offered_tape"])
        self.assertEqual(a["observations"], b["observations"])
        self.assertEqual(a["future_api_good"][5]["total"], 1)
        self.assertEqual(b["future_api_good"][5]["total"], 0)
        late = copy.deepcopy(natural)
        late["rows"][0].update(last_content_at=2.49, terminal_at=2.5)
        self.assertEqual(self.partition(late)["future_api_good"][5]["total"], 0)
        spoof = copy.deepcopy(natural)
        spoof["rows"][0]["native_eos_verified"] = True
        self.assertIsNone(self.partition(spoof)["physical_natural_good"])

    def test_unseen_past_and_marked_invisible_cohorts_are_not_post_cut_births_or_zero(self):
        case = self.episode()
        frame = case["native_frames"][0]
        frame.update(requests=[], running=0, kv_cache_usage=0.)
        rid = uid("past-unseen-offer")
        row = copy.deepcopy(case["rows"][0])
        row.update(request_id=rid, response_request_id=rid)
        case["rows"].append(row)
        case["expected_ids"].append(rid)
        case["offered_tape"].append(.1)
        result = self.partition(case)
        self.assertEqual(result["observations"]["accepted_not_native_visible"],
                         [case["expected_ids"][0]])
        counts = result["future_api_good"][1]
        self.assertEqual(counts["cohort_native_unknown"], 1)
        self.assertEqual(counts["past_offer_outside_snapshot"], 1)
        self.assertEqual(counts["post_cut_offered_birth"], 0)
        self.assertEqual(counts["total"], 2)

    def test_bad_future_labels_withhold_points_without_rewriting_progress_or_history(self):
        baseline = self.episode()
        expected = self.partition(baseline)["observations"]
        for field, value in (("usage", dict(prompt_tokens=128, completion_tokens=0)),
                             ("usage", dict(prompt_tokens=128, completion_tokens=True)),
                             ("terminal_at", .15), ("status", "censored"),
                             ("clock_domain", "foreign")):
            case = copy.deepcopy(baseline)
            case["rows"][0][field] = value
            with self.subTest(field=field, value=value):
                result = self.partition(case)
                self.assertEqual(result["observations"], expected)
                self.assertIsNone(result["future_api_good"])
                self.assertIn("labels_withheld", result)
        case = copy.deepcopy(baseline)
        case["rows"].clear()
        self.assertIsNone(self.partition(case)["future_api_good"])

    def test_equal_receipt_times_preserve_the_same_latest_frame_as_the_train_audit(self):
        case = self.episode()
        first = case["native_frames"][0]
        first["received_at"] = .99
        later = copy.deepcopy(first)
        later.update(gateway_received_at=.91, sampled_at=.92, frontend_sampled_at=.93)
        later["gateway_snapshot"].update(sampled_at=.9, sequence=9)
        later["requests"][0].update(computed_tokens=132, output_tokens=4)
        case["native_frames"].insert(1, later)
        result = self.partition(case)["observations"]
        self.assertEqual(result["native_visible"][0]["output_tokens"], 4)
        self.assertEqual(result["raw_native_progress"][0]["output_tokens"], 4)


class CapPlanIdentificationTests(unittest.TestCase):
    """Hypothetical admission-mediated laws, never native EOS/performance receipts."""

    def plans(self):
        return tuple(itertools.product((16, 32), repeat=5))

    def response(self, plan, *, congested=False):
        # One old charge persists; five cost-one offers arrive, one per slot.
        owners = {"old": 16}
        rejected = []
        for slot, cap in enumerate(plan):
            rid = f"future-{slot}"
            if sum(owners.values()) + 1 <= cap:
                owners[rid] = 1
            else:
                rejected.append(rid)
        admitted = tuple(rid for rid in owners if rid != "old")
        # Two batch laws coincide up to four births. Only the unseen five-birth
        # batch stalls past 5s in the second law. Neither law receives the cap.
        completions = () if congested and len(admitted) == 5 else admitted
        released_cost = sum(owners[rid] for rid in completions)
        for rid in completions:
            del owners[rid]
        self.assertEqual(16 + len(admitted) - released_cost, sum(owners.values()))
        self.assertEqual(6, len(completions) + len(rejected) + len(owners))
        return dict(good=(0, 0, len(completions)), reserved=sum(owners.values()),
                    admitted=admitted, rejected=tuple(rejected), unresolved=tuple(owners))

    def test_randomized_marginals_do_not_identify_unsupported_full_plans_or_batches(self):
        plans = self.plans()
        law = {p: 1 for p in plans if p.count(32) % 2 == 0}
        for slot in range(5):
            self.assertEqual(sum(w for p, w in law.items() if p[slot] == 32), 8)
        audit = cap_plan_support_audit(law, plans)
        self.assertEqual([audit["horizons"][h]["supported_prefixes"] for h in (1, 3, 5)],
                         [2, 8, 16])
        for horizon in (1, 3):
            masses = {}
            for row in audit["horizons"][horizon]["candidates"]:
                prefix = row["prefix"]
                mass = row["declared_prefix_probability"]
                self.assertEqual(masses.setdefault(prefix, mass), mass)
        for p in law:
            self.assertEqual(self.response(p), self.response(p, congested=True))
        all_high = (32,) * 5
        self.assertEqual(self.response(all_high)["good"][2], 5)
        self.assertEqual(self.response(all_high, congested=True)["good"][2], 0)
        row = next(r for r in audit["horizons"][5]["candidates"] if r["plan"] == all_high)
        self.assertFalse(row["declared_prefix_supported"])
        self.assertEqual(row["declared_prefix_probability"], [0, 1])
        self.assertFalse(audit["active_mpc_permit"])

    def test_positive_plan_support_and_random_policy_coverage_do_not_authorize_selection(self):
        plans = self.plans()
        audit = cap_plan_support_audit(dict.fromkeys(plans, 1), plans)
        self.assertTrue(all(r["declared_prefix_supported"]
                            for r in audit["horizons"][5]["candidates"]))
        predictions = {p: self.response(p)["good"][2] for p in plans}
        truths = {p: self.response(p, congested=True)["good"][2] for p in plans}
        covered = sum(predictions[p] == truths[p] for p in plans)
        self.assertEqual(covered, 31)
        selected = max(plans, key=predictions.get)
        self.assertEqual(selected, (32,) * 5)
        self.assertNotEqual(predictions[selected], truths[selected])
        self.assertFalse(audit["selected_policy_coverage_verified"])
        self.assertFalse(audit["conditional_history_support_verified"])

    def test_declared_weights_are_not_empirical_counts_and_invalid_designs_are_refused(self):
        low, high = (16,) * 5, (32,) * 5
        audit = cap_plan_support_audit({low: 3, high: 1}, (low, high))
        self.assertEqual(audit["horizons"][5]["candidates"][1]
                         ["declared_prefix_probability"], [1, 4])
        for law in ({}, {low: 0}, {low: True}, {low: -1}, {low: 1.5},
                    {(16,) * 4: 1}, {(16, 16, 16, 16, 24): 1}):
            with self.subTest(law=law), self.assertRaises(ValueError):
                cap_plan_support_audit(law, (low, high))
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            cap_plan_support_audit({low: 1}, (low, low))


class OutcomeTests(unittest.TestCase):
    def test_natural_truncated_censored_and_failures_keep_full_offered_denominator(self):
        case = arm()
        natural = audit_arm(**case)
        self.assertEqual((natural["good_lower"], natural["good_upper"]), (1, 1))
        case["rows"][0].update(finish_reason="length")
        case["rows"][0]["usage"]["completion_tokens"] = 4
        truncated = audit_arm(**case)
        self.assertEqual(truncated["outcomes"][0]["label"], "truncated")
        self.assertEqual(truncated["good_upper"], 0)
        censored = audit_arm(**arm(status="censored"))
        self.assertEqual((censored["good_lower"], censored["good_upper"]), (0, 1))
        for status in ("rejected", "failed", "cancelled", "timeout"):
            result = audit_arm(**arm(status=status))
            self.assertEqual(result["offered"], 1)
            self.assertEqual(result["good_upper"], 0)
        cohort = arm()
        cohort["offers"], cohort["rows"] = [], []
        for i, status in enumerate(("complete", "rejected", "failed", "cancelled",
                                    "timeout", "censored")):
            item = arm(i, status=status)
            item["offers"][0]["logical_id"] = f"offer-{i}"
            cohort["offers"].extend(item["offers"])
            cohort["rows"].extend(item["rows"])
        result = audit_arm(**cohort)
        self.assertEqual((result["offered"], result["good_lower"], result["good_upper"]),
                         (6, 1, 2))

    def test_zero_bool_float_and_missing_successful_output_are_invalid(self):
        for output in (0, True, 1.5, None):
            with self.subTest(output=output), self.assertRaises(ValueError):
                audit_arm(**arm(output=output))
        self.assertEqual(audit_arm(**arm(output=1))["outcomes"][0]["request_mean_tpot_s"], 0)

    def test_all_timestamps_are_finite_and_ordered_even_single_token(self):
        mutations = [("scheduled_at", float("nan")), ("sent_at", True),
                     ("first_content_at", float("inf")), ("last_content_at", 9),
                     ("terminal_at", 10.05)]
        for field, value in mutations:
            case = arm(output=1)
            case["rows"][0][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                audit_arm(**case)
        with self.assertRaises(ValueError):
            audit_arm(**{**arm(), "origin": float("nan")})

    def test_slo_uses_scheduled_origin_and_terminal_not_last_chunk(self):
        case = arm()
        case["rows"][0]["terminal_at"] = 10.3
        self.assertEqual(audit_arm(**case)["good_lower"], 0)
        case = arm()
        case["rows"][0].update(sent_at=10.6, first_content_at=10.7,
                               last_content_at=10.71, terminal_at=10.72)
        self.assertEqual(audit_arm(**case)["good_lower"], 0)

    def test_missing_extra_duplicate_clock_identity_and_unverified_eos_fail_closed(self):
        for kind in ("missing", "extra", "duplicate", "clock", "identity", "eos",
                     "stream", "limit"):
            case = arm()
            if kind == "missing":
                case["rows"] = []
            elif kind == "extra":
                case["rows"][0]["request_id"] = uid("not-offered")
            elif kind == "duplicate":
                case["rows"] *= 2
            else:
                field, value = {"clock": ("clock_domain", "worker-epoch"),
                                "identity": ("response_request_id", uid("other")),
                                "eos": ("native_eos_verified", False),
                                "limit": ("requested_max_tokens", 8),
                                "stream": ("stream_done", False)}[kind]
                case["rows"][0][field] = value
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                audit_arm(**case)

    def test_censored_late_first_cannot_become_good_and_invalid_cutoff_fails(self):
        case = arm(status="censored")
        case["rows"][0].update(first_content_at=10.6, last_content_at=10.6,
                               observed_until=10.7)
        self.assertEqual(audit_arm(**case)["good_upper"], 0)
        case["rows"][0]["observed_until"] = 10.5
        with self.assertRaises(ValueError):
            audit_arm(**case)

    def test_no_first_after_deadline_tightens_only_complete_client_prefix(self):
        case = arm(status="censored")
        case["rows"][0].update(first_content_at=None, last_content_at=None,
                               observed_until=11)
        result = audit_arm(**case)
        self.assertEqual((result["good_lower"], result["good_upper"]), (0, 0))
        self.assertEqual(result["outcomes"][0]["label"], "censored")
        case["rows"][0]["client_prefix_complete"] = False
        self.assertEqual(audit_arm(**case)["good_upper"], 1)
        case["rows"][0].update(client_prefix_complete=True, observed_until=10.5)
        self.assertEqual(audit_arm(**case)["good_upper"], 1)

    def test_semantic_tape_excludes_labels_but_preserves_tied_offer_order(self):
        case = arm()
        renamed = copy.deepcopy(case)
        renamed["offers"][0].update(request_id=uid("new-id"), logical_id="new-label",
                                   offset_s=0.0)
        renamed["rows"][0].update(request_id=uid("new-id"), response_request_id=uid("new-id"))
        original, relabeled = audit_arm(**case), audit_arm(**renamed)
        self.assertEqual(original["semantic_tape_sha256"], relabeled["semantic_tape_sha256"])
        self.assertNotEqual(original["tape_sha256"], relabeled["tape_sha256"])
        second = arm(2)
        second["offers"][0]["logical_id"] = "offer-1"
        case["offers"].extend(second["offers"])
        case["rows"].extend(second["rows"])
        reversed_case = copy.deepcopy(case)
        reversed_case["offers"].reverse()
        self.assertNotEqual(audit_arm(**case)["semantic_tape_sha256"],
                            audit_arm(**reversed_case)["semantic_tape_sha256"])

    def test_configuration_requires_actual_fields_not_an_opaque_hash(self):
        for change in ({}, {"configuration_sha256": "a" * 64},
                       {**configuration(), "model_revision": True},
                       {**configuration(), "torch_version": None},
                       {**configuration(), "runtime_extra": float("nan")}):
            case = arm()
            case["configuration"] = change
            with self.subTest(configuration=change), self.assertRaises(ValueError):
                audit_arm(**case)


class BlockTests(unittest.TestCase):
    def test_four_blocks_have_exact_two_sided_floor_not_request_level_significance(self):
        result = paired_effect(blocks(), bootstrap_samples=200)
        self.assertEqual(result["effect_good_per_s"], 1)
        self.assertEqual(result["exact_two_sided_signflip_p"], .125)
        self.assertEqual(result["percentile_bootstrap_ci95"], [1, 1])
        self.assertFalse(result["native_performance_accepted"])
        self.assertFalse(result["independent_sampling_verified"])

    def test_nonsignificance_has_no_equivalence_or_superiority_label(self):
        cases = blocks()
        for i in (0, 1):
            cases[i]["left"], cases[i]["right"] = arm(i, "left"), arm(i, "right", "rejected")
        result = paired_effect(cases, bootstrap_samples=200)
        self.assertEqual(result["effect_good_per_s"], 0)
        self.assertEqual(result["exact_two_sided_signflip_p"], 1)
        self.assertLess(result["percentile_bootstrap_ci95"][0], 0)
        self.assertGreater(result["percentile_bootstrap_ci95"][1], 0)
        self.assertNotIn("equivalent", result)
        self.assertNotIn("superior", result)

    def test_cloned_block_is_rejected_even_after_cosmetic_relabeling(self):
        for kind in ("clone", "seed", "unit", "tape", "physical", "declaration"):
            cases = blocks()
            if kind == "clone":
                cases[1] = copy.deepcopy(cases[0])
            elif kind == "seed":
                cases[1]["seed"] = cases[0]["seed"]
            elif kind == "unit":
                cases[1]["randomization_unit"] = cases[0]["randomization_unit"]
            elif kind == "tape":
                for side in ("left", "right"):
                    cases[1][side]["offers"][0]["prompt_sha256"] = (
                        cases[0][side]["offers"][0]["prompt_sha256"])
            elif kind == "physical":
                for field in ("offers", "rows"):
                    cases[1]["right"][field] = copy.deepcopy(cases[1]["left"][field])
            else:
                cases[1]["independent_sampling"] = False
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                paired_effect(cases, bootstrap_samples=20)

    def test_pair_requires_identical_tape_window_and_slo(self):
        for field in ("window_s", "ttft_s", "prompt_sha256"):
            cases = blocks()
            if field == "prompt_sha256":
                cases[0]["right"]["offers"][0][field] = "a" * 64
            else:
                cases[0]["right"][field] = 2
            with self.subTest(field=field), self.assertRaises(ValueError):
                paired_effect(cases, bootstrap_samples=20)

    def test_unrandomized_or_changed_policy_design_cannot_get_permutation_p(self):
        for field, value in (("pair_order_randomized", False),
                             ("pair_order", "unknown"),
                             ("randomization_scheme", "balanced-permuted-order"),
                             ("frozen_comparison_sha256", "a" * 64)):
            cases = blocks()
            cases[1][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                paired_effect(cases, bootstrap_samples=20)

    def test_unresolved_outcomes_withhold_ci_and_permutation_not_impute_success(self):
        cases = blocks()
        cases[0]["right"] = arm(0, "right", "censored")
        result = paired_effect(cases)
        self.assertEqual(result["effect_bounds_good_per_s"], [.75, 1])
        self.assertIsNone(result["effect_good_per_s"])
        self.assertIsNone(result["exact_two_sided_signflip_p"])
        self.assertIsNone(result["percentile_bootstrap_ci95"])

    def test_exact_permutation_is_scale_invariant_not_absolute_epsilon_dependent(self):
        for duration in (1, 10 ** 15):
            cases = blocks()
            for case in cases:
                for side in ("left", "right"):
                    case[side]["window_s"] = duration
                case["frozen_comparison_sha256"] = comparison_digest(
                    configuration=configuration(), window_s=duration,
                    left_policy_sha256=case["left"]["policy_sha256"],
                    right_policy_sha256=case["right"]["policy_sha256"])
            self.assertEqual(paired_effect(cases, bootstrap_samples=20)
                             ["exact_two_sided_signflip_p"], .125)

    def test_partitions_and_old_final_seed_cannot_leak_into_block_analysis(self):
        for mutation in ("mixed", "missing", "heldout"):
            cases = blocks()
            if mutation == "mixed":
                cases[1]["partition"] = "train"
            elif mutation == "missing":
                cases[1].pop("partition")
            else:
                cases[1]["seed"] = 160022
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                paired_effect(cases)

    def test_bootstrap_interpolation_remains_finite_at_opposite_large_effects(self):
        cases = blocks(2)
        cases[1]["left"], cases[1]["right"] = arm(1, "left"), arm(1, "right", "rejected")
        for case in cases:
            for side in ("left", "right"):
                item = case[side]
                item.update(origin=0, window_s=1e-308)
                for name in ("scheduled_at", "sent_at", "first_content_at",
                             "last_content_at", "terminal_at"):
                    if item["rows"][0][name] is not None:
                        item["rows"][0][name] = 0
            case["frozen_comparison_sha256"] = comparison_digest(
                configuration=configuration(), window_s=1e-308,
                left_policy_sha256=case["left"]["policy_sha256"],
                right_policy_sha256=case["right"]["policy_sha256"])
        result = paired_effect(cases, bootstrap_samples=2, random_seed=0)
        import math
        self.assertTrue(all(math.isfinite(v) for v in result["percentile_bootstrap_ci95"]))

    def test_actual_global_slo_config_window_and_policy_cannot_hide_behind_same_hash(self):
        for field in ("ttft_s", "tpot_s", "window_s", "configuration",
                      "runtime_version", "policy_sha256"):
            cases = blocks()
            if field == "configuration":
                for side in ("left", "right"):
                    cases[1][side][field]["native_source_sha256"] = "b" * 64
            elif field == "runtime_version":
                for side in ("left", "right"):
                    cases[1][side]["configuration"]["torch_version"] = "changed-runtime"
            elif field == "policy_sha256":
                cases[1]["right"][field] = "b" * 64
            else:
                for side in ("left", "right"):
                    cases[1][side][field] = (
                        .01 if field == "tpot_s" else .05 if field == "ttft_s" else 2)
            with self.subTest(field=field), self.assertRaisesRegex(ValueError, "frozen comparison"):
                paired_effect(cases)
        cases = blocks()
        for case in cases:
            case["frozen_comparison_sha256"] = "a" * 64
        with self.assertRaisesRegex(ValueError, "frozen comparison"):
            paired_effect(cases)

    def test_new_hash_per_block_does_not_legalize_changing_actual_comparison(self):
        cases = blocks()
        for side in ("left", "right"):
            cases[1][side]["ttft_s"] = .05
        cases[1]["frozen_comparison_sha256"] = comparison_digest(
            configuration=configuration(), window_s=1, ttft_s=.05,
            left_policy_sha256=cases[1]["left"]["policy_sha256"],
            right_policy_sha256=cases[1]["right"]["policy_sha256"])
        with self.assertRaisesRegex(ValueError, "configuration changed"):
            paired_effect(cases)

    def test_semantic_duplicate_tapes_rejected_after_all_identity_labels_change(self):
        cases = []
        for i in range(6):
            case = copy.deepcopy(blocks(2)[0])
            case.update(seed=i, block_id=f"block-{i}", randomization_unit=f"unit-{i}")
            for side in ("left", "right"):
                rid = uid(f"relabeled-{i}-{side}")
                case[side]["offers"][0].update(request_id=rid, logical_id=f"label-{i}")
                case[side]["rows"][0].update(request_id=rid, response_request_id=rid)
            cases.append(case)
        with self.assertRaisesRegex(ValueError, "Repeated offered tape"):
            paired_effect(cases)

    def test_censor_known_bad_never_becomes_success_or_inferential_completion(self):
        cases = blocks()
        cases[0]["right"] = arm(0, "right", "censored")
        cases[0]["right"]["rows"][0].update(first_content_at=None, last_content_at=None,
                                            observed_until=11)
        result = paired_effect(cases)
        self.assertEqual(result["effect_bounds_good_per_s"], [.75, .75])
        self.assertIsNone(result["effect_good_per_s"])
        self.assertIsNone(result["exact_two_sided_signflip_p"])


def physical_steps(prompt=4096, output=32):
    lengths = [2048, prompt - 2048] + [1] * (output - 1)
    position, steps = 0, []
    for i, count in enumerate(lengths):
        steps.append(dict(step_id=f"step-{i}", position=position, tokens=count,
                          executed_position=position, executed_tokens=count,
                          cuda_forward_matched=True, clock_domain="native-host",
                          host_forward_start=1 + i * .01,
                          output_commit_at=1.1 + i * .01))
        position += count
    steps.append(dict(step_id="tail", position=position, tokens=1,
                      executed_position=position, executed_tokens=1,
                      cuda_forward_matched=True, clock_domain="native-host",
                      host_forward_start=1.9, output_commit_at=2.1,
                      pre_finish_placeholder=1, delivered_output_from_step=False))
    return dict(prompt_tokens=prompt, output_tokens=output, steps=steps,
                eos_at=2, clock_domain="native-host")


class WorkTests(unittest.TestCase):
    def test_physical_tail_is_reported_without_turning_old_equality_true(self):
        result = work_accounting(**physical_steps())
        self.assertEqual(result["useful_input_minimum"], 4127)
        self.assertEqual(result["physical_input_tokens"], 4128)
        self.assertEqual(result["undelivered_tail_input_tokens"], 1)
        self.assertFalse(result["old_final_progress_equal"])
        self.assertFalse(result["native_qualification_accepted"])
        case = physical_steps()
        case["steps"].pop()
        self.assertTrue(work_accounting(**case)["old_final_progress_equal"])

    def test_tail_needs_full_join_and_not_placeholder_or_elapsed_time_alone(self):
        for field, value in (("pre_finish_placeholder", 0),
                             ("pre_finish_placeholder", True),
                             ("cuda_forward_matched", False),
                             ("executed_tokens", 2),
                             ("delivered_output_from_step", True),
                             ("host_forward_start", 2.01),
                             ("output_commit_at", 1.99),
                             ("clock_domain", "gpu-relative")):
            case = physical_steps()
            case["steps"][-1][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                work_accounting(**case)

    def test_gaps_duplicate_steps_missing_work_and_more_excess_are_not_relaxed(self):
        for kind in ("gap", "duplicate", "missing", "extra"):
            case = physical_steps()
            if kind == "gap":
                case["steps"][2]["position"] += 1
            elif kind == "duplicate":
                case["steps"][-1]["step_id"] = "step-0"
            elif kind == "missing":
                case["steps"] = case["steps"][:2]
            else:
                case["steps"][-1].update(tokens=2, executed_tokens=2)
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                work_accounting(**case)

    def test_useful_forward_cannot_start_after_eos_or_regress_in_host_order(self):
        for index, start in ((0, 3), (2, 0)):
            case = physical_steps()
            case["steps"][index].update(host_forward_start=start, output_commit_at=4)
            with self.subTest(index=index), self.assertRaises(ValueError):
                work_accounting(**case)


def peer_counterexamples(frozen_root):
    """Replay pinned peer defects read-only; run separately from portable unit tests."""
    import importlib.util
    import sys
    from dataclasses import replace
    from pathlib import Path

    root = Path(frozen_root)
    receipts = {}

    def load(name, relative, expected=None):
        path = root / relative
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if expected is not None and digest != expected:
            raise ValueError(f"Frozen peer source changed: {relative}")
        receipts[relative] = digest
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        return module

    base = "experiments/mpc-research/native-v3/"
    opus = load("native_release_model", "opus/" + base + "native_release_model.py",
                "86f45ab851a446b4a903c8e5f0991acb198ecc4fc5d9d0d9bd0d05e38e77411b")
    ot = load("nv3_opus_r1_tests", "opus/" + base + "test_native_release_model.py",
              "1f38d3cb88d9c89d9acf2296b94278f02ed4f73a7e3e98caf5f7f045f902bed3")
    astra = load("native_response_planner", "astra/" + base + "native_response_planner.py",
                 "e19db180e1fb06c6c34ff21e9b76131e85749edc7f403d4aa65acf366b7a3326")
    at = load("nv3_astra_r1_tests", "astra/" + base + "test_native_response_planner.py",
              "862bc1db7a9baba167f8cf0baa7997c93201cfb7fdce47152e4a6dadaf8e3f08")
    gemini = load("native_campaign_protocol", "gemini/native_campaign_protocol.py",
                  "087c68868f48f6bac9d1ac829c9dc3cb8b749f1c40b87f6d5364bb2d2f4bad79")
    load("nv3_gemini_r1_tests", "gemini/test_native_campaign_protocol.py",
         "a94770f63e58e68e2046b98876831e609d98a6e595ec204402465620f5864d42")
    findings = {}

    ep = ot.episode([(1, 1., 128, 128, 0., .1, .6)])
    foreign = copy.deepcopy(ep)
    for obs in foreign["observations"]:
        obs["native"].update(clock_domain="foreign-clock", run_id="foreign-run")
    findings["opus_foreign_native_identity_accepted"] = bool(opus.build_origins(foreign)[0])
    assert findings["opus_foreign_native_identity_accepted"]
    bad_time = copy.deepcopy(ep)
    bad_time["ledger"][-1]["effective_at"] = -100
    findings["opus_release_before_live_origin_accepted"] = opus.build_dataset([bad_time])[0]["truth"][1.]
    assert findings["opus_release_before_live_origin_accepted"] == (1., 1.)
    plans = ([(0, 16), (.5, 32), (1, 16)], [(0, 32), (.5, 16), (1, 16)])
    averages = [{h: opus._planned_budget({"cap_plan": p}, 0, h, 16)
                 for h in opus.HORIZONS} for p in plans]
    findings["opus_order_distinct_plans_same_all_horizon_features"] = averages
    assert averages[0] == averages[1]
    train_origins = []
    for prompt in (128, 4096):
        train_origins.extend(opus.build_origins(ot.episode([
            (1, 1., prompt, 128, 0., .1, 1.),
            (2, 1., prompt, 128, 0., .1, 1.)]))[0])
    mixed = opus.build_origins(ot.episode([
        (1, 1., 128, 128, 0., .1, 1.),
        (2, 1., 4096, 128, 0., .1, 1.)]))[0][0]
    findings["opus_unseen_mixture_passes_marginal_ood_envelope"] = opus.ood_reasons(
        mixed, opus.support_envelope(train_origins))
    assert findings["opus_unseen_mixture_passes_marginal_ood_envelope"] == []
    findings["opus_tail_accounted_without_cuda_placeholder_commit_clock"] = (
        ot._baseline_4096_32()["tail_accounted"])
    assert findings["opus_tail_accounted_without_cuda_placeholder_commit_clock"]
    previous_predict = opus.predict
    try:
        opus.predict = lambda params, origin: (
            {"batch_aware": {h: .5 for h in opus.HORIZONS}}, [])
        calibration = [dict(partition="calibration", seed_block=i, reserved=1,
                            truth={h: (value, value) for h in opus.HORIZONS})
                       for i, value in ((1, 0), (2, 1))]
        a = opus.calibrate({}, calibration)["bands"][1.]["lower"]
        b = opus.calibrate({}, calibration[:1] + calibration[1:] * 20)["bands"][1.]["lower"]
        findings["opus_same_two_blocks_origin_resampling_changes_band"] = [a, b]
        assert (a, b) == (-.5, .5)
    finally:
        opus.predict = previous_predict

    contradiction = replace(at.state(), native_running=0)
    decision = astra.plan_response(
        contradiction, at.evaluation(), at.StubModel(), expected_identity=at.IDENTITY,
        timing=astra.Timing("test-clock", 10.1, .02, .5, .05), clock=lambda: 10.)
    findings["astra_decode_mark_with_zero_native_running"] = dict(
        status=decision.status, active_permit=decision.active_permit)
    assert decision.status == "shadow" and decision.active_permit is False

    template = gemini.RequestOutcome("r", 128, 2, 10., 10.01, 10.1, 10.12,
                                     10., "stop", True)
    bool_good = gemini.validate_request_outcome(replace(template, output_tokens=True))["is_good"]
    post_good = gemini.validate_request_outcome(replace(template, client_post_at=100.))["is_good"]
    findings["gemini_boolean_output_and_post_after_terminal_good"] = [bool_good, post_good]
    assert bool_good and post_good
    accounting = gemini.compute_work_accounting()
    findings["gemini_exclusive_end_off_by_one"] = accounting.physical_executed_positions
    assert accounting.physical_executed_positions == 4129
    missing = gemini.compute_work_accounting(worker_forward_end_position=100)
    findings["gemini_missing_useful_work_tail_clipped_to_zero"] = missing.tail_work_tokens
    assert missing.tail_work_tokens == 0
    findings["gemini_concurrency_alone_serial_falsification"] = gemini.verify_gpu_elapsed_clock_semantics(
        .2, .1, 2)["serial_service_model_falsified"]
    assert findings["gemini_concurrency_alone_serial_falsification"]
    ledger = gemini.ObservableBatchState()
    record = gemini.MarkedReservationRecord("duplicate", 8., 10., 128, 128)
    assert ledger.admit(record) and ledger.admit(record)
    ledger.release("duplicate", 11.)
    findings["gemini_duplicate_admission_orphan_reservation"] = [
        ledger.reserved_cost, len(ledger.active_reservations)]
    assert findings["gemini_duplicate_admission_orphan_reservation"] == [8., 0]

    aggregate = [gemini.IndependentSeedBlockOutcome(
        f"block-{i}", 180000 + i, "short_homogeneous", "development", 10.,
        10, 1, 10, 0, 0, good, 0, 0) for i, good in enumerate((22, 24, 21, 25))]
    inference = gemini.SuperiorityEvaluator(min_blocks=4).evaluate(aggregate, num_permutations=1)
    findings["gemini_four_impossible_aggregates_one_draw"] = {
        k: inference[k] for k in ("verdict", "two_sided_permutation_p_value")}
    assert inference["verdict"] == "CONFIRMED_SUPERIOR"
    assert inference["two_sided_permutation_p_value"] == 0
    protocol = gemini.build_native_campaign_protocol(offers_duration_s=0, max_drain_duration_s=120)
    findings["gemini_zero_offers_planned_max_drain_satisfies_hours"] = dict(
        summary=protocol["duration_summary"],
        all_schedules_empty=all(not e["actuator_schedule"] for e in protocol["episodes"]))
    assert protocol["duration_summary"]["hours_requirement_satisfied"]
    assert findings["gemini_zero_offers_planned_max_drain_satisfies_hours"]["all_schedules_empty"]
    state = gemini.ObservableBatchState()
    findings["gemini_horizon_and_continuation_parameters_unused"] = [
        gemini.RecedingHorizonMPCController(horizon_steps=h).decide(state, 5) for h in (1, 5)]
    assert findings["gemini_horizon_and_continuation_parameters_unused"] == [32., 32.]
    return dict(scope="Pinned CPU counterexamples; not native performance or safety evidence",
                source_sha256=receipts, counterexamples=findings)


def round3_counterexamples(frozen_root):
    """Replay R2 bytes, including substantive old-Sol failures, without native data."""
    import importlib.util
    import math
    import sys
    from dataclasses import replace
    from pathlib import Path

    root = Path(frozen_root)
    base = "experiments/mpc-research/native-v3/"
    expected = {
        "sol/" + base + "native_experiment_audit.py":
            "44423a5d76782da9d9118ddacbdb94e82d6963b70a65dfdf95d4e82d5487251d",
        "sol/" + base + "test_native_experiment_audit.py":
            "336d298fdc766618e126ce19c952ee1ccb3057f061041a575d07d6e53aeb6bf6",
        "opus/" + base + "native_release_model.py":
            "6e277d09c2ccfded2bb11e31164f97515c4bbdcc838f3df3f5a917864b297270",
        "opus/" + base + "test_native_release_model.py":
            "fd120e927353d4eec18c88b48711d68168a9bf3aa034138206b2b789b4ca1379",
        "astra/" + base + "native_response_planner.py":
            "61fed73aa44057dbfd15b4f337e67caffa29695d9aa80052b20f94e0e3e00b23",
        "astra/" + base + "test_native_response_planner.py":
            "abaedf4af5b6d428437cd0c27727a9b890ad178445f9212746f3888f34a44b07",
        "gemini/" + base + "native_campaign_protocol.py":
            "de51b0af0fd1d02db3c960162a82693df3620751944373c2e697b913c55ca38e",
        "gemini/" + base + "test_native_campaign_protocol.py":
            "f36f174d9f0f2db328dac7b3c4e18f30767f06d8bff9c264c1143599b14a0e03",
    }
    for relative, digest in expected.items():
        if hashlib.sha256((root / relative).read_bytes()).hexdigest() != digest:
            raise ValueError(f"Frozen R2 bytes changed: {relative}")

    def load(name, relative):
        spec = importlib.util.spec_from_file_location(name, root / relative)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        return module

    sol = load("nv3_sol_r2", "sol/" + base + "native_experiment_audit.py")
    opus = load("native_release_model", "opus/" + base + "native_release_model.py")
    ot = load("nv3_opus_r2_tests", "opus/" + base + "test_native_release_model.py")
    astra = load("native_response_planner", "astra/" + base + "native_response_planner.py")
    at = load("nv3_astra_r2_tests", "astra/" + base + "test_native_response_planner.py")
    gemini = load("nv3_gemini_r2", "gemini/" + base + "native_campaign_protocol.py")
    findings = {}

    def legacy(cases):
        for case in cases:
            for side in ("left", "right"):
                case[side].pop("configuration")
                case[side].pop("policy_sha256")
        return cases

    cases = legacy(blocks(2))
    for side in ("left", "right"):
        cases[1][side]["ttft_s"] = .05
    effects = sol.paired_effect(cases, bootstrap_samples=20)["block_effects_good_per_s"]
    findings["sol_r2_changed_global_ttft_with_same_hash"] = effects
    assert effects == [1., 0.]
    cases = []
    for i in range(6):
        case = copy.deepcopy(blocks(2)[0])
        case.update(seed=i, block_id=f"block-{i}", randomization_unit=f"unit-{i}")
        for side in ("left", "right"):
            rid = uid(f"relabeled-{i}-{side}")
            case[side]["offers"][0].update(request_id=rid, logical_id=f"label-{i}")
            case[side]["rows"][0].update(request_id=rid, response_request_id=rid)
        cases.append(case)
    p = sol.paired_effect(legacy(cases), bootstrap_samples=20)["exact_two_sided_signflip_p"]
    findings["sol_r2_six_relabeled_identical_semantic_tapes_p"] = p
    assert p == .03125
    case = arm(status="censored")
    case.pop("configuration")
    case.pop("policy_sha256")
    case["rows"][0].update(first_content_at=None, last_content_at=None, observed_until=11)
    upper = sol.audit_arm(**case)["good_upper"]
    findings["sol_r2_complete_no_first_beyond_ttft_upper"] = upper
    assert upper == 1

    ep = ot.episode([(1, 1., 128, 128, 0., .1, .6)])
    foreign = copy.deepcopy(ep)
    for obs in foreign["observations"]:
        obs["native"].update(clock_domain="foreign-clock", run_id="foreign-run")
    findings["opus_r2_foreign_native_identity_accepted"] = bool(opus.build_origins(foreign)[0])
    assert findings["opus_r2_foreign_native_identity_accepted"]
    bad_time = copy.deepcopy(ep)
    bad_time["ledger"][-1]["effective_at"] = -100
    truth = opus.build_dataset([bad_time])[0]["truth"][1.]
    findings["opus_r2_retroactive_release_truth"] = truth
    assert truth == (1., 1.)
    averages = [{h: opus._planned_budget({"cap_plan": plan}, 0, h, 16)
                 for h in opus.HORIZONS}
                for plan in ([(0, 16), (.5, 32), (1, 16)],
                             [(0, 32), (.5, 16), (1, 16)])]
    findings["opus_r2_order_distinct_plans_same_features"] = averages
    assert averages[0] == averages[1]
    decision = astra.plan_response(
        replace(at.state(), native_running=0), at.evaluation(), at.StubModel(),
        expected_identity=at.IDENTITY, timing=astra.Timing("test-clock", 10.1, .02, .5, .05),
        clock=lambda: 10.)
    findings["astra_r2_decode_mark_zero_running"] = dict(
        status=decision.status, active_permit=decision.active_permit)
    assert decision.status == "shadow" and decision.active_permit is False

    tail = gemini.audit_native_qualification_tail_distribution([])
    findings["gemini_r2_empty_records_stochastic_tail_claim"] = tail
    assert tail["tail_is_stochastic"] is True
    epochs = gemini.plan_gateway_epochs([
        dict(episode_id=str(i), offers_duration_s=120) for i in range(4)])
    findings["gemini_r2_default_first_epoch_episode_count"] = len(epochs[0].episode_ids)
    assert len(epochs[0].episode_ids) == 4
    qualified, reason = gemini.ExperimentDurationAccounting(
        400, 120, 48000, float("nan"), 0, 0, 0).validate_actual_10h_milestone()
    findings["gemini_r2_nan_actual_duration_qualified"] = dict(qualified=qualified, reason=reason)
    assert qualified is True and "nan" in reason
    p = gemini.robust_paired_permutation_test([1e-15] * 4)["p_value"]
    findings["gemini_r2_four_scaled_positive_effects_p"] = p
    assert p == 1.

    try:
        paired_effect(blocks(32), bootstrap_samples=20)
    except ValueError as exc:
        assert "bounded exact enumeration" in str(exc)
        findings["sol_retained_32_block_exact_protocol_refusal"] = str(exc)
    else:
        raise AssertionError("Exact inference was silently replaced beyond its declared bound")

    case = arm()
    case.update(origin=1700000000.123)
    case["offers"][0]["offset_s"] = .1
    scheduled = case["origin"] + .1
    case["rows"][0].update(scheduled_at=scheduled, sent_at=scheduled + .01,
                           first_content_at=scheduled + .1, last_content_at=scheduled + .11,
                           terminal_at=scheduled + .12)
    assert audit_arm(**case)["good_lower"] == 1
    case["rows"][0]["scheduled_at"] = 1700000000.223
    try:
        audit_arm(**case)
    except ValueError as exc:
        assert "Row origin differs" in str(exc)
    else:
        raise AssertionError("Exact source-origin contract unexpectedly relaxed")
    difference = case["rows"][0]["scheduled_at"] - scheduled
    assert math.isfinite(difference) and difference > 0
    findings["sol_retained_independently_rounded_origin_refusal_delta_s"] = difference
    return dict(scope="Pinned R2 CPU witnesses; no native inference or consensus",
                source_sha256=expected, counterexamples=findings)


def round7_peer_counterexamples(frozen_root):
    """Pinned R6 source witnesses only; no native data, fitting or intervention."""
    import importlib.util
    import sys
    from dataclasses import replace
    from pathlib import Path

    root = Path(frozen_root)
    manifest = json.loads((root / "manifest.json").read_text())
    expected = {
        "opus": ("native_release_model.py",
                 "53acdff61b71bd974c83054653ea78ad1797d430602653048e1af9604dafe3bc"),
        "astra": ("native_response_planner.py",
                  "deff252986a704ed461e5ee16cbea9abbe76f07ac6ec0132afc9b02b6a7a4d7b"),
        "gemini": ("native_campaign_protocol.py",
                   "7a1a18fd96cb7b53f527d83044f5b1dd9f458c2705e532bd7773f1eebf45ee87"),
        "sol": ("native_experiment_audit.py",
                "79226047437dcf35f9d6bfcc54382ec6c05c7d31866313d1b4f012c3143746d6"),
    }
    for model, (filename, digest) in expected.items():
        assert hashlib.sha256((root / model / filename).read_bytes()).hexdigest() == digest
        for relative, declared in manifest[model]["files"].items():
            assert hashlib.sha256((root / model / Path(relative).name).read_bytes()).hexdigest() == declared

    def load(model):
        path = root / model / expected[model][0]
        name = "nv3_r7_frozen_" + model
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        return module

    opus, astra, gemini = (load(model) for model in ("opus", "astra", "gemini"))
    findings = {}
    rid = uid("r7-source-witness")
    step = dict(t0=1., cell="fixture", joined={rid: 2},
                cohort={rid}, native=dict(running=1, waiting=0))
    row = dict(scheduled=.1, first=.2, terminal=None,
               first_published_at=1.1, first_received_at=1.2)
    assert opus.id_progress_state(step, rid, row)[0][2] is True
    unseen = dict(row, first=None, client_prefix_complete=False)
    assert opus.id_progress_state(step, rid, unseen) == "ttft_impossible"
    findings["opus_final_row_first_is_not_publication_cut_and_incomplete_prefix_zero"] = True
    other = uid("past-offer-outside-snapshot")
    _, cohort, birth = opus._horizon_good(step, [1.2], [(1.2, other)], 1.)
    assert (cohort, birth) == (0, 1)
    findings["opus_snapshot_complement_is_not_verified_post_cut_offered_birth"] = True
    client = dict(
        request_id=rid, response_request_id=other, clock_domain="fixture",
        scheduled_at=.1, sent_at=.11, first_content_at=.2, terminal_at=.25,
        status="complete", finish_reason="stop", usage=dict(completion_tokens=2),
        stream_done=False, stream_error=True, http_status=500)
    events, _ = opus._client_events(dict(
        clock_domain="fixture", expected_ids=[rid], client_rows=[client]))
    assert len(events["good"]) == 1
    findings["opus_api_labels_do_not_verify_wire_or_independent_physical_eos"] = True

    model = gemini.StructuralBatchProgressHybridModel()
    decoder = gemini.DecodeRequestState(rid, 128, 31, 32, 1., 0., 0., .1)
    state = gemini.StructuralBatchProgressState(1., 16., 1., (), (decoder,))
    _, obs = model.step(state, 16., (), natural_eos_probability=0.)
    assert obs["good"] == 1
    findings["gemini_output_limit_scores_good_without_natural_eos"] = True
    empty = gemini.StructuralBatchProgressState(0., 16., 0., (), ())
    after, _ = model.step(empty, 16., [dict(
        request_id=rid, original_cost=1., prompt_tokens=128,
        maximum_output_tokens=32, scheduled_at=0.)])
    assert after.decode_cohort[0].maximum_output_tokens == 128
    findings["gemini_offer_output_limit32_promotes_to128"] = True
    hidden = gemini.StructuralBatchProgressState(
        0., 16., 2., (), (), accepted_not_native_visible_cost=2.)
    after, _ = model.step(hidden, 16., ())
    assert after.active_reserved_cost == 2. and after.accepted_not_native_visible_cost == 1.6
    findings["gemini_unseen_mass_decays_without_owner_transition"] = True
    fallback = gemini.run_structural_progress_vs_scalar_diagnostic()
    assert fallback["birth_dominance_confirmed"]
    findings["gemini_missing_data_returns_embedded_native_diagnostic_constants"] = True

    request = astra.BatchProgress(rid, 8, 1, 7, 0, 0, None)
    length, = astra.advance_joint_forward((request,), ((rid, 1, 0, 0),))
    natural, = astra.advance_joint_forward(
        (replace(request, eos_at=1),), ((rid, 1, 0, 0),))
    assert (length.finish_reason, natural.finish_reason) == ("length", "stop")
    findings["astra_restricted_helper_preserves_length_vs_latent_eos"] = True
    return dict(scope="Hypothetical/source-contract R6 witnesses, not native results",
                source_sha256={model: digest for model, (_, digest) in expected.items()},
                verified_manifest_files=12, counterexamples=findings)


if __name__ == "__main__":
    unittest.main()
