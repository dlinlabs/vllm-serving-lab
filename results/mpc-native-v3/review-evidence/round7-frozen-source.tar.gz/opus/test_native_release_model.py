"""Focused contract tests for native_release_model. Fixtures exercise accounting and
causality only; they are not native measurements or performance evidence."""
import copy
import random
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import native_release_model as m  # noqa: E402

DOMAIN, RUN, NATIVE_RUN, OBSERVER = "clock-a", "run-a", "native-a", "f" * 64


def _uuid(i):
    return f"{i:032x}"


def episode(requests, *, block=170001, partition="train", step=0.25, until=None,
            episode_id=None, ledger=True, grid=None):
    """requests: (index, cost, prompt, max_tokens, admit, first, release)."""
    events = sorted([(r[4], 1, r) for r in requests] + [(r[6], -1, r) for r in requests],
                    key=lambda e: (e[0], -e[1]))
    ledger_frames, live, reserved, seq = [], {}, 0.0, 0
    for at, sign, r in events:
        seq += 1
        if sign > 0:
            live[_uuid(r[0])] = r
            reserved += r[1]
        else:
            live.pop(_uuid(r[0]))
            reserved -= r[1]
        ledger_frames.append(dict(event="mpc_ledger", run_id=RUN, clock_domain=DOMAIN, complete=True,
                           sequence=seq, effective_at=at, reserved_cost=max(reserved, 0.0)))
    end = until if until is not None else max(e[0] for e in events) + 0.5
    observations, t = [], 0.0
    while t <= end + 1e-9:
        seq_t = sum(1 for e in events if e[0] <= t)
        alive = [e[2] for e in events[:seq_t] if e[1] > 0
                 and not any(x[1] < 0 and x[2] is e[2] for x in events[:seq_t])]
        marks = [dict(request_id=_uuid(r[0]), cost=r[1], prompt_tokens=r[2], max_tokens=r[3],
                      received_at=r[4], admitted_at=r[4],
                      first_at=r[5] if r[5] <= t else None, scheduled_at=None) for r in alive]
        native = dict(schema="pr33-native-read-only-v1", complete=True, sampled_at=t + 0.01,
                      frontend_sampled_at=t + 0.011, run_id=NATIVE_RUN, clock_domain=DOMAIN,
                      observer_sha256=OBSERVER, running=len(alive), waiting=0,
                      pending_batches=0, kv_cache_usage=0.0,
                      requests=[dict(request_id=f"chatcmpl-{_uuid(r[0])}-0000abcd",
                                     prompt_tokens=r[2], maximum_output_tokens=r[3],
                                     output_tokens=min(r[3], max(0, int((t - r[5]) * 50))))
                                for r in alive])
        observations.append(dict(
            gateway=dict(run_id=RUN, clock_domain=DOMAIN, complete=True, sequence=seq_t,
                         sampled_at=t, budget=16.0, requests=marks),
            received_at=t + 0.005, native=native, native_received_at=t + 0.02))
        t += step
    return dict(episode_id=episode_id or f"ep-{block}-{partition}", seed_block=block,
                partition=partition, clock_domain=DOMAIN, run_id=RUN,
                native_run_id=NATIVE_RUN, observer_sha256=OBSERVER,
                origin_grid_s=step if grid is None else grid,
                observations=observations, ledger=ledger_frames if ledger else None)


def random_requests(seed, n=24):
    rng = random.Random(seed)
    out, t = [], 0.0
    for i in range(n):
        t += rng.uniform(0.1, 0.6)
        prompt = rng.choice((128, 4096))
        first = t + (0.05 if prompt == 128 else 0.3)
        out.append((seed * 1000 + i, 1.0 + 0.5 * (prompt == 4096), prompt, 128, t, first,
                    first + rng.uniform(0.5, 6.0)))
    return out


def test_truth_is_exact_for_distinct_costs_and_counts_observation_lag():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.30), (2, 2.0, 128, 128, 0.0, 0.1, 2.6)])
    rows = m.build_dataset([ep])
    origin = rows[0]                       # sampled 0.0, t0 0.02
    assert origin["reserved"] == 3.0
    assert origin["truth"][1.0] == (1.0, 1.0)
    assert origin["truth"][3.0] == (3.0, 3.0)
    late = next(o for o in rows if o["sampled_at"] == 0.25)
    # release at 0.30 happens after sampling but before t0+1 and is counted.
    assert late["truth"][1.0] == (1.0, 1.0)


def test_tied_costs_with_noncohort_release_yield_bounds_not_guesses():
    # Cohort mark 1 and non-cohort mark 3 (same cost) both release between snapshots.
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.05, 1.10), (2, 1.5, 128, 128, 0.0, 0.05, 4.0),
                  (3, 1.0, 128, 128, 1.01, 1.02, 1.05)], step=0.5)
    rows = m.build_dataset([ep])
    origin = next(o for o in rows if o["sampled_at"] == 0.0)
    # target 1.02+ ... t0=0.02 so h=1 target=1.02: neither 1.05 nor 1.10 released yet.
    assert origin["truth"][1.0] == (0.0, 0.0)
    mid = next(o for o in rows if o["sampled_at"] == 0.5 and _uuid(1) in o["cohort"])
    mid["t0"] = 0.5
    groups, unresolved = m.release_groups(mid, *_parsed_and_releases(ep))
    lo, hi = m.cumulative_truth(mid, groups, unresolved, 6.0, 0.57)  # target 1.07
    assert (lo, hi) == (0.0, 1.0)
    assert m.mark_label(_uuid(1), groups, unresolved, 6.0, 1.07) is None
    assert m.mark_label(_uuid(1), groups, unresolved, 6.0, 1.2) == 1


def _parsed_and_releases(ep):
    _, parsed, _ = m.build_origins(ep)
    releases, _ = m.ledger_releases(ep, parsed)
    return parsed, releases


def _raises(fn, text):
    try:
        fn()
    except ValueError as error:
        assert text in str(error), error
    else:
        raise AssertionError("expected ValueError " + text)


def test_ledger_gap_and_snapshot_mismatch_are_rejected():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.6), (2, 2.0, 128, 128, 0.1, 0.2, 1.1)])
    gap = copy.deepcopy(ep)
    del gap["ledger"][2]
    _raises(lambda: m.build_dataset([gap]), "ledger_identity_or_gap")
    bad = copy.deepcopy(ep)
    bad["ledger"][1]["reserved_cost"] = 5.0
    _raises(lambda: m.build_dataset([bad]), "snapshot_ledger_mismatch")


def test_final_heldout_and_partition_leakage_are_refused():
    reqs = [(1, 1.0, 128, 128, 0.0, 0.1, 0.6)]
    _raises(lambda: m.build_dataset([episode(reqs, block=160022)]), "final_heldout_reserved")
    _raises(lambda: m.build_dataset([episode(reqs, block=170001, episode_id="a"),
                                     episode(reqs, block=170001, partition="development",
                                             episode_id="b")]),
            "seed_block_partition_leakage")
    rows = m.build_dataset([episode(reqs, partition="calibration")])
    _raises(lambda: m.fit(rows), "fit_requires_train_only")


def test_unjoined_native_frame_is_rejected_and_stale_grid_points_abstain():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.6)])
    alien = copy.deepcopy(ep)
    alien["observations"][1]["native"]["requests"] = [
        dict(request_id=f"chatcmpl-{_uuid(99)}-0000abcd", output_tokens=0, prompt_tokens=128,
             maximum_output_tokens=128)]
    alien["observations"][1]["native"]["running"] = 1
    origins, _, stats = m.build_origins(alien)
    assert stats["rejected_native_frames"] == {"native_unjoined_or_ambiguous": 1}
    assert all(o["index"] != 1 for o in origins)
    stale = copy.deepcopy(ep)
    for obs in stale["observations"][1:3]:
        obs["native"] = None
    origins, _, stats = m.build_origins(stale)
    assert stats["stale_grid_points"] == 1                # grid 0.52 would reuse sample 0.0
    noncausal = copy.deepcopy(ep)
    noncausal["observations"][0]["native_received_at"] = noncausal["observations"][0]["received_at"] - 0.01
    _raises(lambda: m.build_dataset([noncausal]), "observation_stale_or_noncausal")


def test_features_do_not_depend_on_future_observations():
    ep = episode(random_requests(3))
    base = m.build_origins(ep)[0][8]
    future = copy.deepcopy(ep)
    for obs in future["observations"][9:]:
        for request in obs["native"]["requests"]:
            request["output_tokens"] = 0
    changed = m.build_origins(future)[0][8]
    for rid in base["cohort"]:
        for h in m.HORIZONS:
            assert m.mark_features(base, rid, h) == m.mark_features(changed, rid, h)


def test_end_to_end_train_only_fit_calibration_and_ood_abstention():
    episodes = [episode(random_requests(s), block=170000 + s, partition=p)
                for s, p in ((1, "train"), (2, "train"), (3, "train"), (4, "calibration"),
                             (5, "development"))]
    unseen = episode([(9001, 1.0, 999, 64, 0.0, 0.1, 3.0)], block=170099,
                     partition="development", episode_id="ood")
    result = m.evaluate(episodes + [unseen])
    assert result["train_blocks"] == [170001, 170002, 170003]
    dev = result["scores"]["development"]
    assert set(dev["models"]) == {"train_fraction", "fluid_history", "batch_aware"}
    assert dev["counts"]["ood_joint_work_mix"] >= 1
    assert set(dev["models"]["batch_aware"]["blocks"]) == {170005}
    assert result["calibration"]["blocks"] == [170004]
    assert set(result["development_coverage"]) == {170005}
    assert not result["native_performance_accepted"] and not result["statistical_guarantee"]
    rows = m.build_dataset(episodes[:3])
    params = m.fit(rows)
    for origin in rows:
        pred, _ = m.predict(params, origin)
        if pred:
            values = [pred["batch_aware"][h] for h in m.HORIZONS]
            assert values == sorted(values) and values[-1] <= origin["reserved"] + 1e-9


def _baseline_4096_32(tail_start_offset=-0.001, extra_tail=0, drop=None):
    rid, steps, rows, t = "r", [], [], 0.0
    work = [(0, 2048), (2048, 2048)] + [(4096 + i, 1) for i in range(32 + extra_tail)]
    for i, (pos, n) in enumerate(work):
        if drop == i:
            continue
        steps.append(dict(step_id=f"s{i}", start=t, end=t + 0.01,
                          work=[dict(request_id=rid, position=pos, tokens=n)]))
        rows.append(dict(step_id=f"s{i}", executed_positions={rid: pos}, executed_counts={rid: n}))
        t += 0.01
    finished = steps[-1]["start"] - tail_start_offset
    request = dict(input_tokens=4096, output_tokens=32, finish_reason="stop", finished=finished)
    return m.forward_work_accounting(request, steps, rows, request_id=rid)


def test_tail_accounting_keeps_legacy_audit_false_and_explains_one_prefinish_position():
    report = _baseline_4096_32()
    assert (report["useful_positions"], report["physical_positions"], report["tail_positions"]) \
        == (4127, 4128, 1)
    assert (report["useful_steps"], report["tail_steps"]) == (33, 1)
    assert report["legacy_strict_audit_valid"] is False
    assert report["tail_accounted"] is True


def test_tail_accounting_falsifiers():
    assert "tail_scheduled_after_finish" in _baseline_4096_32(tail_start_offset=0.001)["problems"]
    assert "unexplained_tail_work" in _baseline_4096_32(extra_tail=1)["problems"]
    assert "position_gap_repeat_or_split" in _baseline_4096_32(drop=5)["problems"]
    assert not _baseline_4096_32(extra_tail=1)["tail_accounted"]
    late_commit = _baseline_4096_32(tail_start_offset=-0.02)   # start < finish, end < finish
    assert "tail_commit_before_finish" in late_commit["problems"]
    assert not late_commit["tail_accounted"]


# ---------------------------------------------------------------------------
# Round 2: reproducible counterexamples against the frozen peer R1 bytes.
# NV3_PEER_ROOT points at Mayor's byte-verified freeze; absent files => skipped.
# ---------------------------------------------------------------------------
import importlib.util  # noqa: E402
import os  # noqa: E402

PEER_ROOT = Path(os.environ.get("NV3_PEER_ROOT", "/home/daniel_lin/.copilot/session-state/"
                 "73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-round1-frozen"))
PEER_FILES = dict(
    gemini=("gemini/native_campaign_protocol.py",
            "087c68868f48f6bac9d1ac829c9dc3cb8b749f1c40b87f6d5364bb2d2f4bad79"),
    sol=("sol/experiments/mpc-research/native-v3/native_experiment_audit.py",
         "6abb94a4fbc1f3e238cd2d4687e996829304afe669b38efba14f2ca29074a554"),
)


class Skip(Exception):
    pass


def _peer(name):
    import hashlib
    rel, sha = PEER_FILES[name]
    path = PEER_ROOT / rel
    if not path.exists():
        raise Skip(f"frozen {name} bytes unavailable")
    assert hashlib.sha256(path.read_bytes()).hexdigest() == sha, "peer bytes are not the R1 freeze"
    spec = importlib.util.spec_from_file_location(f"nv3_peer_{name}", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def test_peer_gemini_work_accounting_hides_missing_and_invents_tail_cause():
    g = _peer("gemini")
    short = g.compute_work_accounting(worker_forward_end_position=4100)
    assert short.tail_work_tokens == 0          # 27 missing useful positions clamped away, no error
    long = g.compute_work_accounting(worker_forward_end_position=4200)
    assert long.tail_work_tokens == 73 and "placeholder 1" in long.tail_work_cause
    base = g.compute_work_accounting()
    assert base.physical_executed_positions == base.useful_total_tokens + 1 == 4129  # off-by-one units


def test_peer_gemini_superiority_accepts_one_block_relabelled_six_times():
    g = _peer("gemini")
    blocks = [g.IndependentSeedBlockOutcome(
        block_id=f"clone-{i}", seed=900 + i, workload_family="x", split="final", duration_s=90.0,
        control_decisions=90, offered_requests=500, policy_a_good_completions=300,
        policy_a_rejections=10, policy_a_solver_overruns=0,
        policy_b_good_completions=360 + (i % 2), policy_b_rejections=10,
        policy_b_solver_overruns=0) for i in range(6)]
    assert g.SuperiorityEvaluator().evaluate(blocks)["verdict"] == "CONFIRMED_SUPERIOR"


def test_peer_gemini_protocol_counts_planned_drain_and_trains_on_its_ood_family():
    g = _peer("gemini")
    protocol = g.build_native_campaign_protocol()
    summary = protocol["duration_summary"]
    assert summary["hours_requirement_satisfied"] is True
    assert summary["total_active_and_drain_seconds"] == summary["total_episodes"] * (90 + 30)
    ood_train = [b for b in protocol["groups"].values()
                 if b["family"] == "unseen_ood_mix" and b["split"] == "train"]
    assert len(ood_train) == 10
    mixed = protocol["groups"][next(k for k, v in protocol["groups"].items()
                                    if v["family"] == "mixed_short_long")]
    assert mixed["prompt_tokens"] == 2048       # declared 80/20 p128/p4096 mix is not represented


def test_peer_gemini_empty_origin_and_missing_horizon_score_as_zero_error():
    g = _peer("gemini")
    empty = g.compute_normalized_absolute_error({}, {}, 0.0)
    assert empty["mean_normalized_absolute_error"] == 0.0
    missing = g.compute_normalized_absolute_error({1: 0.0, 3: 0.0, 5: 0.0}, {}, 10.0)
    assert missing["mean_normalized_absolute_error"] == 0.0   # absent labels become perfect


def test_peer_gemini_one_move_ignores_its_continuation():
    g = _peer("gemini")
    state = g.ObservableBatchState()
    assert all(g.StrongOneMoveController(c).decide(state, q) ==
               g.StrongOneMoveController(48.0 - c).decide(state, q)
               for c in (16.0, 32.0) for q in range(10))


def test_peer_sol_censored_upper_bound_ignores_elapsed_ttft_deadline():
    sol = _peer("sol")
    rid = "a" * 32
    offer = dict(request_id=rid, logical_id="l0", offset_s=0.0, prompt_sha256="b" * 64,
                 prompt_tokens=128, max_tokens=128)
    row = dict(request_id=rid, requested_max_tokens=128, clock_domain="c", scheduled_at=10.0,
               status="censored", sent_at=10.0, first_content_at=None, last_content_at=None,
               terminal_at=None, stream_done=False, observed_until=40.0)
    result = sol.audit_arm([offer], [row], origin=10.0, window_s=5.0, clock_domain="c")
    # No first content after 30s, so TTFT<=0.5s is already impossible; upper should be 0.
    assert result["good_upper"] == 1



# ---------------------------------------------------------------------------
# Round 3: regressions for peer witnesses O1-O7 against this module's R1/R2 bytes.
# ---------------------------------------------------------------------------

def test_r3_o1_foreign_native_run_clock_or_observer_is_not_joined():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.6)])
    for key, value in (("run_id", "native-b"), ("clock_domain", "clock-b"),
                       ("observer_sha256", "0" * 64)):
        bad = copy.deepcopy(ep)
        bad["observations"][1]["native"][key] = value
        origins, _, stats = m.build_origins(bad)
        assert stats["rejected_native_frames"] == {"native_source_or_clock": 1}, key
        assert all(o["index"] != 1 for o in origins)
    wide = copy.deepcopy(ep)
    wide["observations"][1]["native"]["frontend_sampled_at"] += 0.2
    assert m.build_origins(wide)[2]["rejected_native_frames"] == {"native_frame_time": 1}


def test_r3_o2_retroactive_and_negative_ledger_release_is_rejected():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.6), (2, 2.0, 128, 128, 0.1, 0.2, 1.1)])
    # Astra: release recorded after the 0.5 snapshot but effective before it.
    retro = copy.deepcopy(ep)
    frame = next(f for f in retro["ledger"] if f["effective_at"] == 0.6)
    frame["effective_at"] = 0.45
    _raises(lambda: m.build_dataset([retro]), "ledger_snapshot_chronology")
    # Sol: an effective_at far in the past.
    negative = copy.deepcopy(ep)
    negative["ledger"][-1]["effective_at"] = -100.0
    _raises(lambda: m.build_dataset([negative]), "ledger_chronology")


def test_r3_o3_plan_order_is_encoded_and_off_grid_plans_are_refused():
    a = [(0.0, 16.0), (1.0, 16.0), (2.0, 32.0), (3.0, 16.0)]
    b = [(0.0, 16.0), (1.0, 32.0), (2.0, 16.0), (3.0, 16.0)]
    fa, fb = m.plan_features(a, 0.5, 5.0, 16.0), m.plan_features(b, 0.5, 5.0, 16.0)
    assert fa != fb and sum(fa[1:]) == sum(fb[1:])          # same average, different order
    assert fa == (0.5, 16.0, 16.0, 32.0, 16.0, 16.0, 16.0)
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.6)])
    ep["cap_plan"] = [(0.0, 16.0), (0.5, 32.0), (1.0, 16.0)]
    _raises(lambda: m.build_origins(ep), "cap_plan_off_slot_grid")


def _cal_rows(block, residuals):
    return [dict(partition="calibration", seed_block=block, episode_id=f"e{block}", t0=float(i),
                 reserved=1.0, truth={h: (r, r) for h in m.HORIZONS})
            for i, r in enumerate(residuals)]


def test_r3_o4_calibration_is_block_level_and_ignores_duplicated_origins():
    original = m.predict
    m.predict = lambda params, o: ({"batch_aware": {h: 0.0 for h in m.HORIZONS}}, [])
    try:
        # Astra: 100 zero-residual origins in one block cannot erase another block's 1.
        astra = _cal_rows(1, [0.0] * 100) + _cal_rows(2, [1.0])
        assert m.calibrate({}, astra)["bands"][1.0]["upper"] == 1.0
        # Sol: duplicating origins cannot move the lower band.
        rows = _cal_rows(3, [-0.5, 0.5])
        base = m.calibrate({}, rows)
        dup = m.calibrate({}, rows + [copy.deepcopy(rows[1]) for _ in range(50)])
        assert base["bands"] == dup["bands"] and base["bands"][1.0]["lower"] == -0.5
    finally:
        m.predict = original


def test_r3_o4_origin_grid_is_invariant_to_duplicated_observations():
    ep = episode(random_requests(5), grid=0.5)
    doubled = copy.deepcopy(ep)
    doubled["observations"] = [copy.deepcopy(o) for o in ep["observations"] for _ in (0, 1)]
    a, b = m.build_dataset([ep]), m.build_dataset([doubled])
    assert [o["t0"] for o in a] == [o["t0"] for o in b]
    for x, y in zip(a, b):
        assert x["truth"] == y["truth"]
        for rid in x["cohort"]:
            assert [m.mark_features(x, rid, h) for h in m.HORIZONS] == \
                   [m.mark_features(y, rid, h) for h in m.HORIZONS]


def test_r3_o5_age_history_and_joint_mixture_leave_support():
    short = [(s * 100 + i, 1.0, 128, 128, 0.3 * i, 0.3 * i + 0.05, 0.3 * i + 1.5)
             for s in (1, 2) for i in range(8)]
    long = [(s * 100 + 50 + i, 1.5, 4096, 128, 0.3 * i, 0.3 * i + 0.3, 0.3 * i + 2.0)
            for s in (3, 4) for i in range(8)]
    train = m.build_dataset([episode([r for r in short if r[0] // 100 == s], block=170000 + s,
                                     episode_id=f"s{s}") for s in (1, 2)]
                            + [episode([r for r in long if r[0] // 100 == s], block=170000 + s,
                                       episode_id=f"l{s}") for s in (3, 4)])
    params = m.fit(train)
    mixed = m.build_dataset([episode([short[0], long[0]], block=170099, partition="development",
                                     episode_id="mix")])
    assert "joint_work_mix" in m.ood_reasons(mixed[0], params["support"])
    probe = copy.deepcopy(next(o for o in train if o["history_rate"] is not None))
    probe["history_rate"] = 10 * max(o["history_rate"] or 0.0 for o in train) + 1.0
    assert "range_history_rate" in m.ood_reasons(probe, params["support"])
    aged = copy.deepcopy(train[0])
    rid = next(iter(aged["cohort"]))
    aged["cohort"][rid] = dict(aged["cohort"][rid], admitted_at=aged["sampled_at"] - 600)
    assert "range_age_s" in m.ood_reasons(aged, params["support"])


def test_r3_o6_tail_flag_is_not_mechanism_or_authority_and_duplicates_fail():
    report = _baseline_4096_32()
    assert report["tail_accounted"] and not report["tail_mechanism_evidenced"]
    assert report["native_qualification_authority"] is False
    rid, steps, rows, t = "r", [], [], 0.0
    for i, (pos, n) in enumerate([(0, 2048), (2048, 2048)] + [(4096 + j, 1) for j in range(32)]):
        steps.append(dict(step_id=f"s{i}", start=t, end=t + 0.01,
                          work=[dict(request_id=rid, position=pos, tokens=n)]))
        rows.append(dict(step_id=f"s{i}", executed_positions={rid: pos}, executed_counts={rid: n}))
        t += 0.01
    finished = steps[-1]["start"] + 0.001
    evidence = dict(placeholder_tokens=1, cuda_completed=True, delivered_output_from_step=False,
                    output_commit_at=finished + 0.005)
    request = dict(input_tokens=4096, output_tokens=32, finish_reason="stop", finished=finished,
                   tail_evidence=evidence)
    full = m.forward_work_accounting(request, steps, rows, request_id=rid)
    assert full["tail_mechanism_evidenced"] and full["native_qualification_authority"] is False
    dup = m.forward_work_accounting(request, steps, rows + [dict(rows[-1])], request_id=rid)
    assert "duplicate_worker_step" in dup["problems"] and not dup["tail_accounted"]


def test_r3_o7_interval_labels_are_not_selected_and_fraction_is_monotone():
    # Snapshot brackets straddling t0+h create interval truth; no origin may be dropped.
    rows = m.build_dataset([episode(random_requests(7), step=0.5, grid=0.25, ledger=False)])
    assert any(o["truth"][h][0] < o["truth"][h][1] for o in rows for h in m.HORIZONS)
    params = m.fit(rows, sensitivity=True)
    fractions = [params["fraction"][h] for h in m.HORIZONS]
    assert fractions == sorted(fractions)
    for h in m.HORIZONS:
        lo, hi = params["fraction_bounds"][h]
        assert lo <= params["fraction"][h] <= hi
        assert params["label_counts"][h]["marks"] == sum(len(o["cohort"]) for o in rows)


def test_r3_snapshot_bracket_truth_without_ledger():
    ep = episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.30), (2, 2.0, 128, 128, 0.0, 0.1, 2.6)],
                 ledger=False)
    origin = m.build_dataset([ep])[0]
    assert origin["truth_source"] == "snapshot_bracket"
    assert origin["truth"][1.0] == (1.0, 1.0) and origin["truth"][3.0] == (3.0, 3.0)
    assert (m.bracket_label((0.25, 0.5), 0.4), m.bracket_label((0.25, 0.5), 0.5),
            m.bracket_label((0.25, 0.5), 0.25)) == (None, 1, 0)
    reappear = copy.deepcopy(ep)
    reappear["observations"][3]["gateway"]["requests"].append(
        copy.deepcopy(ep["observations"][0]["gateway"]["requests"][0]))
    reappear["observations"][3]["native"] = None
    _raises(lambda: m.build_dataset([reappear]), "mark_reappeared")


def test_r3_unconverged_fit_abstains_and_single_class_horizon_is_flagged():
    rows = m.build_dataset([episode(random_requests(s), block=170000 + s, episode_id=f"e{s}")
                            for s in (1, 2)])
    params = m.fit(rows)
    origin = next(o for o in rows if m.predict(params, o)[0] is not None)
    broken = copy.deepcopy(params)
    broken["logistic"][3.0]["converged"] = False
    assert "fit_not_converged" in m.predict(broken, origin)[1]
    constant = m._fit_or_constant([(0.0,), (1.0,)], [1, 1], [1.0, 1.0])
    assert constant["degenerate"] and constant["constant"] == 1.0
    assert all("degenerate" in params["logistic"][h] for h in m.HORIZONS)



def _with_actions(applied_at=1.6, planned_at=1.0):
    ep = episode(random_requests(4), grid=0.25)
    ep["actions"] = [dict(planned_at=None, budget=16.0, budget_version=1, applied_at=-1.0,
                          ack_received_at=-0.99, attempts=1),
                     dict(planned_at=planned_at, budget=16.0, budget_version=2,
                          applied_at=applied_at, ack_received_at=applied_at + 0.02, attempts=2)]
    for obs in ep["observations"]:
        obs["gateway"]["budget_version"] = 1 if obs["gateway"]["sampled_at"] < applied_at else 2
    return ep


def test_r3b_cut_precedes_ack_and_outstanding_command_abstains():
    ep = _with_actions()
    origins, _, stats = m.build_origins(ep)
    assert stats["rejected_native_frames"] == {}
    late = [round(o["t0"], 6) for o in origins if o["outstanding_actions"]]
    assert late == [1.02, 1.27, 1.52]      # sent at 1.0, ACK received 1.62: knowable online
    rows = m.build_dataset([ep, episode(random_requests(5), block=170005, episode_id="b")])
    params = m.fit(rows)
    origin = next(o for o in rows if o["outstanding_actions"])
    assert "outstanding_action_at_cut" in m.predict(params, origin)[1]
    _raises(lambda: m.build_origins(_with_actions(applied_at=1.01, planned_at=1.02)),
            "cut_after_action_ack")


def test_r3b_snapshot_budget_must_match_ack_in_force():
    ep = _with_actions()
    ep["observations"][2]["gateway"]["budget_version"] = 2      # sampled 0.5, ACK v2 at 1.6
    assert m.build_origins(ep)[2]["rejected_native_frames"] == {"gateway_budget_provenance": 1}

REPLICA = Path(os.environ.get("NV3_REPLICA", "/home/daniel_lin/.copilot/session-state/"
               "73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-long01-replica"))


def test_r3_actual_replica_adapter_reproduces_reference_join_counts():
    name = "nv3-181001-p128-m128-arm0.json"
    if not (REPLICA / name).exists():
        raise Skip("read-only native replica unavailable")
    import json
    index = json.loads((REPLICA / "latest-index.json").read_text())
    listed = {json.loads(line)["artifact"]: json.loads(line)["sha256"]
              for line in (REPLICA / "verified-artifact-sha256.jsonl").read_text().splitlines()
              if line.strip()}
    import hashlib
    assert hashlib.sha256((REPLICA / name).read_bytes()).hexdigest() == listed[name]
    ep = m.episode_from_replica(json.loads((REPLICA / name).read_text()), index)
    _, _, stats = m.build_origins(ep)
    assert (stats["joined_frames"], stats["joined_frame_marks_not_native_visible"],
            stats["joined_frame_marks"]) == (765, 3034, 13280)
    assert stats["rejected_native_frames"] == {}
    final = dict(json.loads((REPLICA / name).read_text()), seed_block=160021)
    _raises(lambda: m.episode_from_replica(final, index), "replica_seed_block_not_train")


# ---------------------------------------------------------------------------
# R4: short-step joint transition candidate (nv3-opus-joint-transition-v1)
# ---------------------------------------------------------------------------

def joint_episode(requests, rejected=(), block=170001, episode_id=None, duration=4.0):
    """requests as episode(); rejected: (index, sent_at). Client rows are fixtures."""
    ep = episode(requests, block=block, episode_id=episode_id, until=duration + 0.5)
    rows = [dict(request_id=_uuid(r[0]), clock_domain=DOMAIN, scheduled_at=r[4] - 0.002,
                 sent_at=r[4] - 0.001, first_content_at=r[5], terminal_at=r[6], status="complete",
                 finish_reason="stop", admission_rejection=False,
                 usage=dict(completion_tokens=50)) for r in requests]
    rows += [dict(request_id=_uuid(i), clock_domain=DOMAIN, scheduled_at=t - 0.001, sent_at=t,
                  first_content_at=None, terminal_at=t + 0.01, status="rejected",
                  finish_reason=None, admission_rejection=True, usage=None) for i, t in rejected]
    ep.update(start=0.0, duration_s=duration, cell="fixture", client_rows=rows,
              expected_ids=[r["request_id"] for r in rows])
    return ep


def test_r4_stock_flow_identity_and_receipt_labels():
    ep = joint_episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.7), (2, 2.0, 128, 128, 0.6, 0.65, 3.0)],
                       rejected=[(3, 0.8)])
    steps, good = m.joint_steps(ep)
    by_k = {s["k"]: s for s in steps}
    labelled = [s for s in steps if s["labels"]]
    for s in labelled:
        nxt, y = by_k[s["k"] + 1]["gateway"], s["labels"]
        assert abs(nxt["reserved"] - (s["gateway"]["reserved"] - y["released_cost"]
                                      + y["born_cost"])) < 1e-9
        assert y["offers"] >= y["admitted"]
    totals = {c: sum(s["labels"][c] for s in labelled) for c in m.CLIENT_KINDS}
    assert (totals["rejected"], totals["good"], totals["ttft_miss"]) == (1, 2, 0)
    assert [rid for _, rid in good] == [_uuid(1), _uuid(2)]


def test_r4_counterexample_marginal_release_cannot_be_goodput_kernel():
    """Identical original cohort at the cut => identical R3 marginal features, yet past
    offered/rejected receipts and future births differ, and so does future good."""
    base = [(1, 1.0, 128, 128, 0.0, 0.1, 2.0)]
    a = joint_episode(base, episode_id="a")
    b = joint_episode(base + [(2, 1.0, 128, 128, 1.6, 1.7, 1.9)], rejected=[(8, 0.3), (9, 0.35)],
                      episode_id="b")
    ra = {o["t0"]: o for o in m.build_origins(dict(a, origin_grid_s=0.5, origin_grid_start=0.0))[0]}
    rb = {o["t0"]: o for o in m.build_origins(dict(b, origin_grid_s=0.5, origin_grid_start=0.0))[0]}
    oa, ob = ra[1.0], rb[1.0]
    assert set(oa["cohort"]) == set(ob["cohort"]) == {_uuid(1)}
    assert all(m.mark_features(oa, _uuid(1), h) == m.mark_features(ob, _uuid(1), h)
               for h in m.HORIZONS)
    ja = next(s for s in m.joint_steps(a)[0] if s["t0"] == 1.0)
    jb = next(s for s in m.joint_steps(b)[0] if s["t0"] == 1.0)
    assert (ja["gateway"]["hist_offers"], jb["gateway"]["hist_offers"]) == (1.0, 3.0)
    assert (ja["gateway"]["hist_rejected"], jb["gateway"]["hist_rejected"]) == (0.0, 2.0)
    future = lambda ep: sum(1 for t, _ in m.joint_steps(ep)[1] if 1.0 < t <= 3.0)
    assert (future(a), future(b)) == (1, 2)


def test_r4_client_fencing_and_snapshot_consistency():
    ep = joint_episode([(1, 1.0, 128, 128, 0.0, 0.1, 0.7)], rejected=[(3, 0.8)])
    foreign = copy.deepcopy(ep)
    foreign["client_rows"][0]["clock_domain"] = "clock-b"
    _raises(lambda: m.joint_steps(foreign), "client_row_identity_or_clock")
    missing = copy.deepcopy(ep)
    missing["client_rows"].pop()
    _raises(lambda: m.joint_steps(missing), "client_rows_incomplete")
    contradict = copy.deepcopy(ep)
    row = contradict["client_rows"][0]
    row.update(status="rejected", admission_rejection=True, first_content_at=None,
               finish_reason=None, usage=None)
    _raises(lambda: m.joint_steps(contradict), "snapshot_client_inconsistent")


def test_r4_features_and_rollout_ignore_future_receipts():
    reqs = random_requests(11, n=16)
    ep = joint_episode(reqs, rejected=[(900 + i, 0.2 + 0.4 * i) for i in range(8)], duration=6.0)
    k0 = next(s for s in m.joint_steps(ep)[0] if s["t0"] == 2.0)
    later = copy.deepcopy(ep)
    for row in later["client_rows"]:
        if row["admission_rejection"] and row["sent_at"] > 2.0:
            row["sent_at"] = row["scheduled_at"] = 5.9
            row["terminal_at"] = 5.95
    k1 = next(s for s in m.joint_steps(later)[0] if s["t0"] == 2.0)
    assert k0["gateway"] == k1["gateway"] and k0["hist_steps"] == k1["hist_steps"]
    model = dict(mean=[0.0] * len(m.GATEWAY_FEATURES), scale=[1.0] * len(m.GATEWAY_FEATURES),
                 betas={t: [0.1] + [0.0] * len(m.GATEWAY_FEATURES) for t in m.TARGETS})
    runs = [[{t: 0.0 for t in m.TARGETS}] * m.ROLLOUT_STEPS]
    assert m._rollout(model, k0, runs, random.Random(1), 4) == \
        m._rollout(model, k1, runs, random.Random(1), 4)


def test_r4_crossfit_is_train_only_block_grouped_and_unqualified():
    eps = [joint_episode(random_requests(s, n=30), rejected=[(5000 + s * 10 + i, 0.3 + i)
                                                             for i in range(5)],
                         block=170000 + s // 2, episode_id=f"j{s}", duration=8.0)
           for s in (2, 3, 4, 5)]
    out = m.joint_crossfit(eps)
    assert sorted(out["folds"]) == ["170001", "170002"]
    for held, fold in out["folds"].items():
        assert int(held) not in fold["train_blocks"]
    assert not (out["calibration_result"] or out["mpc_result"] or out["statistical_guarantee"])
    assert out["marginal_release_model_is_joint"] is False and "unqualified" in out["scenario_status"]
    cal = copy.deepcopy(eps)
    cal[0]["partition"] = "calibration"
    _raises(lambda: m.joint_crossfit(cal), "joint_requires_train_only")
    _raises(lambda: m.joint_crossfit(eps[:2]), "crossfit_needs_two_blocks")


def test_r4_actual_replica_joint_steps_are_consistent():
    name = "nv3-181001-p128-m128-arm0.json"
    if not (REPLICA / name).exists():
        raise Skip("read-only native replica unavailable")
    import json
    index = json.loads((REPLICA / "latest-index.json").read_text())
    document = json.loads((REPLICA / name).read_text())
    steps, good = m.joint_steps(m.episode_from_replica(document, index))
    assert len(good) == document["summary"]["natural_cohort_good"] == 2540
    by_k = {s["k"]: s for s in steps}
    labelled = [s for s in steps if s["labels"]]
    assert len(labelled) >= 230
    for s in labelled:
        y = s["labels"]
        assert abs(by_k[s["k"] + 1]["gateway"]["reserved"]
                   - (s["gateway"]["reserved"] - y["released_cost"] + y["born_cost"])) < 1e-6
    assert sum(s["labels"]["offers"] for s in labelled) <= document["summary"]["offered"]


# ---------------------------------------------------------------------------
# R5: exogenous common arrival law (nv3-opus-exogenous-arrival-v2)
# ---------------------------------------------------------------------------

def _r5_step():
    reqs = random_requests(11, n=16)
    ep = joint_episode(reqs, rejected=[(900 + i, 0.2 + 0.4 * i) for i in range(8)], duration=6.0)
    return next(s for s in m.joint_steps(ep)[0] if s["t0"] == 2.0)


def test_r5_arrival_path_is_independent_of_candidate_plan_and_state():
    step = _r5_step()
    k = len(m.GATEWAY_FEATURES)
    model = dict(mean=[0.0] * (k + 1), scale=[1.0] * (k + 1),
                 betas={t: [0.0] * (k + 1) + [0.5] for t in m.TARGETS})
    model["betas"]["born_cost"] = [0.0] * (k + 1) + [3.0]
    model["betas"]["offers"] = [0.0, 1.0] + [0.0] * k  # would couple offers to reserved
    runs = [[{t: 0.1 * j for t in m.TARGETS} for j in range(m.ROLLOUT_STEPS)]]
    law = m.arrival_law(step)
    assert law == statistics.fmean(h["offers"] for h in step["hist_steps"])
    arrivals = lambda r, o: [max(0.0, law + r[o + j]["offers"]) for j in range(m.ROLLOUT_STEPS)]
    paths = {}
    for cap in (16.0, 32.0):
        alt = copy.deepcopy(step)
        alt["plan"] = [cap] * (m.ROLLOUT_STEPS + 1)
        alt["gateway"]["reserved"] += cap  # different state too
        paths[cap] = m._rollout(model, alt, runs, random.Random(3), m.ROLLOUT_STEPS, arrivals)
        assert m.arrival_law(alt) == law
    offers = {c: [[p[j]["offers"] for j in range(m.ROLLOUT_STEPS)] for p in ps]
              for c, ps in paths.items()}
    assert offers[16.0] == offers[32.0]
    assert [p[-1]["reserved"] for p in paths[16.0]] != [p[-1]["reserved"] for p in paths[32.0]]
    # v1 recursion lets the same coefficients move offers with state: the contract differs
    v1 = dict(mean=[0.0] * k, scale=[1.0] * k,
              betas={t: [0.0, 1.0] + [0.0] * (k - 1) for t in m.TARGETS})
    a, b = copy.deepcopy(step), copy.deepcopy(step)
    b["gateway"]["reserved"] += 8.0
    off = lambda st: m._rollout(v1, st, runs, random.Random(3), 2)[0][-1]["offers"]
    assert off(a) != off(b)


def test_r5_oracle_disturbance_is_separate_and_dev_block_gate_refuses_incomplete():
    eps = [joint_episode(random_requests(s, n=30), rejected=[(5000 + s * 10 + i, 0.3 + i)
                                                             for i in range(5)],
                         block=181000 + s // 2, episode_id=f"x{s}", duration=8.0)
           for s in (2, 3, 4, 5)]
    fresh = copy.deepcopy(eps[0])
    fresh.update(seed_block=181003, episode_id="fresh")
    out = m.exogenous_report(eps + [fresh], train_blocks=(181001, 181002))
    assert out["development"]["status"] == "not_run: incomplete"
    cross = out["cross_fit"]
    assert cross["exogenous_schema"] == m.EXO_VERSION and "independent of the candidate" \
        in cross["arrival_contract"] and "unqualified" in cross["exo_scenario_status"]
    assert sorted(cross["folds"]) == ["181001", "181002"]
    for fold in cross["folds"].values():
        oracle = fold["oracle_disturbance_diagnostic"]
        assert oracle["status"].startswith("ORACLE DISTURBANCE")
        assert all("oracle" not in name for name in fold["one_step_mae"])
        assert all("oracle" not in key for per in fold["free_running_mae"].values()
                   for key in per)
        assert oracle["one_step_mae"]["offers"] == 0.0
    base = m.joint_crossfit(eps)
    for held in base["folds"]:
        v1 = base["folds"][held]["free_running_mae"]
        v2 = cross["folds"][held]["free_running_mae"]
        assert all(v2[h][k] == v for h in v1 for k, v in v1[h].items())


# ---------------------------------------------------------------------------
# R6: ID-level progress hybrid (nv3-opus-progress-hybrid-v3)
# ---------------------------------------------------------------------------

def _r6_step(joined, running=4, waiting=0):
    return dict(t0=10.0, cell="c", joined=joined, cohort=set(joined) | {"u"},
                native=dict(running=running, waiting=waiting),
                gateway=dict(reserved=8.0, live=3.0))


def test_r6_counterexample_same_aggregate_state_different_progress_and_future_good():
    """Same Gateway aggregate (R, n, budget, history) -> any aggregate cohort model is
    forced to one prediction; per-ID TTFT/progress state makes future good differ."""
    step = _r6_step({"a": 100, "b": 100})
    ok = dict(scheduled=9.8, first=9.9, terminal=None)
    late = dict(scheduled=9.0, first=None, terminal=None)
    done = dict(scheduled=8.0, first=8.1, terminal=9.5)
    table = {(5.0, "c", True, True, 3, (0, False)): (40, 38),
             (5.0, "c", False, False): (40, 30), (5.0,): (100, 50)}
    rows_a = dict(a=ok, b=ok, u=dict(scheduled=9.9, first=None, terminal=None))
    rows_b = dict(a=late, b=late, u=done)
    prob = lambda rows: sum(m.progress_probability(table, 5.0, m.id_progress_state(step, r, rows[r]))[0]
                            for r in step["cohort"])
    assert abs(prob(rows_a) - (2 * 38 / 40 + 30 / 40)) < 1e-12
    assert prob(rows_b) == 0.0
    assert m.id_progress_state(step, "a", late) == "ttft_impossible"
    assert m.id_progress_state(step, "u", done) == "client_terminal"
    # a first content received after the cut is not used (no future receipt)
    future_first = dict(scheduled=9.8, first=10.3, terminal=None)
    assert m.id_progress_state(step, "a", future_first)[0][2] is False


def test_r6_hazard_fit_rejects_impossible_good_and_backs_off_declared_levels():
    keys = m.id_progress_state(_r6_step({"a": 3}), "a", dict(scheduled=9.8, first=9.9,
                                                              terminal=None))
    assert keys[0] == ("c", True, True, 1, (0, False))
    table = m.fit_progress_hazard([(1.0, keys, 1)] * 5 + [(1.0, keys, 0)] * 25)
    assert m.progress_probability(table, 1.0, keys) == (5 / 30, "level0")
    sparse = m.fit_progress_hazard([(1.0, keys, 1)] * 3)
    assert m.progress_probability(sparse, 1.0, keys) == (1.0, "level3")
    _raises(lambda: m.progress_probability({}, 1.0, keys), "progress_hazard_unsupported")
    _raises(lambda: m.fit_progress_hazard([(1.0, "ttft_impossible", 1)]),
            "deterministic_state_became_good")


def test_r6_diagnostic_refuses_incomplete_block_and_non_train():
    eps = [joint_episode(random_requests(s, n=20), block=181000 + s // 2, episode_id=f"p{s}",
                         duration=8.0) for s in (2, 3, 4, 5, 6)]
    _raises(lambda: m.progress_diagnostic(eps), "development_block_incomplete")
    bad = copy.deepcopy(eps)
    bad[0]["partition"] = "validation"
    _raises(lambda: m.progress_diagnostic(bad), "progress_requires_train_only")


def test_r6_frozen_three_block_origins_match_r5_rollout_origins():
    root = REPLICA.parent / "pr33-native-v3-first-three-complete-train-blocks-frozen"
    if not (root / "verified-artifact-sha256.jsonl").exists():
        raise Skip("frozen three-block Train data unavailable")
    out = m.progress_diagnostic(m.load_replica(root)[0])
    assert out["counts"]["origins"] == 544  # = R5.8 held-out 181003 rollout origins
    assert round(out["summary"]["5s"]["total|history_mean"]["mae"], 2) == 8.76
    for h in ("1s", "3s", "5s"):
        assert abs(out["summary"][h]["ORACLE|oracle_cohort"]["mae"]
                   - out["summary"][h]["part|birth_reduced_form"]["mae"]) < 1e-9


# ---------------------------------------------------------------------------
# R7: paired common-tape plan-response diagnostic (nv3-opus-plan-response-v4)
# ---------------------------------------------------------------------------

def test_r7_plan_inputs_are_exact_planned_sequence_masked_and_receipt_only():
    step = _r5_step()
    step["plan"] = [16.0, 32.0, 32.0, 16.0, 16.0, 32.0, 32.0, 16.0, 16.0, 32.0, 32.0]
    base = m.plan_inputs(step, 5, "r6_next")
    blind = m.plan_inputs(step, 5, "blind")
    assert len(blind) == len(base) - 1
    assert m.plan_inputs(step, 5, "full_plan") == blind + step["plan"][:10]
    assert m.plan_inputs(step, 1, "masked_plan") == blind + step["plan"][:2]
    late = copy.deepcopy(step)
    late["plan"][9] = 16.0                       # differs only after 3 s
    assert m.plan_inputs(late, 3, "masked_plan") == m.plan_inputs(step, 3, "masked_plan")
    assert m.plan_inputs(late, 5, "full_plan") != m.plan_inputs(step, 5, "full_plan")
    assert m.plan_inputs(late, 5, "blind") == blind
    future = copy.deepcopy(step)
    future["labels"] = {t: 99.0 for t in m.TARGETS}
    assert all(m.plan_inputs(future, 5, v) == m.plan_inputs(step, 5, v) for v in m.PLAN_VARIANTS)


def test_r7_schedule_design_and_pair_gates():
    ep = dict(cap_plan=[(0.0, 16), (1.0, 32), (2.0, 32), (3.0, 16), (4.0, 16), (5.0, 32)],
              actions=[dict(planned_at=None, attempts=1, applied_at=0.0, ack_received_at=0.0),
                       dict(planned_at=1.0, attempts=2, applied_at=1.05, ack_received_at=1.06)])
    d = m._schedule_design([ep])
    assert d["repeat_probability"] == 2 / 5 and d["five_slot_patterns"] == 2
    assert d["retried_actions"] == 1 and abs(d["ack_lag_s"]["max"] - 0.06) < 1e-12
    bad = dict(ep, cap_plan=[(0.0, 16), (1.5, 32)])
    _raises(lambda: m._schedule_design([bad]), "schedule_slot_not_1s")
    eps = [joint_episode(random_requests(s, n=20), block=181000 + s // 2, episode_id=f"p{s}",
                         duration=8.0) for s in (2, 3, 4, 5, 6)]
    _raises(lambda: m.plan_response_diagnostic(eps), "development_block_incomplete")
    nontrain = copy.deepcopy(eps)
    nontrain[0]["partition"] = "validation"
    _raises(lambda: m.plan_response_diagnostic(nontrain), "plan_requires_train_only")


def test_r7_frozen_paired_contrast_negatives():
    root = REPLICA.parent / "pr33-native-v3-first-three-complete-train-blocks-frozen"
    if not (root / "verified-artifact-sha256.jsonl").exists():
        raise Skip("frozen three-block Train data unavailable")
    out = m.plan_response_diagnostic(m.load_replica(root)[0])
    assert out["counts"]["origins"] == 544 and out["counts"]["pairs"] == 264
    p = out["paired_difference"]
    for h in ("1s", "3s", "5s"):
        assert p[f"{h}|offers|zero_predictor"] < 0.05      # common tape is real
        assert p[f"{h}|offers|full_plan"] > 0.5             # state ridge breaks invariance
    assert p["5s|good|full_plan"] > p["5s|good|zero_predictor"]   # contrast negative
    assert p["1s|rejected|full_plan"] < p["1s|rejected|blind"]
    assert p["5s|good|masked_plan"] == p["5s|good|full_plan"]

if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    skipped = 0
    for test in tests:
        try:
            test()
            print("PASS", test.__name__)
        except Skip as reason:
            skipped += 1
            print("SKIP", test.__name__, reason)
    print(f"{len(tests) - skipped} passed, {skipped} skipped")
