"""NV3 receipt/outcome audits; no actuator or native qualification authority."""

import copy
import hashlib
from fractions import Fraction
import itertools
import json
import math
import random
import re
import statistics
import time


def _finite(value, name):
    try:
        valid = type(value) in (int, float) and math.isfinite(value) and value >= 0
    except OverflowError:
        valid = False
    if not valid:
        raise ValueError(f"Invalid finite nonnegative {name}")
    return value


def _integer(value, name, minimum=1):
    if type(value) is not int or value < minimum:
        raise ValueError(f"Invalid integer {name}")
    return value


def _text(value, name):
    if not isinstance(value, str) or not value:
        raise ValueError(f"Missing {name}")
    return value


def _uuid(value):
    if not isinstance(value, str) or not re.fullmatch("[0-9a-f]{32}", value):
        raise ValueError("Physical request UUID must be exact lowercase hex32")
    return value


def _sha(value):
    if not isinstance(value, str) or not re.fullmatch("[0-9a-f]{64}", value):
        raise ValueError("Missing SHA256 provenance")
    return value


def _digest(value):
    return hashlib.sha256(json.dumps(
        value, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode()).hexdigest()


def _public_payload(value):
    fields = {"schema", "requested_max_tokens", "prompt_class", "prompt_token_estimate",
              "source_sha256", "prompt_estimator_sha256"}
    if type(value) is not dict or set(value) != fields or value["schema"] != "native-v3-public-payload-v1":
        raise ValueError("Invalid closed public payload schema; no prompt text")
    _finite(_integer(value["requested_max_tokens"], "requested maximum"), "requested maximum")
    if value["prompt_class"] not in (None, "short", "prefill_heavy", "mixed"):
        raise ValueError("Unknown public prompt class")
    if value["prompt_token_estimate"] is not None:
        _finite(_integer(value["prompt_token_estimate"], "prompt estimate", 0), "prompt estimate")
    _sha(value["source_sha256"])
    estimator = value["prompt_estimator_sha256"]
    if value["prompt_class"] is not None or value["prompt_token_estimate"] is not None:
        _sha(estimator)
    elif estimator is not None:
        _sha(estimator)
    return copy.deepcopy(value)


class OfferedReceiptHistory:
    """Ordered client publications, received on one common host clock domain.

    A real callback publisher must stamp event_at/published_at and serialize its
    sequence. receive() stamps observer receipt itself; cut() seals a prefix.
    Single-consumer interface; neither provenance nor stream completeness is
    authenticated here. sent means attempt initiation, not wire proof. Unknown
    offered cost stays None; terminal status is a client lifecycle label, not EOS.
    """

    SCHEMA = "native-v3-offered-publication-v1"
    REGISTRATION_V2 = "native-v3-offered-registration-v2"

    def __init__(self, *, publisher_run_id, observer_run_id, clock_domain,
                 clock=time.monotonic, capture_source_sha256=None):
        self._publisher_run_id = _uuid(publisher_run_id)
        self._observer_run_id = _uuid(observer_run_id)
        self._clock_domain = _text(clock_domain, "observer clock domain")
        self._capture_source = _sha(capture_source_sha256) if capture_source_sha256 is not None else None
        if not callable(clock):
            raise ValueError("Missing observer receipt clock")
        self._clock = clock
        self._receipts, self._records = [], {}
        self._last_clock = self._last_publication = -1
        self._last_cut, self._sealed = None, None

    def _now(self):
        now = _finite(self._clock(), "observer clock")
        if now < self._last_clock:
            raise ValueError("Observer clock regressed")
        return now

    @staticmethod
    def _apply(records, receipt):
        rid, kind = receipt["request_id"], receipt["kind"]
        stamp = {key: receipt[key] for key in (
            "event_at", "published_at", "received_at", "publication_seq")}
        if "capture" in receipt:
            stamp["capture"] = copy.deepcopy(receipt["capture"])
        if kind == "offered":
            if rid in records:
                raise ValueError("Offered UUID reused")
            records[rid] = dict(
                request_id=rid, scheduled_at=receipt["scheduled_at"],
                original_cost=receipt["original_cost"],
                cost_spec_sha256=receipt["cost_spec_sha256"],
                offered=stamp, sent=None, first=None, terminal=None)
            if "public_metadata" in receipt:
                records[rid].update(public_metadata=copy.deepcopy(receipt["public_metadata"]),
                                    registration_schema=receipt["schema"])
            return
        if rid not in records:
            raise ValueError("Publication lacks an offered UUID")
        record = records[rid]
        if "capture" in receipt:
            source = receipt["capture"]["row"]
            sent = record["sent"]["event_at"] if record["sent"] is not None else None
            if (source["scheduled_at"] != record["scheduled_at"]
                    or kind != "sent" and source["sent_at"] != sent):
                raise ValueError("Capture registration/send differs from received history")
            if record["first"] is not None and source["first_content_at"] != record["first"]["event_at"]:
                raise ValueError("Capture first differs from received history")
            if kind == "terminal" and source["first_content_at"] is not None and record["first"] is None:
                record["first_publication_missing"] = True
        if record["terminal"] is not None or record[kind] is not None:
            raise ValueError("Duplicate event or publication after terminal")
        prior = record["first"] or record["sent"] or record["offered"]
        if receipt["event_at"] < prior["event_at"]:
            raise ValueError("Client event chronology regressed")
        if kind == "sent" and receipt["event_at"] < record["scheduled_at"]:
            raise ValueError("Send precedes scheduled offer")
        if kind == "first" and record["sent"] is None:
            raise ValueError("First content precedes send")
        if kind == "terminal":
            if receipt["status"] == "complete" and record["sent"] is None:
                raise ValueError("Complete client response lacks send")
            stamp["status"] = receipt["status"]
        record[kind] = stamp

    def receive(self, publication):
        """Consume a producer envelope; never accept a producer-supplied receive stamp."""
        base = {"schema", "publisher_run_id", "clock_domain", "publication_seq",
                "kind", "request_id", "event_at", "published_at"}
        if type(publication) is not dict:
            raise ValueError("Missing client publication envelope")
        kind = publication.get("kind")
        extra = ({"scheduled_at", "original_cost", "cost_spec_sha256"} if kind == "offered"
                 else {"status"} if kind == "terminal" else set())
        if "capture" in publication and kind != "offered":
            extra |= {"capture"}
        versioned_registration = publication.get("schema") == self.REGISTRATION_V2 and kind == "offered"
        if versioned_registration:
            extra |= {"public_metadata"}
        if kind not in ("offered", "sent", "first", "terminal") or set(publication) != base | extra:
            raise ValueError("Invalid client publication schema; final rows are not receipts")
        if (publication["schema"] != self.SCHEMA and not versioned_registration
                or publication["publisher_run_id"] != self._publisher_run_id
                or publication["clock_domain"] != self._clock_domain):
            raise ValueError("Publisher schema/run/clock differs from observer")
        sequence = _integer(publication["publication_seq"], "publication sequence")
        if sequence != len(self._receipts) + 1:
            raise ValueError("Publication sequence gap/reuse; ordered delivery required")
        _uuid(publication["request_id"])
        event = _finite(publication["event_at"], "client event")
        published = _finite(publication["published_at"], "client publication")
        now = self._now()
        if not event <= published <= now or published < self._last_publication:
            raise ValueError("Publication chronology/future receipt")
        if kind == "offered":
            if versioned_registration:
                _public_payload(publication["public_metadata"])
            _finite(publication["scheduled_at"], "scheduled origin")
            cost, spec = publication["original_cost"], publication["cost_spec_sha256"]
            if cost is not None:
                if _finite(cost, "original offered cost") == 0:
                    raise ValueError("Original offered cost must be positive or unknown")
                _sha(spec)
            elif spec is not None:
                _sha(spec)
        elif kind == "terminal" and publication["status"] not in (
                "complete", "rejected", "cancelled", "failed", "timeout"):
            raise ValueError("Unknown client terminal label")
        if "capture" in publication:
            capture = publication["capture"]
            if type(capture) is not dict or set(capture) != {"source_sha256", "kind", "row"}:
                raise ValueError("Invalid capture source envelope")
            _sha(capture["source_sha256"])
            if capture["source_sha256"] != self._capture_source:
                raise ValueError("Capture source hash differs from bound consumer")
            source = capture["row"]
            field, native_kind = {
                "sent": ("sent_at", "offered"),
                "first": ("first_content_at", "first_content"),
                "terminal": ("terminal_at", "terminal"),
            }[kind]
            if (type(source) is not dict or capture["kind"] != native_kind
                    or source["request_id"] != publication["request_id"]
                    or source["clock_domain"] != self._clock_domain
                    or _finite(source[field], "capture event") != event
                    or not event <= _finite(source["published_at"], "capture publication") <= published
                    or kind == "terminal" and source["status"] != publication["status"]):
                raise ValueError("Capture source/event/clock differs")
        receipt = copy.deepcopy(publication)
        receipt.update(received_at=now, observer_run_id=self._observer_run_id,
                       observer_clock_domain=self._clock_domain)
        proposed = ({receipt["request_id"]: copy.deepcopy(self._records[receipt["request_id"]])}
                    if receipt["request_id"] in self._records else {})
        self._apply(proposed, receipt)
        self._records[receipt["request_id"]] = proposed[receipt["request_id"]]
        self._receipts.append(receipt)
        self._last_clock, self._last_publication = now, published
        return copy.deepcopy(receipt)

    def cut(self, cut_at):
        """Seal a monotone as-of receipt prefix; repeated equal-time cuts stay immutable."""
        cut = _finite(cut_at, "history cut")
        now = self._now()
        if cut > now or self._last_cut is not None and cut < self._last_cut:
            raise ValueError("Future or regressing history cut")
        if cut == self._last_cut:
            self._last_clock = now
            return copy.deepcopy(self._sealed)
        records, watermark = {}, 0
        for receipt in self._receipts:
            if receipt["received_at"] > cut:
                break
            self._apply(records, receipt)
            watermark = receipt["publication_seq"]
        due = sorted((r for r in records.values() if r["scheduled_at"] <= cut),
                     key=lambda r: (r["scheduled_at"], r["offered"]["publication_seq"]))
        statuses = {status: sum(r["terminal"] is not None and r["terminal"]["status"] == status
                               for r in due)
                    for status in ("complete", "rejected", "cancelled", "failed", "timeout")}
        sealed = dict(
            cut_at=cut, receipt_watermark=watermark, clock_domain=self._clock_domain,
            publisher_run_id=self._publisher_run_id, observer_run_id=self._observer_run_id,
            requests=due,
            registrations=[copy.deepcopy(r) for r in records.values()],
            counts=dict(offered=len(due), sent=sum(r["sent"] is not None for r in due),
                        registered_due=len(due),
                        actual_offered=sum(r["sent"] is not None for r in due),
                        first=sum(r["first"] is not None for r in due),
                        unknown_original_cost=sum(r["original_cost"] is None for r in due),
                        late_sent=sum(r["sent"] is not None
                                      and r["sent"]["event_at"] > r["scheduled_at"] for r in due),
                        pending=sum(r["terminal"] is None for r in due),
                        terminal=statuses),
            scope="Receipt-visible due offers, including unsent/closed requests;"
                  " original offered cost is not a Gateway reservation or GPU demand.",
            publisher_complete_through_cut=False, callback_source_authenticated=False,
            independent_native_eos_verified=False, active_mpc_permit=False)
        self._last_cut, self._last_clock, self._sealed = cut, now, copy.deepcopy(sealed)
        return copy.deepcopy(sealed)


class CaptureReceiptBridge:
    """Synchronous capture_chat observe bridge; registrations are not attempts.

    Publisher/consumer clocks are separate callables on a common clock domain.
    register() must precede task creation/validation/cancellation. cut() counts
    actual sent attempts for arrivals; history.cut() retains R5 registration
    semantics. Source declarations and delivered packets grant no authority.
    """

    CAPTURE_SHA256 = "a8bbafd6a84f8a1581a2f0e0d0fe11a086c542e392a45c1466fa9071df93fb6c"

    def __init__(self, *, publisher_run_id, observer_run_id, clock_domain,
                 publisher_clock=time.monotonic, observer_clock=time.monotonic,
                 capture_source_sha256=CAPTURE_SHA256, deliver=None):
        self._publisher = _uuid(publisher_run_id)
        self._domain = _text(clock_domain, "capture clock domain")
        self._source = _sha(capture_source_sha256)
        if not callable(publisher_clock):
            raise ValueError("Missing publisher clock")
        self._clock = publisher_clock
        self.history = OfferedReceiptHistory(
            publisher_run_id=publisher_run_id, observer_run_id=observer_run_id,
            clock_domain=clock_domain, clock=observer_clock, capture_source_sha256=self._source)
        self._deliver = self.history.receive if deliver is None else deliver
        if not callable(self._deliver):
            raise ValueError("Missing synchronous delivery")
        self._registrations, self._sequence = {}, 0
        self._last_publication, self._error = -1, None

    @property
    def observation_error(self):
        """Live error latch, not a retrospectively available cut feature."""
        return self._error

    def _publish(self, kind, rid, event_at=None, **fields):
        if self._error is not None:
            raise ValueError("Capture bridge observation error latched")
        try:
            published = _finite(self._clock(), "bridge publication NOW")
            if published < self._last_publication:
                raise ValueError("Bridge publisher clock regressed")
            event = published if event_at is None else _finite(event_at, "capture event")
            if event > published:
                raise ValueError("Capture event is after bridge publication")
            self._sequence += 1
            self._last_publication = published
            publication = dict(
                schema=(OfferedReceiptHistory.REGISTRATION_V2 if "public_metadata" in fields
                        else OfferedReceiptHistory.SCHEMA), publisher_run_id=self._publisher,
                clock_domain=self._domain, publication_seq=self._sequence,
                kind=kind, request_id=rid, event_at=event, published_at=published, **fields)
            result = self._deliver(copy.deepcopy(publication))
            if hasattr(result, "__await__"):
                if hasattr(result, "close"):
                    result.close()
                raise ValueError("Synchronous bridge delivery required")
            return copy.deepcopy(publication)
        except Exception as exc:
            self._error = self._error or type(exc).__name__
            raise

    def register(self, request_id, scheduled_at, *, original_offered_estimate=None,
                 estimate_provenance=None, public_metadata=None):
        """Prospective plan registration, never a send or reservation-charge receipt."""
        try:
            rid = _uuid(request_id)
            if rid in self._registrations:
                raise ValueError("Registered capture UUID reused")
            scheduled = _finite(scheduled_at, "capture scheduled plan")
            provenance = copy.deepcopy(estimate_provenance)
            if provenance is not None:
                if type(provenance) is not dict:
                    raise ValueError("Estimate provenance must be a dictionary or unknown")
                _digest(provenance)
            source = provenance.get("source_sha256") if provenance is not None else None
            if source is not None:
                _sha(source)
            if original_offered_estimate is not None:
                if _finite(original_offered_estimate, "offered estimate") == 0:
                    raise ValueError("Offered estimate must be positive or unknown")
                _sha(source)
            self._registrations[rid] = dict(scheduled_at=scheduled,
                                            estimate_provenance=provenance)
            extra = {}
            if public_metadata is not None:
                extra["public_metadata"] = _public_payload(public_metadata)
                self._registrations[rid]["public_metadata"] = copy.deepcopy(extra["public_metadata"])
            self._publish("offered", rid, scheduled_at=scheduled,
                          original_cost=original_offered_estimate, cost_spec_sha256=source, **extra)
        except Exception as exc:
            self._error = self._error or type(exc).__name__
            raise

    def observe(self, kind, receipt):
        """Pass directly as capture_chat(observe=bridge.observe); never final-row replay."""
        try:
            fields = {"offered": ("sent", "sent_at"),
                      "first_content": ("first", "first_content_at"),
                      "terminal": ("terminal", "terminal_at")}
            if kind not in fields or type(receipt) is not dict:
                raise ValueError("Unknown capture callback")
            rid = _uuid(receipt["request_id"])
            registration = self._registrations.get(rid)
            if (registration is None or receipt["clock_domain"] != self._domain
                    or receipt["scheduled_at"] != registration["scheduled_at"]):
                raise ValueError("Capture callback lacks matching prospective registration")
            metadata = registration.get("public_metadata")
            if metadata is not None and receipt["requested_max_tokens"] != metadata["requested_max_tokens"]:
                raise ValueError("Capture requested maximum differs from registered public metadata")
            mapped, event_field = fields[kind]
            if kind != "terminal" and (
                    receipt["status"] != "attempted" or receipt["terminal_at"] is not None):
                raise ValueError("Final rows cannot replace capture callbacks")
            capture = dict(source_sha256=self._source, kind=kind, row=copy.deepcopy(receipt))
            extra = {"status": receipt["status"]} if mapped == "terminal" else {}
            self._publish(mapped, rid, _finite(receipt[event_field], "actual capture event"),
                          capture=capture, **extra)
        except Exception as exc:
            self._error = self._error or type(exc).__name__
            raise

    def cut(self, cut_at):
        """Copied as-of prefix; offered/arrival counts refer only to sent attempts."""
        prefix = self.history.cut(cut_at)
        records = prefix["registrations"]
        for record in records:
            record["registration"] = record.pop("offered")
            record["original_offered_estimate"] = record.pop("original_cost")
            record.pop("cost_spec_sha256")
            record["estimate_provenance"] = copy.deepcopy(
                self._registrations[record["request_id"]]["estimate_provenance"])
            record["gateway_reservation_charge"] = None
            record["gateway_charge_provenance"] = None
        statuses = {status: sum(r["terminal"] is not None and r["terminal"]["status"] == status
                               for r in records)
                    for status in ("complete", "rejected", "cancelled", "failed", "timeout")}
        attempts = [r for r in records if r["sent"] is not None]
        return dict(
            cut_at=prefix["cut_at"], receipt_watermark=prefix["receipt_watermark"],
            publisher_run_id=self._publisher, observer_run_id=prefix["observer_run_id"],
            clock_domain=self._domain, capture_source_sha256=self._source,
            requests=copy.deepcopy(records),
            arrival_attempts=[dict(request_id=r["request_id"], **copy.deepcopy(r["sent"]))
                              for r in attempts],
            counts=dict(registered=len(records), planned_due=sum(r["scheduled_at"] <= cut_at for r in records),
                        offered=len(attempts), sent=len(attempts),
                        first=sum(r["first"] is not None for r in records),
                        late_sent=sum(r["sent"]["event_at"] > r["scheduled_at"] for r in attempts),
                        pending=sum(r["terminal"] is None for r in attempts),
                        planned_pending=sum(r["terminal"] is None for r in records),
                        unattempted=sum(r["sent"] is None for r in records),
                        missing_first_publication=sum(r.get("first_publication_missing", False)
                                                      for r in records),
                        terminal=statuses,
                        unsent_cancelled=sum(r["sent"] is None and r["terminal"] is not None
                                             and r["terminal"]["status"] == "cancelled" for r in records)),
            scope="Receipt-visible planned registrations and ACTUAL client attempt arrivals;"
                  " offered estimates are not Gateway charges, wire proof or GPU work.",
            publisher_complete_through_cut=False, callback_source_authenticated=False,
            independent_native_eos_verified=False, active_mpc_permit=False)


class OnlineModelInputAdapter:
    """Single-consumer receipt cuts; no implicit joins or ready-to-run v5 inputs."""

    NATIVE_SOURCE_SHA256 = "835df8ebaa58c773074e65cedba4627b468d14b560233a7655bf9cd2240b83d6"
    SCHEMA = "native-v3-online-model-input-v2"
    GATEWAY_SOURCE_SHA256 = "5e3e2f45a20ed66afed21b93b79f217138edc771493ecca7e963e102c4a94c7d"
    TELEMETRY_SOURCE_SHA256 = "46d6fb923e558f6435d269dd6fa5cfd5b0d71eb1fd91cbb3aaca8a82385e6370"
    RUNTIME_SOURCE_SHA256 = "f04c58eb9b5a81e7e1c7a22aaea1cd6b59de88c568ec77d51f1487af4c85b727"
    CLOCK_SOURCE_SHA256 = "cbbd1f338e0d078d5c5eacdfbcec725dcfe2ed9b46c1ee1ed68ad2f26de24e1f"

    def __init__(self, bridge, native_binding, *, clock=time.monotonic, max_age_s=0.5):
        from pathlib import Path
        from mpc_lab import native_state

        if hashlib.sha256(Path(native_state.__file__).read_bytes()).hexdigest() != self.NATIVE_SOURCE_SHA256:
            raise ValueError("Parent NativeState implementation differs from bound source")
        if not isinstance(bridge, CaptureReceiptBridge) or not callable(clock):
            raise ValueError("Missing actual capture bridge/observer clock")
        if not isinstance(native_binding, native_state.NativeBinding):
            raise ValueError("Missing parent NativeBinding")
        if native_binding.clock_domain != bridge._domain:
            raise ValueError("Native/capture clock domains differ")
        _sha(native_binding.observer_sha256)
        self._parent, self._binding, self._bridge = native_state, copy.deepcopy(native_binding), bridge
        self._clock, self._max_age = clock, _finite(max_age_s, "native age limit")
        if self._max_age == 0:
            raise ValueError("Native age limit must be positive")
        self._native, self._last_clock = [], -1
        self._gateway_bindings = {}
        self._last_cut, self._sealed = None, None

    def _now(self):
        now = _finite(self._clock(), "model-input observer clock")
        if now < self._last_clock:
            raise ValueError("Model-input observer clock regressed")
        self._last_clock = now
        return now

    def receive_native(self, frame):
        """Consume a contemporaneous parent frame; stamp this receiver independently."""
        now = self._now()
        if type(frame) is not dict:
            raise ValueError("Native frame required, not final rows or unbound NativeState")
        source = copy.deepcopy(frame)
        reported_receive = _finite(source["received_at"], "native upstream receive")
        if reported_receive > now:
            raise ValueError("Native upstream receipt is in the future")
        source["received_at"] = now
        result = self._parent.estimate_native_state(
            source, self._binding, now=now, max_age_s=self._max_age)
        if result.state is None:
            raise ValueError(result.reason)
        state = result.state
        if state.sampled_at > reported_receive or source["frontend_sampled_at"] > reported_receive:
            raise ValueError("Native sampling after upstream receipt")
        if source["gateway_received_at"] > reported_receive:
            raise ValueError("Gateway receipt after upstream receipt")
        if self._native and (
                state.sampled_at <= self._native[-1]["state"].sampled_at
                or state.gateway.sequence < self._native[-1]["state"].gateway.sequence):
            raise ValueError("Native sample/Gateway sequence regressed or reused")
        receipt = dict(schema="native-v3-native-observation-receipt-v1",
                       observation_seq=len(self._native) + 1, received_at=now,
                       upstream_received_at=reported_receive, source_published_at=None,
                       state=copy.deepcopy(state))
        self._native.append(receipt)
        return copy.deepcopy(receipt)

    def receive_gateway_uuid_binding(self, gateway, request_id):
        """Local producer read before outcome; not a remotely authenticated certificate."""
        import inspect
        from pathlib import Path
        from types import ModuleType
        from mpc_lab import runtime

        if not isinstance(gateway, ModuleType):
            raise ValueError("Actual Gateway module required, not a declared binding dictionary")
        files = ((gateway.__file__, self.GATEWAY_SOURCE_SHA256),
                 (inspect.getmodule(type(gateway.telemetry)).__file__, self.TELEMETRY_SOURCE_SHA256),
                 (runtime.__file__, self.RUNTIME_SOURCE_SHA256),
                 (inspect.getsourcefile(gateway.mpc_local_clock_domain), self.CLOCK_SOURCE_SHA256))
        for path, digest in files:
            if hashlib.sha256(Path(path).read_bytes()).hexdigest() != digest:
                raise ValueError("Gateway lineage source mismatch")
        if (gateway.BENCHMARK_REQUEST_IDS is not True or gateway.MPC_LAB_ENABLED is not True
                or gateway.ADMISSION_MODE != "cost_aware"
                or any(gateway.os.environ.get(k, "1") != "1"
                       for k in ("WEB_CONCURRENCY", "UVICORN_WORKERS"))):
            raise ValueError("Gateway lineage configuration unqualified")
        if (gateway.mpc_clock_domain != self._binding.clock_domain
                or gateway.telemetry.run_id != self._binding.gateway_run_id
                or gateway.mpc_identity != self._binding.identity):
            raise ValueError("Gateway lineage run/domain/identity mismatch")
        rid = _uuid(request_id)
        record = self._bridge.history._records.get(rid)
        if (record is None or record["sent"] is None or record["terminal"] is not None
                or record["sent"].get("capture", {}).get("source_sha256")
                != CaptureReceiptBridge.CAPTURE_SHA256):
            raise ValueError("Gateway binding requires actual pre-terminal client attempt")
        if rid in self._gateway_bindings:
            raise ValueError("Gateway UUID binding reused")
        entry = gateway.telemetry.active.get(rid)
        if rid not in gateway.benchmark_ids or entry is None:
            raise ValueError("No observed validated benchmark UUID before Gateway outcome")
        now = self._now()
        received = _finite(entry["received"], "Gateway telemetry received")
        if not record["sent"]["event_at"] <= received <= now:
            raise ValueError("Gateway received/actual attempt chronology differs")
        receipt = dict(
            schema="native-v3-gateway-benchmark-uuid-receipt-v1",
            observation_seq=len(self._gateway_bindings) + 1, request_id=rid,
            run_id=gateway.telemetry.run_id, clock_domain=gateway.mpc_clock_domain,
            identity_fingerprint=gateway.mpc_identity.fingerprint,
            gateway_source_sha256=self.GATEWAY_SOURCE_SHA256,
            telemetry_source_sha256=self.TELEMETRY_SOURCE_SHA256,
            runtime_source_sha256=self.RUNTIME_SOURCE_SHA256,
            clock_source_sha256=self.CLOCK_SOURCE_SHA256,
            gateway_received_at=received, received_at=now,
            source_published_at=None, source_publication_seq=None,
            accepted_observed=entry["admitted"] is True,
            scope="Pinned local producer contract/registry observation; execution unauthenticated")
        self._gateway_bindings[rid] = receipt
        return copy.deepcopy(receipt)

    def cut(self, cut_at, *, history_window_s=30.0):
        from dataclasses import asdict

        cut, window = _finite(cut_at, "model-input cut"), _finite(history_window_s, "history window")
        if window == 0 or cut > self._now() or self._last_cut is not None and cut < self._last_cut:
            raise ValueError("Invalid future/regressing model-input cut/window")
        if self._last_cut == cut:
            if self._sealed["history_window_s"] != window:
                raise ValueError("Sealed cut cannot change feature window")
            return copy.deepcopy(self._sealed)
        client = self._bridge.cut(cut)
        visible = [r for r in self._native if r["received_at"] <= cut]
        native, reason, watermark = None, "native_observation_missing", 0
        if visible:
            latest = visible[-1]
            state, watermark = latest["state"], latest["observation_seq"]
            if cut - state.sampled_at <= self._max_age and cut - state.gateway.sampled_at <= self._max_age:
                native, reason = asdict(state), None
                native["observation_receipt"] = {k: v for k, v in latest.items() if k != "state"}
                native["waiting_work"] = None
                native["accepted_not_native_visible_work"] = None
            else:
                reason = "native_observation_stale"
        attempts, pending, mix, public_mix, unknown = [], [], {}, {}, 0
        bindings = {rid: r for rid, r in self._gateway_bindings.items() if r["received_at"] <= cut}
        owners = {}
        for observation in visible:
            for mark in observation["state"].gateway.requests:
                proof = bindings.get(mark.request_id)
                if proof is None:
                    continue
                if mark.received_at < proof["gateway_received_at"]:
                    raise ValueError("Gateway mark precedes bound telemetry receive")
                signature = (mark.cost, mark.prompt_tokens, mark.max_tokens,
                             mark.received_at, mark.admitted_at)
                if mark.request_id in owners and owners[mark.request_id]["signature"] != signature:
                    raise ValueError("Bound original Gateway owner charge/identity changed")
                owners[mark.request_id] = dict(signature=signature, cost=mark.cost,
                                               sampled_at=observation["state"].gateway.sampled_at,
                                               received_at=observation["received_at"],
                                               max_tokens=mark.max_tokens)
        for record in client["requests"]:
            if record["sent"] is None:
                continue
            metadata = copy.deepcopy(record.get("public_metadata"))
            item = dict(request_id=record["request_id"], sent=record["sent"]["event_at"],
                        sent_published_at=record["sent"]["published_at"],
                        sent_publication_seq=record["sent"]["publication_seq"],
                        sent_received_at=record["sent"]["received_at"],
                        registration_schema=record.get("registration_schema", OfferedReceiptHistory.SCHEMA),
                        registration_publication_seq=record["registration"]["publication_seq"],
                        registration_received_at=record["registration"]["received_at"],
                        scheduled_at=record["scheduled_at"], public_metadata=metadata,
                        prompt_estimate_status="unknown" if metadata is None else
                                               "source_declared_not_execution_verified",
                        first=(None if record["first"] is None else
                               {k: record["first"][k] for k in (
                                   "event_at", "published_at", "received_at", "publication_seq")}),
                        terminal=(None if record["terminal"] is None else
                                  {k: record["terminal"][k] for k in (
                                      "event_at", "published_at", "received_at", "publication_seq", "status")}),
                        original_offered_estimate=record["original_offered_estimate"],
                        actual_gateway_charge=None, gateway_status="unknown",
                        gateway_binding_receipt=None, known_gateway_accepted=False,
                        gateway_owned_at_last_sample=None, readmission_allowed=None,
                        engine_request_id=None)
            proof, owner = bindings.get(record["request_id"]), owners.get(record["request_id"])
            if proof is not None:
                item["gateway_binding_receipt"] = copy.deepcopy(proof)
                item["gateway_status"] = "received_admission_unknown"
                if proof["accepted_observed"] or owner is not None:
                    item.update(known_gateway_accepted=True, readmission_allowed=False,
                                gateway_status="accepted_current_ownership_unknown")
                if owner is not None:
                    if metadata is not None and metadata["requested_max_tokens"] != owner["max_tokens"]:
                        raise ValueError("Bound Gateway mark differs from registered payload maximum")
                    item["actual_gateway_charge"] = owner["cost"]
                    item["gateway_charge_receipt"] = {k: v for k, v in owner.items() if k != "signature"}
                if native is not None and item["known_gateway_accepted"]:
                    present = any(m["request_id"] == record["request_id"]
                                  for m in native["gateway"]["requests"])
                    item["gateway_owned_at_last_sample"] = present
                    if present:
                        item["gateway_status"] = "accepted_owned_at_last_sample"
            attempts.append(item)
            if item["terminal"] is None:
                pending.append(copy.deepcopy(item))
            if metadata is None:
                unknown += 1
            else:
                cls = metadata["requested_max_tokens"]
                mix[cls] = mix.get(cls, 0) + 1
                group = public_mix.setdefault(
                    _digest(metadata), dict(public_metadata=copy.deepcopy(metadata), count=0))
                group["count"] += 1
        recent = sum(cut - window < r["sent"] <= cut for r in attempts)
        sealed = dict(
            schema=self.SCHEMA, cut_at=cut, history_window_s=window,
            publisher_run_id=client["publisher_run_id"], observer_run_id=client["observer_run_id"],
            clock_domain=client["clock_domain"], capture_source_sha256=client["capture_source_sha256"],
            native_state_source_sha256=self.NATIVE_SOURCE_SHA256,
            native_binding=dict(native_run_id=self._binding.native_run_id,
                                gateway_run_id=self._binding.gateway_run_id,
                                observer_sha256=self._binding.observer_sha256,
                                identity_fingerprint=self._binding.identity.fingerprint),
            client_receipt_watermark=client["receipt_watermark"],
            native_receipt_watermark=watermark, native=native, native_refusal=reason,
            request_lineage=("source_contract_client_gateway_only_native_unverified" if bindings
                             else "unverified_no_namespace_joins"),
            attempts=attempts, pending_client_attempts=pending,
            past_offered_payload_mix=sorted(mix.items()), unknown_payload_attempts=unknown,
            past_offered_public_payload_mix=[public_mix[k] for k in sorted(public_mix)],
            arrival_rate_approximation=dict(observed_attempts=recent, exposure_s=window,
                                            rate=recent / window,
                                            scope="Incomplete receipt-count/window proxy, not fitted v5 law"),
            v5_input=None,
            v5_refusals=["verified_engine_gateway_client_lineage_missing",
                         "pending_original_gateway_charge_unknown",
                         "all_offered_completeness_and_v5_arrival_law_unqualified",
                         "cell_payload_cost_table_and_prompt_estimator_transfer_unqualified",
                         "planned_assignment_ACK_compliance_and_plan_support_unqualified"],
            publisher_complete_through_cut=False, callback_source_authenticated=False,
            independent_native_eos_verified=False, active_mpc_permit=False)
        self._last_cut, self._sealed = cut, copy.deepcopy(sealed)
        return copy.deepcopy(sealed)


def fit_batch_progress_artifacts(artifacts):
    """Used Train1..3, one fixed cell/arm: conditional persistent-inventory progress only."""
    from pathlib import Path
    from mpc_lab import native_state, runtime

    if hashlib.sha256(Path(native_state.__file__).read_bytes()).hexdigest() != OnlineModelInputAdapter.NATIVE_SOURCE_SHA256:
        raise ValueError("Unbound NativeState fit parser")
    required = {f"nv3-{block}-p4096-m128-arm0.events.jsonl" for block in (181001, 181002, 181003)}
    if set(artifacts) != required:
        raise ValueError("Fit scope is exactly already-used Train1..3 p4096/m128 arm0")
    totals = {phase: dict(increment=0, exposure=0., observations=0) for phase in ("prefill", "decode")}
    counts, hashes = {}, {}
    for name in sorted(required):
        raw, expected = artifacts[name]
        if hashlib.sha256(raw).hexdigest() != _sha(expected):
            raise ValueError("Train artifact bytes differ from receipt")
        hashes[name] = expected
        prior, binding, accepted, excluded = None, None, 0, 0
        reasons = {}

        def exclude(reason):
            reasons[reason] = reasons.get(reason, 0) + 1
        for line in raw.splitlines():
            event = json.loads(line)
            if event.get("kind") != "native_frame":
                continue
            frame = event["value"]
            if binding is None:
                snapshot = runtime.snapshot_from_dict(frame["gateway_snapshot"])
                binding = native_state.NativeBinding(
                    frame["clock_domain"], snapshot.run_id, frame["run_id"],
                    "29fc1ebd875ccc1a53b9584fd0f3b002c518e3653c9b4238877b67b7ec13802e",
                    snapshot.identity)
            estimate = native_state.estimate_native_state(frame, binding, now=frame["received_at"])
            current = estimate.state
            if current is None:
                exclude(estimate.reason)
                prior, excluded = None, excluded + 1
                continue
            if prior is not None:
                before = {p.engine_request_id: p for p in prior.progress}
                after = {p.engine_request_id: p for p in current.progress}
                complete = all(s.waiting == 0 and s.pending_batches == 0
                               and s.frontend_unfinished == s.running for s in (prior, current))
                dt = current.sampled_at - prior.sampled_at
                if (before and set(before) == set(after) and complete
                        and prior.received_at < current.sampled_at and 0 < dt <= .5):
                    np = sum(p.computed_tokens < p.prompt_tokens for p in before.values())
                    den = (2 * np + len(before) - np) * (1 + prior.kv_cache_usage)
                    for rid, old in before.items():
                        new = after[rid]
                        if (old.prompt_tokens, old.maximum_output_tokens) != (
                                new.prompt_tokens, new.maximum_output_tokens):
                            exclude("request_metadata_changed")
                            excluded += 1
                            continue
                        if old.computed_tokens < old.prompt_tokens and new.computed_tokens <= old.prompt_tokens:
                            if new.output_tokens != old.output_tokens:
                                exclude("mixed_prefill_decode")
                                excluded += 1
                                continue
                            phase, increment = "prefill", new.computed_tokens - old.computed_tokens
                        elif old.computed_tokens >= old.prompt_tokens and old.output_tokens < old.maximum_output_tokens:
                            phase, increment = "decode", new.output_tokens - old.output_tokens
                            if new.output_tokens > old.maximum_output_tokens:
                                exclude("output_overhang")
                                excluded += 1
                                continue
                        else:
                            exclude("phase_transition_or_no_headroom")
                            excluded += 1
                            continue
                        if increment < 0:
                            exclude("progress_regressed")
                            excluded += 1
                            continue
                        totals[phase]["increment"] += increment
                        totals[phase]["exposure"] += dt / den
                        totals[phase]["observations"] += 1
                    accepted += 1
                else:
                    exclude("empty_inventory" if not before else
                            "inventory_changed" if set(before) != set(after) else
                            "unknown_waiting_pending_frontend_work" if not complete else
                            "overlap_or_long_gap")
                    excluded += 1
            prior = current
        counts[name] = dict(eligible_intervals=accepted, excluded=excluded, refusal_reasons=reasons)
    rates = {phase + "_rate": (row["increment"] / row["exposure"] if row["exposure"] else None)
             for phase, row in totals.items()}
    return dict(schema="native-v3-persistent-batch-progress-fit-v1", parameters=rates,
                totals=totals, counts=counts, artifact_sha256=hashes,
                scope="Conditional repeated-inventory endpoint progress; transient work unmeasured;"
                      " not EOS, full-offered G5 or causal fit",
                lifecycle_model=None, source_authenticated=False, active_mpc_permit=False)


def evolving_batch_progress(state, offers, applied_budgets, parameters, *, seed,
                            evolving=True):
    """One conservative scenario kernel; existing charges never release on token progress."""
    dt = .5
    if set(state) != {"actors", "kv_cache_usage", "waiting_work_unknown", "unmapped_work"}:
        raise ValueError("Invalid closed prototype state; future labels are not inputs")
    if set(parameters) != {"prefill_rate", "decode_rate"}:
        raise ValueError("Invalid progress parameter schema")
    if state.get("waiting_work_unknown") is not False or state.get("unmapped_work") is not False:
        raise ValueError("Unknown waiting/unmapped work: no qualified population rollout")
    usage = _finite(state["kv_cache_usage"], "KV report")
    if usage > 1:
        raise ValueError("Invalid KV fraction")
    _text(seed, "common scenario seed")
    rates = {phase: _finite(parameters[phase + "_rate"], "reported progress rate")
             for phase in ("prefill", "decode")}
    if not applied_budgets:
        raise ValueError("Missing applied-budget sequence")
    for budget in applied_budgets:
        if _finite(budget, "applied reservation budget") not in (16, 32):
            raise ValueError("Unsupported applied budget; no planned-ACK shortcut")
    actors, seen, offered = {}, set(), []

    def actor(row):
        if type(row) is not dict or set(row) != {
                "request_id", "original_gateway_charge", "prefill_remaining",
                "native_output_tokens", "maximum_output_tokens"}:
            raise ValueError("Invalid closed actor state; no terminal/EOS/header inputs")
        item = copy.deepcopy(row)
        rid = _text(item["request_id"], "opaque scenario ID")
        if rid in seen:
            raise ValueError("Scenario ID reused")
        seen.add(rid)
        if _finite(item["original_gateway_charge"], "original charge") == 0:
            raise ValueError("Unknown/zero original charge is not an offered estimate")
        _integer(item["prefill_remaining"], "reported prefill headroom", 0)
        _integer(item["native_output_tokens"], "reported output", 0)
        _integer(item["maximum_output_tokens"], "reported maximum")
        return item

    for row in state["actors"]:
        item = actor(row)
        actors[item["request_id"]] = item
    for row in offers:
        if type(row) is not dict or set(row) != {"step", "actor"}:
            raise ValueError("Invalid common exogenous offer schema")
        step = _integer(row["step"], "exogenous birth step", 0)
        if step >= len(applied_budgets):
            raise ValueError("Birth after declared rollout")
        offered.append((step, actor(row["actor"])))

    def denominator(population):
        np = sum(p["prefill_remaining"] > 0 for p in population.values())
        return max(1, 2 * np + len(population) - np) * (1 + usage)

    initial_den = denominator(actors)
    path = []
    for step, budget in enumerate(applied_budgets):
        admitted, rejected = [], []
        for at, item in offered:
            if at != step:
                continue
            reserved = math.fsum(p["original_gateway_charge"] for p in actors.values())
            if reserved + item["original_gateway_charge"] <= budget:
                actors[item["request_id"]] = copy.deepcopy(item)
                admitted.append(item["request_id"])
            else:
                rejected.append(item["request_id"])
        den = denominator(actors) if evolving else initial_den
        before = copy.deepcopy(actors)
        for rid in sorted(actors):
            old = before[rid]
            phase = "prefill" if old["prefill_remaining"] > 0 else "decode"
            mean = rates[phase] * dt / den
            whole = math.floor(mean)
            uniform = int(hashlib.sha256(f"{seed}|{rid}|{step}|{phase}".encode()).hexdigest()[:16], 16) / 2 ** 64
            increment = whole + (uniform < mean - whole)
            if phase == "prefill":
                actors[rid]["prefill_remaining"] -= min(old["prefill_remaining"], increment)
            else:
                headroom = max(0, old["maximum_output_tokens"] - old["native_output_tokens"])
                actors[rid]["native_output_tokens"] += min(headroom, increment)
        path.append(dict(at_s=(step + 1) * dt, actors=copy.deepcopy(actors),
                         admitted=admitted, rejected=rejected,
                         reserved=math.fsum(p["original_gateway_charge"] for p in actors.values()),
                         competition_denominator=den))
    return dict(schema="native-v3-evolving-batch-progress-prototype-v1", path=path,
                lifecycle_events=None, gateway_release_events=None, good_predictions=None,
                kv_forecast=None,
                scope="Hypothetical fully mapped reported-progress scenario; constant-cut KV proxy;"
                      " exits/charge release/unknown-work dynamics unfit; not physical EOS or GPU time",
                active_mpc_permit=False)


def batch_progress_input_refusal(model_input):
    """Do not manufacture the engine-owner mapping or latent work required by the prototype."""
    if model_input.get("schema") != OnlineModelInputAdapter.SCHEMA:
        raise ValueError("Unknown online model-input schema")
    return dict(state=None,
                reasons=["pre-outcome_engine_gateway_lineage_unqualified",
                         "waiting_unmapped_snapshot_transient_work_unidentified",
                         "future_payload_original_charge_and_ACK_compliance_unqualified",
                         "lifecycle_release_and_joint_risk_model_unfit"],
                active_mpc_permit=False)


def output_counter_stayer_diagnostic(fit_artifacts, development_artifacts):
    """V2 observation response, not V1 closed-work service; future records are labels only."""
    import bisect
    from pathlib import Path
    from mpc_lab import native_state, runtime

    if hashlib.sha256(Path(native_state.__file__).read_bytes()).hexdigest() != OnlineModelInputAdapter.NATIVE_SOURCE_SHA256:
        raise ValueError("Unbound output-counter parser")
    expected_fit = {f"nv3-{b}-p4096-m128-arm0.events.jsonl" for b in (181001, 181002, 181003)}
    expected_dev = {f"nv3-{b}-p4096-m128-arm0.events.jsonl" for b in range(181004, 181010)}
    if set(fit_artifacts) != expected_fit or set(development_artifacts) != expected_dev:
        raise ValueError("V2 scope requires used Train1..3 fit and4..9 development only")
    horizons = (.5, 1., 3., 5.)
    hashes, parsing = {}, {}

    def states(name, artifact):
        raw, digest = artifact
        if hashlib.sha256(raw).hexdigest() != _sha(digest):
            raise ValueError("Output-counter artifact hash mismatch")
        hashes[name] = digest
        result, reasons, gaps, binding = [], {}, [], None
        for line in raw.splitlines():
            event = json.loads(line)
            if event.get("kind") != "native_frame":
                continue
            frame = event["value"]
            if binding is None:
                snapshot = runtime.snapshot_from_dict(frame["gateway_snapshot"])
                binding = native_state.NativeBinding(
                    frame["clock_domain"], snapshot.run_id, frame["run_id"],
                    "29fc1ebd875ccc1a53b9584fd0f3b002c518e3653c9b4238877b67b7ec13802e",
                    snapshot.identity)
            estimate = native_state.estimate_native_state(frame, binding, now=frame["received_at"])
            if estimate.state is None:
                reasons[estimate.reason] = reasons.get(estimate.reason, 0) + 1
                if estimate.reason in ("clock_domain_mismatch", "native_source_mismatch", "native_identity_mismatch"):
                    parsing[name] = reasons
                    return [], []
                gaps.append(_finite(frame["received_at"], "unqualified native receipt"))
            elif result and estimate.state.received_at <= result[-1].received_at:
                raise ValueError("Counter receipt sequence regressed/reused")
            else:
                result.append(estimate.state)
        parsing[name] = reasons
        return result, gaps

    def phase(p):
        return ("prefill" if p.computed_tokens < p.prompt_tokens else
                "headroom_zero" if p.output_tokens >= p.maximum_output_tokens else "decode")

    def keys(s, p):
        remaining = max(0, p.prompt_tokens - p.computed_tokens)
        key = (phase(p), min(s.running // 8, 4), s.waiting > 0, s.pending_batches > 0,
               min(int(s.kv_cache_usage * 4), 3),
               0 if remaining == 0 else 1 if remaining <= 256 else 2 if remaining <= 1024 else 3)
        return [key, (phase(p),), ()]

    def rows(sequence_and_gaps):
        sequence, gaps = sequence_and_gaps
        times = [s.received_at for s in sequence]
        for index, current in enumerate(sequence):
            for p in current.progress:
                past, past_time = None, None
                for s in reversed(sequence[:index]):
                    if current.received_at - s.received_at > 1.:
                        break
                    q = next((q for q in s.progress if q.engine_request_id == p.engine_request_id), None)
                    if (q is None or (q.prompt_tokens, q.maximum_output_tokens) !=
                            (p.prompt_tokens, p.maximum_output_tokens) or q.output_tokens > p.output_tokens
                            or any(s.received_at < g <= current.received_at for g in gaps)):
                        break
                    past, past_time = q, s.received_at
                slope = ((p.output_tokens - past.output_tokens) / (current.received_at - past_time)
                         if past is not None else None)
                for h in horizons:
                    target_cut = current.received_at + h
                    target_index = bisect.bisect_right(times, target_cut) - 1
                    status, label, future_phase, births = "right_censored", None, None, None
                    if target_cut <= times[-1] and target_index > index:
                        target = sequence[target_index]
                        interval = [{q.engine_request_id: q for q in s.progress}
                                    for s in sequence[index + 1:target_index + 1]]
                        after = {q.engine_request_id: q for q in target.progress}
                        births = len(set(after) - {q.engine_request_id for q in current.progress})
                        q = after.get(p.engine_request_id)
                        if target_cut - target.sampled_at > .5:
                            status = "target_stale"
                        elif any(current.received_at < g <= target_cut for g in gaps):
                            status = "observation_gap_censored"
                        elif q is None:
                            status = "disappeared_censored"
                        elif any(p.engine_request_id not in inventory for inventory in interval):
                            status = "interval_disappearance_censored"
                        elif any((inventory[p.engine_request_id].prompt_tokens,
                                  inventory[p.engine_request_id].maximum_output_tokens) !=
                                 (p.prompt_tokens, p.maximum_output_tokens) for inventory in interval):
                            status = "identity_changed"
                        elif any(b < a for a, b in zip(
                                [p.output_tokens] + [inventory[p.engine_request_id].output_tokens
                                                     for inventory in interval],
                                [inventory[p.engine_request_id].output_tokens for inventory in interval])):
                            status = "counter_regressed"
                        elif q.output_tokens > p.maximum_output_tokens:
                            status = "output_overhang"
                        else:
                            status, label, future_phase = "stayer", q.output_tokens - p.output_tokens, phase(q)
                    yield dict(h=h, cut=current.received_at, engine_request_id=p.engine_request_id,
                               keys=keys(current, p), headroom=max(0, p.maximum_output_tokens - p.output_tokens),
                               status=status, label=label, future_phase=future_phase,
                               future_births=births, past_rate=slope)

    tables, fit_counts = {}, {}
    for name in sorted(expected_fit):
        counts = {}
        for row in rows(states(name, fit_artifacts[name])):
            counts[row["status"]] = counts.get(row["status"], 0) + 1
            if row["status"] != "stayer":
                continue
            for key in row["keys"]:
                entry = tables.setdefault((row["h"], key), [0, 0])
                entry[0] += 1
                entry[1] += row["label"]
        fit_counts[name] = counts

    def predict(row):
        for level, key in enumerate(row["keys"]):
            count, total = tables.get((row["h"], key), (0, 0))
            if count >= 20 or level == 2 and count:
                return min(row["headroom"], total / count), level
        return None, None

    development = {}
    for name in sorted(expected_dev):
        stats = {h: dict(origins=0, statuses={}, comparable=0, model_abs=0., past_abs=0.,
                         phase_abs=0.,
                         past_fallback=0, model_backoff=0, phase_changes=0, birth_context=0,
                         forecast_witness=None, strata={}, forecast_unavailable_origins=0)
                 for h in horizons}
        for row in rows(states(name, development_artifacts[name])):
            stat = stats[row["h"]]
            stat["origins"] += 1
            status = row["status"]
            stat["statuses"][status] = stat["statuses"].get(status, 0) + 1
            mean, level = predict(row)
            stat["forecast_unavailable_origins"] += mean is None
            baseline = (min(row["headroom"], row["past_rate"] * row["h"])
                        if row["past_rate"] is not None else mean)
            if stat["forecast_witness"] is None and row["past_rate"] is not None:
                stat["forecast_witness"] = dict(
                    cut=row["cut"], engine_request_id=row["engine_request_id"],
                    keys=row["keys"], headroom=row["headroom"], model_increment=mean,
                    past_rate=row["past_rate"], past_increment=baseline)
            if status != "stayer" or mean is None:
                continue
            phase_count, phase_total = tables.get((row["h"], row["keys"][1]), (0, 0))
            phase_mean = min(row["headroom"], phase_total / phase_count) if phase_count else mean
            stat["comparable"] += 1
            stat["past_fallback"] += row["past_rate"] is None
            stat["model_backoff"] += level > 0
            stat["model_abs"] += abs(mean - row["label"]) / row["h"]
            stat["past_abs"] += abs(baseline - row["label"]) / row["h"]
            stat["phase_abs"] += abs(phase_mean - row["label"]) / row["h"]
            stat["phase_changes"] += row["future_phase"] != row["keys"][0][0]
            stat["birth_context"] += bool(row["future_births"])
            for stratum in (
                    "changed_reported_phase" if row["future_phase"] != row["keys"][0][0]
                    else "same_reported_phase",
                    "new_inventory_ids" if row["future_births"] else "no_new_inventory_ids",
                    "past_rate_fallback" if row["past_rate"] is None else "past_rate_available"):
                group = stat["strata"].setdefault(stratum, dict(count=0, model_abs=0., past_abs=0.))
                group["count"] += 1
                group["model_abs"] += abs(mean - row["label"]) / row["h"]
                group["past_abs"] += abs(baseline - row["label"]) / row["h"]
        for stat in stats.values():
            count = stat["comparable"]
            stat["model_mae_rate"] = stat.pop("model_abs") / count if count else None
            stat["past_mae_rate"] = stat.pop("past_abs") / count if count else None
            stat["phase_mae_rate"] = stat.pop("phase_abs") / count if count else None
            stat["availability"] = count / stat["origins"] if stat["origins"] else None
            for group in stat["strata"].values():
                group["model_mae_rate"] = group.pop("model_abs") / group["count"]
                group["past_mae_rate"] = group.pop("past_abs") / group["count"]
        development[name] = stats
    return dict(schema="native-v3-output-counter-stayer-observation-v2",
                horizons=list(horizons), fit_table_cells=len(tables),
                fit_labels=sum(v[0] for (h, key), v in tables.items() if key == ()),
                fit_support_by_horizon={h: tables.get((h, ()), (0, 0))[0] for h in horizons},
                fit_counts=fit_counts,
                fit_table_sha256=_digest(sorted(
                    [(h, key, count, total) for (h, key), (count, total) in tables.items()],
                    key=repr)),
                parser_source_sha256=OnlineModelInputAdapter.NATIVE_SOURCE_SHA256,
                development=development, artifact_sha256=hashes, parser_refusals=parsing,
                scope="Conditional output-counter stayer observations, unknown work retained;"
                      " native inventory appearance/disappearance/phase are future labels, not forecast inputs."
                      " No GPU kernel clock/scheduled batch tokens/service/Good/cap effects",
                native_gateway_lineage_verified=False, source_authenticated=False,
                global_complete=False, physical_eos_permit=False, joint_dynamics_fit=False,
                lifecycle_model=None,
                active_mpc_permit=False)


def _configuration(value):
    if not isinstance(value, dict):
        raise ValueError("Missing actual comparison configuration")
    revision = value.get("model_revision")
    if not isinstance(revision, str) or not re.fullmatch("[0-9a-f]{40}", revision):
        raise ValueError("Missing pinned actual model revision")
    for key in ("deployment_id", "boot_id", "gpu_uuid", "driver_version",
                "vllm_version", "torch_version", "transformers_version", "dtype"):
        _text(value.get(key), key)
    for key in ("native_source_sha256", "gateway_source_sha256",
                "core_sha256", "cost_model_sha256", "scheduler_config_sha256"):
        _sha(value.get(key))
    if value.get("observer_mode") not in ("disabled", "off", "light"):
        raise ValueError("Missing actual observer mode")
    return json.loads(json.dumps(value, sort_keys=True, allow_nan=False))


def _number_identity(value, name):
    number = Fraction(_finite(value, name))
    return [number.numerator, number.denominator]


def comparison_digest(*, configuration, left_policy_sha256, right_policy_sha256,
                      window_s, ttft_s=0.5, tpot_s=0.05):
    """Freeze semantic settings before outcomes, not just an opaque receipt label.

    Configuration/policy fields must come from source-bound actual run receipts.
    Computing this digest does not authenticate those receipts or their timing.
    """
    if _finite(window_s, "window") == 0:
        raise ValueError("Window must be positive")
    return _digest(dict(
        schema="native-v3-sol-comparison-v1", configuration=_configuration(configuration),
        left_policy_sha256=_sha(left_policy_sha256),
        right_policy_sha256=_sha(right_policy_sha256),
        window_s=_number_identity(window_s, "window"),
        ttft_s=_number_identity(ttft_s, "TTFT SLO"),
        tpot_s=_number_identity(tpot_s, "TPOT SLO"),
        outcome="natural-complete-scheduled-ttft-terminal-tpot-v1",
        weighting="equal-fresh-workload-block-good-per-offered-window",
    ))


def audit_arm(offers, rows, *, origin, window_s, clock_domain,
              configuration, policy_sha256, ttft_s=0.5, tpot_s=0.05):
    """Score a fixed offered cohort, including drain; unresolved rows stay intervals.

    Offers add logical_id, offset_s, prompt_sha256 and prompt_tokens to the
    physical request_id/max_tokens manifest. Rows use capture_chat field names;
    natural stops additionally require an independently joined EOS receipt.
    Censor absence tightens bounds only with client_prefix_complete=True.
    Configuration contains stable runtime/source settings, not process run IDs.
    """
    _finite(origin, "origin")
    if _finite(window_s, "window") == 0:
        raise ValueError("Window must be positive")
    _text(clock_domain, "clock domain")
    _finite(ttft_s, "TTFT SLO")
    _finite(tpot_s, "TPOT SLO")
    configuration = _configuration(configuration)
    policy_sha256 = _sha(policy_sha256)
    manifest, logical, tape, semantic_tape = {}, set(), [], []
    last_offset = -1
    for offer in offers:
        rid = _uuid(offer["request_id"])
        lid = _text(offer["logical_id"], "logical ID")
        if rid in manifest or lid in logical:
            raise ValueError("Duplicate offered physical/logical UUID")
        offset = _finite(offer["offset_s"], "offered offset")
        if offset >= window_s:
            raise ValueError("Offer outside frozen window")
        if offset < last_offset:
            raise ValueError("Frozen offer list is not in scheduled order")
        last_offset = offset
        prompt = _integer(offer["prompt_tokens"], "prompt tokens")
        limit = _integer(offer["max_tokens"], "output limit")
        recipe = _sha(offer["prompt_sha256"])
        manifest[rid] = offer
        logical.add(lid)
        offset_identity = _number_identity(offset, "offered offset")
        tape.append((lid, offset_identity, prompt, limit, recipe))
        semantic_tape.append((offset_identity, prompt, limit, recipe))
    if not manifest:
        raise ValueError("Empty offered cohort")
    outcomes, seen = [], set()
    for row in rows:
        rid = _uuid(row["request_id"])
        if rid in seen or rid not in manifest:
            raise ValueError("Duplicate/unoffered physical UUID")
        seen.add(rid)
        offer = manifest[rid]
        if (_integer(row.get("requested_max_tokens"), "captured output limit")
                != offer["max_tokens"]):
            raise ValueError("Captured output limit differs from frozen offer")
        if row.get("clock_domain") != clock_domain:
            raise ValueError("Outcome clock differs")
        scheduled = _finite(row.get("scheduled_at"), "scheduled origin")
        if scheduled != origin + offer["offset_s"]:
            raise ValueError("Row origin differs from frozen offered tape")
        status = row.get("status")
        if status not in ("complete", "rejected", "failed", "cancelled", "timeout", "censored"):
            raise ValueError("Unknown outcome status")
        sent = row.get("sent_at")
        if sent is not None:
            if _finite(sent, "send") < scheduled:
                raise ValueError("Send precedes offer")
        elif status != "censored":
            raise ValueError("Resolved outcome lacks send")
        first, last = row.get("first_content_at"), row.get("last_content_at")
        if (first is None) != (last is None):
            raise ValueError("Partial first/last chronology")
        if first is not None:
            if sent is None or not sent <= _finite(first, "first") <= _finite(last, "last"):
                raise ValueError("Invalid content chronology")
        if status == "censored":
            if row.get("terminal_at") is not None or row.get("stream_done") is not False:
                raise ValueError("Censored row claims termination")
            until = _finite(row.get("observed_until"), "censor cutoff")
            if until < max(scheduled, sent or scheduled, last or scheduled):
                raise ValueError("Censor cutoff precedes observed events")
            prefix_complete = row.get("client_prefix_complete", False)
            if type(prefix_complete) is not bool:
                raise ValueError("Invalid client prefix completeness")
        else:
            terminal = _finite(row.get("terminal_at"), "terminal")
            if terminal < (last if last is not None else sent):
                raise ValueError("Terminal precedes observed events")
        usage = row.get("usage")
        count = None
        if usage is not None:
            if not isinstance(usage, dict):
                raise ValueError("Malformed usage")
            prompt = _integer(usage.get("prompt_tokens"), "native prompt")
            count = _integer(usage.get("completion_tokens"), "output tokens", 0)
            if prompt != offer["prompt_tokens"] or count > offer["max_tokens"]:
                raise ValueError("Usage differs from offered token constraints")
        lower, upper, label, ttft, tpot = 0, 0, status, None, None
        if status == "complete":
            _integer(count, "successful output tokens")
            if (first is None or row.get("stream_done") is not True
                    or row.get("stream_error") is not False
                    or type(row.get("http_status")) is not int or row["http_status"] != 200
                    or row.get("response_request_id") != rid):
                raise ValueError("Incomplete/mismatched successful Chat")
            reason = row.get("finish_reason")
            if reason == "stop":
                if row.get("native_eos_verified") is not True:
                    raise ValueError("Stop without independent native EOS join")
                label = "natural"
            elif reason == "length":
                if count != offer["max_tokens"]:
                    raise ValueError("Length finish below requested output limit")
                label = "truncated"
            else:
                raise ValueError("Unqualified completion reason")
            ttft = first - scheduled
            tpot = 0.0 if count == 1 else (terminal - first) / (count - 1)
            lower = upper = int(label == "natural" and ttft <= ttft_s and tpot <= tpot_s)
        elif status == "rejected":
            if (row.get("admission_rejection") is not True
                    or row.get("http_status") != 503
                    or row.get("response_request_id") != rid
                    or first is not None or count not in (None, 0)):
                raise ValueError("Unqualified admission rejection")
        elif status == "censored":
            upper = int(first is None or first - scheduled <= ttft_s)
            if (first is None and prefix_complete
                    and until - scheduled > ttft_s):
                upper = 0
        outcomes.append(dict(request_id=rid, logical_id=offer["logical_id"],
                             label=label, good_lower=lower, good_upper=upper,
                             ttft_s=ttft, request_mean_tpot_s=tpot))
    if seen != set(manifest):
        raise ValueError("Missing full-offered outcome rows; do not drop or fill them")
    return dict(offered=len(manifest), window_s=window_s, outcomes=outcomes,
                good_lower=sum(r["good_lower"] for r in outcomes),
                good_upper=sum(r["good_upper"] for r in outcomes),
                tape_sha256=_digest(sorted(tape)),
                semantic_tape_sha256=_digest(dict(
                    schema="ordered-offered-composition-v1", offers=semantic_tape)),
                physical_uuids=sorted(seen), configuration=configuration,
                policy_sha256=policy_sha256,
                slo=dict(ttft_s=ttft_s, tpot_s=tpot_s),
                scope="Natural complete-good per offered cohort, including drain;"
                      " not accepted-only throughput or steady-state capacity")


def _train_snapshot(frame, gateway_run, reference=None):
    gateway = frame["gateway_snapshot"]
    domain = _text(frame["clock_domain"], "native clock")
    identity = gateway["identity"]
    source = (domain, _uuid(frame["run_id"]), _sha(frame["observer_sha256"]), identity)
    if (frame.get("schema") != "pr33-native-read-only-v1"
            or frame.get("complete") is not True or frame.get("available") is not True
            or gateway.get("schema") != "mpc-admission-v1"
            or gateway.get("complete") is not True
            or gateway.get("run_id") != gateway_run or gateway.get("clock_domain") != domain
            or reference is not None and source != reference):
        raise ValueError("Train snapshot source/epoch/clock/completeness mismatch")
    for key in ("cost_hash", "implementation_hash", "support_hash"):
        _sha(identity.get(key))
    for key in ("model_version", "calibration_version"):
        _text(identity.get(key), key)
    sampled = _finite(gateway["sampled_at"], "Gateway sample")
    received = _finite(frame["received_at"], "native receipt")
    native_sample = _finite(frame["sampled_at"], "native sample")
    frontend = _finite(frame["frontend_sampled_at"], "native frontend sample")
    gateway_received = _finite(frame["gateway_received_at"], "Gateway receipt")
    if not (sampled <= gateway_received <= received
            and native_sample <= frontend <= received
            and frontend - native_sample <= .05):
        raise ValueError("Train snapshot receipt chronology/skew")
    spec = gateway["cost_spec"]
    if _digest({"formula": "max-min-affine-v1", **spec}) != identity["cost_hash"]:
        raise ValueError("Train snapshot cost specification hash mismatch")
    for key in ("intercept", "input_per_token", "output_per_token", "minimum"):
        _finite(spec[key], key)
    if spec["minimum"] == 0:
        raise ValueError("Invalid cost minimum")
    marks = {}
    for mark in gateway["requests"]:
        rid = _uuid(mark["request_id"])
        if rid in marks:
            raise ValueError("Duplicate Gateway cost owner")
        prompt = _integer(mark["prompt_tokens"], "charged prompt", 0)
        limit = _integer(mark["max_tokens"], "charged output limit")
        cost = _finite(mark["cost"], "original charge")
        expected = max(spec["minimum"], spec["intercept"] + spec["input_per_token"] * prompt
                       + spec["output_per_token"] * limit)
        if cost == 0 or not math.isclose(cost, expected, rel_tol=1e-12, abs_tol=0):
            raise ValueError("Train original charge differs from CostSpec")
        admitted = _finite(mark["admitted_at"], "admission")
        ingress = _finite(mark["received_at"], "Gateway ingress")
        first = mark.get("first_at")
        if not ingress <= admitted <= sampled or (
                first is not None and not admitted <= _finite(first, "Gateway first") <= sampled):
            raise ValueError("Train mark chronology")
        if mark.get("scheduled_at") is not None:
            raise ValueError("Unexpected client scheduling field in current Train Gateway schema")
        marks[rid] = dict(request_id=rid, cost=cost, prompt_tokens=prompt,
                          max_tokens=limit, received_at=ingress, admitted_at=admitted,
                          first_at=first, scheduled_at=None)
    visible = {}
    for request in frame["requests"]:
        match = re.fullmatch(r"chatcmpl-([0-9a-f]{32})-[0-9a-f]{8}", request["request_id"])
        if not match or match[1] not in marks or match[1] in visible:
            raise ValueError("Unjoined/ambiguous native UUID")
        rid = match[1]
        prompt = _integer(request["prompt_tokens"], "native prompt", 0)
        output = _integer(request["output_tokens"], "native output", 0)
        computed = _integer(request["computed_tokens"], "scheduler computed tokens", 0)
        if (type(request["maximum_output_tokens"]) is not int
                or request["maximum_output_tokens"] != marks[rid]["max_tokens"]
                or output > marks[rid]["max_tokens"]):
            raise ValueError("Native token constraints")
        visible[rid] = dict(request_id=rid, prompt_tokens=prompt, output_tokens=output,
                            computed_tokens=computed)
    counts = {key: _integer(frame[key], key, 0)
              for key in ("running", "waiting", "pending_batches")}
    usage = _finite(frame["kv_cache_usage"], "KV usage")
    if counts["running"] != len(visible) or usage > 1:
        raise ValueError("Native running/KV mismatch")
    budget = _finite(gateway["budget"], "applied cap")
    if budget not in (16, 32):
        raise ValueError("Unsupported observed cap")
    return dict(source=source, sampled_at=sampled, native_sampled_at=native_sample,
                received_at=received, marks=marks, visible=visible, counts=counts,
                kv_usage=usage, budget=budget,
                budget_version=_integer(gateway["budget_version"], "cap version", 0),
                sequence=_integer(gateway["sequence"], "ledger sequence", 0))


def train_schema_audit(episode_bytes, *, expected_sha256, cut_at, horizon_s=1.0):
    """Byte-bound Train capability audit, not a qualified model or EOS adapter.

    Only receipt-qualified snapshots enter observations. Final client rows and
    later snapshots remain offline labels. Hashes attest bytes, not authenticity,
    online publication, statistical independence or same-state causal support.
    """
    if type(episode_bytes) is not bytes or hashlib.sha256(episode_bytes).hexdigest() != _sha(expected_sha256):
        raise ValueError("Train artifact digest mismatch")
    episode = json.loads(episode_bytes)
    seed = _integer(episode["seed_block"], "Train seed")
    if episode.get("split") != "train" or not 181001 <= seed <= 181016:
        raise ValueError("Only Train181001..181016 is eligible")
    if not _text(episode["episode_id"], "episode ID").startswith(f"nv3-{seed}-"):
        raise ValueError("Train episode/seed mismatch")
    start = _finite(episode["start"], "episode start")
    window = _finite(episode["duration_s"], "offered window")
    cut = _finite(cut_at, "prospective receipt cut")
    horizon = _finite(horizon_s, "short-step horizon")
    end = _finite(start + window, "offered endpoint")
    target = _finite(cut + horizon, "label target")
    if not start <= cut < end or not 0 < horizon <= 3 or target <= cut:
        raise ValueError("Cut/window or bounded short-step horizon")
    gateway_run = _uuid(episode["gateway_run_id"])
    prefix = sorted((f for f in episode["native_frames"]
                     if _finite(f["received_at"], "frame receipt") <= cut),
                    key=lambda f: f["received_at"])
    if not prefix:
        raise ValueError("No received Train snapshot before cut")
    reference, ownership, retired, previous = None, {}, set(), None

    def check(frame):
        nonlocal reference, previous
        snapshot = _train_snapshot(frame, gateway_run, reference)
        reference = reference or snapshot["source"]
        if previous is not None:
            if (snapshot["sampled_at"] < previous["sampled_at"]
                    or snapshot["sequence"] < previous["sequence"]
                    or snapshot["budget_version"] < previous["budget_version"]):
                raise ValueError("Snapshot/ledger chronology regression")
            retired.update(set(previous["marks"]) - set(snapshot["marks"]))
        for rid, mark in snapshot["marks"].items():
            original = tuple(mark[key] for key in (
                "cost", "prompt_tokens", "max_tokens", "received_at", "admitted_at"))
            if rid in retired or rid in ownership and ownership[rid] != original:
                raise ValueError("Reused UUID or changed original whole-cost ownership")
            ownership[rid] = original
        previous = snapshot
        return snapshot

    current = None
    for frame in prefix:
        current = check(frame)
    if (cut - current["sampled_at"] > .5
            or cut - current["native_sampled_at"] > .5):
        raise ValueError("Latest received Train observation is stale")
    marks, visible = current["marks"], current["visible"]
    observations = dict(
        cut_at=cut, gateway_sampled_at=current["sampled_at"],
        native_sampled_at=current["native_sampled_at"], received_at=current["received_at"],
        gateway_run_id=gateway_run, native_run_id=reference[1],
        clock_domain=reference[0], observer_sha256=reference[2],
        gateway_identity=reference[3], applied_cap=current["budget"],
        cap_version=current["budget_version"],
        admitted_marks=[marks[rid] for rid in sorted(marks)],
        native_visible=[visible[rid] for rid in sorted(visible)],
        admitted_snapshot_count=len(marks),
        reserved_cost=math.fsum(m["cost"] for m in marks.values()),
        accepted_not_native_visible=sorted(set(marks) - set(visible)),
        native_counts=current["counts"], kv_usage=current["kv_usage"],
        all_offered_client_history=None,
        full_assigned_sequence_online=None,
    )
    observations["applied_ack_receipts"] = []
    attempts = list(episode["preassignment"])
    for action in episode["actions"]:
        attempts.extend(action["attempts"])
    for attempt in attempts:
        receipt = _finite(attempt["received_at"], "ACK receipt")
        if receipt > cut or attempt["reply"].get("status") != "applied":
            continue
        ack = attempt["reply"]["acknowledgment"]
        command = attempt["reply"]["command"]
        applied = _finite(ack["applied_at"], "actual application")
        if (applied > receipt or ack["clock_domain"] != reference[0]
                or ack["run_id"] != gateway_run or ack.get("status") != "applied"
                or command["identity"] != reference[3]
                or command["run_id"] != gateway_run or command["clock_domain"] != reference[0]
                or command["operation_id"] != ack["operation_id"]
                or command["budget"] != ack["budget"] or ack["budget"] not in (16, 32)
                or ack["budget_version"] != _integer(command["expected_version"], "CAS version", 0) + 1
                or applied > _finite(command["not_after"], "command expiry")):
            raise ValueError("Received command/ACK identity/CAS/expiry/chronology")
        observations["applied_ack_receipts"].append(dict(
            applied_at=applied, received_at=receipt,
            budget=_finite(ack["budget"], "ACK cap"),
            budget_version=_integer(ack["budget_version"], "ACK version", 0),
            operation_id=_uuid(ack["operation_id"])))
    observations["applied_ack_receipts"].sort(key=lambda a: a["received_at"])
    observations["received_ack_conflicts_with_snapshot"] = any(
        a["budget_version"] > current["budget_version"]
        or a["budget_version"] == current["budget_version"] and a["budget"] != current["budget"]
        for a in observations["applied_ack_receipts"])

    labels = dict(target_at=target, cohort_anchor_at=current["sampled_at"],
                  declared_full_assigned_sequence=episode["schedule"],
                  scope="Sampled Gateway cohort disappearance, not physical EOS;"
                        " may include release between sample and decision receipt.")
    last_seen = {rid: current["sampled_at"] for rid in marks}
    disappeared = {}
    try:
        future = sorted((f for f in episode["native_frames"] if f["received_at"] > cut),
                        key=lambda f: f["received_at"])
        for frame in future:
            snapshot = check(frame)
            for rid in marks:
                if rid in snapshot["marks"]:
                    last_seen[rid] = snapshot["sampled_at"]
                elif rid not in disappeared:
                    disappeared[rid] = snapshot["sampled_at"]
        bounds = []
        for rid, mark in marks.items():
            gone = disappeared.get(rid)
            lower = int(gone is not None and gone <= target)
            upper = int(last_seen[rid] < target)
            bounds.append(dict(request_id=rid, original_cost=mark["cost"],
                               last_seen_sampled_at=last_seen[rid],
                               first_absent_sampled_at=gone,
                               released_count_bounds=[lower, upper]))
        labels.update(cohort_disappearance=bounds,
                      released_cost_bounds=[math.fsum(b["original_cost"] * b["released_count_bounds"][i]
                                                      for b in bounds) for i in (0, 1)])
    except (ValueError, KeyError, TypeError) as exc:
        labels["disappearance_withheld"] = str(exc)
    try:
        ids, offsets, rows = episode["expected_ids"], episode["offered_tape"], episode["rows"]
        if len(ids) != len(offsets) or not ids or len(set(ids)) != len(ids):
            raise ValueError("Invalid all-offered manifest")
        planned = {}
        for rid, offset in zip(ids, offsets):
            rid = _uuid(rid)
            if not 0 <= _finite(offset, "offered offset") < window:
                raise ValueError("Offer outside window")
            planned[rid] = start + offset
        seen, statuses, api_stops, client_first_by_cut = set(), {}, 0, 0
        for row in rows:
            rid = _uuid(row["request_id"])
            if rid in seen or rid not in planned or row["scheduled_at"] != planned[rid]:
                raise ValueError("Missing/duplicate/unoffered or mismatched scheduled row")
            seen.add(rid)
            status = _text(row["status"], "client status")
            if status not in ("complete", "rejected", "failed", "cancelled", "timeout", "censored"):
                raise ValueError("Unknown client outcome label")
            statuses[status] = statuses.get(status, 0) + 1
            api_stops += int(status == "complete" and row.get("finish_reason") == "stop")
            first = row.get("first_content_at")
            client_first_by_cut += int(first is not None and _finite(first, "client first label") <= cut)
        if seen != set(planned):
            raise ValueError("Missing full-offered client outcome; no row dropping/imputation")
        labels.update(offered=len(ids), outcome_status_counts=statuses,
                      api_stop_labels=api_stops,
                      offline_planned_offers_by_cut=sum(t <= cut for t in planned.values()),
                      offline_client_first_by_cut=client_first_by_cut,
                      independent_physical_eos_receipts=None,
                      full_offered_rows_reconciled=True,
                      client_wire_outcomes_qualified=False)
    except (ValueError, KeyError, TypeError) as exc:
        labels["client_labels_withheld"] = str(exc)
    return dict(artifact_sha256=expected_sha256, train_seed_block=seed,
                observations=observations, offline_labels=labels,
                authority=dict(collector_source_authenticated=False,
                               online_all_offered_history_verified=False,
                               independent_native_eos_verified=False,
                               joint_physical_state_complete=False,
                               independent_sampling_verified=False,
                               same_state_causal_effect_qualified=False,
                               native_comparison_accepted=False))


def _api_good_candidate(row, domain):
    if row["clock_domain"] != domain:
        raise ValueError("Client label clock differs from receipt observation")
    if row["status"] == "censored":
        raise ValueError("Unresolved full-offered client label; no point partition")
    if row["status"] != "complete":
        return False
    rid = _uuid(row["request_id"])
    times = [_finite(row[key], key) for key in (
        "scheduled_at", "sent_at", "first_content_at", "last_content_at", "terminal_at")]
    if times != sorted(times):
        raise ValueError("API candidate client chronology")
    output = _integer(row["usage"]["completion_tokens"], "API completion tokens")
    _integer(row["usage"]["prompt_tokens"], "API prompt tokens")
    limit = _integer(row["requested_max_tokens"], "API output limit")
    if (output > limit or row["response_request_id"] != rid
            or row["stream_done"] is not True or row["stream_error"] is not False
            or type(row["http_status"]) is not int or row["http_status"] != 200):
        raise ValueError("Unqualified API completion label")
    reason = row["finish_reason"]
    if reason not in ("stop", "length") or reason == "length" and output != limit:
        raise ValueError("Unqualified API completion reason")
    mean_tpot = 0 if output == 1 else (times[4] - times[2]) / (output - 1)
    return reason == "stop" and times[2] - times[0] <= .5 and mean_tpot <= .05


def future_api_good_partition(episode_bytes, *, expected_sha256, cut_at):
    """Offline 1/3/5s attribution diagnostic, not a fitted/physical-native kernel.

    Snapshot-cohort completions, unobserved past offers and post-cut intended
    births are distinct. Future rows are labels only; raw receipt-visible token
    progress is preserved, not interpreted as exclusive executed GPU service.
    """
    audit = train_schema_audit(episode_bytes, expected_sha256=expected_sha256,
                               cut_at=cut_at)
    episode = json.loads(episode_bytes)
    observations = copy.deepcopy(audit["observations"])
    frame = sorted((f for f in episode["native_frames"] if f["received_at"] <= cut_at),
                   key=lambda f: f["received_at"])[-1]
    observations["raw_native_progress"] = [
        {key: request[key] for key in (
            "request_id", "computed_tokens", "output_tokens",
            "prompt_tokens", "maximum_output_tokens")}
        for request in frame["requests"]]
    result = dict(
        artifact_sha256=expected_sha256, train_seed_block=episode["seed_block"],
        observations=observations, future_api_good=None,
        physical_natural_good=None, native_performance_accepted=False,
        active_mpc_permit=False, collector_source_authenticated=False,
        online_all_offered_history_verified=False,
        offline_full_offered_outcomes=audit["offline_labels"].get("outcome_status_counts"),
        scope="Offline resolved API-stop/SLO candidate labels, not physical EOS;"
              " no forecast fit, causal effect, independent block or active permit.")
    if "client_labels_withheld" in audit["offline_labels"]:
        result["labels_withheld"] = audit["offline_labels"]["client_labels_withheld"]
        return result
    marked = {m["request_id"] for m in observations["admitted_marks"]}
    visible = {r["request_id"] for r in observations["native_visible"]}
    groups = ("cohort_native_visible", "cohort_native_unknown",
              "past_offer_outside_snapshot", "post_cut_offered_birth")
    partitions = {h: {group: 0 for group in groups} for h in (1, 3, 5)}
    try:
        if not marked <= set(episode["expected_ids"]):
            raise ValueError("Snapshot owner outside the all-offered episode")
        for row in episode["rows"]:
            rid = row["request_id"]
            if row["scheduled_at"] > cut_at:
                if rid in marked:
                    raise ValueError("Post-cut offered birth already marked before cut")
                group = "post_cut_offered_birth"
            elif rid in marked:
                group = "cohort_native_visible" if rid in visible else "cohort_native_unknown"
            else:
                group = "past_offer_outside_snapshot"
            if not _api_good_candidate(row, observations["clock_domain"]):
                continue
            for horizon in partitions:
                endpoint = _finite(cut_at + horizon, "partition target")
                if not endpoint > cut_at:
                    raise ValueError("Unrepresentable partition horizon")
                if cut_at < row["terminal_at"] <= endpoint:
                    partitions[horizon][group] += 1
        result["future_api_good"] = {
            horizon: dict(**counts, total=sum(counts.values()),
                          post_cut_birth_fraction=(
                              counts["post_cut_offered_birth"] / sum(counts.values())
                              if sum(counts.values()) else None))
            for horizon, counts in partitions.items()}
    except (ValueError, KeyError, TypeError) as exc:
        result["labels_withheld"] = str(exc)
    return result


def cap_plan_support_audit(declared_law, candidates):
    """Exact marginal prefix support for a DECLARED five-slot assignment law.

    Positive integer weights are randomizer weights, not observed path counts.
    This neither authenticates that randomizer nor verifies history-conditional
    positivity, actual ACK compliance, endpoint observability or policy coverage.
    """
    def plan(value):
        if (type(value) is not tuple or len(value) != 5
                or any(type(cap) is not int or cap not in (16, 32) for cap in value)):
            raise ValueError("Five integer 16/32 assignment slots required")
        return value

    if not isinstance(declared_law, dict) or not declared_law:
        raise ValueError("Nonempty declared assignment law required")
    law = {plan(p): _integer(weight, "randomizer weight")
           for p, weight in declared_law.items()}
    if type(candidates) is not tuple or not candidates:
        raise ValueError("Nonempty candidate tuple required")
    required = tuple(plan(p) for p in candidates)
    if len(set(required)) != len(required):
        raise ValueError("Duplicate candidate plan")
    total = sum(law.values())
    horizons = {}
    for horizon in (1, 3, 5):
        prefix_mass = {}
        for p, weight in law.items():
            prefix_mass[p[:horizon]] = prefix_mass.get(p[:horizon], 0) + weight
        rows = []
        for p in required:
            probability = Fraction(prefix_mass.get(p[:horizon], 0), total)
            rows.append(dict(plan=p, prefix=p[:horizon],
                             declared_prefix_probability=[
                                 probability.numerator, probability.denominator],
                             declared_prefix_supported=probability > 0))
        horizons[horizon] = dict(
            supported_prefixes=len(prefix_mass), possible_prefixes=2 ** horizon,
            candidates=rows)
    return dict(
        slot_seconds=1, horizons=horizons,
        slot_convention="Assigned budgets for [cut+j, cut+j+1), j=0..4; ACK timing absent",
        scope="Declared marginal assignment support, not a causal or sampling certificate",
        randomizer_source_authenticated=False, conditional_history_support_verified=False,
        sequential_randomization_verified=False, actual_ack_compliance_verified=False,
        selected_policy_coverage_verified=False, active_mpc_permit=False)


def paired_effect(blocks, *, bootstrap_samples=4000, random_seed=0):
    """Audit raw paired independent blocks before estimating right-minus-left.

    Each block supplies seed, block_id, randomization_unit, independent_sampling,
    pair_order_randomized, pair_order, randomization_scheme,
    partition, frozen_comparison_sha256 (computed with comparison_digest) and
    left/right arguments to audit_arm. Design declarations are not verified facts.
    """
    _integer(bootstrap_samples, "bootstrap draws")
    _integer(random_seed, "bootstrap seed", 0)
    if bootstrap_samples > 100000:
        raise ValueError("Bootstrap exceeds offline bounded audit")
    if not 2 <= len(blocks) <= 16:
        raise ValueError("Require 2..16 independent blocks for bounded exact enumeration")
    seeds, ids, units, tapes, physical = set(), set(), set(), set(), set()
    effects, exact_effects, intervals = [], [], []
    unresolved, comparison, partition = False, None, None
    for block in blocks:
        seed = _integer(block["seed"], "workload seed", 0)
        if 160021 <= seed <= 160024:
            raise ValueError("Reserved old final heldout remains unused")
        split = block.get("partition")
        if split not in ("train", "calibration", "development", "final"):
            raise ValueError("Missing/unknown block partition")
        partition = partition or split
        if split != partition:
            raise ValueError("Mixed block partitions; no train/calibration/final pooling")
        bid = _text(block["block_id"], "block ID")
        unit = _text(block["randomization_unit"], "randomization unit")
        if block.get("independent_sampling") is not True:
            raise ValueError("Independent block sampling not declared")
        if (block.get("pair_order_randomized") is not True
                or block.get("pair_order") not in ("left-first", "right-first")
                or block.get("randomization_scheme") != "independent-fair-pair-order"):
            raise ValueError("Exchangeable randomized pair order not declared")
        frozen = _sha(block.get("frozen_comparison_sha256"))
        comparison = comparison or frozen
        if frozen != comparison:
            raise ValueError("Frozen policy/comparison configuration changed")
        if seed in seeds or bid in ids or unit in units:
            raise ValueError("Repeated independent block identity")
        seeds.add(seed)
        ids.add(bid)
        units.add(unit)
        left, right = audit_arm(**block["left"]), audit_arm(**block["right"])
        if (left["tape_sha256"] != right["tape_sha256"]
                or left["semantic_tape_sha256"] != right["semantic_tape_sha256"]
                or left["window_s"] != right["window_s"] or left["slo"] != right["slo"]
                or left["configuration"] != right["configuration"]):
            raise ValueError("Pair differs in offered tape/window/SLO/configuration")
        actual = comparison_digest(
            configuration=left["configuration"], left_policy_sha256=left["policy_sha256"],
            right_policy_sha256=right["policy_sha256"], window_s=left["window_s"],
            **left["slo"])
        if actual != frozen:
            raise ValueError("Actual SLO/configuration/policies differ from frozen comparison")
        if left["semantic_tape_sha256"] in tapes:
            raise ValueError("Repeated offered tape is outside this unique-tape block protocol")
        tapes.add(left["semantic_tape_sha256"])
        for arm in (left, right):
            uuids = set(arm["physical_uuids"])
            if physical & uuids:
                raise ValueError("Physical UUID reused across arms/blocks")
            physical.update(uuids)
            unresolved |= any(r["label"] == "censored" for r in arm["outcomes"])
        duration = left["window_s"]
        lo = (right["good_lower"] - left["good_upper"]) / duration
        hi = (right["good_upper"] - left["good_lower"]) / duration
        _finite(abs(lo), "block effect lower magnitude")
        _finite(abs(hi), "block effect upper magnitude")
        intervals.append((lo, hi))
        effects.append(lo)
        exact_effects.append(Fraction(right["good_lower"] - left["good_lower"])
                             / Fraction(duration))
    result = dict(blocks=len(blocks), frozen_comparison_sha256=comparison,
                  partition=partition,
                  effect_bounds_good_per_s=[
        statistics.mean(lo for lo, _ in intervals),
        statistics.mean(hi for _, hi in intervals)],
        effect_good_per_s=None, percentile_bootstrap_ci95=None,
        exact_two_sided_signflip_p=None, independent_sampling_verified=False,
        native_performance_accepted=False,
        inference_scope="Equal-weight independent paired blocks; sharp no-effect"
                        " randomization null requires independent fair pair-order swaps"
                        " and no carryover/order-by-policy effect."
                        " Bootstrap percentile interval is approximate, not a guarantee;"
                        " neither non-significance nor this report establishes equivalence.")
    if unresolved:
        result["inference_withheld"] = "Unresolved full-offered outcomes"
        return result
    effect = statistics.mean(effects)
    # Enumerate block label swaps, never request/step/within-block replicates.
    observed_sum = abs(sum(exact_effects))
    extreme = sum(abs(sum(s * d for s, d in zip(signs, exact_effects)))
                  >= observed_sum
                  for signs in itertools.product((-1, 1), repeat=len(effects)))
    rng = random.Random(random_seed)
    draws = sorted(statistics.mean(rng.choices(effects, k=len(effects)))
                   for _ in range(bootstrap_samples))

    def quantile(p):
        index = (len(draws) - 1) * p
        low = math.floor(index)
        high = math.ceil(index)
        weight = index - low
        return (1 - weight) * draws[low] + weight * draws[high]

    result.update(effect_good_per_s=effect,
                  block_effects_good_per_s=effects,
                  percentile_bootstrap_ci95=[quantile(.025), quantile(.975)],
                  exact_two_sided_signflip_p=extreme / (2 ** len(effects)),
                  bootstrap_samples=bootstrap_samples, bootstrap_seed=random_seed)
    return result


def work_accounting(*, prompt_tokens, output_tokens, steps, eos_at, clock_domain):
    """New descriptive useful/physical/tail ledger, NOT a relaxed v2 audit.

    Steps are normalized per-request joined scheduler/worker rows. An adapter
    must supply actual counts/positions and resolved matched CUDA evidence.
    No duration is converted into an absolute GPU/host timestamp.
    """
    prompt = _integer(prompt_tokens, "prompt tokens")
    output = _integer(output_tokens, "delivered output tokens")
    eos = _finite(eos_at, "native EOS")
    _text(clock_domain, "native host clock")
    useful_end = prompt + output - 1
    position, seen, tails, last_begin = 0, set(), [], -1
    for step in steps:
        key = _text(step["step_id"], "step ID")
        if key in seen:
            raise ValueError("Repeated physical step")
        seen.add(key)
        start = _integer(step["position"], "position", 0)
        count = _integer(step["tokens"], "physical input count")
        if start != position:
            raise ValueError("Physical work gap/repeat")
        if (step.get("executed_position") != start
                or type(step.get("executed_position")) is not int
                or step.get("executed_tokens") != count
                or type(step.get("executed_tokens")) is not int
                or step.get("cuda_forward_matched") is not True
                or step.get("clock_domain") != clock_domain):
            raise ValueError("Unmatched scheduler/worker/CUDA work")
        begin = _finite(step.get("host_forward_start"), "host forward start")
        commit = _finite(step.get("output_commit_at"), "host output commit")
        if begin > commit:
            raise ValueError("Forward wrapper begins after output commit")
        if begin < last_begin or begin >= eos:
            raise ValueError("Forward start regresses or begins after natural EOS")
        last_begin = begin
        position = start + count
        if position > useful_end:
            # Only the explicitly qualified one-placeholder natural-EOS case.
            if (start < useful_end or count != 1 or position != useful_end + 1
                    or type(step.get("pre_finish_placeholder")) is not int
                    or step["pre_finish_placeholder"] != 1
                    or not begin < eos <= commit
                    or step.get("delivered_output_from_step") is not False):
                raise ValueError("Unexplained physical excess; retain failed audit")
            tails.append(key)
    if position < useful_end:
        raise ValueError("Physical work below delivered-token minimum")
    return dict(useful_input_minimum=useful_end, physical_input_tokens=position,
                undelivered_tail_input_tokens=position - useful_end,
                tail_step_ids=tails, old_final_progress_equal=position == useful_end,
                native_qualification_accepted=False,
                scope="Contiguous executed input positions; delivered-token minimum"
                      " is not measured exclusive GPU demand. Matched current-stream"
                      " forward evidence is not an absolute clock or whole-service duration.")
