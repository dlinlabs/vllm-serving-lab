"""NV3 R19 Opus cross-critique cross-checks (stdlib, read-only)."""
import hashlib, json, math, re, sys
from pathlib import Path
M = Path(sys.argv[1]); REP = Path(sys.argv[2]); OUT = Path(sys.argv[3])
MSHA = "2e3d34ba69d2d0ed0d93978b93dc959c415a280ab9afdfc84365a3be78256596"
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(M) == MSHA
man = json.loads(M.read_text()); root = Path(man["root"])
inputs = {}
for n, p in man["peers"].items():
    for k in ("report", "raw"):
        h = sha(root / p[k]); assert h == p[k + "_sha256"], (n, k)
        inputs[f"{n}.{k}"] = dict(path=str(root / p[k]), sha256=h)
rec = man["shared_estimands"]["reconciliation"]
inputs["reconciliation"] = dict(path=str(root / rec), sha256=sha(root / rec))
mine = json.loads((root / man["peers"]["opus"]["raw"]).read_text())
P = {"C16": "fixed-cost16", "C32": "fixed-cost32", "N16": "fixed-count16", "N32": "fixed-count32"}
cells = mine["cells"]
cohort = {(c, p): mine["cell_policy_table"][f"{c}|{p}"]["totals"]["natural_cohort_good"] / 480 for c in cells for p in P.values()}
inwin = {(c, p): mine["cell_policy_table"][f"{c}|{p}"]["totals"]["natural_in_window_good"] / 480 for c in cells for p in P.values()}
# Astra per-cell cohort table and Sol per-cell in-window table, parsed from sealed report text
def section(path, start, stop):
    t = Path(path).read_text(); i = t.index(start); return t[i:t.index(stop, i)]
astra_t = section(root / man["peers"]["astra"]["report"], "#### R19 per-cell mean goodput", "#### R19 equal-exposure")
sol_t = section(root / man["peers"]["sol"]["report"], "**Natural SLO-good terminals per offered second:**", "Paired-seed mean")
check = dict(astra_cohort_cell=[], sol_inwindow_cell=[])
for line in astra_t.splitlines():
    m = re.match(r"\| (\S+) \| ([\d.]+) \| ([\d.]+) \| ([\d.]+) \| ([\d.]+) \|", line)
    if m:
        for p, v in zip(("C16", "C32", "N16", "N32"), m.groups()[1:]):
            check["astra_cohort_cell"].append(dict(cell=m[1], policy=P[p], peer=float(v),
                opus=cohort[(m[1], P[p])], match=abs(float(v) - cohort[(m[1], P[p])]) < 5e-7))
for line in sol_t.splitlines():
    m = re.match(r"\| (\S+) \|([\d.]+)\|([\d.]+)\|([\d.]+)\|([\d.]+)\|", line)
    if m:
        c = m[1].replace("/max", "-m")
        for p, v in zip(("N16", "N32", "C16", "C32"), m.groups()[1:]):
            check["sol_inwindow_cell"].append(dict(cell=c, policy=P[p], peer=float(v),
                opus=inwin[(c, P[p])], match=abs(float(v) - inwin[(c, P[p])]) <= 5e-5 + 1e-9))  # 4-dp display rounding
# Gemini: prose vs own raw, and conditional-on-completion "SLO attainment"
g = json.loads((root / man["peers"]["gemini"]["raw"]).read_text())
g32 = g["policy_cell_summary"]["p4096-m128__fixed-count32"]
gem_text = section(root / man["peers"]["gemini"]["report"], "### 42.6", "### 42.7")
gemini = dict(
    prose_quotes_p95_ttft_5_91=("p95 TTFT 膨脹至 5.91" in gem_text),
    prose_quotes_p95_tpot_85_1ms=("p95 TPOT 膨脹至 85.1ms" in gem_text),
    raw_p50_ttft=g32["p50_ttft"], raw_p95_ttft=g32["p95_ttft"],
    raw_p50_tpot=g32["p50_tpot"], raw_p95_tpot=g32["p95_tpot"],
    slo_attainment_is_good_over_complete=all(
        abs(v["slo_attainment_pct"] - round(100 * v["window_good"] / v["complete"], 2)) < .006
        for v in g["policy_cell_summary"].values()),
    example_p128m128_cost16=dict(conditional_pct=g["policy_cell_summary"]["p128-m128__fixed-cost16"]["slo_attainment_pct"],
                                 all_assigned_pct=round(100 * 8725 / 15762, 2)),
    window_30s_definition_in_raw=False)
# Sol cost-owner bounds arithmetic
charges = dict(zip(("p128-m128", "p128-m256", "p4096-m128", "p4096-m256"),
                   (1.0226906624, 1.6893573248, 4.0304346624, 4.6971013248)))
sol_bounds = {c: dict(cost16=math.floor(16 / x), cost32=math.floor(32 / x)) for c, x in charges.items()}
# Astra tail claim from replica (bounded read of episode rows)
D = Path(sys.argv[4]); post = good_post = 0; overhang = 0.0
idx = json.loads((D / "latest-index.json").read_text())
for ent in idx["episodes"]:
    e = json.loads((D / ent["artifact"]).read_text()); end = e["start"] + e["duration_s"]
    for r in e["rows"]:
        if r["terminal_at"] > end:
            post += 1; overhang = max(overhang, r["terminal_at"] - end)
    good_post += e["summary"]["natural_cohort_good"] - e["summary"]["natural_in_window_good"]
pt = mine["policy_table"]
seed = lambda p, k: pt[p][k]["per_seed"]
out = dict(
    schema="nv3-opus-r19-crosscritique-v1", manifest_sha256=MSHA, inputs=inputs,
    opus_report_sha256_at_critique=sha(REP),
    shared_counts=dict(offered=sum(pt[p]["totals"]["offered"] for p in P.values()),
                       natural_complete=sum(pt[p]["totals"]["complete"] for p in P.values()),
                       rejected=sum(pt[p]["totals"]["rejected"] for p in P.values()),
                       protected_rejected=pt["fixed-count16"]["totals"]["rejected"] + pt["fixed-count32"]["totals"]["rejected"],
                       cohort_good=sum(pt[p]["totals"]["natural_cohort_good"] for p in P.values()),
                       in_window_good=sum(pt[p]["totals"]["natural_in_window_good"] for p in P.values())),
    cost32_minus_count32_in_window=[a - b for a, b in zip(seed("fixed-cost32", "in_window_good_per_seed"),
                                                          seed("fixed-count32", "in_window_good_per_seed"))],
    cell_crosscheck=dict(astra_cohort_all_match=all(x["match"] for x in check["astra_cohort_cell"]),
                         astra_n=len(check["astra_cohort_cell"]),
                         sol_inwindow_all_match=all(x["match"] for x in check["sol_inwindow_cell"]),
                         sol_n=len(check["sol_inwindow_cell"]), detail=check),
    astra_tail=dict(post_window_terminals=post, max_overhang_s=overhang, good_post_window=good_post),
    sol_cost_owner_bounds=sol_bounds, gemini=gemini,
    scope=dict(mpc_permit=False, superiority_claim=False, selected_best=False, calval_used=False))
OUT.write_text(json.dumps(out, indent=1, sort_keys=True, allow_nan=False) + "\n")
print(sha(OUT), OUT)
