"""Bounded, shadow-only native response planning; no plant or actuator implementation."""

from dataclasses import dataclass, replace
from fractions import Fraction
from itertools import product
from math import isclose, isfinite
from typing import Callable, Protocol
import hashlib
import json
import math
import statistics
import time
from types import MappingProxyType


CAPS = (16, 32)
OFFSETS = (1.0, 3.0, 5.0)
MAX_REQUESTS = 256
MAX_SCENARIOS = 128


@dataclass(frozen=True)
class Identity:
    """Receipt-bound deployment and process incarnations, not a clock epoch.

    The adapter's epoch must change on Gateway/native run changes even when
    the Pod boot/time namespace and therefore clock_domain remain unchanged.
    """

    deployment: str
    epoch: str
    clock_domain: str
    cost_model: str


@dataclass(frozen=True)
class RequestState:
    """Stage/progress describe the same native prefix as State's counts.

    Awaiting requires an identified native waiting request, not merely a Gateway
    mark without first content. Accepted-but-not-visible work is unknown.
    """

    request_id: str
    original_cost: float
    prompt_tokens: int
    max_output_tokens: int
    observed_output_tokens: int
    stage: str
    age_s: float


@dataclass(frozen=True)
class State:
    state_id: str
    identity: Identity
    origin: float
    sampled_at: float
    received_at: float
    sample_width_s: float
    applied_cap: int
    cap_version: int
    pending_command: bool
    reserved_cost: float
    requests: tuple[RequestState, ...]
    native_waiting: int
    native_running: int
    pending_batches: int
    kv_usage: float
    history_id: str


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    probability: float
    future_offers: int


@dataclass(frozen=True)
class Evaluation:
    """IDs refer to frozen external artifacts, not attestations verified here.

    Good means natural complete, TTFT <= .5s from scheduled offer, and
    (terminal - first content)/(output tokens - 1) <= .05s; one token has TPOT=0.
    All failures/rejections score zero. Old outstanding offers need not be admitted.
    """

    model_id: str
    support_id: str
    future_law_id: str
    uncertainty_id: str
    cohort_id: str
    continuation_id: str
    continuation_development_receipt: str
    tail_rule_id: str
    tail_s: float
    origin_offered_ids: tuple[str, ...]
    scenarios: tuple[Scenario, ...]
    horizon_s: float = 5.0
    slot_s: float = 1.0


@dataclass(frozen=True)
class Timing:
    clock_domain: str
    deadline_at: float
    dispatch_reserve_s: float
    max_age_s: float
    max_sample_width_s: float


@dataclass(frozen=True)
class Plan:
    prefix: tuple[int, ...]
    continuation_id: str


@dataclass(frozen=True)
class Outcome:
    scenario_id: str
    settled_good: int
    unresolved: int
    expected_tail_good: float
    released_origin_ids: tuple[tuple[str, ...], tuple[str, ...], tuple[str, ...]]


@dataclass(frozen=True)
class Prediction:
    state_id: str
    plan: Plan
    evaluation: Evaluation
    outcomes: tuple[Outcome, ...]
    error_below: float
    error_above: float


class ResponseModel(Protocol):
    def predict(
        self, state: State, plan: Plan, evaluation: Evaluation, deadline_at: float
    ) -> Prediction | None:
        """Return None outside joint state/sequence/continuation support."""
        ...


@dataclass(frozen=True)
class Score:
    plan: Plan
    mean_good: float
    lower_good: float
    upper_good: float
    tail_lower: float
    tail_upper: float
    released_origin_cost: tuple[float, ...]


@dataclass(frozen=True)
class Selection:
    best: Score
    first_action_resolved: bool


@dataclass(frozen=True)
class Decision:
    status: str
    reason: str
    shadow_cap: int | None = None
    one_move: Selection | None = None
    two_move: Selection | None = None
    scores: tuple[Score, ...] = ()
    gain_interval: tuple[float, float] | None = None
    elapsed_s: float | None = None

    @property
    def active_permit(self) -> bool:
        return False


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _number(value: float, minimum: float = 0.0) -> bool:
    return type(value) in (float, int) and isfinite(value) and value >= minimum


def _integer(value: int, minimum: int = 0) -> bool:
    return type(value) is int and value >= minimum


def _name(value: str) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _cap(value: int) -> bool:
    return type(value) is int and value in CAPS


def transition_costs(
    live: tuple[tuple[str, float], ...],
    events: tuple[tuple[str, str, float, int], ...],
) -> tuple[tuple[str, float], ...]:
    """Replay ordered (admit/release, id, original cost, actually applied cap)."""
    _require(len(live) <= MAX_REQUESTS and len(events) <= 1024, "ledger size")
    costs = {}
    seen = set()
    for request_id, cost in live:
        _require(_name(request_id) and request_id not in seen, "duplicate live ID")
        _require(_number(cost) and cost > 0, "original cost")
        costs[request_id] = cost
        seen.add(request_id)
    _require(sum(costs.values()) <= max(CAPS), "initial reservation bound")
    for kind, request_id, cost, cap in events:
        _require(_name(request_id) and _number(cost) and cost > 0, "event cost/ID")
        _require(_cap(cap), "unsupported applied cap")
        if kind == "admit":
            _require(request_id not in seen, "reused admission ID")
            _require(sum(costs.values()) + cost <= cap, "projected cost exceeds cap")
            _require(len(costs) < MAX_REQUESTS, "ledger size")
            costs[request_id] = cost
            seen.add(request_id)
        elif kind == "release":
            _require(request_id in costs and costs[request_id] == cost, "release mismatch")
            del costs[request_id]
        else:
            raise ValueError("unknown ledger event")
    return tuple(costs.items())


def _validate_state(state: State, identity: Identity, timing: Timing, now: float) -> None:
    _require(state.identity == identity, "deployment/epoch/cost identity")
    _require(all(_name(x) for x in (
        identity.deployment, identity.epoch, identity.clock_domain, identity.cost_model,
        state.state_id, state.history_id,
    )), "missing identity/history")
    _require(identity.clock_domain == timing.clock_domain, "clock domain")
    _require(all(_number(x) for x in (
        state.origin, state.sampled_at, state.received_at, state.sample_width_s,
        state.reserved_cost, state.kv_usage,
    )), "invalid state numbers")
    _require(state.sampled_at <= state.received_at <= state.origin <= now, "availability")
    _require(now - state.sampled_at <= timing.max_age_s, "stale state")
    _require(state.sample_width_s <= timing.max_sample_width_s, "sample skew")
    _require(_cap(state.applied_cap) and _integer(state.cap_version), "cap/version")
    _require(state.pending_command is False, "pending command")
    _require(all(_integer(x) for x in (
        state.native_waiting, state.native_running, state.pending_batches,
    )) and state.kv_usage <= 1, "batch observation")
    _require(type(state.requests) is tuple and len(state.requests) <= MAX_REQUESTS,
             "mutable/oversized requests")
    ledger = tuple((r.request_id, r.original_cost) for r in state.requests)
    transition_costs(ledger, ())
    _require(isclose(sum(c for _, c in ledger), state.reserved_cost,
                     rel_tol=0, abs_tol=1e-9), "reservation conservation")
    for request in state.requests:
        _require(_integer(request.prompt_tokens, 1)
                 and _integer(request.max_output_tokens, 1)
                 and _integer(request.observed_output_tokens)
                 and request.observed_output_tokens <= request.max_output_tokens,
                 "token observation")
        _require(request.stage in ("awaiting", "prefill", "decode", "release_pending"),
                 "unknown native work")
        _require(_number(request.age_s), "request age")
        if request.stage in ("awaiting", "prefill"):
            _require(request.observed_output_tokens == 0, "stage/progress mismatch")
        elif request.stage == "decode":
            _require(request.observed_output_tokens > 0, "stage/progress mismatch")
    _require(state.native_running == sum(
        r.stage in ("prefill", "decode") for r in state.requests
    ), "native running/stage mismatch")
    _require(state.native_waiting == sum(
        r.stage == "awaiting" for r in state.requests
    ), "native waiting/stage mismatch")


def _validate_evaluation(state: State, evaluation: Evaluation) -> None:
    _require(all(_name(x) for x in (
        evaluation.model_id, evaluation.support_id, evaluation.future_law_id,
        evaluation.uncertainty_id, evaluation.cohort_id, evaluation.continuation_id,
        evaluation.continuation_development_receipt, evaluation.tail_rule_id,
    )), "missing model/evaluation receipt")
    _require(_number(evaluation.horizon_s) and _number(evaluation.slot_s)
             and evaluation.horizon_s == 5.0 and evaluation.slot_s == 1.0,
             "fixed five-second evaluation/two one-second moves")
    _require(_number(evaluation.tail_s), "tail duration")
    ids = evaluation.origin_offered_ids
    _require(type(ids) is tuple and len(ids) <= MAX_REQUESTS
             and all(_name(x) for x in ids) and len(set(ids)) == len(ids),
             "origin cohort")
    _require({r.request_id for r in state.requests}.issubset(ids), "missing live cohort")
    _require(type(evaluation.scenarios) is tuple
             and 1 <= len(evaluation.scenarios) <= MAX_SCENARIOS, "scenario bound")
    ids = set()
    for scenario in evaluation.scenarios:
        _require(_name(scenario.scenario_id) and scenario.scenario_id not in ids,
                 "scenario identity")
        ids.add(scenario.scenario_id)
        _require(_number(scenario.probability) and scenario.probability > 0
                 and _integer(scenario.future_offers), "future law")
    _require(isclose(sum(s.probability for s in evaluation.scenarios), 1.0,
                     rel_tol=0, abs_tol=1e-12), "scenario probabilities")


def _score(state: State, plan: Plan, evaluation: Evaluation, prediction: Prediction) -> Score:
    _require(prediction.state_id == state.state_id and prediction.plan == plan
             and prediction.evaluation == evaluation, "prediction binding")
    _require(type(prediction.outcomes) is tuple
             and len(prediction.outcomes) == len(evaluation.scenarios), "outcome count")
    _require(_number(prediction.error_below) and _number(prediction.error_above),
             "model uncertainty")
    mean = lower = upper = offered = 0.0
    release = [0.0] * len(OFFSETS)
    original_costs = {r.request_id: r.original_cost for r in state.requests}
    for scenario, outcome in zip(evaluation.scenarios, prediction.outcomes):
        _require(outcome.scenario_id == scenario.scenario_id, "joint scenario pairing")
        cohort_size = len(evaluation.origin_offered_ids) + scenario.future_offers
        _require(_integer(outcome.settled_good) and _integer(outcome.unresolved)
                 and outcome.settled_good + outcome.unresolved <= cohort_size,
                 "all-offered accounting")
        _require(_number(outcome.expected_tail_good)
                 and outcome.expected_tail_good <= outcome.unresolved, "tail expectation")
        trajectory = outcome.released_origin_ids
        _require(type(trajectory) is tuple and len(trajectory) == len(OFFSETS)
                 and all(type(ids) is tuple and len(ids) <= len(original_costs)
                         for ids in trajectory), "release trajectory")
        previous_ids = set()
        for i, ids in enumerate(trajectory):
            _require(all(_name(x) for x in ids) and len(set(ids)) == len(ids),
                     "duplicate/invalid release ID")
            current_ids = set(ids)
            _require(previous_ids <= current_ids <= original_costs.keys(),
                     "origin-cost conservation")
            release[i] += scenario.probability * sum(original_costs[x] for x in ids)
            previous_ids = current_ids
        p = scenario.probability
        lower += p * outcome.settled_good
        upper += p * (outcome.settled_good + outcome.unresolved)
        mean += p * (outcome.settled_good + outcome.expected_tail_good)
        offered += p * cohort_size
    return Score(plan, mean, max(0.0, lower - prediction.error_below),
                 min(offered, upper + prediction.error_above), lower, upper, tuple(release))


def _select(scores: tuple[Score, ...], applied_cap: int) -> Selection:
    best = max(scores, key=lambda score: (
        score.mean_good, score.plan.prefix[0] == applied_cap,
        tuple(-cap for cap in score.plan.prefix),
    ))
    other_upper = max(score.upper_good for score in scores
                      if score.plan.prefix[0] != best.plan.prefix[0])
    return Selection(best, best.lower_good > other_upper)


def plan_response(
    state: State,
    evaluation: Evaluation,
    model: ResponseModel,
    *,
    expected_identity: Identity,
    timing: Timing,
    clock: Callable[[], float],
    current_inputs: Callable[[], tuple[State, Evaluation]] | None = None,
) -> Decision:
    """Compare two One-move and four two-move plans, or issue no recommendation.

    Model and input-fence callbacks must cooperate with the deadline. Neither
    can be preempted here. The publisher must atomically return its latest
    receipt-cut State/Evaluation; any update invalidates this planning pass.
    This read is not an actuator CAS or proof of artifact authenticity.

    Agreement on the best first action deliberately retains One-move's
    resolution gate, even if only two-move resolves it. This conservative policy
    is not optimality, a claim of equivalent behavior, or a closed-loop theorem.
    """
    previous = None
    started = None

    def checked_clock() -> float:
        nonlocal previous
        now = clock()
        _require(_number(now) and (previous is None or now >= previous), "clock regression")
        previous = now
        _require(now < timing.deadline_at - timing.dispatch_reserve_s, "deadline")
        return now

    def check_inputs() -> None:
        if current_inputs is None:
            raise ValueError("missing input fence")
        latest = current_inputs()
        _require(type(latest) is tuple and len(latest) == 2
                 and latest == (state, evaluation), "planning inputs changed")

    try:
        _require(_number(timing.deadline_at)
                 and all(_number(x) for x in (
                     timing.dispatch_reserve_s, timing.max_age_s, timing.max_sample_width_s,
                 )), "invalid timing")
        started = checked_clock()
        _validate_state(state, expected_identity, timing, started)
        _validate_evaluation(state, evaluation)
        check_inputs()
        plans = tuple(Plan(prefix, evaluation.continuation_id)
                      for length in (1, 2) for prefix in product(CAPS, repeat=length))
        scores = []
        for plan in plans:
            now = checked_clock()
            _validate_state(state, expected_identity, timing, now)
            now = checked_clock()
            _require(now - state.sampled_at <= timing.max_age_s, "stale state")
            prediction = model.predict(
                state, plan, evaluation, timing.deadline_at - timing.dispatch_reserve_s
            )
            checked_clock()
            _require(prediction is not None, "unsupported state/plan/continuation")
            scores.append(_score(state, plan, evaluation, prediction))
        one = _select(tuple(scores[:2]), state.applied_cap)
        two = _select(tuple(scores[2:]), state.applied_cap)
        gain = (two.best.lower_good - one.best.upper_good,
                two.best.upper_good - one.best.lower_good)
        chosen = one
        reason = "strong One-move retained"
        same_first = two.best.plan.prefix[0] == one.best.plan.prefix[0]
        if not same_first:
            if gain[0] > 0 and two.first_action_resolved:
                chosen, reason = two, "two-move shadow advantage"
            else:
                reason = "two-move advantage unresolved; retain strong One-move"
        finished = checked_clock()
        _validate_state(state, expected_identity, timing, finished)
        check_inputs()
        finished = checked_clock()
        _require(finished - state.sampled_at <= timing.max_age_s, "stale state")
        if not chosen.first_action_resolved:
            fallback_reason = ("same first action; strong One-move unresolved"
                               if same_first and two.first_action_resolved
                               else "first-action uncertainty")
            return Decision("fallback", fallback_reason, one_move=one,
                            two_move=two, scores=tuple(scores), gain_interval=gain,
                            elapsed_s=finished - started)
        return Decision("shadow", reason, chosen.best.plan.prefix[0], one, two,
                        tuple(scores), gain, finished - started)
    except Exception as error:
        elapsed = None if started is None or previous is None else previous - started
        return Decision("fallback", f"{type(error).__name__}: {error}", elapsed_s=elapsed)


@dataclass(frozen=True)
class FlowRequest:
    """Client outcome marks in seconds relative to the receipt-cut origin."""

    request_id: str
    original_cost: float
    offered_at: float
    prompt_tokens: int
    max_output_tokens: int
    output_tokens: int = 0
    first_at: float | None = None
    terminal_at: float | None = None
    natural_eos: bool = False
    rejected: bool = False


@dataclass(frozen=True)
class FlowView:
    at_s: float
    requested_cap: int
    applied_cap: int
    live: tuple[tuple[str, float], ...]
    native: tuple[int | None, int | None, int | None, float | None]
    native_received_at: float
    requests: tuple[FlowRequest, ...]


@dataclass(frozen=True)
class FlowState:
    requests: tuple[FlowRequest, ...]
    history: tuple[FlowView, ...]
    memory: tuple[float, ...]


@dataclass(frozen=True)
class FlowEvent:
    at_s: float
    kind: str
    request_id: str = ""
    output_tokens: int = 0
    natural_eos: bool = False
    cap: int | None = None


@dataclass(frozen=True)
class FlowStep:
    events: tuple[FlowEvent, ...]
    memory: tuple[float, ...]
    native: tuple[int | None, int | None, int | None, float | None]
    native_received_at: float


@dataclass(frozen=True)
class JointPath:
    scenario_id: str
    seed: FlowState
    offers: tuple[FlowRequest, ...]
    innovations: tuple[tuple[float, ...], ...]


class JointKernel(Protocol):
    def step(
        self, state: FlowState, requested_cap: int, offers: tuple[FlowRequest, ...],
        innovation: tuple[float, ...], end_s: float, deadline_at: float,
    ) -> FlowStep | None:
        """One joint short-step law, not independent per-request hazards."""
        ...


def _signed_number(value: float) -> bool:
    return type(value) in (float, int) and isfinite(value)


def _vector(values: tuple[float, ...]) -> bool:
    return (type(values) is tuple and len(values) <= 32
            and all(_signed_number(x) for x in values))


def _flow_request(request: FlowRequest, now: float) -> None:
    _require(_name(request.request_id) and _number(request.original_cost)
             and request.original_cost > 0 and _signed_number(request.offered_at)
             and request.offered_at <= now, "flow offer")
    _require(_integer(request.prompt_tokens, 1)
             and _integer(request.max_output_tokens, 1)
             and _integer(request.output_tokens)
             and request.output_tokens <= request.max_output_tokens, "flow tokens")
    _require(type(request.natural_eos) is bool and type(request.rejected) is bool,
             "flow status")
    _require((request.first_at is None) == (request.output_tokens == 0),
             "flow first/output")
    if request.first_at is not None:
        _require(_signed_number(request.first_at)
                 and request.offered_at <= request.first_at <= now, "flow first time")
    if request.terminal_at is not None:
        _require(_signed_number(request.terminal_at)
                 and request.offered_at <= request.terminal_at <= now
                 and (request.first_at is None or request.first_at <= request.terminal_at),
                 "flow terminal time")
    _require(not request.natural_eos or (
        request.terminal_at is not None and request.output_tokens > 0
        and not request.rejected), "flow EOS")
    _require(not request.rejected or (
        request.output_tokens == 0 and request.terminal_at is None
        and not request.natural_eos), "flow rejection")


def _native_view(native: tuple, received_at: float, now: float) -> None:
    _require(type(native) is tuple and len(native) == 4
             and all(x is None or _integer(x) for x in native[:3])
             and (native[3] is None or (_number(native[3]) and native[3] <= 1)),
             "flow native observation")
    _require(_signed_number(received_at) and received_at <= now, "flow receipt cut")


def _good(request: FlowRequest) -> bool:
    return (request.natural_eos and not request.rejected
            and request.first_at - request.offered_at <= .5
            and (request.output_tokens == 1
                 or (request.terminal_at - request.first_at)
                 / (request.output_tokens - 1) <= .05))


def _advance_flow(
    state: FlowState, requested_cap: int, offers: tuple[FlowRequest, ...],
    step: FlowStep, end_s: float,
) -> FlowState:
    previous = state.history[-1]
    _require(type(step.events) is tuple and len(step.events) <= 1024
             and _vector(step.memory), "flow step bound")
    _native_view(step.native, step.native_received_at, end_s)
    _require(step.native_received_at >= previous.native_received_at,
             "flow receipt regression")
    times = tuple(event.at_s for event in step.events)
    _require(all(_number(t) and previous.at_s < t <= end_s for t in times)
             and tuple(sorted(times)) == times, "flow event chronology")
    _require(not set(times).intersection(r.offered_at for r in offers),
             "unresolved offer/event tie")
    records = {r.request_id: r for r in state.requests}
    live = previous.live
    applied = previous.applied_cap
    ordered = [(r.offered_at, r) for r in offers] + [(e.at_s, e) for e in step.events]
    for _, item in sorted(ordered, key=lambda pair: pair[0]):
        if isinstance(item, FlowRequest):
            _require(item.request_id not in records, "reused flow offer")
            admitted = (sum(Fraction(cost) for _, cost in live)
                        + Fraction(item.original_cost) <= applied)
            _require(admitted == (sum(cost for _, cost in live)
                                  + item.original_cost <= applied),
                     "flow cost arithmetic ambiguous")
            if admitted:
                live = transition_costs(
                    live, (("admit", item.request_id, item.original_cost, applied),))
            records[item.request_id] = replace(item, rejected=not admitted)
            continue
        _require(_integer(item.output_tokens) and type(item.natural_eos) is bool,
                 "flow event mark")
        if item.kind == "apply":
            _require(item.request_id == "" and _cap(item.cap)
                     and item.cap == requested_cap and item.output_tokens == 0
                     and item.natural_eos is False, "flow command application")
            applied = item.cap
            continue
        _require(item.cap is None and item.request_id in dict(live), "flow live event")
        request = records[item.request_id]
        if item.kind == "progress":
            _require(request.terminal_at is None and item.natural_eos is False
                     and request.output_tokens < item.output_tokens
                     <= request.max_output_tokens, "flow progress")
            request = replace(request, output_tokens=item.output_tokens,
                              first_at=(item.at_s if request.first_at is None
                                        else request.first_at))
        elif item.kind == "terminal":
            _require(request.terminal_at is None and item.output_tokens == 0,
                     "duplicate/invalid flow terminal")
            request = replace(request, terminal_at=item.at_s, natural_eos=item.natural_eos)
        elif item.kind == "release":
            _require(request.terminal_at is not None and item.output_tokens == 0
                     and item.natural_eos is False, "flow release before terminal")
            live = transition_costs(
                live, (("release", item.request_id, request.original_cost, applied),))
        else:
            raise ValueError("unknown flow event")
        _flow_request(request, end_s)
        records[item.request_id] = request
    view = FlowView(end_s, requested_cap, applied, live, step.native,
                    step.native_received_at, tuple(records.values()))
    return FlowState(tuple(records.values()), state.history + (view,), step.memory)


@dataclass(frozen=True)
class ShortStepResponse:
    """Opt-in free-running composition; supplied laws/widths are not qualified.

    Fixed .25s integration, at most160 steps,256 total offers and128 joint paths.
    No default kernel, seed adapter, fitted coefficients or native authority.
    """

    state: State
    evaluation: Evaluation
    paths: tuple[JointPath, ...]
    kernel: JointKernel
    continuation: Callable[[tuple[FlowView, ...], float], int]
    clock: Callable[[], float]
    error_below: float
    error_above: float

    def predict(
        self, state: State, plan: Plan, evaluation: Evaluation, deadline_at: float,
    ) -> Prediction | None:
        previous_clock = None

        def check_clock():
            nonlocal previous_clock
            now = self.clock()
            _require(_number(now) and _number(deadline_at) and now < deadline_at
                     and (previous_clock is None or now >= previous_clock),
                     "flow deadline/clock")
            previous_clock = now

        check_clock()
        _require(state == self.state and evaluation == self.evaluation, "flow binding")
        _validate_evaluation(state, evaluation)
        _require(type(plan.prefix) is tuple and 1 <= len(plan.prefix) <= 2
                 and all(_cap(cap) for cap in plan.prefix)
                 and plan.continuation_id == evaluation.continuation_id, "flow plan")
        _require(_number(self.error_below) and _number(self.error_above),
                 "flow model uncertainty")
        step_count = (evaluation.horizon_s + evaluation.tail_s) * 4
        _require(_number(step_count) and step_count <= 160
                 and step_count == int(step_count), "flow time bound")
        _require(type(self.paths) is tuple and len(self.paths) == len(evaluation.scenarios),
                 "flow joint paths")
        outcomes = []
        origin_live = tuple((r.request_id, r.original_cost) for r in state.requests)
        for path, scenario in zip(self.paths, evaluation.scenarios):
            check_clock()
            flow = path.seed
            _require(path.scenario_id == scenario.scenario_id
                     and type(flow.requests) is tuple
                     and tuple(r.request_id for r in flow.requests)
                     == evaluation.origin_offered_ids, "flow origin cohort")
            _require(type(flow.history) is tuple and len(flow.history) == 1
                     and _vector(flow.memory), "flow seed")
            _require(flow.requests == self.paths[0].seed.requests
                     and flow.history == self.paths[0].seed.history,
                     "flow observed seed mismatch")
            initial = flow.history[0]
            _require(initial == FlowView(
                0.0, state.applied_cap, state.applied_cap, origin_live,
                (state.native_running, state.native_waiting, state.pending_batches,
                 state.kv_usage), state.received_at - state.origin, flow.requests),
                     "flow seed observation")
            for request in flow.requests:
                _flow_request(request, 0.0)
                if request.request_id not in dict(origin_live):
                    _require(request.rejected or request.terminal_at is not None,
                             "unobserved origin admission")
            records = {r.request_id: r for r in flow.requests}
            for old in state.requests:
                r = records[old.request_id]
                _require(not r.rejected and r.original_cost == old.original_cost
                         and r.prompt_tokens == old.prompt_tokens
                         and r.max_output_tokens == old.max_output_tokens
                         and r.output_tokens == old.observed_output_tokens
                         and (r.terminal_at is not None) == (old.stage == "release_pending"),
                         "flow origin reconciliation")
            _require(type(path.offers) is tuple
                     and len(path.offers) + len(flow.requests) <= MAX_REQUESTS
                     and type(path.innovations) is tuple
                     and len(path.innovations) == int(step_count)
                     and all(_vector(w) for w in path.innovations), "flow path bound")
            offered_ids = set(records)
            last_offer = 0.0
            for offer in path.offers:
                _flow_request(offer, step_count / 4)
                _require(offer.request_id not in offered_ids
                         and last_offer <= offer.offered_at
                         and offer.output_tokens == 0 and offer.terminal_at is None
                         and not offer.rejected and not offer.natural_eos, "flow future offer")
                offered_ids.add(offer.request_id)
                last_offer = offer.offered_at
            _require(sum(r.offered_at < 5 for r in path.offers) == scenario.future_offers,
                     "flow future-law count")
            releases = []
            at_horizon = None
            cap = None
            for index, innovation in enumerate(path.innovations):
                check_clock()
                if index % 4 == 0:
                    slot = index // 4
                    cap = (plan.prefix[slot] if slot < len(plan.prefix)
                           else self.continuation(flow.history, deadline_at))
                    check_clock()
                    _require(_cap(cap), "flow continuation")
                start, end = index / 4, (index + 1) / 4
                offers = tuple(r for r in path.offers if (
                    start < r.offered_at <= end or index == 0 and r.offered_at == 0))
                step = self.kernel.step(flow, cap, offers, innovation, end, deadline_at)
                check_clock()
                if step is None:
                    return None
                flow = _advance_flow(flow, cap, offers, step, end)
                if end in OFFSETS:
                    live_ids = dict(flow.history[-1].live)
                    releases.append(tuple(rid for rid, _ in origin_live if rid not in live_ids))
                if end == 5:
                    at_horizon = flow
            cohort = set(evaluation.origin_offered_ids) | {
                r.request_id for r in path.offers if r.offered_at < 5}
            horizon_records = [r for r in at_horizon.requests if r.request_id in cohort]
            unresolved_ids = {r.request_id for r in horizon_records
                              if r.terminal_at is None and not r.rejected}
            final_records = {r.request_id: r for r in flow.requests}
            if any(final_records[rid].terminal_at is None for rid in unresolved_ids):
                return None
            outcomes.append(Outcome(
                scenario.scenario_id, sum(_good(r) for r in horizon_records),
                len(unresolved_ids), sum(_good(final_records[rid]) for rid in unresolved_ids),
                tuple(releases)))
        check_clock()
        return Prediction(state.state_id, plan, evaluation, tuple(outcomes),
                          self.error_below, self.error_above)


def nested_family_diagnostic(decision: Decision, applied_cap: int) -> Selection:
    """Score-only union of One/two policies; never change the default decision."""
    expected = tuple(prefix for length in (1, 2) for prefix in product(CAPS, repeat=length))
    _require(_cap(applied_cap) and tuple(s.plan.prefix for s in decision.scores) == expected
             and len({s.plan.continuation_id for s in decision.scores}) == 1,
             "complete common-contract scores required")
    return _select(decision.scores, applied_cap)


@dataclass(frozen=True)
class BatchProgress:
    """Latent non-speculative forward state, NOT a raw native-frame adapter.

    Native commits are atomic in this restricted transition. Delivered tokens,
    ledger release and physical overhang remain separate events/stocks.
    """

    request_id: str
    prompt_tokens: int
    max_output_tokens: int
    prompt_done: int
    native_tokens: int
    decode_done: int
    eos_at: int | None
    finish_reason: str | None = None
    queued_overhang: int = 0
    executed_overhang: int = 0


def _batch_progress_valid(request: BatchProgress) -> None:
    _require(_name(request.request_id)
             and _integer(request.prompt_tokens, 1)
             and _integer(request.max_output_tokens, 1)
             and all(_integer(v) for v in (
                 request.prompt_done, request.native_tokens, request.decode_done,
                 request.queued_overhang, request.executed_overhang,
             )), "batch progress fields")
    _require(request.prompt_done <= request.prompt_tokens
             and request.native_tokens <= request.max_output_tokens
             and (request.eos_at is None or (
                 _integer(request.eos_at, 1)
                 and request.native_tokens <= request.eos_at <= request.max_output_tokens)),
             "batch progress bounds")
    _require((request.prompt_done == request.prompt_tokens) == (request.native_tokens > 0)
             and request.decode_done == max(0, request.native_tokens - 1),
             "atomic non-speculative prefix required")
    reason = ("stop" if request.eos_at is not None and request.native_tokens == request.eos_at
              else "length" if request.native_tokens == request.max_output_tokens else None)
    _require(request.finish_reason == reason, "batch EOS/length distinction")


def advance_joint_forward(
    requests: tuple[BatchProgress, ...],
    allocation: tuple[tuple[str, int, int, int], ...],
) -> tuple[BatchProgress, ...]:
    """Apply one supplied joint forward: (id, prefill positions, decode, overhang).

    No cap, cost, clock, learned service rate or scheduler policy is an input.
    The producer must qualify joint allocation feasibility and completion time.
    """
    _require(type(requests) is tuple and len(requests) <= MAX_REQUESTS
             and type(allocation) is tuple and len(allocation) <= len(requests),
             "joint forward bound")
    current = {}
    for request in requests:
        _batch_progress_valid(request)
        _require(request.request_id not in current, "duplicate batch ID")
        current[request.request_id] = request
    seen = set()
    for item in allocation:
        _require(type(item) is tuple and len(item) == 4, "joint forward allocation")
        rid, prefill, decode, overhang = item
        _require(rid in current and rid not in seen, "joint forward identity")
        seen.add(rid)
        _require(all(_integer(v) for v in (prefill, decode, overhang))
                 and decode <= 1 and overhang <= 1
                 and sum(v > 0 for v in (prefill, decode, overhang)) <= 1,
                 "one request contribution per forward")
        request = current[rid]
        if overhang:
            _require(request.finish_reason is not None and request.queued_overhang > 0,
                     "overhang requires preexisting queued work")
            request = replace(request, queued_overhang=request.queued_overhang - 1,
                              executed_overhang=request.executed_overhang + 1)
        elif prefill or decode:
            _require(request.finish_reason is None, "productive work after finish")
            if prefill:
                _require(request.native_tokens == 0
                         and prefill <= request.prompt_tokens - request.prompt_done,
                         "prefill allocation exceeds residual")
                done = request.prompt_done + prefill
                request = replace(request, prompt_done=done,
                                  native_tokens=int(done == request.prompt_tokens))
            else:
                _require(request.native_tokens > 0, "decode before prefill")
                request = replace(request, decode_done=request.decode_done + 1,
                                  native_tokens=request.native_tokens + 1)
            reason = ("stop" if request.native_tokens == request.eos_at
                      else "length" if request.native_tokens == request.max_output_tokens
                      else None)
            request = replace(request, finish_reason=reason)
        _batch_progress_valid(request)
        current[rid] = request
    return tuple(current.values())


R8_VERSION = "astra-direct-headroom-v1"
R8_LOADER_SHA = "ffcfba35f17d6099b3768ffddb27ddb5710e670cc2ef64faa5be40db0dad6e00"
R8_TRAIN = (181001, 181002, 181003)
R8_EVALUATE = (181004, 181005)
R8_RIDGE = .001
R8_CORE = "b4f234020105f69f608da45dba7317a8bb632ecd84aeb0e310362740e5fa083a"
R8_SOURCES = {
    "6c11fe7e683439f379f0dfdbd21b05f5873b2c90": (
        "a2ec60abeee5ae736abd6b125585cba2d12ab3046527cf6cc2b445aa60b9d609",
        "2587d2b822dcd3812353ce2ac3369b7192fa7ba7"),
    "729b144a0c5885d702a6a49c655f61c62513ed30": (
        "069a58b6c2e15081acaaf70c73a9465fdb64da694d47fbc5b20f35c2560d7422",
        "729b144a0c5885d702a6a49c655f61c62513ed30"),
}
R8_STATE = (
    "reserved", "live", "budget", "headroom", "unstarted", "live_prompt_k",
    "live_max_h", "hist_offers", "hist_rejected", "hist_good", "hist_ttft_miss",
    "hist_released_cost", "hist_born_cost", "running", "waiting", "kv",
    "decode_batch", "prefill_k", "native_unknown_frac", "prefill_remaining_k",
)


@dataclass(frozen=True)
class FullPlanInput:
    """Offline timestamp-prefix features, not an attestation of controller availability."""

    cut: float
    received_at: float
    state: tuple[float, ...]
    arrival_rate: float
    mean_offer_cost: float
    timed_plan: tuple[tuple[float, int], ...]
    cell: str
    source_id: str
    collector_id: str
    availability: str = "client-local-prefix-reconstructed"


def _full_plan_check(x):
    _require(len(x.state) == len(R8_STATE)
             and all(type(v) in (float, int) and isfinite(v) for v in x.state),
             "full-plan state")
    _require(all(isfinite(v) for v in (x.cut, x.received_at, x.arrival_rate,
                                      x.mean_offer_cost))
             and x.received_at <= x.cut and x.arrival_rate >= 0 and x.mean_offer_cost > 0,
             "full-plan prefix or law")
    _require(len(x.timed_plan) == 5 and all(
        at == j and type(cap) is int and cap in CAPS
        for j, (at, cap) in enumerate(x.timed_plan)), "five timed one-second slots")
    _require(x.availability in ("client-local-prefix-reconstructed", "receipt-verified"),
             "full-plan availability")
    g = dict(zip(R8_STATE, x.state))
    _require(g["budget"] in CAPS and all(v >= 0 for k, v in g.items() if k != "headroom")
             and 0 <= g["kv"] <= 1 and 0 <= g["native_unknown_frac"] <= 1,
             "full-plan state domain")


def full_plan_features(x, horizon):
    """Total-response features; the headroom proxy is NOT a free-running ledger."""
    _full_plan_check(x)
    _require(horizon in OFFSETS, "full-plan horizon")
    g = dict(zip(R8_STATE, x.state))
    features = list(x.state) + [x.arrival_rate, x.mean_offer_cost]
    demand = x.arrival_rate * x.mean_offer_cost
    release_rate = g["hist_released_cost"] / 2.
    previous = 0.
    for j in range(int(horizon)):
        stock = max(0., g["reserved"] - j * release_rate)
        admitted = lambda cap: min(demand, max(0., cap - stock))
        benefit = (admitted(x.timed_plan[j][1]) - admitted(16)) / 16.
        features.extend((benefit, benefit * g["unstarted"] / max(1., g["live"]),
                         benefit * g["prefill_remaining_k"],
                         benefit * g["native_unknown_frac"]))
        if j:
            features.append(benefit * previous)
        previous = benefit
    return features


def _full_plan_bin(x):
    g = dict(zip(R8_STATE, x.state))
    return json.dumps([x.cell, g["reserved"] + x.arrival_rate * x.mean_offer_cost > 16,
                       [cap for _, cap in x.timed_plan]], separators=(",", ":"))


def _direct_ridge(xs, ys):
    n, width = len(xs), len(xs[0])
    mean = [statistics.fmean(x[j] for x in xs) for j in range(width)]
    scale = [statistics.pstdev(x[j] for x in xs) or 1. for j in range(width)]
    zs = [[1.] + [(v - m) / s for v, m, s in zip(x, mean, scale)] for x in xs]
    a = [[math.fsum(z[i] * z[j] for z in zs) / n
          + (R8_RIDGE if i == j and i else 0.)
          for j in range(width + 1)] for i in range(width + 1)]
    rhs = [math.fsum(z[j] * y for z, y in zip(zs, ys)) / n for j in range(width + 1)]
    for col in range(width + 1):
        pivot = max(range(col, width + 1), key=lambda row: abs(a[row][col]))
        a[col], a[pivot] = a[pivot], a[col]
        rhs[col], rhs[pivot] = rhs[pivot], rhs[col]
        _require(abs(a[col][col]) > 1e-14, "singular ridge")
        divisor = a[col][col]
        a[col] = [v / divisor for v in a[col]]
        rhs[col] /= divisor
        for row in range(width + 1):
            if row == col:
                continue
            factor = a[row][col]
            a[row] = [v - factor * w for v, w in zip(a[row], a[col])]
            rhs[row] -= factor * rhs[col]
    return dict(mean=mean, scale=scale, beta=rhs)


def _direct_mean(model, features):
    z = [1.] + [(v - m) / s for v, m, s in zip(features, model["mean"], model["scale"])]
    return math.fsum(b * v for b, v in zip(model["beta"], z))


@dataclass(frozen=True)
class FittedFullPlanResponse:
    """Portable fitted means. Deliberately not the planner's joint ResponseModel."""

    artifact: dict

    @classmethod
    def fit(cls, records):
        # records: (Train block, prefix input, cumulative full-good targets at 1/3/5s).
        _require(bool(records), "empty direct fit")
        for block, x, y in records:
            _full_plan_check(x)
            _require(block in R8_TRAIN and len(y) == 3
                     and all(isfinite(v) and v >= 0 for v in y)
                     and y[0] <= y[1] <= y[2], "Train-only cumulative targets")
        sources = {x.source_id for _, x, _ in records}
        _require(len(sources) == 1, "training source mismatch")
        bins = {}
        for _, x, _ in records:
            key = _full_plan_bin(x)
            bins[key] = bins.get(key, 0) + 1
        return cls(dict(
            schema=R8_VERSION, train_blocks=sorted({b for b, _, _ in records}),
            n=len(records), source_id=next(iter(sources)),
            collectors=sorted({x.collector_id for _, x, _ in records}),
            ridge=R8_RIDGE, state_names=list(R8_STATE), bins=bins,
            ranges=[(min(x.state[j] for _, x, _ in records),
                     max(x.state[j] for _, x, _ in records)) for j in range(len(R8_STATE))],
            law_ranges=[(min(getattr(x, name) for _, x, _ in records),
                         max(getattr(x, name) for _, x, _ in records))
                        for name in ("arrival_rate", "mean_offer_cost")],
            models=[_direct_ridge([full_plan_features(x, h) for _, x, _ in records],
                                  [y[j] for _, _, y in records])
                    for j, h in enumerate(OFFSETS)]))

    def predict(self, x):
        _full_plan_check(x)
        _require(self.artifact["schema"] == R8_VERSION
                 and self.artifact["source_id"] == x.source_id, "full-plan source mismatch")
        reasons = [f"range:{name}" for name, value, (low, high) in
                   zip(R8_STATE, x.state, self.artifact["ranges"])
                   if not low - 1e-9 <= value <= high + 1e-9]
        count = self.artifact["bins"].get(_full_plan_bin(x), 0)
        if count < 3:
            reasons.append("cell_pressure_plan_count_below_3")
        for name, (low, high) in zip(("arrival_rate", "mean_offer_cost"),
                                    self.artifact["law_ranges"]):
            if not low - 1e-9 <= getattr(x, name) <= high + 1e-9:
                reasons.append("range:" + name)
        raw = [_direct_mean(m, full_plan_features(x, h))
               for m, h in zip(self.artifact["models"], OFFSETS)]
        good, previous = [], 0.
        for value in raw:
            previous = max(previous, value)
            good.append(previous)
        warnings = []
        if x.collector_id not in self.artifact["collectors"]:
            warnings.append("collector_ACK_hold_transport_unqualified")
        if x.availability != "receipt-verified":
            warnings.append("controller_client_history_receipts_unverified")
        return dict(good=good, raw_good=raw,
                    expected_offers=[x.arrival_rate * h for h in OFFSETS],
                    support_reasons=reasons, support_bin_rows=count, warnings=warnings,
                    calibrated=False, active_permit=False)


def _r8_loader(path):
    import importlib.util
    from pathlib import Path
    path = Path(path)
    _require(hashlib.sha256(path.read_bytes()).hexdigest() == R8_LOADER_SHA,
             "frozen R7 loader hash")
    spec = importlib.util.spec_from_file_location("astra_frozen_opus_r7", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _r8_execution(document, index):
    """Verify holds as observations of a prior CAS, never as new acknowledgments."""
    acknowledgments, held, failures, retries = {}, [], 0, 0
    assignments = {s["at_s"]: s["budget"] for s in document["schedule"]}
    events = [(None, document["preassignment"])]
    events += [(a["at_s"], a["attempts"]) for a in document["actions"]]
    covered = []
    for at, attempts in events:
        retries += len(attempts) > 1
        if at is not None:
            covered.append(at)
        for attempt in attempts:
            reply = attempt["reply"]
            if reply.get("status") != "applied":
                continue
            ack, command = reply["acknowledgment"], reply["command"]
            _require(ack["run_id"] == command["run_id"] == document["gateway_run_id"]
                     and ack["clock_domain"] == command["clock_domain"] == index["clock_domain"]
                     and command["identity"] == index["model_identity"]
                     and ack["operation_id"] == command["operation_id"]
                     and ack["budget"] == command["budget"] == assignments[0 if at is None else at]
                     and ack["budget_version"] == command["expected_version"] + 1
                     and ack["applied_at"] <= min(command["not_after"], attempt["received_at"]),
                     "CAS receipt mismatch")
            acknowledgments[ack["operation_id"]] = ack
        failures += attempts[-1]["reply"].get("status") != "applied"
    for hold in document.get("held_assignments", []):
        covered.append(hold["at_s"])
        obs = hold["state_observation"]
        ack = acknowledgments.get(hold["reference_operation_id"])
        current = [a for a in acknowledgments.values() if a["applied_at"] <= obs["sampled_at"]]
        _require(hold["status"] == "confirmed_hold" and ack is not None and current
                 and ack == max(current, key=lambda a: a["applied_at"])
                 and ack["budget"] == hold["budget"] == assignments[hold["at_s"]]
                 and ack["budget_version"] == hold["budget_version"] == obs["budget_version"]
                 and ack["run_id"] == hold["run_id"] == obs["run_id"] == document["gateway_run_id"]
                 and ack["clock_domain"] == hold["clock_domain"] == obs["clock_domain"]
                 == index["clock_domain"]
                 and obs["get_started_at"] <= obs["sampled_at"] <= obs["get_received_at"]
                 <= hold["confirmed_at"]
                 and document["start"] + hold["at_s"] <= hold["confirmed_at"],
                 "confirmed hold lineage mismatch")
        held.append([hold["at_s"], hold["budget"], hold["budget_version"],
                     hold["reference_operation_id"], hold["confirmed_at"]])
    _require(sorted(covered) == sorted(at for at in assignments if at != 0),
             "assignment coverage or duplicate hold")
    return dict(applied_operations=len(acknowledgments), confirmed_holds=held,
                failed_assignments=failures, retried_assignments=retries,
                holds_are_not_new_CAS=True)


def _r8_archive(path, allowed, loader):
    from pathlib import Path
    root = Path(path)
    index_path = root / "latest-index.json"
    if not index_path.exists():
        index_path = root / "index.json"
    index = json.loads(index_path.read_text())
    _require(R8_SOURCES.get(index["source_commit"]) == (
        index["collector_sha256"], index["gpu_environment"]["native_launch"]["source_commit"])
        and index["implementation_hash"] == index["model_identity"]["implementation_hash"]
        == R8_CORE, "unverified archive source binding")
    listed = [json.loads(s) for s in (root / "verified-artifact-sha256.jsonl").read_text()
              .splitlines() if s.strip()]
    names = {}
    for entry in listed:
        name = entry["artifact"]
        _require(Path(name).name == name and name.startswith("nv3-")
                 and int(name.split("-")[1]) in allowed, "archive scope")
        _require(hashlib.sha256((root / name).read_bytes()).hexdigest() == entry["sha256"],
                 "archive hash")
        names[name] = entry["sha256"]
    documents, episodes, execution = {}, [], {}
    for name in sorted(names):
        if not name.endswith(".json"):
            continue
        d = json.loads((root / name).read_text())
        _require(d["split"] == "train" and d["seed_block"] in allowed
                 and d["duration_s"] == 120, "complete Train episode")
        execution[d["episode_id"]] = _r8_execution(d, index)
        e = loader.episode_from_replica(d, index)
        for observation in e["observations"]:
            cost_bytes = json.dumps({"formula": "max-min-affine-v1",
                                     **observation["gateway"]["cost_spec"]}, sort_keys=True,
                                    separators=(",", ":"), allow_nan=False).encode()
            _require(hashlib.sha256(cost_bytes).hexdigest() == index["model_identity"]["cost_hash"],
                     "cost specification fingerprint")
        e["arm"] = d["arm"]
        documents[e["episode_id"]] = d
        episodes.append(e)
    for block in allowed:
        subset = [e for e in episodes if e["seed_block"] == block]
        _require(len(subset) == 10 and len({(e["cell"], e["arm"]) for e in subset}) == 10
                 and len({e["cell"] for e in subset}) == 5, "incomplete Train block")
    observers = sorted({e["observer_sha256"] for e in episodes})
    source = dict(core=index["implementation_hash"], cost=index["model_identity"]["cost_hash"],
                  native=index["gpu_environment"]["native_launch"]["source_commit"],
                  observers=observers)
    compatibility = dict(core=source["core"], cost=source["cost"], observers=observers,
                         software=index["gpu_environment"]["software"],
                         model_snapshot=index["gpu_environment"]["model_snapshot"],
                         launch_arguments=index["gpu_environment"]["native_launch"]["arguments"])
    source_id = hashlib.sha256(json.dumps(compatibility, sort_keys=True).encode()).hexdigest()
    receipt = dict(source=source, source_id=source_id, collector=index["source_commit"],
                   collector_sha256=index["collector_sha256"],
                   controller=index["controller_version"], clock=index["clock_domain"],
                   model_identity=index["model_identity"],
                   index_sha256=hashlib.sha256(index_path.read_bytes()).hexdigest(),
                   compatibility_metadata=compatibility, execution=execution,
                   native_binary_equivalence_verified=False,
                   artifacts=names, unavailable_frames=sum(e["unavailable_frames"] for e in episodes))
    return episodes, documents, receipt


def _r8_prefix(e, s, receipt, obs):
    # Admission rejection is classified only once the terminal is observable.
    gateway = dict(s["gateway"])
    gateway["hist_ttft_miss"] = float(sum(
        r.get("terminal_at") is not None and s["t0"] - 2 < r["terminal_at"] <= s["t0"]
        and not r.get("admission_rejection")
        and (r.get("first_content_at") is None
             or r["first_content_at"] > r["scheduled_at"] + .5)
        for r in e["client_rows"]))
    s = dict(s, gateway=gateway)
    _require(obs["native_received_at"] <= s["t0"] + 1e-9, "selected prefix absent")
    remaining = 0.
    for r in obs["native"]["requests"]:
        _require(type(r.get("computed_tokens")) is int and r["computed_tokens"] >= 0,
                 "raw computed_tokens missing")
        remaining += max(0, r["prompt_tokens"] - r["computed_tokens"]) / 1000.
    spec = obs["gateway"]["cost_spec"]
    recent = [r for r in e["client_rows"] if s["t0"] - 2 < r["sent_at"] <= s["t0"]]
    costs = []
    for r in recent:
        maximum = r["requested_max_tokens"]
        if e["cell"] == "mixed":
            _require(maximum in (128, 256), "mixed payload family")
            prompt = 128 if maximum == 256 else 4096
        else:
            prompt = int(e["cell"].split("-")[0][1:])
        costs.append(max(spec["minimum"], spec["intercept"] + spec["input_per_token"] * prompt
                         + spec["output_per_token"] * maximum))
    state = {**gateway, **s["native"], "prefill_remaining_k": remaining}
    x = FullPlanInput(s["t0"], obs["native_received_at"], tuple(state[n] for n in R8_STATE),
                      len(recent) / 2., statistics.fmean(costs) if costs else spec["minimum"],
                      tuple((float(j), int(s["plan"][2 * j])) for j in range(5)),
                      e["cell"], receipt["source_id"], receipt["collector"])
    _full_plan_check(x)
    return s, x


def _r8_rows(episodes, documents, receipt, loader, stride):
    records, masks, join_stats = [], [], {}
    for e in episodes:
        steps, good, rows = loader.joint_steps(e, with_rows=True)
        origins, parsed, stats = loader.build_origins(dict(e, origin_grid_s=.5))
        observations = {o["grid_index"]: parsed[o["index"]][1] for o in origins}
        join_stats[e["episode_id"]] = stats
        by_k = {s["k"]: s for s in steps}
        good_times = [t for t, _ in good]
        for k in range(0, int(e["duration_s"] * 2) + 1, stride):
            reasons, s = [], by_k.get(k)
            if k < 4:
                reasons.append("two_second_history_incomplete")
            if k / 2 + 5 > e["duration_s"]:
                reasons.append("five_second_label_censored")
            if s is None:
                reasons.append("no_qualified_join_at_cut")
            elif s["outstanding"]:
                reasons.append("outstanding_prior_action")
            path = loader._actual_path(by_k, s, 10) if s else None
            if path is None:
                reasons.append("complete_future_label_path_missing")
            if reasons:
                masks.append([e["episode_id"], k, reasons])
                continue
            labels = [loader._horizon_good(s, good_times, good, h) for h in OFFSETS]
            _require(all(len(label[0]) == path[int(2 * h) - 1]["good"]
                         for h, label in zip(OFFSETS, labels)), "full-good label mismatch")
            try:
                s, x = _r8_prefix(e, s, receipt, observations[k])
            except ValueError as error:
                masks.append([e["episode_id"], k, [str(error)]])
                continue
            records.append(dict(e=e, s=s, x=x, rows=rows, labels=labels,
                                y=tuple(float(len(label[0])) for label in labels)))
    return records, masks, join_stats


def _r8_comparators(train, loader):
    table = loader.fit_progress_hazard([
        (h, loader.id_progress_state(r["s"], rid, r["rows"][rid]), int(rid in labels[0]))
        for r in train for h, labels in zip(OFFSETS, r["labels"]) for rid in r["s"]["cohort"]])
    models = []
    for j, h in enumerate(OFFSETS):
        ys = [{"cohort": float(r["labels"][j][1]), "birth": float(r["labels"][j][2])}
              for r in train]
        aggregate = loader.fit_ridge([loader._vector(r["s"], False) for r in train],
                                     ys, ("cohort",))
        birth = loader.fit_ridge([loader._exo_vector(r["s"], r["x"].arrival_rate / 2.)
                                  for r in train], ys, ("birth",))
        additive = loader.fit_ridge([loader.plan_inputs(r["s"], h, "full_plan") for r in train],
                                     ys, ("birth",))
        models.append((aggregate, birth, additive))
    return table, models


def _r8_compare(r, comparators, loader):
    table, models = comparators
    values = dict(history=[], aggregate_hybrid=[], old_additive=[])
    for h, (aggregate, birth, additive) in zip(OFFSETS, models):
        cohort = max(0., min(float(len(r["s"]["cohort"])),
                             loader.ridge_predict(aggregate, loader._vector(r["s"], False))["cohort"]))
        b = max(0., loader.ridge_predict(
            birth, loader._exo_vector(r["s"], r["x"].arrival_rate / 2.))["birth"])
        p = math.fsum(loader.progress_probability(table, h, loader.id_progress_state(
            r["s"], rid, r["rows"][rid]))[0] for rid in sorted(r["s"]["cohort"]))
        a = max(0., loader.ridge_predict(
            additive, loader.plan_inputs(r["s"], h, "full_plan"))["birth"])
        values["history"].append(r["s"]["gateway"]["hist_good"] * h / 2.)
        values["aggregate_hybrid"].append(cohort + b)
        values["old_additive"].append(p + a)
    return values


def _r8_metrics(rows):
    from collections import defaultdict
    level, paired = defaultdict(lambda: defaultdict(list)), defaultdict(lambda: defaultdict(list))
    lookup = {(r["cell"], r["arm"], r["k"]): r for r in rows}
    for r in rows:
        for name, pred in r["predictions"].items():
            for j, h in enumerate(OFFSETS):
                level[f"{name}|{h:g}"][r["episode"]].append(abs(pred[j] - r["truth"][j]))
        if r["arm"] != 0:
            continue
        other = lookup.get((r["cell"], 1, r["k"]))
        if other is None:
            continue
        for j, h in enumerate(OFFSETS):
            delta = r["truth"][j] - other["truth"][j]
            paired[f"zero|{h:g}"][r["cell"]].append(abs(delta))
            for name in r["predictions"]:
                predicted = r["predictions"][name][j] - other["predictions"][name][j]
                paired[f"{name}|{h:g}"][r["cell"]].append(abs(predicted - delta))
    mean = lambda groups: {key: statistics.fmean(statistics.fmean(v) for v in cells.values())
                            for key, cells in sorted(groups.items())}
    return dict(level_mae=mean(level), paired_factual_difference_mae=mean(paired),
                origins=len(rows), pairs=sum(
                    r["arm"] == 0 and (r["cell"], 1, r["k"]) in lookup for r in rows))


def run_r8(train_path, evaluate_path, loader_path, sealed_commit):
    """One frozen fit and one evaluation pass; all output is returned as JSON data."""
    import subprocess
    from pathlib import Path
    source_path = "experiments/mpc-research/native-v3/native_response_planner.py"
    sealed = subprocess.check_output(["git", "show", f"{sealed_commit}:{source_path}"])
    _require(hashlib.sha256(sealed).digest() == hashlib.sha256(Path(__file__).read_bytes()).digest(),
             "model source differs from sealed commit")
    loader = _r8_loader(loader_path)
    episodes, documents, receipt = _r8_archive(train_path, R8_TRAIN, loader)
    train, excluded, joins = _r8_rows(episodes, documents, receipt, loader, 2)
    fitted = FittedFullPlanResponse.fit([(r["e"]["seed_block"], r["x"], r["y"]) for r in train])
    comparators = _r8_comparators(train, loader)
    # No evaluation archive is opened until the complete fit above has finished.
    fresh, fresh_documents, fresh_receipt = _r8_archive(evaluate_path, R8_EVALUATE, loader)
    dev, dev_excluded, dev_joins = _r8_rows(fresh, fresh_documents, fresh_receipt, loader, 4)
    out = dict(schema=R8_VERSION, sealed_commit=sealed_commit,
               source_sha256=hashlib.sha256(sealed).hexdigest(),
               loader_sha256=R8_LOADER_SHA, fitted=fitted.artifact,
               train_receipt=receipt, evaluation_receipt=fresh_receipt,
               train_masks=excluded, train_join_stats=joins,
               train_origin_ids=[[r["e"]["episode_id"], r["s"]["k"]] for r in train],
               evaluation_join_stats=dev_joins, blocks={},
               availability="client-local timestamp prefixes reconstructed; controller publication unverified",
               metric="full API-stop/SLO good terminals in (cut,cut+h]; not physical EOS verification",
               active_permit=False, calibrated=False)
    for block in R8_EVALUATE:
        forecasts = []
        for r in dev:
            if r["e"]["seed_block"] != block:
                continue
            p = fitted.predict(r["x"])
            predictions = _r8_compare(r, comparators, loader)
            predictions["direct_headroom"] = p["good"]
            forecasts.append(dict(episode=r["e"]["episode_id"], cell=r["e"]["cell"],
                                   arm=r["e"]["arm"], k=r["s"]["k"], truth=r["y"],
                                   predictions=predictions, raw_direct=p["raw_good"],
                                   offers=p["expected_offers"], support=p["support_reasons"],
                                   support_rows=p["support_bin_rows"], warnings=p["warnings"],
                                   unknown_native_cost_fraction=r["s"]["native"]["native_unknown_frac"],
                                   plan=r["x"].timed_plan))
        out["blocks"][str(block)] = dict(
            all_matched=_r8_metrics(forecasts),
            supported_only=_r8_metrics([r for r in forecasts if not r["support"]]),
            excluded=[m for m in dev_excluded if m[0].startswith(f"nv3-{block}-")],
            rows=forecasts)
    out["block_sha256"] = {
        block: hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                        allow_nan=False).encode()).hexdigest()
        for block, value in out["blocks"].items()}
    return out


R9_V5_SHA = "b1d83f7af2956d51b5f9d9b014ecff50b2b3a6915c5f10cdb52f034ed8a920b5"
R9_VERSION = "astra-v5-mean-only-enumeration-v1"
R9_DEADLINE_S = .1
R9_SCENARIOS = 32
R9_ONE_MOVE = tuple((a, b, b, b, b) for a, b in product(CAPS, repeat=2))
R9_ALL_PLANS = tuple(product(CAPS, repeat=5))


def _immutable(value):
    if isinstance(value, (dict, MappingProxyType)):
        return MappingProxyType({k: _immutable(v) for k, v in value.items()})
    if isinstance(value, (tuple, list)):
        return tuple(_immutable(v) for v in value)
    if isinstance(value, set):
        return frozenset(value)
    return value


def _kernel_hash(kernels, costs):
    def tree(value):
        if isinstance(value, dict):
            return [[repr(k), tree(v)] for k, v in sorted(value.items(), key=lambda p: repr(p[0]))]
        if isinstance(value, (tuple, list)):
            return [tree(v) for v in value]
        return value
    return hashlib.sha256(json.dumps(tree([kernels, costs]), separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


class FrozenV5MeanScorer:
    """Source-pinned adapter; accepts the unchanged already-fitted empirical kernels."""

    def __init__(self, module, kernels, costs, support):
        from pathlib import Path
        _require(hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest() == R9_V5_SHA
                 and module.ADMISSION_VERSION == "nv3-opus-admission-birth-v5"
                 and module.SIM_SCENARIOS == R9_SCENARIOS, "v5 source mismatch")
        self.module = module
        self.source_sha = R9_V5_SHA
        self.clock_domain = module.COMMON_BINDING["clock_domain"]
        self.cost_hash = module.COMMON_BINDING["cost_hash"]
        self.kernel_id = _kernel_hash(kernels, costs)
        self.kernels, self.costs, self.support = (
            _immutable(kernels), _immutable(costs), _immutable(support))

    def support_reasons(self, step):
        return self.module.joint_ood(step, self.support)

    def draw(self, cut, key, scenario):
        return self.module.draw_common_law(cut, key, scenario)

    def score(self, cut, plan, draw):
        expanded = tuple(cap for cap in plan for _ in range(2))
        return self.module.simulate_plan(cut, expanded, draw, self.kernels, self.costs)


@dataclass(frozen=True)
class MeanPlanRequest:
    state_id: str
    identity: Identity
    native_run_id: str
    sampled_at: float
    received_at: float
    key: str
    step: dict
    cut: dict
    original_costs: tuple[tuple[str, float], ...]


def _mean_plan_tie(plan, incumbent):
    variation = sum(a != b for a, b in zip((incumbent,) + plan, plan))
    return (plan[0] != incumbent, variation, plan)


def optimize_v5_mean(request, scorer, *, enabled=False, deadline_at=None,
                     now=time.perf_counter):
    """Finite, mean-only research candidates. Never an actuation or risk permit.

    Deadline uses the caller's local monotonic stopwatch, not the archived Pod clock.
    Checks are cooperative around draw/simulation calls, not callback preemption.
    """
    started, cpu_started = now(), time.process_time()
    scores, draws, error, status = [], [], None, "inactive"
    last_clock = started
    one_complete = full_complete = False

    def check_time():
        nonlocal last_clock
        stamp = now()
        _require(isfinite(stamp) and stamp >= last_clock, "solver clock regressed")
        last_clock = stamp
        if stamp >= deadline_at:
            raise TimeoutError("cooperative deadline")

    def result():
        one = full = None
        if one_complete:
            eligible = [r for r in scores if tuple(r["plan"]) in R9_ONE_MOVE]
            one = min(eligible, key=lambda r: (-r["mean_good"][2],
                                             _mean_plan_tie(tuple(r["plan"]), incumbent)))
        if full_complete:
            full = min(scores, key=lambda r: (-r["mean_good"][2],
                                             _mean_plan_tie(tuple(r["plan"]), incumbent)))
        comparative = one is not None and full is not None
        finished = now()
        final_status, final_reason = status, error
        if final_status == "experimental_candidate" and finished >= deadline_at:
            final_status, final_reason = "deadline", "final return deadline"
        if not isfinite(finished) or finished < last_clock:
            final_status, final_reason = "unsupported", "solver clock regressed"
        return dict(
            status=final_status, reason=final_reason, state_id=request.state_id,
            active_permit=False, risk_coverage_certified=False,
            candidate_first_action=full["plan"][0] if final_status == "experimental_candidate" else None,
            one_move=one, mpc=full, completed_plans=len(scores), completed_draws=len(draws),
            pair_family_support=dict(one_complete=one_complete, mpc_complete=full_complete,
                                     conditional_causal_support="unqualified"),
            implied_gain=full["mean_good"][2] - one["mean_good"][2] if comparative else None,
            first_action_differs=full["plan"][0] != one["plan"][0] if comparative else None,
            wall_s=finished - started if isfinite(finished) and finished >= started else None,
            cpu_s=time.process_time() - cpu_started,
            budget_s=deadline_at - started if type(deadline_at) in (float, int)
            and isfinite(deadline_at) else None,
            source_sha=getattr(scorer, "source_sha", None),
            kernel_id=getattr(scorer, "kernel_id", None), scores=scores)

    incumbent = None
    if enabled is not True:
        return result()
    try:
        _require(type(deadline_at) in (float, int) and isfinite(deadline_at), "deadline required")
        check_time()
        _require(scorer.source_sha == R9_V5_SHA and bool(scorer.kernel_id), "model source")
        identity = request.identity
        _require(identity.deployment == R8_CORE and identity.cost_model == scorer.cost_hash
                 and identity.clock_domain == scorer.clock_domain
                 and bool(identity.epoch) and bool(request.native_run_id)
                 and bool(request.state_id) and bool(request.key), "source or clock identity")
        step, cut = _immutable(request.step), _immutable(request.cut)
        incumbent = int(step["gateway"]["budget"])
        _require(incumbent in CAPS and incumbent == step["gateway"]["budget"]
                 and cut["t0"] == step["t0"] and cut["cell"] == step["cell"]
                 and all(isfinite(v) for v in (request.sampled_at, request.received_at, cut["t0"]))
                 and request.sampled_at <= request.received_at <= cut["t0"]
                 and 0 <= cut["t0"] - request.sampled_at <= .5, "receipt cut freshness")
        reasons = scorer.support_reasons(step)
        _require(not reasons, "state support:" + ",".join(reasons))
        _require(not step["outstanding"], "outstanding action")
        owners = dict(request.original_costs)
        _require(len(owners) == len(request.original_costs) <= MAX_REQUESTS
                 and set(owners) == set(step["cohort"])
                 and all(type(c) in (float, int) and isfinite(c) and c > 0 for c in owners.values())
                 and math.isclose(math.fsum(owners.values()), step["gateway"]["reserved"],
                                  rel_tol=1e-12, abs_tol=1e-9), "original cost stock")
        _require(len(cut["live"]) == len(owners)
                 and {r[0] for r in cut["live"]} == set(owners)
                 and all(c == owners[rid] for rid, c, _, _ in cut["live"]),
                 "immutable owner costs")
        pending_ids = [r[0] for r in cut["pending"]]
        _require(len(pending_ids) <= MAX_REQUESTS and len(set(pending_ids)) == len(pending_ids)
                 and not set(pending_ids) & set(owners), "pending identity overlap")
        _require(type(cut["law"]) in (float, int) and isfinite(cut["law"])
                 and 0 <= cut["law"] <= 64
                 and len(cut["mix"]) <= 16 and (cut["law"] == 0 or bool(cut["mix"]))
                 and all(type(n) is int and n > 0 and
                         isfinite(scorer.costs[(cut["cell"], cls)]) and
                         scorer.costs[(cut["cell"], cls)] > 0 for cls, n in cut["mix"]),
                 "bounded common law")
        _require(all(c == scorer.costs[(cut["cell"], cls)] and isfinite(age) and 0 <= age <= 30
                     for _, c, cls, age in cut["pending"]), "pending cost or age")
        for scenario in range(R9_SCENARIOS):
            check_time()
            draw = _immutable(scorer.draw(cut, request.key, scenario))
            check_time()
            _require(len(draw["arrivals"]) <= 512
                     and len(draw["live_u"]) == len(cut["live"])
                     and len(draw["pending_u"]) == len(cut["pending"]), "scenario work bound")
            draws.append(draw)
        # Complete the same four baseline plans first; never recommend a partial full family.
        order = sorted(R9_ONE_MOVE, key=lambda p: _mean_plan_tie(p, incumbent))
        order += [p for p in R9_ALL_PLANS if p not in R9_ONE_MOVE]
        common_offers = None
        for plan in order:
            plan_started, goods, offers = now(), [], []
            for draw in draws:
                check_time()
                run = scorer.score(cut, plan, draw)
                check_time()
                g = [run[f"good_{h:g}"] for h in OFFSETS]
                o = [run[f"offers_{h:g}"] for h in OFFSETS]
                _require(all(type(v) in (float, int) and isfinite(v) and v >= 0 and v == int(v)
                             for v in g + o)
                         and g == sorted(g) and o == sorted(o)
                         and g[-1] <= len(owners) + len(pending_ids) + len(draw["arrivals"])
                         and o == [sum(t <= h + 1e-9 for t, _, _ in draw["arrivals"])
                                   for h in OFFSETS], "incoherent scenario")
                goods.append(g)
                offers.append(o)
            if common_offers is None:
                common_offers = offers
            _require(offers == common_offers, "candidate-dependent offered law")
            scores.append(dict(plan=plan,
                               mean_good=[math.fsum(g[j] for g in goods) / R9_SCENARIOS
                                          for j in range(3)],
                               wall_s=now() - plan_started))
            one_complete = len(scores) >= len(R9_ONE_MOVE)
        full_complete = True
        status = "experimental_candidate"
        check_time()
    except TimeoutError as exc:
        status, error = "deadline", str(exc)
    except (ValueError, KeyError, TypeError, OverflowError, AttributeError) as exc:
        status, error = "unsupported", f"{type(exc).__name__}:{exc}"
    return result()


def _r9_loader(path):
    import importlib.util
    from pathlib import Path
    _require(hashlib.sha256(Path(path).read_bytes()).hexdigest() == R9_V5_SHA, "frozen v5 hash")
    spec = importlib.util.spec_from_file_location("astra_frozen_opus_v5", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_r9(train_path, evaluate_path, loader_path):
    from collections import Counter, defaultdict
    from pathlib import Path
    module = _r9_loader(loader_path)
    setup_started = time.perf_counter()
    train_eps, _, train_receipt = _r8_archive(train_path, R8_TRAIN, module)
    eval_eps, eval_docs, eval_receipt = _r8_archive(evaluate_path, (181006, 181007), module)
    for path, episodes, documents in ((train_path, train_eps, None),
                                      (evaluate_path, eval_eps, eval_docs)):
        source, index = module.bind_source(Path(path))
        if documents is not None:
            for document in documents.values():
                module.bind_assignments(document, module.SOURCE_BINDINGS[source]["holds"],
                                        index["clock_domain"])
    entries = module._r8_entries(train_eps)
    costs = module.payload_costs(train_eps)
    _require(all(abs(costs.get(k, math.inf) - v) <= 1e-9
                 for k, v in module.payload_costs(eval_eps).items()), "payload cost source shift")
    kernels = module.fit_admission_kernels(entries)
    train_rows = module._progress_rows(entries)
    support = module.joint_support([s for _, s, _, _ in train_rows])
    scorer = FrozenV5MeanScorer(module, kernels, costs, support)
    setup_s = time.perf_counter() - setup_started
    blocks, excluded, equivalence = defaultdict(list), [], []
    for e, steps, good, rows in module._r8_entries(eval_eps):
        by_k = {s["k"]: s for s in steps}
        raw = {r["request_id"]: r for r in e["client_rows"]}
        order = sorted((r["sent"], rid) for rid, r in rows.items())
        by_class = defaultdict(list)
        for stamp, rid in order:
            by_class[module.payload_class(raw[rid])].append(stamp)
        sent_index = ([t for t, _ in order], [rid for _, rid in order], dict(by_class))
        labelled = {s["k"]: labels for _, s, _, labels in
                    module._progress_rows([(e, steps, good, rows)])}
        origins, parsed, _ = module.build_origins(dict(e, origin_grid_s=.5))
        observations = {o["grid_index"]: parsed[o["index"]][1] for o in origins}
        verified_episode = False
        for s in steps:
            if s["k"] % 4:
                continue
            reasons = []
            if s["previous_labels"] is None or s["k"] not in labelled:
                reasons.append("no_previous_or_current_labels")
            elif len(labelled[s["k"]]) != 3:
                reasons.append("horizon_beyond_episode")
            reasons += module.joint_ood(s, support)
            if module._actual_path(by_k, s, 10) is None:
                reasons.append("actual_path_unavailable")
            if reasons:
                excluded.append([e["episode_id"], s["k"], reasons])
                continue
            adapter_started = time.perf_counter()
            cut = module.admission_cut_state(s, rows, raw, costs, sent_index)
            obs = observations[s["k"]]
            key = f"{e['seed_block']}|{e['cell']}|{s['k']}"
            request = MeanPlanRequest(
                f"{e['episode_id']}:{s['k']}:{obs['gateway']['sequence']}",
                Identity(R8_CORE, e["run_id"], e["clock_domain"], scorer.cost_hash),
                e["native_run_id"], obs["gateway"]["sampled_at"], obs["native_received_at"],
                key, s, cut, tuple((m["request_id"], m["cost"])
                                  for m in obs["gateway"]["requests"]))
            adapter_s = time.perf_counter() - adapter_started
            result = optimize_v5_mean(request, scorer, enabled=True,
                                      deadline_at=time.perf_counter() + R9_DEADLINE_S)
            if result["one_move"] is not None and not verified_episode:
                p = result["one_move"]["plan"]
                reference = module.admission_birth_response(
                    cut, [u for u in p for _ in range(2)], key, kernels, costs)
                _require(result["one_move"]["mean_good"] ==
                         [reference[f"good_{h:g}"]["mean"] for h in OFFSETS],
                         "cached CRN differs from frozen v5 response")
                equivalence.append([e["episode_id"], s["k"], list(p)])
                verified_episode = True
            result.update(episode=e["episode_id"], k=s["k"], cell=e["cell"],
                          adapter_s=adapter_s, incumbent=int(s["gateway"]["budget"]),
                          live=len(cut["live"]), pending=len(cut["pending"]),
                          unknown_native_cost_fraction=s["native"]["native_unknown_frac"])
            blocks[str(e["seed_block"])].append(result)
    summaries = {}
    for block, results in blocks.items():
        def duration(name):
            values = sorted(r[name] for r in results)
            return dict(n=len(values), min=values[0], median=statistics.median(values),
                        p95=values[math.ceil(.95 * len(values)) - 1], max=values[-1])
        complete = [r for r in results if r["pair_family_support"]["mpc_complete"]]
        summaries[block] = dict(
            statuses=dict(Counter(r["status"] for r in results)),
            wall_s=duration("wall_s"), cpu_s=duration("cpu_s"),
            exceeds_100ms=sum(r["wall_s"] > .1 for r in results),
            one_complete=sum(r["pair_family_support"]["one_complete"] for r in results),
            both_complete=len(complete),
            first_action_differences=[r["state_id"] for r in complete if r["first_action_differs"]],
            mean_implied_gain=statistics.fmean(r["implied_gain"] for r in complete) if complete else None,
            max_implied_gain=max((r["implied_gain"] for r in complete), default=None))
    return dict(schema=R9_VERSION, source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                v5_source_sha256=R9_V5_SHA, kernel_id=scorer.kernel_id,
                train_receipt=train_receipt, evaluation_receipt=eval_receipt,
                setup_s=setup_s, deadline_s=R9_DEADLINE_S, scenarios=R9_SCENARIOS,
                excluded=excluded, reference_equivalence_checks=equivalence,
                summary=summaries, blocks=dict(blocks),
                active_permit=False, risk_coverage_certified=False)


R10_VERSION = "astra-frozen-v5-exact-prefix-v1"


class FrozenV5PrefixScorer(FrozenV5MeanScorer):
    """Exact prefix reuse of v5, including its known cyclic-survivor approximation.

    Cache ownership is one deeply immutable solver cut and its actual draw objects,
    not a caller-supplied key. Direct callers must use _immutable on both inputs.
    """

    def __init__(self, module, kernels, costs, support, *, trace=False):
        super().__init__(module, kernels, costs, support)
        self.trace = trace
        self._cut = None
        self._draws = {}
        self.prefix_evaluations = 0

    def _root(self, cut, draw):
        import heapq
        m = self.module
        heap, good, events = [], [], [[] for _ in range(5)]
        for (rid, cost, _, keys), u in zip(cut["live"], draw["live_u"]):
            (rel, g, _), _ = m.kernel_draw(self.kernels["cohort"], keys, u)
            heapq.heappush(heap, (rel, rid, cost))
            if g is not None:
                good.append(g)
        all_events = [(0., "pending", rid, cls, cost, age, u)
                      for (rid, cost, cls, age), u in zip(cut["pending"], draw["pending_u"])]
        all_events += [(t, "offer", f"new{i}", cls, self.costs[(cut["cell"], cls)], 0., u)
                       for i, (t, cls, u) in enumerate(draw["arrivals"])]
        previous = -1
        for event in all_events:
            j = min(max(int(math.ceil(event[0] / m.STEP_S - m.EPS)) - 1, 0),
                    m.ROLLOUT_STEPS - 1) // 2
            _require(j >= previous, "nonchronological v5 events")
            previous = j
            events[j].append(event)
        return events, (heap, good, [], [], 0., ())

    def _advance(self, cut, parent, events, cap):
        import heapq
        m = self.module
        old_heap, old_good, old_rejected, old_offers, maximum, old_marks = parent
        heap, good, rejected, offers = (
            list(old_heap), list(old_good), list(old_rejected), list(old_offers))
        marks = []
        for a, kind, rid, cls, cost, age, u in events:
            while heap and heap[0][0] <= a + m.EPS:
                heapq.heappop(heap)
            if kind == "offer":
                offers.append(a)
            reserved = math.fsum(c for _, _, c in heap)
            admitted = reserved + cost <= cap + m.EPS
            mark = dict(t=a, kind=kind, id=rid, cost=cost, reserved=reserved,
                        load=len(heap), cap=cap, admitted=admitted) if self.trace else None
            if not admitted:
                rejected.append(a)
            else:
                keys = [(cut["cell"], cls, m._load_bin(len(heap))), (cut["cell"], cls)]
                (dur, g, terminal), level = m.kernel_draw(
                    self.kernels["birth"], keys, u,
                    min_alive=age if kind == "pending" else None)
                heapq.heappush(heap, (a - age + dur, rid, cost))
                maximum = max(maximum, reserved + cost)
                if g is not None and a - age + g > 0:
                    good.append(a - age + g)
                if mark is not None:
                    mark.update(release=a - age + dur, good=None if g is None else a - age + g,
                                terminal=a - age + terminal, backoff_level=level)
            if mark is not None:
                marks.append(mark)
        self.prefix_evaluations += 1
        return heap, good, rejected, offers, maximum, old_marks + tuple(marks)

    def _node(self, cut, plan, draw):
        _require(type(cut) is MappingProxyType and type(draw) is MappingProxyType,
                 "prefix cache requires immutable solver inputs")
        _require(len(plan) == 5 and all(c in CAPS for c in plan), "five-slot plan")
        if cut is not self._cut:
            self._cut, self._draws = cut, {}
            self.prefix_evaluations = 0
        entry = self._draws.get(id(draw))
        if entry is None:
            events, root = self._root(cut, draw)
            entry = (draw, events, {(): root})
            self._draws[id(draw)] = entry
        _, events, nodes = entry
        prefix = ()
        for j, cap in enumerate(plan):
            child = prefix + (cap,)
            if child not in nodes:
                nodes[child] = self._advance(cut, nodes[prefix], events[j], cap)
            prefix = child
        return nodes[prefix]

    def score(self, cut, plan, draw):
        _, good, rejected, offers, maximum, _ = self._node(cut, plan, draw)
        out = {}
        for h in self.module.SIM_HORIZONS:
            out[f"good_{h:g}"] = float(sum(0 < g <= h + self.module.EPS for g in good))
            out[f"rejected_{h:g}"] = float(sum(r <= h + self.module.EPS for r in rejected))
            out[f"offers_{h:g}"] = float(sum(o <= h + self.module.EPS for o in offers))
        out["max_reserved_after_admission"] = maximum
        return out

    def path_evidence(self, cut, plan, draw):
        _require(self.trace, "trace not enabled")
        heap, good, _, _, _, marks = self._node(cut, plan, draw)
        return dict(events=marks, good_after_5=sum(g > 5 + self.module.EPS for g in good),
                    end_stock=math.fsum(c for rel, _, c in heap if rel > 5 + self.module.EPS),
                    total_drawn_good=sum(g > 0 for g in good))


def _r10_ranking(result):
    scores = result["scores"]
    if not result["pair_family_support"]["mpc_complete"]:
        return None
    one, full = result["one_move"], result["mpc"]
    best = {a: max(r["mean_good"][2] for r in scores if r["plan"][0] == a) for a in CAPS}
    one_best = {a: max(r["mean_good"][2] for r in scores
                       if tuple(r["plan"]) in R9_ONE_MOVE and r["plan"][0] == a) for a in CAPS}
    return dict(first_differs=full["plan"][0] != one["plan"][0],
                tail_differs=full["plan"][1:] != one["plan"][1:],
                one_plan=one["plan"], full_plan=full["plan"],
                one_good=one["mean_good"], full_good=full["mean_good"],
                gain=full["mean_good"][2] - one["mean_good"][2],
                full_first32_minus16=best[32] - best[16],
                one_first32_minus16=one_best[32] - one_best[16],
                tail_lift_by_first={a: best[a] - one_best[a] for a in CAPS},
                tied_full_plans=sum(r["mean_good"][2] == full["mean_good"][2] for r in scores),
                last_slot_ties=sum(next(r["mean_good"][2] for r in scores if tuple(r["plan"]) == p)
                                   == next(r["mean_good"][2] for r in scores
                                           if tuple(r["plan"]) == p[:-1] + (32,))
                                   for p in R9_ALL_PLANS if p[-1] == 16))


def r10_saved_rankings(report):
    """Read the authoritative historical pass; never convert censored cuts to ties."""
    section = report.rsplit("\n## R9 generated complete raw JSON\n", 1)[1]
    raw = section.split("```json\n", 1)[1].split("\n```", 1)[0]
    _require(hashlib.sha256(raw.encode()).hexdigest() ==
             "ac99ec8214f230e705ed7866cb9eb1de4101fefbf91478fb39228f826f65bd23",
             "authoritative R9 receipt")
    data = json.loads(raw)
    return {b: [dict(state_id=r["state_id"], status=r["status"], ranking=_r10_ranking(r))
                for r in rows] for b, rows in data["blocks"].items()}


def r10_saved_diagnostic(report):
    from collections import Counter
    blocks, summary = r10_saved_rankings(report), {}
    for block, rows in blocks.items():
        complete = [r["ranking"] for r in rows if r["ranking"] is not None]
        margins = [r["full_first32_minus16"] for r in complete]
        summary[block] = dict(
            calls=len(rows), statuses=dict(Counter(r["status"] for r in rows)),
            complete=len(complete), first_disagreements=sum(r["first_differs"] for r in complete),
            tail_disagreements=sum(r["tail_differs"] for r in complete),
            positive_gains=sum(r["gain"] > 0 for r in complete),
            mean_gain=statistics.fmean(r["gain"] for r in complete),
            max_gain=max(r["gain"] for r in complete),
            first32_margin_negative=sum(g < 0 for g in margins),
            first32_margin_zero=sum(g == 0 for g in margins),
            first32_margin_positive=sum(g > 0 for g in margins),
            first32_margin_median=statistics.median(margins),
            last_slot_pairs=16 * len(complete),
            last_slot_ties=sum(r["last_slot_ties"] for r in complete),
            tail_lift_positive_by_first={a: sum(r["tail_lift_by_first"][a] > 0 for r in complete)
                                         for a in CAPS})
    return dict(schema="astra-r10-historical-r9-rankings-v1", summary=summary, blocks=blocks,
                historical_raw_sha256="ac99ec8214f230e705ed7866cb9eb1de4101fefbf91478fb39228f826f65bd23",
                new_model_runs=0, new_solver_measurements=0, active_permit=False)


def _r10_inputs(train_path, evaluate_path, loader_path, saved):
    from collections import defaultdict
    from pathlib import Path
    module = _r9_loader(loader_path)
    train, _, train_receipt = _r8_archive(train_path, R8_TRAIN, module)
    episodes, documents, eval_receipt = _r8_archive(evaluate_path, (181006, 181007), module)
    source, index = module.bind_source(Path(evaluate_path))
    for document in documents.values():
        module.bind_assignments(document, module.SOURCE_BINDINGS[source]["holds"],
                                index["clock_domain"])
    entries = module._r8_entries(train)
    costs = module.payload_costs(train)
    _require(all(abs(costs.get(k, math.inf) - v) <= 1e-9
                 for k, v in module.payload_costs(episodes).items()), "payload cost source shift")
    kernels = module.fit_admission_kernels(entries)
    support = module.joint_support([s for _, s, _, _ in module._progress_rows(entries)])
    base = FrozenV5MeanScorer(module, kernels, costs, support)
    fast = FrozenV5PrefixScorer(module, kernels, costs, support)
    trace = FrozenV5PrefixScorer(module, kernels, costs, support, trace=True)
    _require(base.kernel_id == "02b0376f4534f575bea3a1dca6b70813495ff688571d2e6a383ae3ae22f2878f",
             "unchanged R9 kernel artifact")
    wanted = {r["state_id"] for rows in saved.values() for r in rows}
    requests = []
    for e, steps, _, rows in module._r8_entries(episodes):
        raw = {r["request_id"]: r for r in e["client_rows"]}
        order = sorted((r["sent"], rid) for rid, r in rows.items())
        by_class = defaultdict(list)
        for stamp, rid in order:
            by_class[module.payload_class(raw[rid])].append(stamp)
        sent_index = ([t for t, _ in order], [rid for _, rid in order], dict(by_class))
        origins, parsed, _ = module.build_origins(dict(e, origin_grid_s=.5))
        observations = {o["grid_index"]: parsed[o["index"]][1] for o in origins}
        for step in steps:
            obs = observations[step["k"]]
            state_id = f"{e['episode_id']}:{step['k']}:{obs['gateway']['sequence']}"
            if state_id not in wanted:
                continue
            cut = module.admission_cut_state(step, rows, raw, costs, sent_index)
            requests.append((str(e["seed_block"]), MeanPlanRequest(
                state_id, Identity(R8_CORE, e["run_id"], e["clock_domain"], base.cost_hash),
                e["native_run_id"], obs["gateway"]["sampled_at"], obs["native_received_at"],
                f"{e['seed_block']}|{e['cell']}|{step['k']}", step, cut,
                tuple((m["request_id"], m["cost"]) for m in obs["gateway"]["requests"]))))
    _require(len(requests) == len(wanted)
             and {r.state_id for _, r in requests} == wanted, "same R9 origin mask")
    return base, fast, trace, requests, dict(train=train_receipt, evaluate=eval_receipt)


def _r10_audit(request, base, fast, trace, historical):
    """Unbudgeted CPU equivalence proof, NOT an optimizer call or candidate permit."""
    cut = _immutable(request.cut)
    draws = [_immutable(base.draw(cut, request.key, i)) for i in range(R9_SCENARIOS)]
    runs, differences = {}, []
    historical_tail = historical is not None and historical["tail_differs"]
    plans_to_trace = ((tuple(historical["one_plan"]), tuple(historical["full_plan"]))
                      if historical_tail else ())
    traced = {p: [] for p in plans_to_trace}
    for plan in R9_ALL_PLANS:
        goods = []
        for i, draw in enumerate(draws):
            reference = base.score(cut, plan, draw)
            optimized = fast.score(cut, plan, draw)
            _require(reference == optimized, f"exact v5 mismatch:{request.state_id}:{plan}:{i}")
            goods.append([reference[f"good_{h:g}"] for h in OFFSETS])
            if plan in traced:
                traced[plan].append(trace.path_evidence(cut, plan, draw))
        runs[plan] = [math.fsum(g[j] for g in goods) / R9_SCENARIOS for j in range(3)]
    if historical_tail:
        one, full = plans_to_trace
        for i, (left, right) in enumerate(zip(traced[one], traced[full])):
            changes = []
            _require(len(left["events"]) == len(right["events"]), "shared exogenous events")
            for a, b in zip(left["events"], right["events"]):
                _require((a["t"], a["id"], a["cost"]) == (b["t"], b["id"], b["cost"]),
                         "shared original event identities")
                if {k: v for k, v in a.items() if k != "cap"} != (
                        {k: v for k, v in b.items() if k != "cap"}):
                    changes.append(dict(one=a, full=b))
            differences.append(dict(
                scenario=i, changed_events=changes,
                one_tail={k: v for k, v in left.items() if k != "events"},
                full_tail={k: v for k, v in right.items() if k != "events"}))
        _require(runs[one] == historical["one_good"]
                 and runs[full] == historical["full_good"], "historical selected plan means")
    return runs, differences


def run_r10(train_path, evaluate_path, loader_path):
    import platform
    import sys
    from collections import Counter, defaultdict
    from pathlib import Path
    _require(sys.version_info[:2] == (3, 12), "qualified PY312 required for R10 measurement")
    setup_started = time.perf_counter()
    saved = r10_saved_rankings(Path(__file__).with_name("astra.md").read_text())
    base, fast, trace, requests, receipts = _r10_inputs(
        train_path, evaluate_path, loader_path, saved)
    setup_s = time.perf_counter() - setup_started
    old = {r["state_id"]: r["ranking"] for rows in saved.values() for r in rows}
    blocks, summary = defaultdict(list), {}
    for ordinal, (block, request) in enumerate(requests):
        # Alternate order, with fresh cut/draw caches inside every real solver call.
        pair = {}
        for name, scorer in ((("original", base), ("prefix", fast)) if ordinal % 2 == 0
                             else (("prefix", fast), ("original", base))):
            pair[name] = optimize_v5_mean(request, scorer, enabled=True,
                                          deadline_at=time.perf_counter() + R9_DEADLINE_S)
        audit_started = time.perf_counter()
        runs, changes = _r10_audit(request, base, fast, trace, old[request.state_id])
        audit_s = time.perf_counter() - audit_started
        for result in pair.values():
            for row in result["scores"]:
                _require(row["mean_good"] == runs[tuple(row["plan"])],
                         "timed solver vs exact scenario audit")
        # These full rankings are offline diagnostics, not late solver recommendations.
        scores = [dict(plan=p, mean_good=g) for p, g in runs.items()]
        incumbent = int(request.step["gateway"]["budget"])
        best = lambda rows: min(rows, key=lambda r: (-r["mean_good"][2],
                                                    _mean_plan_tie(r["plan"], incumbent)))
        ranking = _r10_ranking(dict(
            scores=scores, pair_family_support=dict(mpc_complete=True),
            one_move=best([r for r in scores if r["plan"] in R9_ONE_MOVE]), mpc=best(scores)))
        if old[request.state_id] is not None:
            _require(json.dumps(ranking, sort_keys=True) ==
                     json.dumps(old[request.state_id], sort_keys=True), "R9 complete rankings")
        blocks[block].append(dict(state_id=request.state_id, cell=request.step["cell"],
                                  timed=pair, exact_plan_audit=ranking,
                                  exact_scenario_comparisons=32 * 32,
                                  audit_s=audit_s, historical_tail_trace=changes))
    for block, rows in blocks.items():
        stats = {}
        for name in ("original", "prefix"):
            results = [r["timed"][name] for r in rows]
            walls = sorted(r["wall_s"] for r in results)
            stats[name] = dict(statuses=dict(Counter(r["status"] for r in results)),
                               wall_median_s=statistics.median(walls),
                               wall_p95_s=walls[math.ceil(.95 * len(walls)) - 1],
                               wall_max_s=max(walls),
                               cells={cell: dict(Counter(r["timed"][name]["status"] for r in rows
                                                        if r["cell"] == cell))
                                      for cell in sorted({r["cell"] for r in rows})})
        summary[block] = dict(
            n=len(rows), timing=stats,
            median_paired_wall_ratio=statistics.median(
                r["timed"]["original"]["wall_s"] / r["timed"]["prefix"]["wall_s"] for r in rows),
            exact_scenario_comparisons=sum(r["exact_scenario_comparisons"] for r in rows),
            offline_first_differences=[r["state_id"] for r in rows
                                       if r["exact_plan_audit"]["first_differs"]],
            offline_tail_differences=[r["state_id"] for r in rows
                                      if r["exact_plan_audit"]["tail_differs"]])
    return dict(schema=R10_VERSION, python=sys.version, executable=sys.executable,
                platform=platform.platform(), setup_s=setup_s, receipts=receipts,
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                v5_source_sha256=R9_V5_SHA, kernel_id=base.kernel_id,
                deadline_s=R9_DEADLINE_S, active_permit=False, risk_coverage_certified=False,
                historical_rankings=saved, blocks=dict(blocks), summary=summary)


R11_VERSION = "astra-two-phase-shared-work-prototype-v1"


@dataclass(frozen=True)
class WorkOwner:
    request_id: str
    cost: float
    prefill_left: float
    decode_left: float


@dataclass(frozen=True)
class WorkBatch:
    at: float
    owners: tuple[WorkOwner, ...]
    unknown_costs: tuple[tuple[str, float], ...] = ()
    retired: frozenset[str] = frozenset()
    waiting: int = 0
    kv_usage: float = 0.

    @property
    def reserved(self):
        return math.fsum([r.cost for r in self.owners] + [c for _, c in self.unknown_costs])


@dataclass(frozen=True)
class WorkCapacity:
    prefill_positions_s: float
    decode_positions_s: float
    max_active: int
    max_kv: float


def _work_batch_check(batch):
    _require(isfinite(batch.at) and type(batch.waiting) is int and batch.waiting >= 0
             and isfinite(batch.kv_usage) and 0 <= batch.kv_usage <= 1, "work batch observables")
    ids = [r.request_id for r in batch.owners] + [rid for rid, _ in batch.unknown_costs]
    _require(len(ids) <= MAX_REQUESTS and len(set(ids)) == len(ids)
             and not set(ids) & batch.retired and all(_name(rid) for rid in ids), "work identities")
    _require(all(isfinite(r.cost) and r.cost > 0
                 and isfinite(r.prefill_left) and r.prefill_left >= 0
                 and isfinite(r.decode_left) and r.decode_left >= 0 for r in batch.owners)
             and all(isfinite(c) and c > 0 for _, c in batch.unknown_costs), "work/cost bounds")


def admit_work(batch, offer, cap):
    """Whole original-cost admission only; budget never enters the service law."""
    _work_batch_check(batch)
    _require(_cap(cap), "reservation budget")
    candidate = replace(batch, owners=batch.owners + (offer,))
    _work_batch_check(candidate)
    if candidate.reserved > cap:
        return batch, False
    return candidate, True


def release_work(batch, request_id):
    """Apply an externally qualified owner-release event, not an inferred API EOS."""
    _work_batch_check(batch)
    matches = [r for r in batch.owners if r.request_id == request_id]
    _require(len(matches) == 1 and matches[0].prefill_left == matches[0].decode_left == 0,
             "release needs resolved finished work and a known owner")
    return replace(batch, owners=tuple(r for r in batch.owners if r.request_id != request_id),
                   retired=batch.retired | {request_id})


def advance_work(batch, dt, capacity):
    """Concurrent, event-split work fluid; not HTTP service or a full-G predictor.

    Remaining decode work is a latent physical-position requirement, NOT delivered
    tokens inferred from max_tokens. EOS, overhang, KV evolution and owner-release
    laws are required external adapters, deliberately not invented here.
    """
    _work_batch_check(batch)
    _require(isfinite(dt) and 0 <= dt <= .5, "short-step duration")
    _require(all(isfinite(c) and c > 0 for c in (
        capacity.prefill_positions_s, capacity.decode_positions_s))
        and type(capacity.max_active) is int and 0 < capacity.max_active <= MAX_REQUESTS
        and isfinite(capacity.max_kv) and 0 <= capacity.max_kv <= 1, "work capacity")
    _require(not batch.unknown_costs and batch.waiting == 0
             and batch.kv_usage <= capacity.max_kv, "unresolved work or KV support")
    owners, elapsed, events = list(batch.owners), 0., []
    while elapsed < dt:
        active = [i for i, r in enumerate(owners) if r.prefill_left > 0 or r.decode_left > 0]
        _require(len(active) <= capacity.max_active, "batch-size support")
        if not active:
            break
        rates = {i: (capacity.prefill_positions_s if owners[i].prefill_left > 0
                     else capacity.decode_positions_s) / len(active) for i in active}
        times = {i: (owners[i].prefill_left if owners[i].prefill_left > 0
                     else owners[i].decode_left) / rates[i] for i in active}
        step = min(dt - elapsed, min(times.values()))
        _require(step > 0 and elapsed + step > elapsed, "unresolvable fluid time step")
        for i in active:
            r = owners[i]
            phase = "prefill_left" if r.prefill_left > 0 else "decode_left"
            remaining = 0. if times[i] <= step else max(0., getattr(r, phase) - rates[i] * step)
            owners[i] = replace(r, **{phase: remaining})
            if remaining == 0.:
                events.append((r.request_id, "prefill_done" if phase == "prefill_left"
                               else "work_done", batch.at + elapsed + step))
                if phase == "prefill_left" and r.decode_left == 0:
                    events.append((r.request_id, "work_done", batch.at + elapsed + step))
        elapsed += step
    return replace(batch, at=batch.at + dt, owners=tuple(owners)), tuple(events)


def _r11_progress_pairs(episode, module):
    """Strict descriptive counter-transfer labels; post-cut closure is a label mask."""
    import bisect
    from collections import Counter
    masks, frames, pairs = Counter(), [], []
    client = {r["request_id"]: r for r in episode["client_rows"]}
    sent = sorted(r["sent_at"] for r in episode["client_rows"])
    for obs in episode["observations"]:
        try:
            marks = module._marks(obs["gateway"], episode)
            module._native(obs["native"], marks, episode, obs["received_at"],
                           obs["native_received_at"])
            module._budget_provenance(obs["gateway"], episode["actions"])
            native = obs["native"]
            requests = {}
            for r in native["requests"]:
                rid = module.NATIVE_ID.fullmatch(r["request_id"])[1]
                _require(type(r.get("computed_tokens")) is int and r["computed_tokens"] >= 0
                         and r["prompt_tokens"] == marks[rid]["prompt_tokens"],
                         "missing or mismatched native progress")
                requests[rid] = r
            _require(requests and set(requests) == set(marks), "empty or invisible work")
            _require(native["waiting"] == 0 and not native.get("orphaned"), "waiting or orphaned")
            frames.append((obs, requests))
        except (ValueError, KeyError, TypeError) as exc:
            masks["frame:" + str(exc)] += 1
            frames.append(None)
    previous = None
    for i, (left, right) in enumerate(zip(frames, frames[1:])):
        reasons = []
        if left is None or right is None:
            masks["pair:unqualified_endpoint"] += 1
            previous = None
            continue
        a, old = left
        b, new = right
        start, end = a["native"]["sampled_at"], b["native"]["sampled_at"]
        dt = end - start
        if not 0 < dt <= .5 or a["native_received_at"] > end:
            reasons.append("time_or_receipt")
        if set(old) != set(new):
            reasons.append("owner_change")
        if bisect.bisect_right(sent, end) != bisect.bisect_right(sent, start):
            reasons.append("intervening_offer")
        if any(client[rid].get("terminal_at") is not None
               and client[rid]["terminal_at"] <= b["native_received_at"] for rid in old):
            reasons.append("terminal_or_overhang_possible")
        phases, delta = set(), 0
        for rid in old.keys() & new.keys():
            x, y = old[rid], new[rid]
            p = "prefill" if x["computed_tokens"] < x["prompt_tokens"] else "decode"
            q = "prefill" if y["computed_tokens"] < y["prompt_tokens"] else "decode"
            phases.add(p)
            if p != q or x["prompt_tokens"] != y["prompt_tokens"]:
                reasons.append("phase_change")
            if y["computed_tokens"] < x["computed_tokens"]:
                reasons.append("counter_regression")
            delta += y["computed_tokens"] - x["computed_tokens"]
        if len(phases) != 1:
            reasons.append("mixed_phase")
        if reasons:
            masks.update("pair:" + r for r in set(reasons))
            previous = None
            continue
        phase = next(iter(phases))
        pair = dict(episode=episode["episode_id"], block=episode["seed_block"],
                    i=i, start=start, end=end, input_received_at=a["native_received_at"],
                    phase=phase, n=len(old), kv=a["native"]["kv_cache_usage"],
                    pending_batches=a["native"]["pending_batches"],
                    receipt_age_s=a["native_received_at"] - start,
                    computed_start=sum(r["computed_tokens"] for r in old.values()),
                    native_output_start=sum(r["output_tokens"] for r in old.values()),
                    positions=delta, dt=dt, rate=delta / dt,
                    previous_rate=previous["rate"] if previous and previous["phase"] == phase
                    and previous["i"] == i - 1 else None)
        pairs.append(pair)
        previous = pair
    return pairs, dict(masks)


def run_r11_progress(train_path, evaluate_path, loader_path):
    """One fixed Train fit / used-4/5 descriptive diagnostic, never a G5 forecast."""
    import sys
    from collections import Counter, defaultdict
    from pathlib import Path
    module = _r9_loader(loader_path)
    train, _, train_receipt = _r8_archive(train_path, R8_TRAIN, module)
    evaluate, docs, eval_receipt = _r8_archive(evaluate_path, (181004, 181005), module)
    source, index = module.bind_source(Path(evaluate_path))
    for document in docs.values():
        module.bind_assignments(document, module.SOURCE_BINDINGS[source]["holds"],
                                index["clock_domain"])
    rows, masks = [], {}
    for episode in train + evaluate:
        pair, mask = _r11_progress_pairs(episode, module)
        rows.extend(pair)
        masks[episode["episode_id"]] = mask
    fitted = {}
    for phase in ("prefill", "decode"):
        selected = [r for r in rows if r["block"] in R8_TRAIN and r["phase"] == phase]
        rates = [r["rate"] for r in selected]
        estimate = statistics.median(rates) if len(rates) >= 20 else None
        fitted[phase] = dict(n=len(rates), positions_s=estimate,
                             max_active=max((r["n"] for r in selected), default=None),
                             max_kv=max((r["kv"] for r in selected), default=None))
    blocks, summary = defaultdict(list), {}
    exclusions = Counter()
    for block in (181004, 181005):
        episodes = sorted({r["episode"] for r in rows if r["block"] == block})
        for episode in episodes:
            pairs = {r["i"]: r for r in rows if r["episode"] == episode}
            for i, first in pairs.items():
                capacity = fitted[first["phase"]]["positions_s"]
                if capacity is None or capacity <= 0 or first["previous_rate"] is None:
                    exclusions["missing_phase_fit_or_prefix_rate"] += 1
                    continue
                for horizon in (0., 1., 3., 5.):
                    chain, j = [], i
                    while j in pairs:
                        r = pairs[j]
                        if r["phase"] != first["phase"] or r["n"] != first["n"]:
                            break
                        chain.append(r)
                        if horizon == 0 or r["end"] - first["start"] >= horizon:
                            break
                        j += 1
                    if not chain or (horizon and chain[-1]["end"] - first["start"] < horizon):
                        exclusions[f"unclosed_{horizon:g}s"] += 1
                        continue
                    if any(r["n"] > fitted[r["phase"]]["max_active"]
                           or r["kv"] > fitted[r["phase"]]["max_kv"] for r in chain):
                        exclusions[f"outside_fitted_support_{horizon:g}s"] += 1
                        continue
                    duration = chain[-1]["end"] - first["start"]
                    truth = sum(r["positions"] for r in chain)
                    blocks[str(block)].append(dict(
                        episode=episode, i=i, phase=first["phase"], n=first["n"],
                        nominal_horizon=horizon, actual_span_s=duration, truth_positions=truth,
                        fluid_positions=capacity * duration,
                        last_rate_positions=first["previous_rate"] * duration))
        summary[str(block)] = {
            f"{h:g}s": dict(
                n=len(selected),
                fluid_mae=statistics.fmean(abs(r["fluid_positions"] - r["truth_positions"])
                                          for r in selected) if selected else None,
                last_rate_mae=statistics.fmean(abs(r["last_rate_positions"] - r["truth_positions"])
                                              for r in selected) if selected else None)
            for h in (0., 1., 3., 5.)
            for selected in [[r for r in blocks[str(block)] if r["nominal_horizon"] == h]]}
    return dict(schema=R11_VERSION, python=sys.version, executable=sys.executable,
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                v5_loader_sha256=R9_V5_SHA, train_receipt=train_receipt,
                evaluation_receipt=eval_receipt, fitted=fitted, pairs=rows, masks=masks,
                exclusions=dict(exclusions), blocks=dict(blocks), summary=summary,
                joint_mixed_service_identified=False, full_good_adapter_available=False,
                active_permit=False, risk_coverage_certified=False)


COUNTER_VERSION = "astra-native-id-stayer-reported-output-v1"
COUNTER_HORIZONS = (.5, 1., 3., 5.)


@dataclass(frozen=True)
class OutputCounterPrefix:
    output: int
    maximum: int
    past_rate: float
    last_rate: float
    running: int
    waiting: int
    pending: int
    prefill_fraction: float
    kv: float
    unknown_cost_fraction: float


def _counter_features(x):
    _require(type(x.output) is int and type(x.maximum) is int and 0 < x.output <= x.maximum
             and all(type(v) is int and v >= 0 for v in (x.running, x.waiting, x.pending))
             and x.running > 0 and all(isfinite(v) and v >= 0 for v in (
                 x.past_rate, x.last_rate, x.prefill_fraction, x.kv, x.unknown_cost_fraction))
             and max(x.prefill_fraction, x.kv, x.unknown_cost_fraction) <= 1,
             "reported-output prefix")
    return [x.past_rate, x.last_rate, math.log1p(x.running), math.log1p(x.waiting),
            math.log1p(x.pending), x.prefill_fraction, x.kv, x.unknown_cost_fraction,
            x.output / x.maximum]


@dataclass(frozen=True)
class StayerOutputModel:
    """Conditional reported-counter means; neither GPU service nor full-good forecasts."""
    artifact: dict

    @classmethod
    def fit(cls, records):
        _require(len(records) >= 20, "counter fit support")
        for row in records:
            _require(row["block"] in R8_TRAIN and row["horizon"] == .5
                     and isfinite(row["rate"]) and row["rate"] >= 0, "counter fit partition/label")
        xs = [_counter_features(OutputCounterPrefix(**r["prefix"])) for r in records]
        ys = [r["rate"] - r["prefix"]["past_rate"] for r in records]
        fit = _direct_ridge(xs, ys)
        return cls(dict(schema=COUNTER_VERSION, ridge=R8_RIDGE, n=len(records), fit=fit,
                        minimum=[min(x[j] for x in xs) for j in range(len(xs[0]))],
                        maximum=[max(x[j] for x in xs) for j in range(len(xs[0]))]))

    def predict(self, prefix, elapsed_from_native_sample):
        _require(self.artifact["schema"] == COUNTER_VERSION, "counter model version")
        _require(isfinite(elapsed_from_native_sample) and 0 < elapsed_from_native_sample <= 6,
                 "counter target sample span")
        x = _counter_features(prefix)
        rate = max(0., prefix.past_rate + _direct_mean(self.artifact["fit"], x))
        delta = min(prefix.maximum - prefix.output, rate * elapsed_from_native_sample)
        return dict(delta_output=delta, rate=rate,
                    outside_train_range=[j for j, v in enumerate(x)
                                         if not self.artifact["minimum"][j] <= v
                                         <= self.artifact["maximum"][j]],
                    conditional_on_native_stayer=True, active_permit=False)


def _counter_records(episode, module, horizons):
    import bisect
    from collections import Counter
    from dataclasses import asdict
    frames, masks = [], Counter()
    for obs in episode["observations"]:
        try:
            marks = module._marks(obs["gateway"], episode)
            module._native(obs["native"], marks, episode, obs["received_at"],
                           obs["native_received_at"])
            module._budget_provenance(obs["gateway"], episode["actions"])
            native = obs["native"]
            ids = {module.NATIVE_ID.fullmatch(r["request_id"])[1]: r
                   for r in native["requests"]}
            _require(all(type(r.get("computed_tokens")) is int and r["computed_tokens"] >= 0
                         and r["prompt_tokens"] == marks[rid]["prompt_tokens"]
                         for rid, r in ids.items()), "reported progress fields")
            reserved = math.fsum(m["cost"] for m in marks.values())
            unknown = math.fsum(m["cost"] for rid, m in marks.items() if rid not in ids)
            frames.append(dict(obs=obs, ids=ids, unknown=unknown / reserved if reserved else 0.))
        except (ValueError, KeyError, TypeError) as exc:
            frames.append(None)
            masks["frame:" + str(exc)] += 1
    times = [o["native"]["sampled_at"] for o in episode["observations"]]
    _require(all(a <= b for a, b in zip(times, times[1:])), "counter sample order")
    rows = []

    def continuous(rid, begin, end):
        previous = None
        for j in range(begin, end + 1):
            frame = frames[j]
            if frame is None:
                return "unqualified_frame"
            if rid not in frame["ids"]:
                return "native_id_disappeared"
            r = frame["ids"][rid]
            if previous is not None:
                if not 0 < times[j] - times[j - 1] <= .5:
                    return "frame_gap"
                if r["output_tokens"] < previous["output_tokens"]:
                    return "reported_output_regression"
                if (r["prompt_tokens"], r["maximum_output_tokens"]) != (
                        previous["prompt_tokens"], previous["maximum_output_tokens"]):
                    return "payload_changed"
            previous = r
        return None

    for i in range(0, len(frames), 4):
        if frames[i] is None:
            masks["origin:unqualified_frame"] += 1
            continue
        frame = frames[i]
        obs, native = frame["obs"], frame["obs"]["native"]
        past = bisect.bisect_right(times, times[i] - .5) - 1
        for rid, current in sorted(frame["ids"].items()):
            masks["origin:native_id_candidates"] += 1
            if current["output_tokens"] == 0 or current["computed_tokens"] < current["prompt_tokens"]:
                masks["origin:not_reported_postprefill"] += 1
                continue
            if past < 0 or i == 0 or continuous(rid, past, i) is not None:
                masks["origin:missing_contiguous_past"] += 1
                continue
            past_rate = (current["output_tokens"] - frames[past]["ids"][rid]["output_tokens"]) / (
                times[i] - times[past])
            last_rate = (current["output_tokens"] - frames[i - 1]["ids"][rid]["output_tokens"]) / (
                times[i] - times[i - 1])
            prefix = OutputCounterPrefix(
                current["output_tokens"], current["maximum_output_tokens"], past_rate, last_rate,
                native["running"], native["waiting"], native["pending_batches"],
                sum(r["computed_tokens"] < r["prompt_tokens"] for r in frame["ids"].values())
                / max(1, native["running"]), native["kv_cache_usage"], frame["unknown"])
            _counter_features(prefix)
            for h in horizons:
                masks[f"target_{h:g}:eligible_origin"] += 1
                target = bisect.bisect_left(times, obs["native_received_at"] + h)
                if (target >= len(times) or times[target] > episode["start"] + episode["duration_s"]
                        or times[target] - (obs["native_received_at"] + h) > .5):
                    masks[f"target_{h:g}:endpoint_unavailable"] += 1
                    continue
                reason = continuous(rid, i, target)
                if reason:
                    masks[f"target_{h:g}:" + reason] += 1
                    continue
                end = frames[target]["ids"][rid]["output_tokens"]
                span = times[target] - times[i]
                rows.append(dict(
                    episode=episode["episode_id"], block=episode["seed_block"], request_id=rid,
                    origin_index=i, target_index=target, horizon=h, native_sampled_at=times[i],
                    received_at=obs["native_received_at"], target_sampled_at=times[target],
                    prefix=asdict(prefix), elapsed=span, delta=end - current["output_tokens"],
                    rate=(end - current["output_tokens"]) / span))
                masks[f"target_{h:g}:retained_stayer"] += 1
    return rows, dict(masks)


def run_stayer_output(train_path, evaluate_paths, loader_path):
    import sys
    from pathlib import Path
    module = _r9_loader(loader_path)
    train, _, train_receipt = _r8_archive(train_path, R8_TRAIN, module)
    masks, training = {}, []
    for episode in train:
        rows, mask = _counter_records(episode, module, (.5,))
        masks[episode["episode_id"]] = mask
        training.extend(rows)
    model = StayerOutputModel.fit(training)
    training_sha = hashlib.sha256(json.dumps(
        training, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    blocks, summary, receipts = {}, {}, {}
    _require(len(evaluate_paths) == 3, "used4/5,6/7,8/9 archives required")
    for path, allowed in zip(evaluate_paths, ((181004, 181005), (181006, 181007), (181008, 181009))):
        episodes, docs, receipt = _r8_archive(path, allowed, module)
        source, index = module.bind_source(Path(path))
        for document in docs.values():
            module.bind_assignments(document, module.SOURCE_BINDINGS[source]["holds"],
                                    index["clock_domain"])
        receipts[str(allowed)] = receipt
        for block in allowed:
            selected = []
            for episode in episodes:
                if episode["seed_block"] != block:
                    continue
                rows, mask = _counter_records(episode, module, COUNTER_HORIZONS)
                masks[episode["episode_id"]] = mask
                for row in rows:
                    prefix = OutputCounterPrefix(**row["prefix"])
                    prediction = model.predict(prefix, row["elapsed"])
                    remaining = prefix.maximum - prefix.output
                    row.update(prediction=prediction,
                               past_rate_delta=min(remaining, prefix.past_rate * row["elapsed"]),
                               last_rate_delta=min(remaining, prefix.last_rate * row["elapsed"]))
                    selected.append(row)
            blocks[str(block)] = selected
            summary[str(block)] = {
                f"{h:g}s": dict(
                    n=len(group),
                    learned_mae=statistics.fmean(abs(r["prediction"]["delta_output"] - r["delta"])
                                                 for r in group) if group else None,
                    past_rate_mae=statistics.fmean(abs(r["past_rate_delta"] - r["delta"])
                                                   for r in group) if group else None,
                    last_rate_mae=statistics.fmean(abs(r["last_rate_delta"] - r["delta"])
                                                   for r in group) if group else None,
                    outside_train_range=sum(bool(r["prediction"]["outside_train_range"])
                                            for r in group))
                for h in COUNTER_HORIZONS
                for group in [[r for r in selected if r["horizon"] == h]]}
    return dict(schema=COUNTER_VERSION, python=sys.version, executable=sys.executable,
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                loader_sha256=R9_V5_SHA, train_receipt=train_receipt,
                evaluation_receipts=receipts, fitted=model.artifact,
                training_records_sha256=training_sha, masks=masks, blocks=blocks, summary=summary,
                full_good_forecast=False, exclusive_gpu_service=False, active_permit=False)


R12_VERSION = "astra-v8-action-order-and-cost-coverage-audit-v1"
R12_OPUS_SHA = "aa927973f4cf6a6ba96a10c09bb77eb9fdef63dda80ad70b78c87b768dab12c7"
R12_GEMINI_SHA = "ade3dfcea281f811ecfe989c8c03e1c48980b4e4ff2b4052cd62120493c290ca"
R12_MANIFEST_SHA = "236435fd1d93e89dd267ad035f744d7f2824e728983363c9ef1767f1e41797a8"


def _r12_load(path, name, digest):
    import importlib.util
    import sys
    from pathlib import Path
    _require(hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, "R12 frozen source")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def audit_v8_order(module, start, plan, arrivals, uniforms, model, costs):
    """Replay v8 exactly; local release-first rearrangement NEVER changes its path.

    All sampled parent releases move to the step start in the diagnostic only.
    Birth releases stay at the end. Neither order is asserted to be native timing.
    """
    m, cell = module, model["cell"]
    pop = [[ph, tt, cls, i] for i, (ph, tt, cls) in enumerate(start)]
    n0, ai, maximum = len(start), 0, 0.
    goods, rejected, offered, steps = [0] * m.ROLLOUT_STEPS, [], [], []
    for j in range(m.ROLLOUT_STEPS):
        batch = m.r11_batch(((r[0], cell, r[2]) for r in pop), model["prompt_k"])
        stock = math.fsum(costs[(cell, r[2])] for r in pop if r[0] in m.COST_PHASES)
        parent = []
        for ph, tt, cls, idx in pop:
            records, _ = m._r11_resolve(
                model["table"], m._r11_keys(cell, cls, ph, tt, batch, True))
            rec = records[min(int(uniforms[idx][j] * len(records)), len(records) - 1)]
            parent.append((ph, tt, cls, idx, rec))
        released = math.fsum(costs[(cell, cls)] for ph, _, cls, _, rec in parent
                             if ph in m.COST_PHASES and rec[0] not in m.COST_PHASES)
        resurrected = math.fsum(costs[(cell, cls)] for ph, _, cls, _, rec in parent
                                if ph not in m.COST_PHASES and rec[0] in m.COST_PHASES)
        reserved, early = stock, stock - released
        births, event_rows = [], []
        while ai < len(arrivals) and arrivals[ai][0] <= (j + 1) * m.STEP_S + m.EPS:
            at, cls = arrivals[ai][:2]
            charge = costs[(cell, cls)]
            accepted = reserved + charge <= plan[j] + m.EPS
            early_accepted = early + charge <= plan[j] + m.EPS
            opportunity = not accepted and reserved - released + charge <= plan[j] + m.EPS
            event_rows.append(dict(at=at, cls=cls, charge=charge, source_stock=reserved,
                                   release_first_stock=early, source_admitted=accepted,
                                   release_first_admitted=early_accepted,
                                   isolated_release_opportunity=opportunity))
            offered.append(at)
            if accepted:
                reserved += charge
                maximum = max(maximum, reserved)
                births.append((cls, int(at - j * m.STEP_S > m.STEP_S / 2 + m.EPS), n0 + ai))
            else:
                rejected.append(at)
            if early_accepted:
                early += charge
            ai += 1
        nxt = []
        for _, _, cls, idx, rec in parent:
            goods[j] += rec[2]
            if rec[0] != "GONE":
                nxt.append([rec[0], rec[1], cls, idx])
        birth_released = 0.
        for cls, half, idx in births:
            records, _ = m._r11_resolve(
                model["table"], m._r11_entry_keys(cell, cls, half, batch, True))
            rec = records[min(int(uniforms[idx][j] * len(records)), len(records) - 1)]
            goods[j] += rec[2]
            if rec[0] != "GONE":
                nxt.append([rec[0], rec[1], cls, idx])
            if rec[0] not in m.COST_PHASES:
                birth_released += costs[(cell, cls)]
        end_stock = math.fsum(costs[(cell, r[2])] for r in nxt if r[0] in m.COST_PHASES)
        admitted_cost = math.fsum(costs[(cell, cls)] for cls, _, _ in births)
        residual = end_stock - (stock - released + resurrected + admitted_cost - birth_released)
        _require(abs(residual) < 1e-8, "v8 stock-flow conservation")
        steps.append(dict(step=j, cap=plan[j], start_stock=stock, end_stock=end_stock,
                          parent_released_cost=released, resurrected_cost=resurrected,
                          admitted_cost=admitted_cost, birth_released_cost=birth_released,
                          balance_residual=residual, offers=event_rows,
                          releases=[dict(index=idx, cls=cls, before=ph, after=rec[0],
                                         cost=costs[(cell, cls)])
                                    for ph, _, cls, idx, rec in parent
                                    if ph in m.COST_PHASES and rec[0] not in m.COST_PHASES]))
        pop = nxt
    result = {}
    for h in m.SIM_HORIZONS:
        result[f"good_{h:g}"] = float(sum(goods[:int(round(h / m.STEP_S))]))
        result[f"rejected_{h:g}"] = float(sum(t <= h + m.EPS for t in rejected))
        result[f"offers_{h:g}"] = float(sum(t <= h + m.EPS for t in offered))
    result["max_reserved_after_admission"] = maximum
    _require(result == m.r11_simulate(start, plan, arrivals, uniforms, model, costs),
             "audit replay differs from exact v8 source")
    return dict(source_result=result, steps=steps,
                counterfactual_good_forecast=None, native_timing_identified=False)


def _r12_cost_coverage(episodes, saved_rows, module):
    import bisect
    from collections import defaultdict
    indexed = defaultdict(set)
    for rows in saved_rows.values():
        for row in rows:
            indexed[(row["episode"], row["origin_index"], row["horizon"])].add(row["request_id"])
    blocks, excluded = defaultdict(list), defaultdict(int)
    for episode in episodes:
        obs = episode["observations"]
        times = [o["native"]["sampled_at"] for o in obs]
        for i in range(0, len(obs), 4):
            current = obs[i]
            try:
                marks = module._marks(current["gateway"], episode)
                native = module._native(current["native"], marks, episode, current["received_at"],
                                        current["native_received_at"])
                module._budget_provenance(current["gateway"], episode["actions"])
            except (ValueError, KeyError, TypeError) as exc:
                excluded[str(exc)] += 1
                continue
            if not marks:
                excluded["empty_original_ledger"] += 1
                continue
            total = math.fsum(r["cost"] for r in marks.values())
            unknown = math.fsum(m["cost"] for rid, m in marks.items() if rid not in native)
            for h in COUNTER_HORIZONS:
                ids = indexed[(episode["episode_id"], i, h)]
                _require(ids <= set(marks), "stayer ID absent from original-cost ledger")
                covered = math.fsum(marks[rid]["cost"] for rid in ids)
                target = bisect.bisect_left(times, current["native_received_at"] + h)
                new_cost = None
                if (target < len(obs) and times[target] <= episode["start"] + episode["duration_s"]
                        and times[target] <= current["native_received_at"] + h + .5):
                    try:
                        later = module._marks(obs[target]["gateway"], episode)
                        module._native(obs[target]["native"], later, episode,
                                       obs[target]["received_at"], obs[target]["native_received_at"])
                        new_cost = math.fsum(m["cost"] for rid, m in later.items() if rid not in marks)
                    except (ValueError, KeyError, TypeError):
                        pass
                blocks[str(episode["seed_block"])].append(dict(
                    episode=episode["episode_id"], origin_index=i, horizon=h,
                    original_owner_count=len(marks), original_cost=total,
                    native_invisible_cost=unknown, counter_covered_owner_count=len(ids),
                    counter_covered_original_cost=covered, unrepresented_original_cost=total - covered,
                    all_original_owners_counter_covered=ids == set(marks),
                    target_new_owner_cost_label=new_cost))
    summary = {}
    for block, rows in blocks.items():
        summary[block] = {}
        for h in COUNTER_HORIZONS:
            group = [r for r in rows if r["horizon"] == h]
            total = math.fsum(r["original_cost"] for r in group)
            summary[block][str(h)] = dict(
                nonempty_qualified_cuts=len(group),
                all_original_owners_covered=sum(r["all_original_owners_counter_covered"] for r in group),
                original_cost_exposure=total,
                covered_cost_fraction=math.fsum(r["counter_covered_original_cost"] for r in group) / total,
                native_invisible_cost_fraction=math.fsum(r["native_invisible_cost"] for r in group) / total,
                cuts_with_target_new_owner_cost=sum((r["target_new_owner_cost_label"] or 0) > 0
                                                   for r in group),
                target_cost_label_missing=sum(r["target_new_owner_cost_label"] is None for r in group))
    return dict(summary=summary, blocks=dict(blocks), excluded=dict(excluded),
                full_gateway_cost_forecast_available=False, missing_cost_imputed_zero=False)


def run_r12(frozen_path, train_path, evaluate_paths):
    import random
    import sys
    from collections import defaultdict
    from pathlib import Path
    root = Path(frozen_path)
    manifest_raw = (root / "manifest.json").read_bytes()
    _require(hashlib.sha256(manifest_raw).hexdigest() == R12_MANIFEST_SHA, "R12 manifest")
    manifest = json.loads(manifest_raw)
    for owner, receipt in manifest.items():
        for path, digest in receipt["files"].items():
            _require(hashlib.sha256((root / owner / Path(path).name).read_bytes()).hexdigest() == digest,
                     "R12 frozen file")
    opus = _r12_load(root / "opus/native_release_model.py", "astra_r12_opus", R12_OPUS_SHA)
    text = (root / "astra/astra.md").read_text()
    historical = r10_saved_rankings(text)
    raw = text.rsplit("\n## R11b counter generated complete raw JSON\n", 1)[1]
    raw = raw.split("```json\n", 1)[1].split("\n```", 1)[0]
    _require(hashlib.sha256(raw.encode()).hexdigest() ==
             "fe030845474330db07d7340f57a73483ee7175e4eda324d08a531f7f1e0eae0e",
             "frozen stayer receipt")
    saved = json.loads(raw)
    train, _, train_receipt = _r8_archive(train_path, R8_TRAIN, opus)
    fit = opus.fit_batch_progress(opus._r8_entries(train))
    costs = opus.payload_costs(train)
    _require(len(evaluate_paths) == 3, "R12 used4..9 archives")
    episodes, receipts = [], {}
    for path, allowed in zip(evaluate_paths, ((181004, 181005), (181006, 181007), (181008, 181009))):
        eps, docs, receipt = _r8_archive(path, allowed, opus)
        source, index = opus.bind_source(Path(path))
        for document in docs.values():
            opus.bind_assignments(document, opus.SOURCE_BINDINGS[source]["holds"], index["clock_domain"])
        episodes.extend(eps)
        receipts[str(allowed)] = receipt
    coverage = _r12_cost_coverage(episodes, saved["blocks"], opus)
    wanted = {r["state_id"] for rows in historical.values() for r in rows}
    blocks = defaultdict(list)
    for episode, steps, _, rows in opus._r8_entries(
            [e for e in episodes if e["seed_block"] in (181006, 181007)]):
        origins, parsed, _ = opus.build_origins(dict(episode, origin_grid_s=.5))
        observations = {o["grid_index"]: parsed[o["index"]][1] for o in origins}
        raw_rows = {r["request_id"]: r for r in episode["client_rows"]}
        classes = {rid: opus.payload_class(r) for rid, r in raw_rows.items()}
        order = sorted((r["sent"], rid) for rid, r in rows.items())
        by_class = defaultdict(list)
        for t, rid in order:
            by_class[classes[rid]].append(t)
        sent_index = ([t for t, _ in order], [rid for _, rid in order], dict(by_class))
        cell_model = dict(fit, cell=episode["cell"])
        for s, seen, _, _ in opus._r11_walk(steps, rows):
            obs = observations[s["k"]]
            state_id = f"{episode['episode_id']}:{s['k']}:{obs['gateway']['sequence']}"
            if state_id not in wanted:
                continue
            cut = opus.admission_cut_state(s, rows, raw_rows, costs, sent_index)
            plan = s["plan"][:opus.ROLLOUT_STEPS]
            start = opus.r11_cut_start(s, rows, classes, seen - s["cohort"], cut, plan, costs)
            key = f"{episode['seed_block']}|{episode['cell']}|{s['k']}"
            law = opus.draw_common_law(cut, key, 0)
            digest = hashlib.sha256(f"{opus.R11_SEED}|{key}|0".encode()).hexdigest()
            rng = random.Random(int(digest[:16], 16))
            uniforms = [[rng.random() for _ in range(opus.ROLLOUT_STEPS)]
                        for _ in range(len(start) + len(law["arrivals"]))]
            audited = audit_v8_order(opus, start, plan, law["arrivals"], uniforms, cell_model, costs)
            counts = {cap: len(opus.r11_cut_start(
                s, rows, classes, seen - s["cohort"], cut, [cap] * opus.ROLLOUT_STEPS, costs))
                      for cap in CAPS}
            audited.update(state_id=state_id, cell=episode["cell"], scenario=0,
                           observed_reserved=s["gateway"]["reserved"],
                           start_count_by_cap=counts,
                           birth_uniform_index_changes=bool(law["arrivals"]) and counts[16] != counts[32])
            blocks[str(episode["seed_block"])].append(audited)
    _require(sum(len(rows) for rows in blocks.values()) == len(wanted), "same R9 origin set")
    summary = {}
    for block, rows in blocks.items():
        steps = [s for r in rows for s in r["steps"]]
        offers = [o for s in steps for o in s["offers"]]
        summary[block] = dict(
            exact_source_scenarios=len(rows), steps=len(steps), offered=len(offers),
            source_rejected=sum(not o["source_admitted"] for o in offers),
            local_release_first_rejected=sum(not o["release_first_admitted"] for o in offers),
            isolated_release_opportunities=sum(o["isolated_release_opportunity"] for o in offers),
            changed_admission_decisions=sum(o["source_admitted"] != o["release_first_admitted"]
                                           for o in offers),
            changed_steps=sum(any(o["source_admitted"] != o["release_first_admitted"]
                                  for o in s["offers"]) for s in steps),
            parent_release_steps=sum(s["parent_released_cost"] > 0 for s in steps),
            nonmonotone_rejection_steps=sum(
                sum(not o["release_first_admitted"] for o in s["offers"]) >
                sum(not o["source_admitted"] for o in s["offers"]) for s in steps),
            max_abs_stock_flow_residual=max(abs(s["balance_residual"]) for s in steps),
            resurrected_cost=math.fsum(s["resurrected_cost"] for s in steps),
            start_stock_error_mean=statistics.fmean(r["steps"][0]["start_stock"] - r["observed_reserved"]
                                                   for r in rows),
            birth_uniform_index_changes=sum(r["birth_uniform_index_changes"] for r in rows))
    gemini = _r12_load(root / "gemini/native_campaign_protocol.py", "astra_r12_gemini", R12_GEMINI_SHA)
    missing = Path(__file__).with_name("r12-deliberately-absent-train-artifact")
    _require(not missing.exists(), "missing-artifact witness path unexpectedly exists")
    fallback = gemini.fit_batch_aware_hazard_model_on_train13(str(missing))
    gmodel = gemini.BatchAwareHazardTransitionModel(fitted_parameters=fallback)
    rates = {n: gmodel.compute_service_rates(gemini.MinimalObservableBatchState(
        timestamp_s=0., running_count=n, decode_count=n, prefill_count=0, kv_cache_usage=.1))[0]
             for n in (1, 8)}
    return dict(schema=R12_VERSION, python=sys.version, source_sha256=hashlib.sha256(
                    Path(__file__).read_bytes()).hexdigest(), manifest=manifest,
                manifest_sha256=R12_MANIFEST_SHA, train_receipt=train_receipt,
                evaluation_receipts=receipts, kernel_hash=_kernel_hash(fit, costs),
                summary=summary, blocks=dict(blocks), counter_cost_coverage=coverage,
                gemini_source_probes=dict(
                    missing_artifact_reports_samples=fallback.n_decode_samples,
                    missing_artifact_reports_episodes=fallback.n_episodes_fitted,
                    fallback_gamma_decode=fallback.gamma_decode, fixed_kv_rates=rates),
                native_timing_identified=False, counterfactual_good_forecast=None,
                active_permit=False)


R13_V9_SHA = "ba9963e534de98eaee7402b6efdf99e4d1fe2f1f22562c07bd1900ca6a65b36f"
R13_VERSION = "astra-exact-v9-binary-prefix-v2-live-status-contract"
R14_V10_SHA = "3ec5b68364a1e7eb17e38ea47a81c5fd0490365bde1b1045e383ff9b09067bd9"
R14_VERSION = "astra-exact-stable-v10-binary-prefix-v1"
R13_METRICS = tuple(f"{name}_{h:g}" for h in OFFSETS for name in ("good", "rejected", "offers")) + (
    "max_reserved_after_admission",)


class FrozenV9BinaryScorer:
    """Exact numerical acceleration of frozen v9, including its legacy CRN indexing.

    A cache belongs to one solve only. Each one-second edge runs two original
    half-second transitions; initial populations may differ by first action.
    """

    SOURCE_SHA = R13_V9_SHA
    VERSION_ATTRIBUTE = "WITHIN_STEP_VERSION"
    VERSION = "nv3-opus-within-step-release-v9"

    def __init__(self, module, model, costs, offsets, support):
        from pathlib import Path
        _require(hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest() == self.SOURCE_SHA
                 and getattr(module, self.VERSION_ATTRIBUTE) == self.VERSION
                 and module.ROLLOUT_STEPS == 10 and module.STEP_S == .5
                 and module.SIM_SCENARIOS == R9_SCENARIOS, "frozen binary scorer source")
        self.module = module
        self.source_sha = self.SOURCE_SHA
        self.kernel_id = _kernel_hash([model, offsets], costs)
        self.model, self.costs, self.offsets, self.support = map(
            _immutable, (model, costs, offsets, support))

    def tape(self, cut, key, scenario, starts, start_ids=None):
        import random
        m = self.module
        law = m.draw_common_law(cut, key, scenario)
        _require(len(law["arrivals"]) <= 512, "scenario work bound")
        n = max(map(len, starts.values())) + len(law["arrivals"])
        tapes = []
        for seed in (m.R11_SEED, m.R12_SEED):
            digest = hashlib.sha256(f"{seed}|{key}|{scenario}".encode()).hexdigest()
            rng = random.Random(int(digest[:16], 16))
            tapes.append(tuple(tuple(rng.random() for _ in range(10)) for _ in range(n)))
        return tuple(law["arrivals"]), *tapes

    def plan_tape(self, tape, first_action):
        return tape

    def reference(self, start, plan, tape, cell):
        m = self.module
        return m.r12_simulate(
            start, tuple(c for c in plan for _ in range(2)), *tape,
            dict(self.model, cell=cell), self.costs, self.offsets)

    def advance(self, state, cap, tape, cell, n0):
        m, costs = self.module, self.costs
        pop, ai, goods, rejected, offered, maximum = state
        j = len(goods)
        arrivals, uniforms, release_uniforms = tape
        batch = m.r11_batch(((ph, cell, cls) for ph, _, cls, _ in pop), self.model["prompt_k"])
        hold, releases, nxt, good = [], [], [], 0
        for ph, tt, cls, idx in pop:
            records, _ = m._r11_resolve(
                self.model["table"], m._r11_keys(cell, cls, ph, tt, batch, True))
            rec = records[min(int(uniforms[idx][j] * len(records)), len(records) - 1)]
            good += rec[2]
            if ph in m.COST_PHASES:
                c = costs[(cell, cls)]
                if rec[0] in m.COST_PHASES:
                    hold.append(c)
                else:
                    pool = m._r12_pool(self.offsets, cell, cls)
                    off = pool[min(int(release_uniforms[idx][j] * len(pool)), len(pool) - 1)]
                    releases.append((j * m.STEP_S + off, c))
            if rec[0] != "GONE":
                nxt.append((rec[0], rec[1], cls, idx))
        releases.sort()
        held, ri, births = math.fsum(hold), 0, []
        rejected, offered = list(rejected), list(offered)
        while ai < len(arrivals) and arrivals[ai][0] <= (j + 1) * m.STEP_S + m.EPS:
            a, cls = arrivals[ai][:2]
            offered.append(a)
            while ri < len(releases) and releases[ri][0] <= a + m.EPS:
                ri += 1
            c = costs[(cell, cls)]
            reserved = held + math.fsum(x for _, x in releases[ri:])
            if reserved + c > cap + m.EPS:
                rejected.append(a)
            else:
                held += c
                maximum = max(maximum, reserved + c)
                births.append((cls, int(a - j * m.STEP_S > m.STEP_S / 2 + m.EPS), n0 + ai))
            ai += 1
        for cls, half, idx in births:
            records, _ = m._r11_resolve(
                self.model["table"], m._r11_entry_keys(cell, cls, half, batch, True))
            rec = records[min(int(uniforms[idx][j] * len(records)), len(records) - 1)]
            good += rec[2]
            if rec[0] != "GONE":
                nxt.append((rec[0], rec[1], cls, idx))
        return tuple(nxt), ai, goods + (good,), tuple(rejected), tuple(offered), maximum

    def prefix(self, start, plan, tape, cell, cache, check):
        state = (tuple((ph, tt, cls, i) for i, (ph, tt, cls) in enumerate(start)),
                 0, (), (), (), 0.)
        steps = 0
        for depth, cap in enumerate(plan, 1):
            key = plan[:depth]
            if key not in cache:
                for _ in range(2):
                    check()
                    state = self.advance(state, cap, tape, cell, len(start))
                    check()
                    steps += 1
                cache[key] = state
            state = cache[key]
        _, _, goods, rejected, offered, maximum = state
        result = {}
        for h in OFFSETS:
            result[f"good_{h:g}"] = float(sum(goods[:int(h * 2)]))
            result[f"rejected_{h:g}"] = float(sum(t <= h + self.module.EPS for t in rejected))
            result[f"offers_{h:g}"] = float(sum(t <= h + self.module.EPS for t in offered))
        result["max_reserved_after_admission"] = maximum
        return result, steps


class FrozenV10BinaryScorer(FrozenV9BinaryScorer):
    """Same transition arithmetic; stable source streams shared by simulated identity."""

    SOURCE_SHA = R14_V10_SHA
    VERSION_ATTRIBUTE = "STABLE_CRN_VERSION"
    VERSION = "nv3-opus-stable-crn-v10"

    def tape(self, cut, key, scenario, starts, start_ids=None):
        m = self.module
        _require(start_ids is not None and set(start_ids) == set(CAPS), "stable identities required")
        live = tuple(f"rid:{rid}" for rid, *_ in cut["live"])
        pending = {f"rid:{rid}" for rid, *_ in cut["pending"]}
        for cap in CAPS:
            ids = start_ids[cap]
            _require(len(ids) == len(starts[cap]) and len(set(ids)) == len(ids)
                     and tuple(ids[:len(live)]) == live and set(ids[len(live):]) <= pending,
                     "stable initial identity/owner mismatch")
        law = m.draw_common_law(cut, key, scenario)
        _require(len(law["arrivals"]) <= 512, "scenario work bound")
        arrivals = tuple(law["arrivals"])
        member_cache, release_cache, tapes = {}, {}, {}
        for cap in CAPS:
            member = m.StableUniforms(m.R13_SEED + "|member", key, scenario, start_ids[cap])
            release = m.StableUniforms(m.R13_SEED + "|release", key, scenario, start_ids[cap])
            # A cache never crosses a tag, origin, scenario, endpoint solve or source.
            member.cache, release.cache = member_cache, release_cache
            tapes[cap] = arrivals, member, release
        return tapes

    def plan_tape(self, tape, first_action):
        return tape[first_action]


def optimize_v9_binary(request, starts, scorer, *, method="prefix", enabled=False,
                       deadline_at=None, now=time.perf_counter, _start_ids=None,
                       _expected_source=R13_V9_SHA):
    """Offline observational mean-G5 enumeration; never authorizes an applied action."""
    began, cpu = now(), time.process_time()
    last, scores, outputs, tapes, caches = began, [], [], [], []
    status, reason, incumbent, steps, one_elapsed = "inactive", None, None, 0, None

    def check():
        nonlocal last
        stamp = now()
        _require(isfinite(stamp) and stamp >= last, "solver clock regressed")
        last = stamp
        if deadline_at is not None and stamp >= deadline_at:
            raise TimeoutError("cooperative deadline")

    if enabled:
        try:
            _require(enabled is True and method in ("reference", "prefix"), "solver mode")
            _require(deadline_at is None or (
                type(deadline_at) in (float, int) and isfinite(deadline_at)), "invalid deadline")
            check()
            m = scorer.module
            _require(scorer.source_sha == _expected_source, "source identity")
            step, cut, starts = _immutable(request.step), _immutable(request.cut), _immutable(starts)
            start_ids = _immutable(_start_ids)
            identity = request.identity
            _require(identity.deployment == R8_CORE and identity.cost_model == m.COMMON_BINDING["cost_hash"]
                     and identity.clock_domain == m.COMMON_BINDING["clock_domain"]
                     and identity.epoch and request.native_run_id and request.state_id and request.key,
                     "source/run/clock identity")
            incumbent = step["gateway"]["budget"]
            _require(incumbent in CAPS and cut["cell"] == step["cell"] and cut["t0"] == step["t0"]
                     and all(isfinite(x) for x in (request.sampled_at, request.received_at, cut["t0"]))
                     and request.sampled_at <= request.received_at <= cut["t0"]
                     and 0 <= cut["t0"] - request.sampled_at <= .5, "receipt freshness")
            _require(not m.joint_ood(step, scorer.support), "prefix support/outstanding action")
            owners = dict(request.original_costs)
            _require(len(owners) == len(request.original_costs) <= MAX_REQUESTS
                     and set(owners) == set(step["cohort"])
                     and all(isfinite(c) and c > 0 for c in owners.values())
                     and math.isclose(math.fsum(owners.values()), step["gateway"]["reserved"],
                                      abs_tol=1e-9, rel_tol=1e-12), "original cost stock")
            _require(len(cut["live"]) == len(owners)
                     and {rid for rid, *_ in cut["live"]} == set(owners)
                     and all(c == owners[rid] for rid, c, _, _ in cut["live"]),
                     "immutable live cost")
            pending = cut["pending"]
            _require(len(pending) <= MAX_REQUESTS and len({r[0] for r in pending}) == len(pending)
                     and not {r[0] for r in pending} & set(owners)
                     and all(c == scorer.costs[(cut["cell"], cls)] and 0 <= age <= 30
                             for _, c, cls, age in pending), "pending stock")
            _require(set(starts) == set(CAPS) and all(len(s) <= 2 * MAX_REQUESTS for s in starts.values())
                     and all(len(starts[a]) >= len(owners) for a in CAPS), "initial population bound")
            _require(all(
                tuple(scorer.costs[(cut["cell"], cls)] for _, _, cls in starts[a][:len(owners)]) ==
                tuple(c for _, c, _, _ in cut["live"])
                and all(ph in m.COST_PHASES for ph, _, _ in starts[a][:len(owners)])
                for a in CAPS), "initial owners evicted or recosted")
            _require(isfinite(cut["law"]) and 0 <= cut["law"] <= 64
                     and len(cut["mix"]) <= 16 and (cut["law"] == 0 or bool(cut["mix"]))
                     and all(type(n) is int and n > 0 and
                             isfinite(scorer.costs[(cut["cell"], cls)]) and
                             scorer.costs[(cut["cell"], cls)] > 0 for cls, n in cut["mix"]),
                     "common exogenous law bound")
            for i in range(R9_SCENARIOS):
                check()
                tapes.append(scorer.tape(cut, request.key, i, starts, start_ids))
                caches.append({})
                check()
            order = sorted(R9_ONE_MOVE, key=lambda p: _mean_plan_tie(p, incumbent))
            order += [p for p in R9_ALL_PLANS if p not in R9_ONE_MOVE]
            for plan in order:
                runs = []
                for i, tape in enumerate(tapes):
                    check()
                    tape = scorer.plan_tape(tape, plan[0])
                    if method == "reference":
                        run = scorer.reference(starts[plan[0]], plan, tape, cut["cell"])
                        steps += 10
                    else:
                        run, count = scorer.prefix(
                            starts[plan[0]], plan, tape, cut["cell"], caches[i], check)
                        steps += count
                    check()
                    _require(all(isfinite(run[k]) and run[k] >= 0 for k in R13_METRICS),
                             "nonfinite or negative scenario")
                    _require([run[f"good_{h:g}"] for h in OFFSETS] ==
                             sorted(run[f"good_{h:g}"] for h in OFFSETS), "noncumulative good")
                    _require(all(run[f"offers_{h:g}"] == sum(t <= h + m.EPS for t, *_ in tape[0])
                                 for h in OFFSETS), "candidate-dependent offer law")
                    runs.append(tuple(run[k] for k in R13_METRICS))
                outputs.append(tuple(runs))
                scores.append(dict(plan=plan, mean_good=tuple(
                    math.fsum(run[j] for run in runs) / R9_SCENARIOS for j in (0, 3, 6))))
                if len(scores) == len(R9_ONE_MOVE):
                    one_elapsed = now() - began
            status = "offline_candidate"
            check()
        except TimeoutError as exc:
            status, reason = "deadline", str(exc)
        except (ValueError, KeyError, TypeError, IndexError, AttributeError, OverflowError) as exc:
            status, reason = "unsupported", f"{type(exc).__name__}:{exc}"
    one = full = None
    rank = lambda r: (-r["mean_good"][2], _mean_plan_tie(r["plan"], incumbent))
    if len(scores) >= 4:
        one = min((r for r in scores if r["plan"] in R9_ONE_MOVE), key=rank)
    if len(scores) == 32:
        full = min(scores, key=rank)
    finished = now()
    if not isfinite(finished) or finished < last:
        status, reason = "unsupported", "solver clock regressed"
    elif status == "offline_candidate" and deadline_at is not None and finished >= deadline_at:
        status, reason = "deadline", "final return deadline"
    return dict(status=status, reason=reason, method=method, scores=scores, outputs=outputs,
                one_move=one, mpc=full, one_completed_wall_s=one_elapsed,
                implied_gain=full["mean_good"][2] - one["mean_good"][2] if full and one else None,
                first_action_differs=full["plan"][0] != one["plan"][0] if full and one else None,
                candidate_first_action=full["plan"][0] if status == "offline_candidate" else None,
                fallback="incumbent_no_new_action", active_permit=False, causal_plan_support=False,
                completed_plans=len(scores), completed_draws=len(tapes), completed_half_steps=steps,
                cached_prefixes=sum(map(len, caches)), wall_s=finished - began,
                cpu_s=time.process_time() - cpu, source_sha=scorer.source_sha,
                kernel_id=scorer.kernel_id)


def optimize_v10_binary(request, starts, start_ids, scorer, **kwargs):
    return optimize_v9_binary(request, starts, scorer, _start_ids=start_ids,
                              _expected_source=R14_V10_SHA, **kwargs)


def run_r13(frozen_path, train_path, evaluate_path, *, _stable=False):
    import sys
    from collections import Counter, defaultdict
    from pathlib import Path
    root = Path(frozen_path)
    manifest_raw = (root / "manifest.json").read_bytes()
    manifest_sha = ("2bb51485f6fc6401716c9c2eb86e1b759cd43a9be8844d9e9f775e7c5795df99"
                    if _stable else "da0464904d863e29a324484be3e58d3400af705813884b2d5a94666640599308")
    _require(hashlib.sha256(manifest_raw).hexdigest() == manifest_sha, "binary profile manifest")
    for owner, receipt in json.loads(manifest_raw).items():
        for name, digest in receipt["files"].items():
            _require(hashlib.sha256((root / owner / Path(name).name).read_bytes()).hexdigest() == digest,
                     "R13 frozen bytes")
    m = _r12_load(root / "opus/native_release_model.py", "astra_binary_opus",
                  R14_V10_SHA if _stable else R13_V9_SHA)
    historical = {}
    if _stable:
        raw = (root / "astra/astra.md").read_text().rsplit(
            "\n## R13 generated complete raw JSON\n", 1)[1].split("```json\n", 1)[1].split("\n```", 1)[0]
        _require(hashlib.sha256(raw.encode()).hexdigest() ==
                 "e8d3c6006e4e6548d13f3dbc4e72c654d18316d85b9a331541bc73167663a5fb",
                 "corrected historical v9 receipt")
        historical = {(r["state_id"], r["endpoint"]): r for r in json.loads(raw)["cases"]}
    train, _, train_receipt = _r8_archive(train_path, R8_TRAIN, m)
    episodes, documents, eval_receipt = _r8_archive(evaluate_path, (181008, 181009), m)
    source, index = m.bind_source(Path(evaluate_path))
    for d in documents.values():
        m.bind_assignments(d, m.SOURCE_BINDINGS[source]["holds"], index["clock_domain"])
    entries = m._r8_entries(train)
    model, costs = m.fit_batch_progress(entries), m.payload_costs(train)
    _require(all(costs.get(k) == v for k, v in m.payload_costs(episodes).items()), "payload cost shift")
    support = m.joint_support([s for _, s, _, _ in m._progress_rows(entries)])
    scorer_type = FrozenV10BinaryScorer if _stable else FrozenV9BinaryScorer
    scorers = {endpoint: scorer_type(
        m, model, costs, m.fit_release_offsets(entries, endpoint), support)
               for endpoint in ("upper", "lower")}
    candidates, excluded = defaultdict(list), Counter()
    identities = {}
    for e, steps, _, rows in m._r8_entries(episodes):
        raw = {r["request_id"]: r for r in e["client_rows"]}
        classes = {rid: m.payload_class(r) for rid, r in raw.items()}
        order = sorted((r["sent"], rid) for rid, r in rows.items())
        by_class = defaultdict(list)
        for t, rid in order:
            by_class[classes[rid]].append(t)
        sent = ([t for t, _ in order], [rid for _, rid in order], dict(by_class))
        origins, parsed, _ = m.build_origins(dict(e, origin_grid_s=.5))
        observations = {o["grid_index"]: parsed[o["index"]][1] for o in origins}
        for step, seen, _, _ in m._r11_walk(steps, rows):
            if step["k"] % 4:
                continue
            reasons = m.joint_ood(step, support)
            if reasons:
                excluded.update(reasons)
                continue
            obs = observations[step["k"]]
            cut = m.admission_cut_state(step, rows, raw, costs, sent)
            request = MeanPlanRequest(
                f"{e['episode_id']}:{step['k']}:{obs['gateway']['sequence']}",
                Identity(R8_CORE, e["run_id"], e["clock_domain"], m.COMMON_BINDING["cost_hash"]),
                e["native_run_id"], obs["gateway"]["sampled_at"], obs["native_received_at"],
                f"{e['seed_block']}|{e['cell']}|{step['k']}", step, cut,
                tuple((r["request_id"], r["cost"]) for r in obs["gateway"]["requests"]))
            starts = {a: tuple(m.r11_cut_start(step, rows, classes, seen - step["cohort"],
                                             cut, [a] * 10, costs)) for a in CAPS}
            if _stable:
                ids = {}
                for cap in CAPS:
                    same_start, ids[cap] = m.r13_cut_start(
                        step, rows, classes, seen - step["cohort"], cut, [cap] * 10, costs)
                    _require(tuple(same_start) == starts[cap], "stable CRN changed initial population")
                identities[request.state_id] = ids
            candidates[str(e["seed_block"])].append((e["cell"], e["arm"], step["k"], request, starts))
    selected = []
    for block, choices in sorted(candidates.items()):
        choices.sort(key=lambda r: r[:3])
        _require(len(choices) >= 8, "eight deterministic eligible cuts required per block")
        selected.extend((block, choices[j * (len(choices) - 1) // 7]) for j in range(8))
    _require(len(selected) == 16, "bounded sixteen cuts")
    if _stable:
        _require({(r[3].state_id, endpoint) for _, r in selected for endpoint in scorers} ==
                 set(historical), "same sixteen R13 cuts/endpoints required")
        _require(all(scorers[endpoint].kernel_id == row["runs"]["reference"]["kernel_id"]
                     for (_, endpoint), row in historical.items()), "unchanged fitted kernel/cost/offsets")
    results = []
    for ordinal, (block, (cell, arm, k, request, starts)) in enumerate(selected):
        for endpoint, scorer in scorers.items():
            record = dict(block=block, cell=cell, arm=arm, grid_index=k,
                          state_id=request.state_id, endpoint=endpoint, runs={})
            if _stable:
                old = historical[(request.state_id, endpoint)]["runs"]["reference"]
                record.update(start_ids=identities[request.state_id], starts=starts,
                              prior_v9=dict(one_move=old["one_move"], mpc=old["mpc"],
                                            first_action_differs=old["first_action_differs"],
                                            implied_gain=old["implied_gain"]))

            def solve(method, deadline_at=None):
                kwargs = dict(method=method, enabled=True, deadline_at=deadline_at)
                if _stable:
                    return optimize_v10_binary(request, starts, identities[request.state_id], scorer, **kwargs)
                return optimize_v9_binary(request, starts, scorer, **kwargs)

            methods = ("reference", "prefix") if ordinal % 2 == 0 else ("prefix", "reference")
            # One cold solve of each type per cut/endpoint, with no cross-call cache.
            complete = {}
            for method in methods:
                complete[method] = solve(method)
            a, b = complete["reference"], complete["prefix"]
            _require(a["scores"] == b["scores"] and a["outputs"] == b["outputs"]
                     and a["status"] == b["status"], "binary reference/prefix discrepancy")
            reference_outputs = a["outputs"]
            for method, result in complete.items():
                outputs = result.pop("outputs")
                result["outputs_sha256"] = hashlib.sha256(json.dumps(
                    outputs, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
                record["runs"][method] = result
            record["exact_scenario_outputs"] = len(a["scores"]) * R9_SCENARIOS
            for method in reversed(methods):
                result = solve(method, time.perf_counter() + R9_DEADLINE_S)
                outputs = result.pop("outputs")
                # Completed deadline plans must also equal their unbudgeted reference.
                _require(outputs == reference_outputs[:len(outputs)]
                         and result["scores"] == a["scores"][:len(outputs)], "deadline score discrepancy")
                result["outputs_sha256"] = hashlib.sha256(json.dumps(
                    outputs, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
                record["runs"][method + "_100ms"] = result
            results.append(record)
    summary = {}
    for endpoint in scorers:
        cases = [r for r in results if r["endpoint"] == endpoint]
        gains = [r["runs"]["reference"]["implied_gain"] for r in cases
                 if r["runs"]["reference"]["implied_gain"] is not None]
        summary[endpoint] = dict(
            cuts=len(cases), exact_scenario_outputs=sum(r["exact_scenario_outputs"] for r in cases),
            first_action_differences=sum(r["runs"]["reference"]["first_action_differs"] is True
                                         for r in cases),
            mean_implied_gain=statistics.fmean(gains) if gains else None,
            methods={method: dict(statuses=dict(Counter(r["runs"][method]["status"] for r in cases)),
                                  median_wall_s=statistics.median(r["runs"][method]["wall_s"] for r in cases),
                                  max_wall_s=max(r["runs"][method]["wall_s"] for r in cases),
                                  median_cpu_s=statistics.median(r["runs"][method]["cpu_s"] for r in cases))
                     for method in ("reference", "prefix", "reference_100ms", "prefix_100ms")},
            paired_reference_over_prefix=statistics.median(
                r["runs"]["reference"]["wall_s"] / r["runs"]["prefix"]["wall_s"] for r in cases))
    return dict(schema=R14_VERSION if _stable else R13_VERSION,
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                python=sys.version, executable=sys.executable, train_receipt=train_receipt,
                evaluation_receipt=eval_receipt, eligible_counts={b: len(v) for b, v in candidates.items()},
                exclusions=dict(excluded), summary=summary, cases=results, deadline_s=R9_DEADLINE_S,
                scenarios=R9_SCENARIOS, observational_scores_only=True, active_permit=False)


def run_r14(frozen_path, train_path, evaluate_path):
    return run_r13(frozen_path, train_path, evaluate_path, _stable=True)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Frozen Train-only R8 direct response diagnostic")
    parser.add_argument("--r8-train")
    parser.add_argument("--r8-evaluate")
    parser.add_argument("--r8-loader")
    parser.add_argument("--sealed-commit")
    parser.add_argument("--r9-train")
    parser.add_argument("--r9-evaluate")
    parser.add_argument("--r9-loader")
    parser.add_argument("--r10-train")
    parser.add_argument("--r10-evaluate")
    parser.add_argument("--r10-loader")
    parser.add_argument("--r10-saved-rankings", action="store_true")
    parser.add_argument("--r11-train")
    parser.add_argument("--r11-evaluate")
    parser.add_argument("--r11-loader")
    parser.add_argument("--counter-train")
    parser.add_argument("--counter-evaluate", nargs=3)
    parser.add_argument("--counter-loader")
    parser.add_argument("--r12-frozen")
    parser.add_argument("--r12-train")
    parser.add_argument("--r12-evaluate", nargs=3)
    parser.add_argument("--r13-frozen")
    parser.add_argument("--r13-train")
    parser.add_argument("--r13-evaluate")
    parser.add_argument("--r14-frozen")
    parser.add_argument("--r14-train")
    parser.add_argument("--r14-evaluate")
    parser.add_argument("--append-report", action="store_true")
    args = parser.parse_args()
    if args.r14_frozen:
        if not (args.r14_train and args.r14_evaluate):
            parser.error("R14 requires frozen v10, Train1-3 and the same USED8/9 archives")
        result = run_r14(args.r14_frozen, args.r14_train, args.r14_evaluate)
        round_name = "R14"
    elif args.r13_frozen:
        if not (args.r13_train and args.r13_evaluate):
            parser.error("R13 requires frozen v9, Train1-3 and USED8/9 archives")
        result = run_r13(args.r13_frozen, args.r13_train, args.r13_evaluate)
        round_name = "R13"
    elif args.r12_frozen:
        if not (args.r12_train and args.r12_evaluate):
            parser.error("R12 requires frozen source, Train1-3 and three used4-9 archives")
        result = run_r12(args.r12_frozen, args.r12_train, args.r12_evaluate)
        round_name = "R12"
    elif args.counter_train:
        if not (args.counter_evaluate and args.counter_loader):
            parser.error("counter diagnostic requires train, three used archives and loader")
        result = run_stayer_output(args.counter_train, args.counter_evaluate, args.counter_loader)
        round_name = "R11b counter"
    elif args.r11_train:
        if not (args.r11_evaluate and args.r11_loader):
            parser.error("R11 requires train, evaluate and loader paths")
        result = run_r11_progress(args.r11_train, args.r11_evaluate, args.r11_loader)
        round_name = "R11"
    elif args.r10_saved_rankings:
        from pathlib import Path
        result = r10_saved_diagnostic(Path(__file__).with_name("astra.md").read_text())
        round_name = "R10 saved rankings"
    elif args.r10_train:
        if not (args.r10_evaluate and args.r10_loader):
            parser.error("R10 requires train, evaluate and loader paths")
        result = run_r10(args.r10_train, args.r10_evaluate, args.r10_loader)
        round_name = "R10"
    elif args.r9_train:
        if not (args.r9_evaluate and args.r9_loader):
            parser.error("R9 requires train, evaluate and loader paths")
        result = run_r9(args.r9_train, args.r9_evaluate, args.r9_loader)
        round_name = "R9"
    else:
        if not (args.r8_train and args.r8_evaluate and args.r8_loader and args.sealed_commit):
            parser.error("R8 requires train, evaluate, loader and sealed-commit")
        result = run_r8(args.r8_train, args.r8_evaluate, args.r8_loader, args.sealed_commit)
        round_name = "R8"
    raw = json.dumps(result, sort_keys=True, separators=(",", ":"), allow_nan=False)
    if args.append_report:
        from pathlib import Path
        digest = hashlib.sha256(raw.encode()).hexdigest()
        with Path(__file__).with_name("astra.md").open("a") as report:
            report.write(f"\n\n## {round_name} generated complete raw JSON\n\nCanonical JSON SHA256: `"
                         + digest + "` (UTF-8, excluding fence/newline).\n\n```json\n"
                         + raw + "\n```\n")
        print(json.dumps(dict(raw_json_sha256=digest, summary=result.get("summary"),
                              fit_rows=result.get("fitted", {}).get("n"),
                              blocks={b: {k: v for k, v in d.items() if k != "rows"}
                                      for b, d in result["blocks"].items()} if round_name == "R8" else {}),
                         sort_keys=True))
    else:
        print(raw)
