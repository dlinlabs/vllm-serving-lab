# NV3 Opus 獨立提案（Round 1）：history-conditioned 原始成本釋放模型

狀態：**獨立初稿，未讀 peer NV3 提案**。沒有新的 native／MPC 結果；
本文件與程式只定義可在實際 Gateway marks／ledger 與 native frames 上執行的
模型、ground truth 與否證測試。單元 fixtures 只驗證會計與因果性，
不是 native 性能、校準或統計保證。

## 1. 共同 ground truth：useful／physical／tail work（不放寬舊 audit）

Strict HTTP 基線（exact UUID、4096 prompt／32 output／natural EOS）：
34 steps＝2 prefill＋32 decode；worker 連續 forward positions 結束於 4128，
delivered-token 最小值 `P+O−1=4127`。舊 v2 `audit_capture` 的
`progress == input+output−1` 因此**仍為 FALSE，原樣保留**。

明確會計（`forward_work_accounting`）：

| 量 | 定義 | 基線值 |
|---|---|---:|
| useful positions | `P+O−1`（最後 sampled token 不需再 forward） | 4127 |
| physical positions | 實際連續 executed positions 終點 | 4128 |
| tail positions | physical − useful | 1 |
| useful steps | 結束 ≤ useful 邊界的 steps（2 prefill＋31 decode） | 33 |
| tail steps | 起點 ≥ useful 邊界的 steps | 1 |

`tail_accounted=True` 只在全部成立時：natural EOS；positions 無 gap／repeat／split；
每個 step 與 worker `executed_positions/executed_counts` 相符；tail ≤1 token；
tail step 是單 token decode 且 **schedule start < engine finish**（pre-finish placeholder）。
否證（各有測試）：tail step 在 finish 後才排程、tail>1（unexplained work）、
tail<0（missing useful work）、position gap、跨越 useful 邊界、worker 未匹配。
GPU elapsed 只是 per-step current-stream label，不是絕對 GPU／host clock
或獨占 service duration；本模組不把它相加成 service time。

對 release 模型的含義：reservation release 不早於 EOS output commit，
tail forward 是 release 之前可能的物理延遲來源；它作為誤差解釋 label，
不是預測輸入。

## 2. 可觀測狀態與 transition

Origin `t0`＝joined observation 的 native client receipt；要求同 run／clock domain、
`gateway.sampled_at ≤ received_at ≤ t0`、age ≤0.5s、native ID
`chatcmpl-<uuid>-<8hex>` 精確 join（未 join／重複即拒絕）。
Cohort＝origin snapshot 中所有 live marks（原始 cost、prompt、max、admitted、first）。

每 mark 特徵（全部 ≤t0 可得）：cost、prompt_k、max/100、started、age、
native_unknown、output progress、remaining cap、decode batch D、
prefill backlog k-tokens（native output=0 ＋ Gateway 已收但 native 未見）、
waiting、cohort cost R、**計畫中**的 cap（frozen `cap_plan` 時間平均，
非 realized）、trailing 2s realized release rate（只用先前已收到的 snapshot pairs）。
有測試證明修改未來 observations 不改變 origin 特徵。

Exact transition 部分沿用 Gateway 守恆：每個 `mpc_ledger` frame 是單一事件，
delta<0 即一次 release（原始 cost、effective_at）。

## 3. Response：累計釋放原始 cost 的 ground truth（含不確定）

Target：origin cohort 在 `(sampled_at, t0+h]` 已釋放的原始 cost，h∈{1,3,5}s；
包含 observation lag 內已發生的 release。

1. Ledger 必須 sequence 連續、complete、同 run/clock；每個 snapshot 的 mark cost 和
   必須等於該 sequence 的 ledger reserved（否則拒絕）。
2. 每個 cohort mark 的消失區間＝最後出現與下一個 snapshot 的 sequence 區間。
3. 同區間同 cost 的 ledger release 事件為候選；若 `n_g` 事件、`m_g` cohort marks：
   cohort 已釋放數 ∈ `[max(0, r−(n_g−m_g)), min(r, m_g)]`（r＝≤τ 的事件數）。
   Cost 相同且有非 cohort release 時輸出**區間**而非猜測；`n_g<m_g` 拒絕。
4. 超過最後 snapshot 而仍未消失的 marks 是 censored 上界。

Per-mark label：唯一可識別時才給 0/1；否則 None，排除於 fit 並計數報告
（選擇偏差限制已承認）。

## 4. 比較的模型（全部只用 Train fit；無發明的 service 參數）

| 模型 | 形式 | 參數來源 |
|---|---|---|
| train_fraction | `R·p̄_h` | Train 精確 truth 的平均釋放比例 |
| fluid_history | `min(R, μ·h)`，μ＝trailing realized rate，缺少時用 Train 平均 cost/s | 歷史＋Train |
| batch_aware | `Σ cost_i·p_i(h)`，per-horizon L2 logistic，h 間 cummax 單調 | Train per-mark labels |

L2=1.0（標準化特徵）、α=0.1、history 2s 均**預先宣告、不調參**。
`fit` 拒絕任何非 Train row；seed block 只能屬於一個 partition；
final held-out **160021–160024 一律拒絕**（未使用）。

## 5. 評估：one／multi／OOD、block calibration

- 主要指標：`mean_h |pred(h)−actual(h)| / R_origin`，episode→block→平均；
  truth 為區間時報 lower/upper error；`R_origin=0` 另計不納入。
- One-step（1s）與 multi-step（3／5s）同一 origin 同時發布，不用 realized future gaps。
- OOD：Train 支援域（R、D、prefill_k、waiting、cap、planned cap、cohort size、
  `(prompt,max)` work shapes）外**整個 origin abstain**，所有模型配對相同樣本；
  abstention 原因逐項計數。
- Calibration：只用 Calibration blocks 的 split residual quantiles 形成 band，
  Development 報 per-block 覆蓋（lower＝所有可行 truth 皆覆蓋、upper＝某個可行 truth 覆蓋）。
  Blocks 間 exchangeability 未證，**不是 coverage 保證**。

## 6. Strong One-move vs MPC、因果支援與安全部署（本模組之外的條件）

- 本模型輸出 `P(release | H_t0, planned cap)`；cap 依賴性只有在 randomized
  cap-sequence episodes（Gate B LL/LH/HL/HH）支援下才可解讀為 action response；
  觀察資料上的 cap 係數不是因果斜率。
- Strong One-move 與 MPC 必須使用同一模型、同一 abstention 與同一 continuation
  （由 Development 在 hold／fixed／reactive 中選定）；只有 multi-step forecast
  在 Development 優於 train_fraction／fluid_history 時，multi-move 才有資訊價值。
- 部署：任何 OOD abstain 或 truth/ledger 驗證失敗 → 回到 development-chosen
  best-supported-fixed；cap 16/32 是 cost cap 而非 concurrency；無 KV hard-safety 宣稱。

## 7. 否證條件（預先宣告）

1. batch_aware 在 Development blocks 上未低於兩個 baseline 的 upper error →
   batch 特徵沒有超過 fluid 的預測價值，不得用於 MPC。
2. 3／5s 誤差相對 1s 未改善 baseline 差距 → 不支持 multi-step 規劃。
3. Development 覆蓋顯著低於 1−α 或 block 間差異大 → band 不可作 risk 約束。
4. 需要 abstain 的 origin 比例高 → 支援域不足，需要更多 randomized Train。
5. tail_accounted 對任何 natural-EOS request 為 False → release 延遲解釋失敗。

## 8. Receipt

- 檔案：`native_release_model.py`
  sha256 `86f45ab851a446b4a903c8e5f0991acb198ecc4fc5d9d0d9bd0d05e38e77411b`；
  `test_native_release_model.py`
  sha256 `1f38d3cb88d9c89d9acf2296b94278f02ed4f73a7e3e98caf5f7f045f902bed3`。
- 測試：`cd experiments/mpc-research/native-v3 && python3 test_native_release_model.py`
  → `9 passed`（Python 3.14.4，stdlib only；pytest 亦可收集 `test_*`）。
  Sandbox 阻擋 pip，故未安裝 numpy／pytest。
- 沒有 SSH／GPU／API、push、merge、`gt done`；沒有讀 peer NV3 提案；
  沒有 native 數據、fixture 常數或統計保證被宣稱為結果。
- 資料 adapter：raw NV3 capture → episode schema（見模組 docstring）待 Gate A／B
  原始資料存在後依實際欄位實作；目前不猜測 capture 欄位。

## Round 2：交叉審查（peer 原始碼，非僅 test pass）

所有反例皆在 `test_native_release_model.py` 中，以 sha256 鎖定 Mayor 凍結的 R1 bytes 後 importlib 載入（`NV3_PEER_ROOT` 可覆寫；檔案不在則 SKIP，不偽造）。重現：`cd experiments/mpc-research/native-v3 && python3 test_native_release_model.py`。

### Gemini（`native_campaign_protocol.py`）— 不可採用為 campaign 協定
| # | 發現 | 反例 test |
|---|---|---|
| G1 | ≥10h 由「計畫 90s offer + 30s max-drain」×320 得出；違反「planned/max-drain 不計入 actual」 | `..._counts_planned_drain_...` |
| G2 | `compute_work_accounting`：end=4100 時 tail=0（27 個缺失位置被 `max(0,·)` 隱藏）；end=4200 時 tail=73 仍寫死「placeholder 1」原因；physical=end+1=4129 與 useful=4128 的單位不同 | `..._hides_missing_and_invents_tail_cause` |
| G3 | concurrency>1 即宣告 serial 被證偽：屬斷言而非資料 | （code review） |
| G4 | 偽重複保護只檢查標籤：同一 block 換 id/seed 複製 6 次 → `CONFIRMED_SUPERIOR` | `..._one_block_relabelled_six_times` |
| G6 | NAE 對空 origin 與缺 horizon 回傳 0 誤差（白送完美分數） | `..._score_as_zero_error` |
| G8 | StrongOneMove 不讀 continuation：c 與 48−c 決策完全相同；「MPC」為寫死閾值啟發式 → 弱基準 | `..._one_move_ignores_its_continuation` |
| G9 | `unseen_ood_mix` 有 10 個 Train blocks（非 OOD）；`mixed_short_long` 僅單一 prompt 2048，與宣稱 80/20 不符；到達率與「120% capacity」為虛構 | 同 G1 test |

### Sol（`native_experiment_audit.py`）— 整體嚴謹，tail 規則較我嚴格，已採納
- 採納：tail 步驟要求輸出 commit 不早於 finish（Sol：`begin < eos <= commit`）。我的 R1 只檢查 `start < finished`。**修正**：`forward_work_accounting` 新增 `tail_commit_before_finish` 證偽；falsifier test 已補。
- 反例 S1：censored 列在 `observed_until − sent_at = 30s` 無 first content，TTFT≤0.5s 已不可能，但 `good_upper` 仍為 1。這是保守的上界，不會產生錯誤宣稱，但會放寬界限而減損辨識力（`test_peer_sol_censored_upper_bound_...`）。
- 次要：`scheduled == origin+offset_s` 用精確浮點相等；`pair_order` 宣告未用；exact sign-flip 上限 16 blocks。皆不影響正確性。

### Astra（`native_response_planner.py`）— 介面嚴謹，無模型
- R1 懷疑：fresh `sum(costs)+c<=cap` 與 gateway 遞增 float 累計不一致。以 gateway CostSpec 形式、cap 16/32、20000 條隨機 admit/release 軌跡檢查，**未重現分歧**；撤回此疑慮，不宣稱缺陷。
- `stage="unknown"` 一律 fallback：過往 joined 樣本約 18%（1865/10367）屬 gateway 已 admit、native 未見，致多數決策為 `shadow_cap=None`。誤差容許度 error_below/above 為呼叫端純量，未經校準。one/two-move 計畫族不巢套。
- **自身修正（受此審查啟發）**：R1 以 `history_rate=-1.0` 哨兵值編碼「無歷史」，會被 logistic 當作真實速率外插。改為 `history_rate=0` + 顯式 `history_missing` 指示特徵。

### 未解決分歧
1. 未知 native 工作：Astra 棄權；我把它當特徵（`native_unknown`）。需資料決定（見實驗 E1）。
2. Tail 嚴格度：Sol 要求 `delivered_output_from_step=False` 的明確證據；我要求 commit≥finish 加 forward 匹配，未要求該欄位。若 native capture 有該欄位，應以 Sol 版本為準。
3. Gemini 的計畫時數與啟發式控制器：我認為不可作為 ≥10h 或 MPC 優越性的依據。
4. 16-arm 資格（40 HTTP、natural EOS 40、16 個 v3 audit valid、8 個 v2 FALSE 保留、20 個明確 tail token）只驗證 capture/HTTP/drain，**不**驗證預測、MPC 或 overhead；本報告無任何 native 預測結果。

### 鑑別性 native 實驗（Development blocks，不動 160021–160024）
- E1：在同一批 Train/Dev 原點上比較 `native_unknown` 特徵與 Astra 式棄權。量測棄權率與 1/3/5s release NAE 及覆蓋率。
- E2：實際 ledger 的 tied-cost 模糊率（區間寬度/上界）。若超過在看資料前預先登錄的門檻，則 per-mark 標籤選擇偏差不可忽略，需改為區間似然。
- E3：tail 發生率對輸出長度與 batch mix 的分佈（以 20 個 tail token 為種子 → 擴展 arms），並以 Sol 與本版 tail 規則交叉判定，任何不一致即為反例。
- E4：LL/LH/HL/HH 隨機化 cap 序列，檢驗 planned-cap 係數是否具因果意義（非僅相關）。
- E5：fluid vs batch_aware 在 Dev 的 block 校準與 OOD 棄權後誤差。batch_aware 未勝出即採 fluid。

### Round 2 receipt
- `native_release_model.py` sha256 `6e277d09c2ccfded2bb11e31164f97515c4bbdcc838f3df3f5a917864b297270`
- `test_native_release_model.py` sha256 `fd120e927353d4eec18c88b48711d68168a9bf3aa034138206b2b789b4ca1379`
- `python3 test_native_release_model.py` → `15 passed, 0 skipped`（Python 3.14.4，stdlib only）
- 本地 commit，bead 保持 in_progress；未執行 gt done／push。

## Round 3：逐一回應 peer 反例、修復、train-only 實際資料診斷

範圍：只改本人三個檔案。R3 只讀取 Train blocks 181001..181016，Calibration/Validation/Final 一律不讀、不 fit、不調參；舊 Final 160021–160024 仍保留不用。本節**沒有** forecast、causal 或 MPC 結果，也沒有 statistical guarantee。

### 逐一回應（針對我 R1/R2 的具體反例）

| 反例（提出者） | 判定 | R3 修復 | 回歸測試 |
|---|---|---|---|
| O1 native run/clock/observer 未檢查（Astra） | 接受 | `_native` 要求 `run_id==native_run_id`、clock_domain、observer_sha256，以及 sampled≤frontend≤received、frontend 寬度 ≤0.05s、age ≤0.5s、running==len(requests)、kv∈[0,1]、`chatcmpl-<32hex>-<8hex>` fullmatch、prompt/maximum_output 與 Gateway mark 一致。這些 predicate 鏡像 `state_sample.join_observations`。不合格的 frame 不算觀測，會計數為 `rejected_native_frames`，不致命 | `test_r3_o1_*` |
| O2 retroactive/負向 ledger release 被當成精確真值（Astra eff .2 vs snapshot .25；Sol eff −100） | 接受 | 新增 `ledger_chronology`（effective_at 不遞減）與 `ledger_snapshot_chronology`（eff[s]≤sampled≤eff[s+1]） | `test_r3_o2_*` |
| O3 `_planned_budget` 平均造成順序 alias（Astra [16,16,32,16]/[16,32,16,16]；Sol 0.5s 切換） | 接受 | 改用無損 slot 編碼：(到下一 slot 邊界時間、t0 預算、ceil(h) 個邊界後的預算)。Astra 的兩個計畫特徵不同。Sol 的 0.5s 計畫不在宣告的 SLOT_S=1s 網格上，直接 raise `cap_plan_off_slot_grid`（宣告範圍，不假裝能編碼） | `test_r3_o3_*` |
| O4 calibrate 合併各原點（Astra [0]*100+[1] 使上帶 1→0；Sol 下帶 −.5→+.5） | 接受 | (a) 原點改在固定決策網格上，取 t0 前最新的 joined 觀測，所以重複觀測或 cadence 改變不會改變權重。(b) `_unique` 依 (block, episode, t0) 去重。(c) 每個 block 各自取 α/2、1−α/2 殘差分位數（用區間真值上下界），帶寬取跨 block 包絡 | `test_r3_o4_*`（兩個） |
| O5 OOD 只看邊際盒、漏掉 age/history、混合 short+long 可通過 | 接受 | 所有使用的特徵都有 range（含 age_s、history_rate、plan 編碼），另加 joint gate：`joint_work_mix`（Train 中出現過的 shape 組合）、`joint_plan_sequence`、leave-one-episode-out NN 半徑（`joint_nn_distance`；少於 2 個 episode 時為 `joint_nn_unavailable`） | `test_r3_o5_*` |
| O6 `tail_accounted` 沒有 placeholder/CUDA/commit 證據；重複 worker key 被合併 | 部分接受 | 新增 `duplicate_worker_step` 問題。`tail_mechanism_evidenced` 需要 `tail_evidence`：placeholder_tokens==1、cuda_completed、delivered_output_from_step False、output_commit_at≥finished。`native_qualification_authority` 恆為 False。保留結構性 `tail_accounted`，但它只代表結構一致 | `test_r3_o6_*` |
| O7 依 horizon 只選精確標籤，使 train_fraction 非單調（{1:4.5,3:0,5:0}） | 接受 | 不再丟棄任何原點或標籤。baseline 用真值上下界平均（另報 `fraction_bounds`、`fluid_rate_bounds`）。logistic 對區間截尾標籤用 0.5 中點（慣例，**非 MLE**），`sensitivity=True` 另以 0/1 補值 fit 出界 | `test_r3_o7_*` |
| logistic 無收斂證明（Astra/Gemini） | 接受 | `fit_logistic` 回報 converged/iterations/last_step/gradient_inf_per_weight/max_abs_beta，未收斂時 `predict` 以 `fit_not_converged` 棄權。單一類別的 horizon 以 `degenerate=True` 常數表示，不偽稱為 fitted model | `test_r3_unconverged_*` |
| 區間標籤選擇偏差（Gemini §10.1） | 接受（部分） | 同 O7。中點仍是慣例；在實際 Train 上報告 0/1 補值敏感度（見下） | 同上 |

### Ledger 不存在時的真值：snapshot brackets
實際 replica **沒有** `mpc_ledger`。snapshot sequence 有間隙，也有 3 個重複，所以真值不能假裝為 ledger 精確值。改用 `snapshot_brackets`：每個 mark 取（最後 live、首次 absent）。h 的下界是「absent≤T」的 cost，上界是「last_live<T」的 cost。mark 消失後若重新出現，raise `mark_reappeared`。測試：`test_r3_snapshot_bracket_truth_without_ledger`。

### Portable 實際 native-frame adapter（只讀）
`load_replica(dir)` 先驗證 `verified-artifact-sha256.jsonl` 中每個 artifact 的 sha256，只載入 split=train 且 seed_block∈181001..181016 的 episode；160021–24 或非 Train 一律 raise。`episode_from_replica` 的 Gateway identity/clock 取自 index；native run/observer 由 frames 取得並要求一致，這只是內部一致性，**不是**獨立 receipt。Join 鏡像 reference 規則，ID 用 exact fullmatch，不用子字串。回歸測試 `test_r3_actual_replica_adapter_reproduces_reference_join_counts` 先比對 artifact hash，再重現 Mayor 的事實：p128-m128-arm0 有 765 個 joined frame，13280 個 mark 中 3034 個 accepted-not-native-visible，0 個 rejected。我也另外用 reference `state_sample.join_observations` 對 181001 其他 episode 交叉核對，計數相同。

### 實際 replica Train-only 診斷（**不是** forecast/causal/MPC 結果）
指令：`python3 native_release_model.py --replica-train-diagnostics <replica>`，約 14 秒。replica 仍在寫入，這是當下快照：22 個 verified artifact，載入 11 個 Train episode。
- clock_domain：`linux-monotonic:64589d75-…:time:[4026534406]`
- collector：6c11fe7e683439f379f0dfdbd21b05f5873b2c90
- native source：2587d2b822dcd3812353ce2ac3369b7192fa7ba7
- native run：58777b3950ff44d88c077e1101096cc8（單一）
- Gateway run_id 每格兩個 episode 共用一個（9950f2…、5101fc…、d06dbf…、e87fd1…、27a40b…、5fcca6…）。這與「每 2 episode rollover、ClockDomain 不變」一致。

| episode | artifact sha256 前 16 | grid 點 | stale | joined frames | rejected |
|---|---|---|---|---|---|
| 181001-mixed-arm0 | c3b5edcc63bb8feb | 120 | 0 | 912 | 0 |
| 181001-mixed-arm1 | fd483ce77832dd52 | 120 | 0 | 903 | 0 |
| 181001-p128-m128-arm0 | d633b4e402e45323 | 121 | 0 | 765 | 0 |
| 181001-p128-m128-arm1 | 467887df4445c5f2 | 121 | 1 | 761 | 0 |
| 181001-p128-m256-arm0 | f99c6470c478a36e | 122 | 0 | 935 | 0 |
| 181001-p128-m256-arm1 | 7ad41e1f0faf34ef | 121 | 0 | 933 | 0 |
| 181001-p4096-m128-arm0 | 74da77e6bc936d88 | 121 | 0 | 878 | 0 |
| 181001-p4096-m128-arm1 | fd61c5abf017d575 | 122 | 0 | 898 | 0 |
| 181001-p4096-m256-arm0 | f7722058627612b4 | 121 | 0 | 945 | 0 |
| 181001-p4096-m256-arm1 | a62d86171cf18028 | 122 | 0 | 961 | 0 |
| 181002-p128-m128-arm1 | 8beef76b13d94f71 | 121 | 0 | 765 | 1 (`native_unjoined_or_ambiguous`) |

- 1331 個原點、12095 個 origin-mark，其中 2087 個 not-native-visible。這是 Train 中真實存在的「未知 native 工作」比例，不能宣稱為全部可見。
- 真值寬度：h=1 有 971 個精確、330 個區間原點，平均寬度占 R 的 0.052，507 個截尾 mark 標籤；h=3 為 1286/15/0.0028/20；h=5 為 1292/9/0.0018/13。結論：~150ms snapshot cadence 對 h=1 不可忽略，對 3/5s 很小。
- Logistic（in-sample，只看收斂與敏感度，**不報任何誤差**）：
  - h=1：10047 released / 1541 unreleased，三種補值皆收斂（8–9 次 Newton），平均標籤敏感度 0.042，最大 0.40。
  - h=3：12065 / 10，皆收斂，但 |β|max 達 16.6（ambiguous_as_1），實質接近分離，資訊量極少。
  - h=5：0 個 unreleased。中點與 as_1 都是 degenerate 常數，只有 as_0 有 fit。**5s 在目前 Train 上不可識別。** 這是誠實結果，不是模型能力。
- 以 R3 之前的程式碼跑會直接 raise `degenerate_train_labels`。R3 改為每個 horizon 各自標記 degenerate；只有三個 horizon 全部 degenerate 才 raise。

### 對 Mayor 實際事實的立場
- 16-arm qualifier 中，只有 20 個 LIGHT request 有 physical GPU work 標籤，而且 20 個都有 1 個 overhang。20 個 OFF request **沒有** tail 測量。所以 20/40 **不是** 0.5 的 tail 機率，也不是 0/1 隨機變異的證據。本模組的 tail 欄位不是 native authority。
- GPU elapsed 不是絕對時鐘，也不是 exclusive service 時間。
- Long 6c driver 規劃 400×120s=48000s，**尚未** 10 小時。planned、drain、setup、idle 都不算實際實驗時數。
- Gateway operation cache 在記憶體中、每 2 episode rollover；1024 上限未放寬。本模組不依賴它。

### RETAINED DISAGREEMENTS（不是投票、不是共識）
1. **未知 native 工作**：Astra 選擇棄權，我把它當特徵（`native_unknown`）。實際 Train 中有 17% origin-mark 不可見，全部棄權會丟掉大量狀態。這要由 Development 上的 E1 決定，目前沒有證據支持任一方。
2. **Marginal ≠ joint**：本模組是單一 marginal 累計 release 預測（`joint_response_kernel=False`），**不可**被當作 Astra 的 good/unreleased/tail 聯合 kernel。我不同意把它拿去餵 joint-feasibility 判定。
3. **中點標籤**是慣例，不是區間似然 MLE。我保留它，並報告 0/1 補值敏感度（h=1 最大 0.40）；若 E2 顯示偏差超過預先登錄的門檻，應改為區間似然。
4. **NN 半徑支援門**是資料定義的棄權包絡，不是 exchangeability 或 coverage 證明。它是 O(n²) stdlib 實作，無法直接擴展到整個 10h campaign，需要分塊或子抽樣（屆時另行宣告）。
5. **Tail 嚴格度**：我保留結構性 `tail_accounted`，Sol/Astra 只承認 mechanism evidence。兩者都不給 qualification authority；在 capture 提供 `tail_evidence` 欄位前，`tail_mechanism_evidenced` 在實際資料上恆為 False。
6. **Sol 的 0.5s 計畫**：我選擇 raise，而不是推廣編碼，因為實際 protocol 的 `schedule.at_s` 是整數秒。若未來 protocol 改變，SLOT_S 需重新宣告，不能沿用。
7. **Calibration**：跨 block 包絡偏保守，而且沒有 coverage 保證。Astra 要求的 conformal 保證在 block 數不足時無法成立，我不宣稱。
8. **MAE gate** 是研究 gate，不等於 MPC 價值；Gemini 的時數與控制器缺陷（R2 已記錄）維持不變。
9. **h=5 Train 不可識別**：我不會用 Calibration/Validation 補救。這需要更高負載或更長 release 的 Train cell（E6）。

### 鑑別性 native 實驗（新增；E1–E5 見 Round 2）
- **E6**：在 Train 中加入讓 5s 內仍有未釋放 mark 的 cell（長輸出或高 cap），使 h=5 可識別；在看資料前預先登錄最少 unreleased 數。
- **E7**：snapshot cadence 減半與加倍的成對 episode。若 grid 原點與 bracket 真值設計正確，h=3/5 的訓練統計量應只隨真值寬度變化。
- **E8**：在 capture 中加入 `tail_evidence`（placeholder、CUDA 完成、commit 時間），對 OFF 與 LIGHT 都測量 tail。只有這樣才能估計 tail 發生率；目前不可估。

### Round 3 receipt
- `native_release_model.py` sha256 `62cc1fa0263885ee751e6c51c0c09b95d887930d120c0366b6db8cc9376a3b48`
- `test_native_release_model.py` sha256 `097fd4798cffae8303b5e1a9ac66446a36d6ffa45d4cde1fe99295167adcd832`
- `python3 test_native_release_model.py` → `26 passed, 0 skipped`（Python 3.14.4，stdlib only；replica 測試在 replica 不存在時 SKIP）
- 本地 commit，bead 保持 in_progress；未執行 gt done/push/network/DB。

## Round 3b：Mayor 補充 Train 證據後的因果 cut／provenance 修正（仍屬 R3，有界）

Mayor 補充的 181001 描述性資料（`first-train-block-descriptive-diagnostics.json`）：
- E2E P95：p128/m128 1.249s、p128/m256 1.563s、p4096/m128 2.829s、p4096/m256 3.241s、mixed 2.605s。
- TTFT P95：0.22–1.10s。
- KV 最高 0.372，不構成滿載或 preemption 資格。
- cap16 觀測中，prior cost >16 的比例：short 約 14%，prefill-heavy 約 40%。

這些是相關的序列描述，**不是** Fixed/MPC 結果或因果成對差異。offered rate 是預先指定的參考值，不是量測到的容量。我未修改執行中的 protocol，也未讀取或擬合任何 Calibration/Validation/Final 資料。

### 新發現：計畫 slot 時間 ≠ 實際 apply 時間
replica 的 `actions` 中有實際 CAS ACK。
- 1785 個計畫動作全部 applied，其中 12 個曾重試。
- `applied_at − 計畫 slot` 的 p50 為 0.037s，p95 為 0.157s，最大 **2.399s**（181001-p128-m128-arm1 at_s=43，前兩次 pending）。

R3 原本的 `cap_plan` 特徵假設「計畫時間即生效」。在實際資料上，這對尾端延遲不成立。

### 修正（只動本人檔案）
1. **快照預算 provenance**：每個 joined snapshot 的 (budget, budget_version) 必須等於它 sampled_at 當下已生效的 ACK（pre-assignment 加上各次動作），否則拒收並計為 `gateway_budget_provenance`。在實際 Train 上，15 個 episode 都是 **0 拒收**：這是實際驗證，不是假設。
2. **Cut 必須在下一個動作的 ACK 之前**：origin 使用的所有 receipt（Gateway 與 native）必須早於任何計畫在 t0 或之後的動作的 `applied_at`，否則 raise `cut_after_action_ack`。實際 Train 上沒有觸發。因此 batch 狀態輸入都是 pre-treatment，不會把動作後的狀態當成同一 pre-treatment 狀態。
3. **未確認動作的 abstention**：若某指令計畫在 t0 前、但 t0 前尚未收到 applied ACK，origin 會以 `outstanding_action_at_cut` 棄權。這在線上可知（指令已送出、ACK 未回），不用 retrospective oracle。實際 Train 有 3 個這樣的 grid 點。
4. **保留的資訊**：actual CAS delay 只出現在診斷 `cas_apply_delay_s`，標明為 cut 之後的結果，**永遠不是輸入**。計畫特徵仍是完整的指派序列（無損 slot 編碼，不會 average-alias），條件於 pre-assignment 歷史。觀測到的實際生效預算是另一個特徵（`budget`）。模型不假設 reserved ≤ budget；cap16 下 prior cost >16 的實際觀測在 support range 內被當作真實狀態。
5. **線上可得性**：輸入只有 Gateway accepted marks（scheduled_at=None）與 native frame，**不使用** client 的 offered/rejected 歷史或 SLO 觀測。標籤來自其後的 snapshot brackets，與輸入分離。若要加入 arrival/SLO 特徵，需要另寫顯式的線上 adapter（本模組未提供）。

### Horizon／控制時間尺度：由實際 1–3s response 判定，不自動加長
15 個 Train episode（181001 完整 10 個加 181002 的 5 個；replica 仍在寫入，30 個 verified artifact）。另外 3 個 artifact 的 sha256 前 16 碼：181002-p128-m128-arm0 1c06c42fa5372c23、p128-m256-arm0 2ecd8a652e470eed、p128-m256-arm1 36f2ea533f261b41、p4096-m128-arm0 3d4f681e0ef0a2e6，其餘同上表。
- 1814 個 origin、17120 個 origin-mark，其中 2890 個 not-native-visible。
- h=1：14318 released / **2051 unreleased** / 751 截尾。
- h=3：17083 / **11** / 26。
- h=5：17102 / **0** / 18。h=5 的中點版與 as_1 版都是 degenerate 常數。

這與 E2E P95 ≤3.24s 一致：在目前的 protocol 下，live cohort 幾乎都在 3s 內釋放，所以 h=3/5 是近乎平凡的目標，資訊集中在 ≤1s（約等於 1s 控制 slot）。**我不在 R3 修改宣告的 HORIZONS**，因為依 Train 結果改 horizon 屬於事後調整。我提出一個可否證的預登錄修正，供 R4 決定：horizons {0.5, 1, 2}s，控制 slot 維持 1s。
- 否證條件：若在預先宣告的 Train 新 block 上 h=2 的 unreleased 比例 <1%，則 2s 也是平凡目標，應改以 sub-second 釋放動態作為 MPC 的主要 response。
- 若 ≥10% 的 grid 點出現 outstanding 動作，則 1s slot 對 CAS 延遲而言太短。

### 新增 RETAINED DISAGREEMENTS／限制
10. outstanding 動作的 origin 我選擇棄權，而不是把 CAS 延遲建模為 response 的一部分。其他 peer 若把延遲當作隨機 response 的一部分，需要明確說明條件於哪些 receipt。
11. 181002 目前只有部分 episode。混入部分 block 只適用於 Train 描述，不得作為 block-level 評估。

### Round 3b receipt
- `native_release_model.py` sha256 `98edb2df3b0bc9f5f4c8e9bedc0df5c4e08070f65408d32f63666004dc55ade3`
- `test_native_release_model.py` sha256 `ffd2b8f6ad3f713ef98538f12caed4a3e99a23a69e90208f1540593c96789a72`
- `python3 test_native_release_model.py` → `28 passed, 0 skipped`（新增 `test_r3b_*` 2 個）
- `--replica-train-diagnostics` 約 21s；本地 commit，bead 保持 in_progress；未執行 gt done/push/network/DB。

---

## Round 4 — short-step joint serving transition candidate (`nv3-opus-joint-transition-v1`)

Scope: one bounded candidate, no weight search, Train only. The R3/R3b marginal
original-ID release model is unchanged and remains a **diagnostic**; it is *not*
renamed or advertised as a joint kernel (`marginal_release_model_is_joint=False`).
The live 400-episode/source-6c protocol was not touched; no GPU process was run.

### R4.1 State, stock-flow equations, observability

Step Δ=0.5 s on a fixed cut grid t_k = start + kΔ (receipt-stamped cuts reused from
R3 `build_origins`, so all R3 clock/source/epoch/provenance/outstanding-action
fences apply unchanged).

Observable at cut t_k (receipts ≤ t_k only):
- Gateway stock: reserved original cost R_k, live count n_k, budget b_k (ACK in
  force, provenance-checked), headroom b_k−R_k, unstarted share, live prompt/max mix.
- Assigned plan b_{k..k+10} (pre-assignment; the actual CAS delay stays a label/fence,
  never a feature).
- Native frame joined by exact canonical UUID (running, waiting, KV, decode batch,
  prefill tokens, unknown-native fraction). Native partial visibility is kept as a
  feature; no stage/EOS clock is manufactured.
- Client all-offered receipt history over the last 4 steps (2 s): offers, rejected,
  good, TTFT misses, released and born cost. This is an explicit **observer input**.
  Gateway marks alone only see accepted traffic, so an online deployment needs this
  client receipt adapter. Future arrivals are never read from the tape.

Flows over (t_k, t_k+Δ] are **labels**, not features:
- D_k / N^D_k: original cost/count released (in snapshot k, absent in k+1).
- B_k / N^B_k: cost/count born.
- O_k = A_k + J_k: offers by send receipt, split into admitted and rejected (the
  503 receipt).
- G_k: natural-EOS good terminals, with TTFT = first − scheduled ≤ 0.5 and
  TPOT = (terminal−first)/(n−1) ≤ 0.05. This reproduces `summary.natural_cohort_good`
  exactly.
- M^TTFT_k: counted at the deadline scheduled+0.5 when first is absent or late, so it
  is knowable at that time.
- M^TPOT_k: counted at the natural terminal.

Stock update: R_{k+1} = R_k − D_k + B_k and n_{k+1} = n_k − N^D_k + N^B_k. The
identity is exact on the snapshot ID sets. It is not itself falsifying; the
falsifiable parts are these fences:
- `client_row_identity_or_clock`: the clock must match, the ID must be 32hex, and
  sent ≥ scheduled.
- `client_rows_incomplete`: rows must equal expected_ids.
- `snapshot_client_inconsistent`: each mark needs a non-rejected row with sent ≤ the
  snapshot sample.
- `mark_reappeared`.

Latent: native scheduler internals, the remaining tokens of unknown-native work, and
the future exogenous arrival process.

### R4.2 Model, support, scenarios

- **Per-target ridge** (closed form, standardized, λ=1e-3 declared, not searched).
  - `gateway_ridge`: Gateway and history features.
  - `batch_ridge`: adds the native batch features.
  - Outputs are clipped physically: ≥ 0, D ≤ R, N^D ≤ n.
- **Support/OOD** is bounded at O(n) per fit, replacing the O(n²) nearest-neighbour
  gate for this candidate. It combines:
  - per-feature Train ranges;
  - a coarse joint bin (cell, budget, headroom//4, live//8, offers//10) that needs
    ≥ 3 Train occurrences;
  - abstention on an outstanding action at the cut.

  Abstentions are counted, not dropped silently.
- **Free-running rollout** (10 steps = 5 s; reported at 1/3/5 s) uses the gateway
  model only, because the native state is latent after the cut and is not forecast.
  - Stocks follow the equation above, the budget follows the assigned plan, and the
    history window rolls over predicted flows.
  - 20 scenarios each add one contiguous Train residual run, which keeps serial and
    cross-target batch correlation.
  - Status: **unqualified**. The bootstrap is not state-conditional, and there is no
    coverage or MPC-risk claim.
- **Cross-fit**: leave-one-seed-block-out on Train only. Non-train partitions raise
  `joint_requires_train_only`; fewer than 2 blocks raise `crossfit_needs_two_blocks`.
- **Baselines**:
  - `train_mean`;
  - `persistence` (previous step's flows);
  - `history_mean` (mean of the last 4 steps) — the strong exogenous baseline;
  - for reserved, `hold` (R_k held constant), plus the above.

### R4.3 Actual Train result

Data: the read-only replica at 40 verified artifacts, which is 20 episodes from Train
blocks 181001 and 181002 (5 cells × 2 arms). No Calibration, Validation, Final or
160021–24 data was read. These are two folds, not an uncertainty estimate; paired arms
within a block are correlated.

Each fold held out one block:

| Held-out block | Train steps | Residual runs | One-step scored | Abstained (joint_bin / outstanding) | Rollout origins |
|---|---|---|---|---|---|
| 181001 | 2389 | 15 | 2196 | 194 (184 / 11) | 538 |
| 181002 | 2385 | 16 | 2175 | 220 (203 / 10) | 528 |

**Cohort-vs-future decomposition of good terminals in (t, t+h]**, over all steps:

| Horizon | From cut cohort | From later births | Later share |
|---|---|---|---|
| 1 s | 6521 | 1572 | 19% |
| 3 s | 7508 | 16172 | 68% |
| 5 s | 7388 | 31404 | 81% |

Original-cohort release therefore cannot be the Goodput kernel beyond about 1 s.
5 s release degeneracy does not make 5 s state/Goodput forecasting moot: births
dominate it.

**One-step MAE per 0.5 s**, held-out block 181001 (block 181002 within ±0.2):

| Target | batch_ridge | gateway_ridge | history_mean | persistence | train_mean |
|---|---|---|---|---|---|
| released_cost | 2.72 | 2.86 | 4.32 | 5.05 | 4.51 |
| born_cost | 2.92 | 2.95 | 3.89 | 4.81 | 4.14 |
| good | 1.12 | 1.17 | 1.72 | 2.19 | 3.39 |
| rejected | 1.66 | 1.67 | 1.89 | 2.07 | 2.34 |
| offers | 1.89 | 1.88 | 1.92 | 2.43 | 4.54 |
| ttft_miss | 0.40 | 0.49 | 0.58 | 0.56 | 0.59 |
| tpot_miss | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |

TPOT misses are essentially absent in this Train data, so TPOT risk is
**unidentified**, not shown to be safe. Native batch features help modestly, and only
on released_cost and ttft_miss.

**Free-running MAE**, joint median vs the strongest baseline. Each cell gives
fold 181001 / fold 181002.

| Target | 1 s | 3 s | 5 s |
|---|---|---|---|
| good (vs history_mean) | 1.80 vs 2.72 / 1.65 vs 2.62 | 5.29 vs 5.59 / 5.55 vs 5.70 | **9.84 vs 8.47 / 10.37 vs 8.67 (loses)** |
| offers (vs history_mean) | 3.06 vs 2.78 / 3.26 vs 3.10 (loses) | 7.58 vs 6.14 / 8.30 vs 7.19 (loses) | 13.11 vs 9.80 / 14.47 vs 10.88 (loses) |
| rejected (vs history_mean) | 3.08 vs 3.39 / 3.28 vs 3.61 | 7.42 vs 6.91 / 7.20 vs 6.91 (loses) | 11.82 vs 10.83 / 12.00 vs 10.58 (loses) |
| ttft_miss (vs best of history_mean/train_mean) | 0.91 vs 1.08 / 0.91 vs 0.99 | 2.07 vs 2.41 / 2.33 vs 2.36 | 3.13 vs 3.63 / 3.54 vs 3.66 |
| reserved (vs hold) | 5.52 vs 8.00 / 5.11 vs 7.16 | 5.36 vs 7.65 / 5.62 vs 8.09 | 5.51 vs 7.97 / 5.60 vs 7.96 |

For reserved, train_mean is about equal to hold.

**Scenario 10–90% band inclusion** falls with horizon: 0.65–0.84 at 1 s and
0.42–0.75 at 5 s (5 s TTFT: 0.42 and 0.51). The bands are under-dispersed, which is
consistent with the unqualified status.

### R4.4 Honest conclusion

- **Where the candidate is useful.** It is a usable *short-step state* model.
  - It beats every baseline one step ahead on all non-degenerate targets.
  - Free-running, it beats hold/train_mean on reserved stock at 1–5 s.
  - It modestly beats the baselines on TTFT-miss counts at 1–5 s.
- **Where it fails.** Free-running, it **loses to history_mean on the exogenous
  flows**: offers at all horizons, rejected at 3–5 s, and good at 5 s. Compounding
  rollout error on the arrival process is the failure. Offers are a pre-assigned
  protocol rate, so predicting them identifies the cell, not capacity.
- **Falsifiable next step** (not done here): a hybrid that feeds the observed
  history_mean of offers as an exogenous input into the stock dynamics, instead of
  rolling its own arrival prediction. That is the only stated change, with no
  search, and it must be tested on a fresh Train block before any Calibration use.
- **Not claimed:** no MPC result, calibration, coverage, statistical guarantee,
  capacity or absolute GPU-time claim. TPOT risk is unidentified on this data.
- **Data sufficiency.** The data is sufficient for one-step and 1 s joint state. It
  is insufficient to qualify 5 s exogenous-flow scenarios.

### R4.5 Retained disagreements and limits

12. **Scenario conditioning.** The residual-bootstrap scenarios are batch-correlated
    but not state-conditional. Astra-style joint response kernels need a
    state-conditional generator; this candidate stays unqualified.
13. **Support gate.** The bounded joint-bin support replaces the R3 O(n²)
    nearest-neighbour gate only for this candidate; R3 keeps its gate. Bin edges are
    declared, not tuned, but are still a modelling choice.
14. **Observer adapter.** The client all-offered history adapter is required. A
    Gateway-only deployment cannot compute the offers, rejected or TTFT-deadline
    history features.
15. **Fold structure.** Two folds over paired arms is not uncertainty
    quantification. Uncertainty should be judged with ≥ 4 Train blocks later.

### R4.6 Receipt

- Run: `python3 native_release_model.py --replica-joint-crossfit <replica>` takes
  about 6 s.
- Tests: `python3 test_native_release_model.py` gives 34 passed, 0 skipped, including
  6 new R4 tests:
  - Stock identity and receipt labels.
  - A marginal≠kernel counterexample: identical R3 `mark_features`, but different
    offered/rejected history and future births give different future good.
  - Client fencing and snapshot consistency.
  - No future leakage into features or rollout.
  - Train-only, block-grouped, unqualified cross-fit.
  - An actual-replica stock-identity check for 181001 p128-m128 arm0
    (2540 good = summary).
- Source sha256 values are recorded in the commit message.

---

## Round 5 — one hypothesis: exogenous common arrival law (`nv3-opus-exogenous-arrival-v2`)

Mayor reproduced frozen R4 `670edf66` (19/68/81% later-birth decomposition and the
5 s good/offers/rejected losses). This round tests exactly one hypothesis: the R4
free-running losses come from recursively predicting the offered flow from candidate
control and state.

What is held fixed:
- Step 0.5 s, history 4 steps, horizons 1/3/5 s, rollout cadence, ridge λ=1e-3.
- Support/OOD gate, 20 scenarios and seed, the 10–90% band, every metric and baseline.
- No cost weights and no search.

v1 is unchanged: its output is byte-identical to R4 on the same data (asserted, and
covered by a regression test), and it is reported side by side on the same origins
and abstentions.

### R5.1 Candidate and causal/regression contract

- **Arrival law** (`arrival_law(step)`): the future offered flow per 0.5 s is the mean
  of the last 4 pre-cut all-offered receipt counts. The function takes only
  `hist_steps` (receipts ≤ t_k). It does not take the plan, cap or post-cut state, and
  the same path is used for every candidate plan.
- **Explicit contract.** The future offered tape is independent of the candidate cap.
  In the scenario rollout the arrival path is drawn *before* any state or plan
  propagation, and the test changes both plan and state and requires an identical
  offered path.
- **Design support** (Train, both blocks, all 5 cells): the paired arms have
  *identical* `offered_tape` while their cap schedules differ in all 120/120 slots.
  - Send-time 0.5 s counts differ between arms by at most 4 per step (p128-m128);
    the sum of differences is 0–44 per episode.
  - Send lag is p99 ≤ 0.016 s, max 0.153 s.

  This is protocol-level support for exogeneity of the *scheduled* tape. The small
  send-time jitter is not shown to be cap-independent.
- **Conditional transition f.** Ridge on the R4 gateway features plus the realized
  interval offers as a disturbance input, fitted on Train labels.
  - **Forecasts never receive realized future offers.** They receive the arrival law
    plus a contiguous Train arrival residual.
  - Feeding realized future offers is reported only under
    `oracle_disturbance_diagnostic` with status `ORACLE DISTURBANCE … not a forecast`,
    and is never mixed into the forecast tables.
- **Scenarios.** Each of the 20 scenarios takes one contiguous Train run of joint
  residuals: the offers residual against the arrival law, plus the conditional
  residuals of f. Status: unqualified, not state-conditional.
- **Native features** stay latent after the cut, as in v1. The one-step `exo_ridge`
  uses the gateway features only, so its comparator is `gateway_ridge`, not
  `batch_ridge`.

### R5.2 Train result (blocks 181001 and 181002, Mayor-frozen 20 JSON)

Data and run:
- Data: `pr33-native-v3-first-two-train-blocks-frozen`. Each of the two folds holds
  out one block.
- Origins and abstentions are identical to R4: 538 and 528 rollout origins;
  194 and 220 one-step abstentions.
- Exo residual runs: 15 and 16.
- Raw JSON sha256 `85fb4bea…4c65` (scratch `/tmp/exo.json`, regenerable by the
  command below).

**One-step MAE**, folds 181001 / 181002:
- `exo_ridge` (offers forecast = arrival law) vs `gateway_ridge`:
  - offers 1.92 / 1.96 vs 1.88 / 1.96.
  - good 1.17 / 1.17 vs 1.17 / 1.17.
  - rejected 1.66 / 1.74 vs 1.67 / 1.76.
  - The other targets are within ±0.06.

  So one step ahead, the exogenous law adds nothing.
- Oracle-disturbance diagnostic: rejected 1.38 / 1.42 and admitted 1.36 / 1.46, while
  good, ttft_miss and released stay unchanged. The realized arrival explains part of
  same-step rejection, and almost nothing of same-step good or release.

**Free-running MAE.** Every forecast target at every horizon is listed. Each cell gives
fold 181001 / fold 181002.

| Target | Horizon | v2 exo median | v1 joint median | Best fixed baseline | Oracle (diag only) |
|---|---|---|---|---|---|
| offers | 1 s | 2.91 / 3.20 | 3.06 / 3.26 | hist_mean 2.78 / 3.10 | — |
| offers | 3 s | 6.20 / 7.41 | 7.58 / 8.30 | hist_mean 6.14 / 7.19 | — |
| offers | 5 s | 10.11 / 11.24 | 13.11 / 14.47 | hist_mean 9.80 / 10.88 | — |
| rejected | 1 s | 3.12 / 3.35 | 3.08 / 3.28 | hist_mean 3.39 / 3.61 | 2.43 / 2.72 |
| rejected | 3 s | 7.14 / 7.00 | 7.42 / 7.20 | hist_mean 6.91 / 6.91 | 5.32 / 5.36 |
| rejected | 5 s | 10.91 / 11.12 | 11.82 / 12.00 | hist_mean 10.83 / 10.58 | 8.17 / 8.69 |
| good | 1 s | 1.81 / 1.66 | 1.80 / 1.65 | hist_mean 2.72 / 2.62 | 1.87 / 1.71 |
| good | 3 s | 5.20 / 5.48 | 5.29 / 5.55 | hist_mean 5.59 / 5.70 | 5.01 / 5.05 |
| good | 5 s | **9.40 / 9.97** | 9.84 / 10.37 | **hist_mean 8.47 / 8.67** | 9.26 / 8.64 |
| ttft_miss | 1 s | 0.90 / 0.91 | 0.91 / 0.91 | 1.08 train_mean / 0.99 hist_mean | 0.89 / 0.91 |
| ttft_miss | 3 s | 2.05 / 2.31 | 2.07 / 2.33 | 2.41 train_mean / 2.36 hist_mean | 2.00 / 2.30 |
| ttft_miss | 5 s | 3.10 / 3.47 | 3.13 / 3.54 | train_mean 3.63 / 3.66 | 3.08 / 3.43 |
| reserved | 1 s | 5.55 / 5.10 | 5.52 / 5.11 | hold 8.00 / 7.16 | 5.39 / 4.84 |
| reserved | 3 s | 5.34 / 5.68 | 5.36 / 5.62 | hold 7.65 / 8.09 | 5.18 / 5.14 |
| reserved | 5 s | 5.62 / 5.62 | 5.51 / 5.60 | hold 7.97 / 7.96 | 5.33 / 5.22 |

The persistence and train_mean baselines are worse everywhere: for example, 5 s good
is 16.55 / 17.11 and 30.96 / 31.10.

**10–90% band inclusion**, v1 → v2, fold 181001 / fold 181002:

| Target | 1 s | 3 s | 5 s |
|---|---|---|---|
| offers | 0.83 → 0.80 / 0.78 → 0.78 | 0.80 → 0.65 / 0.69 → 0.52 | 0.75 → 0.47 / 0.64 → 0.44 |
| rejected | 0.84 → 0.81 / 0.78 → 0.74 | 0.65 → 0.57 / 0.64 → 0.59 | 0.57 → 0.50 / 0.58 → 0.52 |

For good, ttft_miss and reserved, coverage moves by ±0.03 and stays at 0.42–0.77.
v2 bands are **narrower and under-cover more** for the exogenous flows. One-step
arrival residuals summed over a contiguous run understate multi-step arrival
uncertainty. This remains unqualified.

### R5.3 Verdict on the hypothesis

1. **Supported in part.** Recursive arrival prediction was a real error source.
   - Moving to the exogenous law cuts the free-running offers error from 13.1/14.5
     to 10.1/11.2 at 5 s, and 5 s rejected from 11.8/12.0 to 10.9/11.1.
   - 5 s good improves from 9.84/10.37 to 9.40/9.97.
   - Reserved, ttft_miss and short-horizon good are unchanged, so nothing was traded
     away.
2. **Not sufficient. v2 still loses:**
   - offers at 1/3/5 s to history_mean. The v2 median of law+residual paths is not
     the law itself; the residual draws add bias and spread.
   - rejected at 3/5 s.
   - **good at 5 s by about 1.0–1.3.**
3. **Diagnostic falsifier.** With realized future offers fed in (oracle, not a
   forecast), fold 181001 5 s good is still 9.26 vs history_mean 8.47; fold 181002
   ties (8.64 vs 8.67). Even perfect arrivals do not make the iterated transition beat
   a 2 s history mean for 5 s good. The remaining loss is compounding conditional
   transition error and/or missing latent service state, not only arrivals. Rejected
   does become arrival-explained (oracle 8.2/8.7 < 10.8/10.6).
4. **Consequences and limits.** For 5 s Goodput, a direct h-step forecast with the
   same exogenous law is the next competing representation, not more recursion. That
   is not implemented here: one candidate per round. No MPC, calibration, coverage,
   capacity or statistical claim is made. TPOT risk remains unidentified
   (tpot_miss ≈ 0).

### R5.4 Fresh block 181003

Not run. The Mayor-frozen data contains no 181003 file. In the live long01 replica at
this time, the collector-verified list holds 9/10 episodes: `mixed-arm1` is absent.

`exogenous_report` refuses unless the block has exactly 5 cells × 2 arms
(`not_run: incomplete`, which is tested). Once Mayor byte-verifies the complete
block, the same command fits only on 181001/181002 and evaluates 181003 as a
Train/Development diagnostic (`holdouts=[181003]`), with no refit or retuning.

### R5.5 Compatibility with Astra frozen `018ed9b` (`ShortStepResponse`)

My aggregate ridge/residual candidate (v1 or v2) is **not** Astra's original-ID
marked-event kernel K_θ. It cannot be plugged into his `ResponseModel.predict`
without inventing mappings or receipts. These are the exact blockers:

1. **Net snapshot flows vs gross transient work.**
   - My D_k/B_k are set differences of consecutive cut snapshots. A request born and
     released within one 0.5 s step is invisible, and so is any transient physical
     work.
   - Astra replays every ordered offer, admit and release event. He also separates
     ledger release from physical drain via pending work in z.
   - A net-flow model cannot generate his within-step event order or the
     `admit_i = 1{R(t-)+c_i ≤ B(t)}` decisions.
2. **Immutable original-cost IDs.**
   - Astra's state carries every offered ID with immutable c_i, prompt/max,
     scheduled time, delivered tokens and terminal status, and a release must match
     a live original reservation.
   - My rollout carries only scalars (R, n, unstarted share). After the cut it has
     no IDs, so it cannot tell which reservation releases or sample per-request good.
3. **Count coupling.**
   - Astra's admitted + rejected = offered holds per offer by construction.
   - My per-step labels count admissions at send and rejections at the 503 receipt,
     so the identity holds only cumulatively. The ridge targets are separately
     fitted and clipped, and are not coupled. born_n vs admitted, and good ≤ terminal
     ≤ admitted, are not enforced in the rollout either.
   - A path can therefore be count-inconsistent where his composer would declare it
     unsupported.
4. **Client receipt availability.**
   - Astra's N.4 assumes client marks and ledger changes are available at each step
     boundary; he flags this himself as an unqualified availability assumption.
   - My features require the client all-offered receipt adapter (receipts ≤ t_k),
     with TTFT misses at the deadline and good at the terminal.
   - Neither of us has an online publication-delay receipt for the client stream.
     Plugging my history into his FlowView would assert an availability that has
     not been measured.
5. **Conditional uncertainty.**
   - Astra requires a joint, state-conditional path law with a common future law
     across candidates, and refuses externally supplied error widths.
   - My scenarios are an unconditional contiguous-residual bootstrap whose coverage
     is shown to be low (0.42–0.84). They are not admissible as his path weights or
     `error_below/above`.
6. **Cap actuation.**
   - Astra's latest-command model has no ACK/CAS provenance. My cuts require the ACK
     in force and abstain on outstanding actions, so the two support sets differ.
   - My plan input is the assigned schedule, not his requested-vs-applied cap path.

What *is* compatible: the arrival contract (a common future offered law shared by
all candidates, drawn before propagation) and the exact stock identity on original
cost. Any further mapping would be invented, so none is provided.

### R5.6 Retained disagreements (added)

16. **Iterated vs direct.** Astra holds that only a free-running joint event kernel
    qualifies. My data show that the iterated aggregate transition, even with oracle
    arrivals, does not beat a 2 s history mean for 5 s good. A direct h-step model
    must be tested before iteration is assumed to be the right representation.
17. **Arrival residual handling.** Adding one-step arrival residuals worsened offers
    coverage. Whether a multi-step arrival law should be point (law only) or
    residual-perturbed is undecided. It was not tuned here.

### R5.7 Receipt

- Commands:
  - `python3 native_release_model.py --replica-exogenous-arrival <frozen-two-block-dir>`
    (about 9 s).
  - `--replica-joint-crossfit` still reproduces R4 exactly.
- Tests: `python3 test_native_release_model.py` gives 36 passed, 0 skipped, including
  2 new R5 tests:
  - The arrival path is invariant to candidate plan and state, while the same
    coefficients under v1 recursion move offers with state.
  - The oracle is separated from every forecast table; v1 metrics are unchanged
    inside the v2 run; the incomplete fresh block is refused.
- No GPU, network, DB, push or `gt done`. No Calibration/Validation/Final or
  160021–24 access. The live protocol is unchanged.

### R5.8 Fresh-block development diagnostic: held-out 181003 (executed)

**Data audit**, taken from the actual directory
`pr33-native-v3-first-three-complete-train-blocks-frozen`:
- `verified-artifact-sha256.jsonl` (sha256 `35cd61c8…f467`) lists 60 artifacts, and
  all 60 hashes were re-verified by `load_replica` before use.
- There are 30 episode JSON files and 30 event streams, all split=train, with no
  skipped splits.
- Coverage is exactly 3 blocks × 5 cells × 2 arms (181001/181002/181003), and failed
  block 181004 is absent.
- Provenance: collector source `6c11fe7e…`, native source `2587d2b8…`, and one
  clock domain `linux-monotonic:64589d75…`.
- Held-out 181003 rows:
  - 10 episodes and 14226 client rows, of which 5374 are 503 rejections.
  - 8903 Gateway observations and 0 unavailable frames.
  - 2421 grid steps, 2396 of them labelled.

**Command and source**, unchanged since R5:

```
python3 native_release_model.py --replica-exogenous-arrival \
  .../pr33-native-v3-first-three-complete-train-blocks-frozen
```

- `native_release_model.py` sha256 `bfc32c73…de96`, i.e. the R5 commit 26192e3; no
  edits.
- Runtime about 20 s.
- Output sha256 `407a1b46c3b9acb61a309e38daa99c19760366c64d192f4d2253292326ddc123`,
  saved outside the repository as session artifact `opus-r5-dev-181003.json`.
- The output's two-block `cross_fit` section is identical (receipt excluded) to the
  R5 run on the two-block frozen data.

**Protocol.**
- Models, residual runs (31 for v1 and 31 for v2), means and the support were fit on
  181001+181002 only (4774 steps). 181003 is evaluation only; there was no refit and
  no change to λ, horizons, metrics, scenarios or seed.
- The output's `cohort_vs_future_good` covers all 30 episodes and is descriptive
  only. It reports 19/69/81% later births at 1/3/5 s, reproducing R4's pattern.

**181003 counts.**
- 2283 one-step steps scored.
- 106 abstained: 89 joint_bin, 12 outstanding action, 3 headroom range, 2
  prefill_k range.
- 7 had no previous label.
- 544 rollout origins; 25 rollouts unavailable.

**One-step MAE** on held-out 181003:

| Target | batch_ridge | gateway_ridge | exo_ridge | history_mean | persistence | train_mean |
|---|---|---|---|---|---|---|
| released_cost | 2.73 | 2.84 | 2.84 | 4.44 | 5.13 | 4.62 |
| born_cost | 2.99 | 3.05 | 3.06 | 3.92 | 4.84 | 4.15 |
| released_n | 1.24 | 1.26 | 1.26 | 2.03 | 2.53 | 3.47 |
| born_n | 1.48 | 1.50 | 1.51 | 1.83 | 2.43 | 3.35 |
| offers | 1.92 | 1.92 | 1.95 | 1.95 | 2.39 | 4.67 |
| admitted | 1.68 | 1.67 | 1.69 | 1.94 | 2.50 | 3.42 |
| rejected | 1.78 | 1.78 | 1.77 | 1.99 | 2.33 | 2.51 |
| good | 1.09 | 1.15 | 1.15 | 1.74 | 2.14 | 3.40 |
| ttft_miss | 0.39 | 0.45 | 0.45 | 0.54 | 0.51 | 0.56 |
| tpot_miss | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |

The oracle disturbance (diagnostic only) gives rejected 1.42 and admitted 1.43, with
good 1.15 unchanged.

**Free-running MAE** on held-out 181003:

| Target | Horizon | v2 exo | v1 joint | history_mean | Other baselines | Oracle (diag) | Band v1 / v2 |
|---|---|---|---|---|---|---|---|
| offers | 1 s | 3.11 | 3.15 | **2.97** | pers 4.26, train 9.20 | — | 0.81 / 0.78 |
| offers | 3 s | 7.30 | 8.28 | **7.20** | pers 12.02, train 26.98 | — | 0.73 / 0.56 |
| offers | 5 s | 11.58 | 14.53 | **11.41** | pers 20.03, train 44.60 | — | 0.67 / 0.44 |
| rejected | 1 s | 3.08 | **3.06** | 3.35 | pers 4.28, train 4.56 | 2.55 | 0.84 / 0.79 |
| rejected | 3 s | **7.28** | 7.46 | 7.58 | pers 12.15, train 11.43 | 5.71 | 0.69 / 0.62 |
| rejected | 5 s | **11.47** | 12.48 | 12.06 | pers 19.59, train 18.24 | 9.01 | 0.62 / 0.55 |
| good | 1 s | **1.78** | **1.78** | 2.70 | pers 3.48, train 6.46 | 1.79 | 0.75 / 0.76 |
| good | 3 s | **5.56** | 5.58 | 5.69 | pers 9.10, train 18.76 | 5.05 | 0.66 / 0.64 |
| good | 5 s | 9.84 | 10.18 | **8.76** | pers 15.20, train 31.07 | 8.78 | 0.66 / 0.62 |
| ttft_miss | 1 s | **0.85** | **0.85** | 1.04 | pers 1.23, train 1.03 | 0.83 | 0.71 / 0.70 |
| ttft_miss | 3 s | 2.09 | **2.07** | 2.47 | pers 3.76, train 2.36 | 2.03 | 0.48 / 0.49 |
| ttft_miss | 5 s | 3.16 | **3.14** | 3.85 | pers 6.16, train 3.52 | 2.97 | 0.47 / 0.49 |
| reserved | 1 s | 5.13 | **5.07** | 10.30 | hold 7.56, train 7.57 | 4.78 | 0.70 / 0.67 |
| reserved | 3 s | 5.57 | **5.42** | 15.86 | hold 8.26, train 8.29 | 5.28 | 0.72 / 0.73 |
| reserved | 5 s | 5.50 | **5.42** | 20.74 | hold 7.96, train 8.02 | 5.20 | 0.70 / 0.71 |

**Findings on the fresh block.** The R5 pattern repeats, and it stays negative and
unqualified.

1. **Negative.** 5 s good: v2 9.84 and v1 10.18 both lose to history_mean 8.76, by
   1.08 for v2. Offers: v2 loses to history_mean at 1/3/5 s by 0.14/0.10/0.17.
   Neither the exogenous law nor iteration beats the plain 2 s mean on offers.
2. **Negative.** Even the oracle disturbance (realized future offers fed in, not a
   forecast) only ties history_mean on 5 s good (8.78 vs 8.76). The 5 s Goodput
   deficit is not removed by perfect arrivals.
3. **Negative.** Scenario bands under-cover. At 5 s, v2 covers offers at 0.44 and
   rejected at 0.55, and both versions cover ttft_miss at 0.47–0.49. The scenarios
   remain unqualified, and v2 widens the offers under-coverage relative to v1.
4. **Positive** (descriptive, one fresh block):
   - Unlike in the two-block cross-fit, v2 beats history_mean on rejected at 3 and
     5 s (7.28 vs 7.58, 11.47 vs 12.06). v1 is worse than history_mean on 5 s
     rejected (12.48).
   - Both versions beat every baseline on reserved stock at 1–5 s and on TTFT
     misses at 1–5 s.
   - One step ahead, the batch features again help modestly on released_cost and
     ttft_miss.
5. **No claims.** No calibration, coverage, MPC, capacity or statistical claim is
   made from one fresh block with correlated paired arms. TPOT risk is unidentified
   (tpot_miss ≈ 0). This block is now *used* for development and is no longer fresh
   for any later selection.

---

## Round 6 — independent architecture: ID-progress cohort + exogenous-birth hybrid (`nv3-opus-progress-hybrid-v3`)

Written independently; no other R6 material was read. The R5 negatives are preserved
unchanged (R5.3, R5.8): iterated v2 5 s good 9.84 vs history_mean 8.76, oracle
arrivals 8.78, under-covering bands. The R4/R5 commands reproduce byte-identically
(R5.8 output sha256 `407a1b46…c123`; v1 equal on the two-block data).

### R6.1 Choice and why

R5 leaves two candidate explanations for the 5 s Goodput loss:

- (a) missing per-request progress/service state;
- (b) marginal arrival error.

Since about 81% of G5 comes from requests born after the cut, I decompose the target
**exactly** by original ID instead of adding more aggregate recursion:

  G_h(t) = G_h^coh(t) + G_h^birth(t)

- G^coh counts good terminals in (t, t+h] of IDs live in the Gateway snapshot at
  cut t.
- G^birth counts all other IDs that become good in (t, t+h].

The chosen architecture is a **hybrid marked-event / fluid model**:

- **Live cohort: ID-level marked state.** Lifecycle, SLO and EOS logic is exact and
  per request, so it cannot be aggregated without loss.
- **Births: driven by a common exogenous arrival/payload law**, passed through the
  exact admission ledger and a batch-aware service law.

### R6.2 Mathematical proposal (full form)

**Minimal observable state at cut t** (receipts ≤ t only):

  x_t = ( {m_i}_{i∈L_t}, R_t, b_t, β_t, H_t )

- m_i, per live original ID, contains:
  - immutable cost c_i, prompt P_i and max M_i;
  - client scheduled time s_i;
  - client first-content receipt f_i (only if f_i ≤ t);
  - client terminal receipt e_i (only if e_i ≤ t);
  - native visibility v_i and native output_tokens o_i (only if visible).
- R_t is reserved original cost and b_t the ACK-in-force budget.
- β_t is the batch state: native running, waiting and KV.
- H_t is the client all-offered receipt history.

**Deterministic part of h**, exact and derivable from the definitions:

- e_i ≤ t ⇒ `client_terminal`. The request cannot become good in (t, t+h], even
  if its Gateway release lags.
- f_i absent and t − s_i > 0.5, or f_i − s_i > 0.5 ⇒ `ttft_impossible`, so P(good) = 0.

**Action pathway.** The only control is the reservation budget b(·) ∈ {16, 32}. It
acts *only* through the admission indicator

  a_j = 1{R(τ_j−) + c_j ≤ b(τ_j)}

for each offer j at time τ_j. There is no eviction or recosting.

**Service law S.** S maps (β, {m_i}) to token progress and terminal events. It may
depend on the batch (prefill/decode competition through running, waiting and the
prompt mix) but **not on b directly**. Any cap effect must pass through admitted
work and therefore through β.

**f, the transition per short step:**
1. Draw the offers and payloads (P_j, M_j, c_j) from the common exogenous law
   A(H_t). The draw is shared across all candidate plans.
2. Apply the admission ledger.
3. Advance live IDs by S: progress and EOS hazard λ(o_i, M_i, β) from the payload
   output-length law.
4. Emit first/terminal receipts and releases. Release is a Gateway mark event and is
   not equated with GPU drain.

**Coherent scenario kernel.** Use common random numbers for:
- the arrival/payload tape;
- the per-ID EOS uniforms;
- the batch service innovations.

The same tape is used for every candidate plan, so plan differences act only via
admission and then β.

**Exact consistency** (enforced where implemented): good ≤ possible live; per-ID
monotone lifecycle; cohort/birth partition by ID; G_h equals the R4 step-label sum.

**Measurement and source limits** (named, not zeroed):
- Native `computed_tokens` is *not retained* by the R3 exact join, so prefill
  progress of o_i = 0 IDs is unknown.
- At the 181003 evaluation cuts (k%4=0, all live IDs), 500 of 4815 live IDs (10.4%)
  were not native-visible. The audited 17–23% figure applies to all observations.
- Native output_tokens is a progress *bin* only. It is never used as the delivered
  count or as EOS. Natural EOS and TPOT come only from client receipts.
- Within-snapshot transient births and deaths are invisible to the snapshot flows.
- There is no absolute or exclusive GPU-time interpretation.

### R6.3 What is implemented this round (bounded)

The full structural f/S/A simulator is **not** implemented. Fitting S needs per-step
native token progress across consecutive frames, which the R3 join does not keep.

What is implemented is a **direct-horizon** version of the hybrid, enough to answer
"progress state vs arrivals":

- **Cohort part.** Sum over live IDs of an empirical progress probability
  p_h(key), fit on Train 181001+181002 only.
  - States: client_terminal or ttft_impossible, which are exact zeros. A Train
    violation raises.
  - Otherwise the key is (cell, native-visible, first-seen, output-token bin
    {0, 1–15, 16–63, 64–127, ≥128}, batch = (running//8 capped at 4, waiting>0)).
  - Back-off order is declared: drop batch → drop output → (cell, vis, first) →
    global, at a minimum of 20 Train occurrences. No search.
  - The comparator `cohort_aggregate` is a ridge of G^coh on the R4 Gateway aggregate
    vector, with the same λ.
- **Birth part.** A ridge of G^birth_h on (R4 Gateway vector + R5 common exogenous
  arrival law), fit on Train 1/2 only.
  - It is a **reduced form**: it mixes admission and service, and sees budget and
    next-plan budget as features. It is therefore **not admissible as the GPU service
    law or as a plan-response model**.
- **ORACLE diagnostics**, reported separately and never as forecasts:
  - realized G^birth;
  - realized G^coh;
  - the birth model refit and evaluated with the realized mean offered rate over
    (t, t+h].
- **Origins.** The R4/R5 rollout-origin rule is used. On held-out 181003 this gives
  **544 origins, identical to R5.8**, and history_mean reproduces R5.8 exactly
  (2.70 / 5.69 / 8.76). The R6 rows are therefore directly comparable to R5.8.

### R6.4 Train1/2-fit → Train3 (181003, already-used development) descriptive result

- Command:
  `python3 native_release_model.py --replica-progress-diagnostic .../pr33-native-v3-first-three-complete-train-blocks-frozen`
  (about 4.5 s).
- Output sha256 `016456f6eab563bc2f0573ba2b0f90db6789fd3a45a9c7660019de780ae8ed7a`
  (`/tmp/r6.json`, regenerable).
- Train: 4774 usable steps and 612 hazard cells.
- ID states at the 181003 evaluation cuts: level-0 key 3478–3481, back-off level 1
  27–30, ttft_impossible 534, client_terminal 383. Counts are per horizon.

**MAE (bias)** on 544 origins; mean truth G_1/G_3/G_5 = 6.71 / 20.03 / 33.41:

| Row | 1 s | 3 s | 5 s |
|---|---|---|---|
| history_mean (= R5.8) | 2.70 (−0.14) | 5.69 (−0.31) | 8.76 (−0.53) |
| R5.8 v2 iterated exo median (same origins) | 1.78 | 5.56 | 9.84 |
| R5.8 v1 iterated joint median | 1.78 | 5.58 | 10.18 |
| **aggregate_hybrid** (aggregate cohort + birth) | 1.42 (+0.20) | 3.70 (+0.41) | 6.00 (+0.45) |
| **progress_hybrid** (ID cohort + birth) | **1.07** (+0.22) | **3.45** (+0.46) | **5.90** (+0.50) |
| part: cohort_aggregate (truth 5.49 / 6.41 / 6.42) | 1.17 | 0.94 | 0.93 |
| part: cohort_progress | **0.47** | **0.13** | **0.12** |
| part: birth reduced form (truth 1.22 / 13.62 / 26.99) | 0.77 | 3.41 | 5.88 |
| ORACLE birth \| realized arrival rate | 0.77 | 3.24 | 5.50 |
| ORACLE total, progress cohort + realized birth | 0.47 | 0.13 | 0.12 |
| ORACLE total, realized cohort + birth model | 0.77 | 3.41 | 5.88 |

### R6.5 What this distinguishes (descriptive, one used block)

1. **Missing live-cohort progress state is real but small.**
   - ID-level TTFT/progress state removes most cohort error: 0.93 → 0.12 at 5 s,
     and 1.17 → 0.47 at 1 s. It matters most at 1 s, where the cohort is 82% of G.
   - By 3–5 s, G^coh is nearly determined by the exact deterministic states plus
     visible progress.
2. **Marginal arrival error is not the main 5 s problem.** Giving the birth model the
   *realized* arrival rate lowers its 5 s error only from 5.88 to 5.50. This agrees
   with R5's oracle result.
3. **The dominant residual is birth-side admission/service/completion** of requests
   that arrive after the cut: about 5.5 of the 5.9 MAE at 5 s. Its structural
   components (S, the EOS law and the payload mix) are the unimplemented part of
   R6.2.
4. **The R5 5 s loss is mainly a representation failure.**
   - On the *same 544 origins*, direct-horizon forecasts beat the R5 iterated
     rollouts and history_mean at 3 and 5 s: 5.90 / 6.00 vs 9.84 / 10.18 / 8.76.
   - The R5 iterated rollouts lost because 0.5 s errors compound over 10 steps,
     not mainly because of arrivals or cohort state.
   - This is a fact about *point MAE on a used block*. It is not a controller,
     calibration or native-performance result.
5. **The direct form is not a control model.**
   - The direct birth ridge sees only the current and next budget, not the full
     candidate plan.
   - Any cap effect it captures is reduced-form, so it **cannot rank candidate plans**.
   - The structural f of R6.2, with cap → admission → β → S, is what MPC needs, and it
     remains unfit.
6. **Not qualified:**
   - No scenario kernel is fitted, so there are no bands and no coverage claim.
   - TPOT risk is unidentified, since tpot_miss ≈ 0.
   - One block with paired arms supports no statistical claim.
   - There is no Calibration/Validation/Final access.

### R6.6 Discriminating next evidence (not executed)

- Retain native per-request `computed_tokens` in the exact join, as a separate field
  so R3 is unchanged. Fit S as token progress per frame interval, conditional on β.
  The check is whether the birth-part 5 s error falls well below 5.5 when births are
  rolled through a fitted S with a common arrival tape.
- Plan-response falsifier: under the common tape, two plans differing only after t+1 s
  must give an identical cohort part and an identical birth part up to the first
  plan-differing admission.

### R6.7 Retained disagreements (added)

18. **Iterated vs direct.** I now hold, on evidence, that iterated aggregate 0.5 s
    transitions are the wrong representation for 5 s Goodput. A structural transition
    must be judged against the direct-horizon reduced form (5.90 on 181003), not only
    against history_mean.
19. **Declared hazard bins and back-off.** These are modelling choices that were not
    searched. The cohort result (0.12) is insensitive in the sense that the
    deterministic states carry most of it. That claim is not tested across
    alternative bins.
20. **Birth reduced form.** It sees budget features directly, which violates the
    "no direct cap in the service law" contract *if* read as a service law. It is
    labelled reduced-form and must not be used for plan ranking.

### R6.8 Receipt

- Tests: `python3 test_native_release_model.py` gives 40 passed, 0 skipped, including
  4 new R6 tests:
  - Same-aggregate / different-progress counterexample (also: future first-content
    receipts are not used).
  - Deterministic-impossible good raises, and the declared back-off works.
  - Refusal of an incomplete development block and of non-train data.
  - Frozen three-block origins = 544, with history_mean 8.76 matching R5.8.
- R4 and R5 CLI outputs are unchanged.
- Only the three owned files are modified. There is no GPU, network, DB, push or
  `gt done`.

---

## Round 7 — adversarial exchange: peer review, Mayor's full-plan F_N, and a paired common-tape contrast test (`nv3-opus-plan-response-v4`)

Inputs read (byte-pinned by the R6 manifest):
- opus 24746f6
- astra 0184613
- gemini 27f3068
- sol df00f30

I also read Mayor's R6 reproduction note. The R5 negatives are kept: 5 s good is
9.84 (iterated) vs 8.76 (history) vs 8.78 (oracle offers), and the bands
under-cover. All numbers below are **Train-only**: fit on 181001/181002 and
described on the **already-used** 181003. Nothing below is a calibration, coverage,
MPC, native-authority or GPU result.

### R7.1 Corrections to my own R6 (accepted)

1. **The R6 gain over the aggregate is small, as Mayor says.**
   - Total G5 is 5.90 (progress) vs 6.00 (aggregate hybrid), only about 1.7%.
   - The large gain over history and R5 comes from the direct-horizon birth
     treatment, not from per-ID progress.
   - Cohort G5 MAE of 0.12 applies to the cohort part only, which is about 19% of G5.
     I withdraw any reading of R6 as "progress solves 5 s".
2. **The R6 "birth" bucket is mislabelled at short horizons (Sol's partition).**
   - R6 "birth" means "good ID not in the Gateway snapshot at the cut". That includes
     offers scheduled before the cut that were not yet visible as a mark: in-flight
     ingress, snapshot lag, or transient turnover.
   - I measured it on the 181003 cuts with k%4=0 and previous labels, before the OOD
     filter. Among non-cohort good IDs, the share scheduled before the cut is:
     - 1 s: 339/716 = 47%
     - 3 s: 465/7860 = 5.9%
     - 5 s: 459/15224 = 3.0%
   - So the R6 1 s "birth" row is about half pre-cut, unseen work and is **not** a
     post-cut arrival statistic. The 5 s conclusion survives, since about 97% is
     post-cut scheduled.
   - The totals are unaffected. Future reports must use Sol's 3-way split:
     visible/marked cohort, unseen past, and post-cut scheduled.
3. **The R6 JSON was not byte-deterministic.**
   - The cohort probability sum iterated a Python `set` of string IDs, so it depended
     on PYTHONHASHSEED. That explains Mayor's 8 roundoff fields (max 5.56e-17).
   - Fixed with an exact `math.fsum` over the terms. The R6 output now has sha256
     `0056bf8d…b511` for PYTHONHASHSEED 0, 1 and 7.
   - It differs from the frozen `016456f6…8ed7a` in 12 floats only, max
     |Δ| = 1.1e-16. All reported R6 numbers are unchanged.
   - The R5 output stays `407a1b46…c123` under every seed.
4. **"computed_tokens unavailable" was a limit of my join, not of the source.**
   - The raw frames do carry it. Sol shows `(4090,0,4096,128)` and `(2039,0,4096,128)`
     prefill states.
   - My adapter keeps raw native frame fields, so prefill progress *is* recoverable
     within my own module. R6 simply did not use it. This is the scoped next
     experiment in R7.7.

### R7.2 Peer review: Gemini (27f3068)

- **Invented service constants.** The counterexample and `StructuralBatchProgressHybridModel`
  hard-code:
  - `max_batched_tokens=2048` (a 2048-token chunk per 0.5 s step);
  - a KV formula `(decode*128 + prefill*512)/(32*2048)`;
  - "one decode token per 0.5 s step".
  None of these is a measured pinned-scheduler setting or a timing estimate. The
  conclusion "State B rejects 4 and has Goodput 0" is a property of those
  constants, not of the native system. It is a valid mechanism sketch only.
- **The main R6 claim is contradicted by actual Train data.** Gemini states that
  "the 5 s bottleneck is structural progress blindness". On 181003:
  - ID-progress state reduces *cohort* G5 error to 0.12;
  - the residual 5.5–5.9 is post-cut work;
  - realized offers barely help (5.88 → 5.50).
  Progress blindness of the *live cohort* is therefore not the 5 s bottleneck. A
  progress-dependent *service of births* remains possible but unshown.
- **Silent fallback in the receipt test.**
  - `run_structural_progress_vs_scalar_diagnostic` falls back to the constants
    10951, 46975, 0.8109, 9.840 and 8.757, and always uses 8.78, when the JSON is
    absent or the keys are missing.
  - `test_train1_2_fit_train3_descriptive_diagnostic_receipt` therefore passes
    without data.
  - The numbers do match the Mayor R5 JSON keys I checked. The defect is test
    integrity, not falsified data.
- **Ledger clamp.** `R ← max(0, R − c_j)` in the narrative would hide a stock-flow
  violation. Exact release must raise, as Gemini's own line 612 requires.
- **"Validator proves ∂μ/∂u = 0"** checks only Gemini's own model. It cannot
  establish the exclusion for the native system. The exclusion is a model
  restriction; a falsifier for it is in R7.6.

### R7.3 Peer review: Astra (0184613)

- **Agreed:**
  - the control path `u → ACK → admission → S,Q → service`;
  - joint forward allocations rather than per-HTTP serial residence;
  - separate native, delivered and physical counters;
  - EOS as a latent mark;
  - CRN applied to the resulting physical state.
- **The restricted helper rejects common real states.**
  - `BatchProgress` rejects prompt-complete with native-output zero. Sol's actual
    frames show near-prompt-complete, output-0 members (4090/4096).
  - Without a pending-commit state, the helper cannot be initialised from many real
    cuts. Astra itself labels it "not a drop-in adapter", so this is an
    applicability boundary, not an error.
- **The counterexample is a toy.** It uses six positions per 0.25 s and zero
  publication lag, both declared as fixtures. It shows that progress *can* matter
  under perfect arrivals. The Train data shows that, for the cohort part, it
  contributes ≤0.12 G5 MAE at 5 s. Astra's mechanism therefore needs to act through
  *births*, competing with prefill, to explain the residual. That is testable (R7.7).
- **No fit is attempted.** Γ_θ is acknowledged as not identified from snapshots. I
  agree. A full Γ_θ is unlikely to be identifiable before per-forward lineage exists,
  which argues for the direct and hybrid reduced forms judged by R7.6.

### R7.4 Peer review: Sol (df00f30)

- **The exact four-way endpoint partition is right.** It is visible snapshot,
  marked-unknown, past outside snapshot, and post-cut scheduled. It exposed my R6
  mislabelling (R7.1.2), which I adopt.
- **The raw-progress evidence is right** and corrects my "unavailable" wording
  (R7.1.4).
- **Disagreement:** waiting for online callback authority before *any* fit is not
  necessary for *offline* response identification.
  - Paired common-tape arms provide label-only tests of a plan response without
    online receipt authority (R7.5).
  - Deployment authority is still withheld, as Sol says.
- Sol's three selected cuts are descriptive only. Sol states this, and I agree.

### R7.5 Mayor's alternative: direct full-plan response F_N(x, U, w) — identification analysis

**Design facts**, measured by `_schedule_design` on the frozen data:

| | Train 181001–2 | Dev 181003 |
|---|---|---|
| 1 s slots, P(repeat) | 0.483 | 0.486 |
| five-slot patterns supported (of 32) | 32 (min 43 windows) | 32 (min 25) |
| constant 16 / constant 32 windows | 43 / 43 | 31 / 31 |
| ACK lag p50 / p99 / max (s) | 0.041 / 0.42 / 2.41 | 0.041 / 0.36 / 1.32 |
| retried / unapplied actions | 13 / 0 | 7 / 0 |

- Paired arms have **complementary** schedules and the identical offered tape.
- At 304/544 evaluation cuts, the planned budget differs from the in-force budget.
  The origins fall on slot boundaries, so a change is often still in flight at the
  cut.

**Identification:**
- The schedule is pre-generated, independent of state and tape, and close to i.i.d.
  Bernoulli(½) per slot.
- For x in the random-policy state support, the **ITT response**
  E[Y_h | x_t, do(planned U_{t:t+5} = u)] is therefore identified for every u among
  the 32 supported patterns, including constant plans.
- Randomized observed paths *do* identify multistep and constant open-loop plan
  effects. This is a direct total effect through admission → state → service, so it
  is **legitimate learned MPC input without being a GPU service law**. The "no
  direct cap in S" restriction applies only to structural kernels.

**What does not transfer:**
1. *Compliance is plan-dependent.* ITT assumes the deployment ACK law per switch
   matches Train. Constant plans have no switches, while frequent switching
   accumulates lag (p99 0.4 s, max 2.4 s, close to 0.5 s TTFT). Actual-ACK
   estimands need an ACK model and are not identified as same-state effects.
2. *State positivity.* MPC-chosen plans induce state distributions such as long
   32-holds that differ from random alternation. Random-policy residual coverage
   does **not** transfer to an optimized policy or to all candidates. An OOD gate on
   (x, u) is required.
3. *Functional form.* A ridge that is additive in 10 planned values is a
   time-weighted average-cap alias. It cannot represent order or interaction
   (16→32 vs 32→16) except linearly. A per-pattern table is too thin: 43 windows,
   overlapping, from 20 episodes.

**The decisive test of a plan-response model is ranking, not level MAE.** In each
paired arm, the common tape cancels the arrival draw. A model must predict
Y_A − Y_B from each arm's own pre-cut state and planned sequence. This is a
difference of two factual forecasts, not a same-state causal effect, since the
states differ. Predicting zero difference is the honest null.

### R7.6 Runnable discriminating test: paired common-tape contrast

`plan_response_diagnostic` (fit on 181001/181002 with the fixed ridge λ, origins
fixed, and the R6 ID-progress cohort shared by all variants) compares four
plan encodings:
- `blind`: in-force budget/headroom only;
- `r6_next`: the R6 reduced form;
- `masked_plan`: planned 0.5 s sub-steps inside (t0, t0+h];
- `full_plan`: all 10 sub-steps of (t0, t0+5]. These equal the five 1 s slots at
  aligned cuts, without averaging.

The evaluation covers 544 origins and 264 arm pairs (5 cell clusters). Each figure
is the block mean of the cluster means.

**Paired-difference MAE |Δŷ − Δy|** (zero = predict no difference;
sign = agreement on pairs with |Δy| ≥ 1):

| target | h | zero | blind | r6_next | full_plan | sign blind / full |
|---|---|---|---|---|---|---|
| good | 1 s | 3.58 | 1.46 | 1.40 | 1.40 | 0.90 / 0.92 |
| good | 3 s | 5.21 | 4.87 | 4.73 | 4.73 | 0.71 / 0.67 |
| **good** | **5 s** | **6.90** | 8.15 | 8.33 | 8.15 | 0.62 / 0.62 |
| rejected | 1 s | 4.18 | 4.05 | 3.26 | 3.33 | 0.65 / 0.90 |
| rejected | 3 s | 5.51 | 5.74 | 5.74 | 5.33 | 0.54 / 0.77 |
| rejected | 5 s | 7.19 | 7.94 | 7.88 | 7.14 | 0.54 / 0.72 |
| **offers (placebo)** | 1/3/5 s | **0.011 / 0.015 / 0.015** | 0.71 / 2.12 / 3.73 | ≈ same | 0.73 / 2.12 / 3.73 | — |

**Level MAE, 5 s:**
- good: blind 5.92, r6 5.91, full 5.84
- rejected: 9.34 / 9.30 / 9.19
- offers: 10.79 for all variants

Masked vs full: at 5 s they are identical by construction. At 1 s and 3 s they
differ by ≤0.014 in level MAE, so post-horizon slots add nothing, as they should.

**Findings:**
1. **The common tape is real.** Realized paired Δoffers is ≈0.015 per 5 s.
2. **Any free regression of an arrival quantity on cap-affected state breaks the
   common law.**
   - The ridge "offers" forecast predicts a 3.7 per-5 s paired difference that does
     not exist.
   - Offers *must* be imposed structurally, as law(H_t) shared across plans, never
     regressed on x. R5's rollout did this. The R4 v1 recursion and any F_N that
     outputs offers from x violate it.
   - The same spurious attribution can leak into reduced-form good and rejected
     regressions through their state features.
3. **The plan pathway is visible in rejections.** Full-plan inputs raise sign
   agreement from 0.54 to 0.72–0.90 and reduce paired error at all horizons. The
   5 s gain is only to the level of the zero predictor (7.14 vs 7.19).
4. **The MPC objective contrast fails.** At 5 s, every variant predicts paired good
   differences *worse than predicting no difference* (8.15–8.33 vs 6.90), with sign
   agreement of only 0.62.
   - The models predict |ΔG5| of 7.5–8.3, extrapolating correlational state
     coefficients.
   - At 1 s the state-driven contrast is good: 1.40 vs 3.58, sign 0.92. It mostly
     comes from the cohort.
   - **Current direct/reduced forms, including R6 and an additive F_N, have no
     demonstrated ability to rank plans by 5 s good.** Their level MAE gains
     (5.84–5.92) are not ranking skill.

### R7.7 Minimal usable model/interface next (proposal only, not implemented)

```
PlanResponse.scenarios(x_cut, plans: [5x{16,32} 1s slots + phase], law: CommonArrivalLaw,
                       seeds) -> per plan, per seed: {G_h, U_h, Rej_h, Offers_h,
                       released ids/cost}_{h=1,3,5}
```

1. **Offers and payloads:** one draw per seed from law(H_t). They are shared by all
   plans and are *not* a function of x or u, which makes the AC1 placebo
   structurally zero.
2. **Admission:** exact ledger replay `R + c ≤ u(τ)` of that draw against each plan,
   with releases from steps 3–4. Costs are immutable and there is no eviction. The
   ACK law is applied per planned switch, using the empirical Train lag
   distribution, labelled ITT.
3. **Live cohort:** the R6 ID-progress hazard as a completion-time distribution.
   Sol's unseen-past group is carried as unknown mass with its own empirical hazard.
4. **Admitted births:** a marked completion and TTFT-risk kernel conditioned on
   payload class and batch state at admission. The batch state includes `running`,
   `waiting` and the **raw prefill backlog Σ(prompt − computed_tokens)** of
   native-visible IDs. Admissions update this state; that is the only cap → service
   path. The kernel is fit on Train labels as conditional empirical hazards with
   declared bins, with no search.
5. **Uncertainty:** CRN across plans, using the same law draw and per-ID uniforms.
   Bands are reported as random-policy-only.

**Scoped next fitting experiment** (one candidate):
- Fit (4) on all complete Train blocks *other than* the newest.
- Evaluate on new complete Train blocks with AC1–AC6.
- Compare against `blind`, `full_plan` and zero.
- The discriminating question: does the batch-state birth kernel predict **paired
  ΔG5** better than zero, where every reduced form here fails?

### R7.8 Acceptance criteria for a fitted cap-plan response (testable on new complete Train blocks)

Pre-register a frozen source sha, fixed horizons 1/3/5 s, the R4/R5 origin rule, a
fixed λ and bins, and no refit on any evaluated block.
- **AC0 Data:** every evaluated block is complete, with 5 cells × 2 complementary
  arms, byte-verified, Train-only. 181001–3 are already used and cannot serve as
  evidence.
- **AC1 Exogeneity:** predicted offers are bitwise invariant to the plan and to
  cap-caused state, with model paired Δoffers = 0. The realized paired
  |Δoffers| ≤ 0.05 per 5 s is checked as a data precondition.
- **AC2 Causal mask:** the prediction for horizon h is bitwise invariant to planned
  slots after t0 + h.
- **AC3 Exclusion falsifier:** two plans that never bind admission on a draw (same
  admissions) must give identical service and outcomes for that draw.
- **AC4 Primary contrast:** on **every** new block, the paired ΔG5 MAE (block mean
  of cluster means) is below the zero predictor and below `blind`. Sign agreement
  on |ΔG5| ≥ 1 pairs is > 0.5. This must replicate on ≥2 new blocks before any
  controller use; it is a gate, not a statistical guarantee. Rejected and 1/3 s are
  reported alongside.
- **AC5 Level non-regression:** total G1/3/5 MAE is ≤ R6 `progress_hybrid` and
  ≤ history_mean on the same origins.
- **AC6 Exactness:** integer, nonnegative per-scenario counts. Admitted − released
  cost and counts conserve, good ≤ possible, and the 3-way ID partition is exact.
- **AC7 Support/OOD:** abstain when the plan pattern has fewer than the declared
  Train windows or x is outside the Train joint support. Coverage under the random
  policy is reported as **not transferable** to MPC-chosen plans. A later on-policy
  check must keep a randomized fraction of slots so positivity is preserved.

### R7.9 Retained disagreements (new)

21. **Gemini:** progress blindness of the live cohort is not the 5 s bottleneck on
    actual Train data. Invented 2048/KV/step constants do not qualify a native
    mechanism.
22. **Astra:** the mechanism is plausible, but its effect must act via births. A
    full Γ_θ is unidentifiable from current snapshots, so a fitted hybrid with a
    contrast gate is preferred over awaiting per-forward lineage.
23. **Sol:** offline paired contrasts can test a response before online receipt
    authority exists. Deployment stays withheld.
24. **Mayor F_N:** it is legitimate (an identified ITT open-loop response, not a
    service law). The additive ridge version fails AC4 at 5 s and must not emit
    offers. Its transfer needs ACK-law and state-positivity qualification.
25. **Self:** R6/R7 level-MAE improvements are not plan-ranking evidence. Only AC4
    on new blocks is.

### R7.10 Receipt

- Command: `python3 native_release_model.py --replica-plan-response .../pr33-native-v3-first-three-complete-train-blocks-frozen`
  (about 5 s). Output sha256
  `f65efd69ef1fb8b2a5af26a3499f69b1ee7179cf62019e5520f3a396a3295f64`, identical
  under PYTHONHASHSEED 0, 1 and 7. Train rows 4586, origins 544, pairs 264.
- R6 output `0056bf8d…b511` (roundoff-only change from 016456f6, max 1.1e-16).
  R5 output `407a1b46…c123` unchanged.
- Tests: `python3 test_native_release_model.py` gives 43 passed, 0 skipped, with
  3 new R7 tests:
  - Exact planned encoding, the causal mask, and invariance to future labels.
  - Schedule-design facts and the refusal gates.
  - The frozen paired negatives: offer placebo, ΔG5 worse than zero, and
    rejected-plan skill.
- Only the three owned files are changed. There is no GPU, network, DB, push or
  `gt done`.

---

## Round 8 — fitted admission-mediated birth / marked-progress response (R7.7)

### R8.0 Pre-registration (frozen in this commit, BEFORE any 181004/181005 prediction)

- **Module version.** `nv3-opus-admission-birth-v5`, CLI `--replica-admission-birth TRAIN_DIR EVAL_DIR`.
- **Data split.** Fit on complete Train 181001–181003 (old collector 6c11fe7e). Describe complete Train-development 181004/181005 (recovery collector 729b144a).
- **Frozen settings.** Horizons 1/3/5 s, STEP 0.5 s, `SIM_SCENARIOS=32`, seed string `nv3-opus-r8-common-law`, band 10/90, `LOAD_BIN=8`, `LOAD_CAP=4` (reused R6 bins), `HAZARD_MIN=20`, `RIDGE_L2=1e-3`, `PENDING_WINDOW_S=30`.
- **Origin rule.** Unchanged from R6/R7: k%4==0, previous labels present, not Train-support OOD, no outstanding action, full 5 s labels, actual path available. Comparators must not raise "unidentified"; any origin that does is excluded for ALL comparators, so every comparator is scored on the same origins.
- **Comparators.** Refit on 1/2/3: history_mean, aggregate_hybrid, r6_progress_hybrid, r7_full_plan. The candidate is r8_admission_birth, with ablations r8_no_load_bin and r8_no_pending.
- **Metrics.** Primary: total `good_5` block-mean MAE. Secondary: paired-arm factual differences vs the zero predictor. These pairs have different arm states, so they are NOT same-state action effects.
- **Source binding.** An explicit `SOURCE_BINDINGS` registry, with no aliasing:
  - Each source binds its own index file, collector, protocol, controller and native source.
  - Both sources share one cost/support/implementation/clock binding.
  - Every confirmed hold must equal the in-force ACK (budget, version and reference operation, run/clock), and the schedule slots must be covered exactly once.
  - Eval payload costs must equal the Train costs.
- **Boundary revision before sealing (Mayor R8 boundary check).** The draft v5 used the client HTTP terminal as the Gateway release time and released client-terminal owners at 0. It was replaced before freezing with interval-censored Gateway owner disappearance (UPPER bound). Pending latent-status IDs are now conditioned only on having no client terminal by the cut.
  - The draft was run once as a smoke test on the already-used 181003 (fit 1/2): G5 MAE 3.75. Saved as `opus-r8-draft-superseded-smoke-181003.json` (sha256 5839d338…c6f6).
  - The revised spec on the same smoke gives G5 MAE 4.04 (`opus-r8-smoke-181003-fit12.json`, sha256 2baec441…ea55).
  - The revision made the smoke score *worse*. It was not chosen for score.
- **Disclosure.** While inspecting the schema, one coarse 181004 index row was seen: p128-m128-arm1 offered 3981 / complete 2696 / rejected 1285. No 4/5 prediction was computed before this commit.

### R8.1 Sealed run (after pre-registration commit 2bfbb09; no setting changed afterwards)

**Command:**

```
python3 native_release_model.py --replica-admission-birth \
  .../pr33-native-v3-first-three-complete-train-blocks-frozen \
  .../pr33-native-v3-recovery-first-two-train-blocks-frozen \
  > opus-r8-admission-birth-181004-5.json
```

- **Raw output.** Per-block and per-cell results, with sha256 `939e835a9162d31be6a3be8cc20570e46f6156290578277eaa9162f2877b8a68`. Identical under `PYTHONHASHSEED=5`. Runtime 27 s. Saved in the session files directory.
- **Binding.**
  - Train: 30 episodes, source 6c, 0 holds.
  - Eval: 20 episodes, source 729, with 1184 applied commands and 1196 confirmed holds. Every hold is bound to its in-force ACK operation, version and budget, and coverage is exact.
  - Eval payload costs equal the Train costs.
  - Eval design: all 32 five-slot patterns are present (min 48 windows); ACK lag p50 0.041 s / p99 0.62 s / max 1.91 s; 10 retried and 0 unapplied commands.
- **Support and exclusions** (1220 grid origins in total):

  | Reason | Origins |
  |---|---|
  | no previous/current labels | 45 |
  | horizon beyond episode | 40 |
  | actual path unavailable | 10 |
  | OOD joint_bin | 16 |
  | OOD hist_rejected range + joint_bin | 1 |
  | unidentified | 0 |

  - **1108 scored origins** (552 + 556) and 540 arm pairs.
  - Live IDs at cuts: 8895, of which 1322 (14.9%) were not native-visible. 1250 pending latent-status IDs.
  - Planned ≠ in-force at the cut on 565 of 1108 origins.
- **Release boundary (Train).**
  - 26591 admitted records are in the birth kernel. 41 Train admitted IDs have no later snapshot and are excluded as unidentified.
  - Upper bound minus client terminal: p01 −0.026 / p50 +0.072 / p99 +0.26 s, min −0.18 s.
  - Lower bound minus client terminal: p50 −0.069 s.
  - So Gateway release is NOT the HTTP terminal. It can precede it by up to 0.18 s and follow it by up to 0.55 s at the upper bound. True release timing is known only within the snapshot interval.

**Primary result: total G_h block-mean MAE (bias), pooled over 181004+181005**

| predictor | G1 | G3 | G5 |
|---|---|---|---|
| history_mean | 2.86 | 6.04 | 9.16 (−0.35) |
| aggregate_hybrid | 1.39 | 3.84 | 6.12 (+0.59) |
| r6_progress_hybrid | **1.11** | 3.58 | 5.96 (+0.70) |
| r7_full_plan (additive F) | 1.11 | 3.51 | 5.93 (+0.87) |
| **r8_admission_birth** | 1.22 | **2.63** | **4.08 (−1.26)** |
| r8_no_load_bin | 1.28 | 2.95 | 4.64 (−1.78) |
| r8_no_pending | 1.24 | 2.75 | 4.21 (−1.56) |

- **Per block, G5:**
  - 181004: r8 4.06 vs r7 5.67, r6 5.64, aggregate 5.78.
  - 181005: r8 4.09 vs r7 6.20, r6 6.28, aggregate 6.46.
- **Per cell.** r8 has the lowest G5 MAE in all 10 block×cell groups. In both p4096-m128 groups the load-bin ablation is better by 0.01–0.03.
- **Truth mean.** G5 = 31.0: 6.2 from the cut cohort and 24.8 from later IDs.

**Secondary result: paired-arm factual differences, 540 pairs, MAE of predicted ΔY (sign agreement where |Δ| ≥ 1)**

These pairs have different arm states. They are not same-state action effects.

| target | zero | r7_full_plan | r6_progress | r8_admission_birth | r8_no_load_bin |
|---|---|---|---|---|---|
| ΔG1 | 3.39 | **1.44** (0.87) | 1.44 (0.87) | 1.79 (0.83) | 1.86 |
| ΔG5 | 5.91 | 7.86 (0.58) | 7.90 (0.59) | **4.17 (0.70)** | 4.76 |
| Δrejected5 | 6.85 | 7.39 (0.75) | — | **3.79 (0.84)** | 4.07 |
| Δoffers5 (placebo) | 0.038 | 3.56 | — | 0.18 | 0.18 |

### R8.2 Findings (Train DEVELOPMENT only; not Calibration/Validation/Final)

1. **The hypothesis is supported at 3 s and 5 s, but not at 1 s.**
   - The admission-mediated birth simulator reduces total G5 MAE by 31% vs the strongest prior comparator (5.93 → 4.08). It does so in both held blocks and in every cell.
   - For the first time, a model beats the zero predictor on paired ΔG5 (4.17 vs 5.91; R7 was 8.15 vs 6.90 on 181003).
   - At 1 s, R6/R7 cohort hazards remain better (1.11 vs 1.22).
2. **Where the gain comes from.**
   - Load-bin ablation: removing the Gateway-owned-load bin raises G5 MAE 4.08 → 4.64, mostly in p128-m128 (10.7 → 13.4).
   - Pending ablation: G5 4.08 → 4.21, so pending IDs add little at 5 s and some at 1–3 s.
   - Most of the gain over R7 comes from structurally simulating admissions of the common future offered draw.
3. **Negatives that must be retained.**
   - **(a) Systematic G5 under-prediction** (bias −1.26).
   - **(b) Rejected level MAE is no better than R7** (9.25 vs 9.14) and its bias is +3.0. Rejections are over-predicted, consistent with the conservative UPPER-bound release convention over-reserving stock. This is a direct consequence of the release-vs-terminal boundary, not a fixed point.
   - **(c) Scenario 10/90 bands under-cover:** G5 0.63, rejected5 0.52, offers5 0.49 vs nominal 0.80. The Poisson law with a point-estimated rate ignores rate uncertainty and batch-correlated arrivals. The bands are not calibrated intervals.
   - **(d) The offer placebo is 0.18, not 0.** The arms' pre-cut law estimates differ even though the plan never enters, so cross-arm law estimates are not bitwise equal (as Mayor allowed).
   - **(e) 1 s is worse than R6.**
4. **Model-implied contrasts are NOT measured effects.** The output has constant-32 minus constant-16 values (p128-m128 ΔG5 +40, Δrej −56; p4096-m256 ΔG5 +1.7). These come from the fitted kernels at observed states, with load-bin service slowdown as the only cap→service path. They are unverified counterfactuals, and random-schedule support does not extend them to optimized policies.
5. **Data status.**
   - 181004/5 come from a different collector (729, confirmed holds). Bindings are explicit, with no aliasing.
   - These blocks are now USED development; a next fresh complete Train block is needed for any further claim.
   - No calibration, MPC or statistical guarantee is claimed.

### R8.3 Portable interface (fitted, Train 1–3)

- `fit_admission_kernels(entries)` returns cohort/birth marked kernels (release upper, good, terminal), plus the release-lag receipt.
- `payload_costs(episodes)` returns the exact (cell, max_tokens) → original whole-owner cost map.
- `admission_cut_state(step, rows, raw_rows, costs, sent_index)` builds the cut state from receipts ≤ t0 only: live owners with exact costs and progress keys, latent pending IDs, the pre-cut all-offered mix, and the arrival law.
- `draw_common_law(cut, key, scenario)` gives one plan-free draw keyed by (block, cell, k, scenario). The same draw is shared by all plans and by paired arms.
- `admission_birth_response(cut, plan[10], key, kernels, costs)` returns the mean and 10/90 band of good, rejected and offers at 1/3/5 s.
- `simulate_plan` holds the exact ledger. Cost is immutable; there is no eviction; each owner is released once; the only cap→service path is via the load bin.
- **Explicitly unidentified or approximated:**
  - True release time within the snapshot interval (the upper bound is used).
  - The latent Gateway status of pending IDs.
  - ACK-timing compliance (ITT on the planned budget).
  - Native running/KV progress beyond the R6 cohort keys.
  - Rate uncertainty and batch correlation of arrivals (the bands under-cover).
  - The 41 Train IDs with no later snapshot.

### R8.4 Retained disagreements

26. **The R8 gain does not make the simulator an MPC model.**
    - Under-coverage, rejected bias and the 1 s loss block any use as a controller.
    - The next test must use a fresh complete Train block, with the same frozen v5 source and no change.
27. **I disagree with treating the release upper bound as harmless.** The +3 rejected bias is its measurable consequence. A lower/upper sensitivity pair belongs in a fresh, separately pre-registered diagnostic, not a post-hoc rescue on 181004/5.
28. **Mayor's parent native_state adapter (separate engine IDs, running-only progress, immutable owners) was not used here.** R8 still uses the R6 joined output_tokens key. Its integration is future work and must be pre-registered.

**Receipt:**
- Pre-registration commit 2bfbb09.
- Source sha256: `b1d83f7af2956d51b5f9d9b014ecff50b2b3a6915c5f10cdb52f034ed8a920b5`.
- Tests sha256: `b481291425e8c922efb0a39a114c1e8e9a08c03ddcb591fe88b8bc9a3fb028ef`.
- 48 tests passed, 0 skipped.
- Earlier outputs are unchanged: R5 407a1b46…c123, R6 0056bf8d…b511, R7 f65efd69…5f64.
- Only the three owned files were changed. There was no GPU, network, DB, push or `gt done`.

---

## Round 9: release-endpoint sensitivity (pre-registered), mean_truth fix, and optimized-policy transfer critique

### R9.0 Erratum: R8 `mean_truth`

The frozen v5 `summarize` built `{eid: [truth]}` inside a comprehension, so only the LAST origin per episode survived. Mayor found this in R9.

- **Fix.** `_mean_truth`: per-episode mean over all scored origins, then a mean over episodes. This is the same aggregation the MAE uses.
- **Regression tests.**
  - `test_r9_mean_truth_uses_every_origin_per_episode`: a multi-origin fixture.
  - The same test reproduces Mayor's 6/7 audit `corrected_mean_truth` (G5 33.2791) to 1e-12 from the audit's per-origin truths. It does not re-run v5 on 6/7.
- **Unchanged.** Re-running the v5 CLI on 181004/5 changes ONLY 45 `mean_truth` leaves. Every prediction, MAE, bias, coverage, paired and implied-contrast value is byte-identical. The frozen raw `939e835a…` is preserved unchanged. The corrected output is `opus-r9-v5-meantruth-fixed-181004-5.json`, sha256 `8e3f7dac770b072a9806cb35b23d188d6cf2f3c49671e52bde98ebc76ea1896f`.
- **Correction to R8.1.** The reported "truth mean G5 = 31.0: 6.2 cohort + 24.8 later" was wrong. Correct pooled 181004/5 values:

  | quantity | pooled mean |
  |---|---|
  | G5 | 33.19 (cohort 6.42 + later 26.77) |
  | rejected_5 | 22.13 |
  | offers_5 | 59.22 |

  Per block, G5 is 33.13 for 181004 and 33.24 for 181005. Relative statements in R8 (MAE ranks and biases) are unaffected.

### R9.1 Pre-registration: `nv3-opus-release-endpoint-sensitivity-v6`

This is frozen in this commit, before any 181008/181009 artifact exists locally.

- **CLI.** `--replica-release-sensitivity TRAIN_DIR EVAL_DIR`.
- **Fit.** Train blocks 181001–181003 only, exactly as in v5. Blocks 4–7 are NOT refit.
- **Eval.** `R9_EVAL_BLOCKS = (181008, 181009)`. These must be complete: 5 cells × 2 arms each, with randomized pair contrasts. They are Train development, not Calibration, Validation or Final.
- **Unchanged from v5:**
  - Kernels, bins (`LOAD_BIN=8`, `LOAD_CAP=4`) and `HAZARD_MIN`.
  - Arrival law, `SIM_SCENARIOS=32`, seed string and 10/90 band.
  - Horizons 1/3/5 s, SLO/API-stop labels, original whole-owner cost.
  - Origin rule and all comparators.
- **The single varied quantity.** The release time is taken as the lower end L or the upper end U of each owner's censoring interval (L, U]. L is the last snapshot containing the owner; U is the next snapshot.
  - The cohort record, the birth duration and the load-bin owner count all use the same endpoint.
  - The pending-survival condition still uses the client terminal.
- **Invariance gates** (raise if violated):
  - Identical origin sets for both endpoints.
  - Identical truths and identical non-R8 comparator predictions for both endpoints.
  - The upper run reproduces v5 exactly. Verified on the used 4/5 data: every field is equal to the mean_truth-fixed v5 output, with 1108 origins.
- **Reported.**
  - Both complete runs, per block and per cell.
  - The per-origin `upper_minus_lower` prediction contrast.
  - `truth_between_endpoint_means`, a descriptive frequency that is NOT a bound.
  - Per-predictor criteria: rejected_5 bias, G5 MAE and G5 bias under each endpoint.
- **Pre-declared reading (no selection, no averaging).**
  - **H9a.** If the release convention explains the R8 rejected over-prediction, then |rejected_5 bias| under LOWER < 1.5. The threshold is half of the R8 +3.0 and is not searched. If it is ≥ 1.5, the release endpoint is falsified as the main explanation.
  - **H9b.** The G5 MAE ranking of r8 vs the strongest R6/R7 comparator is reported under BOTH endpoints. "Robust to release convention" is claimed only if both endpoints are below the strongest comparator in both blocks.
  - Goodput is non-monotone in release time: earlier release admits more work and can slow service. So the endpoint values are sensitivities, not guaranteed outcome bounds, and no endpoint is adopted after scoring.
- **Engineering smoke on used 181004/5.** I checked only the invariance gates and upper == v5. Lower-endpoint metrics were computed but not inspected.
- **Data binding.** The 8/9 directory must match a registered `SOURCE_BINDINGS` entry. If Mayor's sealed subset comes from a new collector, the loader refuses. Any new binding entry would be added in a separate commit containing ONLY the exact index hashes, before scoring, and disclosed. Live replicas are not scored.

### R9.2 Critique: transferring the SAME v5 core to an optimized policy

The R8 and 6/7 wins (G5 4.08/4.42/4.23 vs about 5.6–5.9) are random-schedule, Train-development descriptions. Each item below is a separate reason they do not transfer to an optimized controller.

1. **ACK law.**
   - v5 is ITT on the planned 0.5 s budget path and ignores ACK timing. Planned ≠ in-force at 51% of cuts. ACK lag is p50 0.04 s, p99 0.42–0.62 s, max 1.9–2.4 s.
   - Under random schedules, ACK lag is independent of the plan. An optimized policy issues state-dependent commands: it switches when reserved stock is high, which is exactly when Gateway/CAS latency may be longest. So the lag distribution is no longer independent of state.
   - Required: an ACK-lag law conditioned on pre-command receipts, and in-force path = planned path shifted by a drawn lag.
   - Test: ITT vs ACK-shifted simulation on Train, compared on rejected_1, where the 0.5 s timing matters most.
2. **Unknown pending.**
   - Pending sent-not-owned IDs are re-offered at the cut against the PLANNED budget. Their real admission was decided at arrival, against the then-in-force budget.
   - Under random schedules this contributes little: G5 4.08 vs 4.21 without pending. A tight-budget optimized policy raises both the latent-rejection fraction and the timing mismatch, and the sign of the bias is unidentified.
   - Pending status remains latent unless a Gateway admission receipt with the decision time is captured.
3. **Load-bin causal invariance.** The birth kernel assumes P(duration, good | cell, payload, owned-count bin at send) is policy-invariant. Three violations are plausible:
   - **(a) Service is fixed at admission.** In reality, later admissions slow earlier owners. An optimized policy that deliberately shapes later load changes earlier IDs' service; v5 cannot represent this.
   - **(b) The bin is a Gateway owner count, not native running/KV/prefill tokens.** Within-bin composition (prefill-heavy vs decode) is policy-dependent. A controller that parks load just under a bin edge (e.g. 15 owners) exploits within-bin heterogeneity.
   - **(c) The only cap→service path is the bin.** The p4096-m128 ablation slightly favoured no bin (by 0.01–0.03), so the bin's causal content is cell-specific.
   - Test: a randomized state-dependent arm (e.g. an ε-randomized threshold policy) whose kernel residuals are compared with random-schedule residuals at matched bins. This is out of scope here; it needs Mayor-run data.
4. **SLO / risk bands.**
   - 10/90 scenario bands cover 0.58–0.65 for G5 and about 0.5 for rejected/offers. Any risk-constrained MPC built on the lower G or upper TTFT-miss quantile would be falsely optimistic.
   - Coverage measured on random-policy residuals does not transfer to the optimized policy's state distribution in any case.
   - Missing: arrival-rate uncertainty, batch-correlated arrivals and kernel-draw dependence across IDs.
5. **Feasible hard 16/32 budgets.**
   - Support exists only for budgets {16, 32} per 1 s slot. All 32 five-slot patterns have ≥ 43–48 random windows, so plan-space positivity holds marginally, but state × plan joint support is thin.
   - Intermediate budgets (e.g. 24) are outside the kernel's support, not an interpolation.
   - Non-eviction means reserved stock can exceed a newly lowered budget for seconds (prior cost > 16 in about 14–40% of cap-16 observations). v5 reproduces this only through its admission test; it has no eviction or overshoot law.
   - Whole-owner costs of 1.02–4.70 make budget 16 admit as few as 3 p4096-m256 owners. An optimized policy's value therefore hinges on discrete packing that v5 resolves only up to cost-class granularity.
   - The model-implied const32−const16 contrasts (e.g. p128-m128 ΔG5 ≈ +40) are unmeasured counterfactuals.
6. **Conclusion.** v5 is a usable random-policy descriptive response with honest exact-ledger admission. It is not an admissible optimized-policy model until items 1, 3 and 4 are tested on data whose policy induces the target state distribution.

### R9.2 Receipt (pre-registration)

- **Source** `native_release_model.py`: sha256 `c58ba883bd84afcc0cac3008510bd4c714c185101b82d7e869757884fea1af35`.
- **Tests** `test_native_release_model.py`: sha256 `417c951ac1b92f1dfed31f8d736e135e0d757603b9e947015f91c06426e2d2fc`. 51 passed, 0 skipped.
- **Earlier outputs unchanged:** R5 `407a1b46…c123`, R6 `0056bf8d…b511`, R7 `f65efd69…5f64`. v5 predictions and MAE are byte-identical apart from `mean_truth`.
- **Not yet run:** the 181008/181009 sensitivity, pending Mayor's checksum-sealed complete subset.

### R9.3 Results on sealed fresh Train 181008/181009, run unchanged at prereg 76b1ad3

**Data and command**

- **Data:** `.../pr33-native-v3-recovery-train-eight-nine-frozen`.
  - 20 episodes (5 cells × 2 arms × 2 blocks), 2400 s offered.
  - 40 artifacts; all 40 re-verified against `verified-artifact-sha256.jsonl` (sha `8a01d66a…96e6`), 0 mismatches.
  - `index.json` sha `ec4d9160e45b41cd7143445192bcfa5abcdaae6dcb584c89d42e733421b103a3`.
  - `subset_scope` binds `original_index_sha256 f8a5f8a9…df93c` and `preregistration_commit 76b1ad3`.
  - Source 729b144a, Train partition, existing registry binding; no guard was relaxed.
- **Command:**
  `python3 native_release_model.py --replica-release-sensitivity <first-three-complete-train-blocks-frozen> <recovery-train-eight-nine-frozen>`
  - Source `c58ba883…af35`; runtime 55 s.
- **Output:** `opus-r9-release-sensitivity-181008-9.json`, sha256 `d3f6d3ec5a49abd7b16b639d47cc29ca6739812fcbcf545d9b6fe72ff040a0a5`, 224,866 bytes.
  - Byte-identical under `PYTHONHASHSEED=7`.

**Counts.** Same for both endpoints; the invariance gates passed.

| count | value |
|---|---|
| Grid origins | 1217 |
| Scored origins (556 / 556 per block) | 1112 |
| Pairs | 543 |
| Excluded: no_previous_or_current_labels | 42 |
| Excluded: horizon_beyond_episode | 40 |
| Excluded: OOD | 14 |
| Excluded: actual_path_unavailable | 9 |
| Excluded: unidentified | 0 |
| Pending IDs | 1318 |
| Live IDs | 8996 |
| Live IDs not native-visible | 1324 |
| Planned ≠ in-force at cut | 528 |

Pooled truth means, using the fixed aggregation: G5 33.665, rejected_5 22.021, offers_5 59.149.

**Pooled MAE / bias.** The upper run reproduces the v5 convention.

| target | history | aggregate | R6 | R7 | r8 UPPER | r8 LOWER |
|---|---|---|---|---|---|---|
| good_1 | 2.885 | 1.416 | **1.070** | 1.072 | 1.232 / −0.20 | 1.127 / +0.02 |
| good_3 | 6.373 | 3.673 | 3.431 | 3.386 | 2.671 / −0.97 | **2.596** / +0.17 |
| good_5 | 9.386 | 6.162 | 5.949 | 5.856 | 4.155 / −1.74 | **3.996** / +0.35 |
| rejected_1 | 3.378 | — | — | 2.613 | 2.449 / +1.03 | **2.144** / +0.17 |
| rejected_5 | 11.684 | — | — | 8.699 | 8.794 / **+2.66** | **8.204** / −0.56 |
| offers_5 | 11.476 | — | — | **10.541** | 11.532 / −0.04 | 11.532 / −0.04 |

**Per-block good_5 MAE**

| block | R7 (strongest comparator) | r8 UPPER | r8 LOWER |
|---|---|---|---|
| 181008 | 5.939 | 4.105 | 3.995 |
| 181009 | 5.774 | 4.204 | 3.997 |

**Paired ΔG5 MAE (543 pairs)**

| predictor | UPPER | LOWER |
|---|---|---|
| r8 | 3.651 (sign agreement 0.776) | 3.783 (0.766) |
| zero predictor | 6.217 | 6.217 |
| R7 | 7.934 | 7.934 |

**10/90 band coverage (nominal 0.8), UPPER vs LOWER**

| target | UPPER | LOWER |
|---|---|---|
| good_1 | 0.791 | 0.819 |
| good_3 | 0.680 | 0.720 |
| good_5 | 0.595 | 0.656 |
| rejected_5 | 0.555 | 0.552 |
| offers_5 | 0.490 | 0.490 |

**Pre-declared criteria**

- **H9a (|LOWER rejected_5 bias| < 1.5): MET.**
  - Pooled −0.56, 181008 −0.60, 181009 −0.53.
  - The sign flips from UPPER (+2.66 / +2.71 / +2.61) in both blocks.
  - The same holds for the no-load-bin ablation (−0.58 vs +2.91). For no-pending, LOWER is −1.24 vs UPPER +1.84: also within 1.5, but more negative.
  - Reading: the R8 rejected over-prediction is mostly attributable to the release convention. This is a SENSITIVITY statement. It does not identify the true release time, which lies inside (L, U]: the truth lies between the two endpoint predictions at only 0.12–0.21 of origins for good_5/rejected.
- **H9b (r8 G5 MAE below the strongest comparator in both blocks under both endpoints): MET.** All four block × endpoint values (4.0–4.2) are below R7 (5.77–5.94).

**Retained negatives, under both endpoints**

- good_1 is still worse than R6/R7 (1.13–1.23 vs 1.07).
- offers_5 is worse than R7 (11.53 vs 10.54), so the common Poisson law remains the weak point of arrivals.
- rejected_5 MAE under UPPER is worse than R7 (8.79 vs 8.70).
- Band coverage is still well below 0.8 for G5 (0.60 / 0.66), offers_5 (0.49) and rejected_5 (0.55).
- 181008/181009 are now USED Train development.

**Not adopted.** No endpoint is adopted, and no averaging is done. LOWER scored better on G5 and rejection here, but by the pre-registered rule this does NOT make LOWER the model. Any future convention change must be pre-registered and tested on fresh Train.

No calibration, MPC, statistical guarantee or native permit is claimed.

---

## Round 10: eligible-set kernel-draw repair (pre-registered), plus a physical interference audit

### R10.0 Defect: cyclic survivor bias in v5 `kernel_draw`

This defect was confirmed independently by Sol and by Mayor.

- **Mechanism.**
  - For a pending ID of age a, v5 starts at `int(u·n)` and walks cyclically to the first record with client terminal > a.
  - Records are stored in episode/send order. Each eligible record is therefore drawn with probability proportional to 1 + (the length of the ineligible run before it), not 1/|eligible|.
  - Counterexample (now a test): records A (terminal 2), D (0.5), B (3) with age 1. u = 0.1/0.5/0.9 → A, B, B. Over a fine u grid: A 1/3, B 2/3. The conditional-uniform answer is 1/2 each.
- **Scope.** Only pending IDs (the only `min_alive` draws) are affected. Cohort and new-birth draws do not change.
- **Preserved.** The v5 and v6 sources, raw outputs and `kernel_draw` itself are unchanged and still byte-reproduce:
  - v6 `d3f6d3ec…`
  - v5-fixed `8e3f7dac…`
  - R5 `407a1b46…`, R6 `0056bf8d…`, R7 `f65efd69…`

### R10.1 Repair: `nv3-opus-admission-birth-v7-eligible-draw`

`kernel_draw_eligible`:

- **Back-off unchanged.** The level is chosen on its TOTAL record count (≥ HAZARD_MIN, or the coarsest non-empty level), exactly as in v5.
- **Eligible-uniform draw.** Within the chosen level, the eligible survivors (terminal > a + EPS, strict) are filtered first, then drawn as `eligible[int(u·|eligible|)]`.
- **Explicit unsupported case.** An empty eligible set raises `kernel_no_eligible_survivor`, with no fall-through to a coarser level. The origin is then excluded as `excluded|unidentified:…`, as before.
  - The v5 cyclic walk also raised on an empty eligible set, so both rules have the same unsupported origins.
- **Disclosed limit.** Choosing the level by total count can leave very few eligible records at that level for old pending IDs. This is kept deliberately; changing it would be a different model.
- **No survival condition.** With `min_alive=None` the repair equals v5 for every u (tested).
- **Selection.** The rule is chosen with `draw_rule` and defaults to `"v5_cyclic"`.

### R10.2 Pre-registration: `nv3-opus-eligible-draw-comparison-v7`

This is frozen before any Train 10/11 data is disclosed.

- **Command:** `python3 native_release_model.py --replica-eligible-draw <first-three-complete-train-blocks-frozen> <Mayor's sealed 10/11 dir>`
- **Fit:** 181001–181003 only.
- **Eval:** `R10_EVAL_BLOCKS = (181010, 181011)`. Both must be complete (5 cells × 2 arms) with randomized pair contrasts; otherwise the run refuses with `block_incomplete`.
- **Unchanged:** seeds, 32 scenarios, horizons 1/3/5 s, origin masks, targets, SLO labels, original whole-owner costs, comparators and penalties.
- **Runs:** four in total. For each release endpoint (upper and lower) there is one v6 (cyclic) run and one repaired run. No endpoint is chosen and nothing is averaged.
- **Gates (raise if violated):**
  - Identical origin sets.
  - Identical truths.
  - Bit-identical `r8_no_pending` and every non-R8 predictor, since only pending draws can differ.
- **Reported, per block and pooled, v6 vs repaired, for each endpoint:**
  - MAE and bias of good_1/3/5 and rejected_1/3/5 for r8 and r8_no_load_bin.
  - All band coverages.
  - Paired ΔG5 MAE.
  - Per-origin |repaired − v6| and the fraction of predictions changed.
- **Primary quantities:** G5 MAE, rejected-5 bias and coverage.
- **Declared reading.**
  - The repair is adopted on correctness grounds, whatever its score.
  - The v6 numbers stay beside it, and no tweak follows from the outcomes.
  - There is no a priori sign, because record order is time order and not duration order.
  - No chance guarantee and no native permit are claimed.
- **Gate-only smoke on the USED 181008/181009 data.** All gates passed, with 1112 origins for both rules. G5 predictions changed at only 0.4% (r8) and 0.6% (no-load-bin) of origins under upper; 0.5% and 0.9% under lower. Truth-based metrics were not inspected.
  - Expectation disclosed in advance: the repair is small on these state distributions because most pending ages are well below the survivor records.
- **Data binding.** A new source would be refused by `bind_source`. Any new binding would come in a separate, disclosed commit before scoring. Live replicas are not scored.

### R10.3 Physical interference audit of the frozen `simulate_plan` (Mayor's same-task request)

**Code facts**

- A live cohort owner's (release, good) is drawn ONCE at the cut from its R6 progress key. Nothing after the cut changes it.
- A birth's (duration, good) mark is drawn ONCE at admission. Its key includes the load bin, i.e. the Gateway-owned count when it is admitted. Later admissions never revisit an earlier mark.

**Executable fixed-CRN witness** (`--interference-witness`; output sha `9467b07d6f4b745571fd78c2de72a376f3e99558c1b204bc2d0f31cceca40a8c`; test `test_r10_fixed_crn_interference_witness`; same result under both draw rules)

- Setup:
  - One live owner L.
  - Birth A at 0.2 s.
  - Plan "open" admits 6 later fillers after 0.5 s; plan "shut" admits 0.
  - All uniforms are common to both plans.
- Results:
  - L stays at (release 2.0, good 1.5) under both plans.
  - A stays at (release 3.2, good 1.2) under both plans.
  - good_5 is identical under both plans.
  - Admitting 8 fillers BEFORE A moves A's load bin and its mark, to (4.2, 2.7).
- Therefore the frozen model contains exactly one batch pathway: load already owned at admission → that birth's service.
  - ∂(cohort service)/∂(future admissions) ≡ 0.
  - ∂(earlier birth's service)/∂(later admissions) ≡ 0.
  - This is a property of the code, not of the data.

**Is the fixed-mark assumption physically adequate?** I don't assume it is, or that it is invalid. Train 181001–181003 (already-used fit data), `--replica-post-admission-load`, output `opus-r10-post-admission-load-train1-3.json`, sha `ce3b9a98…64b9`:

- Within each v5 birth key (cell, payload, load bin at send), take admitted requests still unterminated at send + 0.5 s.
- Compare those whose number of further admissions in (send, send + 0.5] is above the key median with those at or below it, using remaining client duration.
- Results:
  - The "high" group is slower in **15/15 keys**. Pooled: +0.119 s (n = 11,037 vs 15,301).
  - Prefill-heavy cells: p4096-m128 +0.369 s, p4096-m256 +0.365 s.
  - Mixed cell: +0.15 to +0.36 s.
  - p128 cells: +0.02 to +0.10 s.
- This is OBSERVATIONAL. More later admissions co-vary with cap-32 phases and arrival bursts, and client durations include EOS length. It is not a causal interference estimate, and not GPU time. It shows structured residual of the kind the fixed-mark kernel cannot express, and it is largest exactly where prefill competition should be largest.

**Conclusion: factual prediction vs causal interference**

- **Factual random-policy prediction.** The fixed-mark kernel is not automatically invalid here. Its empirical marks were collected under the same random-schedule load paths, so they average the typical post-admission interference into the marks. This is consistent with the R8, 6/7 and R9 G5 results (3.996–4.42 vs ≥ 5.6).
- **Causal plan contrasts / MPC.** Here it IS structurally inadequate.
  - Under a plan that admits more later work than the training paths did, earlier owners keep their training-average service.
  - So model-implied const32 − const16 Goodput contrasts exclude the slowdown of earlier IDs, and are biased toward overstating the value of opening the budget, by an unidentified amount.
  - In the other direction, they overstate the benefit of shutting, because cohort service is not sped up.
  - The birth load bin covers only the at-admission part of this.
- **Gap status.** The structural gap is proved by the witness. Its physical magnitude is suggested, but not identified, by the Train residual.

### R10.4 Minimal observable batch-aware transition (specification only; not implemented or fitted)

This is a step transition at Δ = 0.5 s; native frame cadence is an alternative. Every live ID's progress is re-drawn at each step from the CURRENT batch, so later admissions can slow earlier IDs. There is no serial HTTP first-residence model and no GPU-time ownership.

**Per-ID observable state** (from receipts at or before the step start):

- Gateway owner (immutable cost).
- Native stage: not-visible / waiting / prefill / decode / finished-unreleased.
  - prefill: `computed_tokens < prompt_tokens`
  - decode: `output_tokens` known
- Client delivered-token count and first-token receipt (for SLO).

**Batch aggregates B(t):**

- n_running and n_waiting.
- Σ remaining prefill tokens of running IDs.
- n_decode.
- kv_cache_usage.

**Transition, conditioned on (own stage, B(t)):**

- **(i)** Prefill progress ∆computed ~ P(· | remaining prefill, B).
- **(ii)** Decode tokens per step ~ P(· | B), with a per-token EOS hazard taken from Train output-length survival, given `output_tokens` so far and censored at `max_tokens`.
- **(iii)** Waiting→running hazard given (n_running, kv).
- **(iv)** Not-visible→waiting dwell kernel for the 17–23% accepted-not-native-visible stage. This is latent. It is NOT zeroed, and it is conditioned only on the Gateway mark age.
- **(v)** Native finish → Gateway release via an interval-censored lag kernel. Both endpoints are kept, as in R9.
- **(vi)** Native-to-client delivery lag. This mapping is kept explicit and is not interchangeable with native EOS: the R1 last-token tail-overhang fact applies.

**Rules:**

- Births enter not-visible/waiting only through the unchanged exact admission ledger, so the cap acts only via admission → B(t).
- The arrival law stays common and exogenous.

**Identification:**

- Random cap schedules move B(t) independently of each ID's own payload.
- Step-level fits use Train blocks grouped by block.
- Partial visibility is a real censoring; no stage or EOS clocks are manufactured.

**Falsification tests:**

- **(a)** The fixed-CRN witness must FLIP: later admissions must change earlier IDs' progress.
- **(b)** The Train post-admission residual above must shrink toward 0 once conditioned on the realized B(t) path. Otherwise B(t) is not the right state.
- **(c)** Factual G5 MAE must not be worse than v7 on the same fresh blocks.
- **(d)** Only after (a)–(c) may plan contrasts be read, and even then as model-implied, not measured.

### R10 retained disagreements (added)

29. A fixed-mark kernel can win factual random-policy MAE and still be causally inadequate for plan contrasts. Factual MAE wins (R8, R9) are not evidence for MPC plan ranking.
30. The H9a release-convention reading is a sensitivity statement only. The LOWER endpoint is not adopted, even though it scored better.
31. The repaired draw changes so few predictions that its scored effect on 10/11 is expected to be small. A null result would not vindicate v5's draw: correctness is decided by the conditional-uniform test, not by score.

### R10 receipt (pre-registration seal)

- **Source** `native_release_model.py`: sha256 `e2709d96e623497bd831e1c1afdd042b560d3ea6d9ebc58269586d8e5c89b838`.
- **Tests** `test_native_release_model.py`: sha256 `086b9ee417d18b27b7f524f5a5c40295fd8c5c46f4d21ffbc2d0e29759fbbce6`. 56 passed, 0 skipped.
- **Frozen outputs re-verified byte-identical after the change:**
  - v6 R9 `d3f6d3ec…40a0a5`
  - v5-fixed `8e3f7dac…896f`
  - R5 `407a1b46…c123`, R6 `0056bf8d…b511`, R7 `f65efd69…5f64`
- **R9 result:** `opus-r9-release-sensitivity-181008-9.json` sha256 `d3f6d3ec5a49abd7b16b639d47cc29ca6739812fcbcf545d9b6fe72ff040a0a5`, committed in d53157f.
- **Not run:** 181010/181011 (or any 12/13/Final), pending Mayor's sealed subset.

## Round 11: batch-aware evolving per-ID transition (`nv3-opus-batch-progress-v8`)

Independent shared-core candidate. No peer R11 conclusions were read. Source and tests were frozen at d15a4f1 **before** any development run. Fit uses Train 181001–181003 only. Development uses USED Train 181004–181009 only. Blocks 10/11/12/13, Calibration, Validation and Final were not opened.

### R11.1 Model (stock-flow)

**State at grid cut t_j = t0 + j·0.5 s.** Each ID i has phase φ_i, a TTFT flag τ_i ∈ {ok, dead, open, end} and its immutable payload class c_i.

Phases:
- **Owned, cost-holding:** H, P, D1–D4, T, Q.
  - H: owned but not native-running. Native waiting, not-yet-visible and finished-but-unreleased are lumped, because waiting has no IDs.
  - P: native running with output 0.
  - D1–D4: native output bin (OUTPUT_EDGES 1/16/64/128).
  - T: client terminal seen, cost still held.
  - Q: admitted but not yet seen in any grid snapshot.
- **Released, cost-free:** Z, released from the Gateway before the client terminal.

**Batch state** B_j = (⌊n_run/8⌋ capped at 4, bin(Σ_{H,P,Q} prompt_k; edges 1/4/8/16 k-tokens)). It is recomputed every step from the **current simulated population**. This is the only pathway by which later admissions affect earlier IDs: births enter H/P/Q/D, change B_{j+1}, and B_{j+1} indexes every member's next transition. The pathway never uses serial HTTP residence time.

**Transition.** (φ', τ', good) ~ Ê[· | cell, c, φ, τ, B], an empirical record set from consecutive Train cuts. It backs off to (cell, c, φ, τ) and then to (φ, τ) when a level has fewer than 20 records (HAZARD_MIN). GONE means a client terminal fell in the step; good is that terminal's existing SLO label. EOS and length uncertainty enter **only** through these empirical phase-survival records; no EOS clock is used.

**Births.** An offer a ∈ (t_j, t_{j+1}] is admitted iff R_j + Σ(earlier admissions in step) + c ≤ u_j. Here R_j is the cost of the cost-holding phases at t_j. The admitted ID draws an entry record keyed by (cell, c, half-step offset, B_j).

**Arrivals.** Arrivals are v5/v7's `draw_common_law` (pre-cut all-offered law and mix), common to every plan. Per-ID step uniforms come from a separate seed `nv3-opus-r11-transition` keyed by (origin, scenario), so v5/v7 streams are untouched.

**Plan dependence.** The plan enters only through the admission inequality.

**Start state** (receipts ≤ t0 only):
- Live Gateway owners take their observable phase.
- Pending sent-not-owned IDs seen owned at an earlier grid cut become Z.
- Never-seen pending IDs are re-offered through the ledger (Q if admitted). They are never added to the stock unconditionally.

**Declared approximations:**
- Release is grid-censored at step ends, and the stock used for admission is the step-start stock.
- Native output > 0 is a proxy for the client first token.
- H lumping.
- Q / unseen classification uses admitted labels in **Train records only**.
- `computed_tokens` is not used. Prefill work is prompt-tokens of H/P/Q, a known coarse proxy.
- Costs are whole and immutable per (cell, class).

**Complexity:** O(steps × population) per scenario. The Train walk is incremental; there is no O(n²) scan.

### R11.2 Fixed-CRN witness (`--r11-interference-witness`)

Synthetic tables, same arrivals and uniforms. Live D1 owner L; plan "open" (32) admits 9 births in step 0, plan "shut" (1) admits none.

| Model | L path, open | L path, shut |
|---|---|---|
| B-aware | `[D2]×10` | `[D2, GONE]` |
| B-blind | `[D2, GONE]` | `[D2, GONE]` |

So future admissions change an earlier cohort's service **only** through B under the aware model; the blind ablation is invariant. This is a structural property of `r11_simulate`, not native evidence.

### R11.3 Development results (fit 1–3; same v7 eligible-draw, upper-endpoint origin mask)

Every v7 origin was supported: 1108 / 1111 / 1112 origins for 4/5, 6/7, 8/9, and 0 R11 exclusions.

**G5 full MAE** (primary):

| Block | r11 aware | r11 blind | v7 r8 | R7 | R6 | aggregate | history |
|---|---|---|---|---|---|---|---|
| 181004 | 7.19 | 7.85 | **4.06** | 5.67 | 5.64 | 5.78 | 8.76 |
| 181005 | 7.23 | 7.95 | **4.09** | 6.20 | 6.28 | 6.46 | 9.56 |
| 181006 | 7.07 | 7.76 | **4.42** | 5.97 | 5.92 | 6.07 | 8.80 |
| 181007 | 7.88 | 8.54 | **4.23** | 5.65 | 5.71 | 5.95 | 8.58 |
| 181008 | 7.67 | 8.33 | **4.11** | 5.94 | 6.12 | 6.40 | 9.21 |
| 181009 | 7.70 | 8.38 | **4.20** | 5.77 | 5.78 | 5.93 | 9.56 |

**Bias, coverage and pairs:**
- **r11 G5 bias:** −5.9 to −6.7. v7: −1.2 to −2.0.
- **r11 rejected_5 bias:** +8.8 to +9.6. v7: +2.4 to +3.1.
- **G5 band coverage (nominal 0.8):** 0.51–0.54. rejected_5 coverage: 0.42–0.49.
- **Offers** are identical to v7 in every block (same common law): a check that arrivals are plan- and model-free.
- **Paired G5 MAE:** r11 3.76–4.92 vs v7 3.49–4.65 vs zero 5.83–6.83. r11 beats v7 only in 181006.

**One-step held log loss** (per-ID next state; Jeffreys 0.5 pseudocount; 0.97 of records keyed at the batch level):

| Record type | aware − blind |
|---|---|
| trans | −0.054 to −0.064 nats (every block) |
| entry | −0.012 to +0.006 (null) |

**Reading:**
1. The batch state carries real, replicated one-step information about the evolution of **existing** IDs. In free-running mode, aware beats blind by about 0.66–0.72 G5 MAE in all 6 blocks. This supports the R10.4 claim that population and phase matter for already-live service.
2. As a forecaster v8 is **decisively negative**: G5 is about 75–85% worse than v7 and worse than every strong comparator except history.
3. Start stock is not the cause. On 181008 at k%4 cuts, the simulated start cost minus the actual Gateway reserved has median 0.0 and mean +1.04.
4. The error accumulates dynamically: rejections are over-predicted and goods under-predicted. The leading hypothesis is the declared grid-censored release combined with step-start admission stock: a whole step of releases is withheld from every admission test. This is a hypothesis; it was **not** tested, and nothing was tuned after these scores.
5. Entry batch keys add nothing, so births' first-step state is not identified as batch-dependent at this resolution.

### R11.4 Pre-registration for Train 181012/181013 (sealed before disclosure)

- **Unchanged:** source d15a4f1 / sha `aa927973…12c7`, the CLI `--replica-batch-progress TRAIN1-3 DIR12_13 181012,181013`, and every frozen constant reported in `frozen`. Fit on 181001–181003 only.
- **Comparators:** v7 r8 (eligible draw, upper endpoint), v7 no-load-bin, R7, R6, aggregate hybrid, history.
- **Mask:** the v7 mask, minus R11-unsupported origins dropped from **all** predictors.

Hypotheses:
- **H11a (one-step batch information):** trans aware−blind log loss < 0 in **both** blocks.
- **H11b (free-running batch pathway):** aware G5 MAE < blind G5 MAE in both blocks.
- **H11c (practical forecaster):** aware G5 MAE ≤ 0.95 × v7 G5 MAE in both blocks, and |rejected_5 bias| no worse than v7 + 0.5.
  - The development data already predicts H11c **fails**. It is retained, not removed.

**Stop rule:**
- If H11c fails, v8 is not a forecasting or MPC candidate and no v8 constant is tuned.
- A fresh version (e.g. within-step release ordering) would need its own pre-registration and new blocks.
- H11a/H11b are allowed to pass while H11c fails. That would mean "B is real state; this ledger discretization is inadequate", **not** that MPC is supported.

**Excluded:** both release conventions are not run for v8, because its release is grid-step, not interval endpoints. There is no paired-contrast or plan-ranking claim.

### R11 retained disagreements (added)

32. Batch state can be informative (one-step, aware vs blind) while the full-ledger forecaster is much worse than a fixed-mark kernel. Mechanism fidelity and factual accuracy are separate gates; neither alone licenses causal plan contrasts.
33. v7's factual advantage does not rescue its fixed-mark causal inadequacy (R10). v8's causal pathway does not rescue its factual bias. Neither is a native-permit or MPC model.

### R11 receipt

- **Source freeze:** commit d15a4f1.
  - `native_release_model.py` sha256 `aa927973f4cf6a6ba96a10c09bb77eb9fdef63dda80ad70b78c87b768dab12c7`.
  - `test_native_release_model.py` sha256 `a0653d5495d614f4ce46b726081340b10e7fbc04d5d47275035bb917954d64aa`.
  - 61 passed, 0 skipped.
  - The diff from 62512df is additive only (+548/−0).
  - The R10 witness re-hashes to `9467b07d…a8c`.
- **Development outputs** (PYTHONHASHSEED=7, session files):
  - `opus-r11-batch-progress-181004-5.json` `ef5eea69b1f66aba35f0cd3496f12333c29f4b02630b65de630fbe7ca6bd2303`
  - `opus-r11-batch-progress-181006-7.json` `5b3bf9235744cbcc48cd4009a2cf9f13c2b161df8fb09bc7a5c509dfa1026fc7`
  - `opus-r11-batch-progress-181008-9.json` `f6cb114db4c02958705aef99b7a320e626b72939e099d54f601b05d390921be4`
- **Pending:** the R10 v6-vs-v7 comparison on 10/11 and the R11 run on 12/13, both awaiting Mayor's sealed subsets.

## Round 10 results: frozen eligible-draw comparison on fresh Train 181010/181011

**Run binding:**
- Executed EXACTLY the archived R10 source `pr33-native-v3-round10-frozen/opus/native_release_model.py` (sha256 `e2709d96…b838`, commit 62512df), copied to a temporary directory. The R11 working source was not used.
- Data: `pr33-native-v3-recovery-train-ten-eleven-frozen`. All 40 artifacts verified against `verified-artifact-sha256.jsonl` with 0 mismatches. `index.json` sha `616f7ab9…4c6`; `subset_scope` binds prereg 62512df.
- Collector/native source 729b144a, the same as 8/9.
- Command: `PYTHONHASHSEED=7 python3 -B native_release_model.py --replica-eligible-draw <Train1-3> <Train10-11>`.

**Output:** `opus-r10-eligible-draw-181010-11.json`, sha256 `4c26cfb4334e2cbd715ca2568376a5c8c80b100861e19f35c2baec767716b433`. A rerun under PYTHONHASHSEED=3 is byte-identical.

**Gates:** all passed (exit 0). All four runs (upper/lower × v6 cyclic / v7 eligible) have the same 1109 origins and the same truths, and r8_no_pending plus every non-R8 predictor is bit-identical.

**Draw effect:** the repaired draw changed G5 predictions at 0.38% of origins (upper), mean |Δ| 0.0006.

| Endpoint | Block | G5 MAE v6 → v7 | G5 bias v6 → v7 | rejected_5 bias v6 → v7 | G5 coverage | paired G5 MAE v6 → v7 |
|---|---|---|---|---|---|---|
| upper | 181010 | 4.1546 → 4.1546 | −2.035 → −2.035 | +2.647 → +2.647 | 0.615 | 3.6215 → 3.6214 |
| upper | 181011 | 4.2264 → 4.2252 | −2.040 → −2.042 | +3.008 → +3.009 | 0.587 | 3.9429 → 3.9440 |
| lower | 181010 | 3.6606 → 3.6607 | −0.005 → −0.005 | −0.449 → −0.449 | 0.665 | 3.4980 → 3.4979 |
| lower | 181011 | 3.9968 → 3.9939 | +0.089 → +0.087 | −0.206 → −0.205 | 0.643 | 3.9106 → 3.9068 |

**Reading (pre-registered expectation 31 held):**
- The score difference is negligible and mixed in sign. The repair is **adopted on correctness** (the conditional-uniform test), not on score.
- Both release endpoints are retained. No endpoint is chosen after the scores, even though lower again scores better.
- Negatives retained:
  - Coverage is well below the nominal 0.8 (G5 0.59–0.67; rejected_5 0.50–0.54).
  - Upper-endpoint rejected_5 bias is +2.6 to +3.0.
- 181010/181011 are now USED development. R11 (v8) was NOT run on them and remains fit 1–3 / development 4–9, with 12/13 pre-registered and withheld.

## Round 12: adversarial review of R11 peers, falsifying stock-flow witnesses, and a within-step release candidate (`nv3-opus-within-step-release-v9`)

Scope:
- Train 1–3 fit and USED development 4–9 only.
- 10/11 are not used here; 12/13, Calibration, Validation and Final are unexposed.
- No GPU, SSH, push or `gt done`. Earlier source, raw outputs and negatives are unchanged; H11c's development negative stands.

### R12.1 Adversarial review of the peer R11 proposals (frozen `round11-frozen`)

The distinction I apply throughout:
- A **conditional reported-counter** improvement predicts a native counter (computed/output tokens) for IDs that remain visible.
- A **complete joint/control** forecast predicts, for every offered request under a candidate plan, admission/rejection, the whole-cost ledger and natural good/SLO outcomes over 1/3/5 s.

None of the three peers produces the second. Each improvement below is a conditional-counter result.

**Astra.**
1. **The equal-share fluid dp/dt = −C/N is falsified by Astra's own table.** Aggregate decode throughput rises from about 98 positions/s at N=1 to about 1648 at N=18, roughly 92 per ID at any N. Per-ID decode rate is therefore nearly N-invariant in this regime, which contradicts a 1/N processor-sharing law.
   - The fit has 3739 decode pairs and 0 prefill pairs (median C_D ≈ 300).
   - It loses to last-rate decisively: one-pair MAE 12.96 vs 0.48.
   - The 3/5 s windows have no data.
2. **R11b is a reported-output stayer ridge selected on a future-dependent condition.** The ID must still be visible at t+h.
   - Retention is 33% at 0.5 s, 13% at 1 s, 1 row at 3 s and 0 at 5 s; no p128/m128 rows survive.
   - Its 0.5 s gain (7.7 vs past-rate 14.4) is conditional on survival. It is not usable online at the origin, and it is not G5, rejection or cost.
   - The past-rate baseline may be weakened when its history window straddles prefill or the first token. This is unverified, so I do not claim it.
3. **Causal and deployment.** No cap pathway, no admission ledger and no all-offered target, so it is not a control model.

**Gemini.**
1. **Horizon change after results.** The §31.4 table shows h=3/5 batch MAE of 67/116 against history 24. §32 then moves to 0.15/0.25/0.5 s horizons. Whatever the intent, the shorter horizons were chosen after the long ones were seen to fail, and that must be disclosed as such.
2. **Fitted coefficients.** γ_d = −0.011 has a nonphysical sign and is essentially 0. γ_p = 6.99 says prefill dominates.
3. **Baselines.** At 0.5 s the batch model (11.28) loses to a leaked constant-mean oracle (10.83). The "causal past history mean" (Train mean × dt) is a weak comparator; there is no per-ID past-rate comparison.
4. **Censoring.** Survivor and right-censoring selection is not modelled.
5. **The mock 66 vs 8 tokens is a factory-defined response, not evidence.** The original §31.5 pre-registration (G/T, 8 families, Holm) did not match the 12/13 cells and was later split. The split must be bound to a commit before exposure.

**Sol.**
1. **The D_k ∝ (2·n_prefill + n_decode) denominator is also a processor-sharing law.** Astra's N-invariance counts against its decode term at this load. The prefill weight 2 is a hypothesis, not a fit.
2. **Support.** The closed-mask fit scope (p4096/m128 arm0) has 0 eligible intervals.
3. **Availability.** The follow-up conditional-mean table compares 41.9% of rows at 1 s, 58 rows at 3 s and 0 at 5 s. Sol states this honestly, and Sol's own 80% availability gate fails. The 1 s gain (9.85 vs past-rate 21.17) is a conditional-counter result.

**Synthesis.**
- On this hardware and load, the peers' data support **prefill-driven step inflation** (chunked prefill competes with decode) rather than decode-count sharing. This is consistent with my v8 prefill-work bin carrying the one-step information (−0.054 to −0.064 nats).
- No peer model can yet be compared on full G5 / all offers / rejections / cost. My v8 is the only full-ledger batch candidate, and it is factually much worse than v7 (R11.3).
- The remaining R12 question is therefore mine: **why** v8 is biased (G5 −6, rejected_5 +9).

### R12.2 Falsifying witnesses for "grid-step release + step-start stock" (`nv3-opus-stock-flow-witness-r12`)

**Run:**
- Command: `--replica-stock-flow TRAIN1-3 DEV 181004,181005` (similarly 6/7 and 8/9), PYTHONHASHSEED=7.
- Origins: the same as the v8 development run (v7 eligible-draw upper mask): 1108 / 1111 / 1112.
- `r11_simulate` gained an optional `ledger=` recorder. With `ledger=None` the frozen v8 output still hashes `f6cb114d…1be4` (8/9).

**F2: factual-tape admission replay** (an ORACLE label diagnostic, never a forecast).
- Every ACTUAL offer in grid step (t_k, t_k+0.5] is classified against that step's planned budget, using actual admissions and snapshot-bounded release intervals (`release_intervals`) under both endpoints.
- Two rules:
  - **grid** = v8 rule: R(t_k) + earlier in-step admissions.
  - **event** = R(a−): releases at or before a are applied first.
- Predicted minus actual rejections are summed over 5 s. Actual is about 21–22 rejections of 57–59 offers.

| Block | grid upper | grid lower | event upper | event lower |
|---|---|---|---|---|
| 181004 | +18.53 | +13.01 | +9.85 | −3.53 |
| 181005 | +18.11 | +12.85 | +9.66 | −4.11 |
| 181006 | +18.70 | +13.33 | +10.03 | −3.98 |
| 181007 | +18.42 | +12.80 | +9.52 | −4.20 |
| 181008 | +19.07 | +13.55 | +10.24 | −4.35 |
| 181009 | +17.97 | +12.73 | +9.16 | −3.96 |

**F1: v8 free-running vs factual per grid step** (scenario mean − actual; states differ after step 0).
- Simulated reserved stock is about +1 at step 0, then **−1.3 to −3.1 below** the actual Gateway stock at steps 1–9.
- Yet simulated rejections exceed actual by +1.7 to +2.1 at step 0 and +0.45 to +1.1 at each later step, roughly +9 over 5 s, and simulated admissions fall short correspondingly.

**Reading:**
1. **Supported, and the mechanism is the admission rule, not transition/release drift.** v8 over-rejects while holding *less* stock than reality. On the factual tape, the step-start rule alone over-rejects by +13 to +19 against the actual Gateway decisions in every block, under either endpoint.
2. **Event ordering is necessary but not identified.** Event-ordered stock brackets the actual count (lower −3.5 to −4.4, upper +9.2 to +10.2). The true within-interval release time (snapshot gap about 0.11–0.15 s) moves 5 s rejections by about 14, two-thirds of the actual count.
   - Any model of this ledger must therefore carry release-time **sensitivity**. It must not assert one physical time.
3. **Limits:**
   - The admission time used is client `sent`. Gateway `admitted_at` exists only for snapshot-visible IDs, and the CAS delay is about 0.02–0.04 s.
   - 22–31 admitted IDs per block pair have no later snapshot. Their release is unidentified and they are kept in the stock.
   - Step `gateway.reserved` is the last snapshot at or before t_k (0.05–0.11 s stale), so reconstructed and snapshot stock differ at most cuts. That is staleness plus sent-before-owned, not a ledger contradiction.
   - Rejected rows carry their actual `max_admitted_cost`. It differs from the step's planned budget on only 0.50–0.81 of the about 21 rejections per origin window: the ACK/CAS boundary.

### R12.3 Candidate `nv3-opus-within-step-release-v9` (specification frozen BEFORE any development run)

The v8 model is unchanged except for **one** ledger change:

- **Member transitions.** At step j, every member's next record is drawn from the step-start batch B_j using the SAME CRN uniform as v8. Transitions given the population are therefore bit-identical to v8.
- **Release time.** A cost-holding member whose record leaves the cost-held set releases its whole cost at j·0.5 + δ.
  - δ is drawn by a separate plan-free CRN stream (`nv3-opus-r12-release-offset`) from a Train 1–3 empirical pool.
  - The pool contains start-of-step owners (present in the last snapshot at or before t_j and absent from the last snapshot at or before t_{j+1}), with offset = interval endpoint − t_j clipped to [0, 0.5].
  - Pool back-off: (cell, class) → cell → all, with n ≥ HAZARD_MIN = 20 at each level. If no level qualifies, the origin is explicitly unsupported.
- **Offers.** An offer at a is admitted iff R(a) + c ≤ u_j, where R(a) = holders + members not yet released (δ > a) + births admitted so far. A release exactly at a applies first.
- **Births** hold cost for their whole birth step. This is conservative and they are never released early.
- **What is not changed:** no HTTP residence and no serial GPU time; whole original cost; no eviction on a budget decrease; the arrival law and seeds are common and exogenous; the plan enters only through admission.
- **Both endpoints** are separate predictors (`v9_within_step_upper`, `v9_within_step_lower`). They are never averaged, and neither is selected after scores.
- **Witness tests:**
  - an offset at the step end reproduces v8 exactly (outputs and traces);
  - a release before the offer admits it, while one after the offer does not;
  - the budget is never exceeded;
  - the step-start rule never yields less stock than the event rule on actual Train.

**Frozen development run** (fit 1–3; 4/5, 6/7, 8/9 USED development):
- Command: `--replica-within-step-release TRAIN1-3 DEV <blocks>`, PYTHONHASHSEED=7.
- Unchanged: horizons 1/3/5 s, 32 scenarios, 10–90 band, the common law draw, the v7 upper origin mask (minus explicitly counted unsupported), the targets G/R/O and the paired G5.
- Comparators on the same mask: v8 aware and blind, v7 upper (`r8_admission_birth`), v7 lower (`r8_admission_birth_lower`), v7 no-load-bin, R7, R6, aggregate hybrid, history.

**Expectation before running** (recorded, not tuned):
- v9 rejected_5 bias falls well below v8's +9 under both endpoints, with lower < upper.
- G5 improves on v8.
- Whether it reaches v7 is genuinely uncertain, because v8's transition kernel also differs from v7's fixed marks.
- If v9 does not reduce v8's rejection bias, the F2 mechanism does not transfer to the simulator, and that is reported as a negative.

### R12.4 Pre-registration for the next sealed Train pair (before exposure)

- **Blocks:** 181012/181013 **only if** Mayor confirms they were unexposed when this source commit was archived. Otherwise the first complete Train pair sealed after it. `R12_EVAL_BLOCKS` records (181012, 181013) under that condition.
- **Command:** `--replica-within-step-release TRAIN1-3 DIR BLOCKS` from this commit unchanged. The R11.4 v8 run is unaffected and is reproduced inside this output: same keys, same code path.
- **Hypotheses**, evaluated per endpoint e ∈ {upper, lower} and reported separately:
  - **H12a (ledger repair):** |rejected_5 bias| of v9_e < that of v8 aware, in both blocks.
  - **H12b:** G5 MAE of v9_e < that of v8 aware, in both blocks.
  - **H12c (practical):** G5 MAE of v9_e ≤ 0.95 × v7_e (same endpoint), in both blocks.
- **Stop rule:**
  - If H12c fails for both endpoints, v9 is not a forecasting or MPC candidate and nothing is tuned.
  - If it passes for exactly one endpoint, the result is "unidentified within the release interval", not a pass.
  - Coverage is reported without claim.
  - H11c remains negative regardless.
- **Excluded:** paired plan-ranking or causal-effect claims, a native permit, MPC wins, and Calibration/Validation/Final data.

### R12.5 v9 development results (source frozen at 4232166 BEFORE running; fit 1–3; USED 4–9)

**Mask:** every v7 origin was supported (1108 / 1111 / 1112), with 0 v9 exclusions and 0 missing v7-lower keys. Offers are identical across all ledger predictors (common law).

**Results** (G5 MAE / G5 bias; rejected_5 bias):

| Block | v9 upper | v9 lower | v8 aware | v7 upper | v7 lower |
|---|---|---|---|---|---|
| 181004 | 4.183 / −1.36; +3.02 | 3.911 / +0.09; +1.31 | 7.192 / −5.89; +9.63 | 4.057 / −1.16; +3.08 | 4.117 / +1.02; −0.25 |
| 181005 | 4.244 / −1.60; +2.81 | 3.894 / −0.23; +1.16 | 7.234 / −6.15; +9.41 | 4.093 / −1.36; +2.94 | 4.123 / +0.70; −0.28 |
| 181006 | 4.470 / −1.65; +2.41 | 4.402 / −0.26; +0.74 | 7.068 / −6.03; +8.82 | 4.423 / −1.38; +2.38 | 4.628 / +0.63; −0.74 |
| 181007 | 4.410 / −2.25; +3.03 | 3.792 / −0.87; +1.36 | 7.878 / −6.74; +9.54 | 4.226 / −1.96; +3.03 | 3.773 / +0.09; −0.12 |
| 181008 | 4.239 / −2.01; +2.70 | 3.844 / −0.56; +0.99 | 7.671 / −6.56; +9.31 | 4.105 / −1.69; +2.71 | 3.995 / +0.46; −0.60 |
| 181009 | 4.336 / −2.05; +2.58 | 3.845 / −0.68; +0.93 | 7.701 / −6.51; +9.04 | 4.204 / −1.78; +2.61 | 3.998 / +0.24; −0.53 |

**Other targets:**
- **Paired G5 MAE:** v9 upper 3.54–4.74 and v9 lower 3.51–4.62, vs v7 upper 3.49–4.65, v8 3.76–4.92 and zero 5.83–6.83.
- **G5 band coverage (nominal 0.8):** v9 upper 0.62–0.67, lower 0.65–0.72, v8 0.51–0.54. rejected_5 coverage 0.52–0.59.
- **G1 MAE:** v9 1.05–1.28 vs v7 0.99–1.23.
- **v8 numbers inside these outputs equal the frozen R11.3 values**, confirming the shared code path.

**Reading:**
1. **The F2 mechanism transfers to the simulator.**
   - With transitions bit-identical given the population, event-ordered release alone cuts v8's G5 MAE by 41–52% and its rejected_5 bias from +8.8–9.6 to +0.7–3.0. That would satisfy the H12a/H12b direction on development.
   - v8's R11 negative was therefore largely a **ledger discretization artifact**, not evidence against the batch-aware transition.
2. **Parity, not superiority, with fixed marks.** v9 upper is worse than v7 upper in all 6 blocks (by 1–4%). v9 lower beats v7 lower in 5 of 6 blocks (not 181007), but by less than the 5% H12c margin in 4 of the 5. On development, H12c is expected to **fail** for both endpoints.
   - This is a batch-aware causal transition that forecasts about as well as the fixed-mark kernel. It is not a better forecaster.
3. **Endpoint sensitivity is material and unresolved.** Lower vs upper moves G5 by 0.07–0.62 and rejected_5 bias by about 1.7. The release time inside (L, U] is unidentified at snapshot resolution, and neither endpoint is chosen.
   - Lower scores better here, as it did for v7 in R10. That is a score, not identification.
4. **Remaining negatives:**
   - Bands under-cover badly.
   - The births-hold-whole-step convention and client-`sent` admission timing are unvalidated.
   - The v9 entry records are still batch-uninformative (R11.3 point 5).
   - Nothing here is a causal plan-contrast, a native permit or an MPC result.
   - H11c stays negative for v8.

### R12 retained disagreements (added)

34. A full-ledger model's factual error can be dominated by ledger time discretization rather than by its service/transition law. Evaluate mechanism changes with the ledger fixed and vice versa; R11's "v8 decisively negative" referred to v8's ledger + kernel jointly.
35. The peers' conditional reported-counter gains (Astra R11b, Gemini §32, Sol) are not comparable with full G5/rejection forecasts. Processor-sharing denominators (Astra 1/N, Sol D_k) are contradicted by per-ID decode-rate N-invariance in Astra's own table. Prefill-driven inflation is the better-supported interference channel at this load.
36. Release time within the snapshot interval is a first-order unknown for any admission ledger. It is about 14 rejections per 5 s on the factual tape. A higher-rate Gateway owner log, or explicit release receipts, is a measurement requirement, not a modelling choice.

### R12 receipt

- **Peer sources reviewed (read-only):** `pr33-native-v3-round11-frozen/{astra,gemini,sol}`, archive `dcb06813…f189daf148`.
- **Source and spec freeze, before the v9 development run:** commit 4232166.
  - `native_release_model.py` `ba9963e534de98eaee7402b6efdf99e4d1fe2f1f22562c07bd1900ca6a65b36f`
  - `test_native_release_model.py` `775e62affec5d5c818c19e83591cc2a85c5ee2b6721a16af957caa775b0076cc`
  - Tests: 64 passed, 0 skipped (`python3 test_native_release_model.py`).
  - Additive over aca391e, plus optional `ledger=`/`extension=` hooks that are inert at their defaults.
- **Hash checks with hooks inert:**
  - Frozen v8 output `--replica-batch-progress` on 8/9 re-hashes to `f6cb114d…1be4`.
  - R10 witness `9467b07d…a8c`.
  - R11 witness `c827bb68…bcb`, the same as aca391e.
- **Witness outputs** (PYTHONHASHSEED=7; session files `c45ddf1e…/files/`):
  - `opus-r12-stock-flow-181004-5.json` `244793b6a48c1b3f8b801e2ff644d59118ad2bdead43285903be1ef6eb5d0d77`
  - `opus-r12-stock-flow-181006-7.json` `885472fd10b889dd4eed820b5c2818e37495b68e89d88346bc3ce949b60dac27`
  - `opus-r12-stock-flow-181008-9.json` `2a29a049a533b2ade00497b5bd6ca7a46649e8cc3f3e9ec4327a22a58d4022de`
- **v9 development outputs:**
  - `opus-r12-within-step-181004-5.json` `3ccf64f972b8669d7a75bbd2341e3ee0fa6b3a149fa22f5781c5db640d43b217`
  - `opus-r12-within-step-181006-7.json` `665abff800aeeccdbfa8bd26c1fdda08b08dd9b267144a558f8a2dc4ea82fd26`
  - `opus-r12-within-step-181008-9.json` `804edf3341bd8a0885bd1b93780a1b8de541110e54d1349f1eef1120ab65def0`
- **Pending, awaiting Mayor's sealed subset:**
  - The R11.4 v8 run and the R12.4 v9 run on the next sealed pair: 12/13 only if unexposed when 4232166 was archived.
  - Calibration, Validation and Final remain unused.

## R13 — stable per-birth CRN repair (bead pr-native-v3.1)

Scope: correctness repair of the Monte Carlo pairing only. v8 (d15a4f1) and v9 (4232166) source, raw outputs, gates and negatives are preserved unchanged. Sources read: the sealed R12 peers in `pr33-native-v3-round12-frozen/{astra,gemini,sol}`. No 12/13/Calibration/Validation/Final, Pod, GPU, SSH or fresh data.

### R13.1 Adversarial review of sealed R12 peers

**Astra (R12)**
- **Supported.**
  - Exact replay of frozen v8.
  - The parent-release-first rejection witness: 8896 vs 16687 originally on 181006, and 9292 vs 16788 on 181007. This is the same F2 direction as my R12 stock-flow witness.
  - The non-monotone heterogeneous-cost witness (181007 mixed arm1, k=164).
  - The CRN birth-index shift. I reproduced it independently (R13.2).
- **Limits.**
  - The parent-release-first count is a local one-step ledger count. It is not propagated through a free-running simulator, and it is not a G5 forecast.
  - The R11b stayer-represented original cost is 19.9% at 0.5 s, 8.7% at 1 s and about 0 at 3/5 s. Conditional reported-counter gains therefore say almost nothing about the 5 s whole-cost ledger.
- **Accepted critiques of Opus:**
  - The v8/v9 H-phase lumps prefill progress.
  - Old joins lack computed_tokens.
  - A same-step arrival does not change that step's batch key. This is a documented step-start convention, not a measured fact.
- **Also accepted:** Gemini's fit returns precomputed constants when its data directory is absent. That is a fixture fallback, not a fit.

**Gemini (§34–35)**
- **Stale or incorrect critique of Opus.**
  - It cites R5's 9.84/8.76 as current.
  - It calls v8 a "scalar aggregate", but v8 carries per-ID phases with a batch-keyed kernel.
  - It says Opus lacks an orthogonalised arrival design, but R5 onward use a common exogenous plan-free law (`draw_common_law`).
- **Not hardware evidence.** The RealNativeCohortRunner 66-vs-8-token (−58) contrast is CPU mock/fixture data.
- **Correct cost arithmetic.**
  - Anchor cost 1.6893573248; burst 4.0304346624.
  - 9 anchors = 15.2042. 9 anchors + 4 = 31.326 ≤ 32. 9 anchors + 1 = 19.23 > 16.
  - This is a valid feasibility witness for the hard 16/32 whole-cost budgets. It is not a service law.
- **Horizon changed after results.** The earlier adaptive horizon choice remains disqualifying for any confirmatory claim.

**Sol (R12)**
- **Correct executable counterexample.** Grid snapshot records cannot identify release order inside the interval: early release gives 0 rejections, late release gives 1. A joint within-step ordering law fit to source-stamped release brackets is required, and taking early endpoints would be optimistic.
  - v9 already reports both endpoints and chooses neither. Sol's point is the reason endpoint sensitivity is retained (retained disagreement 36).
- **Valid.** Gemini selection-reversal witness: survivor mean 10 → 27.5.
- **Controlled-cohort spec** `native-v3-controlled-cohort-sol-r12-v1`.
  - The CPU fixture gives −10.
  - With one missing arm the interval is [−12.5, +8.83], so the spec is honest about non-identification.
  - It is a design, not a native result.
- **Valid lineage critique.** The regex UUID join in my `_native` adapter, and in Astra's, is unproven lineage.
  - The parent tree's new lab-only `vllm_xargs.pr33_gateway_request_id` injection, with the observer recording the actual gateway_request_id/cohort_id/ignore_eos, would make this join exact for **future** data only. USED blocks 1–13 keep the regex join and its caveat.

**Measurement consequence.** The parent `mpc_ledger` telemetry provides exact `effective_at` whole-cost stock/release events. On future data this can replace v9's snapshot-interval (L, U] release bracket with observed release times, resolving the upper/lower sensitivity of retained disagreement 36 without a modelling choice. Using it needs:
- an adapter, with clock/source fencing;
- block data that contains it.

No USED block has it, so v9/v10 keep both endpoints. It provides no serial GPU time, and none is used.

### R13.2 CRN defect (independently reproduced)

`r11_response`/`r12_response` draw `uniforms` as a **positional** list of length len(start)+len(arrivals) from `sha256(R11_SEED|key|scenario)`. Index idx < len(start) is a cut member; idx ≥ len(start) is common-law arrival idx−len(start).

`r11_cut_start` re-offers latent never-seen pending owners as Q against `plan[0]`. The number of Q, and so len(start), therefore depends on the plan. Two things follow:
- Every future birth's uniform stream depends on the candidate plan.
- Pending members after a skipped Q also shift.

So two plans at the same origin, given the same arrival tape, do **not** share per-birth random numbers. The arrival tape itself is plan-free; only the service/transition draws are mis-paired.

My independent replication on USED 6/7 (scenario 0, constant plans 16 vs 32; first future birth, step-0 uniform):

| Cut | start length 16 / 32 | positional uniform 16 / 32 |
|---|---|---|
| `nv3-181006-mixed-arm0` k=12 | 5 / 8 | 0.7252071343450393 / 0.8078238380389821 |
| `nv3-181007-mixed-arm0` k=32 | 6 / 7 | 0.6713822373807942 / 0.7042321837779066 |

This matches Astra's reported witness. Her "12:41" label refers to k=12; k=41 shows no length difference. It is enforced by `test_r13_used_cuts_repair_plan_dependent_birth_index_shift`.

**Consequences:**
- **Marginal predictions** for any single plan are unbiased: each stream is still i.i.d. uniform.
- **Paired plan contrasts** carry spurious variance from mismatched birth draws, and can change sign through mis-pairing rather than through the admission pathway.
- **Factual-forecast MAE** changes only by Monte Carlo noise.
- Per R12/R13 the defect is a correctness issue for plan comparison and MPC search, not a forecasting result.

### R13.3 Specification `nv3-opus-stable-crn-v10`

- **Repair.** `StableUniforms(tag, origin key, scenario, start_ids)` assigns each simulated identity its own `ROLLOUT_STEPS` uniforms from `sha256(tag|key|scenario|identity)`:
  - Cut members: `rid:<request_id>`.
  - Common-law births: `arrival:<i>`, where i is the arrival's index in the plan-free tape `draw_common_law(cut, key, scenario)`.
  - Streams are independent of the initial stock size and order, the plan or action, Q admission, and every other identity.
  - Member and release streams use distinct tags (`R13_SEED|member`, `R13_SEED|release`).
  - The frozen `r11_simulate`/`r12_simulate` are called unchanged; they only index `uniforms[idx][j]`.
- **Unchanged:**
  - Fit on Train 1–3.
  - Kernel, records, hierarchy/backoff.
  - Arrival law and its scenario seeds; 32 scenarios.
  - Origin masks, horizons 1/3/5 s, SLO/API-stop labels, original whole-owner cost, non-eviction on budget decrease.
  - Both release endpoints, the v7 comparators, and bands.
  - `r13_cut_start` must reproduce `r11_cut_start` exactly, otherwise it raises `r13_start_mismatch`. It adds only identities.
- **Predictors added** (`--replica-stable-crn TRAIN EVAL BLOCKS`): `v10_stable_aware` / `v10_stable_blind` (v8 ledger) and `v10_within_step_{upper,lower}` (v9 ledger).
  - The same output also carries the frozen v9 predictors and comparators via `within_step_extension`. They must equal the v9 raw values, otherwise the run is invalid.
- **Pairing diagnostic** (descriptive only). At every origin, for constant plans 16 vs 32 on the v8 aware ledger, positional vs stable:
  - mean G5 contrast;
  - scenario SD of the contrast;
  - nonzero-scenario count;
  - whether start lengths differ.

  These are model Monte Carlo diagnostics, **not** causal plan effects, rankings, MPC wins or a permit.
- **Adoption rule:** v10 streams are the default for any future plan contrast **on correctness** (R13.2), whatever their development MAE. Development scores are reported, not used for selection. Nothing is tuned.
- **Positional mode** (`r13_runs(stable=False)`) reproduces the frozen v8/v9 streams. This is test-enforced against `r11_response`.

### R13.4 Gate relocation and pre-registration (before any exposure)

- **Blocks.** Mayor reports that 12/13 summary counts were seen during failure investigation, so **181012/181013 are EXPOSED** and cannot evaluate H11/H12. The original R11.4/R12.4 gates move to the **first complete Train pair unexposed at this seal: 181015/181016 or later** (`R13_EVAL_BLOCKS`).
  - 12/13 may only be used as USED development, and only after it is sealed.
- **Original gates unchanged:**
  - H11a/b/c via `--replica-batch-progress` from d15a4f1.
  - H12a/b/c with their stop rules via `--replica-within-step-release` from 4232166.
  - Thresholds and wording are as in R11.4 and R12.4.
- **Parallel H13 gates** (same thresholds, labelled as stable-CRN versions, never substitutes):
  - H13a: |rejected_5 bias| of v10_within_step_e < that of v10_stable_aware.
  - H13b: G5 MAE of v10_within_step_e < that of v10_stable_aware.
  - H13c: G5 MAE of v10_within_step_e ≤ 0.95 × v7_e.
  - Each must hold in both blocks, for each endpoint, with the R12.4 stop rule.

  Because the repair only changes pairing, H13 and H12 should agree up to Monte Carlo noise. A disagreement is reported as noise sensitivity of the gate, not as a win.
- **Excluded:** endpoint choice by score, weight/horizon search, causal plan-ranking claims, a native permit, MPC wins, and Calibration/Validation/Final data.
- H11c's development negative and H12c's expected failure remain recorded.

### R13.5 v10 development results (source/spec sealed at 8275ec1 BEFORE running; fit 1–3; USED 4–9)

Command: `--replica-stable-crn TRAIN1-3 DIR BLOCKS`, PYTHONHASHSEED=7.

**Validity check.** Every frozen v9/v8/v7/comparator value inside the v10 outputs equals the R12 raw (`opus-r12-within-step-*.json`) exactly. The only differing keys are `/schema` and `/extension/seed`, which are labels.

**G5 MAE / G5 bias; rejected_5 bias, positional (frozen) vs stable (v10):**

| Block | v8 aware | v10 stable aware | v9 upper | v10 upper | v9 lower | v10 lower |
|---|---|---|---|---|---|---|
| 181004 | 7.192 / −5.89; +9.63 | 7.163 / −5.86; +9.61 | 4.183 / −1.35; +3.02 | 4.189 / −1.34; +3.02 | 3.911 / +0.09; +1.31 | 3.932 / +0.10; +1.29 |
| 181005 | 7.234 / −6.15; +9.41 | 7.273 / −6.20; +9.44 | 4.244 / −1.60; +2.81 | 4.252 / −1.65; +2.84 | 3.894 / −0.23; +1.16 | 3.916 / −0.25; +1.17 |
| 181006 | 7.068 / −6.03; +8.82 | 7.056 / −6.04; +8.81 | 4.470 / −1.64; +2.41 | 4.459 / −1.65; +2.40 | 4.402 / −0.26; +0.74 | 4.392 / −0.28; +0.75 |
| 181007 | 7.878 / −6.74; +9.54 | 7.895 / −6.74; +9.54 | 4.410 / −2.25; +3.03 | 4.405 / −2.23; +3.01 | 3.792 / −0.87; +1.36 | 3.839 / −0.84; +1.33 |
| 181008 | 7.671 / −6.56; +9.31 | 7.674 / −6.58; +9.33 | 4.239 / −2.01; +2.70 | 4.250 / −2.01; +2.69 | 3.844 / −0.56; +0.99 | 3.804 / −0.56; +0.97 |
| 181009 | 7.701 / −6.51; +9.04 | 7.664 / −6.47; +9.04 | 4.336 / −2.05; +2.58 | 4.302 / −2.01; +2.56 | 3.845 / −0.68; +0.93 | 3.827 / −0.63; +0.91 |

v7 (`r8_admission_birth`, upper/lower) is unchanged from R12.5.

**Pairing diagnostic.** Per origin; v8 aware ledger; constant plans 32 − 16; 32 scenarios; positional → stable.

| Block | origins | start length differs | mean G5 contrast | scenario SD of contrast |
|---|---|---|---|---|
| 181004 | 552 | 149 | 11.917 → 11.904 | 2.5625 → 2.5588 |
| 181005 | 556 | 157 | 11.966 → 11.957 | 2.5494 → 2.5375 |
| 181006 | 562 | 144 | 12.031 → 12.004 | 2.6431 → 2.5970 |
| 181007 | 549 | 145 | 12.067 → 12.072 | 2.5867 → 2.5523 |
| 181008 | 556 | 149 | 12.165 → 12.183 | 2.5753 → 2.5422 |
| 181009 | 556 | 141 | 12.083 → 12.093 | 2.5617 → 2.5303 |

**Reading:**
1. **The defect is real and frequent.** 25–28% of origins have plan-dependent start lengths, and so mis-paired births under the frozen streams. The 181006/181007 counts (144/562, 145/549) equal Astra's reported counts exactly.
2. **The practical impact on these diagnostics is small.**
   - The stable streams reduce the contrast's scenario SD in all 6 blocks, but only by 0.1–1.7%.
   - Mean contrasts move by at most 0.03.
   - Most contrast variance is genuine model variance: different admitted populations, cost-bounded admissions, and the shared tape's stochastic interaction with the plan. It is not mis-pairing.
   - The repair is adopted on correctness, not because it materially changes these numbers.
3. **Factual scores move only by Monte Carlo noise**, as expected for a marginal-preserving change: G5 MAE ±0.05, bias ±0.05, rejected_5 ±0.03. Every R12.5 reading is unchanged:
   - v10 lower stays at parity with v7 lower, not ≥5% better.
   - H12c/H13c are expected to fail on development.
   - Bands still under-cover.
4. **No causal claim.** The +12 G5 "contrast" between constant 32 and 16 is a model contrast under the fitted kernel and the step-start admission/whole-cost ledger. It is not an identified plan effect, ranking, MPC value or native permit.

### R13 retained disagreements (added)

37. CRN for plan comparison must be keyed by stable simulated identity (request ID or law-tape arrival index), not by position in a plan-dependent population list. Small observed impact does not license positional streams in an MPC search, where many candidate plans are compared and mis-pairing errors compound.
38. Exposure is a property of the data pair, not of the source seal. Gate relocation (12/13 → 15/16) is mandatory once summary counts were seen, even if no model score was computed.

### R13 receipt

- **Peer sources reviewed (read-only):** `pr33-native-v3-round12-frozen/{astra,gemini,sol}`.
- **Source and spec seal before any v10 run:** commit 8275ec1.
  - `native_release_model.py` `3ec5b68364a1e7eb17e38ea47a81c5fd0490365bde1b1045e383ff9b09067bd9`
  - `test_native_release_model.py` `a1ecc3ba87e0c8557db8a93b9ab5151f21a74746735a0b31d1d180f5f8304672`
  - Tests: 66 passed, 0 skipped. The 2 new tests are `test_r13_stable_uniforms_are_identity_keyed` and `test_r13_used_cuts_repair_plan_dependent_birth_index_shift`, the latter on USED 6/7 Astra cuts plus a positional == frozen `r11_response` check.
- **Frozen hashes re-verified on 8275ec1** (PYTHONHASHSEED=7):
  - v8 8/9 `f6cb114d…1be4`
  - R10 witness `9467b07d…a8c`
  - R11 witness `c827bb68…bcb`
  - v9 4/5 `3ccf64f9…b217`, 6/7 `665abff8…fd26`, 8/9 `804edf33…def0`
- **v10 development raw** (session files `c45ddf1e…/files/`):
  - `opus-r13-stable-crn-181004-5.json` `675006ac3ff5175fa0e84f69dfae452ce5d8302d7cea584c6266fb9c98cba58d`
  - `opus-r13-stable-crn-181006-7.json` `28eed3b8f3da2cd2b4a8fc9fe8a95bb9baf31f94308a18767c928bfccdc7f24a`
  - `opus-r13-stable-crn-181008-9.json` `b5703b1a652090271ad327fafc73a3e80cb899cc22f528739221b28f71cfd779`
- **Pending, awaiting Mayor's sealed 181015/181016 (or later) subset:**
  - The R11.4 v8 run from d15a4f1, the R12.4 v9 run from 4232166, and the R13.4 v10 run from 8275ec1.
  - 12/13 are exposed. Calibration, Validation and Final remain unused.
- No GPU, SSH, Pod, push, `gt done`, Witness or Refinery.

## R14 — concurrency-aware event-birth competitor, birth-hold floor and owner-stock audit (bead pr-native-v3.5)

Scope: USED/training data only (fit 1–3; development 4–9; label-only audit additionally on USED 10/11). v8 (d15a4f1), v9 (4232166) and v10 (8275ec1) source, raw outputs, gates and negatives are unchanged. 15/16 are reserved for the UNCHANGED H11/H12/H13 gates and are **not** an R14 fresh pair. Sources read: the sealed R13 peers in `pr33-native-v3-round13-frozen/{astra,gemini,sol}`. No 12/13/15/16/Calibration/Validation/Final, Pod, GPU, SSH or fresh data.

### R14.1 Adversarial review of sealed R13 peers

**Astra (R13)**
- **Supported.** The exact v9 binary-prefix enumerator reproduces all 32,768 reference scenario outputs and cuts work by 61.25%; 100 ms full-MPC completion rises from 6/16 to 13/16. This is a solver-speed result, not a forecast or control result.
- **Retained failure.** The first adapter run failed on a status-vs-class guard bug (raw `eb4f26fd…`); the corrected run is `e8d3c600…`. Both must stay in the record.
- **Limit.** It uses the legacy positional CRN. Its single upper-endpoint first-action difference (`nv3-181008-p4096-m256-arm0:140:353`) coincides with a birth-index shift case (4 vs 5 start members), so that difference is not separable from the R13 pairing defect. It should be re-run with v10 identity streams before being read as an endpoint effect.
- **Agreed.** The ledger has no owner UUID, and births hold cost through the birth step. R14.2 now tests the latter directly.

**Gemini (§36)**
- **Accepted.** The stale Opus critique is retracted. The parent adapter integration is correct: Gateway overwrites `pr33_gateway_request_id`; the cohort tag passes through.
- **Cost arithmetic correct.** 5×512 anchors cost 3.0226906667 each (15.1134533 total); margins +3.1439 (reject arm) and +0.7648 (accept arm).
- **Limits.**
  - The −58 token figure is CPU mock data.
  - As Sol notes, the anchor arithmetic guarantees four rejections only if no anchor releases during the window. R14.2 shows ≈1/3 of real offers fall inside an owner's release interval, so this is a live, not hypothetical, failure mode.
  - The 9×256 slow-ACK early-completion counterexample is a valid model witness, not a GPU measurement.

**Sol (R13)**
- **Correct and important.** `audit_gateway_ledger_prefix` shows suffix truncation is undetectable: status has no final sequence, count or digest, a flush OSError drops a whole batch, and there is no fsync. The 1963 = 3×649 + 16 row identity on the Source144 smoke is a consistency check, not proof of completeness.
- **Agreed.** `TaggedNativeInputAdapter` is a conditional lineage match, not trusted identity. Adjacency/FIFO owner attribution in an aggregate ledger is not promoted. R14.2 quantifies how much attribution is lost (≈78%).
- **Endorsed recommendation.** A final producer watermark/record count, plus (my addition) the owner request_id on each ledger release event.

### R14.2 Owner-stock audit `nv3-opus-owner-stock-audit-r14` (label-only; no model, no plan, no future input)

Inputs per episode: Gateway snapshots (`sampled_at`, `budget`, owners {request_id, cost, admitted_at}), client rows, joint steps. Owner marks are checked immutable (`owner_mark_not_immutable` otherwise). The release of an owner lies in (last snapshot containing it, next snapshot]. The decision window of an offer is the exact Gateway `admitted_at` for accepts and only (client sent, 503 terminal] for rejects. For each offer:
- S_def = cost of owners definitely holding throughout the window; S_pos = cost of owners possibly holding at any point in it; the budget bracket is the budgets of the spanning snapshots.
- The outcome is *determined* if S_def + c > every budget (must reject) or S_pos + c ≤ every budget (must accept); a violation is a determined outcome contradicting the actual one, or a reject with S_pos + c ≤ the exact `max_admitted_cost` it reports.
- **Floor test:** release := max(release, end of birth grid step). Counts offers the floor turns into must-reject that were actually accepted.
- **Aggregate-ledger test:** group releases by (snapshot interval upper end, cost). A singleton group is attributable to one owner without a UUID.

**Train 1–3 results** (`--owner-stock-audit`, raw hash in the receipt):

| Block | Admitted | Offers | Violations | Never snapshotted | Birth released within birth step (definite) | Floor contradicted by actual accept | Offers determined | Releases attributable by (time, cost) |
|---|---|---|---|---|---|---|---|---|
| 181001 | 8940 | 14082 | 0 | 0 | 1 | 0 | 65–67% | 21–22% |
| 181002 | 8840 | 14078 | 0 | 0 | 0 | 1 | 65–67% | 21–22% |
| 181003 | 8852 | 14226 | 0 | 0 | 2 | 0 | 65–67% | 21–22% |

**Readings.**
1. **Stock = sum of snapshot owner marks, exactly.** With Gateway decision instants, all ≈42,000 offers are consistent with the owner-mark stock; there is no hidden stock and no Gateway transient (every owner lives ≥ 0.143 s; snapshots every ≈0.12 s). The only ambiguity is *when inside its snapshot interval* an owner released: ≈1/3 of offers are not determined by marks alone. This is precisely the v9 upper/lower endpoint sensitivity, and it is not resolvable from USED data.
2. **The 0.5 s birth-hold floor is NOT falsified at this load.** Only 3 of ≈26,600 births definitely released within their birth step; one accept in ≈42,000 offers contradicts the floor. Owner lifetime from `admitted_at` (lower endpoint) has p1/p10/p50 = 0.386/0.558/0.867 s; upper ≤ 0.5 s for 0.39%. The floor is a ≈0.4% approximation here, so it cannot explain v9's G5 −6 / rejection +9 bias. **This is load-specific**: shorter outputs or lighter load would make it fail, and it must be re-audited on any new cell.
3. **Client `sent` is not the Gateway decision instant.** Using sent as the decision time produced ≈350–410 unexplained rejects per block (≈7% of rejects) and 32–43 accept violations; with exact `admitted_at` both are 0. Gateway lag `admitted_at − sent` (Train 1–3) is p10/p50/p90/p99 = 0.0021/0.018/0.102/0.327 s (max 0.61). It is strongly concurrency/cell dependent: p128-m128 p50 0.028 s, p90 0.148 s; other cells p90 0.03–0.05 s. In p128-m128 10.2% of accepts are decided in a later grid step than sent; 2.7–4.3% elsewhere. v8/v9/v10 decide at sent, i.e. early, against a stock that has not yet received the releases occurring during the lag. This is a candidate mechanism for over-rejection.
4. **Aggregate ledger without UUIDs.** Exact `effective_at` stock events would remove the endpoint ambiguity of (1) for *stock-based admission* (owners are exchangeable by cost), but only ≈21% of releases are attributable to an owner by (time, cost). Per-owner lifetime/hazard fitting by age from such a ledger is therefore not identified; the ledger needs the owner request_id per release event (and Sol's final watermark/count) for that.
5. **Net vs gross.** ≈2,200 of ≈8,900 snapshot intervals per block contain both births and deaths; ≈710–736 per block have zero net cost change. Net snapshot stock differences undercount gross flow; only the owner set, not the stock series, identifies it.

### R14.3 Competitor specification `nv3-opus-event-decision-lag-v11` (frozen before any development run)

v11 = v10 within-step (`r12_simulate` with identity CRN) with ONE change, justified by R14.2 reading 3 and not by any score:
- Each offer at law time a is decided at Gateway instant d = a + ℓ, with ℓ drawn from the Train 1–3 pool of exact `admitted_at − sent` for accepted owners, keyed by (cell, owner-count bin) with HAZARD_MIN = 20 backoff (cell,) → (). Owner-count bins `R14_OWNER_BINS = (0, 4, 8, 16)` were declared a priori (powers of two around the 16/32 budgets / ≈1–3 unit costs), not searched. In the fit, the count is the number of owners in the last snapshot ≤ sent (observable at sent); in simulation it is the step-start count of cost holders, including members releasing this step.
- Offers within a step are decided in d order against R(d) = holders + members not yet released by d + births admitted so far. d is clipped to the step end (counted as `v11_lag_clipped_to_step_end`); the offer keeps its arrival step's plan and birth record.
- **Declared approximations:** reject decision instants are unobserved, so the accept-lag pool is applied to all offers; clipping ignores the 3–10% cross-step decisions' next-step plan; births still hold through the birth step (floor not falsified).
- **Unchanged:** kernel, fit 1–3, common exogenous law, scenarios (32), horizons 1/3/5 s, origin masks, targets, both release endpoints (never selected or averaged), whole cost, no eviction after a budget decrease. Lag draws are a separate identity-keyed stream (`nv3-opus-r14-decision-lag|…|arrival:<i>`), plan-free; v10 member/release streams are reused exactly, so zero lag reproduces v10 exactly (tested).
- **Concurrency-awareness is through the Gateway lag only.** A concurrency-keyed lifetime/release hazard was considered and NOT built: R14.2 (4) shows per-owner lifetimes from the future ledger are not attributable, and on USED snapshots the release offset is already the interval-censored quantity whose endpoint sensitivity dominates. Building a lifetime hazard on (L, U] endpoints would re-encode the same ambiguity.
- No HTTP residence, no serial GPU time, no native permit, no MPC claim.

CLI: `--replica-event-lag TRAIN EVAL BLOCKS` (predictors `v10_within_step_{upper,lower}`, `v11_event_lag_{upper,lower}`, plus the frozen base predictors and `r8_admission_birth_lower`); `--owner-stock-audit TRAIN EVAL`.

### R14.4 Pre-registration (before any v11 score)

- **Fresh pair:** the first complete Train pair unexposed at this seal **after** 15/16, i.e. 181017/181018 or later (`R14_EVAL_BLOCKS`). 15/16 belong to the unchanged H11/H12/H13 gates; R14 must not be scored there as fresh.
- **Gates, each in both blocks and for each endpoint e separately:**
  - H14a: |rejected_5 bias| of v11_e < that of v10_within_step_e.
  - H14b: G5 MAE of v11_e < that of v10_within_step_e.
  - H14c (practical): G5 MAE of v11_e ≤ 0.95 × v7_e (`r8_admission_birth` upper / `r8_admission_birth_lower`).
- **Stop rule:** if H14a fails for both endpoints, the decision-lag mechanism is not the source of the rejection bias, and nothing is tuned. Development results on 4–9 are descriptive only and cannot change bins, pools, clipping or gates.
- **Excluded:** endpoint choice by score, weight/horizon/bin search, causal plan-ranking claims, native permit, MPC win, Calibration/Validation/Final.

### R14.5 Development results (source/spec sealed at fbda729/b0edfa5 BEFORE running; fit 1–3; USED 4–9)

`--replica-event-lag`, PYTHONHASHSEED=7. Origins 1108/1111/1112 (4/5, 6/7, 8/9), no exclusions, no missing v7-lower keys. Lag draws clipped to step end: 7.6–7.7% of all draws. G5 MAE / G5 bias / rejected_5 bias:

| Block | v10 upper | v11 upper | v7 upper | v10 lower | v11 lower | v7 lower |
|---|---|---|---|---|---|---|
| 181004 | 4.189 / −1.337 / +3.015 | 4.086 / −0.832 / +2.371 | 4.057 / −1.156 / +3.075 | 3.932 / +0.101 / +1.290 | 3.930 / +0.224 / +1.163 | 4.117 / +1.024 / −0.246 |
| 181005 | 4.252 / −1.645 / +2.839 | 4.059 / −1.151 / +2.210 | 4.093 / −1.361 / +2.937 | 3.916 / −0.254 / +1.175 | 3.903 / −0.132 / +1.033 | 4.123 / +0.697 / −0.280 |
| 181006 | 4.459 / −1.653 / +2.396 | 4.434 / −1.170 / +1.791 | 4.423 / −1.375 / +2.380 | 4.392 / −0.277 / +0.746 | 4.386 / −0.151 / +0.613 | 4.628 / +0.629 / −0.738 |
| 181007 | 4.405 / −2.229 / +3.006 | 4.154 / −1.760 / +2.405 | 4.226 / −1.959 / +3.034 | 3.839 / −0.839 / +1.331 | 3.800 / −0.725 / +1.207 | 3.773 / +0.086 / −0.124 |
| 181008 | 4.250 / −2.012 / +2.687 | 4.056 / −1.502 / +2.061 | 4.105 / −1.691 / +2.711 | 3.804 / −0.561 / +0.966 | 3.780 / −0.432 / +0.838 | 3.995 / +0.458 / −0.596 |
| 181009 | 4.302 / −2.013 / +2.559 | 4.089 / −1.527 / +1.958 | 4.204 / −1.780 / +2.608 | 3.827 / −0.632 / +0.909 | 3.809 / −0.519 / +0.781 | 3.998 / +0.244 / −0.531 |

v11/v7 G5 MAE ratio — upper 1.007/0.992/1.002/0.983/0.988/0.973; lower 0.955/0.947/0.948/1.007/0.946/0.953. The strong aggregate hybrid G5 MAE is 5.78–6.46 in these blocks.

**Readings (descriptive, development only; gates are for 181017/181018+):**
1. **H14a/H14b directions hold in all 6 blocks for both endpoints.** Deciding at the Gateway instant cuts the rejected_5 over-prediction by ≈20% (upper) and ≈10% (lower) and the G5 under-prediction correspondingly. Same CRN streams, so these are paired, systematic shifts, not noise. But the size is modest: v11 upper G5 MAE improves 0.5–5.7% on v10 upper, and lower only 0.05–1%.
2. **The mechanism is real but not dominant.** Rejection bias stays positive (+0.6 to +2.4 per origin) for both endpoints. The remaining over-rejection is mostly the release-endpoint ambiguity of R14.2 (1), which v11 cannot resolve.
3. **H14c is expected to FAIL on development.** Upper never reaches 0.95 × v7 upper. Lower clears 0.95 × v7 lower only in 181005/181006/181008 (and 181007 is worse than v7 lower). v7 lower's opposite-signed rejection bias shows both are biased; neither is "the" truth.
4. **Interpretation.** v11 is a correctness-motivated (R14.2 reading 3), modest improvement over v10. It is not a forecaster win, not an MPC result and not evidence about any plan effect. The gates stand as pre-registered; nothing was tuned after these results.

**Owner-stock audit on USED 4–11** (`--owner-stock-audit`; label-only): zero violations of all three kinds, zero never-snapshotted owners in every block. Definite within-birth-step releases 0–4 per block; floor contradicted by an actual accept 0/0/1/0/0/2/0/1 (181004–181011). Offers determined 64–67%; releases attributable by (time, cost) 21–23%. R14.2 readings 1, 2, 4 replicate on all 11 USED blocks.

### R14 retained disagreements (added)

39. Gateway decision time is `admitted_at`, not client `sent`. Any admission replay or simulator that uses `sent` misattributes stock for ≈7% of rejects. Peers' replays that use `sent` should be re-checked.
40. The 0.5 s birth-hold floor is an empirically supported ≈0.4% approximation **at this load**, not a law. It must be re-audited on each new cell/load.
41. The aggregate `mpc_ledger` without owner UUIDs identifies stock timing but not per-owner lifetimes (≈79% unattributable). A per-owner lifetime/hazard model must not be fitted from it by adjacency/FIFO; the ledger needs owner IDs plus a final watermark/count.

### R14 receipt

- **Peer sources reviewed (read-only):** `pr33-native-v3-round13-frozen/{astra,gemini,sol}`.
- **Source/spec/prereg seal before any v11 development run:** tree at fbda729 (auto checkpoint containing exactly the 3 owned files) and explicit seal commit b0edfa5.
  - `native_release_model.py` `0a5fa5dbc4a0e1e9e7793f4aa4e9d5245c566dfdf5637fe2f7637488f109f170`
  - `test_native_release_model.py` `4c78e9dd591ee687235ff64b068991cb19ad826585d30bad8bed67d6b46309f7`
  - Tests: 68 passed, 0 skipped. New: `test_r14_used_train_owner_marks_explain_every_gateway_decision`, `test_r14_decision_lag_bins_pool_backoff_and_zero_lag_equals_v10` (zero lag == v10 exactly; full clipping counted; offers plan-free).
- **Frozen hashes re-verified on the sealed source** (PYTHONHASHSEED=7): R10 witness `9467b07d…a8c`, R11 witness `c827bb68…bcb`, v9 4/5 `3ccf64f9…b217`. Changes are additive (new functions/CLI branches only).
- **Raw** (session files `c45ddf1e…/files/`):
  - `opus-r14-event-lag-181004-5.json` `b33dcb17acba80a2b76e10cdf4686cb519b33b08a0822f73cd2c889fb4513196`
  - `opus-r14-event-lag-181006-7.json` `0092b764450293f423785f16cf846fd6923c966bdda8e2dcc8b46d155918b6c6`
  - `opus-r14-event-lag-181008-9.json` `fe90cc6ce0416cfed008094eb4666f0086986df0d3b7107da7d2221d026548dd`
  - `opus-r14-owner-audit-181001-3.json` `9c7e9de2fb427e1f99f1dd005f78350c14e385e3c240cace43e45e23ecc2925d`
  - `opus-r14-owner-audit-181004-5.json` `1834709c4e037615040348c1ccd468d30f3840373a4f7d2ee63171741c7caca7`
  - `opus-r14-owner-audit-181006-7.json` `e54d75a991b9e039cf34f647bd0c3664a95c29cdc8ca9258babd25e3d92cf8c7`
  - `opus-r14-owner-audit-181008-9.json` `0932a0e0698370991cb643065d8112b9fe40b43e0d9ca68c2e7016a8affbb854`
  - `opus-r14-owner-audit-181010-11.json` `4ec40a90dcf79d057a582b70727cd8c27f4ca9e9086c63f2fb25ed76251968ec`
- **Pending:** H11/H12/H13 on 181015/181016 (unchanged sources); H14 on 181017/181018 or later from b0edfa5. 12/13 exposed; 15/16 not R14-fresh; Calibration/Validation/Final unused.
- No GPU, SSH, Pod, push, `gt done`, Witness or Refinery.

## R14 receipt correction — evaluation protocol (Mayor, not model tuning)

**Invalid proposal retained.** R14.4 pre-registered H14 on "181017/181018 or later" as a fresh Train pair. That is **incompatible with the frozen Source144 protocol**: Train = 15/16 only, Calibration = 17–36, Validation = 37–40. Blocks 17/18 are Calibration and must never be relabelled Train or candidate-validation, and Calibration MAE must never select an architecture. R14.4's 17/18 wording is kept as written above and is marked **INVALID for this protocol**.

`R14_EVAL_BLOCKS = (181017, 181018)` in the sealed source (b0edfa5) is a declaration only. No code path reads it; the CLI takes blocks explicitly. It is left unchanged, so the sealed source hash stays valid, and it is **superseded** by this section. It must not be used to score anything.

**Unchanged:** the original H11/H12/H13 math and gates on 15/16, run from their own sealed sources. Sol's explicit Source144 input bridge is required before those forecasts; the legacy CLI correctly refuses Source144 input. R14 adds nothing to 15/16.

**Corrected H14 pre-registration** (source and model already sealed at b0edfa5 before any new data; gates H14a/b/c, stop rule and exclusions exactly as in R14.4):
- **Primary:** one confirmatory run on the **prospectively reserved new Train pair 41/42**, after it is collected complete and sealed by Mayor. It runs only after the 15/16 gates, through a Source144 input bridge that changes the input format only.
- **Alternative, only if Mayor designates it before any exposure:** a validation run on Val 37–40. Split labels stay unchanged, the run is once only, and it is pre-registered in a separate local commit before exposure. Not chosen now.
- **No Calibration (17–36), Validation or Final data has been accessed.** v11 development results (USED 4–9) remain USED descriptives only.

### Same-source action audit (definitions; no new run on protocol data)

1. **Budget 16/32 is a whole-owner-cost reservation budget, not concurrency 16/32.**
   - In v8–v11 the action enters only through the admission test R(d) + c ≤ plan.
   - Concurrency is an outcome of costs, lifetimes and arrivals. On USED Train 1–3, Gateway snapshots with more than 16 owners occur under both arms: arm0 1,041 of 13,381 snapshots, arm1 1,126 of 13,362. The p128-m128 owner-count bin ≥16 holds 7,501 of 15,958 accepts.
2. **The native runtime limit is fixed at 32 sequences.** States where many sequences are live but cost-limited do not identify a fixed concurrency-cap-16 control, and the Gateway budget-16 arm is not that control either.
   - A forecast of "cap-16 concurrency" from these data would be extrapolation.
   - None of my predictors are interpreted that way.
3. **Cost release happens at terminal cleanup, not at first content.**
   - Mayor's Source144 smoke: the first-content-only marks are 239, while cost is held until terminal cleanup, 529.
   - USED Train 1–3 agrees independently: 26,616 of 26,632 (99.94%) of accepted owners are still in a later Gateway snapshot after their client first-content time. The last-snapshot minus first-content gap has p10/p50/p90 of 0.377/0.644/1.383 s.
   - Consequences:
     - Owner lifetime or release must be keyed to terminal cleanup, observed as Gateway owner disappearance (interval-censored).
     - It must not be keyed to TTFT or first content.
     - The release-offset pools in v9–v11 already use Gateway disappearance, so they are consistent with this.
     - Any peer model that releases at first content under-states stock.

No weight rescale, no false win, no GPU, SSH, Pod, push, `gt done`, Witness or Refinery.
