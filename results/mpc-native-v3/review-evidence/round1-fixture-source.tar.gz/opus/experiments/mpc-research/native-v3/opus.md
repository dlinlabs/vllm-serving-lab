# NV3 Opus 獨立提案（Round 1）：history-conditioned 原始成本釋放模型

狀態：**獨立初稿，未讀 peer NV3 提案**。沒有新的 native／MPC 結果；
本文件與程式只定義可在實際 Gateway marks／ledger 與 native frames 上執行的
模型、ground truth 與否證測試。單元 fixtures 只驗證會計與因果性，
不是 native 性能、校準或統計保證。

## 1. 共同 ground truth：useful／physical／tail work（不放寬舊 audit）

Strict HTTP 基線（exact UUID、4096 prompt／32 output／natural EOS）：
34 steps＝2 prefill＋32 decode；worker 連續 forward positions 結束於 4128，
delivered-token 最小值 `P+O−1=4127`。舊 v2 `audit_capture` 的
`progress == input+output−1` 因此**仍為 FALSE，原樣保留**。

明確會計（`forward_work_accounting`）：

| 量 | 定義 | 基線值 |
|---|---|---:|
| useful positions | `P+O−1`（最後 sampled token 不需再 forward） | 4127 |
| physical positions | 實際連續 executed positions 終點 | 4128 |
| tail positions | physical − useful | 1 |
| useful steps | 結束 ≤ useful 邊界的 steps（2 prefill＋31 decode） | 33 |
| tail steps | 起點 ≥ useful 邊界的 steps | 1 |

`tail_accounted=True` 只在全部成立時：natural EOS；positions 無 gap／repeat／split；
每個 step 與 worker `executed_positions/executed_counts` 相符；tail ≤1 token；
tail step 是單 token decode 且 **schedule start < engine finish**（pre-finish placeholder）。
否證（各有測試）：tail step 在 finish 後才排程、tail>1（unexplained work）、
tail<0（missing useful work）、position gap、跨越 useful 邊界、worker 未匹配。
GPU elapsed 只是 per-step current-stream label，不是絕對 GPU／host clock
或獨占 service duration；本模組不把它相加成 service time。

對 release 模型的含義：reservation release 不早於 EOS output commit，
tail forward 是 release 之前可能的物理延遲來源；它作為誤差解釋 label，
不是預測輸入。

## 2. 可觀測狀態與 transition

Origin `t0`＝joined observation 的 native client receipt；要求同 run／clock domain、
`gateway.sampled_at ≤ received_at ≤ t0`、age ≤0.5s、native ID
`chatcmpl-<uuid>-<8hex>` 精確 join（未 join／重複即拒絕）。
Cohort＝origin snapshot 中所有 live marks（原始 cost、prompt、max、admitted、first）。

每 mark 特徵（全部 ≤t0 可得）：cost、prompt_k、max/100、started、age、
native_unknown、output progress、remaining cap、decode batch D、
prefill backlog k-tokens（native output=0 ＋ Gateway 已收但 native 未見）、
waiting、cohort cost R、**計畫中**的 cap（frozen `cap_plan` 時間平均，
非 realized）、trailing 2s realized release rate（只用先前已收到的 snapshot pairs）。
有測試證明修改未來 observations 不改變 origin 特徵。

Exact transition 部分沿用 Gateway 守恆：每個 `mpc_ledger` frame 是單一事件，
delta<0 即一次 release（原始 cost、effective_at）。

## 3. Response：累計釋放原始 cost 的 ground truth（含不確定）

Target：origin cohort 在 `(sampled_at, t0+h]` 已釋放的原始 cost，h∈{1,3,5}s；
包含 observation lag 內已發生的 release。

1. Ledger 必須 sequence 連續、complete、同 run/clock；每個 snapshot 的 mark cost 和
   必須等於該 sequence 的 ledger reserved（否則拒絕）。
2. 每個 cohort mark 的消失區間＝最後出現與下一個 snapshot 的 sequence 區間。
3. 同區間同 cost 的 ledger release 事件為候選；若 `n_g` 事件、`m_g` cohort marks：
   cohort 已釋放數 ∈ `[max(0, r−(n_g−m_g)), min(r, m_g)]`（r＝≤τ 的事件數）。
   Cost 相同且有非 cohort release 時輸出**區間**而非猜測；`n_g<m_g` 拒絕。
4. 超過最後 snapshot 而仍未消失的 marks 是 censored 上界。

Per-mark label：唯一可識別時才給 0/1；否則 None，排除於 fit 並計數報告
（選擇偏差限制已承認）。

## 4. 比較的模型（全部只用 Train fit；無發明的 service 參數）

| 模型 | 形式 | 參數來源 |
|---|---|---|
| train_fraction | `R·p̄_h` | Train 精確 truth 的平均釋放比例 |
| fluid_history | `min(R, μ·h)`，μ＝trailing realized rate，缺少時用 Train 平均 cost/s | 歷史＋Train |
| batch_aware | `Σ cost_i·p_i(h)`，per-horizon L2 logistic，h 間 cummax 單調 | Train per-mark labels |

L2=1.0（標準化特徵）、α=0.1、history 2s 均**預先宣告、不調參**。
`fit` 拒絕任何非 Train row；seed block 只能屬於一個 partition；
final held-out **160021–160024 一律拒絕**（未使用）。

## 5. 評估：one／multi／OOD、block calibration

- 主要指標：`mean_h |pred(h)−actual(h)| / R_origin`，episode→block→平均；
  truth 為區間時報 lower/upper error；`R_origin=0` 另計不納入。
- One-step（1s）與 multi-step（3／5s）同一 origin 同時發布，不用 realized future gaps。
- OOD：Train 支援域（R、D、prefill_k、waiting、cap、planned cap、cohort size、
  `(prompt,max)` work shapes）外**整個 origin abstain**，所有模型配對相同樣本；
  abstention 原因逐項計數。
- Calibration：只用 Calibration blocks 的 split residual quantiles 形成 band，
  Development 報 per-block 覆蓋（lower＝所有可行 truth 皆覆蓋、upper＝某個可行 truth 覆蓋）。
  Blocks 間 exchangeability 未證，**不是 coverage 保證**。

## 6. Strong One-move vs MPC、因果支援與安全部署（本模組之外的條件）

- 本模型輸出 `P(release | H_t0, planned cap)`；cap 依賴性只有在 randomized
  cap-sequence episodes（Gate B LL/LH/HL/HH）支援下才可解讀為 action response；
  觀察資料上的 cap 係數不是因果斜率。
- Strong One-move 與 MPC 必須使用同一模型、同一 abstention 與同一 continuation
  （由 Development 在 hold／fixed／reactive 中選定）；只有 multi-step forecast
  在 Development 優於 train_fraction／fluid_history 時，multi-move 才有資訊價值。
- 部署：任何 OOD abstain 或 truth/ledger 驗證失敗 → 回到 development-chosen
  best-supported-fixed；cap 16/32 是 cost cap 而非 concurrency；無 KV hard-safety 宣稱。

## 7. 否證條件（預先宣告）

1. batch_aware 在 Development blocks 上未低於兩個 baseline 的 upper error →
   batch 特徵沒有超過 fluid 的預測價值，不得用於 MPC。
2. 3／5s 誤差相對 1s 未改善 baseline 差距 → 不支持 multi-step 規劃。
3. Development 覆蓋顯著低於 1−α 或 block 間差異大 → band 不可作 risk 約束。
4. 需要 abstain 的 origin 比例高 → 支援域不足，需要更多 randomized Train。
5. tail_accounted 對任何 natural-EOS request 為 False → release 延遲解釋失敗。

## 8. Receipt

- 檔案：`native_release_model.py`
  sha256 `86f45ab851a446b4a903c8e5f0991acb198ecc4fc5d9d0d9bd0d05e38e77411b`；
  `test_native_release_model.py`
  sha256 `1f38d3cb88d9c89d9acf2296b94278f02ed4f73a7e3e98caf5f7f045f902bed3`。
- 測試：`cd experiments/mpc-research/native-v3 && python3 test_native_release_model.py`
  → `9 passed`（Python 3.14.4，stdlib only；pytest 亦可收集 `test_*`）。
  Sandbox 阻擋 pip，故未安裝 numpy／pytest。
- 沒有 SSH／GPU／API、push、merge、`gt done`；沒有讀 peer NV3 提案；
  沒有 native 數據、fixture 常數或統計保證被宣稱為結果。
- 資料 adapter：raw NV3 capture → episode schema（見模組 docstring）待 Gate A／B
  原始資料存在後依實際欄位實作；目前不猜測 capture 欄位。
