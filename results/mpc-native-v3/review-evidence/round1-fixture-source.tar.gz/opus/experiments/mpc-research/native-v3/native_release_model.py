"""NV3 (Opus) history-conditioned cumulative original-cost release model.

Offline, stdlib-only research module. It grants no actuation authority, runs no
GPU/HTTP work and contains no service constants: every fitted quantity comes from
Train episodes that a caller assembles from actual Gateway marks/ledger and native
frames. Passing unit fixtures are not native results or statistical guarantees.

Episode schema (one actuated cap episode, all times in one monotonic clock domain):
  episode_id, seed_block, partition in {train, calibration, development},
  clock_domain, run_id,
  observations: [{gateway: /admin/mpc/state document, received_at,
                  native: pr33-native-read-only-v1 frame or None, native_received_at}]
  ledger: every mpc_ledger frame of the episode (contiguous sequence)
  cap_plan: optional [[assigned_from, budget], ...] frozen before the episode.
Origin time t0 is the client receipt of the joined observation. The forecast target
is cost of the origin's live marks released in (gateway.sampled_at, t0+h]; this
includes releases that happened during the observation lag.
"""
from collections import defaultdict
import json
import math
import re
import statistics
import sys

HORIZONS = (1.0, 3.0, 5.0)
PARTITIONS = ("train", "calibration", "development")
FINAL_HELDOUT = frozenset(range(160021, 160025))
NATIVE_ID = re.compile(r"chatcmpl-([0-9a-f]{32})-[0-9a-f]{8}")
MAX_AGE_S = 0.5
HISTORY_S = 2.0
MIN_HISTORY_SPAN_S = 0.5
L2 = 1.0          # predeclared on standardized features; never tuned
ALPHA = 0.1       # predeclared calibration miscoverage
EPS = 1e-9
MARK_FEATURES = ("cost", "prompt_k", "max_h", "started", "age_s", "native_unknown",
                 "progress", "remaining_h", "decode_batch", "prefill_k", "waiting",
                 "cohort_cost", "budget", "history_rate")


def _finite(value):
    return type(value) in (int, float) and math.isfinite(value)


# ----------------------------------------------------------------------------
# Observation validation and causal features
# ----------------------------------------------------------------------------

def _marks(document, episode):
    if (not isinstance(document, dict) or document.get("run_id") != episode["run_id"]
            or document.get("clock_domain") != episode["clock_domain"]
            or document.get("complete") is not True
            or type(document.get("sequence")) is not int
            or not _finite(document.get("sampled_at"))
            or not _finite(document.get("budget")) or document["budget"] <= 0):
        raise ValueError("gateway_identity_or_clock")
    marks = {}
    for mark in document["requests"]:
        rid = mark.get("request_id")
        if (not isinstance(rid, str) or rid in marks or not _finite(mark.get("cost"))
                or mark["cost"] <= 0 or type(mark.get("prompt_tokens")) is not int
                or type(mark.get("max_tokens")) is not int or mark["max_tokens"] <= 0
                or not _finite(mark.get("admitted_at"))
                or mark["admitted_at"] > document["sampled_at"]
                or (mark.get("first_at") is not None and not (
                    _finite(mark["first_at"]) and mark["first_at"] <= document["sampled_at"]))):
            raise ValueError("gateway_mark")
        marks[rid] = mark
    return marks


def _native(frame, marks, gateway_received_at, native_received_at):
    if (not isinstance(frame, dict) or frame.get("schema") != "pr33-native-read-only-v1"
            or frame.get("complete") is not True
            or not all(_finite(v) for v in (frame.get("sampled_at"), native_received_at))
            or not gateway_received_at <= native_received_at
            or not 0 <= native_received_at - frame["sampled_at"] <= MAX_AGE_S
            or frame.get("running") != len(frame.get("requests", ()))
            or type(frame.get("waiting")) is not int or frame["waiting"] < 0):
        raise ValueError("native_frame")
    joined = {}
    for request in frame["requests"]:
        match = NATIVE_ID.fullmatch(request.get("request_id", ""))
        if not match or match[1] not in marks or match[1] in joined:
            raise ValueError("native_unjoined_or_ambiguous")
        out = request.get("output_tokens")
        if type(out) is not int or not 0 <= out <= marks[match[1]]["max_tokens"]:
            raise ValueError("native_work")
        joined[match[1]] = out
    return joined


def _planned_budget(episode, t0, horizon, fallback):
    plan = episode.get("cap_plan")
    if not plan:
        return fallback
    points = sorted(plan)
    # Time-average of the frozen assignment over (t0, t0+h]; a plan, not realized state.
    edges = [t0] + [at for at, _ in points if t0 < at < t0 + horizon] + [t0 + horizon]
    total = 0.0
    for left, right in zip(edges, edges[1:]):
        active = [b for at, b in points if at <= left]
        total += (active[-1] if active else fallback) * (right - left)
    return total / horizon


def build_origins(episode):
    """Joined, causal origins. Features use only observations received <= t0."""
    if episode.get("partition") not in PARTITIONS:
        raise ValueError("unknown_partition")
    if episode.get("seed_block") in FINAL_HELDOUT:
        raise ValueError("final_heldout_reserved")
    observations = sorted(episode["observations"], key=lambda o: (o["gateway"]["sequence"], o["received_at"]))
    parsed = [(_marks(o["gateway"], episode), o) for o in observations]
    for (_, a), (_, b) in zip(parsed, parsed[1:]):
        if (a["gateway"]["sequence"] > b["gateway"]["sequence"]
                or a["gateway"]["sampled_at"] > b["gateway"]["sampled_at"]
                or a["received_at"] > b["received_at"]):
            raise ValueError("observation_order")
    origins = []
    for index, (marks, obs) in enumerate(parsed):
        if obs.get("native") is None:
            continue
        gateway = obs["gateway"]
        t0 = obs["native_received_at"]
        if not gateway["sampled_at"] <= obs["received_at"] <= t0 \
                or t0 - gateway["sampled_at"] > MAX_AGE_S:
            raise ValueError("observation_stale_or_noncausal")
        joined = _native(obs["native"], marks, obs["received_at"], t0)
        decode = sum(1 for out in joined.values() if out > 0)
        prefill_k = sum(marks[r]["prompt_tokens"] for r, out in joined.items() if out == 0)
        prefill_k += sum(m["prompt_tokens"] for r, m in marks.items() if r not in joined)
        # Trailing realized release from previously received snapshot pairs only.
        released, span = 0.0, 0.0
        for (m_a, o_a), (m_b, o_b) in zip(parsed[:index], parsed[1:index + 1]):
            if o_b["received_at"] <= t0 and o_a["gateway"]["sampled_at"] >= t0 - HISTORY_S:
                released += sum(m["cost"] for r, m in m_a.items() if r not in m_b)
                span += o_b["gateway"]["sampled_at"] - o_a["gateway"]["sampled_at"]
        history = released / span if span >= MIN_HISTORY_SPAN_S else None
        cohort_cost = math.fsum(m["cost"] for m in marks.values())
        origins.append(dict(
            episode_id=episode["episode_id"], seed_block=episode["seed_block"],
            partition=episode["partition"], t0=t0, index=index,
            sampled_at=gateway["sampled_at"], cohort=marks, joined=joined,
            reserved=cohort_cost, budget=gateway["budget"], decode_batch=decode,
            prefill_k=prefill_k / 1000, waiting=obs["native"]["waiting"],
            history_rate=history,
            planned_budget={h: _planned_budget(episode, t0, h, gateway["budget"]) for h in HORIZONS}))
    return origins, parsed


def mark_features(origin, rid, horizon):
    mark = origin["cohort"][rid]
    out = origin["joined"].get(rid)
    unknown = out is None
    out = 0 if unknown else out
    return (mark["cost"], mark["prompt_tokens"] / 1000, mark["max_tokens"] / 100,
            float(mark.get("first_at") is not None), origin["sampled_at"] - mark["admitted_at"],
            float(unknown), out / mark["max_tokens"], (mark["max_tokens"] - out) / 100,
            float(origin["decode_batch"]), origin["prefill_k"], float(origin["waiting"]),
            origin["reserved"], origin["planned_budget"][horizon],
            origin["history_rate"] if origin["history_rate"] is not None else -1.0)


# ----------------------------------------------------------------------------
# Ground truth from the contiguous ledger (bounds where cost ties are ambiguous)
# ----------------------------------------------------------------------------

def ledger_releases(episode, parsed):
    frames = sorted(episode["ledger"], key=lambda f: f["sequence"])
    first = parsed[0][1]["gateway"]
    sequence, reserved = first["sequence"], math.fsum(m["cost"] for m in parsed[0][0].values())
    at_sequence = {sequence: reserved}
    releases = []
    for frame in frames:
        if frame["sequence"] <= first["sequence"]:
            continue
        if (frame.get("event") != "mpc_ledger" or frame.get("run_id") != episode["run_id"]
                or frame.get("clock_domain") != episode["clock_domain"]
                or frame.get("complete") is not True or frame["sequence"] != sequence + 1
                or not _finite(frame.get("effective_at")) or not _finite(frame.get("reserved_cost"))):
            raise ValueError("ledger_identity_or_gap")
        delta = frame["reserved_cost"] - reserved
        if delta < -EPS:
            releases.append((frame["sequence"], frame["effective_at"], -delta))
        sequence, reserved = frame["sequence"], frame["reserved_cost"]
        at_sequence[sequence] = reserved
    for marks, obs in parsed:
        value = at_sequence.get(obs["gateway"]["sequence"])
        if value is None or not math.isclose(value, math.fsum(m["cost"] for m in marks.values()),
                                             abs_tol=1e-9):
            raise ValueError("snapshot_ledger_mismatch")
    return releases, parsed[-1][1]["gateway"]["sampled_at"]


def release_groups(origin, parsed, releases):
    """Group cohort marks by (disappearance interval, cost) with candidate ledger events."""
    start = origin["index"]
    pending = set(origin["cohort"])
    groups, unresolved = defaultdict(list), []
    for (_, a), (m_b, b) in zip(parsed[start:], parsed[start + 1:]):
        gone = [rid for rid in pending if rid not in m_b]
        for rid in gone:
            groups[(a["gateway"]["sequence"], b["gateway"]["sequence"],
                    origin["cohort"][rid]["cost"])].append(rid)
        pending -= set(gone)
    for rid in pending:
        unresolved.append(rid)
    out = []
    for (lo, hi, cost), members in groups.items():
        events = sorted(t for seq, t, c in releases
                        if lo < seq <= hi and math.isclose(c, cost, rel_tol=1e-9, abs_tol=1e-12))
        if len(events) < len(members):
            raise ValueError("ledger_release_identity")
        out.append(dict(cost=cost, members=members, events=events))
    return out, unresolved


def cumulative_truth(origin, groups, unresolved, coverage_end, horizon):
    target = origin["t0"] + horizon
    lo = hi = 0.0
    for g in groups:
        done = sum(t <= target for t in g["events"])
        extra = len(g["events"]) - len(g["members"])
        lo += g["cost"] * max(0, done - extra)
        hi += g["cost"] * min(done, len(g["members"]))
    if target > coverage_end:
        hi += sum(origin["cohort"][rid]["cost"] for rid in unresolved)
    return lo, hi


def mark_label(rid, groups, unresolved, coverage_end, target):
    for g in groups:
        if rid in g["members"]:
            if len(g["events"]) == 1 or target >= g["events"][-1]:
                return int(target >= g["events"][-1])
            return 0 if target < g["events"][0] else None
    return 0 if target <= coverage_end else None


def build_dataset(episodes):
    rows, seen = [], {}
    for episode in episodes:
        block, part = episode.get("seed_block"), episode.get("partition")
        if seen.setdefault(block, part) != part:
            raise ValueError("seed_block_partition_leakage")
        origins, parsed = build_origins(episode)
        releases, coverage_end = ledger_releases(episode, parsed)
        for origin in origins:
            groups, unresolved = release_groups(origin, parsed, releases)
            origin["truth"] = {h: cumulative_truth(origin, groups, unresolved, coverage_end, h)
                               for h in HORIZONS}
            origin["labels"] = {(rid, h): mark_label(rid, groups, unresolved, coverage_end,
                                                     origin["t0"] + h)
                                for rid in origin["cohort"] for h in HORIZONS}
            rows.append(origin)
    return rows


# ----------------------------------------------------------------------------
# Train-only fitting
# ----------------------------------------------------------------------------

def _solve(matrix, vector):
    n = len(vector)
    a = [row[:] + [vector[i]] for i, row in enumerate(matrix)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(a[r][col]))
        if abs(a[pivot][col]) < 1e-15:
            raise ValueError("singular_system")
        a[col], a[pivot] = a[pivot], a[col]
        for r in range(n):
            if r != col and a[r][col]:
                f = a[r][col] / a[col][col]
                a[r] = [x - f * y for x, y in zip(a[r], a[col])]
    return [a[i][n] / a[i][i] for i in range(n)]


def _sigmoid(z):
    return 1 / (1 + math.exp(-z)) if z >= 0 else math.exp(z) / (1 + math.exp(z))


def fit_logistic(xs, ys, weights, iterations=50):
    """L2 logistic regression (unpenalized intercept) by Newton iterations."""
    k = len(xs[0])
    mean = [statistics.fmean(x[j] for x in xs) for j in range(k)]
    scale = [statistics.pstdev([x[j] for x in xs]) or 1.0 for j in range(k)]
    zs = [[1.0] + [(x[j] - mean[j]) / scale[j] for j in range(k)] for x in xs]
    beta = [0.0] * (k + 1)
    total = math.fsum(weights)
    for _ in range(iterations):
        grad = [0.0] * (k + 1)
        hess = [[0.0] * (k + 1) for _ in range(k + 1)]
        for z, y, w in zip(zs, ys, weights):
            p = _sigmoid(sum(b * v for b, v in zip(beta, z)))
            g, h = w * (y - p), w * p * (1 - p)
            for i in range(k + 1):
                grad[i] += g * z[i]
                for j in range(i, k + 1):
                    hess[i][j] += h * z[i] * z[j]
        for i in range(k + 1):
            for j in range(i):
                hess[i][j] = hess[j][i]
            if i:
                grad[i] -= L2 * total / len(ys) * beta[i]
                hess[i][i] += L2 * total / len(ys)
        hess[0][0] += 1e-9
        step = _solve(hess, grad)
        beta = [b + s for b, s in zip(beta, step)]
        if max(abs(s) for s in step) < 1e-8:
            break
    return dict(beta=beta, mean=mean, scale=scale)


def _logit_predict(model, x):
    z = [1.0] + [(v - m) / s for v, m, s in zip(x, model["mean"], model["scale"])]
    return _sigmoid(sum(b * v for b, v in zip(model["beta"], z)))


def support_envelope(train):
    marks = [m for o in train for m in o["cohort"].values()]
    keys = ("reserved", "decode_batch", "prefill_k", "waiting", "budget")
    env = {k: (min(o[k] for o in train), max(o[k] for o in train)) for k in keys}
    env["cohort_n"] = (min(len(o["cohort"]) for o in train), max(len(o["cohort"]) for o in train))
    env["work_shapes"] = sorted({(m["prompt_tokens"], m["max_tokens"]) for m in marks})
    env["planned_budget"] = (min(min(o["planned_budget"].values()) for o in train),
                             max(max(o["planned_budget"].values()) for o in train))
    return env


def ood_reasons(origin, env):
    reasons = []
    for key in ("reserved", "decode_batch", "prefill_k", "waiting", "budget"):
        lo, hi = env[key]
        if not lo - EPS <= origin[key] <= hi + EPS:
            reasons.append(key)
    lo, hi = env["cohort_n"]
    if not lo <= len(origin["cohort"]) <= hi:
        reasons.append("cohort_n")
    shapes = {tuple(s) for s in env["work_shapes"]}
    if any((m["prompt_tokens"], m["max_tokens"]) not in shapes for m in origin["cohort"].values()):
        reasons.append("work_shape")
    lo, hi = env["planned_budget"]
    if any(not lo - EPS <= b <= hi + EPS for b in origin["planned_budget"].values()):
        reasons.append("planned_budget")
    return reasons


def _exact(origin, h):
    lo, hi = origin["truth"][h]
    return lo if math.isclose(lo, hi, abs_tol=1e-12) else None


def fit(train):
    """Every parameter uses Train origins only; calibration/development are refused."""
    if not train or any(o["partition"] != "train" for o in train):
        raise ValueError("fit_requires_train_only")
    fraction, rate_num, rate_den, dropped = {}, 0.0, 0.0, 0
    for h in HORIZONS:
        values = [_exact(o, h) / o["reserved"] for o in train
                  if o["reserved"] > 0 and _exact(o, h) is not None]
        dropped += sum(1 for o in train if o["reserved"] > 0 and _exact(o, h) is None)
        if not values:
            raise ValueError("no_exact_train_truth")
        fraction[h] = statistics.fmean(values)
        rate_num += math.fsum(_exact(o, h) for o in train
                              if o["reserved"] > 0 and _exact(o, h) is not None)
        rate_den += h * len(values)
    logits, label_counts = {}, {}
    for h in HORIZONS:
        xs, ys, ws, ambiguous = [], [], [], 0
        for o in train:
            for rid in o["cohort"]:
                y = o["labels"][(rid, h)]
                if y is None:
                    ambiguous += 1
                    continue
                xs.append(mark_features(o, rid, h))
                ys.append(y)
                ws.append(1 / len(o["cohort"]))
        if len(set(ys)) < 2:
            raise ValueError("degenerate_train_labels")
        logits[h] = fit_logistic(xs, ys, ws)
        label_counts[h] = dict(used=len(ys), ambiguous_excluded=ambiguous)
    return dict(fraction=fraction, fluid_rate=rate_num / rate_den, logistic=logits,
                support=support_envelope(train), interval_truth_excluded=dropped,
                label_counts=label_counts, train_blocks=sorted({o["seed_block"] for o in train}))


def predict(params, origin):
    """None when the origin is outside Train support (abstain, never extrapolate)."""
    reasons = ood_reasons(origin, params["support"])
    if reasons:
        return None, reasons
    r = origin["reserved"]
    rate = origin["history_rate"] if origin["history_rate"] is not None else params["fluid_rate"]
    out = dict(train_fraction={}, fluid_history={}, batch_aware={})
    previous = {rid: 0.0 for rid in origin["cohort"]}
    for h in HORIZONS:
        out["train_fraction"][h] = r * params["fraction"][h]
        out["fluid_history"][h] = min(r, rate * h)
        total = 0.0
        for rid, mark in origin["cohort"].items():
            p = max(previous[rid], _logit_predict(params["logistic"][h], mark_features(origin, rid, h)))
            previous[rid] = p
            total += mark["cost"] * p
        out["batch_aware"][h] = total
    return out, []


# ----------------------------------------------------------------------------
# Block-level evaluation, calibration and OOD accounting
# ----------------------------------------------------------------------------

def _interval_error(pred, lo, hi):
    best = 0.0 if lo <= pred <= hi else min(abs(pred - lo), abs(pred - hi))
    return best, max(abs(pred - lo), abs(pred - hi))


def score(params, rows):
    """Equal-weight mean over h of |pred-actual|/R_origin, episode -> block -> mean."""
    per_block = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    counts = defaultdict(int)
    for o in rows:
        if o["reserved"] <= 0:
            counts["zero_reserved_origins"] += 1
            continue
        pred, reasons = predict(params, o)
        if pred is None:
            counts["ood_abstained"] += 1
            for reason in reasons:
                counts["ood_" + reason] += 1
            continue
        counts["scored_origins"] += 1
        for model, values in pred.items():
            errs = [_interval_error(values[h], *o["truth"][h]) for h in HORIZONS]
            per_block[model][o["seed_block"]][o["episode_id"]].append(
                (statistics.fmean(e[0] for e in errs) / o["reserved"],
                 statistics.fmean(e[1] for e in errs) / o["reserved"]))
    result = {}
    for model, blocks in per_block.items():
        block_scores = {}
        for block, episodes in blocks.items():
            means = [(statistics.fmean(v[0] for v in e), statistics.fmean(v[1] for v in e))
                     for e in episodes.values()]
            block_scores[block] = dict(lower=statistics.fmean(m[0] for m in means),
                                       upper=statistics.fmean(m[1] for m in means))
        result[model] = dict(blocks=block_scores,
                             lower=statistics.fmean(b["lower"] for b in block_scores.values()),
                             upper=statistics.fmean(b["upper"] for b in block_scores.values()))
    return dict(models=result, counts=dict(counts))


def _quantile(values, q):
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, math.ceil(q * (len(ordered) + 1)) - 1))
    return ordered[index]


def calibrate(params, rows, model="batch_aware"):
    """Split residual quantiles from Calibration blocks only (descriptive, no guarantee)."""
    if any(o["partition"] != "calibration" for o in rows):
        raise ValueError("calibration_requires_calibration_only")
    bands = {}
    for h in HORIZONS:
        residuals = []
        for o in rows:
            exact = _exact(o, h)
            pred, _ = predict(params, o) if o["reserved"] > 0 else (None, None)
            if pred is not None and exact is not None:
                residuals.append((exact - pred[model][h]) / o["reserved"])
        if not residuals:
            raise ValueError("no_calibration_residuals")
        bands[h] = dict(lower=_quantile(residuals, ALPHA / 2), upper=_quantile(residuals, 1 - ALPHA / 2),
                        n=len(residuals))
    return dict(model=model, alpha=ALPHA, bands=bands,
                blocks=sorted({o["seed_block"] for o in rows}))


def coverage(params, calibration, rows):
    per_block = defaultdict(lambda: [0, 0, 0])
    for o in rows:
        if o["reserved"] <= 0:
            continue
        pred, _ = predict(params, o)
        if pred is None:
            continue
        for h in HORIZONS:
            band = calibration["bands"][h]
            lo = pred[calibration["model"]][h] + band["lower"] * o["reserved"]
            hi = pred[calibration["model"]][h] + band["upper"] * o["reserved"]
            t_lo, t_hi = o["truth"][h]
            cell = per_block[o["seed_block"]]
            cell[2] += 1
            cell[0] += lo - EPS <= t_lo and t_hi <= hi + EPS     # covered for every feasible truth
            cell[1] += t_hi >= lo - EPS and t_lo <= hi + EPS      # covered for some feasible truth
    return {block: dict(lower=c[0] / c[2], upper=c[1] / c[2], n=c[2]) for block, c in per_block.items()}


def evaluate(episodes):
    rows = build_dataset(episodes)
    split = {p: [o for o in rows if o["partition"] == p] for p in PARTITIONS}
    params = fit(split["train"])
    result = dict(schema="nv3-opus-release-model-v1", horizons=list(HORIZONS),
                  train_blocks=params["train_blocks"], fluid_rate_cost_per_s=params["fluid_rate"],
                  label_counts={str(h): v for h, v in params["label_counts"].items()},
                  interval_truth_excluded_from_fit=params["interval_truth_excluded"],
                  scores={p: score(params, split[p]) for p in PARTITIONS if split[p]},
                  native_performance_accepted=False, statistical_guarantee=False,
                  mpc_accepted=False)
    if split["calibration"]:
        cal = calibrate(params, split["calibration"])
        result["calibration"] = dict(cal, bands={str(h): v for h, v in cal["bands"].items()})
        if split["development"]:
            result["development_coverage"] = coverage(params, cal, split["development"])
    return result


# ----------------------------------------------------------------------------
# Useful / physical / tail forward-work accounting (does not relax the v2 audit)
# ----------------------------------------------------------------------------

def forward_work_accounting(request, steps, worker_rows, *, request_id, max_tail_tokens=1):
    """Partition one natural-EOS request's executed positions.

    useful = prompt + delivered_output - 1 (the last sampled token is never fed back);
    physical = contiguous executed positions; tail = physical - useful. The legacy strict
    audit (physical == useful) is reported unchanged. A tail is only *accounted* when it is
    a single contiguous decode position scheduled before the engine finish and matched to
    an executed worker forward. GPU spans are not absolute clocks or exclusive service.
    """
    prompt, output = request["input_tokens"], request["output_tokens"]
    finished = request.get("finished")
    problems = []
    if request.get("finish_reason") != "stop" or type(output) is not int or output <= 0:
        problems.append("not_natural_eos_output")
    workers = {r["step_id"]: r for r in worker_rows}
    progress, useful_steps, tail_steps = 0, 0, []
    useful = prompt + output - 1
    for step in sorted(steps, key=lambda s: s["start"]):
        mine = [w for w in step["work"] if w["request_id"] == request_id]
        if not mine:
            continue
        if len(mine) != 1 or mine[0]["position"] != progress or mine[0]["tokens"] <= 0:
            problems.append("position_gap_repeat_or_split")
            continue
        work = mine[0]
        worker = workers.get(step["step_id"])
        if (worker is None or (worker.get("executed_positions") or {}).get(request_id) != work["position"]
                or (worker.get("executed_counts") or {}).get(request_id) != work["tokens"]):
            problems.append("unmatched_worker_forward")
        if work["position"] + work["tokens"] <= useful:
            useful_steps += 1
        elif work["position"] >= useful:
            tail_steps.append((step, work, worker))
        else:
            problems.append("step_straddles_useful_boundary")
        progress = work["position"] + work["tokens"]
    tail = progress - useful
    if tail < 0:
        problems.append("missing_useful_work")
    if tail > max_tail_tokens:
        problems.append("unexplained_tail_work")
    tail_ok = True
    for step, work, worker in tail_steps:
        if not _finite(finished):
            problems.append("finish_time_unavailable")
            tail_ok = False
        elif not step["start"] < finished:
            problems.append("tail_scheduled_after_finish")
            tail_ok = False
        if work["tokens"] != 1 or worker is None:
            tail_ok = False
    return dict(useful_positions=useful, physical_positions=progress, tail_positions=tail,
                useful_steps=useful_steps, tail_steps=len(tail_steps),
                legacy_strict_audit_valid=progress == useful and not problems,
                tail_accounted=not problems and 0 <= tail <= max_tail_tokens and tail_ok,
                problems=sorted(set(problems)),
                scope="Executed positions per request; GPU forward spans are per-step labels, "
                      "not absolute clocks or exclusive service durations.")


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 1:
        raise SystemExit("usage: native_release_model.py EPISODES.json")
    with open(argv[0], encoding="utf-8") as handle:
        episodes = json.load(handle)
    print(json.dumps(evaluate(episodes), indent=2, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
