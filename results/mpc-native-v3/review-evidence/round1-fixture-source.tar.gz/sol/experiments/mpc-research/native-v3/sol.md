# Sol NV3 independent round 1: identifiable outcomes before predictive control

## Status and evidence boundary

Independent proposal and bounded offline audit, not a new synthetic benchmark,
native model fit, ten-hour receipt, qualification pass, or MPC win. No NV3 peer
proposal was read. Scope is this report and its sibling
`native_experiment_audit.py` / `test_native_experiment_audit.py` only.
No Gateway, observer, core, configuration, remote, or GPU change.
Mayor owns Beads, SSH, execution, and paid-resource decisions.

Read campaign at base `10f2fb0`, native-v2
`decision-and-next-native-protocol.zh-TW.md`, my previous
`round3/sol-revision.md`, actual
`../native-identification-and-model-falsification.zh-TW.md`,
`prefill_lab/contracts.py`, and the native-v2 collector.
The serial HTTP-service interpretation remains falsified: the old empty-start
90s arm delivered 2449 natural completions against that model's upper bound
2004. That does not falsify predictive control or all queueing models.
The old commit-progress model did not beat persistence consistently and used
realized sampling gaps, not fixed future horizons.

Mayor's shared new observation is treated as reported native evidence, not
reproduced locally: exact joined UUID, prompt4096/output32/natural EOS; 34
physical steps, two prefill and 32 decode; contiguous executed end4128 versus
delivered input minimum4127. The final placeholder was1, its host forward
wrapper started before EOS and output commit followed EOS, with a matched
executed CUDA forward. The v2 audit is still FALSE. No local raw capture for
this new observation was supplied; the executable test reproduces the
accounting case with explicitly artificial timestamps, not native timing.

Authorized deployment is the sole user Pod RTX4090/24564MiB/driver595.91.07,
vLLM0.30.0, Torch2.13.0, Transformers5.22.1 and restored pinned Qwen4B.
These shared environment facts are not a loaded-revision or performance
attestation. Final heldout160021-160024 is not read, fitted, or evaluated.

## 1. Observable batch state and transition

Use a receipt-cut history, not a claimed fully observed GPU Markov state.
At origin k retain:

| Component | Available state and provenance | Unresolved part |
|---|---|---|
| Admission | Exact UUID/original-cost ledger; pending/applied cap version; command fence; receipt timestamp | Accepted but unmatched native work stays explicitly unknown |
| Queue | Prompt tokens and recipe, admission age, waiting/admitted-not-first bins | Scheduler order not inferred from HTTP residence |
| Decode | Joined physical request, delivered output so far, context/progress bins, most recent batch participation | Residual output/EOS and pending physical work remain latent |
| Batch history | Last received prefill query-token/chunk-size distribution, decoder/context distribution, placeholder count if observable | Post-drain execution spans are labels, not live features |
| Capture health | Source/epoch/clock, dropped/pending/overflow flags, receipt age/width | Missing values are not zero workload |
| Environment | Receipt-qualified runtime identity and available temperature/clock timeline | Old/partial NVML is not complete environmental control |

Costs16/32 are whole-request reservation budgets, NOT concurrency, scheduler
token limits, or KV bytes. Exact transitions retain old costs on cap reduction:

```
R_next = R + sum(actual admitted original costs) - sum(actual released original costs)
admit only when R + original_cost <= actually_applied_cap
```

No extra overshoot allowance and no forced eviction when `R > reduced_cap`.
Engine EOS, HTTP terminal, output commit, and ledger release remain separate
events. Use native host timestamps only within their qualified domain; join
client/native clocks by exact identity and receipt brackets, not subtraction.

Predict the distribution of cost release, first-content deadline passage,
natural complete-good count, physical progress, and tail incidence jointly
conditioned on this history and a supported assigned cap program. A bounded
stratified/regularized direct response model is the first candidate; a
batch-aware semi-Markov extension is warranted only if phase/history ablation
improves block-held-out forecasts. This report does not implement or fit either.
Latent EOS/tail uncertainty is retained rather than assigning every output
token a deterministic exclusive-service coefficient.

## 2. Useful, physical, and tail-work accounting

Keep the v2 `audit_capture` untouched, including its equality failure. A new
versioned descriptive ledger can reconcile without retrospectively passing it:

* **Delivered-useful input minimum**: `prompt + delivered_output - 1` under the
  declared no-cache/no-speculation protocol. This is a token-position minimum,
  not measured GPU demand or exclusive service duration.
* **Physical input work**: contiguous, exact matched scheduler/worker input
  positions/counts with resolved executed CUDA forward evidence. Preserve
  all34 steps and their identity; do not delete the final step.
* **Undelivered tail input**: physical positions beyond that minimum, with
  request/step evidence that no delivered output came from that work. A
  placeholder alone is insufficient. Label unexplained excess as failed,
  not generic "async tolerance."

The bounded `work_accounting` diagnostic supports only the shared
one-placeholder extra-input case: exact single extra position, matched
execution, native host clock, forward wrapper start before EOS, commit at/after
EOS, and independently determined no delivered output from that step.
It outputs4127/4128/1 and `old_final_progress_equal=False` for the structural
fixture, with qualification explicitly false. Extra/gapped/replayed/unmatched
work fails closed. Those timestamps do NOT place GPU execution on the host
clock: GPUelapsed is a relative current-stream span, not an absolute clock,
other-stream coverage, or complete sampling/transport service.

Mayor's future adapter must retain raw scheduler and worker rows, verify
actual_tokens/counts/positions, EOS/output mapping, step digest and worker/run
identity before normalization. Caller-provided booleans are attestations, not
independently verified native joins. OFF captures without step evidence can
qualify outcomes but cannot qualify this physical ledger.

Falsification experiments, not relaxed acceptance:

1. Repeat natural EOS with different actual output lengths, prompt lengths
   and observed batch compositions. Predict zero/one tail incidence before
   seeing labels; distinguish useful decode steps from physical decode steps.
2. Include mixed prefill/decode and pending-async cases. Test whether excess
   is always the last one-placeholder input or sometimes an earlier/multi-step
   phenomenon; the latter invalidates this bounded reconciliation contract.
3. Stop/abort/length-finish controls remain separate cohorts. Their drain work
   must not be mislabeled as natural EOS or dropped from costs.
4. Independently verify no repeated/gapped positions, no mismatched actual
   worker counts, and executed versus merely scheduled extra work. Deep-trace
   confirmation in a separate diagnostic epoch may qualify execution scope,
   but does not establish unprofiled timing or observer equivalence.

## 3. Response, uncertainty, and full-offered outcomes

Freeze every offered logical ID, physical HTTP-attempt UUID, prompt recipe
SHA, prompt/output limits, scheduled origin and window before execution.
Each physical attempt occurs once globally; identical logical trace IDs across
paired arms are intentional. Do not reoffer after ambiguous BEGIN/POST.
Retain a terminal/censor row for every offer; missing/extra/duplicate rows fail
the audit rather than improving a conditional denominator.

Natural complete-good requires positive integer output, exact successful Chat
UUID, complete non-error stream, finite ordered same-client-clock chronology,
matching prompt/limits, stop reason plus independent native EOS evidence,
scheduled-origin TTFT<=0.5s and request-mean
`(terminal-first)/(output-1)<=0.05s`; one token has TPOT0.
Last chunk is NOT substituted for terminal. Token-gap/P99 claims are absent.
Length-finished outputs are labeled truncated and count0 for this frozen
natural-complete primary outcome; report their complete response counts
separately rather than discarding them. Reject/error/cancel/client timeout
count0. Timeout is a resolved HTTP failure, not proof the engine drained:
physical-work and release labels may remain censored.

Right-censoring yields lower/upper good-count bounds, not assumed success or
imputed native completion. A first token already past TTFT has upper0.
Otherwise conservative upper1 is retained. Report late drain completions in
the original offered cohort; dividing cohort good by its offered window is
not a steady-state capacity claim.

Joint predictive uncertainty should use whole held-out block trajectories,
not independent token/request residuals. Fit on Train; choose features on
grouped Train folds; calibrate on disjoint Calibration blocks; select policy
and continuation only on Development. Report empirical coverage and miss
rates with the block count, not certified chance constraints.

## 4. One-step, multi-step, action ranking, and OOD evaluation

Log forecasts at fixed origins before labels exist, with source hash, model
hash, feature receipt cut, plan, and prediction publication time. Do not input
realized future sampling gaps, final output lengths, post-drain spans, future
offered tapes, or outcomes of paired counterfactual arms.

Primary predictive endpoint: then-live cumulative original-cost release at
1/3/5s, normalized by positive origin reservation and averaged per independent
block. Zero-reservation origins are a separate stratum. Secondary: natural-good
count errors, deadline Brier/reliability, physical/tail incidence, joint
trajectory coverage and ranking of actually supported plans. Predicting token
progress well does not establish release accuracy or control goodput.

Compare ledger/history-only, persistence, hold-current empirical response and
batch-history extension under identical origins and labels. Publish one-step
and free-running multi-step errors separately; do not feed actual intermediate
states to a purported multi-step rollout. Assess calibration before maximizing
over plans, because ranking/selection can exploit model error.

OOD: withheld prompt/output combinations, unseen mixture/order, burst and
recovery, accepted-unmatched work, altered observer source/epoch and available
thermal/clock shifts. Bounds must come from qualified Train/Calibration support,
not invented KV thresholds. Abstain on missing identity, stale/unknown work,
unseen history/action support, unresolved labels or capture overflow.
Reject fitting if supported binding states are too few; state aliasing is a
measurable limitation, not a reason to invent latent features.

## 5. Strong One-move versus MPC, causal support, safe deployment

Only after model qualification, compare Fixed16, development-selected
best-supported-fixed, development-selected reactive, strong One-move, and MPC.
One-move and MPC share 5s forecast window, same uncertainty trajectories,
future-arrival LAW (not realized tape), constraints, tail scoring, control
frequency, and development-frozen continuation. One-move frees its first move;
MPC may free two/three future moves only where sequence support exists.
Both apply just their first move and replan at the same rate. No deliberately
poor Fixed16 continuation or short-window straw baseline.

First run randomized open-loop LL/LH/HL/HH cap16/32 sequences from verified
drained starts, paired common offered tapes within fresh independent workload
blocks, randomized arm order with washout/drain and exact application fences.
Include literal-disabled/enabled-OFF/LIGHT ablations in separate service
epochs and same-action repeats. Repeats estimate within-block EOS/observer
variation, NOT independent seeds. Actual batch composition is a mediator:
randomized nominal bursts do not make a batch-duration causal coefficient.
Sequence ITT effects do not license rolling same-state counterfactuals after
states have diverged; unsupported policy plans remain masked.

Before closed-loop outcomes: freeze configuration hashes, metric, contrasts,
minimum useful effect, independent-block sampling and randomization, handling
of censoring, multiplicity and precision plan from Development variance.
The paired module estimates equal-block right-minus-left natural-good/window,
block-resampled approximate percentile95% CI and exact two-sided block
sign-flip p for a sharp no-effect null under the stated exchangeability design.
This exact enumeration specifically requires independent fair pair-order
coins and no carryover/order-by-policy effect after qualified washout. A
balanced/constrained randomization has a different assignment space and must
not be passed to this routine as independent flips.
It rejects cloned block/seed/randomization unit, repeated logical tapes,
physical UUID reuse, mismatched paired tapes/windows/SLOs, changed frozen
comparison configuration and unrandomized declarations. It withholds CI/p
whenever any offered outcome is censored.

These are guards against obvious pseudoreplication, NOT proof of physical
independence, random assignment, or truthful provenance. Mayor must verify raw
receipts and actual independent block generation. Equal synthetic effects can
produce a degenerate bootstrap interval; it is not a variance or significance
guarantee. Four independent pairs have minimum two-sided exact p0.125, not
0.05. No "superior", "equivalent", or "MPC impossible" classifier exists.
The exact sign-flip routine intentionally caps at16 blocks; a larger frozen
final protocol needs a separately reviewed inference implementation, not
splitting into batches or silently treating approximate p as exact.
Do not take this exploratory pairwise p as multiplicity-adjusted evidence for
winning against all baselines.

Report offered/accept/reject/failure/natural/truncated/censored counts, SLO
quantiles, tail work, action binding incidence, affected offered mass, ranking
errors, full observation-to-solve-to-persist-to-POST-to-fence cost, deadline
fallback, oscillation and recovery. Small first-action disagreement is not a
bound on benefit without affected mass and outcome consequences.

No deployment authority from this module. Candidate first runs shadow-only,
then a separately permitted bounded trial with rollback to the best
development-supported fixed/reactive policy. Keep existing expiry, memory,
timeout, observation completeness and source fences. Unknown work or OOD
invokes qualified fallback; lowering cap does not evict old reservations.
Uncalibrated KV/joint risk is not declared hard-safe. Mayor alone runs GPU/API
work and manages paid time; no claimed ten-hour elapsed experiment or quote.

## Local source/test receipt

Owned directory: `experiments/mpc-research/native-v3/`.
Exact implementation/test SHA256:

```
6abb94a4fbc1f3e238cd2d4687e996829304afe669b38efba14f2ca29074a554  native_experiment_audit.py
da6705c687e8d4fa8aa3df072e751f6c141d1f300e4d9eb5f374b51c289ee96e  test_native_experiment_audit.py
```

Executed local command:

```
python3 -m unittest discover -s experiments/mpc-research/native-v3 \
  -p test_native_experiment_audit.py -v
```

Result: **15 tests passed**, CPython3.14.4; outcome, clone/leakage,
randomization, exact four-block p floor, censored inference, and physical
tail counterexamples. These are standard-library CPU unit tests, not native
measurements. `python` was absent and `python3 -m pytest` reported missing
pytest, so the existing unittest-compatible tests were run with the built-in
runner without installing or changing dependencies.

Full Linux CPU acceptance was not executed: it requires CPython3.12, a clean
checkout and local port checks; this assigned offline scope forbids socket
exploration and includes pre-existing untracked `.beads/` / `.runtime/`.
No full-suite, lint-tool, GPU, deployment or statistical qualification claim.
Those pre-existing paths remain untouched. Only the three owned files are
staged for a local commit with the Copilot trailer, retained for Mayor review.
Mayor can retrieve its exact commit from this branch's HEAD and independently
check the recorded implementation/test hashes. Bead status is not mutated:
Mayor retains in_progress for peer review.

Persistence receipt: the environment automatically checkpointed the owned
source/tests/report before the explicit commit attempt; that attempt found
nothing staged. Verified checkpoint
`c8ef4ce06a36d381882ecf68799913855923bcde` contains the exact source/test hashes
above and matches the worktree. This receipt update is committed separately
with the required Copilot trailer; existing automatic commits are not amended.
