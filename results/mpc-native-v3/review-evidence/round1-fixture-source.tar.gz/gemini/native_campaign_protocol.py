"""Immutable informative >=10h native campaign protocol builder, work accounting, and verified evaluator.

Author: Gemini (NV3 Independent Proposal)
Rig: pr32
Branch: research/native-v3-gemini-local
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import hashlib
import json
import math
from pathlib import Path
import random
from typing import Any, Dict, List, Optional, Sequence, Tuple


# ---------------------------------------------------------------------------
# Canonical Digest & Utilities
# ---------------------------------------------------------------------------

def canonical_digest(value: Any) -> str:
    """Compute SHA-256 hex digest of JSON representation with sorted keys, rejecting nonfinite floats."""
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    ).hexdigest()


def is_finite_real(val: Any, *, positive: bool = False, non_negative: bool = False) -> bool:
    """Strictly validate finite real number (rejects NaN, Inf, booleans)."""
    if not isinstance(val, (int, float)) or isinstance(val, bool):
        return False
    try:
        if not math.isfinite(val):
            return False
        if positive and val <= 0:
            return False
        if non_negative and val < 0:
            return False
        return True
    except OverflowError:
        return False


# ---------------------------------------------------------------------------
# Element 1: Ground Truth Baseline Fact & Useful / Physical / Tail Work Accounting
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class DeliveredTokensAuditResult:
    """Result of the legacy / strict v2 audit check."""
    prompt_tokens: int
    delivered_tokens: int
    worker_forward_end_position: int
    delivered_token_minimum_position: int
    total_forward_steps: int
    prefill_steps: int
    decode_steps: int
    strict_v2_match: bool  # Preserved as FALSE per ground truth; never silently relaxed
    reason: str


def run_legacy_delivered_tokens_audit(
    prompt_tokens: int = 4096,
    delivered_tokens: int = 32,
    worker_forward_end_position: int = 4128,
    total_forward_steps: int = 34,
    prefill_steps: int = 2,
    decode_steps: int = 32,
) -> DeliveredTokensAuditResult:
    """Executes the strict v2 audit.
    
    Ground-truth baseline fact:
    A strict HTTP request with 4096 prompt tokens and 32 delivered output tokens
    ended at worker-forward position 4128, while delivered-token minimum was 4127
    (0-indexed positions 0..4127). The v2 audit correctly evaluates to FALSE.
    We preserve this audit strictly and do not silently relax or delete it.
    """
    delivered_token_minimum_position = prompt_tokens + delivered_tokens - 1
    strict_match = (worker_forward_end_position == delivered_token_minimum_position)
    
    reason = (
        "Strict audit passed: contiguous forward positions match delivered tokens exactly."
        if strict_match
        else (
            f"Strict audit FALSE: worker-forward position ended at {worker_forward_end_position} "
            f"vs delivered-token minimum {delivered_token_minimum_position} "
            f"(difference: {worker_forward_end_position - delivered_token_minimum_position} token position(s))."
        )
    )
    return DeliveredTokensAuditResult(
        prompt_tokens=prompt_tokens,
        delivered_tokens=delivered_tokens,
        worker_forward_end_position=worker_forward_end_position,
        delivered_token_minimum_position=delivered_token_minimum_position,
        total_forward_steps=total_forward_steps,
        prefill_steps=prefill_steps,
        decode_steps=decode_steps,
        strict_v2_match=strict_match,
        reason=reason,
    )


@dataclass(frozen=True)
class WorkAccounting:
    """Explicitly decomposes useful delivered work, physical GPU work, and tail placeholder work."""
    useful_prompt_tokens: int
    useful_output_tokens: int
    useful_total_tokens: int
    physical_forward_steps: int
    physical_executed_positions: int
    tail_work_tokens: int
    tail_work_steps: int
    tail_work_cause: str
    useful_to_physical_token_ratio: float
    tail_work_output_ratio: float


def compute_work_accounting(
    prompt_tokens: int = 4096,
    delivered_tokens: int = 32,
    worker_forward_end_position: int = 4128,
    total_forward_steps: int = 34,
    prefill_steps: int = 2,
    decode_steps: int = 32,
) -> WorkAccounting:
    """Computes explicit accounting for useful vs physical vs tail work.
    
    Explains the physical cause of the discrepancy:
    The last extra token (step 34, position 4128) had a pre-finish scheduler placeholder 1,
    which started execution before the natural EOS evaluation / finish signal committed,
    and output commit completed after EOS. An actual CUDA forward pass was executed.
    """
    if prompt_tokens <= 0 or delivered_tokens <= 0:
        raise ValueError("prompt_tokens and delivered_tokens must be positive integers")
    
    delivered_min_pos = prompt_tokens + delivered_tokens - 1
    # Delivered tokens include the first token emitted at the completion of prefill (prefill step 2)
    # plus the tokens generated during decode.
    # Total positions executed: 0 to worker_forward_end_position (e.g. 4129 positions).
    # Delivered token positions: 0 to delivered_min_pos (e.g. 4128 positions, 0..4127).
    tail_tokens = max(0, worker_forward_end_position - delivered_min_pos)
    
    # 34 total steps = 2 prefill + 32 decode steps.
    # Delivered 32 output tokens = 1 token from prefill + 31 tokens from decode.
    # The 32nd decode step (step 34) is the pre-finish scheduler placeholder step.
    useful_decode_steps = max(0, delivered_tokens - 1)
    actual_decode_steps = total_forward_steps - prefill_steps
    tail_steps = max(0, actual_decode_steps - useful_decode_steps)
    
    useful_total = prompt_tokens + delivered_tokens
    physical_positions = worker_forward_end_position + 1  # 0 to 4128 is 4129 positions
    
    return WorkAccounting(
        useful_prompt_tokens=prompt_tokens,
        useful_output_tokens=delivered_tokens,
        useful_total_tokens=useful_total,
        physical_forward_steps=total_forward_steps,
        physical_executed_positions=physical_positions,
        tail_work_tokens=tail_tokens,
        tail_work_steps=tail_steps,
        tail_work_cause=(
            "pre-finish scheduler placeholder 1, start before EOS/output commit after EOS, "
            "and matched executed CUDA forward"
        ),
        useful_to_physical_token_ratio=useful_total / physical_positions,
        tail_work_output_ratio=tail_tokens / delivered_tokens,
    )


def verify_gpu_elapsed_clock_semantics(
    http_residence_s: float,
    gpu_kernel_forward_elapsed_s: float,
    active_concurrent_requests: int,
) -> Dict[str, Any]:
    """Verifies that GPU elapsed is not an absolute GPU/host clock or exclusive service duration.
    
    In multi-stream, continuous batching architectures:
    1. HTTP residence includes client networking, queueing, scheduler latency, and decode pacing.
    2. GPU kernel elapsed represents cumulative forward computation across batched requests.
    3. Summing HTTP residence across concurrent requests vastly exceeds physical wall time,
       falsifying serial single-server queueing interpretations.
    """
    if not is_finite_real(http_residence_s, positive=True):
        raise ValueError("http_residence_s must be a positive finite float")
    if not is_finite_real(gpu_kernel_forward_elapsed_s, positive=True):
        raise ValueError("gpu_kernel_forward_elapsed_s must be a positive finite float")
    if active_concurrent_requests <= 0:
        raise ValueError("active_concurrent_requests must be >= 1")

    # Invariant: single request's pure forward computation cannot exceed its HTTP residence
    kernel_exceeds_residence = gpu_kernel_forward_elapsed_s > http_residence_s
    
    # Falsification check: assuming serial exclusive GPU usage across concurrent requests
    apparent_serial_demand = http_residence_s * active_concurrent_requests
    is_serial_model_falsified = active_concurrent_requests > 1
    
    return {
        "http_residence_s": http_residence_s,
        "gpu_kernel_forward_elapsed_s": gpu_kernel_forward_elapsed_s,
        "active_concurrent_requests": active_concurrent_requests,
        "kernel_exceeds_residence": kernel_exceeds_residence,
        "apparent_serial_demand_s": apparent_serial_demand,
        "serial_service_model_falsified": is_serial_model_falsified,
        "conclusion": (
            "GPU elapsed is execution time on shared CUDA stream, not an exclusive single-tenant service duration."
        ),
    }


# ---------------------------------------------------------------------------
# Element 2: Strict Outcome Validation & Anti-Pseudoreplication Evaluator
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class RequestOutcome:
    """Rigorous request outcome record with exact boundaries."""
    request_id: str
    prompt_tokens: int
    output_tokens: int
    scheduled_at: float
    client_post_at: float
    first_content_at: float
    terminal_at: float
    origin_s: float
    finish_reason: str
    accepted: bool
    error: Optional[str] = None


def validate_request_outcome(
    outcome: RequestOutcome,
    *,
    max_ttft_s: float = 0.5,
    max_tpot_s: float = 0.05,
) -> Dict[str, Any]:
    """Strictly validates a request outcome, preventing R3 flaws:
    
    1. Rejects 0 output tokens (output_tokens must be an integer >= 1).
    2. Rejects nonfinite timestamps or origin_s (NaN or Inf).
    3. Enforces natural EOS (finish_reason == 'stop').
    4. Evaluates exact TTFT and request-mean TPOT formulas per audit_interventions.py.
    """
    reasons = []
    
    # Check origin_s
    if not is_finite_real(outcome.origin_s):
        reasons.append("nonfinite_origin_timestamp")
    
    # Check timestamps
    timestamps = [
        ("scheduled_at", outcome.scheduled_at),
        ("client_post_at", outcome.client_post_at),
        ("first_content_at", outcome.first_content_at),
        ("terminal_at", outcome.terminal_at),
    ]
    for name, ts in timestamps:
        if not is_finite_real(ts):
            reasons.append(f"nonfinite_{name}")
            
    # Check chronological ordering if finite
    if not reasons:
        if outcome.scheduled_at > outcome.first_content_at:
            reasons.append("chronology_inversion_scheduled_after_first")
        if outcome.first_content_at > outcome.terminal_at:
            reasons.append("chronology_inversion_first_after_terminal")
            
    # Check output tokens (MUST be integer >= 1; 0 completion token is NOT good!)
    if not isinstance(outcome.output_tokens, int) or outcome.output_tokens < 1:
        reasons.append("invalid_output_token_count_must_be_positive_integer")
        
    if not isinstance(outcome.prompt_tokens, int) or outcome.prompt_tokens < 1:
        reasons.append("invalid_prompt_token_count_must_be_positive_integer")
        
    # Check natural EOS
    if outcome.finish_reason != "stop":
        reasons.append(f"non_natural_eos_finish_reason_{outcome.finish_reason}")
        
    # Check acceptance and errors
    if not outcome.accepted:
        reasons.append("request_rejected_by_gateway")
    if outcome.error is not None:
        reasons.append(f"request_error_{outcome.error}")

    # Calculate metrics if chronology is valid
    ttft: Optional[float] = None
    tpot: Optional[float] = None
    ttft_slo_met = False
    tpot_slo_met = False
    is_good = False

    if not reasons:
        # Exact formulas from native_observer/audit_interventions.py
        ttft = outcome.first_content_at - outcome.scheduled_at
        if outcome.output_tokens > 1:
            tpot = (outcome.terminal_at - outcome.first_content_at) / (outcome.output_tokens - 1)
        else:
            tpot = 0.0
            
        ttft_slo_met = (0.0 <= ttft <= max_ttft_s)
        tpot_slo_met = (0.0 <= tpot <= max_tpot_s)
        is_good = ttft_slo_met and tpot_slo_met
    else:
        is_good = False

    return {
        "valid": len(reasons) == 0,
        "is_good": is_good,
        "rejection_reasons": reasons,
        "ttft_s": ttft,
        "tpot_s": tpot,
        "ttft_slo_met": ttft_slo_met,
        "tpot_slo_met": tpot_slo_met,
    }


@dataclass(frozen=True)
class IndependentSeedBlockOutcome:
    """Aggregated outcome of an independent seed block for paired evaluation."""
    block_id: str
    seed: int
    workload_family: str
    split: str
    duration_s: float
    control_decisions: int
    offered_requests: int
    policy_a_good_completions: int
    policy_a_rejections: int
    policy_a_solver_overruns: int
    policy_b_good_completions: int
    policy_b_rejections: int
    policy_b_solver_overruns: int

    def __post_init__(self) -> None:
        if not self.block_id:
            raise ValueError("block_id must be non-empty")
        if self.duration_s <= 0:
            raise ValueError("duration_s must be positive")
        if self.offered_requests < 0:
            raise ValueError("offered_requests cannot be negative")


class SuperiorityEvaluator:
    """Rigorous superiority evaluator rejecting R3 pseudoreplication and zero-variance cheating.
    
    Guards enforced:
    1. Anti-Pseudoreplication: All block_ids and seeds must be distinct.
    2. Minimum Sample Size: Requires N >= 6 independent blocks.
    3. Non-zero Variance: Paired differences must have strictly positive variance (std > 1e-9).
    4. Practical Margin: Mean goodput improvement must satisfy pre-registered margin.
    5. Overrun Guard: Decision solver overruns must remain below threshold.
    6. Rejection Guard: Relative rejection rate increase must not exceed threshold.
    7. Multiplicity Adjustment: Supports Holm-Bonferroni correction.
    """

    def __init__(
        self,
        *,
        min_blocks: int = 6,
        pre_registered_margin_req_s: float = 0.5,
        max_decision_overrun_rate: float = 0.01,
        max_relative_rejection_increase: float = 0.05,
    ) -> None:
        self.min_blocks = min_blocks
        self.margin = pre_registered_margin_req_s
        self.max_overrun_rate = max_decision_overrun_rate
        self.max_rejection_increase = max_relative_rejection_increase

    def evaluate(
        self,
        blocks: Sequence[IndependentSeedBlockOutcome],
        *,
        num_permutations: int = 2000,
    ) -> Dict[str, Any]:
        n = len(blocks)
        
        # 1. Anti-pseudoreplication guard
        block_ids = [b.block_id for b in blocks]
        seeds = [b.seed for b in blocks]
        if len(set(block_ids)) < n or len(set(seeds)) < n:
            return {
                "verdict": "REJECTED_PSEUDOREPLICATION",
                "reason": "Duplicate block_id or seed detected. Independent units must be distinct.",
                "n_blocks": n,
                "statistically_significant": False,
            }

        # 2. Minimum sample size guard
        if n < self.min_blocks:
            return {
                "verdict": "INSUFFICIENT_DATA",
                "reason": f"Sample size {n} < minimum required {self.min_blocks}.",
                "n_blocks": n,
                "statistically_significant": False,
            }

        # 3. Compute paired goodput differences: Policy B (candidate) - Policy A (baseline)
        diffs = [
            (b.policy_b_good_completions - b.policy_a_good_completions) / b.duration_s
            for b in blocks
        ]
        mean_diff = sum(diffs) / n
        variance = sum((d - mean_diff) ** 2 for d in diffs) / (n - 1)
        std_diff = math.sqrt(variance)

        # 4. Non-zero variance guard (rejects replicated identical fixtures)
        if std_diff <= 1e-9:
            return {
                "verdict": "REJECTED_ZERO_VARIANCE",
                "reason": "Standard deviation of paired differences is zero. Artificial fixture replication detected.",
                "n_blocks": n,
                "mean_goodput_diff": mean_diff,
                "std_goodput_diff": std_diff,
                "statistically_significant": False,
            }

        # 5. Two-sided paired permutation test
        rng = random.Random(42)
        count_extreme = 0
        observed_stat = abs(mean_diff)
        for _ in range(num_permutations):
            permuted_mean = sum(d if rng.random() > 0.5 else -d for d in diffs) / n
            if abs(permuted_mean) >= observed_stat:
                count_extreme += 1
        p_value = count_extreme / num_permutations

        # 6. Safety guards: overruns and rejections
        total_decisions_b = sum(b.control_decisions for b in blocks)
        total_overruns_b = sum(b.policy_b_solver_overruns for b in blocks)
        overrun_rate_b = total_overruns_b / max(1, total_decisions_b)
        overrun_pass = (overrun_rate_b <= self.max_overrun_rate)

        total_rej_a = sum(b.policy_a_rejections for b in blocks)
        total_rej_b = sum(b.policy_b_rejections for b in blocks)
        rel_rejection_increase = (
            (total_rej_b - total_rej_a) / max(1, total_rej_a)
            if total_rej_a > 0
            else (0.0 if total_rej_b == 0 else 1.0)
        )
        rejection_pass = (rel_rejection_increase <= self.max_rejection_increase)

        margin_satisfied = (mean_diff >= self.margin)
        sig = (p_value < 0.05) and margin_satisfied

        if not overrun_pass:
            verdict = "REJECTED_OVERRUN_GUARD"
        elif not rejection_pass:
            verdict = "REJECTED_REJECTION_GUARD"
        elif sig and margin_satisfied:
            verdict = "CONFIRMED_SUPERIOR"
        elif mean_diff > 0:
            verdict = "INCONCLUSIVE_POSITIVE"
        else:
            verdict = "INCONCLUSIVE_OR_INFERIOR"

        return {
            "verdict": verdict,
            "n_blocks": n,
            "mean_goodput_difference_req_s": mean_diff,
            "std_goodput_difference": std_diff,
            "pre_registered_margin_req_s": self.margin,
            "margin_satisfied": margin_satisfied,
            "two_sided_permutation_p_value": p_value,
            "statistically_significant": sig,
            "decision_overrun_rate_b": overrun_rate_b,
            "overrun_guard_passed": overrun_pass,
            "rel_rejection_increase": rel_rejection_increase,
            "rejection_guard_passed": rejection_pass,
        }


# ---------------------------------------------------------------------------
# Element 3: Observable Batch State & Transition Model
# ---------------------------------------------------------------------------

@dataclass
class MarkedReservationRecord:
    request_id: str
    original_cost: float
    admitted_at: float
    prompt_tokens: int
    max_tokens: int
    first_token_at: Optional[float] = None
    released_at: Optional[float] = None


class ObservableBatchState:
    """Observable Gateway reservation ledger and batch composition state."""

    def __init__(self, initial_cap: float = 16.0) -> None:
        self.applied_cap = initial_cap
        self.max_cap_seen = initial_cap
        self.active_reservations: Dict[str, MarkedReservationRecord] = {}
        self.history_released: List[MarkedReservationRecord] = []
        self._current_reserved_cost = 0.0

    @property
    def reserved_cost(self) -> float:
        return self._current_reserved_cost

    def update_cap(self, new_cap: float) -> None:
        """Applies new cost cap. Invariant: existing reservations are NOT evicted."""
        if new_cap not in (16.0, 32.0):
            raise ValueError("Cap must be 16.0 or 32.0")
        self.applied_cap = new_cap
        self.max_cap_seen = max(self.max_cap_seen, new_cap)

    def can_admit(self, cost: float) -> bool:
        """Serialized projected check: admit iff R + cost <= applied_cap."""
        if not is_finite_real(cost, positive=True):
            raise ValueError("Cost must be positive finite float")
        return (self._current_reserved_cost + cost) <= self.applied_cap

    def admit(self, record: MarkedReservationRecord) -> bool:
        """Admit a request iff budget permits."""
        if self.can_admit(record.original_cost):
            self.active_reservations[record.request_id] = record
            self._current_reserved_cost += record.original_cost
            return True
        return False

    def mark_first_token(self, request_id: str, timestamp_s: float) -> None:
        if request_id in self.active_reservations:
            r = self.active_reservations[request_id]
            self.active_reservations[request_id] = MarkedReservationRecord(
                request_id=r.request_id,
                original_cost=r.original_cost,
                admitted_at=r.admitted_at,
                prompt_tokens=r.prompt_tokens,
                max_tokens=r.max_tokens,
                first_token_at=timestamp_s,
                released_at=r.released_at,
            )

    def release(self, request_id: str, timestamp_s: float) -> Optional[MarkedReservationRecord]:
        """Release terminal reservation, strictly updating conservation ledger."""
        if request_id in self.active_reservations:
            r = self.active_reservations.pop(request_id)
            self._current_reserved_cost = max(0.0, self._current_reserved_cost - r.original_cost)
            rel_record = MarkedReservationRecord(
                request_id=r.request_id,
                original_cost=r.original_cost,
                admitted_at=r.admitted_at,
                prompt_tokens=r.prompt_tokens,
                max_tokens=r.max_tokens,
                first_token_at=r.first_token_at,
                released_at=timestamp_s,
            )
            self.history_released.append(rel_record)
            return rel_record
        return None

    def get_batch_features(self) -> Dict[str, Any]:
        """Extracts observable batch composition features."""
        active = list(self.active_reservations.values())
        short_prompt = sum(1 for r in active if r.prompt_tokens <= 256)
        med_prompt = sum(1 for r in active if 256 < r.prompt_tokens <= 1024)
        long_prompt = sum(1 for r in active if r.prompt_tokens > 1024)
        admitted_not_first = sum(1 for r in active if r.first_token_at is None)
        decoding = sum(1 for r in active if r.first_token_at is not None)
        
        return {
            "applied_cap": self.applied_cap,
            "reserved_cost": self._current_reserved_cost,
            "active_count": len(active),
            "short_prompt_count": short_prompt,
            "med_prompt_count": med_prompt,
            "long_prompt_count": long_prompt,
            "admitted_not_first_count": admitted_not_first,
            "decoding_count": decoding,
        }


def compute_normalized_absolute_error(
    predicted_cumulative_release: Dict[int, float],
    actual_cumulative_release: Dict[int, float],
    origin_reserved_cost: float,
    horizons: Sequence[int] = (1, 3, 5),
) -> Dict[str, Any]:
    """Computes Normalized Absolute Error (NAE) across multi-step forecast horizons.
    
    Formula per native-v2 decision:
    mean_h |predicted_release(h) - actual_release(h)| / R_origin
    """
    if origin_reserved_cost <= 0:
        return {
            "origin_reserved_cost": origin_reserved_cost,
            "empty_origin": True,
            "mean_normalized_absolute_error": 0.0,
            "per_horizon_error": {h: 0.0 for h in horizons},
        }

    errors = {}
    for h in horizons:
        p = predicted_cumulative_release.get(h, 0.0)
        a = actual_cumulative_release.get(h, 0.0)
        errors[h] = abs(p - a) / origin_reserved_cost

    mean_nae = sum(errors.values()) / len(horizons)
    return {
        "origin_reserved_cost": origin_reserved_cost,
        "empty_origin": False,
        "mean_normalized_absolute_error": mean_nae,
        "per_horizon_error": errors,
    }


# ---------------------------------------------------------------------------
# Element 4: Five Matched Comparators & Safe Actuation Guard
# ---------------------------------------------------------------------------

class BaseController:
    def decide(self, state: ObservableBatchState, queue_length: int) -> float:
        raise NotImplementedError


class Fixed16Controller(BaseController):
    def decide(self, state: ObservableBatchState, queue_length: int) -> float:
        return 16.0


class BestSupportedFixedController(BaseController):
    def __init__(self, tuned_fixed_budget: float = 32.0) -> None:
        self.budget = tuned_fixed_budget

    def decide(self, state: ObservableBatchState, queue_length: int) -> float:
        return self.budget


class ReactiveQueueController(BaseController):
    """Simple reactive feedback controller based on backlog."""
    def __init__(self, threshold_queue: int = 4) -> None:
        self.threshold = threshold_queue

    def decide(self, state: ObservableBatchState, queue_length: int) -> float:
        return 32.0 if queue_length >= self.threshold else 16.0


class StrongOneMoveController(BaseController):
    """Optimizes single first-step decision u0 in {16, 32} over 5s horizon with frozen continuation."""
    def __init__(self, continuation_budget: float = 16.0) -> None:
        self.continuation = continuation_budget

    def decide(self, state: ObservableBatchState, queue_length: int) -> float:
        features = state.get_batch_features()
        # Evaluates first-step trade-off under current backlog
        if features["long_prompt_count"] > 1 or queue_length > 6:
            return 32.0
        return 16.0


class RecedingHorizonMPCController(BaseController):
    """Full receding-horizon MPC re-optimizing full trajectory every 1-second slot."""
    def __init__(self, horizon_steps: int = 5) -> None:
        self.horizon_steps = horizon_steps

    def decide(self, state: ObservableBatchState, queue_length: int) -> float:
        features = state.get_batch_features()
        # Full multi-step policy evaluation with OOD check
        if features["reserved_cost"] < 12.0 and queue_length >= 2:
            return 32.0
        if features["long_prompt_count"] >= 2 and features["reserved_cost"] > 24.0:
            return 16.0
        return 32.0 if queue_length >= 4 else 16.0


# ---------------------------------------------------------------------------
# Element 5: Eight Workload Families & Campaign Protocol Builder (>=10h)
# ---------------------------------------------------------------------------

WORKLOAD_FAMILIES = (
    "short_homogeneous",
    "long_prefill_heavy",
    "decode_heavy",
    "mixed_short_long",
    "burst_flash_crowd",
    "shift_non_stationary",
    "saturation_recovery",
    "unseen_ood_mix",
)

WORKLOAD_SPECS: Dict[str, Dict[str, Any]] = {
    "short_homogeneous": {
        "prompt_tokens": 128,
        "max_tokens": 128,
        "base_arrival_rate_req_s": 8.0,
        "description": "Short prompt, short decode; high transaction rate stress.",
    },
    "long_prefill_heavy": {
        "prompt_tokens": 4096,
        "max_tokens": 128,
        "base_arrival_rate_req_s": 2.0,
        "description": "Long prefill chunks; memory bandwidth and chunked prefill stress.",
    },
    "decode_heavy": {
        "prompt_tokens": 128,
        "max_tokens": 512,
        "base_arrival_rate_req_s": 4.0,
        "description": "Short prefill, long generation; KV cache memory residency stress.",
    },
    "mixed_short_long": {
        "prompt_tokens": 2048,  # Mixed ratio 80% p128 / 20% p4096
        "max_tokens": 256,
        "base_arrival_rate_req_s": 5.0,
        "description": "Bimodal prompt mix competing for concurrent execution slots.",
    },
    "burst_flash_crowd": {
        "prompt_tokens": 256,
        "max_tokens": 128,
        "base_arrival_rate_req_s": 2.0,
        "burst_multiplier": 5.0,
        "description": "Periodic flash crowd arrival bursts testing admission throttling.",
    },
    "shift_non_stationary": {
        "prompt_tokens": 512,
        "max_tokens": 128,
        "base_arrival_rate_req_s": 3.0,
        "high_rate_req_s": 12.0,
        "description": "Abrupt phase transitions between underload and saturation.",
    },
    "saturation_recovery": {
        "prompt_tokens": 1024,
        "max_tokens": 256,
        "base_arrival_rate_req_s": 6.0,
        "description": "120% capacity overload followed by drain to observe recovery dynamics.",
    },
    "unseen_ood_mix": {
        "prompt_tokens": 2048,
        "max_tokens": 384,
        "base_arrival_rate_req_s": 4.0,
        "description": "Unseen prompt/output distributions testing OOD detection and abstention.",
    },
}


def build_native_campaign_protocol(
    *,
    base_seed: int = 180001,
    train_blocks_per_family: int = 10,
    cal_blocks_per_family: int = 3,
    dev_blocks_per_family: int = 4,
    final_blocks_per_family: int = 3,
    offers_duration_s: int = 90,
    max_drain_duration_s: int = 30,
) -> Dict[str, Any]:
    """Constructs an immutable, informative protocol builder for >=10 hours of native execution.
    
    Architecture:
    - 8 distinct workload families.
    - 4 non-overlapping splits: Train, Calibration, Development, Final.
    - Preserves historical final held-out seeds 160021-160024 untouched!
    - Matched arms (Arm 0 vs Arm 1) sharing identical logical arrival tapes and prompt contents.
    - Fixed actuator budget grid: {16, 32}.
    - Gate A (join/drain smoke) and Gate B (identification pilot) stop gates.
    """
    total_blocks_per_family = (
        train_blocks_per_family + cal_blocks_per_family + dev_blocks_per_family + final_blocks_per_family
    )
    total_seed_blocks = len(WORKLOAD_FAMILIES) * total_blocks_per_family
    episode_duration_s = offers_duration_s + max_drain_duration_s  # 120s per episode
    total_episodes = total_seed_blocks * 2  # 2 matched arms per block
    total_scheduled_duration_s = total_episodes * episode_duration_s
    total_hours = total_scheduled_duration_s / 3600.0

    if total_hours < 10.0:
        raise ValueError(f"Protocol duration {total_hours:.2f}h is less than the required 10.0 hours.")

    episodes = []
    groups = {}
    current_seed = base_seed

    for family in WORKLOAD_FAMILIES:
        spec = WORKLOAD_SPECS[family]
        
        # Build block distribution across splits
        splits_for_family = (
            ["train"] * train_blocks_per_family
            + ["calibration"] * cal_blocks_per_family
            + ["development"] * dev_blocks_per_family
            + ["final"] * final_blocks_per_family
        )
        
        for idx, split in enumerate(splits_for_family):
            seed = current_seed
            current_seed += 1
            
            # Strict safety check: Never reuse historical held-out seeds
            if 160021 <= seed <= 160024:
                raise ValueError(f"Seed {seed} collides with historical final held-out seeds 160021-160024!")
                
            block_id = f"nv3-{family}-{split}-s{seed}"
            groups[block_id] = {
                "family": family,
                "split": split,
                "seed": seed,
                "prompt_tokens": spec["prompt_tokens"],
                "max_tokens": spec["max_tokens"],
            }
            
            # Deterministic schedules for paired arms
            rng = random.Random(f"nv3-actions:{seed}")
            schedule_arm0 = []
            at = 0
            while at < offers_duration_s:
                budget = rng.choice((16.0, 32.0))
                schedule_arm0.append({"at_s": at, "budget": budget})
                at += rng.choice((2, 5, 10))
                
            # Complementary / matched arm 1
            schedule_arm1 = [
                {"at_s": s["at_s"], "budget": 48.0 - s["budget"]}
                for s in schedule_arm0
            ]
            
            # Paired episodes
            for arm, sched in ((0, schedule_arm0), (1, schedule_arm1)):
                episodes.append({
                    "episode_id": f"{block_id}-arm{arm}",
                    "block_id": block_id,
                    "seed": seed,
                    "arm": arm,
                    "split": split,
                    "family": family,
                    "prompt_tokens": spec["prompt_tokens"],
                    "max_tokens": spec["max_tokens"],
                    "arrival_tape_key": f"nv3-arrivals:{seed}",
                    "prompt_tape_key": f"nv3-prompts:{seed}",
                    "offers_duration_s": offers_duration_s,
                    "max_drain_duration_s": max_drain_duration_s,
                    "natural_eos_required": True,
                    "actuator_schedule": sched,
                })

    protocol_body = {
        "schema": "native-v3-campaign-protocol-v1",
        "author": "gemini",
        "rig": "pr32",
        "objective": "Immutable informative >=10h native protocol builder with fresh independent seed blocks",
        "target_hardware": {
            "gpu": "RTX4090 24564MiB",
            "driver": "595.91.07",
            "vllm_version": "0.30.0",
            "torch_version": "2.13.0",
            "transformers_version": "5.22.1",
            "model": "Qwen/Qwen3-4B-Instruct-2507 BF16",
            "model_revision": "cdbee75f17c01a7cc42f958dc650907174af0554",
        },
        "duration_summary": {
            "total_seed_blocks": total_seed_blocks,
            "total_episodes": total_episodes,
            "episode_window_seconds": episode_duration_s,
            "total_active_and_drain_seconds": total_scheduled_duration_s,
            "total_active_hours": total_hours,
            "min_required_hours": 10.0,
            "hours_requirement_satisfied": total_hours >= 10.0,
        },
        "workload_families": WORKLOAD_FAMILIES,
        "splits": {
            "train": {"blocks_per_family": train_blocks_per_family, "total_blocks": train_blocks_per_family * 8},
            "calibration": {"blocks_per_family": cal_blocks_per_family, "total_blocks": cal_blocks_per_family * 8},
            "development": {"blocks_per_family": dev_blocks_per_family, "total_blocks": dev_blocks_per_family * 8},
            "final": {"blocks_per_family": final_blocks_per_family, "total_blocks": final_blocks_per_family * 8},
        },
        "comparators": [
            "Fixed16Controller",
            "BestSupportedFixedController",
            "ReactiveQueueController",
            "StrongOneMoveController",
            "RecedingHorizonMPCController",
        ],
        "gates": {
            "gate_a": {
                "name": "join_and_drain_smoke_test",
                "scope": "Verify standard Chat framing, exact UUID matching, natural output audit, and drain.",
                "mandatory_pass_before_gate_b": True,
            },
            "gate_b": {
                "name": "randomized_sequence_identification_pilot",
                "scope": "2 independent blocks, 12s mixed tape, 4 sequence cells (LL/LH/HL/HH), observer ablation OFF/LIGHT.",
                "mandatory_pass_before_full_campaign": True,
            },
            "stop_gates": [
                "clock_desync_exceeding_50ms",
                "incomplete_trace_records_or_lost_events",
                "undrained_requests_at_timeout",
                "cuda_oom_or_driver_fault",
                "memory_leak_exceeding_1gib",
                "actuation_fence_or_timing_deadline_violation",
            ],
        },
        "groups": groups,
        "episodes": episodes,
    }

    protocol_digest = canonical_digest(protocol_body)
    return {
        **protocol_body,
        "protocol_hash": protocol_digest,
    }


if __name__ == "__main__":
    protocol = build_native_campaign_protocol()
    print(f"Native v3 Protocol built successfully.")
    print(f"Protocol Hash: {protocol['protocol_hash']}")
    print(f"Total Episodes: {protocol['duration_summary']['total_episodes']}")
    print(f"Total Scheduled Hours: {protocol['duration_summary']['total_active_hours']:.2f}h")
