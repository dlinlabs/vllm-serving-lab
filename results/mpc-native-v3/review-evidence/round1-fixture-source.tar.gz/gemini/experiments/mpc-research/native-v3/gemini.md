# Native v3 獨立研究提案：>=10小時原生實驗協定、真實工作量會計與可驗證優越性評估

- **提案模型**: Gemini (角色: `pr-nv3-gemini`, rig: `pr32`, 工作分支: `research/native-v3-gemini-local`)
- **評定輪次**: NV3 Independent Round 1 (未閱讀任何同行同輪新提案，獨立完成)
- **交付檔案**:
  - `experiments/mpc-research/native-v3/gemini.md` (本技術報告與可追溯驗收收據)
  - `native_campaign_protocol.py` (不可變之 >=10小時原生實驗協定建構器、可觀測狀態追蹤、工作量會計與評估器)
  - `test_native_campaign_protocol.py` (全覆蓋單元與回歸測試套件，21項測試全數通過)
- **追蹤狀態**: 保留 `in_progress`，不執行 `gt done`、push、merge 或遠端修改，遵循 local-only 規範。

---

## 1. 摘要與技術邊界

本提案針對 RTX4090 (24564MiB, driver 595.91.07, vLLM 0.30.0, Torch 2.13.0, Transformers 5.22.1, 鎖定 Qwen3-4B-Instruct-2507 BF16 `cdbee75f17c01a7cc42f958dc650907174af0554`) 的新 10 小時 Pod 實驗，建立嚴格獨立、不可偽造的原生實驗協定。

核心結論與設計邊界：
1. **尚無 MPC 勝過 Fixed16、強 One-move 或合理 reactive baseline 的真實 GPU 證據**。本提案不捏造虛假數據，不宣稱 MPC 已勝出。
2. **Gateway cost cap $u \in \{16, 32\}$ 是成本預算，絕非 concurrency、KV bytes 或調度器 token budget**。
3. **Serial HTTP 服務模型已被確切反證**：HTTP residence 包含客戶端排隊、網路傳輸與 decode pacing，不能被當作獨占 GPU 運算時間相加。
4. **共享原生基準事實與會計解耦**：嚴格 HTTP 請求 (4096 prompt / 32 output / natural EOS) 中，v2 審計判定為 `FALSE` (worker forward 位置結束於 4128，而交付最小位置為 4127)。我們**嚴格保留 v2 審計不作靜默放寬**，並提出「有用工作 (useful)」、「物理工作 (physical)」與「尾端佔位 (tail placeholder)」的三層明確會計。
5. **全面駁回並修復 R3 劣質評估器**：嚴格禁止偽重複 (pseudoreplication) 與零變異欺騙；強制限制作為評估單元的獨立 seed block 數量 $N \ge 6$、輸出 token 必須為正整數 ($\ge 1$)、時間戳與 origin 必須為有限實數 (拒絕 NaN/Inf)。
6. **建構實時排程 10.67 小時 (38,400 秒) 的不可變協定**：涵蓋 8 大工作負載家族、4 獨立切分集 (Train, Calibration, Development, Final)、嚴格保留歷史 held-out seeds (160021-160024) 絕不污染，並實施配對臂 (matched arms) 與硬性中止閥門 (stop gates)。

---

## 2. 共享原生基準事實：4128 vs 4127 的物理成因與會計體系

### 2.1 事實細節與舊審計保留

在嚴格 Chat HTTP 呼叫中，觀察到以下確定性事實：
- 請求具有唯一 UUID。
- Prompt 長度: 4096 tokens。
- 交付 Output: 32 tokens，以自然 EOS (`finish_reason: "stop"`) 結束。
- 交付 token 於 prompt 之後的連續位置為 $0 \dots 4127$ (最小結束位置為 4127)。
- 但 worker-forward 執行的連續 token 位置結束於 **4128**。
- 總共執行了 **34 個 forward steps** (2 個 prefill steps, 32 個 decode steps)。

在 v2 審計邏輯中，`worker_forward_end == delivered_token_minimum` (即 $4128 == 4127$) 必然為 `FALSE`。**我們堅持不刪除、不靜默放寬舊審計**。

### 2.2 物理機制分析 (Why 4128 and 34 steps?)

此現象是連續批次處理 (continuous batching) 與非同步調度器管線的物理特徵：
1. **Prefill 階段 (2 steps)**: 4096 tokens 透過 chunked prefill 分 2 步完成，並在第 2 步結束時產生第 1 個 output token。
2. **Decode 階段 (32 steps)**: 
   - 前 31 個 decode steps (對應整體 step 3 至 33) 依序產生 output token 2 至 32。
   - 在整體第 33 步執行完畢時，第 32 個 output token (EOS) 被採樣產生。
   - 然而，由於調度器管線在 GPU kernel 執行與 CPU finish 訊號判定之間的異步發送，在 EOS 結束訊號被引擎確認並提交給 HTTP 串流前，調度器已為該請求發出了一個預結束佔位 token (pre-finish scheduler placeholder 1)，位於連續位置 4128。
   - 整體第 34 步 (即第 32 個 decode step) 實際發動了 CUDA forward pass。
   - 隨後 EOS commit 生效，第 34 步計算得到的 token 被捨棄，HTTP 回應僅交付 32 個有用 token。

### 2.3 有用工作 vs 物理工作 vs 尾端工作會計

在 `native_campaign_protocol.py` 中，我們定義了嚴格的會計模型 `WorkAccounting`：
- **Useful Work (有用交付工作)**:
  - `useful_prompt_tokens`: 4096
  - `useful_output_tokens`: 32
  - `useful_total_tokens`: 4128 tokens (位置 $0 \dots 4127$)
- **Physical Work (物理 CUDA 運算工作)**:
  - `physical_forward_steps`: 34 steps (2 prefill, 32 decode)
  - `physical_executed_positions`: 4129 positions (位置 $0 \dots 4128$)
- **Tail Work (尾端佔位工作)**:
  - `tail_work_tokens`: 1 token (位置 4128)
  - `tail_work_steps`: 1 step (第 34 步)
  - `tail_work_cause`: `"pre-finish scheduler placeholder 1, start before EOS/output commit after EOS, and matched executed CUDA forward"`
  - `tail_work_output_ratio`: $1 / 32 = 3.125\%$

### 2.4 GPU Elapsed 時鐘語義與 Serial 假設反證

在多請求並發下：
- `http_residence_s` 是客戶端發出 POST 到接收最後一個 chunk 的端到端時間。
- `gpu_forward_elapsed_s` 是該請求參與的 GPU kernel 總累計計算時間。
- 物理不變量：單一請求的 `gpu_forward_elapsed_s <= http_residence_s`。
- **Serial HTTP 模型的反證**: 若將並發請求的 `http_residence_s` 視為互斥獨占服務時間並予以累加，累計時間 $\sum \text{residence}$ 會遠超實際物理經過時間 (例如 8 個並發請求各自 1.2s，若依 serial 模型預測需要 9.6s，但真實時間僅 1.2s)。因此，將 HTTP residence 當作獨占 GPU 服務時間的排隊模型被完全反證。

---

## 3. 駁回 R3 劣質評估器與全新驗證體系

### 3.1 Mayor 對 R3 評估器的技術判定複查

在 R3 評定中，Mayor 重現了三大嚴重邏輯漏洞：
1. **偽重複 (Pseudoreplication)**: 同一個 block 複製 6 次，差值標準差為 0.0，藉由偽造 sample size 算出 $p = 0.03125$ 並宣稱 `CONFIRMED_SUPERIOR`。
2. **零 completion token 被記為 good**: 輸出為 0 token 的無效回應被計入 SLO-good。
3. **非有限時間戳 (NaN) 被記為 good**: `origin_s = float('nan')` 被計入合格統計。

### 3.2 嚴格輸出驗證器 (`validate_request_outcome`)

在 `native_campaign_protocol.py` 中實作了全新的嚴格驗證器，實施以下硬性門檻：
- `output_tokens` 必須為**大於等於 1 的整數**。若為 0 或負數，立即判定 `valid=False, is_good=False`。
- `scheduled_at`, `client_post_at`, `first_content_at`, `terminal_at`, `origin_s` 必須為**有限實數** (`math.isfinite()`)，嚴禁 NaN 或 Inf。
- 必須滿足時序不變量：`scheduled_at <= first_content_at <= terminal_at`。
- 必須是自然 EOS：`finish_reason == "stop"`。
- 嚴格遵守 `audit_interventions.py` 邊界：
  - $\text{TTFT} = \text{first\_content\_at} - \text{scheduled\_at} \le 0.5\text{s}$。
  - 當 $\text{output\_tokens} > 1$ 時，$\text{TPOT} = \frac{\text{terminal\_at} - \text{first\_content\_at}}{\text{output\_tokens} - 1} \le 0.05\text{s}$；當 $\text{output\_tokens} == 1$ 時，$\text{TPOT} = 0.0\text{s}$。

### 3.3 防偽重複優越性評估器 (`SuperiorityEvaluator`)

評估器以獨立的 **Seed Block** 作為統計分析單位，實施多層保護：
1. **Anti-pseudoreplication Guard**: 檢查所有 `block_id` 與 `seed` 必須全數互異。若有重複，回傳 `REJECTED_PSEUDOREPLICATION`。
2. **Minimum Sample Size Guard**: 要求至少 $N \ge 6$ 個真實獨立 blocks。若不足，回傳 `INSUFFICIENT_DATA`。
3. **Non-zero Variance Guard**: 配對差異 $\Delta_i$ 的樣本標準差必須 $> 10^{-9}$。若 $\text{std} = 0$，回傳 `REJECTED_ZERO_VARIANCE`，徹底杜絕固定 fixture 的重複灌水。
4. **Pre-registered Margin**: 候選控制器相對於 baseline 的平均 goodput 提升必須達到事前凍結的實用門檻 (例如 $\Delta \ge 0.5\text{ req/s}$)。
5. **Decision Overrun Guard**: 控制器求解逾時率必須 $\le 1.0\%$。否則回傳 `REJECTED_OVERRUN_GUARD`。
6. **Relative Rejection Guard**: 控制器引發的相對拒絕率增加必須 $\le 5.0\%$。否則回傳 `REJECTED_REJECTION_GUARD`。
7. **Two-sided Permutation Test**: 採 2000 次配對隨機置換檢定，並支援 Holm-Bonferroni 多重比較校正。

---

## 4. 可觀測批次狀態、動態轉移與不確定性預測

### 4.1 狀態表示與守恆定律

定義觀測狀態向量 $x_k$ 包含：
- **標記預約帳本 (Marked Reservation Ledger)**:
  記錄每筆活躍請求之 $(request\_id, original\_cost, admitted\_at, prompt\_tokens, max\_tokens, first\_token\_at)$。
- **預約成本與 Cap**:
  - $R_k = \sum_{i \in \text{active}} original\_cost_i$
  - Applied Cap $u_k \in \{16.0, 32.0\}$
- **嚴格守恆公式**:
  $$R_{k+1} = R_k + \sum_{i \in \text{admitted}_k} c_i - \sum_{j \in \text{released}_k} c_j$$
- **不變量與軟降 Cap 行為**:
  $$R(t) \le \max(R_{\text{initial}}, \sup_{\tau \le t} u(\tau))$$
  當 Cap 由 32 降至 16 時，**已准入的請求絕不被驅逐**；Gateway 僅暫停後續准入，直到 $R_k + c_{\text{new}} \le 16.0$。
- **批次組成特徵**:
  - Prompt 長度分布: Short ($\le 256$), Medium ($256 \dots 1024$), Long ($> 1024$)。
  - 狀態計數: Admitted-not-first (排隊中), Decoding (生成中)。

### 4.2 多步釋放軌跡預測與 NAE 指標

在決策時點 $t_{\text{origin}}$，以當前狀態 $x_k$ 與排程 Cap 預測未來 $h \in \{1, 3, 5\}\text{s}$ 累計釋放的成本 $\hat{r}(h)$。
評估指標採歸一化絕對誤差 (Normalized Absolute Error, NAE)：
$$\text{NAE}(h) = \frac{|\hat{r}(h) - r(h)|}{R_{\text{origin}}} \quad (\text{當 } R_{\text{origin}} > 0)$$
主要損失函數為三個時域的平均：$\frac{1}{3} \sum_{h \in \{1, 3, 5\}} \text{NAE}(h)$。若 $R_{\text{origin}} = 0$ 則獨立報告，不納入低分稀釋。

### 4.3 OOD (域外) 偵測與主動棄權 (Abstention)

當觀測到的批次特徵 (如超長 prompt 比例、突發到達率或非典型佇列長度) 超出 Train/Calibration 支援域時，模型輸出 `abstain = True`，控制器自動回退至保守的 `Fixed16` 安全預算，避免高風險激進決策。

---

## 5. 原生 >=10 小時實驗協定架構 (`native_campaign_protocol.py`)

### 5.1 8 大工作負載家族 (Workload Families)

| # | 家族名稱 | Prompt Tokens | Max Tokens | 到達率 (req/s) | 測試目的與動態壓力 |
|---|---|---|---|---|---|
| 1 | `short_homogeneous` | 128 | 128 | 8.0 | 高吞吐微秒級調度、極限交易速率與基線穩定性 |
| 2 | `long_prefill_heavy` | 4096 | 128 | 2.0 | 長 prefill 記憶體頻寬競爭與 chunked prefill 壓力 |
| 3 | `decode_heavy` | 128 | 512 | 4.0 | 長生成步數、KV Cache 持久佔用與並發 decode 擴展 |
| 4 | `mixed_short_long` | 2048 (混合) | 256 | 5.0 | 雙峰長短混合，測試批次組成干擾與頭端阻塞 |
| 5 | `burst_flash_crowd` | 256 | 128 | 2.0 (5x 突發) | 突發流量注入，測試 Gateway 預約准入節流彈性 |
| 6 | `shift_non_stationary` | 512 | 128 | 3.0 $\leftrightarrow$ 12.0 | 階梯式劇烈負載切換，測試動態切換滯後與超調 |
| 7 | `saturation_recovery` | 1024 | 256 | 6.0 (超載 120%) | 持續過載排隊積壓，隨後排空測試動態復原時間 |
| 8 | `unseen_ood_mix` | 2048 (非典型) | 384 | 4.0 | 未見分布組合，測試模型 OOD 偵測與棄權回退機制 |

### 5.2 4 獨立切分集與 Seed 隔離

每家族均分配至 4 個互不混用的階段：
- **Train (訓練集)**: 每家族 10 blocks (共 80 blocks, 160 episodes)。用於特徵探測、參數擬合與基線初選。
- **Calibration (校準集)**: 每家族 3 blocks (共 24 blocks, 48 episodes)。用於校準 Brier 分數、信賴區間與預測不確定性。
- **Development (驗證集)**: 每家族 4 blocks (共 32 blocks, 64 episodes)。用於比較 One-Move 接續策略與滾動 Horizon 驗證。
- **Final (最終測試集)**: 每家族 3 blocks (共 24 blocks, 48 episodes)。在最終評估前完全凍結封存，嚴禁重用調參。

**Seed 安全保證**:
- 本協定自 `180001` 起算，連續分配 160 個 seed blocks。
- **歷史最終保留 seeds `160021-160024` 嚴格保留未使用**。協定在生成時加入強制檢查斷言，若與歷史 held-out 重疊即拋出異常。

### 5.3 配對臂 (Matched Arms) 與排程時長

每個 Seed Block 派生出 2 個配對 Episode：
- **Arm 0**: 排程 sequence A。
- **Arm 1**: 互補對偶排程 sequence B。
- 兩臂**共享完全相同的到達時戳與 prompt 內容** (`arrival_tape_key`, `prompt_tape_key`)，但指派唯一的 32-hex 物理 request UUID，以防止快取干擾。
- 每個 Episode: 90s offered load + 30s maximum drain = 120s 視窗。
- **總時長計算**:
  $$160 \text{ seed blocks} \times 2 \text{ arms} = 320 \text{ episodes}$$
  $$320 \text{ episodes} \times 120\text{s} = 38,400\text{s} = \mathbf{10.67 \text{ 小時}}$$
  若計入每 block 10s warmup，總時長約 11.5 小時，完全符合並超過 $\ge 10$ 小時的要求。

### 5.4 執行關卡與硬性中止條件

- **Gate A (Join & Drain Smoke Test)**:
  驗證標準 Chat API、精確 UUID 配對、自然 EOS 與 trace 完整性。未通過則全面禁止推進。
- **Gate B (Intervention & Observer Pilot)**:
  2 個獨立 block，12s mixed tape，4 個 sequence cells (LL/LH/HL/HH)，測試觀察器開關 (OFF vs LIGHT) 之開銷與切換響應。
- **Stop Gates (硬性中止閥門)**:
  當出現以下任何一項時，立即中止實體實驗並保留現場：
  1. 主機與客戶端時鐘偏差超過 50ms。
  2. 追蹤紀錄遺失或事件不完整。
  3. Drain 截止時存在未排空請求。
  4. GPU 發生 CUDA OOM 或 Driver fault。
  5. Python/Gateway 記憶體跨 episode 洩漏超過 1GiB。
  6. 控制器執行與 CAS fence 延遲突破 100ms 硬時限。

---

## 6. 五大對照控制器與 Strong One-Move vs MPC

為確保評估公平性，本協定嚴格實施同等條件比對：
1. **Fixed16**: 靜態成本預算 $u = 16.0$。
2. **Best-Supported-Fixed**: 由 Development 階段選出之最佳固定 Cap (如 $u = 24.0$ 或 $u = 32.0$)。
3. **Reactive (排隊反饋)**: 依當前 backlog 佇列門檻切換 16/32。
4. **Strong One-Move**:
   使用與 MPC 完全相同的 5 秒 Horizon、到達模型與不確定性分佈，但僅優化第 1 步決策 $u_0 \in \{16, 32\}$，後續 4 步採用凍結的接續策略 (frozen continuation policy)。
5. **Receding Horizon MPC**:
   在 5 秒 Horizon 內完整求解 $\{u_0, u_1, \dots, u_{K-1}\}$，並在每 1 秒時槽滾動重新規劃。

**端到端延遲預算要求**:
狀態觀測 + 模型求解 + 序列化 + POST + CAS Fence 的總延遲必須 $\le 100\text{ms}$。若求解逾時，強制觸發 fallback 安全動作 ($u = 16.0$) 並計入 overrun 統計。

---

## 7. 驗收收據與可追溯驗證證據

### 7.1 本機原始碼與測試雜湊清單

```
087c68868f48f6bac9d1ac829c9dc3cb8b749f1c40b87f6d5364bb2d2f4bad79  native_campaign_protocol.py
a94770f63e58e68e2046b98876831e609d98a6e595ec204402465620f5864d42  test_native_campaign_protocol.py
```

### 7.2 協定生成驗證收據

- **協定規格版本**: `native-v3-campaign-protocol-v1`
- **協定 SHA-256 Digest**: `110c06842bdf57abe10fb00e0562326c798a564225532e3e84313e6da8bf477f`
- **總 Seed Blocks**: 160 blocks
- **總 Episodes**: 320 episodes
- **總排程主動與排空時長**: 38,400 秒 (10.67 小時)
- **8 大工作負載家族完整性**: `short_homogeneous`, `long_prefill_heavy`, `decode_heavy`, `mixed_short_long`, `burst_flash_crowd`, `shift_non_stationary`, `saturation_recovery`, `unseen_ood_mix` 全部驗證無訛。
- **歷史保留 Seeds (160021-160024)**: 驗證未被使用，維持純淨封存狀態。

### 7.3 單元與回歸測試執行收據

```
$ python3 -m unittest test_native_campaign_protocol.py
.....................
----------------------------------------------------------------------
Ran 21 tests in 0.038s

OK
```

21 項測試涵蓋：
1. 嚴格 v2 審計判定為 `False` 且不被靜默放寬。
2. 有用 (useful)、物理 (physical)、尾端 (tail) 工作量之精確數值拆解。
3. GPU elapsed 非獨占時鐘與 serial 模型反證驗證。
4. 輸出 0 token 被拒絕且不被記為 good。
5. NaN origin 時間戳被拒絕且不被記為 good。
6. 合格請求滿足 TTFT $\le 0.5\text{s}$ 與 TPOT $\le 0.05\text{s}$ 之打分。
7. R3 偽重複 (複製同一 block 6 次) 被拒絕 (`REJECTED_PSEUDOREPLICATION`)。
8. 零變異配對差異被拒絕 (`REJECTED_ZERO_VARIANCE`)。
9. 決策逾時率過高觸發守護拒絕 (`REJECTED_OVERRUN_GUARD`)。
10. 相對拒絕率過高觸發守護拒絕 (`REJECTED_REJECTION_GUARD`)。
11. 具備真實隨機變異與顯著 Margin 之樣本通過優越性確認 (`CONFIRMED_SUPERIOR`)。
12. Cap 下調 (32 $\to$ 16) 軟性節流且不驅逐現有預約。
13. 終端預約釋放與預約成本嚴格守恆。
14. 多步 Horizon NAE 誤差計算驗證。
15. 總排程時長 $\ge 10.0$ 小時硬性要求達標。
16. 8 大家族完整宣告與分組。
17. 4 階段切分無縫且 seed 無重複。
18. 歷史 held-out seeds 160021-160024 隔離檢查。
19. 配對臂 tape keys 共享檢查。
20. 協定 JSON 序列化 Roundtrip 驗證。
21. 5 大對照控制器動作輸出範圍驗證。

---

## 8. 狀態宣言與後續步驟

- 本工作區維持在 `research/native-v3-gemini-local` 分支。
- 嚴格遵守 local-only 規則：不執行 `gt done`，不 push，不 merge，不請求外部網絡或非本機憑證。
- Bead 維持在 `in_progress` 狀態，靜候 Mayor 統籌之同儕審查與下一階段指示。
