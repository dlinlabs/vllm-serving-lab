"""Unit and regression tests for native_campaign_protocol.

Validates ground-truth accounting, R3 rejection guards, observable state,
and >=10h campaign protocol generation.
"""

import json
import math
import unittest

from native_campaign_protocol import (
    WORKLOAD_FAMILIES,
    DeliveredTokensAuditResult,
    Fixed16Controller,
    IndependentSeedBlockOutcome,
    MarkedReservationRecord,
    ObservableBatchState,
    RecedingHorizonMPCController,
    RequestOutcome,
    StrongOneMoveController,
    SuperiorityEvaluator,
    WorkAccounting,
    build_native_campaign_protocol,
    canonical_digest,
    compute_normalized_absolute_error,
    compute_work_accounting,
    is_finite_real,
    run_legacy_delivered_tokens_audit,
    validate_request_outcome,
    verify_gpu_elapsed_clock_semantics,
)


class TestGroundTruthAccounting(unittest.TestCase):
    """Test verification of the ground-truth baseline fact and work accounting."""

    def test_legacy_strict_audit_remains_false(self):
        """The strict v2 audit must evaluate to FALSE and not be silently relaxed."""
        audit = run_legacy_delivered_tokens_audit(
            prompt_tokens=4096,
            delivered_tokens=32,
            worker_forward_end_position=4128,
            total_forward_steps=34,
            prefill_steps=2,
            decode_steps=32,
        )
        self.assertIsInstance(audit, DeliveredTokensAuditResult)
        self.assertFalse(audit.strict_v2_match, "Strict audit must be False per ground truth")
        self.assertEqual(audit.delivered_token_minimum_position, 4127)
        self.assertEqual(audit.worker_forward_end_position, 4128)
        self.assertIn("Strict audit FALSE", audit.reason)

    def test_explicit_work_accounting(self):
        """Useful, physical, and tail work must be explicitly decomposed."""
        acct = compute_work_accounting(
            prompt_tokens=4096,
            delivered_tokens=32,
            worker_forward_end_position=4128,
            total_forward_steps=34,
            prefill_steps=2,
            decode_steps=32,
        )
        self.assertIsInstance(acct, WorkAccounting)
        self.assertEqual(acct.useful_prompt_tokens, 4096)
        self.assertEqual(acct.useful_output_tokens, 32)
        self.assertEqual(acct.useful_total_tokens, 4128)
        self.assertEqual(acct.physical_executed_positions, 4129)
        self.assertEqual(acct.tail_work_tokens, 1)
        self.assertEqual(acct.tail_work_steps, 1)
        self.assertIn("pre-finish scheduler placeholder 1", acct.tail_work_cause)
        self.assertAlmostEqual(acct.tail_work_output_ratio, 1.0 / 32.0)

    def test_gpu_elapsed_and_serial_falsification(self):
        """GPU elapsed is not an exclusive single-tenant service duration."""
        res = verify_gpu_elapsed_clock_semantics(
            http_residence_s=1.2,
            gpu_kernel_forward_elapsed_s=0.4,
            active_concurrent_requests=8,
        )
        self.assertFalse(res["kernel_exceeds_residence"])
        self.assertTrue(res["serial_service_model_falsified"])
        self.assertAlmostEqual(res["apparent_serial_demand_s"], 9.6)


class TestOutcomeValidationAndR3Rejection(unittest.TestCase):
    """Test outcome validation rejecting R3 flaws (zero tokens, NaN origin, pseudoreplication)."""

    def test_zero_completion_tokens_rejected(self):
        """0 output tokens must be rejected as invalid and not scored as good."""
        outcome = RequestOutcome(
            request_id="req-zero",
            prompt_tokens=128,
            output_tokens=0,  # Flaw in R3
            scheduled_at=10.0,
            client_post_at=10.05,
            first_content_at=10.2,
            terminal_at=10.25,
            origin_s=10.0,
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertFalse(val["valid"])
        self.assertFalse(val["is_good"])
        self.assertIn("invalid_output_token_count_must_be_positive_integer", val["rejection_reasons"])

    def test_nan_origin_rejected(self):
        """NaN origin timestamp must be rejected as invalid."""
        outcome = RequestOutcome(
            request_id="req-nan",
            prompt_tokens=128,
            output_tokens=16,
            scheduled_at=10.0,
            client_post_at=10.05,
            first_content_at=10.2,
            terminal_at=10.5,
            origin_s=float("nan"),  # Flaw in R3
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertFalse(val["valid"])
        self.assertFalse(val["is_good"])
        self.assertIn("nonfinite_origin_timestamp", val["rejection_reasons"])

    def test_valid_good_outcome(self):
        """A properly formatted request meeting SLOs must be scored good."""
        outcome = RequestOutcome(
            request_id="req-valid",
            prompt_tokens=128,
            output_tokens=32,
            scheduled_at=10.0,
            client_post_at=10.01,
            first_content_at=10.15,  # TTFT = 0.15s <= 0.5s
            terminal_at=10.77,       # TPOT = (10.77 - 10.15) / 31 = 0.02s <= 0.05s
            origin_s=10.0,
            finish_reason="stop",
            accepted=True,
            error=None,
        )
        val = validate_request_outcome(outcome)
        self.assertTrue(val["valid"])
        self.assertTrue(val["is_good"])
        self.assertAlmostEqual(val["ttft_s"], 0.15)
        self.assertAlmostEqual(val["tpot_s"], 0.02)

    def test_evaluator_rejects_pseudoreplication(self):
        """Duplicating the identical block (R3 flaw) must trigger pseudoreplication rejection."""
        evaluator = SuperiorityEvaluator(min_blocks=6)
        single_block = IndependentSeedBlockOutcome(
            block_id="block-dup",
            seed=170001,
            workload_family="short_homogeneous",
            split="development",
            duration_s=10.0,
            control_decisions=10,
            offered_requests=100,
            policy_a_good_completions=10,
            policy_a_rejections=5,
            policy_a_solver_overruns=0,
            policy_b_good_completions=20,
            policy_b_rejections=5,
            policy_b_solver_overruns=0,
        )
        # Duplicate identical block 6 times
        replicated_blocks = [single_block] * 6
        res = evaluator.evaluate(replicated_blocks)
        self.assertEqual(res["verdict"], "REJECTED_PSEUDOREPLICATION")
        self.assertFalse(res["statistically_significant"])

    def test_evaluator_rejects_zero_variance(self):
        """Distinct block IDs with identical paired differences must be rejected for zero variance."""
        evaluator = SuperiorityEvaluator(min_blocks=6)
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"block-{i}",
                seed=170000 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=10,
                offered_requests=100,
                policy_a_good_completions=10,
                policy_a_rejections=5,
                policy_a_solver_overruns=0,
                policy_b_good_completions=20,  # Exact same difference across all
                policy_b_rejections=5,
                policy_b_solver_overruns=0,
            )
            for i in range(6)
        ]
        res = evaluator.evaluate(blocks)
        self.assertEqual(res["verdict"], "REJECTED_ZERO_VARIANCE")
        self.assertFalse(res["statistically_significant"])

    def test_evaluator_confirms_valid_superiority(self):
        """Independent blocks with natural variance and genuine margin can achieve confirmation."""
        evaluator = SuperiorityEvaluator(
            min_blocks=6,
            pre_registered_margin_req_s=0.5,
        )
        # 8 independent blocks with positive mean improvement and natural variance
        good_b = [22, 24, 21, 25, 23, 26, 22, 24]
        good_a = [12, 11, 13, 10, 12, 11, 13, 12]
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"valid-block-{i}",
                seed=170010 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=10,
                offered_requests=100,
                policy_a_good_completions=good_a[i],
                policy_a_rejections=5,
                policy_a_solver_overruns=0,
                policy_b_good_completions=good_b[i],
                policy_b_rejections=5,
                policy_b_solver_overruns=0,
            )
            for i in range(8)
        ]
        res = evaluator.evaluate(blocks)
        self.assertEqual(res["verdict"], "CONFIRMED_SUPERIOR")
        self.assertTrue(res["statistically_significant"])
        self.assertTrue(res["margin_satisfied"])
        self.assertGreater(res["std_goodput_difference"], 0.0)


class TestObservableBatchState(unittest.TestCase):
    """Test observable Gateway state, soft-cap behavior, and conservation."""

    def test_soft_cap_reduction_does_not_evict(self):
        """Lowering applied cap from 32 to 16 must NOT evict existing reservations."""
        state = ObservableBatchState(initial_cap=32.0)
        
        # Admit 3 requests with cost 8.0 each -> total 24.0
        for i in range(3):
            admitted = state.admit(MarkedReservationRecord(
                request_id=f"r-{i}",
                original_cost=8.0,
                admitted_at=10.0 + i,
                prompt_tokens=256,
                max_tokens=128,
            ))
            self.assertTrue(admitted)
            
        self.assertEqual(state.reserved_cost, 24.0)
        
        # Lower cap to 16.0
        state.update_cap(16.0)
        self.assertEqual(state.applied_cap, 16.0)
        # Invariant: existing reservations survive
        self.assertEqual(state.reserved_cost, 24.0)
        self.assertEqual(len(state.active_reservations), 3)
        
        # New admission is throttled because 24.0 + 4.0 > 16.0
        new_admitted = state.admit(MarkedReservationRecord(
            request_id="r-new",
            original_cost=4.0,
            admitted_at=15.0,
            prompt_tokens=128,
            max_tokens=128,
        ))
        self.assertFalse(new_admitted)

    def test_release_and_conservation(self):
        """Releasing terminal reservations strictly decreases reserved cost."""
        state = ObservableBatchState(initial_cap=32.0)
        rec = MarkedReservationRecord(
            request_id="r-term",
            original_cost=6.5,
            admitted_at=10.0,
            prompt_tokens=512,
            max_tokens=128,
        )
        state.admit(rec)
        self.assertEqual(state.reserved_cost, 6.5)
        
        released = state.release("r-term", timestamp_s=12.5)
        self.assertIsNotNone(released)
        self.assertEqual(state.reserved_cost, 0.0)
        self.assertEqual(len(state.history_released), 1)

    def test_normalized_absolute_error_computation(self):
        """NAE across multi-step horizons must be correctly normalized."""
        pred = {1: 4.0, 3: 8.0, 5: 12.0}
        actual = {1: 5.0, 3: 8.0, 5: 10.0}
        origin_r = 16.0
        
        res = compute_normalized_absolute_error(pred, actual, origin_r)
        self.assertFalse(res["empty_origin"])
        # |4-5|/16 = 1/16, |8-8|/16 = 0, |12-10|/16 = 2/16 -> mean = (3/16)/3 = 1/16 = 0.0625
        self.assertAlmostEqual(res["mean_normalized_absolute_error"], 0.0625)


class TestCampaignProtocolBuilder(unittest.TestCase):
    """Test campaign protocol builder properties (duration, workloads, splits, immutability)."""

    def test_protocol_builder_duration_exceeds_10_hours(self):
        """The protocol must schedule >= 10.0 hours of active execution."""
        protocol = build_native_campaign_protocol()
        hours = protocol["duration_summary"]["total_active_hours"]
        self.assertGreaterEqual(hours, 10.0, f"Scheduled hours {hours:.2f}h must be >= 10.0h")
        self.assertTrue(protocol["duration_summary"]["hours_requirement_satisfied"])
        self.assertEqual(protocol["duration_summary"]["total_episodes"], 320)

    def test_eight_workload_families_present(self):
        """All 8 workload families must be declared and populated in the protocol."""
        protocol = build_native_campaign_protocol()
        self.assertEqual(len(protocol["workload_families"]), 8)
        for fam in WORKLOAD_FAMILIES:
            self.assertIn(fam, protocol["workload_families"])

    def test_splits_and_seed_isolation(self):
        """Train, calibration, development, and final splits must be populated with fresh seeds."""
        protocol = build_native_campaign_protocol(base_seed=180001)
        groups = protocol["groups"]
        all_seeds = [g["seed"] for g in groups.values()]
        
        # Verify no duplicate seeds
        self.assertEqual(len(all_seeds), len(set(all_seeds)))
        
        # Verify historical held-out seeds 160021-160024 are NOT used
        for seed in all_seeds:
            self.assertFalse(
                160021 <= seed <= 160024,
                f"Seed {seed} must not overlap with historical final held-out seeds 160021-160024!",
            )

    def test_matched_arms_share_tape(self):
        """Matched arms (0 and 1) must share identical arrival and prompt tape keys."""
        protocol = build_native_campaign_protocol()
        episodes = protocol["episodes"]
        
        # Group episodes by block_id
        by_block = {}
        for ep in episodes:
            by_block.setdefault(ep["block_id"], []).append(ep)
            
        for block_id, eps in by_block.items():
            self.assertEqual(len(eps), 2, f"Block {block_id} must have exactly 2 matched arms")
            arm0, arm1 = sorted(eps, key=lambda x: x["arm"])
            self.assertEqual(arm0["arm"], 0)
            self.assertEqual(arm1["arm"], 1)
            self.assertEqual(arm0["arrival_tape_key"], arm1["arrival_tape_key"])
            self.assertEqual(arm0["prompt_tape_key"], arm1["prompt_tape_key"])

    def test_canonical_digest_immutability(self):
        """Protocol hash must be a deterministic 64-character SHA-256 hex string."""
        p1 = build_native_campaign_protocol()
        p2 = build_native_campaign_protocol()
        self.assertEqual(p1["protocol_hash"], p2["protocol_hash"])
        self.assertEqual(len(p1["protocol_hash"]), 64)

    def test_protocol_json_serialization_roundtrip(self):
        """Protocol must serialize to valid JSON without NaN or Inf and roundtrip exactly."""
        protocol = build_native_campaign_protocol()
        json_str = json.dumps(protocol, allow_nan=False)
        roundtrip = json.loads(json_str)
        self.assertEqual(protocol["protocol_hash"], roundtrip["protocol_hash"])
        self.assertEqual(len(roundtrip["episodes"]), 320)

    def test_overrun_guard_rejection(self):
        """Excessive decision overruns must trigger REJECTED_OVERRUN_GUARD."""
        evaluator = SuperiorityEvaluator(min_blocks=6, max_decision_overrun_rate=0.01)
        good_b = [22, 24, 21, 25, 23, 26]
        good_a = [12, 11, 13, 10, 12, 11]
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"overrun-block-{i}",
                seed=170050 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=100,
                offered_requests=100,
                policy_a_good_completions=good_a[i],
                policy_a_rejections=5,
                policy_a_solver_overruns=0,
                policy_b_good_completions=good_b[i],
                policy_b_rejections=5,
                policy_b_solver_overruns=5,  # 5% overrun rate > 1% threshold
            )
            for i in range(6)
        ]
        res = evaluator.evaluate(blocks)
        self.assertEqual(res["verdict"], "REJECTED_OVERRUN_GUARD")
        self.assertFalse(res["overrun_guard_passed"])

    def test_rejection_guard_rejection(self):
        """Excessive relative rejection increase must trigger REJECTED_REJECTION_GUARD."""
        evaluator = SuperiorityEvaluator(min_blocks=6, max_relative_rejection_increase=0.05)
        good_b = [22, 24, 21, 25, 23, 26]
        good_a = [12, 11, 13, 10, 12, 11]
        blocks = [
            IndependentSeedBlockOutcome(
                block_id=f"rej-block-{i}",
                seed=170060 + i,
                workload_family="short_homogeneous",
                split="development",
                duration_s=10.0,
                control_decisions=100,
                offered_requests=100,
                policy_a_good_completions=good_a[i],
                policy_a_rejections=10,
                policy_a_solver_overruns=0,
                policy_b_good_completions=good_b[i],
                policy_b_rejections=15,  # 50% relative increase > 5% threshold
                policy_b_solver_overruns=0,
            )
            for i in range(6)
        ]
        res = evaluator.evaluate(blocks)
        self.assertEqual(res["verdict"], "REJECTED_REJECTION_GUARD")
        self.assertFalse(res["rejection_guard_passed"])

    def test_controllers_produce_valid_budgets(self):
        """All 5 comparators must produce allowed budgets in {16.0, 32.0}."""
        state = ObservableBatchState(initial_cap=16.0)
        controllers = [
            Fixed16Controller(),
            StrongOneMoveController(),
            RecedingHorizonMPCController(),
        ]
        for ctrl in controllers:
            decision = ctrl.decide(state, queue_length=5)
            self.assertIn(decision, (16.0, 32.0))


if __name__ == "__main__":
    unittest.main()
