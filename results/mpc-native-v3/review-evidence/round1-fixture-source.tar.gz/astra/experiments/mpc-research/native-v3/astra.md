# Astra NV3 round 1: a response-model interface, not another simulated plant

Status: independent local proposal and bounded shadow planner. No native run,
fitted response model, calibration acceptance, active permit, or performance
claim. Only the three owned files in this directory are changed. No fresh
NV3 peer proposal was read. Bead `pr-nv3-astra` remains for Mayor-managed
in-progress peer review; this report is the offline handoff receipt.

## 1. Evidence and decisions retained

Read `campaign.zh-TW.md` from base `10f2fb0`, the native-v2 decision and next
protocol, my v2 round3 revision, the actual native identification/falsification
report, and the persisted Train diagnostic JSONs:

- `results/mpc-native-4090-scout/native-prefill-combined.json` explicitly rejects
  the exclusive serial HTTP interpretation: 2449/2056 natural completions in
  90s exceed its 2004 bound. This does not reject all queueing/fluid models.
- `native-prediction-combined.json` records retrospective Gateway availability
  as unverified, `model_accepted=false`, and no calibration or online forecasts.
- `native-token-diagnostic.json` is a decode-survivor progress diagnostic, not
  an identified batch service law. Realized next-snapshot gaps are not known
  future horizons. The report's candidate MAE 1.043 versus persistence 1.029
  is not evidence that a complex predictor already beats the strongest baseline.
- Native-v2's common 5s evaluation, exact whole-cost releases, pending work
  caveat, support-limited outcome model and strong continuation remain useful.
  The old claims that physical memory is sufficient/necessary for MPC gain,
  that a non-significant result proves impossibility, or that scalar cost is
  KV safety remain rejected. The supplied old Gemini report does not override
  these later evidence-based decisions.

The Mayor-supplied new fact is a strict HTTP UUID-joined 4096-prompt/32-output
natural-EOS completion, but its old work audit is still FALSE: contiguous
worker positions end at 4128 versus useful delivered-token minimum 4127.
There are 34 executed steps (2 prefill, 32 decode). The final extra token had
a scheduler placeholder of 1, step start before EOS, output commit after EOS,
and matching executed CUDA forward. This is supplied ground truth, not a local
rerun or an audited raw capture I downloaded. Do not write "Gate A passed."

The supplied current environment is one authorized RTX4090/24564MiB,
driver595.91.07, vLLM0.30.0/Torch2.13.0/Transformers5.22.1 and restored pinned
Qwen4B. Prior deployment coefficients do not qualify this deployment. No use of
held-out 160021-160024, GPU, SSH, API, credentials, or paid resources occurred.

## 2. Useful work, physical work, and two different tails

Keep the old audit and its failed result byte-for-byte unchanged. Propose a
separately versioned accounting contract, qualified against raw data before use:

1. **Delivered/useful ledger:** client output token IDs/count, EOS/finish reason,
   native output-commit lineage, and prompt input positions. In this cache-off,
   non-speculative case, producing `m` delivered tokens requires minimum
   input work `p + m - 1`; the first output comes from prompt forward. This is
   a lower-bound dependency count, not the complete executed-work identity.
2. **Physical ledger:** every actual worker forward's exact request ID, step ID,
   executed position interval, token count, and qualified stream-scoped CUDA
   elapsed interval. Include the extra position even when no delivered output
   results. Preserve schedule/execute disagreement, duplicates, gaps, discarded
   sampling, cancellation and pending work explicitly; do not erase them as EOS.
3. **Attribution ledger:** join each physical interval to useful dependencies,
   explained async lookahead/discarded work, or **unexplained** work. In the
   supplied example physical 4128 minus useful minimum 4127 is 1. Calling that
   one position an explained EOS-adjacent lookahead requires the supplied
   launch/placeholder/commit/forward lineage. It is not a universal `+1`
   tolerance. An unexplained difference must still fail label qualification.

Engine host order and worker event duration are distinct facts. A host step
started before the EOS callback is not proof of GPU execution before EOS.
GPU elapsed is neither an absolute host/GPU timestamp nor exclusive service
demand. Do not subtract it from HTTP residence or sum request allocations as a
server-capacity proof. Kernel overlap and mixed batches require batch-scoped
labels; decode-progress coefficients are not prefill service coefficients.

Physical tail work after useful output may delay other requests even after
the corresponding reservation releases. Keep a pending-physical-work summary
or abstain; never infer GPU drain from `R=0` or client EOS alone.
Separately, **evaluation tail** means unresolved offered outcomes after the 5s
cohort window and bounded drain. It is not the extra CUDA work. Retain both.

Falsification cases for the new contract, to be run by the measurement owner:
remove/duplicate the last worker interval; change its position or count; retain
a placeholder without executed forward; inject an extra interval without a
launch/commit explanation; lose EOS/output-commit evidence; add more than one
ahead step; cancel while work is pending; replay cap-drop/cleanup before GPU
drain; and repeat across short/long prompt and mixed batch composition.
Each must either have complete causal lineage or remain invalid/unknown.
Reject cross-clock comparisons and unresolved CUDA events. Repeat OFF/LIGHT
and literal-disabled measurements to distinguish observer effects. This module
does not implement or weaken any capture audit.

## 3. Observable state and identifiable transition

The full online prefix `H(t)` contains only receipts actually delivered by the
decision origin, not backdated scheduler events or end-of-drain CUDA labels:

| Component | Required record / uncertainty |
|---|---|
| Identity and clocks | Deployment/source/config/model revision, cost estimator, service epoch, boot/clock provenance; source event and consumer receipt times separately |
| Exact reservation ledger | UUID, original charged cost, admission/release version and time; cap applied/version/expiry and any pending command |
| All-offered cohort | Old unresolved offers including not-yet-admitted transport work, plus future offers in `[t,t+5)`; rejects/errors never disappear from denominator |
| Request marks | Prompt/max-output, received output progress, first-content status, age, waiting/prefill/decode/release-pending/unknown state |
| Batch prefix | Native running/waiting counts, pending batches, prompt chunk/progress and context bins if actually available, KV occupancy, missing/unknown IDs, sampling width and receipt age |
| Environment/history | Recent arrival/mix and release histories, cap history, pending physical tail, observer mode, preemption/recovery flags; unknown remaining EOS and future batch membership |

This is not a sufficient observed Markov GPU state. History and latent physical
work remain important. The implemented `State` has a bounded marked live ledger,
batch counts/KV, identity/version and timestamps, plus `history_id` for a frozen
received-prefix artifact. It is an interface, not a production state adapter.
The eventual adapter must bind the richer prefix above to that ID, and mark
unknown native request work as `stage="unknown"` (which is rejected). An
accepted-but-not-yet-visible native request cannot be quietly labelled known.
An old offer that has not been admitted instead stays in `origin_offered_ids`
without fabricated reservation cost. `release_pending` means output is known
but original cost is still held; it is not an implicit release.

Exact accounting, not an estimated fluid release:

```
R_next = R + sum(actual admitted original costs) - sum(actual released original costs)
admit iff R + original_cost <= actually_applied_cap
R <= max(initial R, maximum historically applied cap)
```

`transition_costs` replays ordered admit/release events, checks exact original
cost and ID, refuses double release/reuse, and checks projected cost **before**
admitting. Within the supported 16/32 family, initial R cannot exceed32.
Lowering cap to16 with R=24 is allowed; it does not evict, fractional-release,
or recost requests. Applying a cap without an event changes no reservation.
16/32 are cost caps, not request counts, KV bytes or scheduler token budgets.

Unknown response:

```
P_theta(origin-cost releases at 1/3/5s, complete-good and unresolved cohort counts
        | H(t), assigned cap prefix + frozen continuation, future arrival law,
          deployment/source/observer support)
```

Start with support-limited whole-policy response estimation, stratifying coarse
origin reserved cost and prompt mix only if randomized data support it. Compare
action-only, persistence/hold, and regularized coarse models on blocked data.
Do not concatenate independent response-table cells into fictitious rolling
transitions. No serial HTTP law, extrapolated knee, fitted GPU coefficient or
stochastic EOS generator is embedded in the code.

## 4. Implemented bounded planner contract

`native_response_planner.py` injects a `ResponseModel.predict` implementation.
There is deliberately no built-in performance model, artifact loader, data
collector, actuator, or permit generator. `None` means unsupported. Missing any
candidate aborts the comparison; failed/unsupported plans are not scored zero.

All six calls receive the **same immutable Evaluation object**: 5s half-open
offered window, 1s slots, identical origin cohort, future law and weighted joint
scenario IDs, model/support/uncertainty IDs, continuation receipt and tail rule.
Response must echo state/plan/evaluation identity and every scenario in order.
The caller supplies a forecast distribution frozen at the origin, not the
experiment's realized future tape. Scenario future-offer counts are draws under
that distribution, not observed future admissions. IDs alone cannot prove this;
the external data/model qualification must.

Two candidates optimize One-move's first cap, then invoke the development-chosen
continuation from t+1 onward. Four candidates enumerate all cap pairs, then use
the **same continuation policy** from t+2 onward. The continuation policy gets
only that rollout's available prefix; it may be hold, best-supported-fixed or
a pre-frozen strong reactive rule selected on Development. It is not silently
Fixed16, nor chosen separately per policy after seeing outcomes. A reactive
continuation is represented by its policy ID, not replaced with the realized
cap path from another arm. Its support must be explicit in the injected model.
Ordinary LL/LH/HL/HH data with fixed continuation do not support this interface's
strong reactive baseline automatically.

For each joint scenario, the model supplies settled-good `G`, unresolved `U`,
expected additional tail-good `E` in `[0,U]`, and nested sets of released
**origin request IDs** at 1/3/5s. No duplicate/unknown ID or reversal is allowed.
The scorer sums original costs, so releases in each draw are whole-cost;
only the average across draws may be fractional, always in `[0,R_origin]`.
The remaining offered mass is settled
bad/rejected/error/cancelled. Good requires positive output and natural complete,
TTFT from scheduled offer <=0.5s, request-mean TPOT using **terminal**, not last
content, <=0.05s; one token TPOT=0. Upstream outcome extraction must enforce
these predicates; aggregate predictions here cannot re-audit raw responses.

Rank by weighted expected `G+E`, never by settled `G` alone. Separately report
tail interval `[sum pG, sum p(G+U)]`; expand it by declared joint model-error
allowances and clip to the all-offered count. These allowances are in good-count
units, must include selection over this candidate family, and must come from
independent Calibration. They are **not** per-request independent draws.
The interval is a conservative reporting/abstention envelope, not an internally
proved confidence/chance constraint. Calibration is not implied by a nonempty ID.

Tie-breaking prefers currently applied cap, then lexicographic cap order.
A selected first action is resolved only if its lower envelope exceeds every
candidate upper envelope with the other first action. Equal/overlapping bands
yield no recommendation. Keep strong One-move if first actions coincide; when
they differ, prefer two moves only with resolved first-action ranking and a
positive conservative two-minus-one interval. Otherwise retain One-move if
resolved, or abstain. A larger open-loop score is not a closed-loop gain claim;
reactive continuation means the two candidate families are not necessarily
nested. This is intentionally conservative and may abstain despite a useful
paired estimator; adding a calibrated paired contrast is future work, not an
excuse to assert independence.

Work is bounded to six model calls, <=128 shared scenarios, <=256 live/origin
IDs and a three-offset release trajectory; the standalone ledger helper bounds
each replay at1024 events. These are engineering limits, not native capacities.
No scenario sampling/search expansion occurs inside the planner.

## 5. Clock, cost, deadline and fallback boundary

State must match expected deployment/epoch/cost identity, use the consumer's
qualified clock domain, satisfy `sample <= receipt <= origin <= now`, and pass
finite-number, age/skew, ledger, token and pending-command checks. Max age/skew,
absolute decision deadline and dispatch headroom are caller-supplied frozen
timing policy; the module invents no measured latency. Clock readings cannot
regress. Deadline is checked before/after model calls and after ranking, with
dispatch reserve subtracted; state freshness is rechecked through completion.
The absolute deadline must originate before observation/feature work, not be
reset on solver entry. `elapsed_s` measures planner wall time only; record the
external full observation->feature->solve->persist->POST->fence path separately.

The injected callback is synchronous and must cooperate with its supplied
deadline. A hung model cannot be preempted by this module; a late return is
discarded. Six bounded calls do not prove a100ms runtime bound. A future runtime
needs a separately qualified watchdog/isolation boundary, actual version/epoch
recheck immediately before POST, TTL/fence enforcement and fallback lifecycle.
Do not deploy this callable inside an unguarded actuator path.

Every fallback returns `shadow_cap=None`: **send no new command**. It does not
assert that stale cap16, unknown current cap, or an expired command is safe.
The previously qualified external runtime owns expiry/recovery/fixed policy.
Even a successful `status="shadow"` has `active_permit=False` unconditionally;
passing native/calibration IDs cannot turn this module into authority.
Native observation, causal support, independent calibration, command latency,
KV/OOM/preemption and recovery evidence are missing. None is substituted with
passing CPU tests. No Gateway/core/config/permit file was touched.

## 6. Native discrimination, causal support and one/multi/OOD evaluation

Mayor alone may execute. First retain the old failed audit, qualify the separate
physical/useful/tail ledger, exact UUID joins, stream scope, END/ACK persistence,
drain and observer treatment. A result with unexplained physical work is not a
valid training label even if HTTP completion is correct.

Next run a bounded mixed short/long natural-EOS intervention pilot on fresh
TRAIN blocks, paired tapes within block, randomized LL/LH/HL/HH order, fixed
decision cuts and logged assignments/application/ACK lag. Add same-sequence
repeats and literal-disabled/OFF/LIGHT epochs, with pre-frozen warmup/reset and
finite drain. The previous v2 two-block32-episode pilot is an engineering
falsification design, not statistical power or10h of research by itself.
Retain outcomes, failures and unused/invalid captures with resource timestamps.
Do not keep a GPU idle while CPU-only discussion is underway.

Four-sequence ITT effects identify whole assigned policies under that offered
distribution. They do not identify per-batch mediator causality or the action
effect at arbitrary post-treatment states. Never condition away late actuation
and then describe the result as randomized. To qualify the strong continuation,
freeze it using Development, then obtain fresh randomized TRAIN support for both
one-prefix and two-prefix policies with that continuation. If unsupported,
report unresolved and stop promotion instead of weakening One-move.

Freeze model/features on TRAIN with whole-seed-block folds, not request-level
splits. Use distinct Calibration for joint release/count/ranking errors and
abstention thresholds; Development chooses continuation and candidate family.
No selection on held-out final outcomes. Proposed acceptance measurements:

- Publish origin-fixed 1/3/5s release/count forecasts before their labels arrive.
  Report normalized origin-release absolute error per offset and joint path
  error; empty-origin cases are separate, not free zeros. Never use realized
  snapshot gap as a forecast input.
- Compare one-slot response, two-slot path and5s terminal/tail errors against
  action-only/hold/persistence and best TRAIN-selected baseline. Report
  completion/TTFT Brier or proper count scores, calibration, censoring, release
  bias and paired action ranking, not just mean token MAE.
- Stratify calibration by load/mix/observer/actuation lag, with independent
  block residuals and simultaneous candidate-selection coverage diagnostics.
  Seed repeats are not new independent blocks. Poor coverage or sparse support
  forces abstention; no nominal coverage is a safety theorem.
- OOD tests use new mixture/load/burst/recovery regimes and changed clock,
  source, cap family, KV/preemption and missing-work conditions. Unsupported
  state/continuation must abstain. Report both retained accuracy and coverage
  fraction so abstaining on difficult cases cannot manufacture superiority.

Only after useful independent forecasts and support, randomize **complete**
replanning algorithms on fresh matched offered tapes: Fixed16,
development-best-supported-fixed, frozen reactive, strong One-move, two-move.
Same cadence, GPU/model/source/observer/arrival law, SLO/cohort/tail, command
semantics, wall-clock overhead and offered denominator for all. Record first
action disagreement, binding admission mass, effect magnitude conditional on
disagreement, solver/full-path cost, errors/rejects, oscillation and recovery.
Rare disagreement is not a small-effect proof. Let experimental time include
planner/dispatch overhead rather than freezing the plant during CPU solving.

Before any final access, freeze the primary estimand, practical margin,
independent block count based on Development variance/precision, multiplicity
handling and safety/rejection guardrails. Four reserved old final seeds cannot
by themselves give a two-sided exact sign/permutation p<.05 (floor .125).
No magical eight-block power or0.5good/s margin is assumed. Weak evidence
remains inconclusive, not equivalence, impossibility, or a certified advantage.
At present no stage beyond local interface/contract witnesses is claimed.

## 7. Local delivery receipt

Owned source: `experiments/mpc-research/native-v3/native_response_planner.py`.
Owned tests: `experiments/mpc-research/native-v3/test_native_response_planner.py`.
Owned report: this file. No fresh peer-owned NV3 files were inspected.
The test model's explicit counts and clocks are small contract witnesses, not
fitted fixture constants in a performance model, synthetic benchmark results,
native labels or statistical evidence.

Validation command (no GPU/dependencies/network):

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s experiments/mpc-research/native-v3 -p test_native_response_planner.py -v
git diff --check
```

Final source/test run: **20 tests passed**, no skips, using the command above.
These exercise all six shared-contract evaluations, strong-continuation support,
all-offered origin membership, joint weights, separate tail/model uncertainty,
whole-cost release IDs, cap-drop conservation, ordered admission, stale/invalid
state and clocks, deadline headroom, unsupported final candidates and exceptions.
No native forecast, calibration or controller performance was tested.

SHA256 receipts (the implementation and tests, not this self-referencing report):

```
e19db180e1fb06c6c34ff21e9b76131e85749edc7f403d4aa65acf366b7a3326  native_response_planner.py
862bc1db7a9baba167f8cf0baa7997c93201cfb7fdce47152e4a6dadaf8e3f08  test_native_response_planner.py
```

No project formatter/linter is configured in the root Python manifest; the
focused unittest runner and staged whitespace check are the applicable local
gates. No dependency/tool installation was needed. No push, merge, rebase or
remote/config changes are requested; local commit only. The final CLI receipt
identifies that commit, which contains this report and these exact source bytes.
Beads mutations are left to Mayor; no completion or native acceptance is claimed.
