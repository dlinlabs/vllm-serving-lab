"""Contract witnesses only; the stub below is not a native fitted response model."""

from dataclasses import replace
import unittest

from native_response_planner import (
    Decision, Evaluation, Identity, Outcome, Prediction, RequestState, Scenario,
    State, Timing, plan_response, transition_costs,
)


IDENTITY = Identity("test-deployment", "test-epoch", "test-clock", "test-cost")


def state():
    return State(
        "test-state", IDENTITY, 10.0, 9.9, 9.95, .01, 16, 4, False, 8.0,
        (RequestState("old", 8.0, 4096, 128, 2, "decode", .2),),
        0, 1, 0, .1, "test-received-history",
    )


def evaluation():
    return Evaluation(
        "test-model", "test-support", "test-future-law", "test-uncertainty",
        "test-cohort", "development-selected-reactive", "test-development-receipt",
        "test-tail-rule", 30.0, ("old",), (Scenario("joint-test-draw", 1.0, 9),),
    )


class StubModel:
    def __init__(self):
        self.calls = []
        self.values = {(16,): 4, (32,): 2, (16, 16): 3,
                       (16, 32): 4, (32, 16): 8, (32, 32): 5}
        self.transform = lambda prediction: prediction

    def predict(self, state, plan, evaluation, deadline_at):
        self.calls.append((state, plan, evaluation, deadline_at))
        outcome = Outcome(evaluation.scenarios[0].scenario_id,
                          self.values[plan.prefix], 0, 0.0, ((), ("old",), ("old",)))
        return self.transform(Prediction(state.state_id, plan, evaluation,
                                         (outcome,), 0.0, 0.0))


class PlannerTests(unittest.TestCase):
    def run_plan(self, model=None, **kwargs):
        return plan_response(
            kwargs.pop("state", state()), kwargs.pop("evaluation", evaluation()),
            model or StubModel(), expected_identity=kwargs.pop("expected_identity", IDENTITY),
            timing=kwargs.pop("timing", Timing("test-clock", 10.1, .02, .5, .05)),
            clock=kwargs.pop("clock", lambda: 10.0), **kwargs,
        )

    def test_complete_bounded_search_uses_identical_contract_and_strong_continuation(self):
        model = StubModel()
        result = self.run_plan(model)
        self.assertEqual(result.status, "shadow")
        self.assertEqual(result.shadow_cap, 32)
        self.assertEqual(result.one_move.best.plan.prefix, (16,))
        self.assertEqual(result.two_move.best.plan.prefix, (32, 16))
        self.assertEqual(result.gain_interval, (4.0, 4.0))
        self.assertEqual([call[1].prefix for call in model.calls],
                         [(16,), (32,), (16, 16), (16, 32), (32, 16), (32, 32)])
        self.assertTrue(all(call[2] is model.calls[0][2] for call in model.calls))
        self.assertTrue(all(call[1].continuation_id == evaluation().continuation_id
                            and call[3] == 10.08 for call in model.calls))
        self.assertFalse(result.active_permit)

    def test_no_default_model_or_permit_even_with_declared_receipts(self):
        self.assertEqual(self.run_plan(object()).status, "fallback")
        self.assertFalse(Decision("shadow", "not evidence", 32).active_permit)

    def test_same_first_action_retains_one_move_even_with_larger_open_loop_score(self):
        model = StubModel()
        model.values[(16, 32)] = 9
        result = self.run_plan(model)
        self.assertEqual(result.shadow_cap, 16)
        self.assertEqual(result.reason, "strong One-move retained")

    def test_uncertainty_overlap_does_not_authorize_point_estimate_winner(self):
        model = StubModel()
        model.transform = lambda p: replace(p, error_below=5, error_above=5)
        result = self.run_plan(model)
        self.assertEqual(result.status, "fallback")
        self.assertIsNone(result.shadow_cap)
        self.assertEqual(result.two_move.best.mean_good, 8)

    def test_tail_expectation_not_settled_count_ranks_but_bounds_prevent_false_certainty(self):
        model = StubModel()

        def tail(p):
            if p.plan.prefix == (32,):
                return replace(p, outcomes=(Outcome("joint-test-draw", 1, 8, 8,
                                                    ((), ("old",), ("old",))),))
            return p

        model.transform = tail
        result = self.run_plan(model)
        self.assertEqual(result.one_move.best.plan.prefix, (32,))
        self.assertEqual(result.one_move.best.mean_good, 9)
        self.assertEqual((result.one_move.best.tail_lower, result.one_move.best.tail_upper),
                         (1, 9))
        self.assertEqual(result.status, "fallback")

    def test_missing_one_move_continuation_support_aborts_not_weakens_baseline(self):
        model = StubModel()
        model.transform = lambda p: None if len(p.plan.prefix) == 1 else p
        result = self.run_plan(model)
        self.assertEqual(result.status, "fallback")
        self.assertIn("unsupported", result.reason)
        self.assertEqual(len(model.calls), 1)

    def test_unknown_or_missing_last_candidate_aborts_partial_optimization(self):
        model = StubModel()
        model.transform = lambda p: None if p.plan.prefix == (32, 32) else p
        result = self.run_plan(model)
        self.assertIsNone(result.shadow_cap)
        self.assertEqual(result.scores, ())
        self.assertEqual(len(model.calls), 6)

    def test_state_fences_fail_before_model(self):
        changes = (
            {"identity": replace(IDENTITY, epoch="other")},
            {"identity": replace(IDENTITY, cost_model="other")},
            {"sampled_at": 9.0}, {"received_at": 10.01}, {"origin": float("nan")},
            {"sample_width_s": .06}, {"reserved_cost": 4.0}, {"pending_command": True},
            {"applied_cap": 24}, {"kv_usage": float("inf")}, {"cap_version": True},
            {"requests": (replace(state().requests[0], stage="unknown"),)},
            {"requests": (replace(state().requests[0], original_cost=-1),)},
            {"requests": (state().requests[0], state().requests[0])},
        )
        for change in changes:
            with self.subTest(change=change):
                model = StubModel()
                self.assertEqual(self.run_plan(model, state=replace(state(), **change)).status,
                                 "fallback")
                self.assertEqual(model.calls, [])

    def test_clock_domain_invalid_deadline_and_regression(self):
        for timing in (Timing("other", 10.1, .02, .5, .05),
                       Timing("test-clock", float("nan"), .02, .5, .05),
                       Timing("test-clock", 10.02, .02, .5, .05)):
            self.assertEqual(self.run_plan(timing=timing).status, "fallback")
        ticks = iter((10.0, 9.99))
        self.assertIn("clock regression", self.run_plan(clock=lambda: next(ticks)).reason)

    def test_deadline_includes_callback_and_reserves_dispatch_time(self):
        ticks = iter((10.0, 10.0, 10.081))
        model = StubModel()
        result = self.run_plan(model, clock=lambda: next(ticks))
        self.assertEqual(result.status, "fallback")
        self.assertIn("deadline", result.reason)
        self.assertEqual(len(model.calls), 1)
        self.assertGreater(result.elapsed_s, .08)

    def test_state_that_expires_during_evaluation_aborts(self):
        ticks = iter((10.0, 10.0, 10.01, 10.02))
        result = self.run_plan(clock=lambda: next(ticks),
                               timing=Timing("test-clock", 10.1, .02, .11, .05))
        self.assertIn("stale", result.reason)

    def test_prediction_contract_pairing_accounting_and_release_validation(self):
        transformations = (
            lambda p: replace(p, state_id="future-state"),
            lambda p: replace(p, evaluation=replace(p.evaluation, horizon_s=1)),
            lambda p: replace(p, plan=replace(p.plan, continuation_id="weak-fixed16")),
            lambda p: replace(p, error_above=float("nan")),
            lambda p: replace(p, outcomes=p.outcomes * 2),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0], scenario_id="other"),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0], settled_good=11),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0], settled_good=True),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0], expected_tail_good=1),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0],
                                                   released_origin_ids=(("old",), (), ("old",))),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0],
                                                   released_origin_ids=((), (), ("new",))),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0],
                                                   released_origin_ids=((), (), ("old", "old"))),)),
        )
        for transform in transformations:
            with self.subTest(transform=transform):
                model = StubModel()
                model.transform = transform
                self.assertEqual(self.run_plan(model).status, "fallback")

    def test_joint_weighting_and_tail_model_uncertainty_remain_distinct(self):
        model = StubModel()
        law = replace(evaluation(), scenarios=(Scenario("a", .25, 9), Scenario("b", .75, 3)))

        def joint(p):
            return replace(p, outcomes=(
                Outcome("a", 6, 2, 1, ((), ("old",), ("old",))),
                Outcome("b", 1, 1, .5, ((), (), ("old",))),
            ), error_below=.2, error_above=.4)

        model.transform = joint
        score = self.run_plan(model, evaluation=law).scores[0]
        self.assertEqual(score.mean_good, 2.875)
        self.assertEqual((score.tail_lower, score.tail_upper), (2.25, 3.5))
        self.assertEqual((score.lower_good, score.upper_good), (2.05, 3.9))
        self.assertEqual(score.released_origin_cost, (0, 2, 8))

    def test_invalid_or_unbounded_evaluation_is_rejected_without_predicting(self):
        for change in (
            {"horizon_s": 1.0}, {"slot_s": 2.0}, {"slot_s": True},
            {"tail_s": float("nan")},
            {"continuation_development_receipt": ""},
            {"origin_offered_ids": ()}, {"origin_offered_ids": ("old", "old")},
            {"scenarios": ()}, {"scenarios": evaluation().scenarios * 129},
            {"scenarios": (Scenario("x", .9, 3),)},
            {"scenarios": (Scenario("x", 1, -1),)},
            {"scenarios": (Scenario("x", .5, 1), Scenario("x", .5, 1))},
        ):
            model = StubModel()
            self.assertEqual(self.run_plan(model, evaluation=replace(evaluation(), **change)).status,
                             "fallback")
            self.assertEqual(model.calls, [])

    def test_unadmitted_old_offers_stay_in_cohort_without_fake_reserved_work(self):
        model = StubModel()
        model.values = {prefix: 11 for prefix in model.values}
        result = self.run_plan(
            model, evaluation=replace(evaluation(), origin_offered_ids=("old", "not-admitted"))
        )
        self.assertEqual(len(result.scores), 6)
        self.assertEqual(result.scores[0].mean_good, 11)
        self.assertEqual(result.scores[0].released_origin_cost[-1], 8)

    def test_model_exception_is_no_command_not_fixed16_actuation(self):
        model = StubModel()

        def fail(_):
            raise RuntimeError("model unavailable")

        model.transform = fail
        result = self.run_plan(model)
        self.assertIn("model unavailable", result.reason)
        self.assertIsNone(result.shadow_cap)


class LedgerTests(unittest.TestCase):
    def test_cap_drop_preserves_reservations_and_releases_original_whole_cost(self):
        self.assertEqual(transition_costs((("a", 20), ("b", 12)),
                                         (("release", "b", 12, 16),)), (("a", 20),))
        self.assertEqual(transition_costs((("a", 20), ("b", 12)),
                                         (("release", "a", 20, 16),
                                          ("admit", "c", 4, 16))), (("b", 12), ("c", 4)))

    def test_cap_is_cost_not_count_and_events_are_ordered(self):
        with self.assertRaisesRegex(ValueError, "exceeds cap"):
            transition_costs((("a", 12),), (("admit", "b", 8, 16),))
        with self.assertRaisesRegex(ValueError, "exceeds cap"):
            transition_costs((("a", 16),), (("admit", "b", 8, 16),
                                           ("release", "a", 16, 16)))
        self.assertEqual(transition_costs((("a", 16),), (("release", "a", 16, 16),
                                                        ("admit", "b", 8, 16))),
                         (("b", 8),))

    def test_duplicate_release_recost_and_reused_id_rejected(self):
        for events in (
            (("release", "a", 7, 16),),
            (("release", "a", 8, 16), ("release", "a", 8, 16)),
            (("release", "a", 8, 16), ("admit", "a", 8, 16)),
        ):
            with self.assertRaises(ValueError):
                transition_costs((("a", 8),), events)

    def test_lowered_cap_state_not_rejected_as_overshoot(self):
        snapshot = replace(state(), reserved_cost=24,
                           requests=(replace(state().requests[0], original_cost=24),))
        model = StubModel()
        result = plan_response(snapshot, evaluation(), model, expected_identity=IDENTITY,
                               timing=Timing("test-clock", 10.1, .02, .5, .05),
                               clock=lambda: 10.0)
        self.assertEqual(result.status, "shadow")


if __name__ == "__main__":
    unittest.main()
