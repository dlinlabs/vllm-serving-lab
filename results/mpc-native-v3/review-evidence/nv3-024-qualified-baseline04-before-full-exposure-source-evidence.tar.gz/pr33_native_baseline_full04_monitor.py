"""Mirror only closed fresh episodes; notify measured duration, not MPC success."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import time


BASE = Path(__file__).resolve().parent
STAGE = "/root/pr33-native-v3-baseline-stage-04"
OUTPUT = "/root/pr33-native-v3-baseline-source-c4ace2e/results/mpc-native-v3/fixed-baseline-four-seed04"
DEST = BASE / "pr33-native-v3-baseline-four-seed04-replica"
PROTOCOL = BASE / "pr33-native-v3-four-seed-baseline04-protocol.json"
PRIOR_SECONDS = 26880
spec = importlib.util.spec_from_file_location("baseline04_transport", BASE / "pr33_native_identification03_monitor.py")
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


def main():
    protocol = json.loads(PROTOCOL.read_text())
    assert hashlib.sha256(PROTOCOL.read_bytes()).hexdigest() == "f5e6ef6fbc90bca5b48de8c21bff9fdefb320167581f6897b141ae5bb1ca514d"
    qualification = json.loads((BASE / "pr33-native-v3-baseline-qualification04-replica/runtime-qualification-receipt.json").read_text())
    expected = json.loads((BASE / "pr33-native-v3-baseline-04-owned-service-identity.json").read_text())
    assert qualification["runtime_baseline_contract_qualified"]
    assert qualification["engine_run_id"] == expected["engine_run_id"]
    prior = json.loads((BASE / "pr33-native-v3-continuation03-replica/latest-index.json").read_text())
    prior_finished = datetime.fromisoformat(prior["finished_at_utc"])
    assert prior["clock_domain"] == expected["clock_domain"]
    DEST.mkdir()
    hashes, verified, windows = {}, [], []
    notified, failures = False, 0

    def copy(name):
        if not re.fullmatch(
            r"(?:nv3-baseline-18104[5-8]-(?:p(?:128|4096)-m(?:128|256)|mixed)-fixed-"
            r"(?:count|cost)(?:16|32)\.(?:json|events\.jsonl)|gateway-epoch-\d{4}/"
            r"(?:gateway-telemetry\.jsonl|gateway-telemetry-status\.json|process\.log))", name):
            raise ValueError("Unexpected full-baseline artifact")
        if name in hashes:
            return
        remote_sha = helper.remote(f"sha256sum {OUTPUT}/{name}").decode().split()[0]
        path = DEST / name
        path.parent.mkdir(parents=True, exist_ok=True)
        incoming = path.with_suffix(path.suffix + ".incoming")
        subprocess.run([*helper.SCP, f"root@81.27.69.179:{OUTPUT}/{name}", str(incoming)],
                       check=True, timeout=180)
        actual = hashlib.sha256(incoming.read_bytes()).hexdigest()
        if actual != remote_sha:
            raise ValueError("Mirror checksum mismatch; incoming bytes retained")
        incoming.replace(path)
        hashes[name] = actual
        with (DEST / "verified-artifact-sha256.jsonl").open("a") as stream:
            stream.write(json.dumps(dict(artifact=name, sha256=actual)) + "\n")

    console = (DEST / "driver-console.log").open("x")
    process = subprocess.Popen([*helper.SSH,
        "/root/pr33-native-v3-venv/bin/python " + STAGE + "/pr33_native_baseline_full04_remote.py"],
        stdout=console, stderr=subprocess.STDOUT)
    index = None
    deadline = time.monotonic() + 13200
    try:
        while time.monotonic() < deadline:
            try:
                raw = helper.remote(f"cat {OUTPUT}/index.json")
                index = json.loads(raw)
                assert index["protocol_sha256"] == hashlib.sha256(PROTOCOL.read_bytes()).hexdigest()
                assert index["clock_domain"] == expected["clock_domain"]
                assert datetime.fromisoformat(index["started_at_utc"]) > prior_finished
                count = len(index["episodes"])
                assert [e["episode_id"] for e in index["episodes"]] == [
                    e["episode_id"] for e in protocol["episodes"][:count]]
                for entry in index["episodes"][len(verified):]:
                    name = entry["artifact"]
                    copy(name)
                    copy(name.removesuffix(".json") + ".events.jsonl")
                    episode = json.loads((DEST / name).read_text())
                    assert episode["duration_s"] == 120 and episode["completed_at"]
                    assert episode["summary"]["other"] == 0
                    assert len(episode["rows"]) == len(episode["expected_ids"])
                    assert {r["request_id"] for r in episode["rows"]} == set(episode["expected_ids"])
                    receipt = episode["gateway_telemetry_receipt"]
                    assert receipt["assigned_http_gateway_parity"]
                    assert receipt["closed_status"]["status"] == "closed"
                    assert receipt["closed_status"]["dropped"] == receipt["closed_status"]["write_errors"] == 0
                    assert episode["initial_drain"] and len(episode["final_drain"]) == 2
                    assert all(row["native"]["run_id"] == expected["engine_run_id"]
                               for row in episode["samples"])
                    begin, end = episode["start"], episode["start"] + 120
                    assert not windows or begin >= windows[-1][1]
                    assert begin >= int(expected["start_ticks"]) / 100
                    windows.append((begin, end))
                    epoch = index["gateway_epochs"][len(verified)]
                    for filename in ("gateway-telemetry.jsonl", "gateway-telemetry-status.json", "process.log"):
                        copy(epoch["evidence"] + "/" + filename)
                    verified.append(entry["episode_id"])
                assert index["actual_offered_window_s"] == count * 120
                (DEST / "latest-index.json").write_bytes(raw)
                ledger = dict(verified_episode_ids=verified, prior_distinct_seconds=PRIOR_SECONDS,
                    new_distinct_seconds=len(verified) * 120,
                    cumulative_distinct_seconds=PRIOR_SECONDS + len(verified) * 120,
                    smoke_seconds_included=0, windows=windows,
                    clock_domain=expected["clock_domain"], error=index.get("error"),
                    source_completed=index.get("completed", False), mpc_superiority=False)
                (DEST / "distinct-acquisition-ledger.json").write_text(json.dumps(ledger, indent=2) + "\n")
                print(json.dumps({k: ledger[k] for k in
                    ("new_distinct_seconds", "cumulative_distinct_seconds", "source_completed", "mpc_superiority")}), flush=True)
                if not index.get("error") and ledger["cumulative_distinct_seconds"] >= 36000 and not notified:
                    helper.notify("Baseline04 checked distinct acquisition reached10h; smoke excluded. "
                        "Full cohort may still run; no MPC win/heldout score. Inspect verified baseline04 ledger.")
                    notified = True
                if index.get("error") or index.get("completed"):
                    process.wait(timeout=180)
                    break
                if process.poll() is not None:
                    raise RuntimeError("Remote acquisition exited without a terminal index")
                resources = helper.remote("nvidia-smi --query-gpu=utilization.gpu,memory.used,temperature.gpu,"
                    "power.draw --format=csv,noheader,nounits; df -Pk /root | tail -n1")
                with (DEST / "resource-usage.jsonl").open("a") as stream:
                    stream.write(json.dumps(dict(observed_at=datetime.now(timezone.utc).isoformat(),
                        resource=resources.decode().strip(), provider_billing_stop_verified=False)) + "\n")
                failures = 0
            except subprocess.SubprocessError:
                failures += 1
                if failures >= 3:
                    raise
            time.sleep(30)
        else:
            raise TimeoutError("Bounded mirror/acquisition deadline")
        proof_raw = helper.remote(f"cat {STAGE}/owned-service-shutdown.json")
        proof = json.loads(proof_raw)
        assert all(proof[k] is True for k in (
            "serving_port_closed", "owned_processes_exited", "gpu_compute_processes_empty"))
        (DEST / "owned-service-shutdown.json").write_bytes(proof_raw)
        if index is None or index.get("error") or process.returncode:
            if index is not None and len(index["episodes"]) < len(protocol["episodes"]):
                partial = protocol["episodes"][len(index["episodes"])]["episode_id"]
                for suffix in (".json", ".events.jsonl"):
                    name = partial + suffix
                    if subprocess.run([*helper.SSH, f"test -f {OUTPUT}/{name}"], timeout=45).returncode == 0:
                        copy(name)
                for epoch in index["gateway_epochs"]:
                    for filename in ("gateway-telemetry.jsonl", "gateway-telemetry-status.json", "process.log"):
                        name = epoch["evidence"] + "/" + filename
                        if subprocess.run([*helper.SSH, f"test -f {OUTPUT}/{name}"], timeout=45).returncode == 0:
                            copy(name)
            raise RuntimeError("Full cohort incomplete; failed/partial evidence retained, no complete comparison")
        assert len(verified) == 80 and len(hashes) == 400
        assert PRIOR_SECONDS + len(verified) * 120 == 36480
        print("80 closed episodes/400 raw-event-Gateway artifacts verified;36480 distinct seconds."
              " Owned GPU stopped;Pod retained/billing unverified;MPC win NOT established.", flush=True)
    except BaseException:
        if process.poll() is None:
            helper.remote(f"touch {STAGE}/abort-full04")
            process.wait(timeout=180)
        raise
    finally:
        console.close()


if __name__ == "__main__":
    main()
