"""Run the sealed cohort once, with independent Pod-local owned cleanup."""
import json
from pathlib import Path
import signal
import subprocess
import time

from pr33_native_baseline_owned_stop04 import stop


ROOT = Path("/root/pr33-native-v3-baseline-source-c4ace2e")
STAGE = Path("/root/pr33-native-v3-baseline-stage-04")
PROTOCOL_SHA = "f5e6ef6fbc90bca5b48de8c21bff9fdefb320167581f6897b141ae5bb1ca514d"


if __name__ == "__main__":
    import hashlib
    protocol = STAGE / "four-seed-baseline04.json"
    try:
        if hashlib.sha256(protocol.read_bytes()).hexdigest() != PROTOCOL_SHA:
            raise RuntimeError("Sealed protocol changed")
        # Qualification receipt is mirrored only after Mayor verifies all raw bytes.
        qualification = json.loads((STAGE / "runtime-qualification-receipt.json").read_text())
        identity = json.loads((STAGE / "owned-service-identity.json").read_text())
        if (qualification.get("runtime_baseline_contract_qualified") is not True
                or qualification.get("engine_run_id") != identity["engine_run_id"]
                or qualification.get("collector_sha256") != "16e4b406a600baf2e3236b0cfc25f4c4a2a7339223f972c89b9d649ce3e71ff2"
                or qualification.get("symmetric_offered_window_observation") is not True
                or qualification.get("actual_native_uuid_witness") is not True):
            raise RuntimeError("Exact qualified runtime binding absent")
        if (STAGE / "abort-full04").exists():
            raise RuntimeError("Acquisition aborted before exposure")
        process = subprocess.Popen([
            "timeout", "--signal=INT", "--kill-after=30s", "12600s",
            "/root/pr33-native-v3-venv/bin/python",
            str(ROOT / "experiments/mpc-research/native-v3/count_baseline.py"),
            "--execute", "--source-qualified", "--protocol", str(protocol),
            "--config", "/root/pr33-native-v3-control.json",
            "--output", str(ROOT / "results/mpc-native-v3/fixed-baseline-four-seed04"),
        ])
        while process.poll() is None:
            if (STAGE / "abort-full04").exists():
                process.send_signal(signal.SIGINT)
                process.wait(timeout=60)
                raise RuntimeError("Acquisition aborted; exposed seeds remain burned")
            time.sleep(2)
        if process.returncode:
            raise subprocess.CalledProcessError(process.returncode, process.args)
    finally:
        stop()
