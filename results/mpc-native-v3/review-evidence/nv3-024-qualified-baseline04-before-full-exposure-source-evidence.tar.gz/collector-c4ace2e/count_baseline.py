"""Separate natural fixed-count/fixed-cost experiment; never calibrated MPC."""
import argparse
import asyncio
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import random
import socket
import sys
import time
import uuid


ROOT = Path(__file__).resolve().parents[3]
SERVING_SOURCE = "144cef32a9b51c3a74355ff67f5eafdfac6e075f"
GATEWAY_SHA = "a4a8229b0f636b64c945881d062c3ee925ef5fccc5ba2e6fc7629657d3575ea7"
LEGACY_SHA = "78e2c8b91f6b4a582feb69293adff5aa34d4fbd332dfa93b92735bcd0275a069"
OBSERVER_SHA = "77633dc7652066e45b7680d297d3e36ddb97a3e12222de9f526a76b9a01d66b4"
COST_SHA = "cf8162ea687a697d698f26d0bd663fdb9a2f172dce71add05d267ac3dfb43833"
HTTP_CAPTURE_SHA = "0648738704771f80470849b0c0beb671d0f17c9dbc75e4095cff155b20d04be7"
RUNTIME_SHA = "f04c58eb9b5a81e7e1c7a22aaea1cd6b59de88c568ec77d51f1487af4c85b727"
IMPLEMENTATION_SHA = "ed8a6a537b7b663f44f4d6ed42d9679fe88048b4077c25dd778b6e8cf418a014"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(ROOT / "experiments/mpc-research/native_observer"))
from collect_identification import CELLS, persist, summary, tape_for
from baseline_http_capture import capture_baseline_chat


def messages(tokenizer, target, words, topic):
    from collect_interventions import messages as legacy_messages
    return legacy_messages(tokenizer, target, words, topic)


@dataclass(frozen=True)
class Policy:
    name: str
    mode: str
    count: int
    cost: int


POLICIES = (
    Policy("fixed-count16", "protected", 16, 32),
    Policy("fixed-count32", "protected", 32, 32),
    Policy("fixed-cost16", "cost_aware", 32, 16),
    Policy("fixed-cost32", "cost_aware", 32, 32),
)


def protocol_for(cost_spec, *, smoke=False):
    episodes = []
    cells = ("p128-m128", "mixed") if smoke else tuple(CELLS)
    seeds = (180005,) if smoke else (181045, 181046, 181047, 181048)
    duration = 12 if smoke else 120
    for block, seed in enumerate(seeds):
        for cell in cells:
            order = list(POLICIES)
            random.Random(f"baseline-order:181045:{cell}").shuffle(order)
            if block % 2:
                order.reverse()
            for policy in order:
                episodes.append(dict(
                    episode_id=f"nv3-baseline-{seed}-{cell}-{policy.name}",
                    seed_block=seed, split="train", cell=cell,
                    policy=policy.name, duration_s=duration))
    return dict(
        schema="native-v3-fixed-baseline-v2", serving_source_commit=SERVING_SOURCE,
        serving_gateway_sha256=GATEWAY_SHA, legacy_collector_sha256=LEGACY_SHA,
        collector_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        classifier_sha256=hashlib.sha256(Path(__file__).with_name("baseline_http_capture.py").read_bytes()).hexdigest(),
        http_capture_sha256=HTTP_CAPTURE_SHA, runtime_sha256=RUNTIME_SHA,
        implementation_hash=IMPLEMENTATION_SHA, mpc_instrumentation=True,
        observer_sha256=OBSERVER_SHA, cost_spec=cost_spec, smoke=smoke,
        max_waiting=2, shared_upstream_client=False, forced_ignore_eos=False,
        requested_sample_period_s=.1, max_state_age_s=.5,
        ttft_slo_s=.5, tpot_slo_s=.05,
        http_attempt_timeout_s=30,
        terminal_scope="Natural EOS eligible; length/timeout not good; all offered IDs retained.",
        burn_rule="Any incomplete cohort, source, telemetry or HTTP failure stops; no resume or replacement of exposed seeds. Only complete seed/policy matrices support comparisons.",
        smoke_overload_burst=40 if smoke else 0,
        cost_drain_contract="Unchanged0648 drain_evidence with complete Source144 request-mark snapshot; exact empty requests/reserved0, run/identity/domain and500ms freshness. Scalar metrics preserved without normalization.",
        failed_final_drain_probes_retained=True,
        initial_drain_probes_retained=True,
        cost_snapshot_observation_scope="Initial/final drain only; no policy-dependent admin snapshot GET during offered observation windows.",
        hypotheses="Baseline support only; no MPC or superiority permit.",
        episodes=episodes, planned_offered_window_s=len(episodes)*duration,
    )


def validate_protocol(protocol):
    if type(protocol.get("smoke")) is not bool:
        raise ValueError("explicit experiment partition required")
    if protocol != protocol_for(protocol.get("cost_spec"), smoke=protocol["smoke"]):
        raise ValueError("unregistered or changed baseline protocol")
    from mpc_lab.contracts import CostSpec
    if CostSpec(**protocol["cost_spec"]).fingerprint != COST_SHA:
        raise ValueError("public serving cost specification changed")
    if hashlib.sha256(Path(__file__).with_name("collect_identification.py").read_bytes()).hexdigest() != LEGACY_SHA:
        raise ValueError("historical tape/payload/capture helpers changed")
    if hashlib.sha256((ROOT / "gateway.py").read_bytes()).hexdigest() != GATEWAY_SHA:
        raise ValueError("serving Gateway changed")
    from mpc_lab.contracts import implementation_hash
    for path, expected in (
        (ROOT / "mpc_lab/http_capture.py", HTTP_CAPTURE_SHA),
        (ROOT / "mpc_lab/runtime.py", RUNTIME_SHA),
        (ROOT / "experiments/mpc-research/native_observer/pr33_native_observer.py", OBSERVER_SHA),
    ):
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError("bound runtime/capture/observer changed")
    if implementation_hash() != IMPLEMENTATION_SHA:
        raise ValueError("serving implementation changed")


def gateway_environment(config, policy, evidence, cost_spec):
    environment = dict(os.environ)
    for key in ("MODEL_NAME", "ADMIN_API_KEY", "COST_INTERCEPT", "INPUT_TOKEN_COST",
                "OUTPUT_TOKEN_COST", "MIN_REQUEST_COST", "DEFAULT_MAX_TOKENS"):
        if key in config:
            environment[key] = str(config[key])
    environment.update(
        HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
        PYTHONPATH=str(ROOT), VLLM_URL="http://127.0.0.1:8000",
        ADMISSION_MODE=policy.mode, MAX_IN_FLIGHT=str(policy.count), MAX_WAITING="2",
        MAX_ADMITTED_COST=str(policy.cost), MPC_LAB_ENABLED="true",
        MPC_OWNER_LEDGER_ENABLED="false", BENCHMARK_REQUEST_IDS="1",
        SHARED_UPSTREAM_CLIENT="0", PREFILL_LAB_RAW_COMPLETIONS="0",
        GATEWAY_DIAGNOSTICS="0", LOOP_LAG_TELEMETRY="0",
        TELEMETRY_JSONL=str(evidence / "gateway-telemetry.jsonl"),
        TELEMETRY_STATUS_JSON=str(evidence / "gateway-telemetry-status.json"))
    for key, field in (
        ("COST_INTERCEPT", "intercept"), ("INPUT_TOKEN_COST", "input_per_token"),
        ("OUTPUT_TOKEN_COST", "output_per_token"), ("MIN_REQUEST_COST", "minimum"),
        ("DEFAULT_MAX_TOKENS", "default_max_tokens"),
    ):
        environment[key] = str(cost_spec[field])
    from mpc_lab.contracts import CostSpec, ModelParameters
    parameters = ModelParameters(cost_spec=CostSpec(**cost_spec),
        model_version="native-id-unfitted-v1", calibration_version="unfitted-not-validated")
    environment.update(
        MPC_MODEL_VERSION=parameters.model_version,
        MPC_CALIBRATION_VERSION=parameters.calibration_version,
        MPC_SUPPORT_HASH=parameters.identity.support_hash,
        MPC_TOKENIZER_IDENTITY=cost_spec["tokenizer_identity"].split(";model=", 1)[0])
    return environment


def policy_metrics(metrics, policy, cost_spec=None):
    if (metrics.get("admission_mode") != policy.mode
            or metrics.get("max_in_flight") != policy.count
            or metrics.get("max_waiting_capacity") != 2
            or metrics.get("initial_admission_budget") != policy.cost
            or metrics.get("admission_budget") != policy.cost
            or metrics.get("budget_version") != 0
            or metrics.get("shared_upstream_client", False) is not False
            or metrics.get("tokenizer_available") is not True):
        raise ValueError("actual static admission policy differs")
    if cost_spec is not None and any(
        metrics.get(key) != cost_spec[field] for key, field in (
            ("cost_intercept", "intercept"), ("input_token_cost", "input_per_token"),
            ("output_token_cost", "output_per_token"))):
        raise ValueError("actual cost arithmetic differs")


def drained(frame, metrics, now, cost_drain=None):
    at = metrics.get("state_sampled_at")
    if (type(at) not in (int, float) or not 0 <= now-at <= .5
            or frame.get("complete") is not True
            or any(type(frame.get(k)) is not int or frame[k] < 0
                   for k in ("running", "waiting", "orphaned"))):
        return False
    stock_clear = (isinstance(cost_drain, dict) and cost_drain.get("drained") is True
                   if metrics.get("admission_mode") == "cost_aware"
                   else metrics["current_admitted_cost"] == 0)
    return (metrics["current_in_flight"] == 0 and metrics["current_waiting"] == 0
            and stock_clear
            and not any(frame[k] for k in ("running", "waiting", "orphaned")))


def payloads_for(tokenizer, seed, cell, tape):
    rng = random.Random(f"payloads:{seed}:{cell}")
    cache, payloads = {}, []
    for _ in tape:
        selected = rng.choice(("p128-m256", "p4096-m128")) if cell == "mixed" else cell
        prompt, maximum, _ = CELLS[selected]
        words = rng.choice((28, 32, 36) if maximum == 128 else (65, 80, 95))
        topic = rng.choice(("the solar system", "ocean currents", "photosynthesis", "volcanoes"))
        key = prompt, maximum, words, topic
        if key not in cache:
            cache[key] = messages(tokenizer, prompt, words, topic)
        payloads.append(dict(
            model="Qwen/Qwen3-4B-Instruct-2507", messages=cache[key],
            temperature=0, max_tokens=maximum))
    return payloads


def verify_epoch(evidence, episode):
    status = json.loads((evidence / "gateway-telemetry-status.json").read_text())
    if (status.get("status") != "closed" or status.get("run_id") != episode["gateway_run_id"]
            or status.get("dropped") != 0 or status.get("write_errors") != 0):
        raise ValueError("closed loss-free Gateway telemetry required")
    raw = (evidence / "gateway-telemetry.jsonl").read_bytes()
    records = [json.loads(line) for line in raw.splitlines()]
    if any(row.get("run_id") != episode["gateway_run_id"] for row in records):
        raise ValueError("foreign telemetry epoch")
    assigned = set(episode["expected_ids"])
    outcomes = {row["request_id"]: row for row in episode["rows"]}
    request_events = defaultdict(Counter)
    for row in records:
        if row.get("request_id") is not None:
            request_events[row["request_id"]][row["event"]] += 1
    if not set(request_events) <= assigned:
        raise ValueError("foreign Gateway client inventory")
    for rid in assigned:
        events = request_events[rid]
        expected = "completed" if outcomes[rid]["status"] == "complete" else "rejected"
        if (events["received"] != 1 or events[expected] != 1
                or events["accepted"] != (expected == "completed")):
            raise ValueError("assigned Gateway/HTTP outcome parity failed")
    admitted = {rid for rid, row in outcomes.items() if row["status"] == "complete"}
    visible = {mark.get("gateway_request_id") for row in episode["samples"]
               for mark in row["native"].get("requests", [])}
    if not visible <= admitted:
        raise ValueError("native UUID not joined to an admitted assigned client")
    return dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw),
                closed_status=status, assigned_http_gateway_parity=True,
                observed_native_uuid_join=bool(visible), native_visible_ids=len(visible),
                owner_journal_qualified=False, authentication_qualified=False)


async def run(args, protocol):
    import httpx
    from transformers import AutoTokenizer
    from mpc_lab.runtime import local_clock_domain, snapshot_from_dict
    from mpc_lab.contracts import CostSpec, ModelParameters
    from mpc_lab.http_capture import drain_evidence
    validate_protocol(protocol)
    if not args.source_qualified:
        raise ValueError("separate source/runtime qualification required; flag is attestation only")
    with socket.socket() as sock:
        if sock.connect_ex(("127.0.0.1", 8080)) == 0:
            raise ValueError("foreign or prior Gateway active")
    output = args.output.resolve()
    if not output.is_relative_to(ROOT / "results") or output.exists():
        raise ValueError("fresh results directory required")
    output.mkdir(parents=True)
    config = json.loads(args.config.read_text())
    if f";model={config['MODEL_NAME']};" not in protocol["cost_spec"]["tokenizer_identity"]:
        raise ValueError("actual tokenizer/model binding differs")
    tokenizer = AutoTokenizer.from_pretrained(config["MODEL_NAME"], local_files_only=True)
    parameters = ModelParameters(cost_spec=CostSpec(**protocol["cost_spec"]),
        model_version="native-id-unfitted-v1", calibration_version="unfitted-not-validated")
    domain, engine_run = local_clock_domain(), None
    index = dict(
        schema=protocol["schema"], protocol_sha256=hashlib.sha256(args.protocol.read_bytes()).hexdigest(),
        serving_source_commit=SERVING_SOURCE, collector_sha256=protocol["collector_sha256"],
        classifier_sha256=protocol["classifier_sha256"], implementation_hash=IMPLEMENTATION_SHA,
        started_at_utc=datetime.now(timezone.utc).isoformat(),
        clock_domain=domain, calibrated=False, mpc_active=False,
        episodes=[], gateway_epochs=[], actual_offered_window_s=0)
    persist(output / "index.json", index)
    process = None
    async with httpx.AsyncClient(
        base_url="http://127.0.0.1:8080", timeout=30, trust_env=False,
        limits=httpx.Limits(max_connections=None, max_keepalive_connections=100)) as client, \
        httpx.AsyncClient(base_url="http://127.0.0.1:8000", timeout=5, trust_env=False,
                         headers={"x-observer-key": config["ADMIN_API_KEY"]}) as native:
        async def sample(policy, gateway_run, *, for_drain=False):
            nonlocal engine_run
            cost_snapshot = None
            if for_drain and policy.mode == "cost_aware":
                response = await client.get("/admin/mpc/state",
                    headers={"x-admin-api-key": config["ADMIN_API_KEY"]})
                response.raise_for_status()
                cost_snapshot = response.json()
            response = await client.get("/metrics")
            response.raise_for_status()
            metrics = response.json()
            policy_metrics(metrics, policy, protocol["cost_spec"])
            if metrics["telemetry_run_id"] != gateway_run:
                raise ValueError("Gateway epoch changed")
            response = await native.get("/pr33-native/state")
            response.raise_for_status()
            frame = response.json()
            engine_run = engine_run or frame["run_id"]
            now = time.monotonic()
            if (frame["clock_domain"] != domain or frame["run_id"] != engine_run
                    or frame["observer_sha256"] != OBSERVER_SHA
                    or not 0 <= now-frame["sampled_at"] <= .5
                    or not 0 <= frame["frontend_sampled_at"]-frame["sampled_at"] <= .05):
                raise ValueError("native source/clock/freshness changed")
            cost_drain = None
            if cost_snapshot is not None:
                cost_drain = drain_evidence(snapshot_from_dict(cost_snapshot), frame,
                    identity=parameters.identity, gateway_run=gateway_run, engine_run=engine_run,
                    domain=domain, now=now, pending_operation=False, max_age_s=.5)
            return dict(native=frame, metrics=metrics, received_at=now,
                        cost_snapshot=cost_snapshot, cost_drain=cost_drain)

        async def drain(policy, gateway_run, record_probe=None):
            end, checks = time.monotonic()+30, []
            while time.monotonic() < end:
                row = await sample(policy, gateway_run, for_drain=True)
                if record_probe is not None:
                    record_probe(row)
                checks = checks+[row] if drained(
                    row["native"], row["metrics"], row["received_at"], row["cost_drain"]) else []
                if len(checks) == 2:
                    return checks
                await asyncio.sleep(.05)
            raise ValueError("physical/Gateway drain not established")

        async def stop_gateway():
            if process is not None and process.returncode is None:
                process.terminate()
                try:
                    await asyncio.wait_for(process.wait(), 15)
                except TimeoutError:
                    process.kill()
                    await process.wait()

        try:
            for spec in protocol["episodes"]:
                validate_protocol(protocol)
                policy = next(p for p in POLICIES if p.name == spec["policy"])
                evidence = output / f"gateway-epoch-{len(index['gateway_epochs'])+1:04d}"
                evidence.mkdir()
                with (evidence / "process.log").open("x") as log:
                    process = await asyncio.create_subprocess_exec(
                        sys.executable, "-m", "uvicorn", "gateway:app", "--host", "127.0.0.1",
                        "--port", "8080", "--workers", "1", cwd=ROOT,
                        env=gateway_environment(config, policy, evidence, protocol["cost_spec"]),
                        stdout=log, stderr=asyncio.subprocess.STDOUT)
                index["gateway_epochs"].append(dict(
                    pid=process.pid, evidence=evidence.name, policy=policy.name))
                persist(output / "index.json", index)
                for attempt in range(90):
                    if process.returncode is not None:
                        raise ValueError("owned Gateway exited")
                    try:
                        response = await client.get("/metrics")
                        response.raise_for_status()
                        metrics = response.json()
                        policy_metrics(metrics, policy, protocol["cost_spec"])
                        gateway_run = metrics["telemetry_run_id"]
                        break
                    except httpx.HTTPError:
                        if attempt == 89:
                            raise
                        await asyncio.sleep(1)
                episode = dict(spec, rows=[], samples=[], gateway_run_id=gateway_run)
                path = output / (spec["episode_id"]+".json")
                persist(path, episode)
                def record_initial_drain(row):
                    episode.setdefault("initial_drain_probes", []).append(row)
                    persist(path, episode)
                episode["initial_drain"] = await drain(policy, gateway_run, record_initial_drain)
                tape = tape_for(spec["seed_block"], spec["cell"], spec["duration_s"])
                if protocol["smoke"]:
                    tape = sorted([.5] * protocol["smoke_overload_burst"] + tape)
                payloads = payloads_for(tokenizer, spec["seed_block"], spec["cell"], tape)
                ids = [uuid.uuid4().hex for _ in tape]
                episode.update(start=time.monotonic()+.5, offered_tape=tape, expected_ids=ids)
                persist(path, episode)
                stop = asyncio.Event()
                tasks = []
                with path.with_suffix(".events.jsonl").open("x") as events:
                    last_sync = time.monotonic()
                    def event(kind, value):
                        nonlocal last_sync
                        events.write(json.dumps(dict(kind=kind, value=value), allow_nan=False)+"\n")
                        if time.monotonic()-last_sync >= 1:
                            events.flush()
                            os.fsync(events.fileno())
                            last_sync = time.monotonic()
                    def record(row):
                        episode["rows"].append(row)
                        event("http_outcome", row)
                    def record_drain(row):
                        episode.setdefault("final_drain_probes", []).append(row)
                        event("final_drain_probe", row)
                    async def observe():
                        while not stop.is_set():
                            row = await sample(policy, gateway_run)
                            episode["samples"].append(row)
                            event("state", row)
                            await asyncio.sleep(.1)
                    async def offers():
                        await asyncio.gather(*(capture_baseline_chat(
                            client, "/v1/chat/completions", payload, rid, episode["start"]+at,
                            policy_mode=policy.mode, enabled=True,
                            timeout_s=protocol["http_attempt_timeout_s"], record=record)
                            for rid, at, payload in zip(ids, tape, payloads)))
                        await asyncio.sleep(max(0, episode["start"]+spec["duration_s"]-time.monotonic()))
                    tasks = [asyncio.create_task(observe()), asyncio.create_task(offers())]
                    try:
                        done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
                        for task in done:
                            task.result()
                        stop.set()
                        episode["final_drain"] = await drain(policy, gateway_run, record_drain)
                        if (len(episode["rows"]) != len(ids)
                                or {r["request_id"] for r in episode["rows"]} != set(ids)):
                            raise ValueError("all-offered identity/completeness failed")
                        episode["summary"] = summary(episode["rows"], episode["start"], spec["duration_s"])
                        if episode["summary"]["other"]:
                            raise ValueError("failed HTTP retained; no valid baseline acquisition claim")
                        episode["completed_at"] = time.monotonic()
                    finally:
                        stop.set()
                        for task in tasks:
                            task.cancel()
                        await asyncio.gather(*tasks, return_exceptions=True)
                        events.flush()
                        os.fsync(events.fileno())
                        persist(path, episode)
                        persist(output / "index.json", index)
                await stop_gateway()
                episode["gateway_telemetry_receipt"] = verify_epoch(evidence, episode)
                if protocol["smoke"] and not episode["gateway_telemetry_receipt"]["observed_native_uuid_join"]:
                    raise ValueError("qualification actual native UUID witness absent")
                if (protocol["smoke"] and policy.mode == "protected"
                        and episode["summary"]["rejected"] == 0):
                    raise ValueError("qualification count rejection witness absent")
                persist(path, episode)
                index["episodes"].append(dict(
                    episode_id=spec["episode_id"], artifact=path.name, split="train"))
                index["actual_offered_window_s"] += spec["duration_s"]
                persist(output / "index.json", index)
                print(json.dumps(dict(episode=spec["episode_id"],
                                      valid_seconds=index["actual_offered_window_s"])), flush=True)
            index["completed"] = True
        except BaseException as exc:
            index["error"] = type(exc).__name__+": "+str(exc)
            raise
        finally:
            await stop_gateway()
            index["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
            persist(output / "index.json", index)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare", action="store_true")
    mode.add_argument("--execute", action="store_true")
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--cost-spec", type=Path)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--config", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--source-qualified", action="store_true")
    args = parser.parse_args()
    if args.prepare:
        if args.cost_spec is None:
            parser.error("--prepare requires public cost specification")
        protocol = protocol_for(json.loads(args.cost_spec.read_text()), smoke=args.smoke)
        validate_protocol(protocol)
        with args.protocol.open("x") as stream:
            json.dump(protocol, stream, indent=2, allow_nan=False)
    else:
        if args.config is None or args.output is None:
            parser.error("--execute requires config and output")
        asyncio.run(run(args, json.loads(args.protocol.read_text())))


if __name__ == "__main__":
    main()
