"""Reuse only the retained, fingerprinted Source144 deployment."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import socket
import subprocess


ROOT = Path("/root/pr33-native-v3-source-144cef3")
STAGE = Path("/root/pr33-native-v3-baseline-stage-04")
VENV = Path("/root/pr33-native-v3-venv")
MODEL = "/root/.cache/huggingface/hub/models--Qwen--Qwen3-4B-Instruct-2507/snapshots/cdbee75f17c01a7cc42f958dc650907174af0554"


if __name__ == "__main__":
    for port in (8000, 8080):
        with socket.socket() as sock:
            if sock.connect_ex(("127.0.0.1", port)) == 0:
                raise RuntimeError("Prior or foreign service active")
    gpu = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=uuid", "--format=csv,noheader"], text=True).strip()
    if gpu != "GPU-9e2cff5f-3fc0-a820-884d-495cb605b5a9":
        raise RuntimeError("Authorized GPU identity changed")
    if subprocess.check_output(
        ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True).strip():
        raise RuntimeError("Prior or foreign GPU process active")
    versions = {name: importlib.metadata.version(name) for name in ("vllm", "torch", "transformers")}
    if versions != {"vllm": "0.30.0", "torch": "2.13.0", "transformers": "5.22.1"}:
        raise RuntimeError("Serving software changed")
    observer = ROOT / "experiments/mpc-research/native_observer/pr33_native_observer.py"
    if hashlib.sha256(observer.read_bytes()).hexdigest() != "77633dc7652066e45b7680d297d3e36ddb97a3e12222de9f526a76b9a01d66b4":
        raise RuntimeError("Observer source changed")
    config = json.loads(Path("/root/pr33-native-v3-control.json").read_text())
    if config["MODEL_NAME"] != MODEL:
        raise RuntimeError("Model snapshot changed")
    services = STAGE / "serving-vllm"
    services.mkdir()
    (services / "vllm.pid").write_text(str(os.getpid()) + "\n")
    args = [
        "serve", MODEL, "--served-model-name", "Qwen/Qwen3-4B-Instruct-2507",
        "--host", "127.0.0.1", "--port", "8000", "--dtype", "bfloat16",
        "--max-model-len", "8192", "--max-num-seqs", "32",
        "--max-num-batched-tokens", "2048", "--gpu-memory-utilization", "0.8",
        "--no-enable-prefix-caching", "--tensor-parallel-size", "1",
        "--enable-request-id-headers",
    ]
    (services / "vllm-launch.json").write_text(json.dumps({
        "source_commit": "144cef32a9b51c3a74355ff67f5eafdfac6e075f",
        "arguments": args,
        "scope": "Baseline qualification/support only; no calibrated MPC or physical pilot.",
    }, indent=2) + "\n")
    os.chdir(ROOT)
    os.environ.update(
        PATH=str(VENV / "bin") + ":" + os.environ["PATH"],
        PYTHONPATH=str(ROOT) + ":" + str(observer.parent),
        VLLM_PLUGINS="pr33_native_observer", PR33_NATIVE_OBSERVER_ENABLED="1",
        PR33_NATIVE_OBSERVER_KEY=config["ADMIN_API_KEY"],
        HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", VLLM_NO_USAGE_STATS="1",
    )
    executable = str(VENV / "bin/vllm")
    os.execv(executable, [executable, *args])
