"""Fresh runtime qualification; failed qualification stops only the owned backend."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess


BASE = Path(__file__).resolve().parent
SOURCE = "/root/pr33-native-v3-baseline-source-c4ace2e"
STAGE = "/root/pr33-native-v3-baseline-stage-04"
OUTPUT = SOURCE + "/results/mpc-native-v3/fixed-baseline-qualification04"
DEST = BASE / "pr33-native-v3-baseline-qualification04-replica"
PROTOCOL = BASE / "pr33-native-v3-qualification-smoke04-protocol.json"
spec = importlib.util.spec_from_file_location("owned_stop_helper04", BASE / "pr33_native_identification03_monitor.py")
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


def copy(name):
    if not re.fullmatch(
        r"(?:index\.json|nv3-baseline-180005-(?:p128-m128|mixed)-fixed-(?:count|cost)(?:16|32)"
        r"\.(?:json|events\.jsonl)|gateway-epoch-\d{4}/(?:gateway-telemetry\.jsonl|"
        r"gateway-telemetry-status\.json|process\.log))", name):
        raise ValueError("Unregistered qualification artifact")
    expected = helper.remote(f"sha256sum {OUTPUT}/{name}").decode().split()[0]
    path = DEST / name
    path.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([*helper.SCP, f"root@81.27.69.179:{OUTPUT}/{name}", str(path)],
                   check=True, timeout=180)
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise ValueError("Qualification checksum mismatch; preserve incoming evidence")
    return actual


def main():
    DEST.mkdir()
    expected = json.loads((BASE / "pr33-native-v3-baseline-04-owned-service-identity.json").read_text())
    helper.STAGE, helper.DEST = STAGE, DEST
    try:
        subprocess.run([*helper.SSH,
            "timeout --signal=INT --kill-after=30s 480s /root/pr33-native-v3-venv/bin/python "
            + SOURCE + "/experiments/mpc-research/native-v3/count_baseline.py --execute "
            "--source-qualified --protocol " + STAGE + "/qualification-smoke04.json "
            "--config /root/pr33-native-v3-control.json --output " + OUTPUT],
            check=True, timeout=600)
        hashes = {"index.json": copy("index.json")}
        index = json.loads((DEST / "index.json").read_text())
        protocol = json.loads(PROTOCOL.read_text())
        assert index.get("completed") is True and not index.get("error")
        assert index["protocol_sha256"] == hashlib.sha256(PROTOCOL.read_bytes()).hexdigest()
        assert len(index["episodes"]) == 8 and index["actual_offered_window_s"] == 96
        assert [e["episode_id"] for e in index["episodes"]] == [e["episode_id"] for e in protocol["episodes"]]
        for entry in index["episodes"]:
            name = entry["artifact"]
            hashes[name] = copy(name)
            events = name.removesuffix(".json") + ".events.jsonl"
            hashes[events] = copy(events)
            episode = json.loads((DEST / name).read_text())
            receipt = episode["gateway_telemetry_receipt"]
            assert receipt["assigned_http_gateway_parity"]
            assert receipt["observed_native_uuid_join"] and receipt["native_visible_ids"] > 0
            assert episode["initial_drain_probes"] and episode["final_drain_probes"]
            assert episode["gateway_run_id"] == receipt["closed_status"]["run_id"]
            for row in episode["samples"]:
                assert row["native"]["run_id"] == expected["engine_run_id"]
                assert row["cost_snapshot"] is None
            if "fixed-count" in entry["episode_id"]:
                assert episode["summary"]["rejected"] > 0
                assert any(row.get("source_capture_status") == "failed"
                           and row["status"] == "rejected" for row in episode["rows"])
        for epoch in index["gateway_epochs"]:
            for name in ("gateway-telemetry.jsonl", "gateway-telemetry-status.json", "process.log"):
                artifact = epoch["evidence"] + "/" + name
                hashes[artifact] = copy(artifact)
        (DEST / "verified-artifact-sha256.jsonl").write_text(
            "".join(json.dumps(dict(artifact=n, sha256=h)) + "\n" for n, h in hashes.items()))
        receipt = dict(
            scope="Eight actual HTTP/Source144-product admission runtime qualification episodes only",
            engine_run_id=expected["engine_run_id"], collector_sha256=protocol["collector_sha256"],
            classifier_sha256=protocol["classifier_sha256"], complete_episodes=8,
            smoke_seconds_excluded_from_ten_hour=96, artifact_sha256=hashes,
            symmetric_offered_window_observation=True, actual_native_uuid_witness=True,
            runtime_baseline_contract_qualified=True, calibrated_mpc_permit=False,
            physical_cohort_pilot_permit=False, baseline_superiority_claim=False,
            provider_billing_stop_verified=False)
        (DEST / "runtime-qualification-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        print(json.dumps({k: v for k, v in receipt.items() if k != "artifact_sha256"}), flush=True)
    except BaseException:
        try:
            helper.stop_owned(expected)
        finally:
            raise


if __name__ == "__main__":
    main()
