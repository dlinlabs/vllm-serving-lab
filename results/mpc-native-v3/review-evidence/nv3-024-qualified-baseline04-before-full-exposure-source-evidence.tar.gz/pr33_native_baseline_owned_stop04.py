"""Pod-local cleanup survives loss of the Mayor SSH transport."""
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time


STAGE = Path("/root/pr33-native-v3-baseline-stage-04")


def stop():
    expected = json.loads((STAGE / "owned-service-identity.json").read_text())
    pid = int((STAGE / "serving-vllm/vllm.pid").read_text())
    if pid != expected["pid"]:
        raise RuntimeError("Owned PID file changed")
    with socket.socket() as sock:
        if sock.connect_ex(("127.0.0.1", 8080)) == 0:
            raise RuntimeError("Gateway active; refuse backend shutdown")
    ledger = STAGE / "shutdown-owned-processes.json"
    owned = {int(k): v for k, v in json.loads(ledger.read_text()).items()} if ledger.exists() else {}
    proc = Path("/proc") / str(pid)
    if proc.joinpath("cmdline").exists():
        stat = proc.joinpath("stat").read_text().rsplit(")", 1)[1].split()
        if (stat[19] != expected["start_ticks"]
                or hashlib.sha256(proc.joinpath("cmdline").read_bytes()).hexdigest()
                != expected["cmdline_sha256"]):
            raise RuntimeError("Owned PID/start/command mismatch")
        owned[pid] = stat[19]
        processes = {}
        for entry in Path("/proc").iterdir():
            if not entry.name.isdigit():
                continue
            try:
                fields = entry.joinpath("stat").read_text().rsplit(")", 1)[1].split()
                processes[int(entry.name)] = int(fields[1]), fields[19]
            except (FileNotFoundError, ProcessLookupError):
                continue
        changed = True
        while changed:
            changed = False
            for child, (parent, start) in processes.items():
                if parent in owned and child not in owned:
                    owned[child] = start
                    changed = True
        ledger.write_text(json.dumps(owned, sort_keys=True))
        os.kill(pid, signal.SIGTERM)
    for _ in range(120):
        alive = []
        for child, start in owned.items():
            try:
                fields = Path(f"/proc/{child}/stat").read_text().rsplit(")", 1)[1].split()
                if fields[19] == start and fields[0] not in ("Z", "X"):
                    alive.append(child)
            except (FileNotFoundError, ProcessLookupError):
                pass
        with socket.socket() as sock:
            if sock.connect_ex(("127.0.0.1", 8000)) != 0 and not alive:
                gpu = subprocess.check_output(
                    ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader,nounits"],
                    text=True, timeout=15).strip()
                if gpu:
                    raise RuntimeError("Unidentified GPU compute remains")
                proof = dict(owned_vllm_pid=pid, serving_port_closed=True,
                    owned_processes_exited=True, gpu_compute_processes_empty=True,
                    owned_process_ids=sorted(owned), pod_retained=True,
                    provider_billing_stop_verified=False)
                (STAGE / "owned-service-shutdown.json").write_text(json.dumps(proof) + "\n")
                print(json.dumps(proof), flush=True)
                return
        time.sleep(1)
    raise RuntimeError("Bounded owned shutdown incomplete")


if __name__ == "__main__":
    stop()
