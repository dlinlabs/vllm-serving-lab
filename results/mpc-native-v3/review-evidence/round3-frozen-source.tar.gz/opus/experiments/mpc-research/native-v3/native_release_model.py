"""NV3 (Opus) history-conditioned cumulative original-cost release model.

Offline, stdlib-only research module. It grants no actuation authority, runs no
GPU/HTTP work and contains no service constants: every fitted quantity comes from
Train episodes that a caller assembles from actual Gateway marks and native frames.
Passing unit fixtures are not native results or statistical guarantees.

Episode schema (one actuated cap episode, all times in one monotonic clock domain):
  episode_id, seed_block, partition in {train, calibration, development},
  clock_domain, run_id (Gateway epoch), native_run_id, observer_sha256,
  identity (optional Gateway model identity; checked when present),
  observations: [{gateway: /admin/mpc/state document, received_at,
                  native: pr33-native-read-only-v1 frame or None, native_received_at}]
  ledger: contiguous mpc_ledger frames, or None -> snapshot-bracket truth
  cap_plan: optional [[assigned_from, budget], ...] frozen before the episode, on the
            SLOT_S grid; origin_grid_start / origin_grid_s: optional decision grid.
  actions: optional actual CAS receipts [{planned_at (None for pre-assignment), budget,
           budget_version, applied_at, ack_received_at}]. When present every joined
           snapshot's (budget, budget_version) must match the ACK in force at its
           sampled_at, origins must be cut before the next planned action's ACK, and an
           origin with a command sent but no ACK received by t0 abstains.
Origins are decision times on a fixed grid (not observation cadence). An origin uses
the latest joined observation received at or before the grid time. The forecast target
is the cost of that observation's live marks released in (gateway.sampled_at, t0+h].
This is a marginal cumulative-release forecast, not a joint good/unreleased/tail kernel.
"""
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import sys

HORIZONS = (1.0, 3.0, 5.0)
PARTITIONS = ("train", "calibration", "development")
FINAL_HELDOUT = frozenset(range(160021, 160025))
NATIVE_ID = re.compile(r"chatcmpl-([0-9a-f]{32})-[0-9a-f]{8}")   # native_prediction.NATIVE_ID
MAX_AGE_S = 0.5                 # state_sample.join_observations max_age_s
FRONTEND_WIDTH_S = 0.05         # state_sample.join_observations frontend bracket
HISTORY_S = 2.0
MIN_HISTORY_SPAN_S = 0.5
SLOT_S = 1.0                    # actual protocol cap slots are integer at_s seconds
ORIGIN_GRID_S = 1.0             # predeclared decision cadence
L2 = 1.0          # predeclared on standardized features; never tuned
ALPHA = 0.1       # predeclared calibration miscoverage (descriptive band, no guarantee)
NEWTON_MAX, NEWTON_TOL = 50, 1e-8
EPS = 1e-9
BASE_FEATURES = ("cost", "prompt_k", "max_h", "started", "age_s", "native_unknown",
                 "progress", "remaining_h", "decode_batch", "prefill_k", "waiting",
                 "cohort_cost", "budget", "history_rate", "history_missing")


def plan_slots(horizon):
    return math.ceil(horizon / SLOT_S - EPS)


def feature_names(horizon):
    return BASE_FEATURES + ("plan_phase",) + tuple(
        f"plan_b{k}" for k in range(plan_slots(horizon) + 1))


def _finite(value):
    return type(value) in (int, float) and math.isfinite(value)


# ----------------------------------------------------------------------------
# Observation validation (mirrors state_sample.join_observations) and causal features
# ----------------------------------------------------------------------------

def _marks(document, episode):
    if (not isinstance(document, dict) or document.get("run_id") != episode["run_id"]
            or document.get("clock_domain") != episode["clock_domain"]
            or (episode.get("identity") is not None
                and document.get("identity") != episode["identity"])
            or document.get("complete") is not True
            or type(document.get("sequence")) is not int
            or not _finite(document.get("sampled_at"))
            or not _finite(document.get("budget")) or document["budget"] <= 0):
        raise ValueError("gateway_identity_or_clock")
    spec = document.get("cost_spec")
    marks = {}
    for mark in document["requests"]:
        rid = mark.get("request_id")
        received = mark.get("received_at")
        if (not isinstance(rid, str) or rid in marks or not _finite(mark.get("cost"))
                or mark["cost"] <= 0 or type(mark.get("prompt_tokens")) is not int
                or mark["prompt_tokens"] <= 0
                or type(mark.get("max_tokens")) is not int or mark["max_tokens"] <= 0
                or not _finite(mark.get("admitted_at"))
                or mark["admitted_at"] > document["sampled_at"]
                or (received is not None and not (_finite(received)
                                                   and received <= mark["admitted_at"]))
                or (mark.get("first_at") is not None and not (
                    _finite(mark["first_at"])
                    and mark["admitted_at"] <= mark["first_at"] <= document["sampled_at"]))):
            raise ValueError("gateway_mark")
        if spec is not None:
            estimate = max(spec["minimum"], spec["intercept"]
                           + spec["input_per_token"] * mark["prompt_tokens"]
                           + spec["output_per_token"] * mark["max_tokens"])
            if not math.isclose(mark["cost"], estimate, rel_tol=1e-12):
                raise ValueError("gateway_cost_spec_mismatch")
        marks[rid] = mark
    return marks


def _native(frame, marks, episode, gateway_received_at, native_received_at):
    if (not isinstance(frame, dict) or frame.get("schema") != "pr33-native-read-only-v1"
            or frame.get("complete") is not True
            or frame.get("run_id") != episode.get("native_run_id")
            or frame.get("clock_domain") != episode["clock_domain"]
            or frame.get("observer_sha256") != episode.get("observer_sha256")):
        raise ValueError("native_source_or_clock")
    times = (frame.get("sampled_at"), frame.get("frontend_sampled_at"), native_received_at)
    if (not all(_finite(v) for v in times) or not gateway_received_at <= native_received_at
            or not frame["sampled_at"] <= frame["frontend_sampled_at"] <= native_received_at
            or frame["frontend_sampled_at"] - frame["sampled_at"] > FRONTEND_WIDTH_S
            or not 0 <= native_received_at - frame["sampled_at"] <= MAX_AGE_S):
        raise ValueError("native_frame_time")
    usage = frame.get("kv_cache_usage")
    if (any(type(frame.get(k)) is not int or frame[k] < 0
            for k in ("running", "waiting", "pending_batches"))
            or frame["running"] != len(frame.get("requests", ()))
            or not (_finite(usage) and 0 <= usage <= 1)):
        raise ValueError("native_counts")
    joined = {}
    for request in frame["requests"]:
        match = NATIVE_ID.fullmatch(request.get("request_id", ""))
        if not match or match[1] not in marks or match[1] in joined:
            raise ValueError("native_unjoined_or_ambiguous")
        out, mark = request.get("output_tokens"), marks[match[1]]
        if (type(out) is not int or not 0 <= out <= mark["max_tokens"]
                or type(request.get("prompt_tokens")) is not int or request["prompt_tokens"] < 0
                or request.get("maximum_output_tokens") != mark["max_tokens"]):
            raise ValueError("native_work")
        joined[match[1]] = out
    return joined


def _cap_plan(episode):
    plan = episode.get("cap_plan")
    if not plan:
        return None
    points = sorted((float(at), b) for at, b in plan)
    first = points[0][0]
    for at, budget in points:
        slots = (at - first) / SLOT_S
        if abs(slots - round(slots)) > 1e-6 or not (_finite(budget) and budget > 0):
            raise ValueError("cap_plan_off_slot_grid")
    return points


def plan_features(points, t0, horizon, fallback):
    """Lossless slot encoding of the frozen plan on (t0, t0+h]: time to the next slot
    boundary, the budget active at t0, then the budget after each of ceil(h) boundaries."""
    slots = plan_slots(horizon)
    if points is None:
        return (SLOT_S,) + (float(fallback),) * (slots + 1)

    def active(t):
        value = fallback
        for at, budget in points:
            if at <= t + EPS:
                value = budget
        return float(value)
    first = points[0][0]
    boundary = first + SLOT_S * (math.floor((t0 - first) / SLOT_S + EPS) + 1)
    return (boundary - t0, active(t0)) + tuple(active(boundary + k * SLOT_S)
                                               for k in range(slots))


def _budget_provenance(gateway, actions):
    """The snapshot budget must be the one applied by the ACK in force at sampled_at."""
    applied = sorted((a for a in actions if _finite(a.get("applied_at"))),
                     key=lambda a: a["applied_at"])
    current = [a for a in applied if a["applied_at"] <= gateway["sampled_at"] + EPS]
    if (not current or current[-1].get("budget_version") != gateway.get("budget_version")
            or current[-1]["budget"] != gateway["budget"]):
        raise ValueError("gateway_budget_provenance")


def _outstanding(actions, t0):
    """Online-knowable: commands planned before t0 whose applied ACK was not received."""
    return sum(1 for a in actions if a.get("planned_at") is not None
               and a["planned_at"] < t0 - EPS and not a["ack_received_at"] <= t0 + EPS)


def build_origins(episode):
    """Fixed-grid causal origins. Features use only observations received <= t0."""
    if episode.get("partition") not in PARTITIONS:
        raise ValueError("unknown_partition")
    if episode.get("seed_block") in FINAL_HELDOUT:
        raise ValueError("final_heldout_reserved")
    observations = sorted(episode["observations"],
                          key=lambda o: (o["gateway"]["sequence"], o["received_at"]))
    parsed = [(_marks(o["gateway"], episode), o) for o in observations]
    for (_, a), (_, b) in zip(parsed, parsed[1:]):
        if (a["gateway"]["sampled_at"] > b["gateway"]["sampled_at"]
                or a["received_at"] > b["received_at"]):
            raise ValueError("observation_order")
    joined_at, rejected = [], defaultdict(int)
    for index, (marks, obs) in enumerate(parsed):
        if obs.get("native") is None:
            continue
        if not obs["gateway"]["sampled_at"] <= obs["received_at"] <= obs["native_received_at"]:
            raise ValueError("observation_stale_or_noncausal")
        try:
            joined = _native(obs["native"], marks, episode, obs["received_at"],
                             obs["native_received_at"])
            if episode.get("actions") is not None:
                _budget_provenance(obs["gateway"], episode["actions"])
        except ValueError as error:
            # A frame failing the strict join is not an observation (online: fallback).
            rejected[str(error)] += 1
            continue
        joined_at.append((obs["native_received_at"], index, joined))
    actions = episode.get("actions")
    stats = dict(grid_points=0, stale_grid_points=0, no_observation_grid_points=0,
                 outstanding_action_grid_points=0,
                 joined_frames=len(joined_at), rejected_native_frames=dict(rejected),
                 joined_frame_marks=sum(len(parsed[i][0]) for _, i, _ in joined_at),
                 joined_frame_marks_not_native_visible=sum(
                     sum(r not in j for r in parsed[i][0]) for _, i, j in joined_at))
    if not joined_at:
        return [], parsed, stats
    plan = _cap_plan(episode)
    step = episode.get("origin_grid_s", ORIGIN_GRID_S)
    start = episode.get("origin_grid_start", min(j[0] for j in joined_at))
    last = max(j[0] for j in joined_at)
    origins = []
    for k in range(int(math.floor((last - start) / step + EPS)) + 1):
        t0 = start + k * step
        stats["grid_points"] += 1
        seen = [j for j in joined_at if j[0] <= t0 + EPS]
        if not seen:
            stats["no_observation_grid_points"] += 1
            continue
        _, index, joined = max(seen, key=lambda j: (j[0], j[1]))
        marks, obs = parsed[index]
        gateway = obs["gateway"]
        if t0 - gateway["sampled_at"] > MAX_AGE_S:
            stats["stale_grid_points"] += 1
            continue
        outstanding = 0
        if actions is not None:
            used = max(obs["received_at"], obs["native_received_at"])
            for a in actions:
                # Inputs must precede the ACK of any action planned at/after the cut.
                if (a.get("planned_at") is not None and a["planned_at"] >= t0 - EPS
                        and _finite(a.get("applied_at")) and not used < a["applied_at"]):
                    raise ValueError("cut_after_action_ack")
            outstanding = _outstanding(actions, t0)
            stats["outstanding_action_grid_points"] += outstanding > 0
        decode = sum(1 for out in joined.values() if out > 0)
        prefill_k = sum(marks[r]["prompt_tokens"] for r, out in joined.items() if out == 0)
        prefill_k += sum(m["prompt_tokens"] for r, m in marks.items() if r not in joined)
        # Trailing realized release from snapshot pairs received <= t0 only.
        released, span = 0.0, 0.0
        for (m_a, o_a), (m_b, o_b) in zip(parsed, parsed[1:]):
            if o_b["received_at"] > t0 + EPS:
                break
            if o_a["gateway"]["sampled_at"] >= gateway["sampled_at"] - HISTORY_S:
                released += sum(m["cost"] for r, m in m_a.items() if r not in m_b)
                span += o_b["gateway"]["sampled_at"] - o_a["gateway"]["sampled_at"]
        history = released / span if span >= MIN_HISTORY_SPAN_S else None
        cohort_cost = math.fsum(m["cost"] for m in marks.values())
        origins.append(dict(
            episode_id=episode["episode_id"], seed_block=episode["seed_block"],
            partition=episode["partition"], t0=t0, grid_index=k, index=index,
            sampled_at=gateway["sampled_at"], cohort=marks, joined=joined,
            reserved=cohort_cost, budget=gateway["budget"], decode_batch=decode,
            prefill_k=prefill_k / 1000, waiting=obs["native"]["waiting"],
            history_rate=history, outstanding_actions=outstanding,
            plan={h: plan_features(plan, t0, h, gateway["budget"]) for h in HORIZONS}))
    return origins, parsed, stats


def mark_features(origin, rid, horizon):
    mark = origin["cohort"][rid]
    out = origin["joined"].get(rid)
    unknown = out is None
    out = 0 if unknown else out
    return (mark["cost"], mark["prompt_tokens"] / 1000, mark["max_tokens"] / 100,
            float(mark.get("first_at") is not None), origin["sampled_at"] - mark["admitted_at"],
            float(unknown), out / mark["max_tokens"], (mark["max_tokens"] - out) / 100,
            float(origin["decode_batch"]), origin["prefill_k"], float(origin["waiting"]),
            origin["reserved"], origin["budget"],
            origin["history_rate"] if origin["history_rate"] is not None else 0.0,
            float(origin["history_rate"] is None)) + tuple(origin["plan"][horizon])


# ----------------------------------------------------------------------------
# Ground truth: contiguous ledger (exact/tied bounds) or snapshot brackets
# ----------------------------------------------------------------------------

def ledger_releases(episode, parsed):
    frames = sorted(episode["ledger"], key=lambda f: f["sequence"])
    first = parsed[0][1]["gateway"]
    sequence, reserved = first["sequence"], math.fsum(m["cost"] for m in parsed[0][0].values())
    at_sequence = {sequence: reserved}
    effective = {}
    releases, previous_at = [], -math.inf
    for frame in frames:
        if frame["sequence"] <= first["sequence"]:
            continue
        if (frame.get("event") != "mpc_ledger" or frame.get("run_id") != episode["run_id"]
                or frame.get("clock_domain") != episode["clock_domain"]
                or frame.get("complete") is not True or frame["sequence"] != sequence + 1
                or not _finite(frame.get("effective_at")) or not _finite(frame.get("reserved_cost"))):
            raise ValueError("ledger_identity_or_gap")
        if frame["effective_at"] < previous_at:
            raise ValueError("ledger_chronology")
        previous_at = frame["effective_at"]
        delta = frame["reserved_cost"] - reserved
        if delta < -EPS:
            releases.append((frame["sequence"], frame["effective_at"], -delta))
        sequence, reserved = frame["sequence"], frame["reserved_cost"]
        at_sequence[sequence] = reserved
        effective[sequence] = frame["effective_at"]
    for marks, obs in parsed:
        seq, sampled = obs["gateway"]["sequence"], obs["gateway"]["sampled_at"]
        value = at_sequence.get(seq)
        if value is None or not math.isclose(value, math.fsum(m["cost"] for m in marks.values()),
                                             abs_tol=1e-9):
            raise ValueError("snapshot_ledger_mismatch")
        # A snapshot at sequence s was read after event s and before event s+1.
        if effective.get(seq, -math.inf) > sampled + EPS or \
                effective.get(seq + 1, math.inf) < sampled - EPS:
            raise ValueError("ledger_snapshot_chronology")
    return releases, parsed[-1][1]["gateway"]["sampled_at"]


def release_groups(origin, parsed, releases):
    """Group cohort marks by (disappearance interval, cost) with candidate ledger events."""
    start = origin["index"]
    pending = set(origin["cohort"])
    groups, unresolved = defaultdict(list), []
    for (_, a), (m_b, b) in zip(parsed[start:], parsed[start + 1:]):
        gone = [rid for rid in pending if rid not in m_b]
        for rid in gone:
            groups[(a["gateway"]["sequence"], b["gateway"]["sequence"],
                    origin["cohort"][rid]["cost"])].append(rid)
        pending -= set(gone)
    for rid in pending:
        unresolved.append(rid)
    out = []
    for (lo, hi, cost), members in groups.items():
        events = sorted(t for seq, t, c in releases
                        if lo < seq <= hi and math.isclose(c, cost, rel_tol=1e-9, abs_tol=1e-12))
        if len(events) < len(members):
            raise ValueError("ledger_release_identity")
        out.append(dict(cost=cost, members=members, events=events))
    return out, unresolved


def cumulative_truth(origin, groups, unresolved, coverage_end, horizon):
    target = origin["t0"] + horizon
    lo = hi = 0.0
    for g in groups:
        done = sum(t <= target for t in g["events"])
        extra = len(g["events"]) - len(g["members"])
        lo += g["cost"] * max(0, done - extra)
        hi += g["cost"] * min(done, len(g["members"]))
    if target > coverage_end:
        hi += sum(origin["cohort"][rid]["cost"] for rid in unresolved)
    return lo, hi


def mark_label(rid, groups, unresolved, coverage_end, target):
    for g in groups:
        if rid in g["members"]:
            if len(g["events"]) == 1 or target >= g["events"][-1]:
                return int(target >= g["events"][-1])
            return 0 if target < g["events"][0] else None
    return 0 if target <= coverage_end else None


def snapshot_brackets(origin, parsed):
    """Release of each cohort mark lies in (last live sampled_at, first absent sampled_at]."""
    last = {rid: origin["sampled_at"] for rid in origin["cohort"]}
    absent = {}
    horizon_end = origin["t0"] + max(HORIZONS)
    for marks, obs in parsed[origin["index"] + 1:]:
        sampled = obs["gateway"]["sampled_at"]
        for rid in origin["cohort"]:
            if rid in marks:
                if rid in absent:
                    raise ValueError("mark_reappeared")
                last[rid] = sampled
            elif rid not in absent:
                absent[rid] = sampled
        if sampled >= horizon_end and len(absent) == len(origin["cohort"]):
            break
        if sampled >= horizon_end and all(last[r] >= horizon_end for r in origin["cohort"]
                                          if r not in absent):
            break
    return {rid: (last[rid], absent.get(rid, math.inf)) for rid in origin["cohort"]}


def bracket_truth(origin, brackets, horizon):
    target = origin["t0"] + horizon
    lo = math.fsum(origin["cohort"][r]["cost"] for r, (_, a) in brackets.items() if a <= target)
    hi = math.fsum(origin["cohort"][r]["cost"] for r, (l, _) in brackets.items() if l < target)
    return lo, hi


def bracket_label(bracket, target):
    live, absent = bracket
    return 1 if absent <= target else 0 if target <= live else None


def build_dataset(episodes, stats=None):
    rows, seen = [], {}
    stats = {} if stats is None else stats
    for episode in episodes:
        block, part = episode.get("seed_block"), episode.get("partition")
        if seen.setdefault(block, part) != part:
            raise ValueError("seed_block_partition_leakage")
        origins, parsed, origin_stats = build_origins(episode)
        stats[episode["episode_id"]] = origin_stats
        if episode.get("ledger") is not None:
            releases, coverage_end = ledger_releases(episode, parsed)
        for origin in origins:
            if episode.get("ledger") is not None:
                groups, unresolved = release_groups(origin, parsed, releases)
                origin["truth_source"] = "ledger"
                origin["truth"] = {h: cumulative_truth(origin, groups, unresolved, coverage_end, h)
                                   for h in HORIZONS}
                origin["labels"] = {(rid, h): mark_label(rid, groups, unresolved, coverage_end,
                                                         origin["t0"] + h)
                                    for rid in origin["cohort"] for h in HORIZONS}
            else:
                brackets = snapshot_brackets(origin, parsed)
                origin["truth_source"] = "snapshot_bracket"
                origin["truth"] = {h: bracket_truth(origin, brackets, h) for h in HORIZONS}
                origin["labels"] = {(rid, h): bracket_label(brackets[rid], origin["t0"] + h)
                                    for rid in origin["cohort"] for h in HORIZONS}
            rows.append(origin)
    return rows


# ----------------------------------------------------------------------------
# Train-only fitting
# ----------------------------------------------------------------------------

def _solve(matrix, vector):
    n = len(vector)
    a = [row[:] + [vector[i]] for i, row in enumerate(matrix)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(a[r][col]))
        if abs(a[pivot][col]) < 1e-15:
            raise ValueError("singular_system")
        a[col], a[pivot] = a[pivot], a[col]
        for r in range(n):
            if r != col and a[r][col]:
                f = a[r][col] / a[col][col]
                a[r] = [x - f * y for x, y in zip(a[r], a[col])]
    return [a[i][n] / a[i][i] for i in range(n)]


def _sigmoid(z):
    return 1 / (1 + math.exp(-z)) if z >= 0 else math.exp(z) / (1 + math.exp(z))


def fit_logistic(xs, ys, weights, iterations=NEWTON_MAX):
    """L2 logistic (quasi-)likelihood, y in [0,1], unpenalized intercept, Newton.

    Returns convergence diagnostics; callers must not use an unconverged fit."""
    k = len(xs[0])
    mean = [statistics.fmean(x[j] for x in xs) for j in range(k)]
    scale = [statistics.pstdev([x[j] for x in xs]) or 1.0 for j in range(k)]
    zs = [[1.0] + [(x[j] - mean[j]) / scale[j] for j in range(k)] for x in xs]
    beta = [0.0] * (k + 1)
    total = math.fsum(weights)
    converged, used, step_size, grad_norm = False, 0, math.inf, math.inf
    for used in range(1, iterations + 1):
        grad = [0.0] * (k + 1)
        hess = [[0.0] * (k + 1) for _ in range(k + 1)]
        for z, y, w in zip(zs, ys, weights):
            p = _sigmoid(sum(b * v for b, v in zip(beta, z)))
            g, h = w * (y - p), w * p * (1 - p)
            for i in range(k + 1):
                grad[i] += g * z[i]
                for j in range(i, k + 1):
                    hess[i][j] += h * z[i] * z[j]
        for i in range(k + 1):
            for j in range(i):
                hess[i][j] = hess[j][i]
            if i:
                grad[i] -= L2 * total / len(ys) * beta[i]
                hess[i][i] += L2 * total / len(ys)
        hess[0][0] += 1e-9
        grad_norm = max(abs(g) for g in grad) / total
        step = _solve(hess, grad)
        beta = [b + s for b, s in zip(beta, step)]
        step_size = max(abs(s) for s in step)
        if step_size < NEWTON_TOL:
            converged = True
            break
    return dict(beta=beta, mean=mean, scale=scale, converged=converged, iterations=used,
                last_step=step_size, gradient_inf_per_weight=grad_norm,
                max_abs_beta=max(abs(b) for b in beta))


def _fit_or_constant(xs, ys, ws):
    """A horizon whose determinate labels have one class has no identifiable covariate
    effect; it is reported as a degenerate weighted constant, never as a fitted model."""
    if len({y for y in ys if y in (0, 1)}) < 2:
        value = math.fsum(w * y for y, w in zip(ys, ws)) / math.fsum(ws)
        return dict(constant=value, degenerate=True, converged=True, iterations=0,
                    last_step=0.0, gradient_inf_per_weight=0.0, max_abs_beta=0.0)
    return dict(fit_logistic(xs, ys, ws), degenerate=False)


def _logit_predict(model, x):
    if model.get("degenerate"):
        return model["constant"]
    z = [1.0] + [(v - m) / s for v, m, s in zip(x, model["mean"], model["scale"])]
    return _sigmoid(sum(b * v for b, v in zip(model["beta"], z)))


def origin_vector(origin):
    marks = origin["cohort"].values()
    unknown = math.fsum(m["cost"] for r, m in origin["cohort"].items() if r not in origin["joined"])
    progress = [origin["joined"][r] / m["max_tokens"] for r, m in origin["cohort"].items()
                if r in origin["joined"]]
    return (origin["reserved"], float(origin["decode_batch"]), origin["prefill_k"],
            float(origin["waiting"]), origin["budget"],
            origin["history_rate"] if origin["history_rate"] is not None else 0.0,
            float(origin["history_rate"] is None), float(len(origin["cohort"])),
            unknown / origin["reserved"] if origin["reserved"] else 0.0,
            statistics.fmean(progress) if progress else 0.0,
            float(sum(1 for m in marks if m.get("first_at") is None))) \
        + tuple(origin["plan"][max(HORIZONS)])


def _nn(vector, others, scale):
    return min((math.sqrt(sum(((a - b) / s) ** 2 for a, b, s in zip(vector, o, scale)))
                for o in others), default=math.inf)


def support_envelope(train):
    """Data-defined support: every used feature's range, observed joint work mixes and
    plan sequences, and a leave-one-episode-out nearest-neighbour radius. It is an
    abstention envelope, not a certificate of exchangeability or coverage."""
    env = dict(ranges={}, work_mixes=sorted({tuple(sorted({(m["prompt_tokens"], m["max_tokens"])
                                                            for m in o["cohort"].values()}))
                                             for o in train}),
               plan_patterns={h: sorted({tuple(o["plan"][h][1:]) for o in train})
                              for h in HORIZONS})
    for h in HORIZONS:
        rows = [mark_features(o, rid, h) for o in train for rid in o["cohort"]]
        env["ranges"][h] = [(min(c), max(c)) for c in zip(*rows)] if rows else None
    vectors = [(o["episode_id"], origin_vector(o)) for o in train]
    scale = [statistics.pstdev([v[j] for _, v in vectors]) or 1.0
             for j in range(len(vectors[0][1]))]
    radius = None
    if len({e for e, _ in vectors}) >= 2:
        radius = max(_nn(v, [w for f, w in vectors if f != e], scale) for e, v in vectors)
    env["nn"] = dict(vectors=[v for _, v in vectors], scale=scale, radius=radius,
                     rule="max leave-one-episode-out NN distance over Train origins")
    return env


def ood_reasons(origin, env):
    reasons = set()
    for h in HORIZONS:
        names, ranges = feature_names(h), env["ranges"][h]
        for rid in origin["cohort"]:
            for name, value, (lo, hi) in zip(names, mark_features(origin, rid, h), ranges):
                if not lo - EPS <= value <= hi + EPS:
                    reasons.add("range_" + name)
        if tuple(origin["plan"][h][1:]) not in {tuple(p) for p in env["plan_patterns"][h]}:
            reasons.add("joint_plan_sequence")
    mix = tuple(sorted({(m["prompt_tokens"], m["max_tokens"]) for m in origin["cohort"].values()}))
    if mix not in {tuple(tuple(s) for s in w) for w in env["work_mixes"]}:
        reasons.add("joint_work_mix")
    nn = env["nn"]
    if nn["radius"] is None:
        reasons.add("joint_nn_unavailable")
    elif _nn(origin_vector(origin), nn["vectors"], nn["scale"]) > nn["radius"] + EPS:
        reasons.add("joint_nn_distance")
    return sorted(reasons)


def _labelled(train, h, ambiguous_as):
    xs, ys, ws, ambiguous = [], [], [], 0
    for o in train:
        for rid in o["cohort"]:
            y = o["labels"][(rid, h)]
            if y is None:
                ambiguous += 1
                y = ambiguous_as
            xs.append(mark_features(o, rid, h))
            ys.append(y)
            ws.append(1 / len(o["cohort"]))
    return xs, ys, ws, ambiguous


def fit(train, sensitivity=False):
    """Every parameter uses Train origins only; calibration/development are refused.
    No origin or mark is dropped for interval truth: baselines use mean truth bounds and
    the logistic uses the midpoint 0.5 for interval-censored mark labels (a convention,
    not an MLE). With sensitivity=True the 0/1 imputation bounds are also fitted."""
    if not train or any(o["partition"] != "train" for o in train):
        raise ValueError("fit_requires_train_only")
    positive = [o for o in train if o["reserved"] > 0]
    if not positive:
        raise ValueError("no_train_origins")
    fraction, fraction_bounds, lo_sum, hi_sum, h_sum = {}, {}, 0.0, 0.0, 0.0
    for h in HORIZONS:
        lo = statistics.fmean(o["truth"][h][0] / o["reserved"] for o in positive)
        hi = statistics.fmean(o["truth"][h][1] / o["reserved"] for o in positive)
        fraction_bounds[h], fraction[h] = (lo, hi), (lo + hi) / 2
        lo_sum += math.fsum(o["truth"][h][0] for o in positive)
        hi_sum += math.fsum(o["truth"][h][1] for o in positive)
        h_sum += h * len(positive)
    logits, label_counts, bounds = {}, {}, {}
    for h in HORIZONS:
        xs, ys, ws, ambiguous = _labelled(train, h, 0.5)
        logits[h] = _fit_or_constant(xs, ys, ws)
        label_counts[h] = dict(marks=len(ys), interval_censored_midpoint=ambiguous,
                               released=sum(y == 1 for y in ys), unreleased=sum(y == 0 for y in ys))
        if sensitivity:
            bounds[h] = tuple(_fit_or_constant(*_labelled(train, h, a)[:3]) for a in (0.0, 1.0))
    if all(m["degenerate"] for m in logits.values()):
        raise ValueError("degenerate_train_labels")
    return dict(fraction=fraction, fraction_bounds=fraction_bounds,
                fluid_rate=(lo_sum + hi_sum) / 2 / h_sum,
                fluid_rate_bounds=(lo_sum / h_sum, hi_sum / h_sum), logistic=logits,
                label_bounds=bounds, support=support_envelope(train), label_counts=label_counts,
                fit_weighting="origin-equal mark weights; not block-balanced",
                train_blocks=sorted({o["seed_block"] for o in train}))


def _batch_aware(models, origin):
    out, previous = {}, {rid: 0.0 for rid in origin["cohort"]}
    for h in HORIZONS:
        total = 0.0
        for rid, mark in origin["cohort"].items():
            p = max(previous[rid], _logit_predict(models[h], mark_features(origin, rid, h)))
            previous[rid] = p
            total += mark["cost"] * p
        out[h] = total
    return out


def predict(params, origin):
    """None when outside the Train support envelope or when any fit did not converge."""
    reasons = ood_reasons(origin, params["support"])
    if origin.get("outstanding_actions"):
        reasons.append("outstanding_action_at_cut")
    if any(not params["logistic"][h]["converged"] for h in HORIZONS):
        reasons.append("fit_not_converged")
    if reasons:
        return None, reasons
    r = origin["reserved"]
    rate = origin["history_rate"] if origin["history_rate"] is not None else params["fluid_rate"]
    out = dict(train_fraction={h: r * params["fraction"][h] for h in HORIZONS},
               fluid_history={h: min(r, rate * h) for h in HORIZONS},
               batch_aware=_batch_aware(params["logistic"], origin))
    return out, []


# ----------------------------------------------------------------------------
# Block-level evaluation, calibration and OOD accounting
# ----------------------------------------------------------------------------

def _unique(rows):
    """One row per (block, episode, origin time): duplicated origins carry no new block."""
    out = {}
    for o in rows:
        out.setdefault((o.get("seed_block"), o.get("episode_id"), o.get("t0")), o)
    return list(out.values())


def _interval_error(pred, lo, hi):
    best = 0.0 if lo <= pred <= hi else min(abs(pred - lo), abs(pred - hi))
    return best, max(abs(pred - lo), abs(pred - hi))


def score(params, rows):
    """Equal-weight mean over h of |pred-actual|/R_origin, grid origin -> episode -> block."""
    per_block = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    counts = defaultdict(int)
    for o in _unique(rows):
        if o["reserved"] <= 0:
            counts["zero_reserved_origins"] += 1
            continue
        pred, reasons = predict(params, o)
        if pred is None:
            counts["ood_abstained"] += 1
            for reason in reasons:
                counts["ood_" + reason] += 1
            continue
        counts["scored_origins"] += 1
        for model, values in pred.items():
            errs = [_interval_error(values[h], *o["truth"][h]) for h in HORIZONS]
            per_block[model][o["seed_block"]][o["episode_id"]].append(
                (statistics.fmean(e[0] for e in errs) / o["reserved"],
                 statistics.fmean(e[1] for e in errs) / o["reserved"]))
    result = {}
    for model, blocks in per_block.items():
        block_scores = {}
        for block, episodes in blocks.items():
            means = [(statistics.fmean(v[0] for v in e), statistics.fmean(v[1] for v in e))
                     for e in episodes.values()]
            block_scores[block] = dict(lower=statistics.fmean(m[0] for m in means),
                                       upper=statistics.fmean(m[1] for m in means))
        result[model] = dict(blocks=block_scores,
                             lower=statistics.fmean(b["lower"] for b in block_scores.values()),
                             upper=statistics.fmean(b["upper"] for b in block_scores.values()))
    return dict(models=result, counts=dict(counts))


def _quantile(values, q):
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, math.ceil(q * (len(ordered) + 1)) - 1))
    return ordered[index]


def calibrate(params, rows, model="batch_aware"):
    """Block-level descriptive band from Calibration blocks only.

    Each block contributes its own within-block residual quantiles on the fixed origin
    grid, using interval truth bounds (no exact-only selection); the band is the envelope
    across blocks. Duplicated origins and the number of origins in a block cannot move
    another block's contribution. No coverage guarantee is claimed."""
    if any(o["partition"] != "calibration" for o in rows):
        raise ValueError("calibration_requires_calibration_only")
    per_block = defaultdict(lambda: defaultdict(lambda: ([], [])))
    for o in _unique(rows):
        pred, _ = predict(params, o) if o["reserved"] > 0 else (None, None)
        if pred is None:
            continue
        for h in HORIZONS:
            lo, hi = o["truth"][h]
            cell = per_block[o["seed_block"]][h]
            cell[0].append((lo - pred[model][h]) / o["reserved"])
            cell[1].append((hi - pred[model][h]) / o["reserved"])
    if not per_block:
        raise ValueError("no_calibration_residuals")
    bands = {}
    for h in HORIZONS:
        blocks = {b: (_quantile(c[h][0], ALPHA / 2), _quantile(c[h][1], 1 - ALPHA / 2))
                  for b, c in per_block.items() if c[h][0]}
        bands[h] = dict(lower=min(v[0] for v in blocks.values()),
                        upper=max(v[1] for v in blocks.values()), blocks=len(blocks))
    return dict(model=model, alpha=ALPHA, bands=bands, blocks=sorted(per_block),
                statistical_guarantee=False)


def coverage(params, calibration, rows):
    per_block = defaultdict(lambda: [0, 0, 0])
    for o in _unique(rows):
        if o["reserved"] <= 0:
            continue
        pred, _ = predict(params, o)
        if pred is None:
            continue
        for h in HORIZONS:
            band = calibration["bands"][h]
            lo = pred[calibration["model"]][h] + band["lower"] * o["reserved"]
            hi = pred[calibration["model"]][h] + band["upper"] * o["reserved"]
            t_lo, t_hi = o["truth"][h]
            cell = per_block[o["seed_block"]]
            cell[2] += 1
            cell[0] += lo - EPS <= t_lo and t_hi <= hi + EPS     # covered for every feasible truth
            cell[1] += t_hi >= lo - EPS and t_lo <= hi + EPS      # covered for some feasible truth
    return {block: dict(lower=c[0] / c[2], upper=c[1] / c[2], n=c[2]) for block, c in per_block.items()}


def evaluate(episodes):
    stats = {}
    rows = build_dataset(episodes, stats)
    split = {p: [o for o in rows if o["partition"] == p] for p in PARTITIONS}
    params = fit(split["train"])
    result = dict(schema="nv3-opus-release-model-v3", horizons=list(HORIZONS),
                  train_blocks=params["train_blocks"], fluid_rate_cost_per_s=params["fluid_rate"],
                  label_counts={str(h): v for h, v in params["label_counts"].items()},
                  convergence={str(h): {k: v for k, v in m.items()
                                        if k not in ("beta", "mean", "scale")}
                               for h, m in params["logistic"].items()},
                  origin_grid=stats,
                  scores={p: score(params, split[p]) for p in PARTITIONS if split[p]},
                  native_performance_accepted=False, statistical_guarantee=False,
                  mpc_accepted=False, joint_response_kernel=False)
    if split["calibration"]:
        cal = calibrate(params, split["calibration"])
        result["calibration"] = dict(cal, bands={str(h): v for h, v in cal["bands"].items()})
        if split["development"]:
            result["development_coverage"] = coverage(params, cal, split["development"])
    return result


# ----------------------------------------------------------------------------
# Useful / physical / tail forward-work accounting (does not relax the v2 audit)
# ----------------------------------------------------------------------------

def forward_work_accounting(request, steps, worker_rows, *, request_id, max_tail_tokens=1):
    """Partition one natural-EOS request's executed positions.

    useful = prompt + delivered_output - 1 (the last sampled token is never fed back);
    physical = contiguous executed positions; tail = physical - useful. The legacy strict
    audit (physical == useful) is reported unchanged. A tail is only *accounted* when it is
    a single contiguous decode position scheduled before the engine finish, whose matched
    output commit (step end) is at/after that finish, and matched to an executed worker
    forward. That is structural parity only: tail_mechanism_evidenced additionally needs
    request["tail_evidence"] with placeholder_tokens == 1, cuda_completed, an explicit
    delivered_output_from_step False and output_commit_at >= finished. Neither flag is
    native qualification authority. GPU spans are not absolute clocks or exclusive service.
    """
    prompt, output = request["input_tokens"], request["output_tokens"]
    finished = request.get("finished")
    problems = []
    if request.get("finish_reason") != "stop" or type(output) is not int or output <= 0:
        problems.append("not_natural_eos_output")
    workers = {}
    for row in worker_rows:
        if row["step_id"] in workers:
            problems.append("duplicate_worker_step")
        workers[row["step_id"]] = row
    progress, useful_steps, tail_steps = 0, 0, []
    useful = prompt + output - 1
    for step in sorted(steps, key=lambda s: s["start"]):
        mine = [w for w in step["work"] if w["request_id"] == request_id]
        if not mine:
            continue
        if len(mine) != 1 or mine[0]["position"] != progress or mine[0]["tokens"] <= 0:
            problems.append("position_gap_repeat_or_split")
            continue
        work = mine[0]
        worker = workers.get(step["step_id"])
        if (worker is None or (worker.get("executed_positions") or {}).get(request_id) != work["position"]
                or (worker.get("executed_counts") or {}).get(request_id) != work["tokens"]):
            problems.append("unmatched_worker_forward")
        if work["position"] + work["tokens"] <= useful:
            useful_steps += 1
        elif work["position"] >= useful:
            tail_steps.append((step, work, worker))
        else:
            problems.append("step_straddles_useful_boundary")
        progress = work["position"] + work["tokens"]
    tail = progress - useful
    if tail < 0:
        problems.append("missing_useful_work")
    if tail > max_tail_tokens:
        problems.append("unexplained_tail_work")
    tail_ok = True
    for step, work, worker in tail_steps:
        if not _finite(finished):
            problems.append("finish_time_unavailable")
            tail_ok = False
        elif not step["start"] < finished:
            problems.append("tail_scheduled_after_finish")
            tail_ok = False
        elif not (_finite(step.get("end")) and step["end"] >= finished):
            problems.append("tail_commit_before_finish")
            tail_ok = False
        if work["tokens"] != 1 or worker is None:
            tail_ok = False
    accounted = not problems and 0 <= tail <= max_tail_tokens and tail_ok
    evidence = request.get("tail_evidence") or {}
    mechanism = (accounted and tail == 1 and evidence.get("placeholder_tokens") == 1
                 and evidence.get("cuda_completed") is True
                 and evidence.get("delivered_output_from_step") is False
                 and _finite(evidence.get("output_commit_at")) and _finite(finished)
                 and evidence["output_commit_at"] >= finished)
    return dict(useful_positions=useful, physical_positions=progress, tail_positions=tail,
                useful_steps=useful_steps, tail_steps=len(tail_steps),
                legacy_strict_audit_valid=progress == useful and not problems,
                tail_accounted=accounted, tail_mechanism_evidenced=mechanism,
                native_qualification_authority=False,
                problems=sorted(set(problems)),
                scope="Executed positions per request; GPU forward spans are per-step labels, "
                      "not absolute clocks or exclusive service durations.")


# ----------------------------------------------------------------------------
# Portable adapter for actual native-v3 identification artifacts (read-only)
# ----------------------------------------------------------------------------

REPLICA_SPLITS = {"train": "train"}        # R3: Train only; other splits are not loaded
TRAIN_BLOCKS = frozenset(range(181001, 181017))
NATIVE_EXTRA = ("gateway_snapshot", "gateway_received_at", "received_at", "available")


def episode_from_replica(document, index):
    """Map one native-v3 episode artifact to this module's episode schema.

    Gateway identity/clock come from the index receipt; the native run/observer are taken
    from the episode's frames and must be uniform (internal consistency, not an
    independent receipt). The ledger is not captured, so truth uses snapshot brackets."""
    if document.get("split") not in REPLICA_SPLITS:
        raise ValueError("replica_split_not_allowed")
    if document["seed_block"] in FINAL_HELDOUT or document["seed_block"] not in TRAIN_BLOCKS:
        raise ValueError("replica_seed_block_not_train")
    frames = [f for f in document["native_frames"] if f.get("available") is True]
    sources = {(f.get("run_id"), f.get("observer_sha256")) for f in frames}
    if len(sources) != 1:
        raise ValueError("native_source_not_uniform")
    (native_run, observer), = sources
    return dict(
        episode_id=document["episode_id"], seed_block=document["seed_block"],
        partition=REPLICA_SPLITS[document["split"]], clock_domain=index["clock_domain"],
        run_id=document["gateway_run_id"], native_run_id=native_run, observer_sha256=observer,
        identity=index["model_identity"], ledger=None, origin_grid_start=document["start"],
        cap_plan=[(document["start"] + s["at_s"], s["budget"]) for s in document["schedule"]],
        actions=_replica_actions(document),
        observations=[dict(gateway=f["gateway_snapshot"], received_at=f["gateway_received_at"],
                           native={k: v for k, v in f.items() if k not in NATIVE_EXTRA},
                           native_received_at=f["received_at"]) for f in frames],
        unavailable_frames=len(document["native_frames"]) - len(frames))


def _replica_actions(document):
    """Actual CAS receipts: pre-assignment plus every planned action's final attempt."""
    out = []
    for planned, attempts in ([(None, document["preassignment"])]
                              + [(document["start"] + a["at_s"], a["attempts"])
                                 for a in document["actions"]]):
        last = attempts[-1]
        ack = last["reply"].get("acknowledgment") or {}
        applied = last["reply"].get("status") == "applied"
        out.append(dict(planned_at=planned, budget=ack.get("budget"),
                        budget_version=ack.get("budget_version"),
                        applied_at=ack.get("applied_at") if applied else None,
                        ack_received_at=last["received_at"] if applied else math.inf,
                        attempts=len(attempts)))
    return out


def load_replica(directory):
    """Verify every listed artifact's sha256 before use; load allowed-split episodes."""
    root = Path(directory)
    index = json.loads((root / "latest-index.json").read_text())
    listed = [json.loads(line) for line in (root / "verified-artifact-sha256.jsonl").read_text()
              .splitlines() if line.strip()]
    for row in listed:
        if hashlib.sha256((root / row["artifact"]).read_bytes()).hexdigest() != row["sha256"]:
            raise ValueError("replica_artifact_hash:" + row["artifact"])
    names = sorted(r["artifact"] for r in listed
                   if r["artifact"].endswith(".json") and r["artifact"].startswith("nv3-"))
    episodes, skipped = [], []
    for name in names:
        document = json.loads((root / name).read_text())
        if document.get("split") not in REPLICA_SPLITS:
            skipped.append(name)
            continue
        episodes.append(episode_from_replica(document, index))
    receipt = dict(collector_source_commit=index.get("source_commit"),
                   native_source_commit=index["gpu_environment"]["native_launch"]["source_commit"],
                   clock_domain=index["clock_domain"], verified_artifacts=len(listed),
                   loaded=[e["episode_id"] for e in episodes], skipped_splits=skipped,
                   gateway_runs={e["episode_id"]: e["run_id"] for e in episodes},
                   native_runs=sorted({e["native_run_id"] for e in episodes}),
                   artifact_sha256={r["artifact"]: r["sha256"] for r in listed
                                    if r["artifact"] in names})
    return episodes, receipt


def train_diagnostics(episodes, receipt=None):
    """Train-only descriptive diagnostics; not forecast, calibration or causal results."""
    if any(e["partition"] != "train" for e in episodes):
        raise ValueError("diagnostics_train_only")
    stats = {}
    rows = build_dataset(episodes, stats)
    marks = [(o, rid) for o in rows for rid in o["cohort"]]
    out = dict(schema="nv3-opus-train-diagnostics-v1", receipt=receipt, origin_grid=stats,
               origins=len(rows), origin_marks=len(marks),
               origin_marks_not_native_visible=sum(r not in o["joined"] for o, r in marks),
               forecast_result=False, causal_result=False, mpc_result=False)
    delays = sorted(a["applied_at"] - a["planned_at"] for e in episodes
                    for a in e.get("actions") or () if a["planned_at"] is not None
                    and _finite(a["applied_at"]))
    out["cas_apply_delay_s"] = dict(
        n=len(delays), p50=_quantile(delays, 0.5), p95=_quantile(delays, 0.95),
        max=delays[-1], not_applied=sum(1 for e in episodes for a in e.get("actions") or ()
                                        if not _finite(a["applied_at"])),
        retried=sum(1 for e in episodes for a in e.get("actions") or () if a["attempts"] > 1),
        scope="applied_at - planned slot time; an outcome after the cut, never an input") \
        if delays else None
    out["truth"] = {}
    for h in HORIZONS:
        width = [o["truth"][h][1] - o["truth"][h][0] for o in rows if o["reserved"] > 0]
        share = [w / o["reserved"] for w, o in zip(width, [o for o in rows if o["reserved"] > 0])]
        ambiguous = sum(o["labels"][(rid, h)] is None for o, rid in marks)
        out["truth"][str(h)] = dict(
            exact_origins=sum(w <= EPS for w in width), interval_origins=sum(w > EPS for w in width),
            mean_width_share=statistics.fmean(share) if share else None,
            interval_censored_mark_labels=ambiguous)
    params = fit(rows, sensitivity=True)
    out["fit"] = {}
    for h in HORIZONS:
        low, high = params["label_bounds"][h]
        gaps = [abs(_logit_predict(high, mark_features(o, rid, h))
                    - _logit_predict(low, mark_features(o, rid, h))) for o, rid in marks]
        out["fit"][str(h)] = dict(
            label_counts=params["label_counts"][h],
            convergence={name: {k: v for k, v in model.items()
                                if k not in ("beta", "mean", "scale")}
                         for name, model in (("midpoint", params["logistic"][h]),
                                             ("ambiguous_as_0", low), ("ambiguous_as_1", high))},
            in_sample_label_sensitivity_mean_abs_probability=statistics.fmean(gaps),
            in_sample_label_sensitivity_max_abs_probability=max(gaps))
    out["fit_scope"] = "Train in-sample diagnostics only; no prediction error is reported"
    return out


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) == 2 and argv[0] == "--replica-train-diagnostics":
        episodes, receipt = load_replica(argv[1])
        print(json.dumps(train_diagnostics(episodes, receipt), indent=2, sort_keys=True))
        return
    if len(argv) != 1:
        raise SystemExit("usage: native_release_model.py EPISODES.json | "
                         "--replica-train-diagnostics DIR")
    with open(argv[0], encoding="utf-8") as handle:
        episodes = json.load(handle)
    print(json.dumps(evaluate(episodes), indent=2, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
