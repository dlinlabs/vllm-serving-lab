# Astra NV3 round 1: a response-model interface, not another simulated plant

Status: independent local proposal and bounded shadow planner. No native run,
fitted response model, calibration acceptance, active permit, or performance
claim. Only the three owned files in this directory are changed. No fresh
NV3 peer proposal was read. Bead `pr-nv3-astra` remains for Mayor-managed
in-progress peer review; this report is the offline handoff receipt.

## 1. Evidence and decisions retained

Read `campaign.zh-TW.md` from base `10f2fb0`, the native-v2 decision and next
protocol, my v2 round3 revision, the actual native identification/falsification
report, and the persisted Train diagnostic JSONs:

- `results/mpc-native-4090-scout/native-prefill-combined.json` explicitly rejects
  the exclusive serial HTTP interpretation: 2449/2056 natural completions in
  90s exceed its 2004 bound. This does not reject all queueing/fluid models.
- `native-prediction-combined.json` records retrospective Gateway availability
  as unverified, `model_accepted=false`, and no calibration or online forecasts.
- `native-token-diagnostic.json` is a decode-survivor progress diagnostic, not
  an identified batch service law. Realized next-snapshot gaps are not known
  future horizons. The report's candidate MAE 1.043 versus persistence 1.029
  is not evidence that a complex predictor already beats the strongest baseline.
- Native-v2's common 5s evaluation, exact whole-cost releases, pending work
  caveat, support-limited outcome model and strong continuation remain useful.
  The old claims that physical memory is sufficient/necessary for MPC gain,
  that a non-significant result proves impossibility, or that scalar cost is
  KV safety remain rejected. The supplied old Gemini report does not override
  these later evidence-based decisions.

The Mayor-supplied new fact is a strict HTTP UUID-joined 4096-prompt/32-output
natural-EOS completion, but its old work audit is still FALSE: contiguous
worker positions end at 4128 versus useful delivered-token minimum 4127.
There are 34 executed steps (2 prefill, 32 decode). The final extra token had
a scheduler placeholder of 1, step start before EOS, output commit after EOS,
and matching executed CUDA forward. This is supplied ground truth, not a local
rerun or an audited raw capture I downloaded. Do not write "Gate A passed."

The supplied current environment is one authorized RTX4090/24564MiB,
driver595.91.07, vLLM0.30.0/Torch2.13.0/Transformers5.22.1 and restored pinned
Qwen4B. Prior deployment coefficients do not qualify this deployment. No use of
held-out 160021-160024, GPU, SSH, API, credentials, or paid resources occurred.

## 2. Useful work, physical work, and two different tails

Keep the old audit and its failed result byte-for-byte unchanged. Propose a
separately versioned accounting contract, qualified against raw data before use:

1. **Delivered/useful ledger:** client output token IDs/count, EOS/finish reason,
   native output-commit lineage, and prompt input positions. In this cache-off,
   non-speculative case, producing `m` delivered tokens requires minimum
   input work `p + m - 1`; the first output comes from prompt forward. This is
   a lower-bound dependency count, not the complete executed-work identity.
2. **Physical ledger:** every actual worker forward's exact request ID, step ID,
   executed position interval, token count, and qualified stream-scoped CUDA
   elapsed interval. Include the extra position even when no delivered output
   results. Preserve schedule/execute disagreement, duplicates, gaps, discarded
   sampling, cancellation and pending work explicitly; do not erase them as EOS.
3. **Attribution ledger:** join each physical interval to useful dependencies,
   explained async lookahead/discarded work, or **unexplained** work. In the
   supplied example physical 4128 minus useful minimum 4127 is 1. Calling that
   one position an explained EOS-adjacent lookahead requires the supplied
   launch/placeholder/commit/forward lineage. It is not a universal `+1`
   tolerance. An unexplained difference must still fail label qualification.

Engine host order and worker event duration are distinct facts. A host step
started before the EOS callback is not proof of GPU execution before EOS.
GPU elapsed is neither an absolute host/GPU timestamp nor exclusive service
demand. Do not subtract it from HTTP residence or sum request allocations as a
server-capacity proof. Kernel overlap and mixed batches require batch-scoped
labels; decode-progress coefficients are not prefill service coefficients.

Physical tail work after useful output may delay other requests even after
the corresponding reservation releases. Keep a pending-physical-work summary
or abstain; never infer GPU drain from `R=0` or client EOS alone.
Separately, **evaluation tail** means unresolved offered outcomes after the 5s
cohort window and bounded drain. It is not the extra CUDA work. Retain both.

Falsification cases for the new contract, to be run by the measurement owner:
remove/duplicate the last worker interval; change its position or count; retain
a placeholder without executed forward; inject an extra interval without a
launch/commit explanation; lose EOS/output-commit evidence; add more than one
ahead step; cancel while work is pending; replay cap-drop/cleanup before GPU
drain; and repeat across short/long prompt and mixed batch composition.
Each must either have complete causal lineage or remain invalid/unknown.
Reject cross-clock comparisons and unresolved CUDA events. Repeat OFF/LIGHT
and literal-disabled measurements to distinguish observer effects. This module
does not implement or weaken any capture audit.

## 3. Observable state and identifiable transition

The full online prefix `H(t)` contains only receipts actually delivered by the
decision origin, not backdated scheduler events or end-of-drain CUDA labels:

| Component | Required record / uncertainty |
|---|---|
| Identity and clocks | Deployment/source/config/model revision, cost estimator, service epoch, boot/clock provenance; source event and consumer receipt times separately |
| Exact reservation ledger | UUID, original charged cost, admission/release version and time; cap applied/version/expiry and any pending command |
| All-offered cohort | Old unresolved offers including not-yet-admitted transport work, plus future offers in `[t,t+5)`; rejects/errors never disappear from denominator |
| Request marks | Prompt/max-output, received output progress, first-content status, age, waiting/prefill/decode/release-pending/unknown state |
| Batch prefix | Native running/waiting counts, pending batches, prompt chunk/progress and context bins if actually available, KV occupancy, missing/unknown IDs, sampling width and receipt age |
| Environment/history | Recent arrival/mix and release histories, cap history, pending physical tail, observer mode, preemption/recovery flags; unknown remaining EOS and future batch membership |

This is not a sufficient observed Markov GPU state. History and latent physical
work remain important. The implemented `State` has a bounded marked live ledger,
batch counts/KV, identity/version and timestamps, plus `history_id` for a frozen
received-prefix artifact. It is an interface, not a production state adapter.
The eventual adapter must bind the richer prefix above to that ID, and mark
unknown native request work as `stage="unknown"` (which is rejected). An
accepted-but-not-yet-visible native request cannot be quietly labelled known.
An old offer that has not been admitted instead stays in `origin_offered_ids`
without fabricated reservation cost. `release_pending` means output is known
but original cost is still held; it is not an implicit release.

Exact accounting, not an estimated fluid release:

```
R_next = R + sum(actual admitted original costs) - sum(actual released original costs)
admit iff R + original_cost <= actually_applied_cap
R <= max(initial R, maximum historically applied cap)
```

`transition_costs` replays ordered admit/release events, checks exact original
cost and ID, refuses double release/reuse, and checks projected cost **before**
admitting. Within the supported 16/32 family, initial R cannot exceed32.
Lowering cap to16 with R=24 is allowed; it does not evict, fractional-release,
or recost requests. Applying a cap without an event changes no reservation.
16/32 are cost caps, not request counts, KV bytes or scheduler token budgets.

Unknown response:

```
P_theta(origin-cost releases at 1/3/5s, complete-good and unresolved cohort counts
        | H(t), assigned cap prefix + frozen continuation, future arrival law,
          deployment/source/observer support)
```

Start with support-limited whole-policy response estimation, stratifying coarse
origin reserved cost and prompt mix only if randomized data support it. Compare
action-only, persistence/hold, and regularized coarse models on blocked data.
Do not concatenate independent response-table cells into fictitious rolling
transitions. No serial HTTP law, extrapolated knee, fitted GPU coefficient or
stochastic EOS generator is embedded in the code.

## 4. Implemented bounded planner contract

`native_response_planner.py` injects a `ResponseModel.predict` implementation.
There is deliberately no built-in performance model, artifact loader, data
collector, actuator, or permit generator. `None` means unsupported. Missing any
candidate aborts the comparison; failed/unsupported plans are not scored zero.

All six calls receive the **same immutable Evaluation object**: 5s half-open
offered window, 1s slots, identical origin cohort, future law and weighted joint
scenario IDs, model/support/uncertainty IDs, continuation receipt and tail rule.
Response must echo state/plan/evaluation identity and every scenario in order.
The caller supplies a forecast distribution frozen at the origin, not the
experiment's realized future tape. Scenario future-offer counts are draws under
that distribution, not observed future admissions. IDs alone cannot prove this;
the external data/model qualification must.

Two candidates optimize One-move's first cap, then invoke the development-chosen
continuation from t+1 onward. Four candidates enumerate all cap pairs, then use
the **same continuation policy** from t+2 onward. The continuation policy gets
only that rollout's available prefix; it may be hold, best-supported-fixed or
a pre-frozen strong reactive rule selected on Development. It is not silently
Fixed16, nor chosen separately per policy after seeing outcomes. A reactive
continuation is represented by its policy ID, not replaced with the realized
cap path from another arm. Its support must be explicit in the injected model.
Ordinary LL/LH/HL/HH data with fixed continuation do not support this interface's
strong reactive baseline automatically.

For each joint scenario, the model supplies settled-good `G`, unresolved `U`,
expected additional tail-good `E` in `[0,U]`, and nested sets of released
**origin request IDs** at 1/3/5s. No duplicate/unknown ID or reversal is allowed.
The scorer sums original costs, so releases in each draw are whole-cost;
only the average across draws may be fractional, always in `[0,R_origin]`.
The remaining offered mass is settled
bad/rejected/error/cancelled. Good requires positive output and natural complete,
TTFT from scheduled offer <=0.5s, request-mean TPOT using **terminal**, not last
content, <=0.05s; one token TPOT=0. Upstream outcome extraction must enforce
these predicates; aggregate predictions here cannot re-audit raw responses.

Rank by weighted expected `G+E`, never by settled `G` alone. Separately report
tail interval `[sum pG, sum p(G+U)]`; expand it by declared joint model-error
allowances and clip to the all-offered count. These allowances are in good-count
units, must include selection over this candidate family, and must come from
independent Calibration. They are **not** per-request independent draws.
The interval is a conservative reporting/abstention envelope, not an internally
proved confidence/chance constraint. Calibration is not implied by a nonempty ID.

Tie-breaking prefers currently applied cap, then lexicographic cap order.
A selected first action is resolved only if its lower envelope exceeds every
candidate upper envelope with the other first action. Equal/overlapping bands
yield no recommendation. Keep strong One-move if first actions coincide; when
they differ, prefer two moves only with resolved first-action ranking and a
positive conservative two-minus-one interval. Otherwise retain One-move if
resolved, or abstain. A larger open-loop score is not a closed-loop gain claim;
reactive continuation means the two candidate families are not necessarily
nested. This is intentionally conservative and may abstain despite a useful
paired estimator; adding a calibrated paired contrast is future work, not an
excuse to assert independence.

Work is bounded to six model calls, <=128 shared scenarios, <=256 live/origin
IDs and a three-offset release trajectory; the standalone ledger helper bounds
each replay at1024 events. These are engineering limits, not native capacities.
No scenario sampling/search expansion occurs inside the planner.

## 5. Clock, cost, deadline and fallback boundary

State must match expected deployment/epoch/cost identity, use the consumer's
qualified clock domain, satisfy `sample <= receipt <= origin <= now`, and pass
finite-number, age/skew, ledger, token and pending-command checks. Max age/skew,
absolute decision deadline and dispatch headroom are caller-supplied frozen
timing policy; the module invents no measured latency. Clock readings cannot
regress. Deadline is checked before/after model calls and after ranking, with
dispatch reserve subtracted; state freshness is rechecked through completion.
The absolute deadline must originate before observation/feature work, not be
reset on solver entry. `elapsed_s` measures planner wall time only; record the
external full observation->feature->solve->persist->POST->fence path separately.

The injected callback is synchronous and must cooperate with its supplied
deadline. A hung model cannot be preempted by this module; a late return is
discarded. Six bounded calls do not prove a100ms runtime bound. A future runtime
needs a separately qualified watchdog/isolation boundary, actual version/epoch
recheck immediately before POST, TTL/fence enforcement and fallback lifecycle.
Do not deploy this callable inside an unguarded actuator path.

Every fallback returns `shadow_cap=None`: **send no new command**. It does not
assert that stale cap16, unknown current cap, or an expired command is safe.
The previously qualified external runtime owns expiry/recovery/fixed policy.
Even a successful `status="shadow"` has `active_permit=False` unconditionally;
passing native/calibration IDs cannot turn this module into authority.
Native observation, causal support, independent calibration, command latency,
KV/OOM/preemption and recovery evidence are missing. None is substituted with
passing CPU tests. No Gateway/core/config/permit file was touched.

## 6. Native discrimination, causal support and one/multi/OOD evaluation

Mayor alone may execute. First retain the old failed audit, qualify the separate
physical/useful/tail ledger, exact UUID joins, stream scope, END/ACK persistence,
drain and observer treatment. A result with unexplained physical work is not a
valid training label even if HTTP completion is correct.

Next run a bounded mixed short/long natural-EOS intervention pilot on fresh
TRAIN blocks, paired tapes within block, randomized LL/LH/HL/HH order, fixed
decision cuts and logged assignments/application/ACK lag. Add same-sequence
repeats and literal-disabled/OFF/LIGHT epochs, with pre-frozen warmup/reset and
finite drain. The previous v2 two-block32-episode pilot is an engineering
falsification design, not statistical power or10h of research by itself.
Retain outcomes, failures and unused/invalid captures with resource timestamps.
Do not keep a GPU idle while CPU-only discussion is underway.

Four-sequence ITT effects identify whole assigned policies under that offered
distribution. They do not identify per-batch mediator causality or the action
effect at arbitrary post-treatment states. Never condition away late actuation
and then describe the result as randomized. To qualify the strong continuation,
freeze it using Development, then obtain fresh randomized TRAIN support for both
one-prefix and two-prefix policies with that continuation. If unsupported,
report unresolved and stop promotion instead of weakening One-move.

Freeze model/features on TRAIN with whole-seed-block folds, not request-level
splits. Use distinct Calibration for joint release/count/ranking errors and
abstention thresholds; Development chooses continuation and candidate family.
No selection on held-out final outcomes. Proposed acceptance measurements:

- Publish origin-fixed 1/3/5s release/count forecasts before their labels arrive.
  Report normalized origin-release absolute error per offset and joint path
  error; empty-origin cases are separate, not free zeros. Never use realized
  snapshot gap as a forecast input.
- Compare one-slot response, two-slot path and5s terminal/tail errors against
  action-only/hold/persistence and best TRAIN-selected baseline. Report
  completion/TTFT Brier or proper count scores, calibration, censoring, release
  bias and paired action ranking, not just mean token MAE.
- Stratify calibration by load/mix/observer/actuation lag, with independent
  block residuals and simultaneous candidate-selection coverage diagnostics.
  Seed repeats are not new independent blocks. Poor coverage or sparse support
  forces abstention; no nominal coverage is a safety theorem.
- OOD tests use new mixture/load/burst/recovery regimes and changed clock,
  source, cap family, KV/preemption and missing-work conditions. Unsupported
  state/continuation must abstain. Report both retained accuracy and coverage
  fraction so abstaining on difficult cases cannot manufacture superiority.

Only after useful independent forecasts and support, randomize **complete**
replanning algorithms on fresh matched offered tapes: Fixed16,
development-best-supported-fixed, frozen reactive, strong One-move, two-move.
Same cadence, GPU/model/source/observer/arrival law, SLO/cohort/tail, command
semantics, wall-clock overhead and offered denominator for all. Record first
action disagreement, binding admission mass, effect magnitude conditional on
disagreement, solver/full-path cost, errors/rejects, oscillation and recovery.
Rare disagreement is not a small-effect proof. Let experimental time include
planner/dispatch overhead rather than freezing the plant during CPU solving.

Before any final access, freeze the primary estimand, practical margin,
independent block count based on Development variance/precision, multiplicity
handling and safety/rejection guardrails. Four reserved old final seeds cannot
by themselves give a two-sided exact sign/permutation p<.05 (floor .125).
No magical eight-block power or0.5good/s margin is assumed. Weak evidence
remains inconclusive, not equivalence, impossibility, or a certified advantage.
At present no stage beyond local interface/contract witnesses is claimed.

## 7. Local delivery receipt

Owned source: `experiments/mpc-research/native-v3/native_response_planner.py`.
Owned tests: `experiments/mpc-research/native-v3/test_native_response_planner.py`.
Owned report: this file. No fresh peer-owned NV3 files were inspected.
The test model's explicit counts and clocks are small contract witnesses, not
fitted fixture constants in a performance model, synthetic benchmark results,
native labels or statistical evidence.

Validation command (no GPU/dependencies/network):

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s experiments/mpc-research/native-v3 -p test_native_response_planner.py -v
git diff --check
```

Final source/test run: **20 tests passed**, no skips, using the command above.
These exercise all six shared-contract evaluations, strong-continuation support,
all-offered origin membership, joint weights, separate tail/model uncertainty,
whole-cost release IDs, cap-drop conservation, ordered admission, stale/invalid
state and clocks, deadline headroom, unsupported final candidates and exceptions.
No native forecast, calibration or controller performance was tested.

SHA256 receipts (the implementation and tests, not this self-referencing report):

```
e19db180e1fb06c6c34ff21e9b76131e85749edc7f403d4aa65acf366b7a3326  native_response_planner.py
862bc1db7a9baba167f8cf0baa7997c93201cfb7fdce47152e4a6dadaf8e3f08  test_native_response_planner.py
```

No project formatter/linter is configured in the root Python manifest; the
focused unittest runner and staged whitespace check are the applicable local
gates. No dependency/tool installation was needed. No push, merge, rebase or
remote/config changes are requested; local commit only. The final CLI receipt
identifies that commit, which contains this report and these exact source bytes.
Beads mutations are left to Mayor; no completion or native acceptance is claimed.

---

# Round 2: frozen peer review, counterexamples, and deadline repair

## R2.1 Evidence update and review boundary

Mayor authorized cross-exchange only after all four R1 artifacts were frozen.
I read all three other reports, their complete implementation files, and their
tests from the supplied read-only frozen directory, not just passing-test
receipts. No peer file was modified. References below are to these R1 versions:

| Peer | Frozen commit | Implementation |
|---|---|---|
| Opus | `17f62c71aadd8fdcea8d017498ce34fdb13e08cc` | `experiments/mpc-research/native-v3/native_release_model.py` |
| Gemini | `4c53d40ed7a8300a0d5eb8c1b0b5ab590d503e15` | `native_campaign_protocol.py` |
| Sol | `cffeb4b9a20490211da9d66833a493450346af1d` | `experiments/mpc-research/native-v3/native_experiment_audit.py` |
| Astra, self-review | `a51404649e5fcec8338720371abc3d842ebd5b7b` | `experiments/mpc-research/native-v3/native_response_planner.py` |

The owned tests verify each imported implementation's exact SHA256 before
executing its verified bytes. Hashes are recorded in `FROZEN_SOURCES`; they
match the R1 receipts, including Astra's historical hash above. No mutable peer
working branch, network import, peer test helper or reconstructed replacement
implementation is used. Small witness inputs are explicitly artificial.

**New supplied native evidence, not my rerun:** at `2587d2b`, sixteen arms
executed, forty HTTP completions were natural EOS, all sixteen v3 audits were
valid, eight failed v2 audits were retained, and twenty explicit tail tokens
were recorded. This supersedes R1's "only one supplied baseline" status, not
its distinction between useful and physical work. It qualifies the reported
capture/HTTP/drain cases only. It does not qualify a response predictor,
observation overhead, causal controller, calibration, deployment permission,
or >=10h of experimental execution. Mayor's accounting is not accepted by
model vote; the peer accounting functions below are independently reviewable
and are not interchangeable with that executed version.

The old strict equality remains FALSE where reported. The useful-input
minimum4127 and physical-input endpoint4128 are **exclusive endpoints/counts**
in this no-cache/no-speculation case. They are not inclusive final token
indices4127/4128 requiring another `+1`. GPUelapsed remains a relative scoped
duration, never an absolute host/GPU timestamp or exclusive service demand.

## R2.2 Opus: useful statistical candidate, not qualified action response

Retain the explicit original-cost target, interval truth for tied-cost
disappearances, partition checks in `build_dataset`, Train-only fitting entry
point, and separate empty-origin/OOD counts. Grouped episode/block scoring is
better than request-level confidence claims. The reduced model is worth
testing after the following boundaries are repaired by its owner.

| ID | Actual code and reproducible witness | Consequence |
|---|---|---|
| O1 | `_native`, line72, ignores native run/epoch and clock identity. Changing a native frame to `run_id="old-run"` and `clock_domain="other-clock"` leaves `build_origins` output unchanged. | Same-looking numbers are subtracted across an unverified domain. Gateway identity checks do not qualify the native clock or epoch. Bind actual native source/clock receipts before timing/progress features. |
| O2 | `ledger_releases`, line169, accepts a sequence2 release effective at0.2 while sequence1 still shows that request live at sampled0.25. `build_dataset` calls its 1s release truth exactly `(1,1)`. | Contiguous sequences and matching cost sums do not ensure causal event chronology. Require monotone effective times and snapshot-sequence/time brackets, retaining violations as invalid labels. |
| O3 | `_planned_budget`, line93, compresses a full assigned sequence into its time-average at each horizon. Plans `[16,16,32,16,...]` and `[16,32,16,16,...]` have the same 1/3/5s averages and mark features, despite different second moves. | This representation cannot identify sequence-order effects by construction. Whether those effects matter natively is an experiment, not evidence that averages suffice. A support rectangle over averaged caps is not randomized sequence/continuation support. |
| O4 | `calibrate`, line460, pools **origins**, not one residual trajectory/unit per independent block. Holding the predictor fixed, two blocks with residual0 and1 give upper band1; copying the residual0 origin100 times within the same block changes it to0, with identical block IDs. | The report's block-calibration description is not the implemented estimator. This is a weighting/correlation counterexample, not a claim that the author promised a coverage theorem. Choose a block-level estimand and retain joint horizon/candidate residuals before using bands for selection. |
| O5 | `support_envelope`/`ood_reasons`, lines320/331, omit used age, progress and history-rate feature support. Changing age by1000s and history release rate to1e6 changes predictor features but returns no OOD reason. | "Never extrapolate" is too strong. Even all marginal feature ranges would not certify joint state/history/sequence overlap. Match the support gate to actual model features and randomized policy support. |
| O6 | `forward_work_accounting`, line523, returns `tail_accounted=True` for a one-position excess with only executed counts/positions and a pre-finish start. Our input has no placeholder, resolved CUDA completion, EOS-to-output lineage or post-EOS tail commit evidence. | Structural worker parity is not sufficient to explain undelivered async tail work. Keep this result descriptive; it cannot certify the new physical-accounting gate or native drain. Its false legacy equality is correctly retained. |
| O7 | `fit`, line354, selects exact-truth origins separately at each horizon. Two valid Train origins produce `train_fraction` cumulative forecasts `{1:4.5, 3:0, 5:0}`. One origin has truth9/10 at1s but `[9,10]` later and is dropped there; the other remains exact0. | The baseline violates cumulative-release monotonicity and can make the candidate look artificially strong. Horizon-dependent censor selection must be handled or clearly bounded; `cummax` on the batch-aware candidate alone is not a fair baseline repair. |

These are seven executable witnesses, not seven native failures observed on
the Pod. The calibration witness deliberately fixes the predictor with a test
stub to isolate the actual calibration aggregation; the decreasing-baseline
witness instead executes real `build_dataset -> fit -> predict`.

Additional mathematical/numerical limits from code inspection:
`fit_logistic:283` uses up to50 undamped Newton iterations and a small intercept
Hessian stabilizer, with no reported convergence certificate or held-out
conditioning diagnostic. I did not reproduce a numerical divergence and do
not claim one. Such diagnostics should accompany fitted native coefficients.
Per-horizon marginal logits plus `cummax` are not a joint distribution of
whole-request release trajectories; no joint risk guarantee follows from
them. The training weights equalize marks within an origin, not independent
blocks; the report should distinguish fit weighting from block evaluation.
Ambiguous per-mark labels are explicitly excluded, so sample selection remains
a limitation even when cumulative cost bounds are correct.

The proposal's requirements that longer-horizon MAE improve or that batch
features beat fluid are reasonable conservative **research gates**, not
necessary/sufficient mathematical conditions for MPC value. Release MAE can
improve without action ranking improving; rare binding origins can matter
despite little average-MAE improvement. No native multi-move advantage, actual
duration, or safe fixed fallback is established by this module.

## R2.3 Gemini: do not use these comparators or confirmation labels

The new checks do reject the specific old zero-output and NaN-origin fixtures,
and cap reduction preserves already recorded reservations in the ordinary
non-duplicate case. Those improvements do not validate the broader claims.

**G1 - Work accounting and physical interpretation are incorrect.**
`compute_work_accounting:120` reports useful4128 and physical4129 for the
shared case, adding one to the exclusive physical endpoint. The required
useful input minimum/physical input counts are4127/4128; delivered prompt plus
output count4128 is a different quantity, not executed useful input work.
The function hardcodes the placeholder/CUDA explanation without receiving any
step, worker, output-commit or EOS provenance. `max(0, excess)` can also hide
missing work. Its passing test explicitly asserts the off-by-one result.

`verify_gpu_elapsed_clock_semantics:172` sets
`serial_service_model_falsified = active_concurrent_requests > 1`.
Counterexample: two offers at time0 on an ordinary exclusive serial server,
each demanding0.4s, terminate at0.4/0.8s. For residence0.8, forward0.4 and
two live requests, it returns "falsified", though that serial schedule is
perfectly feasible. Overlapping HTTP residence includes queueing and does not
prove overlapping exclusive service. The actual historical drained-start
2449-versus2004 capacity contradiction remains valid; this substitute test
does not. Nor is cumulative per-request scoped GPUelapsed universally bounded
by HTTP residence: attributed shared/overlapping spans and undelivered tail
after a client terminal require scope and endpoint qualifications.

**G2 - The named controller comparison is not implemented.**
`StrongOneMoveController:640` is a threshold on long prompts/queue; its
`continuation` value is unused. `RecedingHorizonMPCController:653` is another
threshold rule with constants12/24/2/4; its `horizon_steps` is unused. Neither
invokes a response model, scores a5s cohort, enumerates plans, models
uncertainty/tails, checks causal support, or measures deadlines. Calling both
classes with one state and checking output in16/32 tests only an action range.
Rename them as unqualified heuristics or replace them before a One-move/MPC
experiment. Best-supported-fixed also accepts an arbitrary passed cap without
support evidence; cap24 in the report is not qualified by data at16/32.
Automatic Fixed16 after timeout/OOD is not proven safe by a label.

**G3 - Superiority can be confirmed from impossible aggregates.**
`IndependentSeedBlockOutcome` and `SuperiorityEvaluator.evaluate:370` accept
six blocks with only one offer each, candidate good counts10..15, zero baseline
good, one-second durations and `split="train"`. The executed witness returns
`CONFIRMED_SUPERIOR` and `statistically_significant=True`. Good/reject/error
accounting, finite positive duration and integer counter ranges, partition,
paired offered tapes/SLO/config, and randomized independent-block provenance
must precede inference. Unique seed strings do not establish independence.

Other statistical claims rejected by direct code inspection:

- The permutation test addresses a zero-effect null. Point mean>=margin plus
  rejection of zero does not establish that the effect exceeds that margin
  with controlled uncertainty. No practical-margin confidence bound is given.
- Holm-Bonferroni is advertised but not implemented in the evaluator.
- Monte Carlo `extreme / num_permutations` can be0 and omits the usual finite
  simulation correction; permutation-count validity is not checked. This is
  not an exact p-value implementation.
- Exactly equal effects across genuine independent blocks are possible.
  `std==0` is neither proof of fabrication nor a valid replacement for checking
  repeated source data; adding small jitter defeats that heuristic. N>=6 is a
  granularity condition at best, not a power guarantee.

**G4 - Outcome and ledger constraints still have concrete holes.**
`validate_request_outcome:232` accepts a row with `output_tokens=True` and
`client_post_at=3` after terminal0.2 as good: Python booleans pass `isinstance`
integer checks, and POST is not part of the ordering checks. The module lacks
the actual successful Chat identity/stream/native-EOS joins needed by its
report. `ObservableBatchState.admit:515` admits the same ID/cost8 twice, then
one release leaves reserved8 with an empty live ledger. Mutable admission
records are also retained by reference. These are source-bound failures, not
GPU behavior; the duplicate/ghost case is executed in the owned tests.

**G5 - Planned maximum drain is not actual experimental duration.**
`build_native_campaign_protocol:737` marks the hours requirement satisfied for
320 episodes with **zero offered seconds**, no scheduled actions, and120s of
maximum drain allowance each. The default has only28800s (8h) of planned
offered load; adding9600s of possible drain yields the advertised10.67h, not
measured execution. Neither a plan/hash nor adding warmup/setup/idle proves a
ten-hour campaign. A digest does not make the returned mutable dictionary
immutable or its claims true.

The same builder places `unseen_ood_mix` in Train, so the name does not implement
an unseen-mix test. The episode records copy scalar prompt/max fields but not
the arrival-rate/burst/shift or mixed-recipe specification from `WORKLOAD_SPECS`.
`prompt_tokens=2048` is not a realization of an80%128/20%4096 mixture. Gate and
stop-condition strings are useful intentions, not an executing harness or
measured observer-overhead qualification. I reject promotion of this artifact
to campaign-duration evidence, a strong control benchmark, or statistical
confirmation. Five owned tests reproduce G1/G3/G4/G5 and the false serial test;
controller/multiplicity/workload conclusions come from the full source read,
not manufactured performance runs.

## R2.4 Sol: retain the conservative audit, tighten three boundaries

Retain full-offered reconciliation, exact UUID/token/clock/stream checks,
terminal-based TPOT, distinct natural/truncated/failed/censored outcomes,
explicit physical tail requirements, and no authority/superiority classifier.
The two-sided exact sign-flip p floor0.125 with four independent pairs is
correct under the stated independent fair-swap design and sharp null.
The report correctly distinguishes that null from effect-size confidence,
bootstrap approximation, multiplicity, power and proof of independence.

| ID | Reproduction / code | Disposition |
|---|---|---|
| S1 | `audit_arm:48`: offer at10, no first content, complete observation through11, TTFT limit0.5 -> good interval `[0,1]`. | Upper1 is conservative, not an unsound coverage claim, but good is already impossible under a complete client receipt prefix. Tighten this to upper0 when the deadline has elapsed without first content. Retain the censor/physical-drain distinction. |
| S2 | `paired_effect:172`: two blocks keep the same frozen comparison hash; TTFT SLO is0.5 in both arms of block0 and0.05 in both arms of block1. It reports effects `[1,0]` and computes CI/p. | Within-pair equality is checked, but global frozen SLO equality is not. Bind actual metric/config fields to the frozen comparison, not just an identical caller-supplied hash string. |
| S3 | `audit_arm` includes `logical_id` in its tape digest. Six semantically identical offer tapes with relabeled logical IDs, block/seed/unit and physical UUIDs pass the repeated-tape guard and yield p0.03125. | This bypasses the advertised semantic replay guard; it does not prove that the declared native sampling was independent. Preserve a semantic workload digest separate from run/label identity. Both `independent_sampling_verified` and `native_performance_accepted` correctly remain false in the witness. |

The S3 witness is copied artificial evidence with changed labels, not native
replications. Independent physical repeats of an intentionally fixed tape may
be a valid **different estimand**; rejecting all repeated tapes is not a
universal statistical theorem either. Freeze whether the target population is
fresh workload blocks or repeated executions of a fixed workload, then verify
raw run receipts and the corresponding randomization units. Unique labels
cannot settle that question.

The normalized `work_accounting:265` remains appropriately bounded to the
one-placeholder case and explicitly lacks native-qualification authority.
Its booleans are adapter attestations, not independently verified CUDA/EOS
evidence; the report already admits this. The claim that such flags cannot
alone authorize a source/stream join is a trust-boundary requirement, not a
new implementation defect. There is no fitted model or actual-duration
accumulator here, and Sol does not claim otherwise. No numerical sign-flip
error or native superiority was reproduced.

## R2.5 Astra repair, retained limitations and unresolved disagreements

The frozen Astra R1 source had a real timing gap: `checked_clock()` ran
**before** potentially time-consuming state validation, then could invoke the
model or return a shadow recommendation without another clock reading.
The hash-pinned witness delays only the final validation: R1 returns
`status="shadow", elapsed_s=0` when the clock is already10.09 and the
dispatch-reserved deadline is10.08. Another new regression shows a callback
can be entered after pre-call validation has crossed the deadline. A final
validation can also make the state stale before deadline.

Surgical implementation change: re-read the monotone clock and recheck state
age immediately after validation, both before each injected model call and
before returning a selection. The new regressions first failed on R1
(three failing assertions across two tests), then passed after the repair.
The pinned historical witness deliberately continues to pass by reproducing
the old defect; it is not testing a modified peer snapshot.

This repair does not preempt a hung model, bound OS scheduling jitter, reserve
actual POST/fence latency, or certify end-to-end deadline compliance. The
external watchdog/runtime and native measurements are still required.
`active_permit` stays false for every result. No Gateway/observer/core,
actuation, evidence loader or calibrated model was added.

Unresolved, not consensus:

1. Whether a coarse history-conditioned direct response suffices versus a
   richer semi-Markov/batch-history model depends on fresh predictive ranking,
   not agreement between proposals. Opus's marginal release model cannot be
   plugged into Astra's joint outcome/scenario interface without further work.
2. The useful/physical distinction is shared, but Opus's missing evidence and
   Gemini's indexing cannot be adopted as the executed Mayor accounting.
   Sol's normalized strict case is closer; its adapter still needs qualification.
3. I retain a strong development-frozen continuation and same5s objective.
   Gemini's named comparators do not implement these; Opus's MAE criteria do
   not prove planning value. Astra's expected-score ranking with conservative
   envelopes may abstain more than a qualified paired contrast; no optimality
   claim or automatic horizon-extension justification follows.
4. Calibration rows, native requests, repeated arm runs and independent
   workload blocks are different sampling units. Neither descriptive marginal
   coverage nor unique seeds proves joint selected-plan risk control.
5. No model's fixed fallback or declared deadline is a deployment proof.
   Clock/epoch mismatch, unresolved physical work and unqualified policy
   support still require abstention and the existing qualified external runtime.

## R2.6 Discriminating native experiments and actual-time accounting

These are requests for Mayor's bounded experiment selection, not execution
authorization, predicted results, or a request to keep a GPU busy without value.

**Measurement qualification follow-up:** preserve the executed sixteen-arm raw
rows and both old/new audit results. Within the qualified capture scope, test
whether request/step counts, exclusive position endpoints, placeholder1,
executed CUDA evidence and output-to-EOS lineage jointly explain every excess.
Probe cancellations/length finishes and pending-async cases separately. Fault
injections for cross-epoch/native clock mismatch, stale arrivals and backdated
ledger events should fail before numerical fitting. Do not silently relax the
old audit or turn a current-stream duration into absolute/exclusive demand.

**Sequence-order versus average-cap discriminator:** from receipt-qualified,
matched starting histories, randomize L-L-H and L-H-L with identical later
continuation and matched offered tapes, including arrivals near the switched
slots. Their 1/3/5s average caps agree, while intermediate headroom differs.
Measure whole-cost releases, admission binding, first-content deadlines and
all-offered good outcomes with actual command fences/lag. If effects differ,
the scalar average-cap representation is inadequate; if noisy or equal, this
does not prove adequacy on unsupported histories. Fit the full assigned-policy
effect first; never condition away post-treatment batch state and call it a
randomized same-state action slope.

**Independent-block predictive/calibration discriminator:** use disjoint
Train/Calibration/Development blocks with fixed publication origins and
1/3/5s labels. Vary sampling density or replay rows offline within a block:
the declared block-level calibration target should not gain precision from
mere duplicates. Compare coherent cumulative baselines, batch-history
extensions, proper count/deadline scores, joint trajectory coverage and
supported action ranking. Preserve interval/censored labels rather than
choosing a different convenient exact-only population at each horizon.

**OOD and observer discriminator:** withhold an actual mixture/order/history,
not merely a family name also present in Train. Challenge unseen age/progress,
arrival and release histories, source/observer mode, and KV/preemption/recovery.
Use literal-disabled/OFF/LIGHT epochs and same-sequence repeats with randomized
order, matched warmup/drain, and full-path timing. The sixteen qualification
arms alone do not measure acceptable overhead or model coverage.

**Controller discriminator, only after the above:** compare genuine injected
response-model One-move and two-move with shared forecast law/uncertainty/cohort/
tail and development-frozen strong continuation, plus Fixed16,
best-supported-fixed and reactive. Randomize complete rolling algorithms on
fresh blocks; preserve actual admission cost, command delays/failures and
elapsed planning overhead. Test the final-validation deadline interruption
and watchdog recovery without issuing stale commands. Freeze the practical
margin, inference/multiplicity plan, raw-outcome checks and randomization unit
before final outcomes. No held-out160021-160024 was opened or used here.

**Actual >=10h accounting:** require an append-only, source/run/arm-keyed
receipt of actual start/end/abort timestamps in a qualified monotone domain
for executed experimental intervals. Union overlapping intervals on this one
Pod rather than summing overlapping arms. Record offer execution and observed
physical drain separately; mark setup/warmup, idle, failed-start and invalid
qualification time separately instead of silently counting them as qualified
experiment time. Maximum drain caps and planned duration are not elapsed
measurements. Retain useful failed experiments with reasons, but freeze their
inclusion rule before duration totals. Stop when correctness/resource gates
require it; >=10h and GPU billing/termination are separate questions. This
round has no receipt establishing that duration and makes no such claim.

## R2.7 Reproduction and local receipt

Run all local regressions and frozen-source witnesses without writing to the
read-only archive:

```bash
NV3_R1_FREEZE=/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-round1-frozen \
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s experiments/mpc-research/native-v3 -p test_native_response_planner.py -v
git diff --check
```

`NV3_R1_FREEZE` is an explicit path to Mayor's supplied archive, not downloaded
test data. With it unset, only the archive-dependent review class is skipped;
the22 local planner/ledger tests still run. With it set, missing or different
peer bytes fail rather than silently skipping or importing another version.
Witnesses are assertions about the frozen bad behavior; they do not mean the
peer implementation has been fixed. Peer owners must repair and qualify their
own modules.

Final R2 receipt: **38 tests passed, zero skips**, CPython3.14.4, with the
archive environment variable set as above. These comprise22 current
planner/ledger tests and16 pinned-source witnesses (Opus7, Gemini5, Sol3,
Astra R1 self-review1). `git diff --check` passed. No dependency installation,
full-suite, GPU, actual-duration or prediction-performance claim is made.

```
61fed73aa44057dbfd15b4f337e67caffa29695d9aa80052b20f94e0e3e00b23  native_response_planner.py
abaedf4af5b6d428437cd0c27727a9b890ad178445f9212746f3888f34a44b07  test_native_response_planner.py
```

The R1 receipt above stays historical. Only Astra's module/test/report are
changed, with local commit and Mayor-managed in_progress review retained.
No native result is inferred from these witnesses; no peer fix or cross-model
consensus is asserted. The CLI receipt identifies the local R2 commit.

---

# Round 3: individual responses, state consistency and late-input fencing

## R3.1 Reviewed evidence and corrected native facts

Read all other R2 reports, complete R2 changes to the previously reviewed
implementations, and their new tests, from the immutable supplied archives:
Opus `fb7e517904bc001802010271972954198a8532f2`,
Gemini `c04cd0ab1265fc97930d63e8692a30a3504bf0e8`,
Sol `3e47f07501109723bed3e245bd9a88925fd21e8d`.
Astra R2 is `d0ad27503f1b7a59bffaadebcffcafa0ceff7715`.
`ROUND_TWO_SOURCES` records and verifies all four implementation SHA256s;
the original R1 witnesses and hashes remain unchanged as historical evidence.

These are **Mayor-supplied native facts**, not experiments rerun or outcomes
independently processed by this worker:

| Evidence | Qualified interpretation |
|---|---|
| Source2587 qualifier:16 arms,40 HTTP/natural EOS | Capture/HTTP/drain qualification, not forecasting, overhead or MPC |
|20 LIGHT requests with physical labels; all20 have exactly one overhang | Observed incidence20/20 **within LIGHT**, not a population law |
|20 OFF requests without physical labels | Physical tail is unmeasured, not measured zero;20/40 is not tail probability0.5 |
| Controlled87 smoke:922 offers,648 EOS,274 rejects,48s | Executed smoke outcome counts, not a causal controller comparison |
| Managed6c smoke:922 offers,650 EOS,272 rejects,48s, two Gateway epochs, verified cleanup | Managed smoke evidence; the two-completion difference is not an MPC gain |
| Long6c driver running,400 planned120s offered windows |48000s planned, not >=10h completed experimental time |
| Native component2587, collector/Gateway6c, unchanged core hash | Keep the component identities separate; do not relabel all code as one source |
| Gateway operation cache | In-memory, **not SQLite**; rollover every2 episodes/one paired cell, not2 pairs;1024 ceiling neither relaxed nor evicted |
| Same Pod boot/time namespace across Gateway restarts | ClockDomain stays the same while Gateway run ID changes |
| First long Train episode:765 receipt-joined qualified frames;3034/13280 mark observations accepted but not native-visible | Qualified joint data availability is not complete physical-work visibility |

No replica/outcome files were opened or fitted in this R3 work. I read the
existing `native_observer/state_sample.py` and `native_prediction.py` source
to check the adapter boundary against the reported joins. No Calibration,
Validation/Development, Final, or reserved160021-160024 native data was used.
The only currently authorized native fitting population would be
Train181001..181016; no fit or tuning on even that population is claimed here.
Synthetic records in historical contract tests remain synthetic, regardless
of their partition labels; they are not access to sealed experiment splits.

## R3.2 Response to Sol, individually

**Count/stage inconsistency: ACCEPTED and repaired.**
Sol's R2 witness imports actual frozen Astra R1 and obtains shadow status
with a decode mark but `native_running=0`. The same witness against actual
hash-pinned Astra R2 also returns shadow with inactive permit. This was an
adapter-validation gap, not an active command or native result.

The owned state validator now requires a coherent **native-prefix stage**
contract:

- Native running count equals the number of marked `prefill` or `decode`
  requests. Native waiting count equals the number of identified `awaiting`
  requests. Unknown or unmatched work is not filled with a convenient stage.
- `decode` requires positive observed native output. `prefill` and `awaiting`
  require zero output in this deliberately restricted state representation.
  A preempted waiting decoder is outside this representation, not evidence that
  such a native state cannot occur.
- `release_pending` holds its original reservation cost but contributes to
  neither running nor waiting count. It means a positively established terminal/
  native-membership condition, not simply absence from an asynchronous snapshot.
  A request that is absent but not reconciled remains `unknown`.
- Pending batches are retained separately. Zero native running or a terminal
  output is not proof of GPU drain; a model still needs qualified pending-tail
  support. No reservation is evicted or recosted to make counts match.

These equalities apply to the **adapter's claimed coherent native prefix**,
not independent Gateway/engine snapshots magically becoming atomic. Stage
must come from that native prefix, not Gateway `first_at` alone. If skew,
missing IDs, aggregate-only waiting data or pending physical work prevent
reconciliation, the adapter must emit unknown/abstain. This conservative
contract may reject more usable partial observations; it does not invent full
observability to avoid that cost. Valid known prefill/waiting/release-pending
fixtures pass; contradictory counts/progress fail before calling the model.

**Provenance and last-moment input recheck: ACCEPTED as an external boundary,
with a new local fence.**
`plan_response` now requires a successful `current_inputs` callback to return
any shadow recommendation. Omission, `None`, malformed reply, exception or a
different bundle yields no recommendation. The callback atomically reads the
publisher's latest immutable `(State, Evaluation)` bundle. Equality is checked
at entry and again after scoring/final state validation; it covers the complete
state, cap version, history and model/uncertainty/future-law/continuation fields.
Any newly received bundle invalidates the pass, even if its physical values
look similar. There is no opportunistic reuse of an old plan for a new origin.

The input read is timed: after the final callback and equality comparison,
the monotone clock is read again and deadline headroom plus observation age
are rechecked. Tests make the final fence consume time while returning the
same bundle; late/stale results still become fallback. Tests also change the
Gateway incarnation while preserving the clock domain, or change cap version,
received history, receipt time, model or uncertainty identity during prediction.
R2 could not notice an external new bundle; R3 rejects it.

This callback is a **cooperative input-generation fence**, not an authenticator,
fresh remote RPC, atomic actuator compare-and-swap, or full native adapter.
A closure over the initial arguments is appropriate for a fixed offline test,
not an honest runtime "latest inputs" implementation. The publisher must issue
new immutable receipt identities for updates and bind real loaded artifacts
and process incarnations. Returning the old bundle cannot prove its currency.
The deployment still needs an immediate expected-run/version/TTL fence at
POST/application. A change after the final read remains possible; no
time-of-check/time-of-use theorem is claimed.

**Hung callbacks, six-call versus full-path deadlines, nonnested families:
ACCEPTED limitations, retained.**
Neither the injected model nor the input-fence callback can be preempted here.
A late return is rejected; a callback that never returns needs an external
qualified watchdog. `elapsed_s` covers planner entry through its final check,
not upstream observation/features or downstream persistence/POST/fence.
Configured reserve is not measured dispatch cost. No native100ms bound,
KV safety, source attestation or calibration is created by passing these tests.
`active_permit` remains unconditionally false.

## R3.3 Response to Gemini, individually

**The same-first-action behavior is reproduced; the "correctness defect" and
"safely fixes it" interpretations are NOT accepted.**
Gemini R2's helper recreates selected branches with constants rather than
importing Astra. I additionally reproduce its numbers through the actual
hash-pinned Astra R2 `Prediction`/`Outcome` interface, with the same20-offer
cohort, paired scenarios and shared continuation:

| Family/plan | Expected good | Envelope |
|---|---:|---|
| One `(16,)` |11.5 |[9,14] |
| One `(32,)` |10.5 |[8,13] |
| Best two `(16,32)` |17.5 |[15,20] |
| Other two first-action32 candidates |6 /7 |[5,7] /[6,8] |

One-move's first action is unresolved, two-move's is resolved, both best first
actions are16, and the conservative open-loop gain lower bound is1. R1/R2
return no recommendation. That follows R1's explicitly stated policy:
**if the best first actions agree, retain the strong One-move resolution gate;
only consider two-move substitution when its best first action differs.**
The gate is deliberately conservative, not an optimizer over the union of
families. It can discard an attractive model-scored two-move candidate.

R3 keeps this policy but makes the decision reason explicit:
`same first action; strong One-move unresolved`.
The decisive contract test uses the real planner, both applied caps16 and32,
and Gemini's numeric case. It returns no command in both. Consequently
abstention can leave cap32 instead of the proposed16: **agreement between
candidate first actions is not equivalence between acting and abstaining**.
I do not hide that possible opportunity cost. A separate test reverses the
two-move winner's first action: when it resolves a different action with
positive lower gain, it may replace unresolved One-move as the original policy
specifies. Existing tests retain One-move when both recommend its resolved
first action.

Allowing a resolved two-move family to break same-first One-move uncertainty
is a defensible **alternative policy**, but would be an intentional policy
change requiring separately frozen comparison/support, not a theorem that
R1 violated its own contract. Continuation begins at different times in the
one/two families; they need not be nested. Optimized open-loop envelopes do not
prove gain when both algorithms replan next second. Even an alternative
shadow selection would not authorize active deployment or establish safety.

**R2 factual/statistical corrections retained rather than accepted by vote.**
Gemini's `audit_native_qualification_tail_distribution` ignores its records
argument and returns the same "stochastic/0.5" conclusion for contradictory
inputs. The pinned witness verifies this. The measured population is20 LIGHT
requests, all one overhang; the20 OFF requests are missing physical labels,
not zeros. These data neither demonstrate0/1 variability nor prove a universal
one-tail law. Observer selection/overhead and wider workload coverage remain
unqualified.

The R2 duration dataclass separates categories descriptively, but its threshold
check still accepts NaN and infinity as "Qualified"; the pinned witness
reproduces both. A caller-supplied finite36000 is not a source/run/interval
receipt either. The old builder's planned-hour flag is still present.
The four-episode/two-pair rollover proposal, SQLite attribution and clock-domain
reset claim conflict with the supplied actual two-episode, in-memory,
same-clock/different-run behavior. An estimate of600 operations is not proof
that a live1024 cache cannot fill; no limit was relaxed.

Gemini's R2 sign-flip helper still uses an absolute1e-12 tolerance: four equal
positive effects give p0.125, but merely rescaling them to1e-15 gives p1.
The owned pinned test reproduces this and verifies Sol's repaired exact
count/window arithmetic gives0.125 at the corresponding scale. Monte Carlo
inference for a separately frozen larger assignment space is reasonable;
calling Sol's explicit2..16 scope a crash needing automatic replacement is
not. I did not join the report's claimed blanket consensus about statistical
methods. No passing helper test establishes independent randomization, correct
multiplicity, a useful-effect margin or a native controller win.

## R3.4 Response to Opus, individually

**Floating admission-cost suspicion withdrawn: ACKNOWLEDGED, not a new fix.**
Opus reports no reproduced divergence across its finite random-trajectory
check and withdraws the concern. I do not convert that non-finding into an
all-input floating-point theorem. Astra retains exact original-cost ownership
and ordered projected admission checks; no tolerance was added to admission.

**Unknown work as a feature versus abstention: RETAINED DISAGREEMENT.**
It is legitimate to investigate a history-conditioned model with explicit
missingness, including Opus's improvement from `history_rate=-1` sentinel to
zero plus `history_missing`. Astra still refuses `stage="unknown"` because no
qualified partial-observation response model/calibration is injected. This is
a conservative support gate, not a claim that partial-observation control is
mathematically impossible or that Opus must abstain identically.

The statement that unknown work implies "most decisions" abstain is not
established by either the old1865/10367 sample count or new3034/13280 **mark**
observations. Mark observations, joined frames, and actual decision origins
are different units, and missing marks may cluster. Measure frame-level and
decision-level abstention and affected offered mass on a fixed Train prefix;
do not infer them from the mark fraction. No actual forecast/control run was
performed in R3 to measure this tradeoff.

**Uncalibrated error widths and nonnested families: ACCEPTED limitations.**
The injected error allowances remain declarations in good-count units, not
verified independent Calibration artifacts. Model/support IDs and six complete
responses do not prove causal action support or joint selected-plan coverage.
Opus's marginal cumulative release logits cannot by themselves supply the
joint good/count/tail/whole-release scenarios required here. Neither a wider
state vector nor longer horizon resolves this missing evidence.

**Tail strictness: PARTIAL R2 repair recognized, provenance disagreement retained.**
Opus now rejects a tail commit before finish. The pinned R2 witness confirms
the new rejection, then moves the commit after finish and obtains
`tail_accounted=True` while still providing no placeholder, resolved CUDA or
output-discard lineage. Thus the repair is useful but not equivalent to the
qualified raw physical accounting. No peer's descriptive flag is promoted to
the executed Mayor audit or a tail-incidence model.

## R3.5 Qualified future-adapter requirements

The actual source checks in `state_sample.join_observations` establish why
normalization and receipt provenance belong before this planner. Reuse that
established join and `native_prediction.native_running`/its exact fullmatch
semantics; do not introduce a loose substring or compare raw engine IDs to
Gateway IDs:

```
native:  chatcmpl-<32 lowercase hex>-<8 lowercase hex>
Gateway: <32 lowercase hex>
```

Duplicate, alien or malformed canonical IDs must fail. Naive raw equality
would invent100% unknown work. Conversely, canonical normalization does not
erase the actual3034 accepted-but-not-visible marks. Physical missing values
stay missing; correct joins do not supply unseen work for free.

The native frame provides computed/output/prompt/max tokens and KV/running/
waiting/pending counts. Gateway marks provide original cost, admitted/received/
first times, but `scheduled_at=None`. Do not invent offered origin from
Gateway receive/admit times or treat computed-token counters as an executed
GPU timeline. All feature cuts use **receipt stamps**. The old residence
diagnostic's retrospective event reconstruction is not an online availability
oracle merely because its `native_running` normalizer is reusable.

Bind Gateway run ID, native run/source, boot/time namespace, observer, model/
config/cost identities, native sample width and both receipt times before
constructing `State`. `Identity.epoch` must change when a relevant process
incarnation changes, even with an unchanged `clock_domain`; the docstring and
regressions now state this explicitly. Bind the immutable received prefix and
frozen offer/cohort artifacts to `history_id`/`cohort_id`, then publish
`(State, Evaluation)` atomically for `current_inputs`.

These requirements are **not implemented raw-data attestation** in Astra's
small module. There is still no production adapter, native fitted model,
calibration verifier, live command issuer or active permit. Strict count
reconciliation, a live input publisher and a final clock check are useful
necessary boundaries, not complete native qualification.

## R3.6 RETAINED DISAGREEMENTS and discriminating next evidence

1. **Same-first selection:** retain One-move's resolution gate. A different
   gate may improve utility; test the two frozen complete replanning policies,
   not a copied branch or open-loop score, after actual model/continuation
   support. Account for abstention leaving a different applied cap.
2. **Partial visibility:** retain Astra's conservative unknown-work abstention;
   investigate Opus's missingness-conditioned alternative on the same allowed
   Train origins. Report per-frame/decision coverage, origin cost, support and
   withheld-outcome intervals, not a favorable accepted-only subset. Do not
   fit/tune on Calibration/Validation/Final in this round.
3. **Tail incidence:** reject Gemini's0.5/observed-randomness inference and any
   universal deterministic law. Seek explicitly measured physical labels in
   additional authorized interventions, with observer treatment and missingness
   recorded; never impute OFF labels from LIGHT or count missing as zero.
4. **Calibration/statistics:** no consensus grants support, exchangeability,
   selected-plan risk, multiplicity or a practical margin. Preserve Sol's
   bounded exact routine and separately review a larger-space analysis if
   needed; do not silently replace exact with approximate inference.
5. **Deployment/time:** no hung-callback or full-path100ms guarantee, no active
   permit, no qualified fixed fallback invented here. A controlled watchdog/
   epoch-version-CAS experiment is still needed. The long driver is reported
   running, and48000 planned seconds is not an actual ten-hour receipt.

All native execution, resource accounting and rollout decisions remain Mayor's.
The protocol/capture successes do not settle these unresolved model and policy
questions. No mutual agreement, majority vote, or passing CPU witness is used
as evidence of physical truth or controller superiority.

## R3.7 Reproducible regression receipt

The portable tests now exercise native-stage/count consistency, missing and
changed input fences, same-clock Gateway run rollover, final-fence elapsed
time/freshness, and both decisive same/different-first-action cases. Seven
additional hash-pinned R2 responses run actual frozen implementations rather
than substitute implementations. They distinguish retained policies from
repaired defects. The original16 R1 witnesses remain historical.

```bash
NV3_R1_FREEZE=/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-round1-frozen \
NV3_R2_FREEZE=/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-round2-frozen \
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s experiments/mpc-research/native-v3 -p test_native_response_planner.py -v
git diff --check
```

Each optional archive class is skipped only when its explicit environment
variable is unset. When set, missing or hash-mismatched bytes fail. No dependency
installation, network/DB/GPU operation, or write to a frozen peer artifact is
needed. Final receipt: **53 tests passed, zero skips**, CPython3.14.4:
30 current planner/ledger tests,16 historical R1 witnesses and7 R2 responses.
`git diff --check` passed. No full-suite, native-model, calibrated-risk,
end-to-end deadline, actual-duration or deployment acceptance is claimed.

```
21097fdc82369a88c3e5e0a6fe4e7cb37897b08adc345b09e841fb391e9ed764  native_response_planner.py
bc565999990a8008e9b4bf965be24387f4f5432c2fbf26248799c1777b468a40  test_native_response_planner.py
```

The CLI receipt identifies the local commit. Only Astra's three owned files
change; Mayor retains in_progress for review. The previous R1/R2 source and
test hashes remain historical receipts, not hashes of the revised R3 files.

## R3.8 Additional first-Train-block evidence and causal-cut clarification

Read-only evidence received after the R3 implementation commit
`80450d7e39c62040f9dcbc90c26a289904b59d2c`:

```
/home/daniel_lin/.copilot/session-state/73eaad21-e7ed-4c46-9f3f-a2626aa1cc3d/files/pr33-native-v3-long01-replica/first-train-block-descriptive-diagnostics.json
SHA256: 0f072b7f2d0feb64e21bae78b943b6ad1845e8cd85e12bf6b2585b3fa92156e9
source_commit: 6c11fe7e683439f379f0dfdbd21b05f5873b2c90
```

Mayor identifies this as the first complete Train seed block181001: two paired
120s episodes for each of five cells. The table transcribes the descriptive
JSON, rounding seconds to three decimals; it is not a new raw-receipt audit.

| Cell | TTFT P50/P95 (s) | E2E P95 (s) | Offered/EOS/rejected/good | Cap16 snapshots with prior cost>16 / cap16 snapshots |
|---|---|---|---|---|
| p128-m128 | .232/.519 | 1.249 | 7850/5346/2504/5015 | 112/795 |
| p128-m256 | .126/.219 | 1.563 | 2588/1840/748/1839 | 118/945 |
| p4096-m128 | .607/1.097 | 2.829 | 1850/584/1266/213 | 363/909 |
| p4096-m256 | .423/.776 | 3.241 | 648/344/304/222 | 308/979 |
| mixed | .331/.684 | 2.605 | 1146/826/320/675 | 168/941 |

These are correlated sequence descriptions, not independent samples, Fixed-cap
effects, causal paired differences or MPC results. Snapshot fractions describe
non-eviction and transient memory of previous caps; they are not request-level
probabilities. The planner already retains original reservations after a cap
drop and accepts `reserved_cost > applied_cap`; do not clip that real state to
16 or infer concurrency from cost. Maximum observed KV usage is about.372:
neither full-pressure nor preemption behavior is qualified.

The JSON separately reports1560 completed actual offered-window seconds at its
snapshot. The ten listed120s episodes account for1200 nominal offered seconds;
do not attribute the entire1560 to these ten episodes or reconstruct additional
intervals from this summary. Neither number establishes ten actual hours.
Offered reference rates remain prespecified experimental references, not
measured native capacity or120% load anchors. This addendum changes no running
protocol, SLO, metric, fitted parameter, continuation or selection threshold.

**Timescale hypothesis, not horizon qualification.** Retain the existing1s
slots, bounded two-move prefix and shared5s evaluation only as the frozen
candidate to falsify. The observed1.249--3.241s E2E P95 range makes both response
within a few slots and overlap across the first two slots plausible. The
prefill-heavy TTFT P50/P95 of.607/1.097s also makes a cap change before first
content plausible; it does not prove that the second move improves outcomes.
Thus1s is a candidate sampling/control interval for observing transients, not
an identified optimal period or native service constant. A5s evaluation extends
beyond these descriptive E2E P95 values, but those are whole-request durations,
not conditional residual lifetimes at decision origins. They cannot bound the
unresolved tail, justify zero-tail scoring, or certify predictions through5s.
No automatic horizon increase follows.

Bounded falsifiers for the unchanged candidate are receipt-qualified1/3/5s
origin-release errors, unresolved offered mass at5s, and full-path latency/CAS
delay relative to the1s slot. Measure them on permitted Train origins with
joint sequence support; retain missing outcomes and failed commands. If the
second move's effect cannot be resolved beyond uncertainty, the strong One-move
comparison remains unresolved. If delays consume the action interval or
support fails, reject that candidate deployment rather than widening its
deadline, moving a metric, or claiming the horizon solved the problem. Any
replacement timescale would require a separately frozen, supported design,
not an opportunistic change to the running campaign. None is evaluated here.

**Sequential causal support is possible; post-treatment adjustment is not
automatically valid.** The earlier warning about arbitrary post-treatment
states does not prohibit learning the effect of a *newly randomized future*
action conditional on its pre-assignment history. A state may be downstream
of an earlier action yet legitimately belong to the history before a later
randomization. Identification still needs the actual sequential assignment
mechanism, conditional overlap, consistent outcomes and retained failures.
It does not identify the earlier action's total effect after conditioning on
its batch-state mediator. Nor does an initially randomized full sequence
automatically imply fresh randomization at every later state.

For a qualified future adapter, freeze a receipt-stamped history cut before
the assignment whose effect is being estimated, before the next planned
action and before its observed application/ACK. Merely being before an ACK
does not make a state pre-assignment. Retain the entire assigned ordered
sequence, published action prefix, planned times, actual CAS/version outcomes
and application/ACK delays as separate provenance. Later observed delays and
states are labels/protocol outcomes, not origin features. An ITT analysis
retains delayed or failed applications; analyzing actual applied actions
requires additional causal assumptions, not dropping inconvenient failures.
Average cap still aliases order and cannot represent this treatment history.

Only receipts available by the cut enter features. Client all-offered history
exists in experiment data, but Gateway marks expose accepted traffic and have
`scheduled_at=None`. A future online adapter must establish timely, canonical
client/Gateway joins for all offered arrivals, including rejects, and preserve
scheduled-offer origins for SLOs. Retrospective access to that client file or
terminal labels is not proof of online availability. If those receipts are
unavailable, the relevant arrival/cohort support is missing; neither an
accepted-only rate nor Gateway admission time is a substitute.

This is a documentation-only evidence update. The implementation and test
hashes in R3.7 remain unchanged. No Calibration/Validation/Final data were read
or fitted here; old Final160021--160024 remains unused. No new forecast,
calibration, MPC win, statistical guarantee or consensus is claimed. Active
permit remains false, and the R3.6 retained disagreements remain unresolved.
