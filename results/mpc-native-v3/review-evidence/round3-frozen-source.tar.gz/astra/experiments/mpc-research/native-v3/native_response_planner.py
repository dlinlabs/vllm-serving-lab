"""Bounded, shadow-only native response planning; no plant or actuator implementation."""

from dataclasses import dataclass
from itertools import product
from math import isclose, isfinite
from typing import Callable, Protocol


CAPS = (16, 32)
OFFSETS = (1.0, 3.0, 5.0)
MAX_REQUESTS = 256
MAX_SCENARIOS = 128


@dataclass(frozen=True)
class Identity:
    """Receipt-bound deployment and process incarnations, not a clock epoch.

    The adapter's epoch must change on Gateway/native run changes even when
    the Pod boot/time namespace and therefore clock_domain remain unchanged.
    """

    deployment: str
    epoch: str
    clock_domain: str
    cost_model: str


@dataclass(frozen=True)
class RequestState:
    """Stage/progress describe the same native prefix as State's counts.

    Awaiting requires an identified native waiting request, not merely a Gateway
    mark without first content. Accepted-but-not-visible work is unknown.
    """

    request_id: str
    original_cost: float
    prompt_tokens: int
    max_output_tokens: int
    observed_output_tokens: int
    stage: str
    age_s: float


@dataclass(frozen=True)
class State:
    state_id: str
    identity: Identity
    origin: float
    sampled_at: float
    received_at: float
    sample_width_s: float
    applied_cap: int
    cap_version: int
    pending_command: bool
    reserved_cost: float
    requests: tuple[RequestState, ...]
    native_waiting: int
    native_running: int
    pending_batches: int
    kv_usage: float
    history_id: str


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    probability: float
    future_offers: int


@dataclass(frozen=True)
class Evaluation:
    """IDs refer to frozen external artifacts, not attestations verified here.

    Good means natural complete, TTFT <= .5s from scheduled offer, and
    (terminal - first content)/(output tokens - 1) <= .05s; one token has TPOT=0.
    All failures/rejections score zero. Old outstanding offers need not be admitted.
    """

    model_id: str
    support_id: str
    future_law_id: str
    uncertainty_id: str
    cohort_id: str
    continuation_id: str
    continuation_development_receipt: str
    tail_rule_id: str
    tail_s: float
    origin_offered_ids: tuple[str, ...]
    scenarios: tuple[Scenario, ...]
    horizon_s: float = 5.0
    slot_s: float = 1.0


@dataclass(frozen=True)
class Timing:
    clock_domain: str
    deadline_at: float
    dispatch_reserve_s: float
    max_age_s: float
    max_sample_width_s: float


@dataclass(frozen=True)
class Plan:
    prefix: tuple[int, ...]
    continuation_id: str


@dataclass(frozen=True)
class Outcome:
    scenario_id: str
    settled_good: int
    unresolved: int
    expected_tail_good: float
    released_origin_ids: tuple[tuple[str, ...], tuple[str, ...], tuple[str, ...]]


@dataclass(frozen=True)
class Prediction:
    state_id: str
    plan: Plan
    evaluation: Evaluation
    outcomes: tuple[Outcome, ...]
    error_below: float
    error_above: float


class ResponseModel(Protocol):
    def predict(
        self, state: State, plan: Plan, evaluation: Evaluation, deadline_at: float
    ) -> Prediction | None:
        """Return None outside joint state/sequence/continuation support."""
        ...


@dataclass(frozen=True)
class Score:
    plan: Plan
    mean_good: float
    lower_good: float
    upper_good: float
    tail_lower: float
    tail_upper: float
    released_origin_cost: tuple[float, ...]


@dataclass(frozen=True)
class Selection:
    best: Score
    first_action_resolved: bool


@dataclass(frozen=True)
class Decision:
    status: str
    reason: str
    shadow_cap: int | None = None
    one_move: Selection | None = None
    two_move: Selection | None = None
    scores: tuple[Score, ...] = ()
    gain_interval: tuple[float, float] | None = None
    elapsed_s: float | None = None

    @property
    def active_permit(self) -> bool:
        return False


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _number(value: float, minimum: float = 0.0) -> bool:
    return type(value) in (float, int) and isfinite(value) and value >= minimum


def _integer(value: int, minimum: int = 0) -> bool:
    return type(value) is int and value >= minimum


def _name(value: str) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _cap(value: int) -> bool:
    return type(value) is int and value in CAPS


def transition_costs(
    live: tuple[tuple[str, float], ...],
    events: tuple[tuple[str, str, float, int], ...],
) -> tuple[tuple[str, float], ...]:
    """Replay ordered (admit/release, id, original cost, actually applied cap)."""
    _require(len(live) <= MAX_REQUESTS and len(events) <= 1024, "ledger size")
    costs = {}
    seen = set()
    for request_id, cost in live:
        _require(_name(request_id) and request_id not in seen, "duplicate live ID")
        _require(_number(cost) and cost > 0, "original cost")
        costs[request_id] = cost
        seen.add(request_id)
    _require(sum(costs.values()) <= max(CAPS), "initial reservation bound")
    for kind, request_id, cost, cap in events:
        _require(_name(request_id) and _number(cost) and cost > 0, "event cost/ID")
        _require(_cap(cap), "unsupported applied cap")
        if kind == "admit":
            _require(request_id not in seen, "reused admission ID")
            _require(sum(costs.values()) + cost <= cap, "projected cost exceeds cap")
            _require(len(costs) < MAX_REQUESTS, "ledger size")
            costs[request_id] = cost
            seen.add(request_id)
        elif kind == "release":
            _require(request_id in costs and costs[request_id] == cost, "release mismatch")
            del costs[request_id]
        else:
            raise ValueError("unknown ledger event")
    return tuple(costs.items())


def _validate_state(state: State, identity: Identity, timing: Timing, now: float) -> None:
    _require(state.identity == identity, "deployment/epoch/cost identity")
    _require(all(_name(x) for x in (
        identity.deployment, identity.epoch, identity.clock_domain, identity.cost_model,
        state.state_id, state.history_id,
    )), "missing identity/history")
    _require(identity.clock_domain == timing.clock_domain, "clock domain")
    _require(all(_number(x) for x in (
        state.origin, state.sampled_at, state.received_at, state.sample_width_s,
        state.reserved_cost, state.kv_usage,
    )), "invalid state numbers")
    _require(state.sampled_at <= state.received_at <= state.origin <= now, "availability")
    _require(now - state.sampled_at <= timing.max_age_s, "stale state")
    _require(state.sample_width_s <= timing.max_sample_width_s, "sample skew")
    _require(_cap(state.applied_cap) and _integer(state.cap_version), "cap/version")
    _require(state.pending_command is False, "pending command")
    _require(all(_integer(x) for x in (
        state.native_waiting, state.native_running, state.pending_batches,
    )) and state.kv_usage <= 1, "batch observation")
    _require(type(state.requests) is tuple and len(state.requests) <= MAX_REQUESTS,
             "mutable/oversized requests")
    ledger = tuple((r.request_id, r.original_cost) for r in state.requests)
    transition_costs(ledger, ())
    _require(isclose(sum(c for _, c in ledger), state.reserved_cost,
                     rel_tol=0, abs_tol=1e-9), "reservation conservation")
    for request in state.requests:
        _require(_integer(request.prompt_tokens, 1)
                 and _integer(request.max_output_tokens, 1)
                 and _integer(request.observed_output_tokens)
                 and request.observed_output_tokens <= request.max_output_tokens,
                 "token observation")
        _require(request.stage in ("awaiting", "prefill", "decode", "release_pending"),
                 "unknown native work")
        _require(_number(request.age_s), "request age")
        if request.stage in ("awaiting", "prefill"):
            _require(request.observed_output_tokens == 0, "stage/progress mismatch")
        elif request.stage == "decode":
            _require(request.observed_output_tokens > 0, "stage/progress mismatch")
    _require(state.native_running == sum(
        r.stage in ("prefill", "decode") for r in state.requests
    ), "native running/stage mismatch")
    _require(state.native_waiting == sum(
        r.stage == "awaiting" for r in state.requests
    ), "native waiting/stage mismatch")


def _validate_evaluation(state: State, evaluation: Evaluation) -> None:
    _require(all(_name(x) for x in (
        evaluation.model_id, evaluation.support_id, evaluation.future_law_id,
        evaluation.uncertainty_id, evaluation.cohort_id, evaluation.continuation_id,
        evaluation.continuation_development_receipt, evaluation.tail_rule_id,
    )), "missing model/evaluation receipt")
    _require(_number(evaluation.horizon_s) and _number(evaluation.slot_s)
             and evaluation.horizon_s == 5.0 and evaluation.slot_s == 1.0,
             "fixed five-second evaluation/two one-second moves")
    _require(_number(evaluation.tail_s), "tail duration")
    ids = evaluation.origin_offered_ids
    _require(type(ids) is tuple and len(ids) <= MAX_REQUESTS
             and all(_name(x) for x in ids) and len(set(ids)) == len(ids),
             "origin cohort")
    _require({r.request_id for r in state.requests}.issubset(ids), "missing live cohort")
    _require(type(evaluation.scenarios) is tuple
             and 1 <= len(evaluation.scenarios) <= MAX_SCENARIOS, "scenario bound")
    ids = set()
    for scenario in evaluation.scenarios:
        _require(_name(scenario.scenario_id) and scenario.scenario_id not in ids,
                 "scenario identity")
        ids.add(scenario.scenario_id)
        _require(_number(scenario.probability) and scenario.probability > 0
                 and _integer(scenario.future_offers), "future law")
    _require(isclose(sum(s.probability for s in evaluation.scenarios), 1.0,
                     rel_tol=0, abs_tol=1e-12), "scenario probabilities")


def _score(state: State, plan: Plan, evaluation: Evaluation, prediction: Prediction) -> Score:
    _require(prediction.state_id == state.state_id and prediction.plan == plan
             and prediction.evaluation == evaluation, "prediction binding")
    _require(type(prediction.outcomes) is tuple
             and len(prediction.outcomes) == len(evaluation.scenarios), "outcome count")
    _require(_number(prediction.error_below) and _number(prediction.error_above),
             "model uncertainty")
    mean = lower = upper = offered = 0.0
    release = [0.0] * len(OFFSETS)
    original_costs = {r.request_id: r.original_cost for r in state.requests}
    for scenario, outcome in zip(evaluation.scenarios, prediction.outcomes):
        _require(outcome.scenario_id == scenario.scenario_id, "joint scenario pairing")
        cohort_size = len(evaluation.origin_offered_ids) + scenario.future_offers
        _require(_integer(outcome.settled_good) and _integer(outcome.unresolved)
                 and outcome.settled_good + outcome.unresolved <= cohort_size,
                 "all-offered accounting")
        _require(_number(outcome.expected_tail_good)
                 and outcome.expected_tail_good <= outcome.unresolved, "tail expectation")
        trajectory = outcome.released_origin_ids
        _require(type(trajectory) is tuple and len(trajectory) == len(OFFSETS)
                 and all(type(ids) is tuple and len(ids) <= len(original_costs)
                         for ids in trajectory), "release trajectory")
        previous_ids = set()
        for i, ids in enumerate(trajectory):
            _require(all(_name(x) for x in ids) and len(set(ids)) == len(ids),
                     "duplicate/invalid release ID")
            current_ids = set(ids)
            _require(previous_ids <= current_ids <= original_costs.keys(),
                     "origin-cost conservation")
            release[i] += scenario.probability * sum(original_costs[x] for x in ids)
            previous_ids = current_ids
        p = scenario.probability
        lower += p * outcome.settled_good
        upper += p * (outcome.settled_good + outcome.unresolved)
        mean += p * (outcome.settled_good + outcome.expected_tail_good)
        offered += p * cohort_size
    return Score(plan, mean, max(0.0, lower - prediction.error_below),
                 min(offered, upper + prediction.error_above), lower, upper, tuple(release))


def _select(scores: tuple[Score, ...], applied_cap: int) -> Selection:
    best = max(scores, key=lambda score: (
        score.mean_good, score.plan.prefix[0] == applied_cap,
        tuple(-cap for cap in score.plan.prefix),
    ))
    other_upper = max(score.upper_good for score in scores
                      if score.plan.prefix[0] != best.plan.prefix[0])
    return Selection(best, best.lower_good > other_upper)


def plan_response(
    state: State,
    evaluation: Evaluation,
    model: ResponseModel,
    *,
    expected_identity: Identity,
    timing: Timing,
    clock: Callable[[], float],
    current_inputs: Callable[[], tuple[State, Evaluation]] | None = None,
) -> Decision:
    """Compare two One-move and four two-move plans, or issue no recommendation.

    Model and input-fence callbacks must cooperate with the deadline. Neither
    can be preempted here. The publisher must atomically return its latest
    receipt-cut State/Evaluation; any update invalidates this planning pass.
    This read is not an actuator CAS or proof of artifact authenticity.

    Agreement on the best first action deliberately retains One-move's
    resolution gate, even if only two-move resolves it. This conservative policy
    is not optimality, a claim of equivalent behavior, or a closed-loop theorem.
    """
    previous = None
    started = None

    def checked_clock() -> float:
        nonlocal previous
        now = clock()
        _require(_number(now) and (previous is None or now >= previous), "clock regression")
        previous = now
        _require(now < timing.deadline_at - timing.dispatch_reserve_s, "deadline")
        return now

    def check_inputs() -> None:
        if current_inputs is None:
            raise ValueError("missing input fence")
        latest = current_inputs()
        _require(type(latest) is tuple and len(latest) == 2
                 and latest == (state, evaluation), "planning inputs changed")

    try:
        _require(_number(timing.deadline_at)
                 and all(_number(x) for x in (
                     timing.dispatch_reserve_s, timing.max_age_s, timing.max_sample_width_s,
                 )), "invalid timing")
        started = checked_clock()
        _validate_state(state, expected_identity, timing, started)
        _validate_evaluation(state, evaluation)
        check_inputs()
        plans = tuple(Plan(prefix, evaluation.continuation_id)
                      for length in (1, 2) for prefix in product(CAPS, repeat=length))
        scores = []
        for plan in plans:
            now = checked_clock()
            _validate_state(state, expected_identity, timing, now)
            now = checked_clock()
            _require(now - state.sampled_at <= timing.max_age_s, "stale state")
            prediction = model.predict(
                state, plan, evaluation, timing.deadline_at - timing.dispatch_reserve_s
            )
            checked_clock()
            _require(prediction is not None, "unsupported state/plan/continuation")
            scores.append(_score(state, plan, evaluation, prediction))
        one = _select(tuple(scores[:2]), state.applied_cap)
        two = _select(tuple(scores[2:]), state.applied_cap)
        gain = (two.best.lower_good - one.best.upper_good,
                two.best.upper_good - one.best.lower_good)
        chosen = one
        reason = "strong One-move retained"
        same_first = two.best.plan.prefix[0] == one.best.plan.prefix[0]
        if not same_first:
            if gain[0] > 0 and two.first_action_resolved:
                chosen, reason = two, "two-move shadow advantage"
            else:
                reason = "two-move advantage unresolved; retain strong One-move"
        finished = checked_clock()
        _validate_state(state, expected_identity, timing, finished)
        check_inputs()
        finished = checked_clock()
        _require(finished - state.sampled_at <= timing.max_age_s, "stale state")
        if not chosen.first_action_resolved:
            fallback_reason = ("same first action; strong One-move unresolved"
                               if same_first and two.first_action_resolved
                               else "first-action uncertainty")
            return Decision("fallback", fallback_reason, one_move=one,
                            two_move=two, scores=tuple(scores), gain_interval=gain,
                            elapsed_s=finished - started)
        return Decision("shadow", reason, chosen.best.plan.prefix[0], one, two,
                        tuple(scores), gain, finished - started)
    except Exception as error:
        elapsed = None if started is None or previous is None else previous - started
        return Decision("fallback", f"{type(error).__name__}: {error}", elapsed_s=elapsed)
