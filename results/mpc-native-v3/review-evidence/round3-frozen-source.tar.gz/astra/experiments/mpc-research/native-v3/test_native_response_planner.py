"""Contract witnesses only; the stub below is not a native fitted response model."""

from dataclasses import replace
import copy
import hashlib
import importlib.util
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import native_response_planner as planner
from native_response_planner import (
    Decision, Evaluation, Identity, Outcome, Prediction, RequestState, Scenario,
    State, Timing, plan_response, transition_costs,
)


IDENTITY = Identity("test-deployment", "test-epoch", "test-clock", "test-cost")


def state():
    return State(
        "test-state", IDENTITY, 10.0, 9.9, 9.95, .01, 16, 4, False, 8.0,
        (RequestState("old", 8.0, 4096, 128, 2, "decode", .2),),
        0, 1, 0, .1, "test-received-history",
    )


def evaluation():
    return Evaluation(
        "test-model", "test-support", "test-future-law", "test-uncertainty",
        "test-cohort", "development-selected-reactive", "test-development-receipt",
        "test-tail-rule", 30.0, ("old",), (Scenario("joint-test-draw", 1.0, 9),),
    )


class StubModel:
    def __init__(self):
        self.calls = []
        self.values = {(16,): 4, (32,): 2, (16, 16): 3,
                       (16, 32): 4, (32, 16): 8, (32, 32): 5}
        self.transform = lambda prediction: prediction

    def predict(self, state, plan, evaluation, deadline_at):
        self.calls.append((state, plan, evaluation, deadline_at))
        outcome = Outcome(evaluation.scenarios[0].scenario_id,
                          self.values[plan.prefix], 0, 0.0, ((), ("old",), ("old",)))
        return self.transform(Prediction(state.state_id, plan, evaluation,
                                         (outcome,), 0.0, 0.0))


def agreement_model():
    """Gemini's R2 numeric witness through the real injected-response interface."""
    model = StubModel()
    bands = {
        (16,): (9, 5, 2.5), (32,): (8, 5, 2.5),
        (16, 16): (10, 2, 1), (16, 32): (15, 5, 2.5),
        (32, 16): (5, 2, 1), (32, 32): (6, 2, 1),
    }

    def prediction(p):
        good, unresolved, expected_tail = bands[p.plan.prefix]
        return replace(p, outcomes=(Outcome(
            "joint-test-draw", good, unresolved, expected_tail, ((), ("old",), ("old",)),
        ),))

    model.transform = prediction
    law = replace(evaluation(), scenarios=(Scenario("joint-test-draw", 1.0, 19),))
    return model, law


class PlannerTests(unittest.TestCase):
    def run_plan(self, model=None, **kwargs):
        snapshot = kwargs.pop("state", state())
        law = kwargs.pop("evaluation", evaluation())
        return plan_response(
            snapshot, law, model or StubModel(),
            expected_identity=kwargs.pop("expected_identity", IDENTITY),
            timing=kwargs.pop("timing", Timing("test-clock", 10.1, .02, .5, .05)),
            clock=kwargs.pop("clock", lambda: 10.0),
            current_inputs=kwargs.pop("current_inputs", lambda: (snapshot, law)), **kwargs,
        )

    def test_complete_bounded_search_uses_identical_contract_and_strong_continuation(self):
        model = StubModel()
        result = self.run_plan(model)
        self.assertEqual(result.status, "shadow")
        self.assertEqual(result.shadow_cap, 32)
        self.assertEqual(result.one_move.best.plan.prefix, (16,))
        self.assertEqual(result.two_move.best.plan.prefix, (32, 16))
        self.assertEqual(result.gain_interval, (4.0, 4.0))
        self.assertEqual([call[1].prefix for call in model.calls],
                         [(16,), (32,), (16, 16), (16, 32), (32, 16), (32, 32)])
        self.assertTrue(all(call[2] is model.calls[0][2] for call in model.calls))
        self.assertTrue(all(call[1].continuation_id == evaluation().continuation_id
                            and call[3] == 10.08 for call in model.calls))
        self.assertFalse(result.active_permit)

    def test_no_default_model_or_permit_even_with_declared_receipts(self):
        self.assertEqual(self.run_plan(object()).status, "fallback")
        self.assertFalse(Decision("shadow", "not evidence", 32).active_permit)

    def test_same_first_action_retains_one_move_even_with_larger_open_loop_score(self):
        model = StubModel()
        model.values[(16, 32)] = 9
        result = self.run_plan(model)
        self.assertEqual(result.shadow_cap, 16)
        self.assertEqual(result.reason, "strong One-move retained")

    def test_uncertainty_overlap_does_not_authorize_point_estimate_winner(self):
        model = StubModel()
        model.transform = lambda p: replace(p, error_below=5, error_above=5)
        result = self.run_plan(model)
        self.assertEqual(result.status, "fallback")
        self.assertIsNone(result.shadow_cap)
        self.assertEqual(result.two_move.best.mean_good, 8)

    def test_tail_expectation_not_settled_count_ranks_but_bounds_prevent_false_certainty(self):
        model = StubModel()

        def tail(p):
            if p.plan.prefix == (32,):
                return replace(p, outcomes=(Outcome("joint-test-draw", 1, 8, 8,
                                                    ((), ("old",), ("old",))),))
            return p

        model.transform = tail
        result = self.run_plan(model)
        self.assertEqual(result.one_move.best.plan.prefix, (32,))
        self.assertEqual(result.one_move.best.mean_good, 9)
        self.assertEqual((result.one_move.best.tail_lower, result.one_move.best.tail_upper),
                         (1, 9))
        self.assertEqual(result.status, "fallback")

    def test_missing_one_move_continuation_support_aborts_not_weakens_baseline(self):
        model = StubModel()
        model.transform = lambda p: None if len(p.plan.prefix) == 1 else p
        result = self.run_plan(model)
        self.assertEqual(result.status, "fallback")
        self.assertIn("unsupported", result.reason)
        self.assertEqual(len(model.calls), 1)

    def test_unknown_or_missing_last_candidate_aborts_partial_optimization(self):
        model = StubModel()
        model.transform = lambda p: None if p.plan.prefix == (32, 32) else p
        result = self.run_plan(model)
        self.assertIsNone(result.shadow_cap)
        self.assertEqual(result.scores, ())
        self.assertEqual(len(model.calls), 6)

    def test_state_fences_fail_before_model(self):
        changes = (
            {"identity": replace(IDENTITY, epoch="other")},
            {"identity": replace(IDENTITY, cost_model="other")},
            {"sampled_at": 9.0}, {"received_at": 10.01}, {"origin": float("nan")},
            {"sample_width_s": .06}, {"reserved_cost": 4.0}, {"pending_command": True},
            {"applied_cap": 24}, {"kv_usage": float("inf")}, {"cap_version": True},
            {"requests": (replace(state().requests[0], stage="unknown"),)},
            {"requests": (replace(state().requests[0], original_cost=-1),)},
            {"requests": (state().requests[0], state().requests[0])},
        )
        for change in changes:
            with self.subTest(change=change):
                model = StubModel()
                self.assertEqual(self.run_plan(model, state=replace(state(), **change)).status,
                                 "fallback")
                self.assertEqual(model.calls, [])

    def test_clock_domain_invalid_deadline_and_regression(self):
        for timing in (Timing("other", 10.1, .02, .5, .05),
                       Timing("test-clock", float("nan"), .02, .5, .05),
                       Timing("test-clock", 10.02, .02, .5, .05)):
            self.assertEqual(self.run_plan(timing=timing).status, "fallback")
        ticks = iter((10.0, 9.99))
        self.assertIn("clock regression", self.run_plan(clock=lambda: next(ticks)).reason)

    def test_deadline_includes_callback_and_reserves_dispatch_time(self):
        ticks = iter((10.0, 10.0, 10.0, 10.081))
        model = StubModel()
        result = self.run_plan(model, clock=lambda: next(ticks))
        self.assertEqual(result.status, "fallback")
        self.assertIn("deadline", result.reason)
        self.assertEqual(len(model.calls), 1)
        self.assertGreater(result.elapsed_s, .08)

    def test_state_that_expires_during_evaluation_aborts(self):
        ticks = iter((10.0, 10.0, 10.0, 10.01, 10.02))
        result = self.run_plan(clock=lambda: next(ticks),
                               timing=Timing("test-clock", 10.1, .02, .11, .05))
        self.assertIn("stale", result.reason)

    def test_prediction_contract_pairing_accounting_and_release_validation(self):
        transformations = (
            lambda p: replace(p, state_id="future-state"),
            lambda p: replace(p, evaluation=replace(p.evaluation, horizon_s=1)),
            lambda p: replace(p, plan=replace(p.plan, continuation_id="weak-fixed16")),
            lambda p: replace(p, error_above=float("nan")),
            lambda p: replace(p, outcomes=p.outcomes * 2),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0], scenario_id="other"),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0], settled_good=11),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0], settled_good=True),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0], expected_tail_good=1),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0],
                                                   released_origin_ids=(("old",), (), ("old",))),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0],
                                                   released_origin_ids=((), (), ("new",))),)),
            lambda p: replace(p, outcomes=(replace(p.outcomes[0],
                                                   released_origin_ids=((), (), ("old", "old"))),)),
        )
        for transform in transformations:
            with self.subTest(transform=transform):
                model = StubModel()
                model.transform = transform
                self.assertEqual(self.run_plan(model).status, "fallback")

    def test_joint_weighting_and_tail_model_uncertainty_remain_distinct(self):
        model = StubModel()
        law = replace(evaluation(), scenarios=(Scenario("a", .25, 9), Scenario("b", .75, 3)))

        def joint(p):
            return replace(p, outcomes=(
                Outcome("a", 6, 2, 1, ((), ("old",), ("old",))),
                Outcome("b", 1, 1, .5, ((), (), ("old",))),
            ), error_below=.2, error_above=.4)

        model.transform = joint
        score = self.run_plan(model, evaluation=law).scores[0]
        self.assertEqual(score.mean_good, 2.875)
        self.assertEqual((score.tail_lower, score.tail_upper), (2.25, 3.5))
        self.assertEqual((score.lower_good, score.upper_good), (2.05, 3.9))
        self.assertEqual(score.released_origin_cost, (0, 2, 8))

    def test_invalid_or_unbounded_evaluation_is_rejected_without_predicting(self):
        for change in (
            {"horizon_s": 1.0}, {"slot_s": 2.0}, {"slot_s": True},
            {"tail_s": float("nan")},
            {"continuation_development_receipt": ""},
            {"origin_offered_ids": ()}, {"origin_offered_ids": ("old", "old")},
            {"scenarios": ()}, {"scenarios": evaluation().scenarios * 129},
            {"scenarios": (Scenario("x", .9, 3),)},
            {"scenarios": (Scenario("x", 1, -1),)},
            {"scenarios": (Scenario("x", .5, 1), Scenario("x", .5, 1))},
        ):
            model = StubModel()
            self.assertEqual(self.run_plan(model, evaluation=replace(evaluation(), **change)).status,
                             "fallback")
            self.assertEqual(model.calls, [])

    def test_unadmitted_old_offers_stay_in_cohort_without_fake_reserved_work(self):
        model = StubModel()
        model.values = {prefix: 11 for prefix in model.values}
        result = self.run_plan(
            model, evaluation=replace(evaluation(), origin_offered_ids=("old", "not-admitted"))
        )
        self.assertEqual(len(result.scores), 6)
        self.assertEqual(result.scores[0].mean_good, 11)
        self.assertEqual(result.scores[0].released_origin_cost[-1], 8)

    def test_model_exception_is_no_command_not_fixed16_actuation(self):
        model = StubModel()

        def fail(_):
            raise RuntimeError("model unavailable")

        model.transform = fail
        result = self.run_plan(model)
        self.assertIn("model unavailable", result.reason)
        self.assertIsNone(result.shadow_cap)

    def test_validation_time_cannot_start_late_model_or_return_late_recommendation(self):
        for slow_call, expected_calls in ((2, 0), (8, 6)):
            with self.subTest(slow_call=slow_call):
                now, calls = [10.0], [0]
                validate = planner._validate_state
                model = StubModel()

                def slow_validation(*args):
                    validate(*args)
                    calls[0] += 1
                    if calls[0] == slow_call:
                        now[0] += .09

                with patch.object(planner, "_validate_state", slow_validation):
                    result = self.run_plan(model, clock=lambda: now[0])
                self.assertEqual(result.status, "fallback")
                self.assertIn("deadline", result.reason)
                self.assertIsNone(result.shadow_cap)
                self.assertEqual(len(model.calls), expected_calls)

    def test_final_validation_time_is_included_in_state_freshness(self):
        now, calls = [10.0], [0]
        validate = planner._validate_state

        def slow_validation(*args):
            validate(*args)
            calls[0] += 1
            if calls[0] == 8:
                now[0] += .02

        with patch.object(planner, "_validate_state", slow_validation):
            result = self.run_plan(clock=lambda: now[0],
                                   timing=Timing("test-clock", 10.1, .02, .11, .05))
        self.assertEqual(result.status, "fallback")
        self.assertIn("stale", result.reason)

    def test_native_counts_and_stage_progress_must_reconcile_before_prediction(self):
        changes = (
            {"native_running": 0}, {"native_running": 2}, {"native_waiting": 1},
            {"requests": (replace(state().requests[0], observed_output_tokens=0),)},
            {"requests": (replace(state().requests[0], stage="prefill"),)},
            {"requests": (replace(state().requests[0], stage="awaiting"),),
             "native_running": 0, "native_waiting": 1},
            {"requests": (replace(state().requests[0], stage="release_pending"),)},
            {"requests": (), "reserved_cost": 0},
        )
        for change in changes:
            with self.subTest(change=change):
                model = StubModel()
                result = self.run_plan(model, state=replace(state(), **change))
                self.assertEqual(result.status, "fallback")
                self.assertIn("mismatch", result.reason)
                self.assertEqual(model.calls, [])

    def test_known_prefill_waiting_and_release_pending_do_not_evict_cost(self):
        for stage, output, running, waiting in (
            ("prefill", 0, 1, 0), ("awaiting", 0, 0, 1), ("release_pending", 2, 0, 0),
        ):
            with self.subTest(stage=stage):
                snapshot = replace(
                    state(), requests=(replace(state().requests[0], stage=stage,
                                               observed_output_tokens=output),),
                    native_running=running, native_waiting=waiting, pending_batches=1,
                )
                result = self.run_plan(state=snapshot)
                self.assertEqual(result.status, "shadow")
                self.assertEqual(snapshot.reserved_cost, 8)
                self.assertFalse(result.active_permit)

    def test_same_first_resolved_two_move_deliberately_does_not_override_unresolved_one(self):
        for applied_cap in (16, 32):
            with self.subTest(applied_cap=applied_cap):
                model, law = agreement_model()
                result = self.run_plan(model, evaluation=law,
                                       state=replace(state(), applied_cap=applied_cap))
                self.assertEqual(result.one_move.best.plan.prefix, (16,))
                self.assertEqual(result.two_move.best.plan.prefix, (16, 32))
                self.assertFalse(result.one_move.first_action_resolved)
                self.assertTrue(result.two_move.first_action_resolved)
                self.assertEqual(result.gain_interval[0], 1)
                self.assertEqual(result.status, "fallback")
                self.assertEqual(result.reason, "same first action; strong One-move unresolved")
                self.assertIsNone(result.shadow_cap)

    def test_different_first_resolved_two_move_can_override_unresolved_one(self):
        model, law = agreement_model()
        original = model.transform

        def transform(p):
            if len(p.plan.prefix) == 1:
                return original(p)
            lookup = (48 - p.plan.prefix[0], p.plan.prefix[1])
            swapped = original(replace(p, plan=replace(p.plan, prefix=lookup)))
            return replace(swapped, plan=p.plan)

        model.transform = transform
        result = self.run_plan(model, evaluation=law)
        self.assertFalse(result.one_move.first_action_resolved)
        self.assertTrue(result.two_move.first_action_resolved)
        self.assertEqual(result.shadow_cap, 32)
        self.assertEqual(result.reason, "two-move shadow advantage")

    def test_changed_input_bundle_at_entry_stops_before_model(self):
        model = StubModel()
        changed = replace(state(), pending_command=True)
        result = self.run_plan(model, current_inputs=lambda: (changed, evaluation()))
        self.assertEqual(result.status, "fallback")
        self.assertIn("planning inputs changed", result.reason)
        self.assertEqual(model.calls, [])

    def test_last_input_fence_detects_epoch_version_history_and_model_changes(self):
        changes = (
            (replace(state(), identity=replace(IDENTITY, epoch="next-gateway-run")), evaluation()),
            (replace(state(), cap_version=5), evaluation()),
            (replace(state(), history_id="new-received-prefix"), evaluation()),
            (replace(state(), received_at=9.96), evaluation()),
            (state(), replace(evaluation(), model_id="new-model")),
            (state(), replace(evaluation(), uncertainty_id="new-uncertainty")),
        )
        for changed in changes:
            with self.subTest(changed=changed):
                model = StubModel()
                latest = [(state(), evaluation())]

                def advance(p):
                    latest[0] = changed
                    return p

                model.transform = advance
                result = self.run_plan(model, current_inputs=lambda: latest[0])
                self.assertEqual(result.status, "fallback")
                self.assertIn("planning inputs changed", result.reason)
                self.assertIsNone(result.shadow_cap)
                self.assertFalse(result.active_permit)

    def test_input_fence_time_is_included_in_deadline_and_freshness(self):
        for delay, age_limit, reason in ((.09, .5, "deadline"), (.02, .11, "stale")):
            with self.subTest(reason=reason):
                now, calls = [10.0], [0]

                def current():
                    calls[0] += 1
                    if calls[0] == 2:
                        now[0] += delay
                    return state(), evaluation()

                result = self.run_plan(current_inputs=current, clock=lambda: now[0],
                                       timing=Timing("test-clock", 10.1, .02, age_limit, .05))
                self.assertEqual(result.status, "fallback")
                self.assertIn(reason, result.reason)

    def test_missing_malformed_or_failed_input_fence_is_not_authority(self):
        def failed():
            raise RuntimeError("publisher unavailable")

        for callback in (None, lambda: (state(),), lambda: [state(), evaluation()], failed):
            result = self.run_plan(current_inputs=callback)
            self.assertEqual(result.status, "fallback")
            self.assertFalse(result.active_permit)
        model = StubModel()
        result = plan_response(
            state(), evaluation(), model, expected_identity=IDENTITY,
            timing=Timing("test-clock", 10.1, .02, .5, .05), clock=lambda: 10,
        )
        self.assertIn("missing input fence", result.reason)
        self.assertEqual(model.calls, [])


class LedgerTests(unittest.TestCase):
    def test_cap_drop_preserves_reservations_and_releases_original_whole_cost(self):
        self.assertEqual(transition_costs((("a", 20), ("b", 12)),
                                         (("release", "b", 12, 16),)), (("a", 20),))
        self.assertEqual(transition_costs((("a", 20), ("b", 12)),
                                         (("release", "a", 20, 16),
                                          ("admit", "c", 4, 16))), (("b", 12), ("c", 4)))

    def test_cap_is_cost_not_count_and_events_are_ordered(self):
        with self.assertRaisesRegex(ValueError, "exceeds cap"):
            transition_costs((("a", 12),), (("admit", "b", 8, 16),))
        with self.assertRaisesRegex(ValueError, "exceeds cap"):
            transition_costs((("a", 16),), (("admit", "b", 8, 16),
                                           ("release", "a", 16, 16)))
        self.assertEqual(transition_costs((("a", 16),), (("release", "a", 16, 16),
                                                        ("admit", "b", 8, 16))),
                         (("b", 8),))

    def test_duplicate_release_recost_and_reused_id_rejected(self):
        for events in (
            (("release", "a", 7, 16),),
            (("release", "a", 8, 16), ("release", "a", 8, 16)),
            (("release", "a", 8, 16), ("admit", "a", 8, 16)),
        ):
            with self.assertRaises(ValueError):
                transition_costs((("a", 8),), events)

    def test_lowered_cap_state_not_rejected_as_overshoot(self):
        snapshot = replace(state(), reserved_cost=24,
                           requests=(replace(state().requests[0], original_cost=24),))
        model = StubModel()
        result = plan_response(snapshot, evaluation(), model, expected_identity=IDENTITY,
                               timing=Timing("test-clock", 10.1, .02, .5, .05),
                               clock=lambda: 10.0, current_inputs=lambda: (snapshot, evaluation()))
        self.assertEqual(result.status, "shadow")


FROZEN_SOURCES = {
    "opus": ("opus/experiments/mpc-research/native-v3/native_release_model.py",
             "86f45ab851a446b4a903c8e5f0991acb198ecc4fc5d9d0d9bd0d05e38e77411b"),
    "gemini": ("gemini/native_campaign_protocol.py",
               "087c68868f48f6bac9d1ac829c9dc3cb8b749f1c40b87f6d5364bb2d2f4bad79"),
    "sol": ("sol/experiments/mpc-research/native-v3/native_experiment_audit.py",
            "6abb94a4fbc1f3e238cd2d4687e996829304afe669b38efba14f2ca29074a554"),
    "astra": ("astra/experiments/mpc-research/native-v3/native_response_planner.py",
              "e19db180e1fb06c6c34ff21e9b76131e85749edc7f403d4aa65acf366b7a3326"),
}

ROUND_TWO_SOURCES = {
    name: (f"{name}/experiments/mpc-research/native-v3/{filename}", digest)
    for name, filename, digest in (
        ("opus", "native_release_model.py",
         "6e277d09c2ccfded2bb11e31164f97515c4bbdcc838f3df3f5a917864b297270"),
        ("gemini", "native_campaign_protocol.py",
         "de51b0af0fd1d02db3c960162a82693df3620751944373c2e697b913c55ca38e"),
        ("sol", "native_experiment_audit.py",
         "44423a5d76782da9d9118ddacbdb94e82d6963b70a65dfdf95d4e82d5487251d"),
        ("astra", "native_response_planner.py",
         "61fed73aa44057dbfd15b4f337e67caffa29695d9aa80052b20f94e0e3e00b23"),
    )
}


def load_frozen(name, round_number=1):
    sources = FROZEN_SOURCES if round_number == 1 else ROUND_TWO_SOURCES
    relative, expected = sources[name]
    path = Path(os.environ[f"NV3_R{round_number}_FREEZE"]) / relative
    source = path.read_bytes()
    if hashlib.sha256(source).hexdigest() != expected:
        raise ValueError(f"{name} R{round_number} source hash differs")
    spec = importlib.util.spec_from_file_location(f"nv3_r{round_number}_{name}", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    # Compile the verified bytes, not a second read or a potentially stale pyc.
    exec(compile(source, str(path), "exec"), module.__dict__)
    return module


def opus_episode():
    rid = "1" * 32
    mark = dict(request_id=rid, cost=1.0, prompt_tokens=128, max_tokens=8,
                admitted_at=0.0, first_at=None)
    return dict(
        episode_id="witness", seed_block=170001, partition="train",
        run_id="run", clock_domain="host",
        observations=[
            dict(gateway=dict(run_id="run", clock_domain="host", complete=True,
                              sequence=1, sampled_at=0.25, budget=16, requests=[mark]),
                 received_at=.255, native_received_at=.27,
                 native=dict(schema="pr33-native-read-only-v1", complete=True,
                             sampled_at=.26, running=1, waiting=0,
                             clock_domain="host", run_id="run",
                             requests=[dict(request_id=f"chatcmpl-{rid}-1234abcd",
                                            output_tokens=0)])),
            dict(gateway=dict(run_id="run", clock_domain="host", complete=True,
                              sequence=2, sampled_at=2.0, budget=16, requests=[]),
                 received_at=2.01, native=None),
        ],
        ledger=[dict(event="mpc_ledger", sequence=2, run_id="run", clock_domain="host",
                     complete=True, effective_at=.5, reserved_cost=0)],
    )


def sol_blocks(n=2):
    blocks = []
    for i in range(n):
        arms = {}
        for side in ("left", "right"):
            rid = hashlib.sha256(f"{i}-{side}".encode()).hexdigest()[:32]
            offer = dict(request_id=rid, logical_id=f"offer-{i}", offset_s=0,
                         prompt_tokens=128, max_tokens=4,
                         prompt_sha256=hashlib.sha256(f"prompt-{i}".encode()).hexdigest())
            row = dict(request_id=rid, response_request_id=rid, clock_domain="client",
                       requested_max_tokens=4, scheduled_at=10, sent_at=10.01,
                       first_content_at=10.1, last_content_at=10.11, terminal_at=10.12,
                       status="complete", stream_done=True, stream_error=False,
                       http_status=200, finish_reason="stop", native_eos_verified=True,
                       usage=dict(prompt_tokens=128, completion_tokens=2))
            if side == "left":
                row.update(status="rejected", http_status=503, first_content_at=None,
                           last_content_at=None, admission_rejection=True, usage=None)
            arms[side] = dict(offers=[offer], rows=[row], origin=10, window_s=1,
                              clock_domain="client")
        blocks.append(dict(seed=170010 + i, block_id=f"b{i}", randomization_unit=f"u{i}",
                           independent_sampling=True, pair_order_randomized=True,
                           pair_order="left-first",
                           randomization_scheme="independent-fair-pair-order",
                           frozen_comparison_sha256="a" * 64, **arms))
    return blocks


@unittest.skipUnless(os.environ.get("NV3_R1_FREEZE"), "set NV3_R1_FREEZE for pinned R1 review")
class FrozenRoundOneWitnesses(unittest.TestCase):
    """Expected failures of frozen contracts, not native data or fixed-peer tests."""

    @classmethod
    def setUpClass(cls):
        cls.opus, cls.gemini, cls.sol, cls.astra = (
            load_frozen(name) for name in ("opus", "gemini", "sol", "astra")
        )

    def test_opus_cross_clock_and_epoch_native_frame_is_accepted(self):
        episode = opus_episode()
        baseline = self.opus.build_origins(episode)[0]
        episode["observations"][0]["native"].update(clock_domain="other-clock", run_id="old-run")
        self.assertEqual(self.opus.build_origins(episode)[0], baseline)

    def test_opus_release_before_last_live_snapshot_is_accepted_as_exact_truth(self):
        episode = opus_episode()
        episode["ledger"][0]["effective_at"] = .2
        row = self.opus.build_dataset([episode])[0]
        self.assertLess(.2, row["sampled_at"])
        self.assertEqual(row["truth"][1.0], (1.0, 1.0))

    def test_opus_different_cap_sequences_have_identical_predictor_features(self):
        episode = opus_episode()
        t0 = .27
        episode["cap_plan"] = [(t0, 16), (t0 + 1, 16), (t0 + 2, 32), (t0 + 3, 16)]
        left = self.opus.build_origins(episode)[0][0]
        episode["cap_plan"] = [(t0, 16), (t0 + 1, 32), (t0 + 2, 16), (t0 + 3, 16)]
        right = self.opus.build_origins(episode)[0][0]
        for h in self.opus.HORIZONS:
            for a, b in zip(self.opus.mark_features(left, "1" * 32, h),
                            self.opus.mark_features(right, "1" * 32, h)):
                self.assertAlmostEqual(a, b)

    def test_opus_same_block_repetition_shrinks_claimed_block_calibration(self):
        zero = dict(partition="calibration", seed_block=170002, reserved=1,
                    truth={h: (0, 0) for h in self.opus.HORIZONS})
        one = dict(partition="calibration", seed_block=170003, reserved=1,
                   truth={h: (1, 1) for h in self.opus.HORIZONS})
        fixed_prediction = ({"batch_aware": {h: 0 for h in self.opus.HORIZONS}}, [])
        with patch.object(self.opus, "predict", return_value=fixed_prediction):
            before = self.opus.calibrate({}, [zero, one])
            repeated = self.opus.calibrate({}, [zero] * 100 + [one])
        self.assertEqual(before["blocks"], repeated["blocks"])
        self.assertEqual(before["bands"][1.0]["upper"], 1)
        self.assertEqual(repeated["bands"][1.0]["upper"], 0)

    def test_opus_tail_is_explained_without_placeholder_or_cuda_completion_evidence(self):
        steps = [dict(step_id=f"s{i}", start=i / 100, end=.02 + i / 100,
                      work=[dict(request_id="r", position=i, tokens=1)]) for i in range(2)]
        workers = [dict(step_id=f"s{i}", executed_positions={"r": i},
                        executed_counts={"r": 1}) for i in range(2)]
        result = self.opus.forward_work_accounting(
            dict(input_tokens=1, output_tokens=1, finish_reason="stop", finished=.1),
            steps, workers, request_id="r",
        )
        self.assertTrue(result["tail_accounted"])
        self.assertFalse(result["legacy_strict_audit_valid"])

    def test_opus_ood_envelope_does_not_cover_used_age_and_history_features(self):
        origin = self.opus.build_origins(opus_episode())[0][0]
        support = self.opus.support_envelope([origin])
        shifted = copy.deepcopy(origin)
        shifted["cohort"]["1" * 32]["admitted_at"] = -1000
        shifted["history_rate"] = 1e6
        self.assertEqual(self.opus.ood_reasons(shifted, support), [])
        self.assertNotEqual(self.opus.mark_features(origin, "1" * 32, 1),
                            self.opus.mark_features(shifted, "1" * 32, 1))

    def test_opus_horizon_specific_censor_exclusion_makes_cumulative_baseline_decrease(self):
        partial = opus_episode()
        early = partial["observations"][0]
        early["gateway"]["requests"][0]["cost"] = 9
        pending = dict(early["gateway"]["requests"][0], request_id="2" * 32, cost=1)
        early["gateway"]["requests"].append(pending)
        early["native"]["requests"].append(
            dict(request_id=f"chatcmpl-{'2' * 32}-1234abcd", output_tokens=0)
        )
        early["native"]["running"] = 2
        partial["ledger"][0]["reserved_cost"] = 1
        partial["observations"][1]["gateway"]["requests"] = [pending]
        slow = opus_episode()
        slow.update(episode_id="slow", seed_block=170002, ledger=[])
        slow["observations"][0]["gateway"]["requests"][0]["cost"] = 10
        slow["observations"][1].update(received_at=6.01)
        slow["observations"][1]["gateway"].update(
            sequence=1, sampled_at=6,
            requests=copy.deepcopy(slow["observations"][0]["gateway"]["requests"]),
        )
        rows = self.opus.build_dataset([partial, slow])
        self.assertEqual(rows[0]["truth"], {1.0: (9.0, 9.0), 3.0: (9.0, 10.0),
                                            5.0: (9.0, 10.0)})
        params = self.opus.fit(rows)
        pred, reasons = self.opus.predict(params, rows[0])
        self.assertEqual(reasons, [])
        self.assertEqual(pred["train_fraction"], {1.0: 4.5, 3.0: 0.0, 5.0: 0.0})

    def test_gemini_accounting_adds_a_position_and_concurrency_does_not_falsify_serial(self):
        accounting = self.gemini.compute_work_accounting()
        self.assertEqual(accounting.physical_executed_positions, 4129)
        self.assertEqual(accounting.useful_total_tokens, 4128)
        # Two simultaneous offers on a serial server: demand .4 each, terminal .4/.8.
        result = self.gemini.verify_gpu_elapsed_clock_semantics(.8, .4, 2)
        self.assertTrue(result["serial_service_model_falsified"])

    def test_gemini_zero_offered_duration_satisfies_ten_hour_flag(self):
        protocol = self.gemini.build_native_campaign_protocol(
            offers_duration_s=0, max_drain_duration_s=120
        )
        self.assertTrue(protocol["duration_summary"]["hours_requirement_satisfied"])
        self.assertEqual(sum(e["offers_duration_s"] for e in protocol["episodes"]), 0)
        self.assertTrue(all(not e["actuator_schedule"] for e in protocol["episodes"]))
        self.assertIn("unseen_ood_mix", {e["family"] for e in protocol["episodes"]
                                       if e["split"] == "train"})

    def test_gemini_impossible_good_counts_can_confirm_superiority(self):
        m = self.gemini
        blocks = [m.IndependentSeedBlockOutcome(
            block_id=f"impossible-{i}", seed=170100 + i, workload_family="fixture",
            split="train", duration_s=1, control_decisions=1, offered_requests=1,
            policy_a_good_completions=0, policy_a_rejections=0, policy_a_solver_overruns=0,
            policy_b_good_completions=10 + i, policy_b_rejections=0, policy_b_solver_overruns=0,
        ) for i in range(6)]
        result = m.SuperiorityEvaluator().evaluate(blocks)
        self.assertEqual(result["verdict"], "CONFIRMED_SUPERIOR")
        self.assertTrue(result["statistically_significant"])

    def test_gemini_duplicate_admission_leaves_ghost_reservation(self):
        m = self.gemini
        snapshot = m.ObservableBatchState(32)
        record = m.MarkedReservationRecord("same", 8, 0, 128, 8)
        self.assertTrue(snapshot.admit(record))
        self.assertTrue(snapshot.admit(record))
        snapshot.release("same", 1)
        self.assertEqual(snapshot.active_reservations, {})
        self.assertEqual(snapshot.reserved_cost, 8)

    def test_gemini_boolean_output_and_post_after_terminal_are_scored_good(self):
        m = self.gemini
        outcome = m.RequestOutcome("r", 128, True, 0, 3, .1, .2, 0, "stop", True)
        self.assertTrue(m.validate_request_outcome(outcome)["is_good"])

    def test_sol_no_first_token_after_ttft_deadline_retains_impossible_upper(self):
        arm = sol_blocks()[0]["right"]
        arm["rows"][0].update(status="censored", first_content_at=None, last_content_at=None,
                              terminal_at=None, observed_until=11, stream_done=False, usage=None)
        result = self.sol.audit_arm(**arm)
        self.assertEqual((result["good_lower"], result["good_upper"]), (0, 1))

    def test_sol_same_frozen_comparison_allows_different_slo_between_blocks(self):
        blocks = sol_blocks()
        for side in ("left", "right"):
            blocks[1][side]["ttft_s"] = .05
        result = self.sol.paired_effect(blocks, bootstrap_samples=20)
        self.assertEqual(result["block_effects_good_per_s"], [1, 0])
        self.assertEqual(result["effect_good_per_s"], .5)

    def test_sol_logical_id_renaming_evades_repeated_tape_guard(self):
        blocks = sol_blocks(6)
        for block in blocks:
            for side in ("left", "right"):
                block[side]["offers"][0]["prompt_sha256"] = "b" * 64
        result = self.sol.paired_effect(blocks, bootstrap_samples=20)
        self.assertEqual(result["exact_two_sided_signflip_p"], .03125)
        self.assertFalse(result["independent_sampling_verified"])
        self.assertFalse(result["native_performance_accepted"])

    def test_astra_r1_can_return_shadow_after_final_validation_crosses_deadline(self):
        now, calls = [10.0], [0]
        validate = self.astra._validate_state

        def slow_validation(*args):
            validate(*args)
            calls[0] += 1
            if calls[0] == 8:
                now[0] += .09

        with patch.object(self.astra, "_validate_state", slow_validation):
            result = self.astra.plan_response(
                state(), evaluation(), StubModel(), expected_identity=IDENTITY,
                timing=Timing("test-clock", 10.1, .02, .5, .05), clock=lambda: now[0],
            )
        self.assertEqual(result.status, "shadow")
        self.assertEqual(result.elapsed_s, 0)
        self.assertGreater(now[0], 10.08)
        self.assertFalse(result.active_permit)


@unittest.skipUnless(os.environ.get("NV3_R2_FREEZE"), "set NV3_R2_FREEZE for pinned R2 review")
class FrozenRoundTwoResponses(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.opus, cls.gemini, cls.sol, cls.astra = (
            load_frozen(name, 2) for name in ("opus", "gemini", "sol", "astra")
        )

    def test_sol_count_stage_counterexample_against_actual_astra_r2(self):
        result = self.astra.plan_response(
            replace(state(), native_running=0), evaluation(), StubModel(),
            expected_identity=IDENTITY, timing=Timing("test-clock", 10.1, .02, .5, .05),
            clock=lambda: 10,
        )
        self.assertEqual(result.status, "shadow")
        self.assertFalse(result.active_permit)

    def test_opus_r2_commit_fence_is_stronger_but_not_full_tail_provenance(self):
        steps = [dict(step_id=f"s{i}", start=i / 100, end=.02,
                      work=[dict(request_id="r", position=i, tokens=1)]) for i in range(2)]
        workers = [dict(step_id=f"s{i}", executed_positions={"r": i},
                        executed_counts={"r": 1}) for i in range(2)]
        request = dict(input_tokens=1, output_tokens=1, finish_reason="stop", finished=.1)
        before = self.opus.forward_work_accounting(request, steps, workers, request_id="r")
        self.assertIn("tail_commit_before_finish", before["problems"])
        steps[-1]["end"] = .2
        after = self.opus.forward_work_accounting(request, steps, workers, request_id="r")
        self.assertTrue(after["tail_accounted"])
        self.assertFalse(after["legacy_strict_audit_valid"])

    def test_gemini_same_first_case_reproduces_on_actual_astra_not_only_copied_logic(self):
        model, law = agreement_model()
        result = self.astra.plan_response(
            state(), law, model, expected_identity=IDENTITY,
            timing=Timing("test-clock", 10.1, .02, .5, .05), clock=lambda: 10,
        )
        self.assertFalse(result.one_move.first_action_resolved)
        self.assertTrue(result.two_move.first_action_resolved)
        self.assertEqual(result.gain_interval[0], 1)
        self.assertIsNone(result.shadow_cap)
        peer = self.gemini.demonstrate_astra_selection_defect()
        self.assertEqual(peer["astra_unfixed_status"], result.status)

    def test_astra_r2_does_not_notice_new_gateway_run_in_same_clock_domain(self):
        latest = [state()]
        model = StubModel()

        def advance(p):
            latest[0] = replace(state(), identity=replace(IDENTITY, epoch="new-gateway-run"))
            return p

        model.transform = advance
        result = self.astra.plan_response(
            state(), evaluation(), model, expected_identity=IDENTITY,
            timing=Timing("test-clock", 10.1, .02, .5, .05), clock=lambda: 10,
        )
        self.assertEqual(latest[0].identity.clock_domain, IDENTITY.clock_domain)
        self.assertNotEqual(latest[0].identity.epoch, IDENTITY.epoch)
        self.assertEqual(result.status, "shadow")

    def test_gemini_tail_claim_ignores_records_and_missing_physical_measurement(self):
        measured = [dict(observer="light", tail_tokens=1) for _ in range(20)]
        off = [dict(observer="off", tail_tokens=None) for _ in range(20)]
        reported = self.gemini.audit_native_qualification_tail_distribution(measured + off)
        contradictory = self.gemini.audit_native_qualification_tail_distribution(
            [dict(observer="light", tail_tokens=0)]
        )
        self.assertEqual(reported, contradictory)
        self.assertTrue(reported["tail_is_stochastic"])
        self.assertEqual(reported["mean_tail_tokens_per_request"], .5)

    def test_gemini_actual_duration_checker_qualifies_nonfinite_duration(self):
        for duration in (float("nan"), float("inf")):
            record = self.gemini.ExperimentDurationAccounting(
                400, 120, 48000, duration, 0, 0, 0,
            )
            self.assertTrue(record.validate_actual_10h_milestone()[0])

    def test_gemini_r2_exact_signflip_still_changes_with_units_but_sol_is_repaired(self):
        normal = self.gemini.robust_paired_permutation_test([1.0] * 4)
        scaled = self.gemini.robust_paired_permutation_test([1e-15] * 4)
        self.assertEqual(normal["p_value"], .125)
        self.assertEqual(scaled["p_value"], 1)
        cases = sol_blocks(4)
        for case in cases:
            case["partition"] = "train"
            for side in ("left", "right"):
                case[side]["window_s"] = 10 ** 15
        self.assertEqual(self.sol.paired_effect(cases, bootstrap_samples=20)
                         ["exact_two_sided_signflip_p"], .125)


if __name__ == "__main__":
    unittest.main()
