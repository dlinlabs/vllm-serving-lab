OWNED FIXED32 INFLIGHT OWNER-ACQUISITION ADAPTER01

Default-off CPU candidate; not an author-executed Native experiment. Development
authority is inputs/inflight-approval01.json. The accepted predecessor remains
immutable/spent: its Native pass had three EMPTY cuts, not inflight coverage.

PROTOCOL.json and all271 inputs were frozen before controls. Prospective managed
payload is ordinary counting, temperature0, streamfalse, cap16. No min_tokens,
ignore_eos or latency guarantee. OFFERS.json and the20ms scheduled
dispatch-attempt trigger are fixed. A scheduling timestamp is not native receipt.
Actual trigger lateness, source time, collector return and terminal HTTP receipt
are retained; no desired-stock polling, delays adjusted from outcomes or resamples.

Explicit source-compatibility amendment: the original frozen NATIVE_PLAN.json
used seed170103, rejected by the unchanged TRAIN-only170001..170012 source guard.
Its11 first-control failures remain. PLAN_AMENDMENT01.json freezes the sole change
to170003 in NATIVE_PLAN.revision01.json BEFORE successor controls; the executable
uses this effective plan. Original plan/protocol/payload/trigger/offers/budgets/
source guards stay untouched. Mayor must review this amendment before execution.

One unchanged source-derived initial closure, one CAS32/version0->1, one cap16
warmup, two serial cap16 managed offers. Source acquisition alone may overlap a
managed transport. Exactly one inflight cut is attempted at its single trigger
if still pending, followed by the existing post-outcome cut. Up to five cuts.
True coverage requires target scheduler/issued stock joined through actual
publication/lifecycle/owner evidence AND collector availability before the
managed terminal receipt. Pending task/intent is insufficient. Early completion,
empty/zero-work/unattributed stock, historical-only overlap and refusals stay
distinct. Both prescribed offers must be covered for component_pass=true.
Engineering completion alone, or offline replay exit0, does not mean coverage.

New private Capture reserves sequence/ID/cap atomically before any await, with
no whole-request lock. Sequences mean reservation order, not completion order.
Reserved/terminal/refused files are exclusive and immutable; cancelled, partial
and unsent evidence remains. HTTP settings are immutable per call and explicit
HTTPX timeouts avoid inheriting the0.2 GET default for managed/warmup requests.
Source sync GET/async flush remain bounded0.2; source age/whole-cut bound0.5.
Source callback futures, managed tasks and both clients have bounded cleanup;
the explicit three-thread executor never uses unbounded asyncio.run shutdown.
Failed cleanup still closes both clients and refuses; known owned parent/PID/
start-tick/pidfd/subreaper supervision remains the ultimate process bound.

Unchanged260/180/20/3/40/17; cleanup7+30+2+1. Final3 includes legacy snapshot,
fixed0.25s/max9 full observations/two empty, retained/fsynced capture, end/ACK.
Preserve all legacy failures, startup samples, ghosts and zero-work routes.
Requested cap48 is not equality with physical issued tokens. No retries,
restores, model/forecast/MPC/action comparison or extra offers.

Route remains Source13-first, prepared-forward/light, copy-ready0 with extension
absent, exact existing phase/input-post. No inherited copy-ready timing claim.
All source/SDK/Source13 and old capsules stay unchanged. SOURCE_DECLARATION01
lists the new private origin names/path and prospective plan-input supply;
source clock/closure/prefix/stock validation assertions are unchanged.
Gateway itself remains the source-pinned exec session leader; parent streaming
redaction readers join before private config deletion. Preserve the hierarchy:
process_clock_provenance resolves its source pin through parents[3].

DEPLOYMENT.json specifies all new paths and the complete deployment/output
contract. Default from the staged directory:
  /workspace/pr32-r23/venv/bin/python -I -B launch01.py

Only after Mayor review, Parent acceptance, a NEW prospective local commit and
the external exclusive GPU lease, create a separate preregistration document
using the intentionally-refusing template. ONCE from the new staged directory:
  /workspace/pr32-r23/venv/bin/python -I -B launch01.py \
    --execute-on-existing-gpu \
    --mayor-preregistration /workspace/pr32-r23/mayor-owner-inflight01-preregistration.json

No old spent main/entry is called. New state/public must not exist. The launcher
also flocks the same shared internal GPU lock; do not hold that same flock in
the invoking shell. No installs/downloads/new rent. Repeat source/SDK/origin/
model/boot/GPU-idle/port guards; old receipts do not prove future composition.
Actual short0700 TMPDIR preflight precedes any service;0600 config is private.

Read export-gate.json FIRST, require safe_to_export=true and no DO_NOT_EXPORT.
Never export private state/config or unsafe output. Safe failures/misses remain
indexed with all raw receipts and offered rows. Missing receipts do not prove
no send. Unjoined helpers prevent success/export/config deletion.

Offline reported-evidence replay:
  python -I -B replay01.py ABSOLUTE_PUBLIC_OUTPUT
Exit0 means consistency, not a new experiment or automatically a coverage pass.
Prior empty evidence only:
  python -I -B replay01.py --prior-accepted-empty
Neither re-proves dead procfs. Retained earlier raw seal is independently checked.

CPU controls, using new exclusive attempt names and both designated Python:
  sh validate.sh ABSOLUTE_PYTHON development UNIQUE_ATTEMPT
Source/protocol freeze precedes each revision's controls. The harness denies
sockets/DNS/native imports/arbitrary processes. Only bounded benign owned test
children are permitted; real asynchronous MockTransport and original source
Gateway/input/phase/capture/closure code exercise the observation boundary.
All failures, exact code snapshots, commands/exits and helper joins remain.

actual_application_at=null. ack.applied_at remains pre-write; interval upper is
not promoted to an exact point. Version1 is not an acquisition/request token.
Point/model/prediction/comparison/MPC gates and Native14FAIL stay unchanged.
Any success proves only two particular usable source-bound target observations,
not prediction, persistent state, future GPU emptiness or general deployability.
