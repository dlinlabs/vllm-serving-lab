"""Synthetic-only source, transport and owned-process controls; no real sockets."""

import asyncio
from copy import deepcopy
from dataclasses import replace
import json
import os
from pathlib import Path
import sys
import time
from types import SimpleNamespace

import httpx
import pytest

import acquire01 as a
import common01 as c
import launch01 as launch
from owned01 import Owned
from synthetic01 import DOMAIN, Fixture as SourceFixture, rewrite, wire as fixture_wire


SECRET = "SYNTHETIC-CREDENTIAL-NOT-REAL-0123456789"


class Fixture(SourceFixture):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.plan = c.load(c.PLAN)

def test_default_off_touches_no_host(capsys, monkeypatch):
    monkeypatch.setattr(c, "remote_only", lambda: pytest.fail("host reached"))
    assert launch.main([]) == 0
    assert json.loads(capsys.readouterr().out)["status"] == "disabled"


def test_live_local_attempt_refuses_before_native_access(monkeypatch):
    monkeypatch.setattr(c, "clock_helpers", lambda: pytest.fail("native helper reached"))
    with pytest.raises(ValueError, match="Mayor_only"):
        launch.main(["--execute-on-existing-gpu"])


@pytest.mark.parametrize("cut", [1, 5, 11, 23, 39])
def test_capture_redaction_across_chunk_boundaries(cut):
    raw = b"before:" + SECRET.encode() + b":after"
    pieces = [raw[:cut], raw[cut:cut + 3], raw[cut + 3:]]
    clean = b"".join(c.redaction().redacted_chunks(pieces, SECRET.encode()))
    assert clean == b"before:[REDACTED_AUTH]:after"


def test_unknown_JSON_or_decoded_credential_refuses_export(tmp_path):
    import base64
    c.write(tmp_path / "receipt.json", dict(response_body_base64=base64.b64encode(SECRET.encode()).decode()))
    assert not c.privacy_scan((tmp_path,), SECRET)
    (tmp_path / "receipt.json").unlink()
    (tmp_path / "partial.json").write_text('{"interrupted":')
    assert not c.privacy_scan((tmp_path,), SECRET)
    assert SECRET not in json.dumps(c.failure(ValueError(SECRET), SECRET))
    with pytest.raises(ValueError, match="privacy_scan_nonempty_key"):
        c.privacy_scan((tmp_path,), "")


@pytest.mark.parametrize("late", [False, True])
def test_source_failure_keeps_safe_index_but_late_output_cannot_pass(tmp_path, monkeypatch, late):
    c.write(tmp_path / "all-offered.json", launch.all_offered(tmp_path, False))
    result = dict(component_pass=False, errors=["source_postflight_refusal"])
    now = [1.0]
    monkeypatch.setattr(launch.time, "monotonic", lambda: now[0])
    original = launch.output_inventory
    def inventory(directory):
        rows = original(directory)
        now[0] = 4.0 if late else 1.1
        return rows
    monkeypatch.setattr(launch, "output_inventory", inventory)
    if late:
        with pytest.raises(ValueError, match="output_absolute_deadline"):
            launch.publish_outputs(tmp_path, result, joined=True, secret="", deadline=3, no_key_created=True)
        assert not (tmp_path / "export-gate.json").exists()
    else:
        assert not launch.publish_outputs(tmp_path, result, joined=True, secret="", deadline=3,
                                          no_key_created=True)
        gate = c.load(tmp_path / "export-gate.json")
        assert gate["safe_to_export"] and not gate["component_pass"]
        assert {r["path"] for r in c.load(tmp_path / "result-index.json")["files"]} == {
            "all-offered.json", "supervision.json"}
def wait_for(predicate, seconds=3):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if predicate():
            return
        time.sleep(0.01)
    raise AssertionError("bounded_fixture_readiness")


def spawn(owned, mode, directory):
    directory.mkdir()
    return owned.spawn([sys.executable, "-B", str(c.HERE / "child_fixture01.py"), mode, str(directory)],
                       directory=directory / "owned", cwd=c.HERE, env=dict(os.environ))


def test_parent_readers_redact_stdout_stderr_and_join(tmp_path):
    owned = Owned(SECRET)
    child = spawn(owned, "echo", tmp_path / "echo")
    other = spawn(owned, "echo", tmp_path / "other-reader")
    try:
        wait_for(lambda: child["process"].poll() is not None)
        wait_for(lambda: other["process"].poll() is not None)
    finally:
        receipt = owned.cleanup(time.monotonic(), allocation=(0.2, 30, 2, 1))
    assert receipt["all_joined"] and receipt["capture_complete"]
    assert b"[REDACTED_AUTH]" in (child["directory"] / "process.log").read_bytes()
    assert b"[REDACTED_AUTH]" in (other["directory"] / "process.log").read_bytes()
    assert c.privacy_scan((tmp_path,), SECRET)
    c.write(tmp_path / "owned-cleanup.json", receipt)


def test_real_owned_exec_keeps_serving_pid_and_source_clock_target(tmp_path):
    owned = Owned(SECRET)
    directory = tmp_path / "exec"
    child = spawn(owned, "exec", directory)
    try:
        wait_for(lambda: (directory / "fake-serving-identity.json").exists())
        actual = c.load(directory / "fake-serving-identity.json")
        assert actual["pid"] == actual["session"] == actual["group"] == child["receipt"]["pid"]
        row = dict(run_id="synthetic-serving", clock_domain=c.domain(), complete=True)
        startup = a.ready_copy(child["receipt"], dict(
            snapshot=row, gateway_run_id=row["run_id"], clock_domain=row["clock_domain"]))
        proof = c.preflight().frozen.module("process_clock_provenance").prove_owned_process_clock(
            startup, role="gateway", acquire=lambda: dict(row, sampled_at=time.monotonic()))
        assert proof["owned_chain"][0]["pid"] == actual["pid"]
        c.write(tmp_path / "synthetic-direct-PID-clock.json", proof)
    finally:
        receipt = owned.cleanup(time.monotonic(), client=child, cancelled=True,
                                allocation=(0.1, 30, 2, 1))
    assert receipt["all_joined"]
    c.write(tmp_path / "owned-cleanup.json", receipt)


def test_unbounded_worker_is_refused_and_owned_process_is_reaped(tmp_path):
    owned = Owned(SECRET)
    directory = tmp_path / "blocked"
    child = spawn(owned, "blocked", directory)
    try:
        wait_for(lambda: (directory / "client-cleanup.json").exists())
        failure = c.load(directory / "client-cleanup.json")
        assert not failure["joined"] and failure["worker_threads_remaining"]
        assert child["process"].poll() is None
    finally:
        receipt = owned.cleanup(time.monotonic(), client=child, cancelled=True,
                                allocation=(0.1, 30, 2, 1))
    assert receipt["all_joined"] and not receipt["surviving_owned_pids"]
    c.write(tmp_path / "owned-cleanup.json", receipt)


def test_normal_five_second_postflight_is_not_cancelled(monkeypatch, tmp_path):
    now = [105.01]
    c.write(tmp_path / "active-start.json", dict(started_at=90.0, deadline=110.0, clock_domain=c.domain()))
    c.write(tmp_path / "protocol-finished.json", dict(
        finished_at=100.0, active_started_at=90.0, component_pass=True, clock_domain=c.domain()))
    monkeypatch.setattr(launch.time, "monotonic", lambda: now[0])
    owned = SimpleNamespace(remember=lambda: None)
    result = launch.monitor(owned, {}, 1, [], directory=tmp_path)
    assert result == dict(anchor=100.0, cancel=False, normal=True)
    assert result["anchor"] + 7 > now[0]


@pytest.mark.parametrize("finished", [500.0, 89.0])
def test_future_or_inconsistent_completion_marker_refused(tmp_path, finished):
    c.write(tmp_path / "protocol-finished.json", dict(finished_at=finished, clock_domain=c.domain()))
    with pytest.raises((ValueError, KeyError)):
        launch.marker(tmp_path, "protocol-finished.json", 90, 100)


def test_missing_client_result_preserves_unknown_offers_not_zero(tmp_path):
    result = launch.all_offered(tmp_path, True)
    assert len(result["offers"]) == 2 and all(r["fate"] == "unobserved" for r in result["offers"])
    assert result["missing_receipt_not_proof_of_no_send"]


@pytest.mark.parametrize("defect", ["wrong_pid", "old_ticks", "wrong_source", "missing"])
def test_loaded_origins_require_actual_core_and_serving_pid(defect):
    policy = c.load(c.HERE / "ORIGIN_POLICY.json")["origins"]
    records = [dict(module=name, **policy[name], valid=True, pid=pid, start_ticks=ticks)
               for pid, ticks, names in ((111, 30, ("phase_observer", "input_post_observer", "queue_observer")),
                                         (200, 40, ("gateway_prefix_bridge", "gateway")))
               for name in names]
    assert c.require_origins(records, native_pid=111, gateway_pid=200,
                             process_reader=lambda pid: 30 if pid == 111 else 40)
    if defect == "wrong_pid":
        records[-1]["pid"] = 201
    elif defect == "old_ticks":
        records[-1]["start_ticks"] = 39
    elif defect == "wrong_source":
        records[-1]["sha256"] = "0" * 64
    else:
        records.pop()
    with pytest.raises(ValueError, match="missing_actual_running_origin"):
        c.require_origins(records, native_pid=111, gateway_pid=200,
                          process_reader=lambda pid: 30 if pid == 111 else 40)


async def fixture_wire_clients(case, directory, *, native_handler=None):
    async def native(request):
        if native_handler:
            return await native_handler(request)
        frame = case.phase.phase_snapshot(case.core)
        frame["base"]["frontend_sampled_at"] = case.clock()
        if case.mutate_native:
            case.mutate_native(frame)
        return httpx.Response(200, json=frame)
    native = httpx.AsyncClient(base_url="http://127.0.0.1:8000", transport=httpx.MockTransport(native))
    gateway = httpx.AsyncClient(base_url="http://127.0.0.1:8080",
                                transport=httpx.ASGITransport(app=case.app))
    return a.Wire(directory, SECRET, DOMAIN, native, gateway, clock=case.clock)


def test_bounded_transport_preserves_cancelled_receipt_and_drains(tmp_path):
    async def scenario():
        async def handler(request):
            await asyncio.sleep(2)
        client = lambda: httpx.AsyncClient(base_url="http://127.0.0.1",
                                           transport=httpx.MockTransport(handler))
        wire = a.Wire(tmp_path, SECRET, c.domain(), client(), client())
        began = time.monotonic()
        try:
            with pytest.raises(TimeoutError):
                await asyncio.to_thread(wire.sync, "native", "/pr33-native/phase-state",
                                         deadline=began + 1, role="blocked-synthetic-http")
            await asyncio.sleep(0.02)
            assert time.monotonic() - began < 0.6
            row = wire.capture.records[0]
            assert row["error_type"] in ("CancelledError", "TimeoutError")
            assert not row["body_complete"]
            assert (tmp_path / "http/000.json").exists()
        finally:
            await wire.close()
    asyncio.run(scenario())


def test_adapter_collects_source_bootstrap_then_preserves_released_ghost_and_zero_route(monkeypatch, tmp_path):
    async def scenario():
        fixture_dir, output = tmp_path / "producer", tmp_path / "wire"
        fixture_dir.mkdir()
        output.mkdir()
        case = Fixture(monkeypatch, fixture_dir)
        await case.initialize()
        wire = await fixture_wire_clients(case, output)
        try:
            closure, report = await a.collect_one(
                wire, case.startup, output, "initial", deadline=case.clock() + 0.5,
                memory=case.public_memory, process=case.native_process,
                telemetry=fixture_dir / "gateway.jsonl")
            assert report["observation"]["actual_application_at"] is None
            assert c.sha(output / report["prefix"]["path"]) == report["prefix"]["sha256"]
            _, nid = await case.issue_then_release_with_physical_stock()
            closure, later = await a.collect_one(
                wire, case.startup, output, "later", deadline=case.clock() + 0.5,
                memory=case.public_memory, process=case.native_process,
                telemetry=fixture_dir / "gateway.jsonl", closure=closure)
            stock = later["observation"]["full_stock"]
            assert stock["base"]["running"] == stock["base"]["waiting"] == 0
            assert stock["base"]["pending_batches"] == 2
            assert stock["queue_oldest_first"][1]["work"] == []
            assert stock["queued_ghost_request_ids"] == [nid]
            assert later["phases"]["released_ghost_ids"] == (nid,)
            case.preserve("source-bootstrap-inputs.json", case.startup)
        finally:
            await wire.close()
    asyncio.run(scenario())


@pytest.mark.parametrize("defect", ["child_pid", "source", "future", "missing_lifecycle", "epoch"])
def test_new_adapter_does_not_weaken_old_cut_refusals(monkeypatch, tmp_path, defect):
    async def scenario():
        case = Fixture(monkeypatch, tmp_path)
        await case.initialize()
        output = tmp_path / "adapter"
        output.mkdir()
        if defect == "child_pid":
            case.gateway_process["pid"] = 201
        else:
            def mutate(frame):
                phase = frame["native_phase"]
                if defect == "source":
                    phase["source_sha256"] = "0" * 64
                elif defect == "future":
                    phase["source_at"] = case.clock() + 1
                elif defect == "missing_lifecycle":
                    del phase["lifecycle"]
                else:
                    phase["run_id"] = "different"
            case.mutate_native = mutate
        wire = await fixture_wire_clients(case, output)
        try:
            with pytest.raises((ValueError, KeyError)):
                await a.collect_one(wire, case.startup, output, "refusal",
                    deadline=case.clock() + 0.5, memory=case.public_memory,
                    process=case.native_process, telemetry=tmp_path / "gateway.jsonl")
            refused = c.load(output / "refusal-refused.json")
            assert refused["status"] == "refused" and "native_record" in refused
        finally:
            await wire.close()
    asyncio.run(scenario())


def test_legacy_empty_but_pending_is_retained_and_full_queue_scope_is_required(monkeypatch, tmp_path):
    async def scenario():
        case = Fixture(monkeypatch, tmp_path)
        await case.initialize()
        output = tmp_path / "final"
        output.mkdir()
        seen = []
        async def native(request):
            frame = case.queue_frame()
            frame["base"]["frontend_sampled_at"] = case.clock()
            if request.url.path == "/pr33-native/state":
                frame["base"]["pending_batches"] = 1
                frame["base"]["orphaned"] = None
                return httpx.Response(200, json=frame["base"])
            seen.append(request.url.path)
            return httpx.Response(200, json=frame)
        wire = await fixture_wire_clients(case, output, native_handler=native)
        try:
            async def sleep(value):
                case.clock.advance(value)
            final = await a.final_drain(wire, output, native_run="synthetic-native",
                                        deadline=case.clock() + 3, sleep=sleep)
            assert final["legacy_failure"] == "legacy_final_native_not_drained_at_first_snapshot"
            assert len(seen) == 2 and final["status"] == "two_complete_empty_observations"
        finally:
            await wire.close()
    asyncio.run(scenario())


@pytest.mark.parametrize("kind", ["nonempty", "unknown", "late"])
def test_final_unknown_late_or_persistent_stock_refuses(monkeypatch, tmp_path, kind):
    async def scenario():
        case = Fixture(monkeypatch, tmp_path)
        await case.initialize()
        output = tmp_path / "final"
        output.mkdir()
        async def native(request):
            frame = case.queue_frame()
            frame["base"]["frontend_sampled_at"] = case.clock()
            if request.url.path == "/pr33-native/state":
                return httpx.Response(200, json=frame["base"])
            if kind == "nonempty":
                frame["queue_oldest_first"] = [dict(step_id="b" * 64, work=[])]
                frame["base"]["pending_batches"] = 1
                frame["base"]["orphaned"] = None
            elif kind == "unknown":
                frame.pop("queue_oldest_first")
            else:
                case.clock.advance(4)
            return httpx.Response(200, json=frame)
        wire = await fixture_wire_clients(case, output, native_handler=native)
        try:
            async def sleep(value):
                case.clock.advance(value)
            with pytest.raises((ValueError, TimeoutError)):
                await a.final_drain(wire, output, native_run="synthetic-native",
                                    deadline=case.clock() + 3, sleep=sleep)
            assert c.load(output / "final-drain.json")["status"] == "refused"
            assert len(list((output / "http").glob("*.json"))) >= 2
        finally:
            await wire.close()
    asyncio.run(scenario())


@pytest.mark.parametrize("defect", ["gpu_events_pending", "future_source", "invalid", "missing_offer"])
def test_end_refusal_never_sends_ack(tmp_path, defect):
    pre = c.preflight()
    source = dict(schema="native-v2-batch-capture-v1", bridge_sha256="b" * 64,
                  plan_sha256="c" * 64, source_commit="d" * 40, run_id="batch", clock_domain=DOMAIN)
    metadata = fixture_wire("POST", "/pr33-native/batch", source, sent=1, received=2)
    calls = []
    records = []
    async def call(*args, **kwargs):
        calls.append(kwargs["payload"]["operation"])
        body = dict(source, trial_id=c.load(c.PLAN)["trials"][0]["trial_id"],
                    command_started_at=3.1, capture_valid=False, validation_errors=[])
        if defect == "gpu_events_pending":
            body["status"] = defect
        if defect == "future_source":
            body.update(capture_valid=True, command_started_at=1000)
        if defect == "missing_offer":
            capture = dict(schema="prefill-capture-v1", status="complete", requests={}, steps=[],
                           workers=[dict(rows=[], pending=[], overflow=0)], errors=[], overflow=0,
                           pending_step_ids=[])
            body.update(capture_valid=True, capture=capture,
                        capture_sha256=pre.frozen.control().sha(pre.frozen.control().canonical(capture)))
            rid = "a" * 32
            row = fixture_wire("POST", "/v1/chat/completions",
                dict(model=c.MODEL_ID, choices=[dict(finish_reason="stop")], usage=dict(completion_tokens=1)),
                sent=2, received=2.5, payload=dict(model=c.MODEL_ID, max_tokens=16))
            row.update(role="managed-1", request_id=rid, response_headers={"x-request-id": rid})
            records.append(row)
        return fixture_wire("POST", "/pr33-native/batch", body, sent=3, received=4)
    wire = SimpleNamespace(api=pre.frozen.control(), pre=pre, call=call, clock=lambda: 4,
                           capture=SimpleNamespace(records=records))
    with pytest.raises(ValueError):
        asyncio.run(a.finish_capture(wire, tmp_path, metadata, deadline=5))
    assert calls == ["end"] and not (tmp_path / "retained-capture.json").exists()


def test_exact_token_estimator_refuses_fallback_instead_of_inventing_public_memory():
    class Tokenizer:
        def apply_chat_template(self, *args, **kwargs):
            raise ValueError("synthetic_bad_template")
    with pytest.raises(ValueError, match="no_fallback"):
        c.estimate_prompt({"messages": [{"role": "user", "content": "ready"}]}, Tokenizer())


@pytest.mark.parametrize("defect", [None, "wrong_serving_pid", "tokenizer_delay", "metadata_source",
                                  "outcome_malformed", "overlap_running", "overlap_ghost",
                                  "overlap_empty", "overlap_zero_work", "overlap_late", "overlap_refused",
                                  "overlap_assessment_refused"])
def test_complete_adapter_protocol_uses_real_source_producers_and_retains_all_rows(
        monkeypatch, tmp_path, defect):
    """CPU fake core/worker and HTTP, actual source CAS/ledger/capture/phase/prefix."""
    async def scenario():
        from fastapi import Request
        from synthetic01 import WARM
        root, output = tmp_path / "stack", tmp_path / "stack/client"
        for path in (root, root / "native", root / "gateway", output):
            path.mkdir()
        c.write(root / "SYNTHETIC_ONLY.json", dict(
            scope="CPU_SOURCE_FIXTURE_ONLY", native_execution=False, GPU_execution=False,
            fake_core_worker_HTTP_clocks=True, actual_application_at=None))
        case = Fixture(monkeypatch, root / "gateway")
        case.gateway["TELEMETRY_JSONL"] = str(root / "gateway/gateway-telemetry.jsonl")
        if defect == "wrong_serving_pid":
            case.gateway_process["pid"] = 201
        monkeypatch.setattr(c, "PUBLIC", root)
        monkeypatch.setattr(case.proc_api, "LinuxProc", lambda: case.proc)
        sdk = c.load(c.SOURCE / "experiments/prefill-vllm-v030-source-map.json")
        source = dict(version=sdk["version"], files=sdk["sha256"], upstream=sdk["upstream"])
        bridge = c.preflight().frozen.module("batch_capture_bridge")
        clocks = [dict(process_id=111, clock_domain=DOMAIN, bridge_sha256=bridge.source_hash())]
        case.core.model_executor = SimpleNamespace(collective_rpc=lambda name: clocks)
        steps, captured_requests = [], {}

        def core_command(core, payload):
            if payload["operation"] == "meta":
                return dict(source=source, tensor_parallel_size=1, pipeline_parallel_size=1,
                            process_id=111, workers=[dict(source=source)])
            if payload["operation"] == "external_begin":
                case.capture = case.capture_api.ExternalCapture(core, payload["trial_id"], "light")
                core._prefill_trial = case.capture
                return {"external": True}
            assert payload["operation"] == "external_end"
            return dict(schema="prefill-capture-v1", trial_id=case.capture.id, status="complete",
                        overflow=0, pending_step_ids=[], errors=[], requests=captured_requests,
                        steps=[dict(step_id=k) for k in steps],
                        workers=[dict(pending=[], overflow=0, rows=[
                            dict(step_id=k, gpu_forward_s=0.001, gpu_error=None) for k in steps])])

        capture = bridge.BatchCapture(case.core, case.plan, core_command,
                                      clock=case.clock, domain=DOMAIN)
        case.app.add_api_route("/admin/mpc/budget", case.gateway["mpc_update_budget"], methods=["POST"])
        offered = []
        release = {}
        overlap = isinstance(defect, str) and defect.startswith("overlap_")
        phase_reads = [0]

        async def offer(request: Request):
            payload = await request.json()
            rid = request.headers["x-benchmark-request-id"]
            offered.append(rid)
            decision = await case.gateway["begin_request"](
                16, False, mpc_mark=(rid, case.clock(), 5, 16))
            assert decision.accepted
            nid = "chatcmpl-" + rid + "-22222222"
            native = SimpleNamespace(request_id=nid, num_prompt_tokens=5, max_tokens=16,
                sampling_params=SimpleNamespace(extra_args={}), prompt_token_ids=[1, 2, 3, 4, 5])
            case.ledger.put(("ADD", (native, 0)))
            case.input_queue.get_nowait()
            assert case.capture.register_request(native)
            gate = asyncio.Event()
            release[rid] = gate
            if overlap and defect not in ("overlap_ghost", "overlap_empty", "overlap_zero_work"):
                case.core.scheduler.running = [native]
                case.core.scheduler.requests = {nid: native}
                await asyncio.wait_for(gate.wait(), timeout=1)
                case.core.scheduler.running, case.core.scheduler.requests = [], {}
            scheduled = SimpleNamespace(num_scheduled_tokens={nid: 1}, total_num_scheduled_tokens=1,
                scheduled_new_reqs=[], scheduled_cached_reqs=SimpleNamespace(
                    req_ids=[nid], num_computed_tokens=[5]))
            key = c.preflight().frozen.module("prefill_lab.contracts").step_key(scheduled)
            case.capture.inflight[key] = dict(start=case.clock(), end=None)
            case.capture.after_output(scheduled, {0: SimpleNamespace(outputs=[
                SimpleNamespace(request_id=nid, new_token_ids=[6], finish_reason="stop")])})
            await case.gateway["finish_request"](16, request_id=rid)
            steps.append(key)
            captured_requests[nid] = dict(finished=case.clock())
            case.routes = [dict(step_id=key, work=[
                dict(request_id=nid, position=6, tokens=1, prompt_length=5)])]
            case.ghosts = [nid]
            if overlap and defect in ("overlap_ghost", "overlap_empty", "overlap_zero_work"):
                if defect == "overlap_ghost":
                    case.routes.append(dict(step_id="b" * 64, work=[]))
                elif defect == "overlap_zero_work":
                    case.routes, case.ghosts = [dict(step_id="b" * 64, work=[])], []
                else:
                    case.routes, case.ghosts = [], []
                await asyncio.wait_for(gate.wait(), timeout=1)
            from fastapi.responses import JSONResponse, Response
            if defect == "outcome_malformed":
                return Response("not-JSON", status_code=200, headers={"x-request-id": rid})
            return JSONResponse(dict(model=payload["model"], choices=[dict(finish_reason="stop")],
                                     usage=dict(completion_tokens=1)), headers={"x-request-id": rid})

        case.app.add_api_route("/v1/chat/completions", offer, methods=["POST"])
        warm_count = [0]
        final_phase = [False]
        async def native(request):
            path = request.url.path
            if path == "/health":
                return httpx.Response(200, json={})
            if path == "/v1/models":
                return httpx.Response(200, json={"data": [{"id": c.MODEL_ID}]})
            if path == "/v1/chat/completions":
                warm_count[0] += 1
                case.ledger.put(("ADD", (SimpleNamespace(request_id=WARM + "-11111111"), 0)))
                case.input_queue.get_nowait()
                return httpx.Response(200, json=dict(
                    id=WARM, choices=[dict(finish_reason="stop")], usage=dict(completion_tokens=1)))
            if path == "/pr33-native/batch":
                reply = capture.invoke(json.loads(request.content))
                if defect == "metadata_source" and json.loads(request.content)["operation"] == "metadata":
                    reply["source_commit"] = "0" * 40
                return httpx.Response(200, json=reply)
            if path == "/pr33-native/phase-state":
                frame = case.phase.phase_snapshot(case.core)
                phase_reads[0] += 1
                if defect == "overlap_refused" and phase_reads[0] == 2:
                    frame["native_phase"]["source_sha256"] = "0" * 64
            else:
                if path == "/pr33-native/queue-state" and final_phase[0]:
                    case.routes, case.ghosts = [], []
                frame = case.queue_frame()
            frame["base"]["frontend_sampled_at"] = case.clock()
            if path == "/pr33-native/state":
                final_phase[0] = True
                return httpx.Response(200, json=frame["base"])
            return httpx.Response(200, json=frame)
        api = c.preflight().frozen.control()
        monkeypatch.setattr(api, "clock_domain", lambda: DOMAIN)
        origins = [dict(module=name, **row, valid=True, pid=111 if name in
                    ("phase_observer", "input_post_observer", "queue_observer") else 200,
                    start_ticks=30 if name in ("phase_observer", "input_post_observer", "queue_observer") else 40)
                   for name, row in c.load(c.HERE / "ORIGIN_POLICY.json")["origins"].items()]
        monkeypatch.setattr(c, "load_origins", lambda _: origins)
        original_origin_check = c.require_origins
        monkeypatch.setattr(c, "require_origins", lambda records, **kw: original_origin_check(
            records, process_reader=lambda pid: 30 if pid == 111 else 40, **kw))
        async def sleep(value):
            case.clock.advance(value)
        original_startup, original_final = a.startup, a.final_drain
        monkeypatch.setattr(a, "startup", lambda *args, **kw: original_startup(*args, sleep=sleep, **kw))
        monkeypatch.setattr(a, "final_drain", lambda *args, **kw: original_final(*args, sleep=sleep, **kw))
        original_offer, original_collect = a.managed_offer, a.collect_one
        monkeypatch.setattr(a, "managed_offer",
                            lambda *args, **kw: original_offer(*args, sleep=sleep, **kw))
        async def collect(*args, **kw):
            name = args[3]
            try:
                return await original_collect(*args, **kw)
            finally:
                if overlap and name.endswith("-inflight-cut"):
                    for gate in release.values():
                        gate.set()
                    if defect == "overlap_late":
                        await asyncio.sleep(0)
                        await asyncio.sleep(0)
        monkeypatch.setattr(a, "collect_one", collect)
        if defect == "overlap_assessment_refused":
            def refuse_assessment(*args, **kwargs):
                raise ValueError("synthetic_inflight_assessment_refusal")
            monkeypatch.setattr(a, "assess_inflight", refuse_assessment)
        wire = await fixture_wire_clients(case, output, native_handler=native)
        starts = dict(
            native=dict(pid=100, process_group=100, start_ticks="10", started_at=99,
                        native_ready=False, cleanup_completed=False),
            gateway=dict(pid=200, process_group=200, start_ticks="40", started_at=99,
                         native_ready=False, cleanup_completed=False))
        def template(*args, **kw):
            if defect == "tokenizer_delay":
                case.clock.advance(0.6)
            return {"input_ids": [1, 2, 3, 4, 5]}
        tokenizer = SimpleNamespace(apply_chat_template=template)
        try:
            result = await a.protocol_run(wire, output, starts, case.clock() + 180, tokenizer)
            assert warm_count == [1]
            refused = defect in ("overlap_refused", "overlap_assessment_refused")
            expected_engineering = defect is None or overlap and not refused
            assert result["engineering_pass"] is expected_engineering, result
            assert result["component_pass"] is (defect in ("overlap_running", "overlap_ghost")), result
            assert len(result["offers"]) == 2 and result["actual_application_at"] is None
            if overlap:
                count = 1 if refused else 2
                assert len(offered) == count
                assert all(row["cut"] for row in result["offers"][:count])
                assert all((output / f"offer-{n}-transport-join.json").exists() for n in range(1, count + 1))
                if defect in ("overlap_running", "overlap_ghost"):
                    assert result["nonempty_overlap_count"] == 2
                    assert all(row["inflight"]["available_at"] < row["inflight"]["client_receive_at"]
                               for row in result["offers"])
                    if defect == "overlap_ghost":
                        assert all(row["inflight"]["stock_counts"]["ghosts"] == 1
                                   and row["inflight"]["stock_counts"]["zero_work_routes"] == 1
                                   for row in result["offers"])
                else:
                    assert result["nonempty_overlap_count"] == 0
                    if defect == "overlap_zero_work":
                        assert all(row["inflight"]["stock_counts"]["zero_work_routes"] == 1
                                   for row in result["offers"])
                    elif defect == "overlap_late":
                        assert all(row["inflight"]["status"] == "available_after_outcome"
                                   for row in result["offers"])
                    elif defect == "overlap_refused":
                        assert result["offers"][1]["fate"] == "not_sent"
                        assert (output / "offer-1-inflight-cut-refused.json").exists()
                    elif defect == "overlap_assessment_refused":
                        assert result["offers"][1]["fate"] == "not_sent"
                        assert result["offers"][0]["inflight"]["status"] == "refused_or_unknown"
                        assert (output / "offer-1-inflight-cut.json").exists()
            elif defect == "outcome_malformed":
                assert offered == [result["offers"][0]["request_id"]]
                assert result["offers"][0]["fate"] == "received_unclassifiable"
                assert result["offers"][1]["fate"] == "not_sent"
                assert (output / "offer-1-cut.json").exists()
                assert (output / "retained-capture.json").exists()
            elif defect is not None:
                assert offered == [] and all(row["fate"] == "not_sent" for row in result["offers"])
                if defect == "metadata_source":
                    assert not (output / "initial-cut.json").exists()
                    assert [json.loads(r["request_body"])["operation"] for r in wire.capture.records
                            if r["path"] == "/pr33-native/batch"] == ["metadata"]
                else:
                    assert (output / ("initial-cut-refused.json" if defect == "wrong_serving_pid"
                                      else "initial-cut.json")).exists()
            else:
                assert offered == [row["request_id"] for row in result["offers"]]
                assert [row["fate"] for row in result["offers"]] == ["completed_stop"] * 2
                assert (output / "retained-capture.json").exists()
                assert c.load(output / "final-drain.json")["legacy_failure"] is not None
                assert len([r for r in wire.capture.records if r["path"] == "/admin/mpc/budget"]) == 1
                assert [json.loads(r["request_body"])["operation"] for r in wire.capture.records
                        if r["path"] == "/pr33-native/batch"] == ["metadata", "begin", "end", "ack"]
                assert result["nonempty_overlap_count"] == 0
                assert all(row["inflight"]["status"] == "early_complete_no_cut" for row in result["offers"])
            if expected_engineering:
                replay = c.module("_inflight_candidate_replay", c.HERE / "replay01.py").check_client(output.parent)
                assert replay["replay_consistent"] and replay["component_evidence_consistent"] == result["component_pass"]
                c.write(output / "synthetic-offline-replay.json", replay)
        finally:
            await wire.close()
    asyncio.run(scenario())


def test_origin_guard_measures_actual_module_file_and_detects_wrong_source():
    guard = c.module("_synthetic_owner_origin_guard", c.HERE / "origin_guard/sitecustomize.py")
    obj = c.preflight().frozen.module("phase_observer")
    expected = dict(path=str(Path(obj.__file__).resolve()), sha256=c.sha(obj.__file__))
    row = guard.attestation("phase_observer", obj, expected, "synthetic_local_check")
    assert row["valid"] and row["pid"] == os.getpid()
    assert row["start_ticks"] == c.owner().snapshot(os.getpid())[0]
    assert not guard.attestation("phase_observer", obj, dict(expected, sha256="0" * 64),
                                  "synthetic_local_check")["valid"]


def test_new_gateway_handoff_preserves_source_exec_pid_without_safe_exec(monkeypatch, tmp_path):
    import service01
    c.preflight().frozen.install_paths()
    source13 = c.SOURCE / c.SOURCE13_REL
    state, public = tmp_path / "state", tmp_path / "public"
    state.mkdir()
    (public / "gateway").mkdir(parents=True)
    monkeypatch.setattr(c, "STATE", state)
    monkeypatch.setattr(c, "PUBLIC", public)
    monkeypatch.setattr(c, "SOURCE13", source13)
    monkeypatch.setattr(c, "remote_only", lambda: None)
    monkeypatch.setattr(c, "owned_parent", lambda *args: None)
    monkeypatch.setattr(c, "private_config", lambda: {})
    monkeypatch.setattr(c, "verify_code", lambda: {})
    monkeypatch.setattr(c, "import_prerequisites", lambda: {})
    monkeypatch.setenv("TMPDIR", str(state / "t"))
    monkeypatch.setenv("PYTHONPATH", str(c.ROOT))
    monkeypatch.setattr(os, "getsid", lambda _: os.getpid())
    monkeypatch.setattr(os, "getpgrp", os.getpid)
    observed = []
    monkeypatch.setattr(os, "execv", lambda exe, args: observed.append((os.getpid(), exe, args)))
    original_prefix = c.preflight().frozen.module("launch_gateway_prefix_service")
    expected = [str(c.PYTHON), "-m", "uvicorn", "gateway:app",
                "--host", "127.0.0.1", "--port", "8080", "--workers", "1"]
    def source_handoff(path, run_name):
        assert Path(path) == source13 / "launch_gateway_prefix_service.py"
        assert run_name == "__main__"
        os.execv(str(c.PYTHON), original_prefix.handoff_arguments(str(c.PYTHON), expected))
    monkeypatch.setattr(service01.runpy, "run_path", source_handoff)
    monkeypatch.setattr(sys, "argv", ["service01.py", "--service", "gateway",
                                     "--owner-pid", "1", "--owner-start-ticks", "1"])
    before_cache = sys.pycache_prefix
    try:
        service01.main()
    finally:
        sys.pycache_prefix = before_cache
    assert observed[0][0] == os.getpid()
    assert observed[0][2][3:5] == ["gateway_prefix_bridge:application", "--factory"]
    receipt = c.load(public / "gateway/direct-exec.json")
    assert receipt["pid"] == os.getpid() and not receipt["spawned_redactor_process"]


def test_owned_registration_failure_still_retains_and_joins_child(monkeypatch, tmp_path):
    owned = Owned(SECRET)
    real = owned.helper.remember
    failed = [False]
    def fail_once(*args, **kwargs):
        if not failed[0]:
            failed[0] = True
            raise OSError("synthetic_registration_failure")
        return real(*args, **kwargs)
    monkeypatch.setattr(owned.helper, "remember", fail_once)
    with pytest.raises(OSError):
        spawn(owned, "hold", tmp_path / "registration")
    assert len(owned.roots) == 1
    receipt = owned.cleanup(time.monotonic(), allocation=(0.1, 30, 2, 1))
    assert receipt["all_joined"] and not receipt["surviving_owned_pids"]
    c.write(tmp_path / "owned-cleanup.json", receipt)
