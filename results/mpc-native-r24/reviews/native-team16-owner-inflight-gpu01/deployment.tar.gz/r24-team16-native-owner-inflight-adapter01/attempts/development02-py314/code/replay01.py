"""Offline reported-evidence replay; never starts services or re-proves live procfs."""

import argparse
import base64
from dataclasses import asdict
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common01 as c
from coverage01 import assess


def checked_journal(directory, name, *, pre, startup, closure, memory, deadline, records):
    api = pre.frozen.control()
    journal = c.load(directory / "client" / (name + ".json"))
    cut = journal["cut"]
    view = pre.inspect_cut(cut, consume_at=journal["observation"]["consumed_at"], deadline=deadline)
    c.require(api.canonical(view) == api.canonical(journal["observation"])
              and view["gateway_budget_version"] == 1, "reported_stock_or_version_changed")
    phases = pre.frozen.module("source_owner_phases").classify_source_owners(
        cut, initial_closure=closure, native_startup=startup["native_owned"], public_memory=memory,
        now=journal["phases"]["classified_at"], expected_clock_domain=cut["common_clock_proof"]["clock_domain"])
    c.require(api.canonical(phases.evidence()) == api.canonical(journal["phases"]), "phase_replay")
    prefix = directory / "client" / (name + "-prefix.jsonl")
    c.require(c.sha(prefix) == cut["owner_prefix"]["receipt"]["prefix_sha256"]
              and prefix.stat().st_size == cut["owner_prefix"]["prefix_bytes"], "retained_prefix_bytes")
    native = journal["native_record"]
    c.require(api.canonical(native) == api.canonical(records[native["sequence"]])
              and api.canonical(api.body(native)) == api.canonical(cut["native_observation"]),
              "cut_actual_HTTP_binding")
    return journal


def check_client(directory):
    directory = Path(directory)
    pre, result = c.preflight(), c.load(directory / "client/result.json")
    api = pre.frozen.control()
    c.require(result["schema"] == "team16-owner-inflight-result-v1"
              and result["actual_application_at"] is None and not result["native_mpc_permitted"],
              "reported_scope_or_gate_changed")
    records = [c.load(path) for path in sorted((directory / "client/http").glob("*.json"),
                                              key=lambda p: int(p.stem))]
    c.require(1 <= len(records) <= 1900 and [r["sequence"] for r in records] == list(range(len(records))),
              "HTTP_complete_sequence")
    for row in records:
        raw = base64.b64decode(row["response_body_base64"], validate=True)
        reservation = c.load(directory / "client/http-reservations" / f'{row["sequence"]:03d}.json')
        c.require(c.sha_bytes(raw) == row["response_body_sha256"]
                  and len(raw) == row["response_bytes_captured"]
                  and row["auth_values_captured"] is False
                  and set(row["response_headers"]) <= {"content-type", "x-request-id"}
                  and row["reserved_at"] <= row["client_receive_at"] <= result["finished_at"]
                  and all(row[key] == reservation[key] for key in
                          ("sequence", "role", "method", "path", "request_body", "request_id", "reserved_at"))
                  and reservation["dispatch_attempted"] is False,
                  "HTTP_raw_receipt_binding")
        if row["dispatch_attempted"]:
            c.require(row["reserved_at"] <= row["client_send_at"] <= row["client_receive_at"],
                      "HTTP_dispatch_binding")
        else:
            c.require(row["client_send_at"] is None and row["error_type"], "unsent_HTTP_binding")
        if result["engineering_pass"] and not row["role"].startswith("startup-health-"):
            c.require(not row["error_type"] and not row["credential_removed"], "successful_HTTP_error")
            pre.receipt_body(row, method=row["method"], path=row["path"], cutoff=result["finished_at"])
    planned = c.load(c.OFFERS)["rows"]
    offers = result["offers"]
    c.require(len(offers) == 2 and [r["request_id"] for r in offers] ==
              [r["request_id"] for r in planned], "offered_inventory")
    c.require(len(list((directory / "client/http-reservations").glob("*.json"))) == len(records),
              "unterminated_HTTP_reservation")
    managed = [r for r in records if r["request_id"] is not None]
    c.require(len({r["request_id"] for r in managed}) == len(managed)
              and {r["request_id"] for r in managed} <= {r["request_id"] for r in offers},
              "unique_managed_receipts")
    if not result["engineering_pass"]:
        c.require(result["component_pass"] is False and result["failures"], "unexplained_engineering_refusal")
        return dict(scope="OFFLINE_REFUSED_RAW_INVENTORY_ONLY_NOT_REQUALIFIED",
                    replay_consistent=True, component_evidence_consistent=False,
                    reported_engineering_pass=False, actual_application_at=None,
                    native_mpc_permitted=False, model_qualified=False, live_procfs_reproved=False,
                    HTTP_records=len(records), offers_sent_or_reserved=len(managed))
    c.require(not result["failures"], "engineering_pass_with_failure")
    all_offers = [r for r in records if r["path"] == "/v1/chat/completions"]
    commands = [r for r in records if r["path"] == "/admin/mpc/budget"]
    batches = [r for r in records if r["path"] == "/pr33-native/batch"]
    c.require(len(all_offers) == 3 and sum(r["role"] == "one-warmup" for r in all_offers) == 1
              and len(commands) == 1 and json.loads(commands[0]["request_body"])["budget"] == 32
              and all(json.loads(r["request_body"])["max_tokens"] == 16 for r in all_offers)
              and [json.loads(r["request_body"])["operation"] for r in batches] ==
              ["metadata", "begin", "end", "ack"], "fixed_protocol_no_extra_requests")
    startup = c.load(directory / "client/bootstrap-inputs.json")
    initial = c.load(directory / "client/initial-cut.json")
    pre.bootstrap_inputs(startup, cutoff=initial["cut"]["validated_at"])
    closure = pre.frozen.module("capture_owner_closure").establish_initial_capture_closure(
        initial["cut"], native_startup=startup["native_owned"], gateway_startup=startup["gateway_owned"])
    c.require(api.canonical(asdict(closure)) == api.canonical(result["initial_closure"]), "closure_binding")
    deadline, memory, nonempty = result["active_started_at"] + 20, {}, 0
    def read_cut(name):
        return checked_journal(directory, name, pre=pre, startup=startup, closure=closure,
                               memory=memory, deadline=deadline, records=records)
    previous = read_cut("initial-cut")
    expected_names, last_outcome = {"initial-cut.json"}, None
    classifications = []
    for offer in offers:
        ordinal = offer["ordinal"]
        row = records[offer["record"]]
        c.require(row["request_id"] == offer["request_id"]
                  and api.offer_fate(row, offer["request_id"]) == offer["fate"]
                  and offer["fate"] in ("completed_stop", "completed_length")
                  and previous["cut"]["validated_at"] <= offer["send_intent_at"]
                  <= row["client_send_at"] <= row["client_receive_at"]
                  and row["client_send_at"] - previous["cut"]["cut_at"] <= 0.5
                  and (last_outcome is None or last_outcome <= row["client_send_at"])
                  and json.loads(row["request_body"]) == c.load(c.OFFERS)["payload"],
                  "offer_receipt_cutoff_or_fate")
        last_outcome = row["client_receive_at"]
        memory[offer["request_id"]] = pre.frozen.module("live_owner_prefix").PublicRequest(
            offer["prompt_tokens"], 16)
        attempt = c.load(directory / "client" / f"offer-{ordinal}-inflight-attempt.json")
        observed = c.load(directory / "client" / f"offer-{ordinal}-inflight.json")
        joined = c.load(directory / "client" / f"offer-{ordinal}-transport-join.json")
        c.require(joined["joined"] is True and joined["record"] == row["sequence"]
                  and attempt["dispatch"] == dict(sequence=row["sequence"], client_send_at=row["client_send_at"])
                  and attempt["trigger_delay_s"] == c.protocol()["inflight"]["trigger_delay_s"]
                  and attempt["scheduled_trigger_at"] == row["client_send_at"] + attempt["trigger_delay_s"]
                  and attempt["scheduled_trigger_at"] <= attempt["trigger_at"] <= deadline,
                  "single_trigger_or_join_binding")
        expected = dict(attempt)
        if attempt["cut"] is not None:
            name = f"offer-{ordinal}-inflight-cut"
            c.require(attempt["pending_at_trigger"] is True
                      and attempt["trigger_at"] < row["client_receive_at"]
                      and attempt["cut"] == name + ".json"
                      and attempt["cut_file_sha256"] == c.sha(directory / "client" / (name + ".json")),
                      "inflight_single_cut_binding")
            journal = read_cut(name)
            c.require(attempt["trigger_at"] <= journal["native_record"]["client_send_at"],
                      "inflight_cut_before_fixed_trigger")
            expected.update(assess(journal, row, offer["request_id"],
                                   returned_at=attempt["cut_returned_at"], deadline=deadline))
            expected_names.add(name + ".json")
        else:
            c.require(attempt["status"] == "early_complete_no_cut"
                      and attempt["pending_at_trigger"] is False
                      and row["client_receive_at"] <= attempt["trigger_at"], "unexplained_missing_inflight_cut")
        c.require(api.canonical(expected) == api.canonical(observed) == api.canonical(offer["inflight"]),
                  "inflight_assessment_replay")
        nonempty += observed["nonempty_overlap"] is True
        classifications.append(observed["status"])
        name = f"offer-{ordinal}-cut"
        previous = read_cut(name)
        c.require(offer["cut"] == name + ".json"
                  and row["client_receive_at"] <= previous["native_record"]["client_send_at"],
                  "post_outcome_cut_chronology")
        expected_names.add(name + ".json")
    c.require({p.name for p in (directory / "client").glob("*-cut.json")} == expected_names
              and result["nonempty_overlap_count"] == nonempty
              and result["coverage_complete"] is (nonempty == 2)
              and result["component_pass"] is (nonempty == 2), "unexpected_cut_or_coverage_claim")
    final = c.load(directory / "client/final-drain.json")
    c.require(final["status"] == "two_complete_empty_observations"
              and final["deadline"] == result["active_finished_at"] + 3
              and final["finished_at"] <= final["deadline"]
              and result["active_finished_at"] <= result["active_started_at"] + 20,
              "final_clock_bound")
    native_run = startup["native_owned"]["readiness"]["frames"][0]["run_id"]
    legacy = api.native_state(records[final["legacy_record"]], pre.frozen.settings(), native_run=native_run)
    expected_legacy = (None if all(legacy[k] == 0 for k in
        ("running", "waiting", "pending_batches", "frontend_unfinished"))
        else "legacy_final_native_not_drained_at_first_snapshot")
    c.require(final["legacy_failure"] == expected_legacy and 2 <= len(final["samples"]) <= 9,
              "legacy_failure_preserved")
    consecutive, last_received = 0, None
    for sample in final["samples"]:
        row = records[sample["record"]]
        _, empty = api.full_queue_observation(
            row, pre.frozen.settings(), native_run=native_run, deadline=final["deadline"])
        c.require(empty == sample["empty"] and (
            last_received is None or row["client_send_at"] - last_received >= 0.25), "final_fixed_poll")
        consecutive = consecutive + 1 if empty else 0
        last_received = row["client_receive_at"]
    c.require(consecutive == 2, "full_stock_empty_not_proved")
    ended, acknowledged = map(api.body, batches[-2:])
    retained = c.load(directory / "client/retained-capture.json")
    c.require(ended["capture_valid"] is True and not ended["validation_errors"]
              and api.canonical(ended["capture"]) == api.canonical(retained)
              and c.sha(directory / "client/retained-capture.json") == ended["capture_sha256"]
              and json.loads(batches[-1]["request_body"])["capture_sha256"] == ended["capture_sha256"]
              and acknowledged["acknowledged"] is True
              and last_received <= batches[-2]["client_send_at"] <= batches[-2]["client_receive_at"]
              <= batches[-1]["client_send_at"] <= batches[-1]["client_receive_at"] <= final["deadline"],
              "capture_retention_ACK_chronology")
    return dict(scope="OFFLINE_REPORTED_EVIDENCE_NOT_NEW_NATIVE_EXECUTION",
                replay_consistent=True, component_evidence_consistent=nonempty == 2,
                reported_engineering_pass=True, nonempty_overlap_count=nonempty,
                classifications=classifications, actual_application_at=None,
                native_mpc_permitted=False, model_qualified=False,
                live_procfs_reproved=False, offers=2, warmup=1, legacy_failure=expected_legacy)


def prior_empty_evidence():
    root = c.HERE / "inputs/prior-native01"
    manifest = root / "RAW-SHA256SUMS"
    c.require(c.sha(manifest) == c.protocol()["accepted_prior_raw_manifest"], "prior_raw_manifest")
    names = set()
    for line in manifest.read_text().splitlines():
        fingerprint, name = line.split("  ", 1)
        path = Path(name)
        c.require(not path.is_absolute() and ".." not in path.parts and name not in names,
                  "prior_raw_relative_inventory")
        names.add(name)
        c.require(c.sha(root / path) == fingerprint, "prior_raw_changed")
    c.require({str(p.relative_to(root)) for p in root.rglob("*")
               if p.is_file() and p != manifest} == names, "prior_complete_inventory")
    directory = root / "native-output"
    rows = {}
    pre = c.preflight()
    result = c.load(directory / "client/result.json")
    for name in ("initial-cut", "offer-1-cut", "offer-2-cut"):
        journal = c.load(directory / "client" / (name + ".json"))
        view = pre.inspect_cut(journal["cut"], consume_at=journal["observation"]["consumed_at"],
                               deadline=result["active_started_at"] + 20)
        stock = view["full_stock"]
        c.require(not stock["scheduler_state"]["requests"] and not stock["queue_oldest_first"]
                  and not stock["queued_ghost_request_ids"]
                  and all(stock["base"][key] == 0 for key in
                          ("running", "waiting", "pending_batches", "frontend_unfinished")),
                  "prior_cut_not_empty")
        rows[name] = dict(source_at=journal["cut"]["cut_at"],
                          available_at=journal["cut"]["validated_at"], full_stock_empty=True)
    return dict(scope="PRIOR_ACCEPTED_NATIVE_EVIDENCE_ONLY_NOT_A_NEW_RUN",
                manifest_sha256=c.sha(manifest), verified_files=len(names), cuts=rows,
                prior_engineering_component_pass=result["component_pass"],
                nonempty_coverage_established=False, native_mpc_permitted=False,
                actual_application_at=None, live_procfs_reproved=False)


def main(argv=None):
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("directory", type=Path, nargs="?")
    parser.add_argument("--prior-accepted-empty", action="store_true")
    args = parser.parse_args(argv)
    if args.prior_accepted_empty:
        c.require(args.directory is None, "prior_or_new_replay_not_both")
        c.verify(False)
        print(json.dumps(prior_empty_evidence(), sort_keys=True))
        return 0
    if args.directory is None:
        parser.error("directory or --prior-accepted-empty is required")
    directory = args.directory.resolve()
    os.chdir(c.PREFLIGHT)
    c.verify(False)
    try:
        c.require(not (directory / "DO_NOT_EXPORT.json").exists(), "export_revoked")
        gate = c.load(directory / "export-gate.json")
        supervision = c.load(directory / "supervision.json")
        c.require(gate["safe_to_export"]
                  and gate["completed_at"] <= gate["absolute_deadline"]
                  and supervision["phase_bounds"]
                  and supervision["sources_unchanged"] and supervision["candidate_unchanged"]
                  and supervision["cleanup"]["all_joined"] and supervision["cleanup"]["capture_complete"]
                  and supervision["private_config_removed_after_join"], "supervision_or_export_refused")
        index = c.load(directory / "result-index.json")
        names = {row["path"] for row in index["files"]}
        actual = {str(path.relative_to(directory)) for path in directory.rglob("*")
                  if path.is_file() and path.name not in index["excluded_final_files"]}
        c.require(names == actual and len(names) == len(index["files"]), "complete_output_inventory")
        for row in index["files"]:
            name = Path(row["path"])
            c.require(not name.is_absolute() and ".." not in name.parts, "index_path")
            path = directory / name
            c.require(path.is_file() and not path.is_symlink() and c.sha(path) == row["sha256"]
                      and path.stat().st_size == row["bytes"], "raw_file_binding")
        reply = check_client(directory)
        c.require(gate["component_pass"] == supervision["component_pass"] ==
                  reply["component_evidence_consistent"], "supervisor_coverage_disagreement")
    except (ValueError, KeyError, TypeError, OSError) as error:
        reply = dict(scope="OFFLINE_REPLAY_REFUSAL", replay_consistent=False, component_evidence_consistent=False,
                     error_type=type(error).__name__, actual_application_at=None, native_mpc_permitted=False)
    print(json.dumps(reply, sort_keys=True))
    return 0 if reply["replay_consistent"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
