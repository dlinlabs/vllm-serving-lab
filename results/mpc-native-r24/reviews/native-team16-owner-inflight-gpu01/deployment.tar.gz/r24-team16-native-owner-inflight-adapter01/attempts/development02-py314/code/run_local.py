"""One bounded test-child; retain every exact source snapshot and outcome."""

import json
from pathlib import Path
import subprocess
import sys
import time

import common01 as c


def main():
    mode, name = sys.argv[1:]
    c.require(Path.cwd().resolve() == c.HERE and "/" not in name, "exclusive_test_namespace")
    directory = Path("attempts") / name
    directory.mkdir(parents=True)
    before = c.verify(True)
    c.verify_code()
    (directory / "code/origin_guard").mkdir(parents=True)
    names = sorted({*c.load(c.HERE / "RUNNABLES.json"), "RUNNABLES.json"})
    for filename in names:
        with (directory / "code" / filename).open("xb") as handle:
            handle.write((c.HERE / filename).read_bytes())
    c.write(directory / "before.json", dict(inputs=before,
            code_sha256={name: c.sha(c.HERE / name) for name in names}))
    command = [sys.executable, "-B", "run_checks01.py", mode, str(directory)]
    started = time.monotonic()
    with (directory / "output.log").open("xb") as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
        ticks = c.owner().snapshot(process.pid)[0]
        timeout = False
        try:
            code = process.wait(timeout=120)
        except subprocess.TimeoutExpired:
            timeout = True
            process.kill()
            code = process.wait(timeout=5)
    c.write(directory / "result.json", dict(command=command, pid=process.pid, start_ticks=ticks,
            returncode=code, timeout=timeout, joined=True, elapsed_s=time.monotonic() - started,
            inputs_before=before, inputs_after=c.verify(True), code_after=c.verify_code()))
    text = (directory / "output.log").read_text()
    print(text[-12000:] if len(text) > 12000 else text)
    print(json.dumps(c.load(directory / "result.json"), sort_keys=True))
    return code if code >= 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
