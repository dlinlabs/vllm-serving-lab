"""Narrow accepted-source and prior-raw freeze before this new component's controls."""

import hashlib
import json
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PARENT = ROOT / ".runtime/r24-team16-native-owner-acquisition-adapter01"
PARENT_SEAL = "52b1246f9038d068642dbf043a5c246e9a94c1e05129148ab983fe159a6fa484"
RAW_SEAL = "646fe6a6f5c9a316fa57ee23cdbc1ed118602a1ba05d066854735c6ef24d7d75"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as handle:
        json.dump(value, handle, sort_keys=True, indent=2, allow_nan=False)
        handle.write("\n")


def verify(originals=False):
    pins = json.loads((HERE / "INPUTS.json").read_bytes())
    for row in pins["bindings"]:
        if sha(HERE / row["copy"]) != row["sha256"] or (
                originals and sha(row["source"]) != row["sha256"]):
            raise ValueError("changed_input:" + row["copy"])
    for name, digest in json.loads((HERE / "PRE_SOURCE_FREEZE.json").read_bytes())["sha256"].items():
        if sha(HERE / name) != digest:
            raise ValueError("prefrozen_source_or_protocol_changed:" + name)
    return dict(bindings=len(pins["bindings"]), originals=originals,
                inputs_sha256=sha(HERE / "INPUTS.json"), protocol_sha256=sha(HERE / "PROTOCOL.json"),
                native_plan_sha256=sha(HERE / "NATIVE_PLAN.json"), offers_sha256=sha(HERE / "OFFERS.json"))


def main():
    if Path.cwd().resolve() != HERE or sha(PARENT / "SHA256SUMS") != PARENT_SEAL:
        raise ValueError("exclusive_scope_or_parent_seal")
    sealed = {line[66:]: line[:64] for line in (PARENT / "SHA256SUMS").read_text().splitlines()}
    rows = []
    def retain(source, target, expected):
        source, target = Path(source), Path(target)
        if source.is_symlink() or sha(source) != expected or target.is_absolute():
            raise ValueError("input_binding")
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as handle:
            handle.write(source.read_bytes())
        rows.append(dict(source=str(source), copy=str(target), sha256=expected, bytes=target.stat().st_size))
    for path in sorted((PARENT / "inputs").rglob("*")):
        if path.is_file():
            name = str(path.relative_to(PARENT))
            retain(path, name, sealed[name])
    prototype = [
        "common01.py", "owned01.py", "service01.py", "acquire01.py", "launch01.py",
        "origin_guard/sitecustomize.py", "child_fixture01.py", "test_adapter01.py",
        "run_checks01.py", "run_local.py", "validate.sh", "pytest.ini", "replay01.py", "smoke01.py"]
    for name in prototype + ["PROTOCOL.json", "SOURCE_DECLARATION01.json", "ORIGIN_POLICY.json",
                             "INPUTS.json", "SUPPLEMENT01.json", "RUNNABLES.json", "REPORT.json",
                             "DEPLOYMENT.json", "README.txt"]:
        retain(PARENT / name, "inputs/accepted-adapter/" + name, sealed[name])
        if name in prototype:
            target = Path(name)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as handle:
                handle.write((PARENT / name).read_bytes())
    retain(PARENT / "SHA256SUMS", "inputs/accepted-adapter/SHA256SUMS", PARENT_SEAL)
    retain(PARENT / "ORIGIN_POLICY.json", "ORIGIN_POLICY.json", sealed["ORIGIN_POLICY.json"])
    reviews = ROOT / "results/mpc-native-r24/reviews"
    raw = reviews / "native-team16-owner-adapter-gpu01/received01"
    if sha(raw / "RAW-SHA256SUMS") != RAW_SEAL:
        raise ValueError("accepted_raw_seal")
    for line in (raw / "RAW-SHA256SUMS").read_text().splitlines():
        digest, name = line.split("  ", 1)
        if Path(name).is_absolute() or ".." in Path(name).parts:
            raise ValueError("raw_path")
        retain(raw / name, "inputs/prior-native01/" + name, digest)
    retain(raw / "RAW-SHA256SUMS", "inputs/prior-native01/RAW-SHA256SUMS", RAW_SEAL)
    for source, target in (
        ("native-team16-owner-inflight-engineering-approval01.json", "inputs/inflight-approval01.json"),
        ("native-team16-owner-adapter-gpu01-results.json", "inputs/prior-native01-results.json")):
        retain(reviews / source, target, sha(reviews / source))
    protocol = json.loads(Path("PROTOCOL.json").read_bytes())
    trial = "nv2-team16-owner-inflight01-fixed32"
    offers = dict(schema="team16-owner-inflight-offers-v1", status="PROSPECTIVE_NOT_EXECUTED", fixed_budget=32,
        rows=[dict(ordinal=n, request_id=hashlib.sha256((trial + ":" + str(n)).encode()).hexdigest()[:32],
                   prompt=protocol["managed_payload"]["messages"][0]["content"], max_tokens=16, fate="not_offered")
              for n in (1, 2)],
        payload=protocol["managed_payload"], warmup=dict(offers=1, max_tokens=16, fate="not_offered"))
    write("OFFERS.json", offers)
    plan = json.loads((PARENT / "inputs/preflight/PROPOSED_NATIVE_PLAN.json").read_bytes())
    plan.update(experiment_id=HERE.name, trace_sha256=sha("OFFERS.json"),
                scope="Prospective fixed32 inflight owner-acquisition; unchanged source contracts, not model/MPC.")
    plan["trials"][0].update(trial_id=trial, request_ids=[row["request_id"] for row in offers["rows"]],
                              seed=170103)
    write("NATIVE_PLAN.json", plan)
    write("INPUTS.json", dict(schema="team16-owner-inflight-inputs-v1", bindings=rows,
        accepted_parent_manifest=PARENT_SEAL, accepted_prior_raw_manifest=RAW_SEAL,
        old_entries_never_executed=True, original_sources_never_edited=True))
    write("DISCOVERY.json", dict(native_executions=0, events=[
        dict(file="native-team16-owner-adapter-gpu01-results.json",
             event="Initial view exceeded20KB tool limit; read in bounded ranges, no source changes.")]))
    write("PRE_SOURCE_FREEZE.json", dict(frozen_at_unix=time.time(), tests_started=False, native_execution=False,
        sha256={name: sha(name) for name in (
            "freeze01.py", "PROTOCOL.json", "SOURCE_DECLARATION01.json", "INPUTS.json",
            "OFFERS.json", "NATIVE_PLAN.json", "ORIGIN_POLICY.json")}))
    print(json.dumps(verify(True), sort_keys=True))


if __name__ == "__main__":
    main()
