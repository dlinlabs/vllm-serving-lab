"""Freeze candidate source before every new, exclusive CPU validation attempt."""

import json
from pathlib import Path
import sys
import time

import common01 as c


def main():
    name, = sys.argv[1:]
    c.require(Path.cwd().resolve() == c.HERE and "/" not in name, "exclusive_revision")
    previous = c.load("RUNNABLES.json") if Path("RUNNABLES.json").exists() else None
    names = [str(path.relative_to(c.HERE)) for path in sorted(c.HERE.glob("*.py"))]
    names += ["origin_guard/sitecustomize.py", "PROTOCOL.json", "SOURCE_DECLARATION01.json",
              "ORIGIN_POLICY.json", "NATIVE_PLAN.json", "OFFERS.json", "validate.sh", "pytest.ini"]
    names += [name for name in ("DEPLOYMENT.json", "MAYOR_PREREGISTRATION.template.json", "README.txt")
              if Path(name).exists()]
    pins = {name: c.sha(c.HERE / name) for name in names}
    c.write(Path("attempts") / ("code-freeze-" + name + ".json"),
        dict(frozen_at_unix=time.time(), prior_sha256=previous, current_sha256=pins,
             inputs=c.verify(True), successor_controls_started=False))
    with Path("RUNNABLES.json").open("w") as stream:
        json.dump(pins, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps(dict(runnables=len(pins), inputs=c.verify(True)), sort_keys=True))


if __name__ == "__main__":
    main()
