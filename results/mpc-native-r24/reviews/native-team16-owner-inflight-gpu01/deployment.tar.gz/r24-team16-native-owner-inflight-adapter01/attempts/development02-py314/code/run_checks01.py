"""CPU audit boundary: only named benign owned fixture children are allowed."""

import json
import os
from pathlib import Path
import sys
import threading

import common01 as c


def audit(event, args):
    if event in {"socket.connect", "socket.bind", "socket.getaddrinfo", "os.system", "os.exec", "os.posix_spawn"}:
        raise RuntimeError("CPU_forbidden_effect:" + event)
    if event == "import" and str(args[0]).split(".")[0] in {"vllm", "torch", "transformers"}:
        raise RuntimeError("CPU_native_import")
    if event == "subprocess.Popen":
        argv = args[1]
        if (not isinstance(argv, list) or len(argv) != 5 or argv[:3] !=
                [sys.executable, "-B", str(c.HERE / "child_fixture01.py")]
                or argv[3] not in ("echo", "exec", "hold", "blocked")):
            raise RuntimeError("CPU_unapproved_child")


def main():
    mode, output = sys.argv[1], Path(sys.argv[2]).resolve()
    c.verify(False)
    c.preflight()
    os.chdir(c.PREFLIGHT)
    sys.addaudithook(audit)
    import pytest
    tests = [str(c.HERE / name) for name in ("test_adapter01.py", "test_transport01.py")] if mode != "baseline" else [
        str(c.SOURCE / "tests/test_r24_capture_owner_closure.py") + "::test_known_completed_warm_marker_is_not_classified_as_pending",
        str(c.SOURCE / "tests/test_r24_capture_owner_closure.py") + "::test_released_physical_ghost_has_no_owner_charge_but_live_release_refuses",
        str(c.SOURCE / "tests/test_r24_process_clock_provenance.py") + "::test_native_descendant_and_gateway_source_derived_clock_join",
        str(c.SOURCE / "tests/test_r24_process_clock_provenance.py") + "::test_acquisition_and_validation_latency_are_charged",
    ]
    result = int(pytest.main(["-q", "-c", str(c.HERE / "pytest.ini"), "-p", "no:cacheprovider",
                             "--basetemp", str(output / "work"),
                             "--junitxml", str(output / "junit.xml"), *tests]))
    threads = [t.name for t in threading.enumerate() if t is not threading.main_thread()]
    children = Path(f"/proc/{os.getpid()}/task/{os.getpid()}/children").read_text().split()
    c.write(output / "child-result.json", dict(returncode=result, threads_remaining=threads,
            child_pids_remaining=children, native_imports=0, sockets=0, inputs=c.verify(False)))
    print(json.dumps(dict(returncode=result, remaining_threads=threads, remaining_children=children)))
    return 3 if threads or children else result


if __name__ == "__main__":
    raise SystemExit(main())
