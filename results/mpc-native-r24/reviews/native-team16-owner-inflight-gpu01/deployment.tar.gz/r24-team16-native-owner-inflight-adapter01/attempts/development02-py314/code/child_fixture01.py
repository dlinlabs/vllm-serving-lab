"""Bounded benign CPU child used only by owned cleanup/redaction controls."""

import os
from pathlib import Path
import signal
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))


def main():
    mode, output = sys.argv[1], Path(sys.argv[2])
    if mode == "exec":
        os.execv(sys.executable, [sys.executable, "-B", __file__, "hold", str(output)])
    if mode == "echo":
        secret = b"SYNTHETIC-CREDENTIAL-NOT-REAL-0123456789"
        os.write(1, b"before:" + secret[:11])
        time.sleep(0.02)
        os.write(2, secret[11:] + b":after\n")
        return 0
    if mode == "blocked":
        import asyncio
        from acquire01 import bounded_loop

        async def blocked():
            await asyncio.wait_for(asyncio.to_thread(time.sleep, 5), timeout=0.02)

        bounded_loop(blocked(), output)
        return 2
    if mode == "hold":
        from freeze01 import write
        write(output / "fake-serving-identity.json", dict(
            synthetic=True, pid=os.getpid(), session=os.getsid(0), group=os.getpgrp()))
        signal.signal(signal.SIGTERM, lambda signum, frame: None)
        time.sleep(5)
        return 0
    raise ValueError("unknown_benign_fixture_mode")


if __name__ == "__main__":
    raise SystemExit(main())
