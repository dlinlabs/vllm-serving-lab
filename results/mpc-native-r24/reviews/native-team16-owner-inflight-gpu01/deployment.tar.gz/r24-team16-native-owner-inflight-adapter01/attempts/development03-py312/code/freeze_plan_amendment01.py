"""Preserve the rejected plan; freeze a source-compatible seed-only successor."""

from copy import deepcopy
import json
from pathlib import Path
import time

from freeze01 import HERE, sha, verify, write


def main():
    if Path.cwd().resolve() != HERE:
        raise ValueError("exclusive_amendment_scope")
    verify(True)
    original = json.loads(Path("NATIVE_PLAN.json").read_bytes())
    if original["trials"][0]["seed"] != 170103:
        raise ValueError("unexpected_predecessor_seed")
    plan = deepcopy(original)
    plan["trials"][0]["seed"] = 170003
    write("NATIVE_PLAN.revision01.json", plan)
    source = "inputs/preflight/inputs/source-tree/experiments/mpc-research/native-v2/batch_capture_bridge.py"
    write("PLAN_AMENDMENT01.json", dict(
        schema="team16-source-compatible-capture-seed-amendment-v1",
        frozen_at_unix=time.time(), corrected_plan_controls_started=False,
        native_execution=False, Mayor_review_before_any_future_execution=True,
        detected_by="attempts/development02-py314/output.log",
        detection_sha256=sha("attempts/development02-py314/output.log"),
        original_plan="NATIVE_PLAN.json", original_sha256=sha("NATIVE_PLAN.json"),
        effective_plan="NATIVE_PLAN.revision01.json", effective_sha256=sha("NATIVE_PLAN.revision01.json"),
        source=source, source_sha256=sha(source), source_guard="validate_plan lines23-31: TRAIN seed170001..170012",
        change=dict(JSON_pointer="/trials/0/seed", before=170103, after=170003),
        rationale="The first candidate plan was rejected before synthetic protocol execution. Select an existing permitted TRAIN seed; never weaken the source guard.",
        unchanged=["payload", "prompt", "20ms trigger", "request IDs", "capture ID", "CAS", "fixed32",
                   "one warmup plus two managed cap16 offers", "all budgets", "source/closure/clock/stock gates"],
        old_plan_and_all_failures_retained=True,
        not_outcome_tuning="No source cut or inference outcome existed in the failed controls. No Native execution.",
        actual_application_at=None, native_mpc_permitted=False))
    print(json.dumps(dict(plan_sha256=sha("NATIVE_PLAN.revision01.json"),
                          amendment_sha256=sha("PLAN_AMENDMENT01.json")), sort_keys=True))


if __name__ == "__main__":
    main()
