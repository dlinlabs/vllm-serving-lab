"""Bounded real-async overlap; all HTTP is MockTransport, never sockets."""

import asyncio
import json
import time

import httpx
import pytest

import acquire01 as a
import common01 as c
from transport01 import Capture


SECRET = "SYNTHETIC-INFLIGHT-CREDENTIAL-NOT-REAL"


def client(handler):
    return httpx.AsyncClient(base_url="http://127.0.0.1:8080",
                              transport=httpx.MockTransport(handler), timeout=0.2)


def test_source_GET_and_flush_finish_before_pending_managed_POST_without_settings_race(tmp_path):
    async def scenario():
        entered, release = asyncio.Event(), asyncio.Event()
        observed = []
        async def handler(request):
            observed.append((request.url.path, dict(request.extensions["timeout"])))
            if request.url.path == "/v1/chat/completions":
                entered.set()
                await release.wait()
            return httpx.Response(200, json={"kind": request.url.path})
        wire = a.Wire(tmp_path, SECRET, c.domain(), client(handler), client(handler))
        task = asyncio.create_task(wire.call("gateway", "POST", "/v1/chat/completions",
            role="managed-control", identifier="a" * 32, payload={"max_tokens": 16},
            deadline=time.monotonic() + 1, limit=0.8))
        try:
            await asyncio.wait_for(entered.wait(), 0.2)
            native = await asyncio.to_thread(wire.sync, "native", "/pr33-native/phase-state",
                                             role="concurrent-native", deadline=time.monotonic() + 0.2)
            gateway = await wire.call("gateway", "GET", "/admin/mpc/state",
                                      role="concurrent-gateway", deadline=time.monotonic() + 0.2)
            flush = await wire.call("gateway", "POST", "/admin/mpc/flush-prefix",
                                    role="concurrent-flush", payload={}, deadline=time.monotonic() + 0.2)
            assert not task.done()
            assert [native["sequence"], gateway["sequence"], flush["sequence"]] == [1, 2, 3]
            assert not (tmp_path / "http/000.json").exists()
            assert (tmp_path / "http-reservations/000.json").exists()
            assert all((tmp_path / "http" / f"{n:03d}.json").exists() for n in (1, 2, 3))
            release.set()
            post = await asyncio.wait_for(task, 0.2)
            assert post["sequence"] == 0 and post["call_settings"]["http_timeout_s"] > 0.7
            assert all(row["call_settings"]["http_timeout_s"] <= 0.2 for row in (native, gateway, flush))
            assert observed[0][1]["read"] > 0.7 and all(t["read"] <= 0.2 for _, t in observed[1:])
            assert post["client_send_at"] < native["client_send_at"] < native["client_receive_at"] < post["client_receive_at"]
            assert len({row["sequence"] for row in wire.capture.records}) == 4
            with pytest.raises(TypeError):
                wire.capture.settings["http_timeout_s"] = 100
        finally:
            release.set()
            await wire.close()
            await asyncio.gather(task, return_exceptions=True)
    asyncio.run(scenario())


def test_global_cap_is_atomic_under_simultaneous_reservations_and_reverse_completions(tmp_path):
    async def scenario():
        api = c.preflight().frozen.control()
        capture = Capture(tmp_path, dict(maximum_http_exchanges=3, body_cap_bytes=1024),
                          SECRET, c.domain(), clock=time.monotonic, api=api)
        gates = [asyncio.Event() for _ in range(3)]
        arrivals = []
        async def handler(request):
            n = int(request.url.path[1:])
            arrivals.append(n)
            await gates[n].wait()
            return httpx.Response(200, json={"n": n})
        http = client(handler)
        tasks = [asyncio.create_task(capture.exchange(http, "GET", "/" + str(n), role="quota",
                  deadline=time.monotonic() + 1, limit=0.8)) for n in range(6)]
        try:
            await asyncio.sleep(0)
            assert arrivals == [0, 1, 2]
            assert len(capture.records) == len(capture.refusals) == 3
            for n in (2, 1, 0):
                gates[n].set()
                await asyncio.sleep(0)
            results = await asyncio.gather(*tasks, return_exceptions=True)
            assert all(isinstance(row, dict) for row in results[:3])
            assert all(isinstance(row, ValueError) for row in results[3:])
            assert sorted(p.name for p in (tmp_path / "http").glob("*.json")) == ["000.json", "001.json", "002.json"]
            assert len(list((tmp_path / "http-refusals").glob("*.json"))) == 3
            assert [json.loads(p.read_bytes())["sequence"] for p in sorted((tmp_path / "http").glob("*.json"))] == [0, 1, 2]
            assert [row["sequence"] for row in sorted(capture.records, key=lambda row: row["client_receive_at"])] == [2, 1, 0]
        finally:
            await capture.close()
            await http.aclose()
            await asyncio.gather(*tasks, return_exceptions=True)
    asyncio.run(scenario())


@pytest.mark.parametrize("kind", ["late", "unknown", "credential"])
def test_late_unknown_and_redacted_echo_evidence_never_pass_source_body(tmp_path, kind):
    async def scenario():
        now = [1.0]
        async def handler(request):
            if kind == "late":
                now[0] += 0.3
                return httpx.Response(200, json={"late": True})
            if kind == "credential":
                return httpx.Response(200, json={"echo": SECRET}, headers={"x-request-id": SECRET})
            return httpx.Response(200, content=b"unknown-non-JSON-output")
        wire = a.Wire(tmp_path, SECRET, c.domain(), client(handler), client(handler), clock=lambda: now[0])
        try:
            if kind in ("late", "credential"):
                with pytest.raises(ValueError):
                    await wire.call("native", "GET", "/pr33-native/phase-state", role=kind, deadline=1.2)
            else:
                row = await wire.call("native", "GET", "/pr33-native/phase-state", role=kind, deadline=1.2)
                with pytest.raises(ValueError):
                    wire.api.body(row)
            row = c.load(tmp_path / "http/000.json")
            assert (kind != "late" or row["error_type"] == "LateReceipt")
            assert SECRET not in (tmp_path / "http/000.json").read_text()
            if kind == "credential":
                import base64
                assert SECRET.encode() not in base64.b64decode(row["response_body_base64"])
                assert row["credential_removed"]
        finally:
            await wire.close()
    asyncio.run(scenario())


def test_capture_cleanup_failure_still_closes_both_owned_clients(tmp_path, monkeypatch):
    async def scenario():
        async def handler(request):
            return httpx.Response(200)
        wire = a.Wire(tmp_path, SECRET, c.domain(), client(handler), client(handler))
        async def refuse():
            raise ValueError("synthetic_capture_cleanup_refusal")
        monkeypatch.setattr(wire.capture, "close", refuse)
        with pytest.raises(ValueError, match="owned_transport_cleanup_refused"):
            await wire.close()
        assert wire.native.is_closed and wire.gateway.is_closed
        receipt = c.load(tmp_path / "client-transports-cleanup.json")
        assert receipt["joined"] and receipt["errors"][0]["phase"] == "capture"
    asyncio.run(scenario())


@pytest.mark.parametrize("defect", ["stale", "future_available", "unknown_clock", "unknown_receipt",
                                  "unknown_source", "unknown_epoch", "source_before_dispatch"])
def test_prior_empty_cut_cannot_be_promoted_by_stale_unknown_future_chronology(defect):
    from copy import deepcopy
    from coverage01 import assess
    root = c.HERE / "inputs/prior-native01/native-output/client"
    journal = c.load(root / "offer-1-cut.json")
    prior = c.load(root / "result.json")
    row = c.load(root / "http" / f'{prior["offers"][0]["record"]:03d}.json')
    row["dispatch_attempted"] = True
    returned = journal["phases"]["classified_at"] + 0.0001
    deadline = prior["active_started_at"] + 20
    baseline = assess(journal, row, row["request_id"], returned_at=returned, deadline=deadline)
    assert baseline["status"] == "source_after_outcome" and not baseline["nonempty_overlap"]
    damaged = deepcopy(journal)
    if defect == "stale":
        returned += 0.6
    elif defect == "future_available":
        returned = journal["cut"]["validated_at"] - 0.0001
    elif defect == "unknown_clock":
        row["client_clock_domain"] = "unknown"
    elif defect == "unknown_receipt":
        row["client_receive_at"] = None
    elif defect == "unknown_source":
        damaged["cut"]["native_observation"]["native_phase"]["source_sha256"] = "0" * 64
    elif defect == "unknown_epoch":
        damaged["cut"]["native_observation"]["base"]["run_id"] = "other_epoch"
    else:
        row["client_send_at"] = journal["cut"]["cut_at"] + 0.0001
        row["client_receive_at"] = row["client_send_at"] + 0.1
    with pytest.raises(ValueError):
        assess(damaged, row, row["request_id"], returned_at=returned, deadline=deadline)


def test_prior_raw_seal_and_empty_inventory_are_only_prior_evidence():
    import replay01
    result = replay01.prior_empty_evidence()
    assert result["prior_engineering_component_pass"] and not result["nonempty_coverage_established"]
    assert result["live_procfs_reproved"] is False


def test_effective_plan_repairs_invalid_seed_without_weakening_source_guard():
    from copy import deepcopy
    validator = c.preflight().frozen.module("batch_capture_bridge").validate_plan
    original = c.load(c.HERE / "NATIVE_PLAN.json")
    with pytest.raises(ValueError, match="non-TRAIN"):
        validator(original)
    repaired = c.load(c.PLAN)
    assert validator(repaired) == {repaired["trials"][0]["trial_id"]: "light"}
    expected = deepcopy(original)
    expected["trials"][0]["seed"] = 170003
    assert repaired == expected


def test_duplicate_ID_refuses_without_another_dispatch_even_while_first_is_pending(tmp_path):
    async def scenario():
        entered = asyncio.Event()
        calls = []
        async def handler(request):
            calls.append(request)
            entered.set()
            await asyncio.Event().wait()
        wire = a.Wire(tmp_path, SECRET, c.domain(), client(handler), client(handler))
        task = asyncio.create_task(wire.call("gateway", "POST", "/v1/chat/completions",
            role="managed", identifier="b" * 32, deadline=time.monotonic() + 1, limit=0.8))
        try:
            await asyncio.wait_for(entered.wait(), 0.2)
            with pytest.raises(ValueError, match="duplicate_or_invalid"):
                await wire.call("gateway", "POST", "/v1/chat/completions", role="duplicate",
                                identifier="b" * 32, deadline=time.monotonic() + 0.2)
            assert len(calls) == 1 and len(wire.capture.records) == 1
        finally:
            await wire.close()
            await asyncio.gather(task, return_exceptions=True)
        row = c.load(tmp_path / "http/000.json")
        assert row["error_type"] == "CancelledError" and not row["body_complete"]
        assert not wire.capture.active
    asyncio.run(scenario())


def test_concurrent_close_retains_both_partial_cancelled_exchanges_and_joins(tmp_path):
    async def scenario():
        events = {"/one": asyncio.Event(), "/two": asyncio.Event()}
        async def handler(request):
            events[request.url.path].set()
            await asyncio.Event().wait()
        wire = a.Wire(tmp_path, SECRET, c.domain(), client(handler), client(handler))
        tasks = [asyncio.create_task(wire.call(
            target, "GET", path, role="cancel-control", deadline=time.monotonic() + 1, limit=0.8))
            for target, path in (("native", "/one"), ("gateway", "/two"))]
        await asyncio.wait_for(asyncio.gather(*(event.wait() for event in events.values())), 0.2)
        began = time.monotonic()
        await wire.close()
        results = await asyncio.gather(*tasks, return_exceptions=True)
        assert time.monotonic() - began < 0.5
        assert all(isinstance(row, asyncio.CancelledError) for row in results)
        assert all(c.load(tmp_path / "http" / f"{n:03d}.json")["error_type"] == "CancelledError" for n in (0, 1))
        assert not wire.capture.active
    asyncio.run(scenario())


def test_source_permit_refusal_is_retained_before_any_dispatch(tmp_path):
    async def scenario():
        async def handler(request):
            pytest.fail("stale observation caused a request")
        wire = a.Wire(tmp_path, SECRET, c.domain(), client(handler), client(handler))
        def refuse():
            raise ValueError("synthetic_stale_source")
        try:
            with pytest.raises(ValueError, match="synthetic_stale_source"):
                await wire.call("gateway", "POST", "/v1/chat/completions", role="unsent",
                    identifier="c" * 32, before_send=refuse, deadline=time.monotonic() + 0.2)
            row = c.load(tmp_path / "http/000.json")
            assert row["dispatch_attempted"] is False and row["client_send_at"] is None
            assert row["error_type"] == "ValueError"
        finally:
            await wire.close()
    asyncio.run(scenario())
