"""Mayor-only, single-attempt, owned Source13 launch for the frozen fixed control probe."""

import argparse
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
import launch_common as c


def alarm(signum, frame):
    raise TimeoutError("owned_launch_phase_deadline")


def arm(deadline):
    remaining = deadline - time.monotonic()
    c.require(remaining > 0, "owned_launch_deadline_reached")
    signal.setitimer(signal.ITIMER_REAL, remaining)


def monitor(process, owner, owned, startup_deadline, cancelled, *, directory=c.PUBLIC):
    phase, teardown_at = "startup", None
    deadline = startup_deadline
    while process.poll() is None and not cancelled:
        owner.remember_adopted(owned)
        if (directory / "attach-finished.json").exists():
            end = c.load(directory / "attach-finished.json")["finished_at"]
            start = c.load(directory / "attach-start.json")["started_at"]
            c.require(start <= startup_deadline and start <= end <= start + 23
                      and end <= time.monotonic(), "late_or_future_attach_receipt")
            if teardown_at is None:
                teardown_at = end
            phase, deadline = "normal_child_cleanup", teardown_at + 7
        elif (directory / "attach-start.json").exists():
            start = c.load(directory / "attach-start.json")["started_at"]
            c.require(start <= startup_deadline and start <= time.monotonic(), "attach_after_startup_deadline")
            phase, deadline = "attach", start + 23
        if time.monotonic() >= deadline:
            return dict(phase=phase, deadline_reached=True, teardown_at=teardown_at)
        arm(teardown_at + 40 if teardown_at is not None else deadline)
        time.sleep(0.1)
    return dict(phase=phase, deadline_reached=False, teardown_at=teardown_at)


def completion_bounds(result, directory=c.PUBLIC):
    try:
        start = c.load(directory / "attach-start.json")
        end = c.load(directory / "attach-finished.json")
        points = [result["started_at"], start["started_at"], end["finished_at"],
                  result["teardown_started_at"], result["teardown_finished_at"], result["finished_at"]]
        return (all(type(point) in (int, float) and math.isfinite(point) for point in points)
                and result["clock_domain"] == start["clock_domain"] == end["clock_domain"]
                and points[0] <= points[1] <= points[0] + 180
                and points[1] <= points[2] <= points[1] + 23
                and points[2] == points[3] <= points[4] <= points[3] + 40
                and points[4] <= points[5] <= min(points[4] + 17, points[0] + 260))
    except (OSError, ValueError, KeyError, TypeError):
        return False


def request_child_cancel(owner, owned, directory=c.PUBLIC):
    marker = directory / "native-child-identity.json"
    if not marker.exists():
        return False
    value = c.load(marker)
    pid = value["pid"]
    if owned.get(pid) != value["start_ticks"] or not owner.alive(pid, owned):
        return False
    descriptor = os.pidfd_open(pid)
    try:
        if owner.alive(pid, owned):
            signal.pidfd_send_signal(descriptor, signal.SIGTERM)
    except ProcessLookupError:
        pass
    finally:
        os.close(descriptor)
    return True


def cleanup(process, owner, owned, deadline, directory=c.PUBLIC, *, cancel_child=True, events=None):
    arm(deadline)
    owner.remember_adopted(owned)
    if process.poll() is None and cancel_child:
        try:
            cancelled = request_child_cancel(owner, owned, directory)
            if events is not None:
                events.append(dict(action="owned_child_cancel", sent=cancelled))
        except (OSError, ValueError, KeyError, TypeError) as error:
            if isinstance(error, TimeoutError):
                raise
            if events is not None:
                events.append(dict(action="owned_child_cancel_refused", error_type=type(error).__name__))
        grace_end = min(deadline - 33, time.monotonic() + 7)
        while process.poll() is None and time.monotonic() < grace_end:
            owner.remember_adopted(owned)
            time.sleep(0.1)
    survivors = owner.terminate_owned(owned, process, grace=0)
    process.wait(timeout=max(0.01, min(2, deadline - time.monotonic())))
    c.require(time.monotonic() <= deadline, "owned_cleanup_deadline_exceeded")
    return survivors


def complete_child_outcome(outcome, teardown_started, teardown_finished):
    return (isinstance(outcome, dict) and outcome.get("status") == "fixed_client_finished"
            and type(outcome.get("client_returncode")) is int and outcome["client_returncode"] == 0
            and outcome.get("installed_sources_unchanged") is True
            and outcome.get("candidate_sources_unchanged") is True
            and outcome.get("postflight_status") == "completed"
            and "error_type" not in outcome and "postflight_error_type" not in outcome
            and type(outcome.get("postflight_started_at")) in (int, float)
            and type(outcome.get("finished_at")) in (int, float)
            and teardown_started <= outcome["postflight_started_at"] <= outcome["finished_at"]
            <= min(teardown_started + 7, teardown_finished))


def teardown_anchor(result, directory, now):
    marker = directory / "attach-finished.json"
    if marker.exists():
        try:
            end = c.load(marker)["finished_at"]
            start = c.load(directory / "attach-start.json")["started_at"]
            c.require(type(end) in (int, float) and type(start) in (int, float)
                      and result["started_at"] <= start <= result["started_at"] + 180
                      and start <= end <= min(start + 23, now), "unknown_teardown_receipt")
            return end
        except (OSError, ValueError, KeyError, TypeError):
            result["errors"].append("unknown_teardown_receipt")
    return now


def offer_inventory(directory=c.PUBLIC, client_output=c.CLIENT_OUTPUT):
    warmup = directory / "startup-native/warmup-offered.json"
    index = client_output / "index.json"
    raw_offers, receipt_errors = [], []
    for path in sorted((client_output / "http").glob("*.json")):
        try:
            row = c.load(path)
        except (ValueError, OSError) as error:
            receipt_errors.append(dict(path=str(path.relative_to(client_output)),
                                       error_type=type(error).__name__))
            continue
        if not isinstance(row, dict):
            receipt_errors.append(dict(path=str(path.relative_to(client_output)),
                                       error_type="unknown_HTTP_receipt_shape"))
            continue
        if row.get("path") == "/v1/chat/completions":
            raw_offers.append(dict(path=str(path.relative_to(client_output)),
                                   request_id=row.get("request_id"), error_type=row.get("error_type"),
                                   http_status=row.get("http_status")))
    try:
        document = c.load(index) if index.exists() else None
    except (ValueError, OSError) as error:
        document = None
        receipt_errors.append(dict(path="index.json", error_type=type(error).__name__))
    if document is not None and not isinstance(document, dict):
        document = None
        receipt_errors.append(dict(path="index.json", error_type="unknown_client_index_shape"))
    started = (directory / "attach-start.json").exists()
    preflight_refused = bool(document and document.get("schema") ==
                            "team16-fixed-control-probe-preflight-refusal-v1")
    offers = document.get("offers") if document else None
    if document and not preflight_refused and (
            document.get("schema") != "team16-fixed-control-probe-result-v2"
            or not isinstance(offers, list) or len(offers) != 8
            or any(not isinstance(row, dict) or row.get("index") != index or "status" not in row
                   for index, row in enumerate(offers))):
        receipt_errors.append(dict(path="index.json", error_type="unknown_client_offer_inventory"))
        offers = None
    if offers is None:
        offers = [dict(index=number, status="not_sent" if not started or preflight_refused else "unobserved")
                  for number in range(8)]
    return dict(
        startup_warmup_planned=1, startup_warmup_send_attempted=warmup.exists(),
        startup_warmup_receipts="startup-native/http/",
        startup_terminal_observation=(directory / "startup-native/warmup-fate.json").exists(),
        client_planned=8, client_started=started, client_index_present=document is not None,
        client_offers=offers, raw_receipt_errors=receipt_errors,
        client_reported_attempted=document.get("offered_attempted") if document is not None else None,
        observed_partial_client_offer_receipts=raw_offers,
        missing_receipt_is_not_proof_of_no_send=True,
        maximum_combined_offers=9, maximum_combined_requested_completion_tokens=144)


def main():
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--execute-on-existing-gpu", action="store_true", required=True)
    parser.parse_args()
    c.require_remote()
    started = time.monotonic()
    signal.signal(signal.SIGALRM, alarm)
    arm(started + 180)
    c.verify_runnable()
    c.create_attempt()
    result = dict(schema="team16-owned-fixed-control-supervision-v1",
                  started_at=started, amendment_sha256=c.sha(c.HERE / "AMENDMENT02.json"),
                  child_started=False, returncode=None, errors=[],
                  native_mpc_permitted=False, deployable=False)
    process, root_fd, owner, secret = None, None, None, ""
    owned, survivors, cancelled = {}, [], []
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(sig, lambda signum, frame: cancelled.append(signum))
    cache, config_path = c.STATE / "python-cache-evidence", c.STATE / "control.private.json"
    try:
        clock = c.clock_helpers()
        env = clock.native_environment(c.STATE, cache)
        env["MPC_OWNER_LEDGER_ENABLED"] = "true"
        os.environ["TMPDIR"] = env["TMPDIR"]
        preflight = c.module("_fixed_control_prelaunch", c.CLIENT / "prelaunch01.py")
        receipt = preflight.make_receipt(c.STATE / "t", c.STATE)
        c.write(c.STATE / "tmpdir-preflight.json", receipt)
        (c.STATE / "tmpdir-preflight.json").chmod(0o600)
        c.write(c.PUBLIC / "tmpdir-preflight.json", receipt)
        result["clock_domain"] = receipt["clock_domain"]
        result["source_before"] = clock.source_binding(cache)
        result["gpu_before"] = clock.gpu_inventory()
        clock.require_idle(result["gpu_before"])
        c.require(c.ALIAS.is_symlink() and c.ALIAS.resolve() == c.MODEL,
                  "existing_immutable_alias_required")
        config = c.private_config()
        secret = config["ADMIN_API_KEY"]
        owner = c.owners()
        owner.enable_subreaper()
        command = c.guarded([
            c.NATIVE, "-I", "-B", "-X", "pycache_prefix=" + str(cache),
            c.HERE / "launch_native.py", "--owned", "--startup-deadline", str(started + 180)])
        result["command"] = command
        with (c.PUBLIC / "native-child.log").open("xb") as log:
            process = subprocess.Popen(command, cwd=c.HERE, env=env, stdout=log,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            result["child_started"] = True
            root_fd = os.pidfd_open(process.pid)
            owner.remember(process.pid, owned, parent=os.getpid())
            result["monitor"] = monitor(process, owner, owned, started + 180, cancelled, directory=c.PUBLIC)
            if result["monitor"]["deadline_reached"]:
                result["phase_failure"] = ("natural_child_postflight_window_exhausted"
                    if result["monitor"]["phase"] == "normal_child_cleanup" else "startup_or_attach_deadline_reached")
                raise TimeoutError(result["phase_failure"])
    except BaseException as error:
        result["errors"].append(type(error).__name__)
    finally:
        teardown_at = teardown_anchor(result, c.PUBLIC, time.monotonic())
        cleanup_deadline = min(started + 243, teardown_at + 40)
        result["teardown_started_at"] = teardown_at
        result["cleanup_events"] = []
        if process is not None:
            try:
                normal = result.get("monitor", {}).get("phase") == "normal_child_cleanup"
                survivors = cleanup(process, owner, owned, cleanup_deadline, c.PUBLIC,
                                    cancel_child=not normal, events=result["cleanup_events"])
                result["returncode"] = process.returncode
                if any("error_type" in event for event in result["cleanup_events"]):
                    result["errors"].append("owned_cancel_receipt_refused")
            except BaseException as error:
                result["errors"].append("cleanup:" + type(error).__name__)
                survivors = [pid for pid in owned if owner.alive(pid, owned)]
            finally:
                if root_fd is not None:
                    os.close(root_fd)
        result["owned_joined"] = (process is None or process.returncode is not None) and not survivors
        result["teardown_finished_at"] = time.monotonic()
        if result["owned_joined"] and config_path.exists():
            config_path.unlink()
        result["private_config_removed_after_join"] = not config_path.exists()
        result["public_evidence_credentials_absent"] = False
        try:
            arm(min(started + 260, result["teardown_finished_at"] + 17))
            result["offered"] = offer_inventory(c.PUBLIC, c.CLIENT_OUTPUT)
            c.require(result["owned_joined"], "DO_NOT_EXPORT_owned_writers_remain")
            result["source_after"] = c.clock_helpers().source_binding(cache)
            result["sources_unchanged"] = result.get("source_before") == result["source_after"]
            result["gpu_after"] = c.clock_helpers().gpu_inventory()
            c.clock_helpers().require_idle(result["gpu_after"])
            c.verify_runnable()
            result["candidate_sources_unchanged"] = True
            result["public_evidence_credentials_absent"] = (
                c.public_credentials_absent((c.PUBLIC, c.CLIENT_OUTPUT), secret) if secret else
                not result["child_started"])
            c.require(result["public_evidence_credentials_absent"], "DO_NOT_EXPORT_CREDENTIAL_REFUSAL")
            result["raw_files"] = c.evidence_index()
            result["independent_client_replay_valid"] = False
            if result["child_started"]:
                candidate_replay = c.client_library().replay(c.CLIENT_OUTPUT)
                reported_replay = c.load(c.CLIENT_OUTPUT / "replay.json")
                result["independent_client_replay_valid"] = (
                    candidate_replay == reported_replay and candidate_replay["component_contract_pass"] is True
                    and candidate_replay["actual_application_deadline_proved"] is True
                    and isinstance(candidate_replay.get("terminal_observation"), dict)
                    and candidate_replay["terminal_observation"].get("observed_empty_at_two_intervals") is True)
        except BaseException as error:
            result["errors"].append("postflight:" + type(error).__name__)
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
        result.update(
            owned_pid_start_ticks={str(pid): tick for pid, tick in owned.items()},
            surviving_owned_pids=survivors, child_subreaper=owner is not None,
            interrupted_signals=cancelled, finished_at=time.monotonic(),
            application_timing="interval_censored_never_acknowledgement_as_application")
        outcome = {}
        if result["child_started"]:
            try:
                outcome = c.load(c.PUBLIC / "component-outcome.json")
            except (OSError, ValueError):
                result["errors"].append("missing_or_unknown_child_outcome")
        result["phase_deadlines_satisfied"] = completion_bounds(result, c.PUBLIC)
        result["child_outcome_complete"] = complete_child_outcome(
            outcome, result["teardown_started_at"], result["teardown_finished_at"])
        result["component_completed"] = bool(
            result["returncode"] == 0 and result["owned_joined"]
            and result.get("sources_unchanged") and result["public_evidence_credentials_absent"]
            and result.get("candidate_sources_unchanged") and not result["errors"] and not cancelled
            and result["child_outcome_complete"] and result.get("independent_client_replay_valid")
            and result["phase_deadlines_satisfied"]
            and result["private_config_removed_after_join"])
        c.write(c.PUBLIC / "supervision.json", result)
        c.write(c.PUBLIC / "result-index.json", dict(
            schema="team16-owned-fixed-control-result-index-v1",
            component_completed=result["component_completed"],
            export_permitted=result["public_evidence_credentials_absent"],
            supervision="supervision.json", client_result=str(c.CLIENT_OUTPUT),
            client_replay=str(c.CLIENT_OUTPUT / "replay.json"),
            all_offered=result.get("offered"), raw_files=result.get("raw_files", []),
            failures=result["errors"], native_mpc_permitted=False, deployable=False))
    print(__import__("json").dumps(dict(
        component_completed=result["component_completed"], public_result=str(c.PUBLIC),
        export_permitted=result["public_evidence_credentials_absent"], surviving_owned_pids=survivors)))
    return 0 if result["component_completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
