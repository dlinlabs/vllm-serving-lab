"""Two-offer fixed32 protocol using unchanged source closure/cut contracts."""

import asyncio
import base64
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
from copy import deepcopy
from dataclasses import asdict
import json
import os
from pathlib import Path
import re
import signal
import sys
import threading
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common01 as c


class Wire:
    """Source worker callbacks wait on bounded async I/O, not blocking sockets."""
    def __init__(self, output, secret, domain, native, gateway, *, clock=time.monotonic):
        self.pre = c.preflight()
        self.api = self.pre.frozen.control()
        self.clock, self.native, self.gateway = clock, native, gateway
        self.loop, self.pending = asyncio.get_running_loop(), set()
        settings = dict(self.pre.frozen.settings(), http_timeout_s=0.2,
                        maximum_http_exchanges=1900, body_cap_bytes=1048576)
        self.capture = self.api.Capture(output, settings, secret, domain, clock=clock)
        self.lock = asyncio.Lock()

    async def call(self, target, method, path, *, role, payload=None, auth=True,
                   identifier=None, deadline, limit=0.2):
        timeout = min(limit, deadline - self.clock())
        c.require(timeout > 0, "HTTP_absolute_deadline")
        # Capture.exchange preserves its cancelled/late/incomplete record in finally.
        async with asyncio.timeout(timeout):
            async with self.lock:
                previous = self.capture.settings
                self.capture.settings = dict(previous, http_timeout_s=timeout)
                try:
                    record = await self.capture.exchange(
                        self.native if target == "native" else self.gateway, method, path,
                        role=role, payload=payload, auth=auth, identifier=identifier)
                    c.require(self.clock() <= deadline
                              and record["client_receive_at"] - record["client_send_at"] <= timeout,
                              "HTTP_late_receipt_retained")
                    c.require(record["credential_removed"] is False, "HTTP_credential_echo_retained_redacted")
                    return record
                finally:
                    self.capture.settings = previous

    def sync(self, target, path, *, deadline, role):
        future = asyncio.run_coroutine_threadsafe(self.call(
            target, "GET", path, role=role, deadline=deadline), self.loop)
        self.pending.add(future)
        try:
            return future.result(timeout=min(0.2, max(0.001, deadline - self.clock())))
        except FutureTimeout:
            future.cancel()
            raise TimeoutError("owned_sync_HTTP_200ms") from None
        finally:
            self.pending.discard(future)

    def response(self, record):
        import httpx
        self.api.body(record)
        return httpx.Response(record["http_status"],
                              content=base64.b64decode(record["response_body_base64"]),
                              request=httpx.Request(record["method"], "http://127.0.0.1" + record["path"]))

    def gateway_clients(self, deadline):
        wire = self

        class Sync:
            def get(self, path):
                c.require(path == "/admin/mpc/state", "only_source_gateway_GET")
                return wire.response(wire.sync("gateway", path, deadline=deadline, role="cut-gateway"))

        class Async:
            async def post(self, path, **kwargs):
                c.require(path == "/admin/mpc/flush-prefix", "only_source_gateway_flush")
                return wire.response(await wire.call(
                    "gateway", "POST", path, role="cut-flush", payload=kwargs["json"],
                    deadline=deadline))

        return Sync(), Async()

    async def close(self):
        for future in tuple(self.pending):
            future.cancel()
        async with asyncio.timeout(0.2):
            await self.native.aclose()
            await self.gateway.aclose()


def persist_prefix(output, name, cut, telemetry):
    size = cut["owner_prefix"]["prefix_bytes"]
    c.require(type(size) is int and 0 <= size <= 33554432, "prefix_capacity")
    with Path(telemetry).open("rb") as handle:
        raw = handle.read(size)
    c.require(len(raw) == size and c.sha_bytes(raw) ==
              cut["owner_prefix"]["receipt"]["prefix_sha256"], "retained_prefix_byte_binding")
    path = output / (name + "-prefix.jsonl")
    with path.open("xb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    return dict(path=path.name, bytes=size, sha256=c.sha(path))


async def collect_one(wire, startup, output, name, *, deadline, memory, process,
                      telemetry, closure=None):
    pre, api = wire.pre, wire.api
    gateway_sync, gateway_async = wire.gateway_clients(deadline)
    snapshot = api.body(startup["gateway_initial_record"])
    options = dict(
        native_process=process, native_sources=pre.frozen.sources(),
        expected_capture_id=c.load(c.PLAN)["trials"][0]["trial_id"],
        gateway_sync=gateway_sync, gateway_async=gateway_async,
        telemetry_path=telemetry, expected_run_id=snapshot["run_id"],
        expected_clock_domain=snapshot["clock_domain"], expected_identity=snapshot["identity"],
        initial_budget=32, public_memory=memory, max_age_s=0.5)
    journal = {}
    native_get = lambda: wire.sync(
        "native", "/pr33-native/phase-state", deadline=deadline, role=name + "-native")
    try:
        async with asyncio.timeout(max(0, deadline - wire.clock())):
            if closure is None:
                closure, journal = await pre.collect_initial(
                    enabled=True, startup=startup, native_get=native_get, journal=journal,
                    deadline=deadline, clock=wire.clock, **options)
                cut = journal["cut"]
            else:
                def native_body():
                    record = native_get()
                    journal["native_record"] = deepcopy(record)
                    pre.receipt_body(record, method="GET", path="/pr33-native/phase-state",
                                     cutoff=wire.clock())
                    settings = dict(pre.frozen.settings(), final_queue_path="/pr33-native/phase-state")
                    frame, _ = api.full_queue_observation(
                        record, settings, native_run=startup["native_owned"]["readiness"]["frames"][0]["run_id"],
                        deadline=deadline)
                    phase = frame["native_phase"]
                    c.require(record["client_send_at"] <= phase["source_at"] <=
                              phase["sample_finished_at"] <= record["client_receive_at"],
                              "phase_receipt_source_bracket")
                    return frame
                cut = await pre.frozen.module("clocked_owner_cut").collect_clocked_owner_cut(
                    native_acquire=native_body, native_startup=startup["native_owned"],
                    gateway_startup=startup["gateway_owned"], initial_closure=closure,
                    clock=wire.clock, **options)
                journal.update(cut=cut, status="received")
            observation = pre.inspect_cut(cut, consume_at=wire.clock(), deadline=deadline)
            phases = pre.frozen.module("source_owner_phases").classify_source_owners(
                cut, initial_closure=closure, native_startup=startup["native_owned"],
                public_memory=memory, now=wire.clock(), expected_clock_domain=snapshot["clock_domain"])
            journal.update(status="source_cut_received", observation=observation,
                           phases=phases.evidence(), closure=asdict(closure),
                           prefix=persist_prefix(output, name, cut, telemetry))
            c.write(output / (name + ".json"), journal)
            # Receipt/serialization never advances the physical source time.
            pre.inspect_cut(cut, consume_at=wire.clock(), deadline=deadline)
            return closure, journal
    except BaseException as error:
        journal.update(status="refused", **c.failure(error, wire.capture.secret))
        path = output / (name + "-refused.json")
        if not path.exists():
            c.write(path, journal)
        raise


def ready_copy(started, readiness):
    return dict(started, native_ready=True, cleanup_completed=False, readiness=readiness)


async def startup(wire, directory, started, deadline, *, sleep=asyncio.sleep):
    api, records = wire.api, wire.capture.records
    status = dict(warmup_status="not_sent", startup_samples=[], complete=False)
    c.write(directory / "startup-planned.json", dict(warmup_offers=1, max_tokens=16))
    try:
        for target in ("native", "gateway"):
            for attempt in range(180):
                try:
                    record = await wire.call(
                        target, "GET", "/health" if target == "native" else "/admin/mpc/state",
                        role="startup-health-" + target, auth=target == "gateway", deadline=deadline)
                except TimeoutError:
                    c.require(wire.clock() < deadline, "startup_health_absolute_deadline")
                    await sleep(min(1, max(0, deadline - wire.clock())))
                    continue
                if record["http_status"] == 200 and record["body_complete"]:
                    if target == "gateway":
                        value = api.snapshot(record)
                        c.require(value.budget == 32 and value.budget_version == 0
                                  and value.sequence == 0 and not value.requests, "initial_gateway_not_fresh32")
                    break
                await sleep(min(1, max(0, deadline - wire.clock())))
            else:
                raise ValueError("startup_health_count_exhausted")
        models = await wire.call("native", "GET", "/v1/models", role="model", auth=False, deadline=deadline)
        c.require(c.MODEL_ID in {r["id"] for r in api.body(models)["data"]}, "native_model_alias")
        payload = dict(model=c.MODEL_ID, messages=[dict(role="user", content="Count from one to five.")],
                       temperature=0, max_tokens=16)
        status["warmup_status"] = "send_attempted"
        c.write(directory / "warmup-offered.json", dict(request=payload, send_attempted=True,
                                                      sent_intent_at=wire.clock()))
        warm = await wire.call("native", "POST", "/v1/chat/completions", role="one-warmup",
                               payload=payload, auth=False, deadline=deadline, limit=60)
        reply = api.body(warm)
        c.require(warm["http_status"] == 200 and type(reply["usage"]["completion_tokens"]) is int
                  and 1 <= reply["usage"]["completion_tokens"] <= 16, "warmup_response_cap")
        status["warmup_status"] = "received"
        empty, epoch = [], None
        for number in range(1800):
            if number:
                await sleep(0.1)
            record = await wire.call("native", "GET", "/pr33-native/queue-state",
                                      role="startup-queue", deadline=deadline)
            sample = dict(record=record["sequence"], empty=None)
            status["startup_samples"].append(sample)
            frame, vacant = api.full_queue_observation(
                record, wire.pre.frozen.settings(), native_run=epoch, deadline=deadline)
            epoch = frame["base"]["run_id"]
            sample["empty"] = vacant
            empty = empty + [record] if vacant else []
            if len(empty) == 2:
                break
        c.require(len(empty) == 2, "startup_full_stock_not_drained")
        initial = await wire.call("gateway", "GET", "/admin/mpc/state", role="initial32", deadline=deadline)
        before = api.snapshot(initial)
        c.require(before.budget == 32 and before.budget_version == before.sequence == 0
                  and not before.requests, "initial_gateway_not_fresh32")
        native = ready_copy(started["native"], dict(
            frames=[api.body(row)["base"] for row in empty], warmup_response=reply))
        c.write(directory.parent / "native/ready.json", native)
        status["complete"] = True
        return dict(native_owned=native, warmup_record=warm, drain_records=empty,
                    gateway_initial_record=initial)
    finally:
        status["finished_at"] = wire.clock()
        c.write(directory / "startup-result.json", status)


async def bootstrap(wire, initial, started, directory, deadline):
    api = wire.api
    snapshot = api.body(initial["gateway_initial_record"])
    command = dict(schema=snapshot["schema"], run_id=snapshot["run_id"],
                   clock_domain=snapshot["clock_domain"], identity=snapshot["identity"],
                   expected_version=0, budget=32, not_after=snapshot["sampled_at"] + 0.5,
                   operation_id="team16-owner-acquisition01-bootstrap32")
    c.write(directory / "CAS-planned.json", dict(command=command, count=1))
    ack = await wire.call("gateway", "POST", "/admin/mpc/budget", role="same-budget-CAS",
                          payload=command, deadline=deadline)
    confirmation = await wire.call("gateway", "GET", "/admin/mpc/state",
                                   role="confirm-version1", deadline=deadline)
    gateway = ready_copy(started["gateway"], dict(
        snapshot=snapshot, gateway_run_id=snapshot["run_id"], clock_domain=snapshot["clock_domain"],
        same_budget_ack=dict(status="applied", command=command, acknowledgment=api.body(ack))))
    initial.update(gateway_owned=gateway, cas_command_record=ack, gateway_confirm_record=confirmation)
    # Validate genuine interval/receipt confirmation before issuing metadata or begin.
    before = api.snapshot(initial["gateway_initial_record"])
    interval = api.evaluate_step(
        dict(before_record=0, command_record=1, after_records=[2], budget=32,
             control="fresh", expected_http=200, operation_id=command["operation_id"]),
        [initial["gateway_initial_record"], ack, confirmation], before, wire.pre.frozen.settings())
    c.require(interval["actual_applied_at"] is None
              and interval["actual_application_before_deadline"] == "established_by_interval_upper"
              and api.snapshot(confirmation, binding=before).sequence == 1, "CAS_confirmation")
    c.write(directory / "CAS-confirmation.json", interval)
    c.write(directory.parent / "gateway/ready.json", gateway)
    meta = await wire.call("native", "POST", "/pr33-native/batch", role="capture-metadata",
                           payload={"operation": "metadata"}, deadline=deadline)
    initial["capture_metadata_record"] = meta
    metadata = wire.pre.receipt_body(meta, method="POST", path="/pr33-native/batch", cutoff=wire.clock())
    expected_sdk = c.load(c.SOURCE / "experiments/prefill-vllm-v030-source-map.json")
    expected_bridge = c.sha(c.SOURCE / "experiments/mpc-research/native-v2/batch_capture_bridge.py")
    c.require(metadata.get("schema") == "native-v2-batch-capture-v1"
              and metadata.get("bridge_sha256") == expected_bridge
              and metadata.get("plan_sha256") == api.sha(api.canonical(c.load(c.PLAN)))
              and metadata.get("source_commit") == c.load(c.PLAN)["source_commit"]
              and metadata.get("clock_domain") == snapshot["clock_domain"]
              and isinstance(metadata.get("run_id"), str) and bool(metadata["run_id"])
              and meta["client_send_at"] <= metadata["command_started_at"] <= meta["client_receive_at"]
              and metadata["runtime"]["source"]["files"] == expected_sdk["sha256"]
              and metadata["runtime"]["source"]["version"] == expected_sdk["version"]
              and type(metadata["runtime"]["tensor_parallel_size"]) is int
              and type(metadata["runtime"]["pipeline_parallel_size"]) is int
              and metadata["runtime"]["tensor_parallel_size"] == metadata["runtime"]["pipeline_parallel_size"] == 1
              and type(metadata["runtime"]["process_id"]) is int and metadata["runtime"]["process_id"] > 0
              and len(metadata["runtime"]["workers"]) == len(metadata["worker_clocks"]) == 1
              and metadata["runtime"]["workers"][0]["source"] == metadata["runtime"]["source"]
              and metadata["worker_clocks"][0]["clock_domain"] == snapshot["clock_domain"]
              and metadata["worker_clocks"][0]["bridge_sha256"] == expected_bridge
              and type(metadata["worker_clocks"][0]["process_id"]) is int
              and metadata["worker_clocks"][0]["process_id"] > 0,
              "metadata_source_before_capture_begin")
    proc = wire.pre.frozen.module("process_clock_provenance").LinuxProc().read(metadata["runtime"]["process_id"])
    process = dict(pid=proc.pid, start_ticks=proc.start_ticks, pid_namespace=proc.pid_namespace)
    begin = await wire.call("native", "POST", "/pr33-native/batch", role="capture-begin",
                            payload=dict(operation="begin", trial_id=c.load(c.PLAN)["trials"][0]["trial_id"]),
                            deadline=deadline)
    initial["capture_begin_record"] = begin
    wire.pre.bootstrap_inputs(initial, cutoff=wire.clock())
    c.write(directory / "bootstrap-inputs.json", initial)
    return process


async def final_drain(wire, directory, *, native_run, deadline, sleep=asyncio.sleep):
    result = dict(status="incomplete", deadline=deadline, samples=[], legacy_failure=None)
    try:
        legacy = await wire.call("native", "GET", "/pr33-native/state", role="legacy-final", deadline=deadline)
        frame = wire.api.native_state(legacy, wire.pre.frozen.settings(), native_run=native_run)
        result["legacy_record"] = legacy["sequence"]
        if not all(frame[key] == 0 for key in ("running", "waiting", "pending_batches", "frontend_unfinished")):
            result["legacy_failure"] = "legacy_final_native_not_drained_at_first_snapshot"
        consecutive = 0
        for number in range(9):
            if number:
                await sleep(0.25)
            row = await wire.call("native", "GET", "/pr33-native/queue-state",
                                   role="final-full-queue", deadline=deadline)
            item = dict(record=row["sequence"], empty=None)
            result["samples"].append(item)
            _, empty = wire.api.full_queue_observation(
                row, wire.pre.frozen.settings(), native_run=native_run, deadline=deadline)
            item["empty"] = empty
            consecutive = consecutive + 1 if empty else 0
            if consecutive == 2:
                result["status"] = "two_complete_empty_observations"
                return result
        raise ValueError("final_full_stock_not_drained")
    except BaseException as error:
        result.update(status="refused", **c.failure(error, wire.capture.secret))
        raise
    finally:
        result["finished_at"] = wire.clock()
        c.write(directory / "final-drain.json", result)


async def finish_capture(wire, directory, metadata, *, deadline):
    end = await wire.call("native", "POST", "/pr33-native/batch", role="capture-end",
                          payload={"operation": "end"}, deadline=deadline)
    document = wire.api.body(end)
    expected = wire.api.body(metadata)
    c.require(all(document.get(key) == expected[key] for key in
                  ("schema", "bridge_sha256", "plan_sha256", "source_commit", "run_id", "clock_domain"))
              and document.get("capture_valid") is True
              and end["client_send_at"] <= document["command_started_at"] <= end["client_receive_at"] <= deadline
              and document.get("validation_errors") == []
              and document.get("trial_id") == c.load(c.PLAN)["trials"][0]["trial_id"],
              "unknown_pending_or_invalid_capture_end")
    capture = document["capture"]
    raw = wire.api.canonical(capture)
    c.require(wire.api.sha(raw) == document["capture_sha256"]
              and wire.pre.frozen.module("batch_capture_bridge").capture_errors(capture, "light") == [],
              "capture_complete_source_binding")
    attempts = [row for row in wire.capture.records if row.get("role", "").startswith("managed-")
                and row["path"] == "/v1/chat/completions"]
    offered = {row["request_id"] for row in attempts}
    completed = set()
    for row in attempts:
        try:
            fate = wire.api.offer_fate(row, row["request_id"])
        except (ValueError, KeyError, TypeError):
            continue
        if fate in ("completed_stop", "completed_length"):
            completed.add(row["request_id"])
    identifiers = []
    for identifier in capture["requests"]:
        match = re.fullmatch(r"chatcmpl-([a-f0-9]{32})-[a-f0-9]{8}", identifier)
        c.require(match is not None, "capture_unknown_native_identifier")
        identifiers.append(match[1])
    c.require(len(identifiers) == len(set(identifiers)) and set(identifiers) <= offered
              and completed <= set(identifiers), "capture_offered_request_binding")
    path = directory / "retained-capture.json"
    with path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    c.require(c.sha(path) == document["capture_sha256"] and wire.clock() < deadline,
              "capture_retention_or_final_deadline")
    ack = await wire.call("native", "POST", "/pr33-native/batch", role="capture-ack",
                          payload=dict(operation="ack", trial_id=document["trial_id"],
                                       capture_sha256=document["capture_sha256"]), deadline=deadline)
    answer = wire.api.body(ack)
    c.require(answer.get("acknowledged") is True
              and ack["client_send_at"] <= answer["command_started_at"] <= ack["client_receive_at"] <= deadline
              and all(answer.get(key) == expected[key] for key in
                  ("schema", "bridge_sha256", "plan_sha256", "source_commit", "run_id", "clock_domain"))
              and wire.clock() <= deadline, "capture_ACK_source_or_deadline")
    return dict(capture_sha256=document["capture_sha256"], ack_record=ack["sequence"])


async def protocol_run(wire, directory, started, startup_deadline, tokenizer):
    rows = [dict(row, fate="not_sent", record=None, cut=None)
            for row in c.load(c.PREFLIGHT / "PROPOSED_OFFERS.json")["rows"]]
    result = dict(schema="team16-owner-acquisition-result-v1", offers=rows, failures=[],
                  native_mpc_permitted=False, actual_application_at=None, component_pass=False)
    initial, closure, active_at, began = None, None, None, False
    try:
        initial = await startup(wire, directory, started, startup_deadline)
        active_at = wire.clock()
        c.require(active_at <= startup_deadline, "startup_late")
        deadline = active_at + 20
        c.publish(directory.parent / "active-start.json", dict(
            started_at=active_at, deadline=deadline, clock_domain=wire.api.clock_domain()))
        process = await bootstrap(wire, initial, started, directory, deadline)
        began = True
        origins = c.load_origins(c.STATE / "origins")
        c.require_origins(origins, native_pid=process["pid"], gateway_pid=started["gateway"]["pid"])
        c.write(directory / "running-origins.json", origins)
        memory = {}
        telemetry = c.PUBLIC / "gateway/gateway-telemetry.jsonl"
        closure, journal = await collect_one(wire, initial, directory, "initial-cut",
            deadline=min(deadline, wire.clock() + 0.5), memory=memory, process=process, telemetry=telemetry)
        for row in rows:
            wire.pre.inspect_cut(journal["cut"], consume_at=wire.clock(), deadline=deadline)
            payload = dict(model=c.MODEL_ID, messages=[dict(role="user", content=row["prompt"])],
                           temperature=0, max_tokens=16)
            count = c.estimate_prompt(payload, tokenizer)
            memory[row["request_id"]] = wire.pre.frozen.module("live_owner_prefix").PublicRequest(count, 16)
            row.update(send_intent_at=wire.clock(), prompt_tokens=count)
            c.write(directory / ("offer-" + str(row["ordinal"]) + "-intent.json"), deepcopy(row))
            wire.pre.inspect_cut(journal["cut"], consume_at=wire.clock(), deadline=deadline)
            row["fate"] = "send_attempted"
            record = await wire.call("gateway", "POST", "/v1/chat/completions",
                role="managed-" + str(row["ordinal"]), payload=payload, auth=False,
                identifier=row["request_id"], deadline=deadline, limit=20)
            row["record"] = record["sequence"]
            try:
                row["fate"] = wire.api.offer_fate(record, row["request_id"])
            except (ValueError, KeyError, TypeError) as error:
                row.update(fate="received_unclassifiable", outcome_error=c.failure(error, wire.capture.secret))
            if record["http_status"] is not None:
                closure, journal = await collect_one(wire, initial, directory,
                    "offer-" + str(row["ordinal"]) + "-cut",
                    deadline=min(deadline, wire.clock() + 0.5), memory=memory, process=process,
                    telemetry=telemetry, closure=closure)
                row["cut"] = "offer-" + str(row["ordinal"]) + "-cut.json"
            c.require(row["fate"] in ("completed_stop", "completed_length"), "managed_offer_not_completed")
        result["initial_closure"] = asdict(closure)
    except BaseException as error:
        result["failures"].append(dict(phase="startup_or_active", **c.failure(error, wire.capture.secret)))
    finally:
        if active_at is not None:
            end = wire.clock()
            result["active_started_at"], result["active_finished_at"] = active_at, end
            final_deadline = min(active_at + 23, end + 3)
            if end > active_at + 20:
                result["failures"].append(dict(phase="active", error_type="late_active_completion"))
            try:
                if initial is not None:
                    await final_drain(wire, directory, native_run=wire.api.body(
                        initial["drain_records"][0])["base"]["run_id"], deadline=final_deadline)
                    if began:
                        result["capture_retention"] = await finish_capture(
                            wire, directory, initial["capture_metadata_record"], deadline=final_deadline)
            except BaseException as error:
                result["failures"].append(dict(phase="final", **c.failure(error, wire.capture.secret)))
        result["component_pass"] = bool(not result["failures"] and closure is not None
            and all(row["cut"] and row["fate"] in ("completed_stop", "completed_length") for row in rows)
            and result.get("capture_retention"))
        result["finished_at"] = wire.clock()
        c.write(directory / "result.json", result)
        c.publish(directory.parent / "protocol-finished.json", dict(
            finished_at=result["finished_at"], active_started_at=active_at,
            component_pass=result["component_pass"], clock_domain=wire.api.clock_domain()))
    return result


def bounded_loop(coroutine, directory):
    """Process-owned executor; an unjoinable worker means refusal, never implicit wait."""
    loop = asyncio.new_event_loop()
    executor = ThreadPoolExecutor(max_workers=3, thread_name_prefix="owner-source")
    loop.set_default_executor(executor)
    asyncio.set_event_loop(loop)
    task = loop.create_task(coroutine)
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        loop.add_signal_handler(sig, task.cancel)
    outcome, failure = None, None
    try:
        outcome = loop.run_until_complete(task)
    except BaseException as error:
        failure = type(error).__name__
    finally:
        remaining = asyncio.all_tasks(loop)
        for pending in remaining:
            pending.cancel()
        if remaining:
            loop.run_until_complete(asyncio.wait(remaining, timeout=0.2))
        executor.shutdown(wait=False, cancel_futures=True)
        until = time.monotonic() + 0.5
        for thread in tuple(executor._threads):
            thread.join(max(0, until - time.monotonic()))
        alive = [thread.name for thread in executor._threads if thread.is_alive()]
        still_pending = len(asyncio.all_tasks(loop))
        for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            loop.remove_signal_handler(sig)
        loop.close()
        asyncio.set_event_loop(None)
        c.write(directory / "client-cleanup.json", dict(
            worker_threads_remaining=alive, async_tasks_remaining=still_pending,
            error_type=failure, joined=not alive and not still_pending, finished_at=time.monotonic()))
    return outcome, not alive and not still_pending and failure is None


def main():
    import argparse
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--owned-client", action="store_true", required=True)
    parser.parse_args()
    c.remote_only()
    sys.pycache_prefix = str(c.STATE / "python-cache-evidence")
    c.verify_code()
    os.chdir(c.PREFLIGHT)
    c.preflight().frozen.verify()
    config = c.private_config()
    invocation = c.load(c.STATE / "client-invocation.json")
    c.owned_parent(invocation["owner_pid"], invocation["owner_start_ticks"])
    c.write(c.STATE / "client-single-entry.json", dict(pid=os.getpid()))
    started = {name: c.load(c.PUBLIC / name / "started.json") for name in ("native", "gateway")}
    output = c.PUBLIC / "client"
    output.mkdir(mode=0o700)

    async def run():
        import httpx
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(c.ALIAS, local_files_only=True)
        wire = Wire(output, config["ADMIN_API_KEY"], c.domain(),
            httpx.AsyncClient(base_url="http://127.0.0.1:8000", timeout=0.2, trust_env=False),
            httpx.AsyncClient(base_url="http://127.0.0.1:8080", timeout=0.2, trust_env=False))
        try:
            return await protocol_run(wire, output, started, invocation["startup_deadline"], tokenizer)
        finally:
            await wire.close()

    result, joined = bounded_loop(run(), output)
    return 0 if joined and result and result["component_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
