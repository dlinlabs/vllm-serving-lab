OWNED FIXED32 OWNER-ACQUISITION ADAPTER01

This is a new CPU-tested default-off candidate, not an author-executed Native
experiment or MPC/model qualification. Mayor must review/freeze/preregister it.
Engineering authority: inputs/approval01.json; host receipt is read-only prior
evidence, not proof that the new composition has run.

Protocol and dependencies were frozen before CPU controls. PROTOCOL.json retains
the original260/180/20/3/40/17 budgets, cleanup7+30+2+1, fixed32, one cap16 warmup,
one same-budget32 CAS0->1, and two serial cap16 offers. Final3s includes the legacy
sample, fixed0.25s/max9 full samples/two empty, one end and one ACK after fsync and
SHA reread. No CAS/offer/cut/end/ACK retries, resampling, restore, model or MPC.
All logical-empty/physical-stock distinctions, refusals and startup samples stay.

Approved route: omit prepared-copy-ready (flag0), retain prepared-forward/light,
enable the existing exact phase/input-post hooks, Source13-first. No inherited
copy-ready timing qualification. Source/installed SDK/old capsules are untouched.
SOURCE_DECLARATION01.json discloses the private passive post-exec origin guard.
It attests existing modules; it is not an observer or replacement source contract.
Gateway stays the actual owned session-leader PID through source-pinned exec;
redaction belongs to joined parent readers, not an intermediate serving leader.

Mayor deployment and exact paths: DEPLOYMENT.json. The complete hierarchy matters:
process_clock_provenance resolves its source pin through parents[3]. Copy the
sealed directory outside SourceRoot; do not install packages or flatten inputs.
No old spent entrypoint/main is called.

Default-off command in the staged directory:
  /workspace/pr32-r23/venv/bin/python -I -B launch01.py

After review, external exclusive GPU lock and a NEW preregistration commit,
write a separate preregistration JSON using MAYOR_PREREGISTRATION.template.json
(the template intentionally refuses). Then, ONCE, from the staged directory:
  /workspace/pr32-r23/venv/bin/python -I -B launch01.py \
    --execute-on-existing-gpu \
    --mayor-preregistration /workspace/pr32-r23/mayor-owner-adapter01-preregistration.json

The launcher independently flocks its declared remote lock. Do not additionally
hold that same flock in the calling shell. Both private state and public output
must be absent; any attempted namespace is spent. No retry or existing-state use.
The existing model/cache alias must already exist and match; downloads disabled.
Actual short private TMPDIR preflight occurs before any native service.

Read export-gate.json FIRST. Require safe_to_export=true and no DO_NOT_EXPORT.json
before retrieval. Private state/config is never an export input. Private config is
removed only after all owned processes/readers join; otherwise it is quarantined.
Unknown/partial JSON refuses public export. Safe failures still retain raw index,
all-offered ledger, client result, source snapshots, process logs and lifecycle.
No missing receipt is evidence that a request was not sent.

Offline replay of a safely exported public result:
  python -I -B replay01.py ABSOLUTE_PUBLIC_OUTPUT
This validates reported raw/hash/closure/stock/prefix/offer/capture chronology and
supervision, not fresh procfs. It never starts services or makes Native claims.
The synthetic controls call its client portion under source-derived fake core,
worker, transport and clocks. Actual Source13 CAS/ledger/phase/capture/closure code
runs in those fixtures; synthetic success does not prove real hook registration.

CPU replay (new exclusive output names; preserve prior attempts):
  sh validate.sh ABSOLUTE_PYTHON development UNIQUE_ATTEMPT
The harness blocks sockets, DNS, native imports and arbitrary processes. Only
bounded benign owned fixture children are allowed; joined receipts are retained.
Run both designated Python3.14 and3.12. All test artifacts stay under attempts/.

Source age and collector receipt cutoffs are absolute. Public request memory
uses the unchanged Gateway tokenizer estimator and refuses fallback. Full
scheduler/issued/ghost/zero-work stock is retained even after logical completion.
End/ACK requires source/epoch/complete/hash/actual-offer inventory consistency.
Blocking callback transport is bounded0.2; the explicit executor never invokes
unbounded asyncio.run/default-executor shutdown. A worker that cannot join causes
refusal; the owning client process is reaped by the supervisor. Unkillable OS
work cannot be promised away: survivors prevent success/export/config deletion.

actual_application_at remains null. Old ack.applied_at is a pre-write sample,
not an exact effect timestamp. The confirmed interval upper precedes capture;
budget version1 is NOT an acquisition/request token. Original point-only,
prediction/model/comparison/MPC gates and Native14FAIL remain unchanged.
Two full empty samples do not prove persistent or GPU-future quiescence.
