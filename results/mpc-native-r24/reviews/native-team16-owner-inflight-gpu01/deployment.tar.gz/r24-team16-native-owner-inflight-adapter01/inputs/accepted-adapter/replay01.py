"""Offline reported-evidence replay; never starts services or re-proves live procfs."""

import argparse
import base64
from dataclasses import asdict
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common01 as c


def check_client(directory):
    directory = Path(directory)
    pre, result = c.preflight(), c.load(directory / "client/result.json")
    api = pre.frozen.control()
    c.require(result["component_pass"] is True and not result["failures"]
              and result["actual_application_at"] is None and not result["native_mpc_permitted"],
              "reported_component_refusal")
    records = [c.load(path) for path in sorted((directory / "client/http").glob("*.json"),
                                              key=lambda p: int(p.stem))]
    c.require(1 <= len(records) <= 1900 and [r["sequence"] for r in records] == list(range(len(records))),
              "HTTP_complete_sequence")
    for row in records:
        raw = base64.b64decode(row["response_body_base64"], validate=True)
        c.require(c.sha_bytes(raw) == row["response_body_sha256"]
                  and len(raw) == row["response_bytes_captured"]
                  and row["auth_values_captured"] is False and row["credential_removed"] is False
                  and set(row["response_headers"]) <= {"content-type", "x-request-id"}
                  and row["client_send_at"] <= row["client_receive_at"] <= result["finished_at"],
                  "HTTP_raw_receipt_binding")
        if not row["role"].startswith("startup-health-"):
            pre.receipt_body(row, method=row["method"], path=row["path"], cutoff=result["finished_at"])
    planned = c.load(c.PREFLIGHT / "PROPOSED_OFFERS.json")["rows"]
    offers = result["offers"]
    c.require(len(offers) == 2 and [r["request_id"] for r in offers] ==
              [r["request_id"] for r in planned], "offered_inventory")
    all_offers = [r for r in records if r["path"] == "/v1/chat/completions"]
    commands = [r for r in records if r["path"] == "/admin/mpc/budget"]
    batches = [r for r in records if r["path"] == "/pr33-native/batch"]
    c.require(len(all_offers) == 3 and sum(r["role"] == "one-warmup" for r in all_offers) == 1
              and len(commands) == 1 and json.loads(commands[0]["request_body"])["budget"] == 32
              and all(json.loads(r["request_body"])["max_tokens"] == 16 for r in all_offers)
              and [json.loads(r["request_body"])["operation"] for r in batches] ==
              ["metadata", "begin", "end", "ack"], "fixed_protocol_no_extra_requests")
    startup = c.load(directory / "client/bootstrap-inputs.json")
    initial = c.load(directory / "client/initial-cut.json")
    pre.bootstrap_inputs(startup, cutoff=initial["cut"]["validated_at"])
    closure = pre.frozen.module("capture_owner_closure").establish_initial_capture_closure(
        initial["cut"], native_startup=startup["native_owned"], gateway_startup=startup["gateway_owned"])
    c.require(api.canonical(asdict(closure)) == api.canonical(result["initial_closure"]), "closure_binding")
    memory, previous = {}, None
    names = ["initial-cut", "offer-1-cut", "offer-2-cut"]
    for index, name in enumerate(names):
        if index:
            offer = offers[index - 1]
            row = records[offer["record"]]
            c.require(row["request_id"] == offer["request_id"]
                      and api.offer_fate(row, offer["request_id"]) == offer["fate"]
                      and offer["fate"] in ("completed_stop", "completed_length")
                      and previous["cut"]["validated_at"] <= offer["send_intent_at"]
                      <= row["client_send_at"] <= row["client_receive_at"]
                      and row["client_send_at"] - previous["cut"]["cut_at"] <= 0.5,
                      "offer_receipt_cutoff_or_fate")
            memory[offer["request_id"]] = pre.frozen.module("live_owner_prefix").PublicRequest(
                offer["prompt_tokens"], 16)
        journal = c.load(directory / "client" / (name + ".json"))
        cut = journal["cut"]
        view = pre.inspect_cut(cut, consume_at=journal["observation"]["consumed_at"],
                               deadline=result["active_started_at"] + 20)
        c.require(api.canonical(view) == api.canonical(journal["observation"])
                  and view["gateway_budget_version"] == 1, "reported_stock_or_version_changed")
        phases = pre.frozen.module("source_owner_phases").classify_source_owners(
            cut, initial_closure=closure, native_startup=startup["native_owned"], public_memory=memory,
            now=journal["phases"]["classified_at"], expected_clock_domain=cut["common_clock_proof"]["clock_domain"])
        c.require(api.canonical(phases.evidence()) == api.canonical(journal["phases"]), "phase_replay")
        prefix = directory / "client" / (name + "-prefix.jsonl")
        c.require(c.sha(prefix) == cut["owner_prefix"]["receipt"]["prefix_sha256"]
                  and prefix.stat().st_size == cut["owner_prefix"]["prefix_bytes"], "retained_prefix_bytes")
        previous = journal
    final = c.load(directory / "client/final-drain.json")
    c.require(final["status"] == "two_complete_empty_observations"
              and final["deadline"] == result["active_finished_at"] + 3
              and final["finished_at"] <= final["deadline"]
              and result["active_finished_at"] <= result["active_started_at"] + 20,
              "final_clock_bound")
    native_run = startup["native_owned"]["readiness"]["frames"][0]["run_id"]
    legacy = api.native_state(records[final["legacy_record"]], pre.frozen.settings(), native_run=native_run)
    expected_legacy = (None if all(legacy[k] == 0 for k in
        ("running", "waiting", "pending_batches", "frontend_unfinished"))
        else "legacy_final_native_not_drained_at_first_snapshot")
    c.require(final["legacy_failure"] == expected_legacy and 2 <= len(final["samples"]) <= 9,
              "legacy_failure_preserved")
    consecutive, last_received = 0, None
    for sample in final["samples"]:
        row = records[sample["record"]]
        _, empty = api.full_queue_observation(
            row, pre.frozen.settings(), native_run=native_run, deadline=final["deadline"])
        c.require(empty == sample["empty"] and (
            last_received is None or row["client_send_at"] - last_received >= 0.25), "final_fixed_poll")
        consecutive = consecutive + 1 if empty else 0
        last_received = row["client_receive_at"]
    c.require(consecutive == 2, "full_stock_empty_not_proved")
    ended, acknowledged = map(api.body, batches[-2:])
    retained = c.load(directory / "client/retained-capture.json")
    c.require(ended["capture_valid"] is True and not ended["validation_errors"]
              and api.canonical(ended["capture"]) == api.canonical(retained)
              and c.sha(directory / "client/retained-capture.json") == ended["capture_sha256"]
              and json.loads(batches[-1]["request_body"])["capture_sha256"] == ended["capture_sha256"]
              and acknowledged["acknowledged"] is True
              and last_received <= batches[-2]["client_send_at"] <= batches[-2]["client_receive_at"]
              <= batches[-1]["client_send_at"] <= batches[-1]["client_receive_at"] <= final["deadline"],
              "capture_retention_ACK_chronology")
    return dict(scope="OFFLINE_REPORTED_EVIDENCE_NOT_NEW_NATIVE_EXECUTION",
                component_evidence_consistent=True, actual_application_at=None,
                native_mpc_permitted=False, model_qualified=False,
                live_procfs_reproved=False, offers=2, warmup=1, legacy_failure=expected_legacy)


def main(argv=None):
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args(argv)
    directory = args.directory.resolve()
    os.chdir(c.PREFLIGHT)
    c.verify(False)
    try:
        c.require(not (directory / "DO_NOT_EXPORT.json").exists(), "export_revoked")
        gate = c.load(directory / "export-gate.json")
        supervision = c.load(directory / "supervision.json")
        c.require(gate["safe_to_export"] and gate["component_pass"]
                  and gate["completed_at"] <= gate["absolute_deadline"]
                  and supervision["component_pass"] and supervision["phase_bounds"]
                  and supervision["sources_unchanged"] and supervision["candidate_unchanged"]
                  and supervision["cleanup"]["all_joined"] and supervision["cleanup"]["capture_complete"]
                  and supervision["private_config_removed_after_join"], "supervision_or_export_refused")
        index = c.load(directory / "result-index.json")
        names = {row["path"] for row in index["files"]}
        actual = {str(path.relative_to(directory)) for path in directory.rglob("*")
                  if path.is_file() and path.name not in index["excluded_final_files"]}
        c.require(names == actual and len(names) == len(index["files"]), "complete_output_inventory")
        for row in index["files"]:
            name = Path(row["path"])
            c.require(not name.is_absolute() and ".." not in name.parts, "index_path")
            path = directory / name
            c.require(path.is_file() and not path.is_symlink() and c.sha(path) == row["sha256"]
                      and path.stat().st_size == row["bytes"], "raw_file_binding")
        reply = check_client(directory)
    except (ValueError, KeyError, TypeError, OSError) as error:
        reply = dict(scope="OFFLINE_REPLAY_REFUSAL", component_evidence_consistent=False,
                     error_type=type(error).__name__, actual_application_at=None, native_mpc_permitted=False)
    print(json.dumps(reply, sort_keys=True))
    return 0 if reply["component_evidence_consistent"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
