"""Bounded default/help/refusal CLI controls; no live flag or network."""

import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import common01 as c


def main():
    name, = sys.argv[1:]
    c.require(Path.cwd().resolve() == c.HERE and "/" not in name, "exclusive_smoke_name")
    output = c.HERE / "outputs" / name
    output.mkdir()
    before = c.verify_code()
    cases = [
        ("default", "launch01.py", [], 0),
        ("launcher-help", "launch01.py", ["--help"], 0),
        ("service-help", "service01.py", ["--help"], 0),
        ("client-help", "acquire01.py", ["--help"], 0),
        ("replay-unknown", "replay01.py", [str(output / "absent-native-result")], 1),
    ]
    rows = []
    for label, script, args, expected in cases:
        command = [sys.executable, "-I", "-B", str(c.HERE / script), *args]
        with (output / (label + ".log")).open("xb") as log:
            process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            ticks = c.owner().snapshot(process.pid)[0]
            started = time.monotonic()
            timeout = False
            try:
                status = process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                timeout = True
                process.kill()
                status = process.wait(timeout=2)
        rows.append(dict(command=command, pid=process.pid, start_ticks=ticks, returncode=status,
                         expected=expected, elapsed_s=time.monotonic()-started,
                         timeout=timeout, joined=True, log=label + ".log"))
    for path in c.HERE.glob("*.py"):
        ast.parse(path.read_bytes(), filename=str(path))
    children = Path(f"/proc/{os.getpid()}/task/{os.getpid()}/children").read_text().split()
    passed = all(row["returncode"] == row["expected"] and not row["timeout"] for row in rows) and not children
    c.write(output / "receipt.json", dict(
        passed=passed, rows=rows, child_pids_remaining=children, code_before=before,
        code_after=c.verify_code(), scope="CPU_DEFAULT_HELP_OFFLINE_REFUSAL_ONLY"))
    print(json.dumps(dict(output=str(output), passed=passed, cases=len(rows), remaining_children=children)))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
