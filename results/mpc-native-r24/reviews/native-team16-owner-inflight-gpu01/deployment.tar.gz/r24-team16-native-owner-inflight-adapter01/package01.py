"""Local evidence/index/seal packaging only; no Native execution path."""

import difflib
import json
import os
from pathlib import Path
import sys
import time
import xml.etree.ElementTree as ET

import common01 as c


def original_seal():
    root = c.HERE.parent / "r24-team16-native-owner-acquisition-adapter01"
    manifest = root / "SHA256SUMS"
    c.require(c.sha(manifest) == c.protocol()["accepted_parent_manifest"], "accepted_parent_manifest")
    names = set()
    for line in manifest.read_text().splitlines():
        fingerprint, name = line.split("  ", 1)
        path = root / name
        c.require(not Path(name).is_absolute() and ".." not in Path(name).parts
                  and name not in names and path.is_file() and not path.is_symlink()
                  and c.sha(path) == fingerprint, "accepted_parent_changed")
        names.add(name)
    actual = {str(path.relative_to(root)) for path in root.rglob("*")
              if path.is_file() and path != manifest}
    c.require(actual == names, "accepted_parent_inventory_changed")
    return dict(manifest_sha256=c.sha(manifest), verified_files=len(names), entire_seal_unchanged=True)


def gone(identities):
    rows = []
    for pid, ticks in sorted(identities):
        state = c.owner().snapshot(pid)
        absent = state is None or state[0] != ticks
        c.require(absent, "owned_identity_still_present")
        rows.append(dict(pid=pid, start_ticks=ticks, original_identity_absent=True))
    return rows


def prepare():
    c.require(not (c.HERE / "REPORT.json").exists(), "exclusive_packaging")
    c.verify_code()
    bindings = c.verify(True)
    removed = []
    for path in sorted(c.HERE.rglob("*")):
        if not path.is_symlink():
            continue
        relative, target = path.relative_to(c.HERE), path.resolve(strict=True)
        c.require(relative.parts[0] == "attempts" and path.parent.name == "work"
                  and path.name.endswith("current") and target.is_dir()
                  and target.is_relative_to(path.parent), "unknown_symlink_not_removed")
        removed.append(dict(path=str(relative), target=os.readlink(path),
                            retained_target=str(target.relative_to(c.HERE))))
        path.unlink()
    c.write(c.HERE / "PYTEST_CONVENIENCE_CLEANUP.json", dict(
        scope="Only pytest current symlinks removed; every target/raw/failure retained", rows=removed))
    identities, attempts, failures, helper_reports, commands = set(), [], [], [], []
    for receipt in sorted((c.HERE / "attempts").glob("*/result.json")):
        result = c.load(receipt)
        directory = receipt.parent
        child = c.load(directory / "child-result.json")
        c.require(result["joined"] and not result["timeout"] and not child["threads_remaining"]
                  and not child["child_pids_remaining"], "test_helper_not_drained")
        identities.add((result["pid"], int(result["start_ticks"])))
        suite = ET.parse(directory / "junit.xml").getroot().find("testsuite")
        row = dict(name=directory.name, tests=int(suite.attrib["tests"]),
                   failures=int(suite.attrib["failures"]), errors=int(suite.attrib["errors"]),
                   returncode=result["returncode"], helpers_drained=True,
                   output=str((directory / "output.log").relative_to(c.HERE)),
                   exact_source_snapshot=str((directory / "code").relative_to(c.HERE)),
                   before_after_bindings_unchanged=result["inputs_before"] == result["inputs_after"])
        attempts.append(row)
        for case in suite.findall("testcase"):
            error = case.find("failure")
            if error is None:
                error = case.find("error")
            if error is not None:
                failures.append(dict(attempt=directory.name, test=case.attrib["name"],
                                     message=error.attrib.get("message"), full_raw=row["output"]))
        commands.append(dict(wrapper=["sh", "validate.sh", result["command"][0], "development", directory.name],
                             child_argv=result["command"], returncode=result["returncode"],
                             environment="Frozen validate.sh: unsetPYTHONPATH/threads1/nobytecode/noautoload/nocache/nice19/-B",
                             receipt=str(receipt.relative_to(c.HERE))))
    for path in sorted((c.HERE / "attempts").rglob("owned-cleanup.json")):
        row = c.load(path)
        c.require(row["all_joined"] and not row["surviving_owned_pids"], "owned_fixture_not_joined")
        identities.update((int(pid), int(ticks)) for pid, ticks in row["owned_pid_start_ticks"].items())
        helper_reports.append(dict(path=str(path.relative_to(c.HERE)), all_joined=True,
                                   identities=len(row["owned_pid_start_ticks"])))
    cli = []
    for path in sorted((c.HERE / "outputs").glob("*/receipt.json")):
        row = c.load(path)
        c.require(row["passed"] and not row["child_pids_remaining"], "CLI_failure_or_survivor")
        cli.append(dict(name=path.parent.name, cases=len(row["rows"]), passed=True))
        for call in row["rows"]:
            c.require(call["joined"] and not call["timeout"], "CLI_child_not_joined")
            identities.add((call["pid"], int(call["start_ticks"])))
            commands.append(dict(argv=call["command"], returncode=call["returncode"],
                                 expected=call["expected"], receipt=str(path.relative_to(c.HERE)),
                                 output=str((path.parent / call["log"]).relative_to(c.HERE))))
    final = [row for row in attempts if row["name"].startswith("final04-")]
    c.require(len(final) == 2 and all(row["tests"] == 70 and row["failures"] == row["errors"] ==
                                   row["returncode"] == 0 for row in final), "final_dual_controls")
    c.require(len([row for row in cli if row["name"].startswith("cli04-")]) == 2, "final_dual_CLI")
    source_cases = []
    for version in ("py314", "py312"):
        for path in sorted((c.HERE / "attempts" / ("final04-" + version) / "work").rglob("result.json")):
            row = c.load(path)
            if row.get("schema") != "team16-owner-inflight-result-v1":
                continue
            source_cases.append(dict(version=version, raw=str(path.relative_to(c.HERE)),
                engineering_pass=row["engineering_pass"], component_pass=row["component_pass"],
                nonempty_overlap_count=row["nonempty_overlap_count"],
                outcomes=[offer["fate"] for offer in row["offers"]],
                classifications=[offer.get("inflight", {}).get("status") for offer in row["offers"]],
                physical_stock=[offer.get("inflight", {}).get("stock_counts") for offer in row["offers"]],
                failures=row["failures"], scope="SYNTHETIC_SOURCE_CPU_ONLY"))
    c.require(len(source_cases) == 24 and sum(row["component_pass"] for row in source_cases) == 4,
              "expected_source_scenarios")
    for label in ("default", "prior-accepted-empty"):
        a = c.HERE / "outputs/cli04-py314" / (label + ".log")
        b = c.HERE / "outputs/cli04-py312" / (label + ".log")
        c.require(a.read_bytes() == b.read_bytes(), "dual_CLI_view_disagreement")
    prior = c.load(c.HERE / "outputs/cli04-py314/prior-accepted-empty.log")
    original = original_seal()
    old_guard = (c.HERE / "inputs/accepted-adapter/origin_guard/sitecustomize.py").read_text()
    new_guard = (c.HERE / "origin_guard/sitecustomize.py").read_text()
    expected = old_guard.replace("R24_OWNER_ORIGIN_", "R24_OWNER_INFLIGHT_ORIGIN_").replace(
        "/owner-state01/origins", "/owner-inflight-state01/origins-inflight01")
    c.require(new_guard == expected, "origin_guard_change_beyond_declared_namespace")
    c.require(c.sha(c.HERE / "owned01.py") == c.sha(c.HERE / "inputs/accepted-adapter/owned01.py"),
              "ownership_primitive_changed")
    c.write(c.HERE / "HELPER_INDEX.json", dict(
        scope="Only this candidate's known owned CPU helpers; no outsider processes signalled",
        all_known_owned_identities_gone=True, identities=gone(identities), receipts=helper_reports,
        intentional_blocked_worker="Its own refusal/remaining-thread receipt is retained; the outer owned process was subsequently reaped and joined. Not silently treated as a successful child shutdown."))
    c.write(c.HERE / "COMMANDS.json", dict(
        source_freeze="freeze01.py -> attempts/source-freeze01.log; PRE_SOURCE_FREEZE.json precedes controls",
        revisions=[str(p.relative_to(c.HERE)) for p in sorted((c.HERE / "attempts").glob("code-freeze-*.json"))],
        amendment="freeze_plan_amendment01.py -> attempts/plan-amendment01.log; PLAN_AMENDMENT01.json",
        validations=commands, Native_commands_executed_by_author=[],
        prospective_Mayor_command=c.load(c.HERE / "DEPLOYMENT.json")["Mayor_command"]))
    c.write(c.HERE / "SOURCE_INDEX.json", dict(
        original_and_copied_bindings="INPUTS.json", bindings=bindings,
        candidate_runnables=c.load(c.HERE / "RUNNABLES.json"),
        original_plan_retained="NATIVE_PLAN.json", effective_plan=str(c.PLAN.name),
        plan_amendment="PLAN_AMENDMENT01.json", accepted_parent=original,
        prior_raw=prior, ownership_primitive_byte_identical=True,
        origin_guard_only_declared_namespace_changes=True,
        origin_diff=list(difflib.unified_diff(old_guard.splitlines(), new_guard.splitlines(),
                                            fromfile="accepted-private-guard", tofile="new-private-guard")),
        source_contracts_relaxed=False))
    c.write(c.HERE / "FAILURES.json", dict(
        failed_attempts=[row for row in attempts if row["returncode"] != 0], cases=failures,
        diagnosed_cause="First candidate plan seed170103 violated unchanged TRAIN170001..170012 guard before any synthetic protocol execution.",
        repair="Separate source-only seed170003 amendment, frozen before successor controls. Original source guard/plan/logs kept; no outcome/trigger/payload/budget tuning.",
        investigation_notes=["A read-only lookup of a predecessor template not in the narrow retained prototype set found no file. The new disabled template was derived directly from authority(); no original was edited or entrypoint executed.",
                             "code-freeze-development01 was an untested pre-review revision; the first CPU attempt was development02-py314."],
        all_attempts=attempts))
    c.write(c.HERE / "REPORT.json", dict(
        schema="team16-owner-inflight-CPU-delivery-v1", prepared_at_unix=time.time(),
        status="CPU_VERIFIED_CANDIDATE_REQUIRES_VALID_FINAL_MANIFEST_AND_MAYOR_REVIEW_NOT_NATIVE_QUALIFIED",
        author_Native_executions=0, author_network_SSH_GPU_git_installs_or_nested_agents=0,
        final_tests=final, final_CLI=[r for r in cli if r["name"].startswith("cli04-")],
        original_bindings_unchanged=bindings, entire_predecessor_unchanged=original,
        prior_evidence=prior, prior_views_and_default_byte_identical_across_Pythons=True,
        focused_source_scenarios=source_cases,
        changes=["Concurrent atomic receipt/ID/cap reservation; no whole-managed-POST Wire lock",
                 "Immutable per-call settings and explicit finite HTTPX/absolute timeouts",
                 "One fixed20ms pending-offer source cut plus each permitted post-outcome cut",
                 "Actual target stock/source/receipt overlap classification; empty/early/historical/refused truthfully distinct",
                 "Unchanged full ghost/zero-work/closure/process-clock/flushed-prefix contracts",
                 "Joined current transport and preserved post-outcome cut even when source/assessment refuses",
                 "Both clients closed even when capture cleanup refuses; bounded task/client/executor cleanup",
                 "New stage/state/origin/capture/operation/offer names; accepted owned/redaction primitives unchanged"],
        explicit_plan_amendment="PLAN_AMENDMENT01.json; review seed170103->170003 correction and effective NATIVE_PLAN.revision01.json before any Native staging.",
        failure_index="FAILURES.json", source_index="SOURCE_INDEX.json", command_index="COMMANDS.json",
        helper_index="HELPER_INDEX.json", deployment="DEPLOYMENT.json",
        source_or_budget_contract_relaxation=False,
        limitations=["Synthetic core/worker/transport/clock fixtures are not new Native evidence.",
                     "Prior real component had only three EMPTY cuts; it cannot establish inflight coverage.",
                     "Counting prompt may finish early or miss its single window; no retries/resampling to find success.",
                     "Actual scheduler delay/source-cut latency and0.2 transport bounds may cause truthful refusal.",
                     "Collector availability before terminal receipt is required; source-time-only historical overlap is insufficient.",
                     "Two finite full-empty observations do not prove persistent or future GPU quiescence.",
                     "Exact application point remains unknown; budget version is not a request/acquisition token.",
                     "No model, predictive, P2, benchmark comparison, deployment or NativeMPC qualification.",
                     "Unkillable OS work cannot be promised away; remaining owned identities prevent success/export/config deletion."],
        Native_prerequisites=["Mayor full review/Parent replay of this seal AND seed-only amendment, then NEW local prospective preregistration commit",
                              "Stage complete hierarchy outside SourceRoot; only new absent state/public namespaces",
                              "Existing external exclusive GPU lease plus launcher shared nonblocking flock",
                              "Repeat sameboot/GPU-idle/ports/model alias/source-before/installed38-file SDK/all4 entrypoint guards",
                              "Real post-exec/fork module origins and actual serving session-leader PID; no old receipt substitution",
                              "Actual short0700 TMPDIR receipt before service,0600 private config, capture-time redaction",
                              "One warmup, two complete initial empty samples with every preceding sample retained, real same-budgetCAS0->1 confirmation before capture",
                              "Actual process-clock/phase/lifecycle/publication/flushed byte-prefix initial closure before offers",
                              "Two fixed serial offers, at most one fixed-trigger inflight cut each and permitted post-outcome cuts; retain all misses/refusals",
                              "Original260/180/20/3/40/17 and7+30+2+1; final stock/end/ACK, all helpers joined, private config removed, safe export and independent Mayor postchecks"],
        actual_application_at=None, acquisition_token=None, request_token=None,
        deployable=False, qualified_model=False, prediction_qualified=False,
        Native14="FAIL unchanged", native_mpc_permitted=False,
        expected_final_action="Seal complete directory; stop idle. Mayor alone may authorize one fresh Native component."))
    print(json.dumps(dict(prepared=True, tests_each=70, CLI_each=6, retained_failures=len(failures),
                          helper_identities=len(identities), original_bindings=bindings["bindings"]),
                     sort_keys=True))


def seal():
    report = c.load(c.HERE / "REPORT.json")
    c.verify_code()
    c.verify(True)
    c.require(original_seal() == report["entire_predecessor_unchanged"], "parent_postpackaging_change")
    helpers = c.load(c.HERE / "HELPER_INDEX.json")["identities"]
    gone({(row["pid"], row["start_ticks"]) for row in helpers})
    files = sorted(path for path in c.HERE.rglob("*") if path.is_file())
    c.require(not any(path.is_symlink() for path in c.HERE.rglob("*")), "unsealed_symlink")
    with (c.HERE / "SHA256SUMS").open("x") as stream:
        for path in files:
            stream.write(c.sha(path) + "  " + str(path.relative_to(c.HERE)) + "\n")
    for path in files + [c.HERE / "SHA256SUMS"]:
        path.chmod(0o444)
    for path in sorted((p for p in c.HERE.rglob("*") if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
        path.chmod(0o555)
    c.HERE.chmod(0o555)
    print(json.dumps(dict(sealed=True, manifest_sha256=c.sha(c.HERE / "SHA256SUMS"),
                          manifest_entries=len(files), total_files=len(files) + 1,
                          total_bytes=sum(p.stat().st_size for p in files + [c.HERE / "SHA256SUMS"])),
                     sort_keys=True))


if __name__ == "__main__":
    c.require(Path.cwd().resolve() == c.HERE and sys.argv[1:] in (["prepare"], ["seal"]),
              "local_packaging_argument")
    (prepare if sys.argv[1] == "prepare" else seal)()
